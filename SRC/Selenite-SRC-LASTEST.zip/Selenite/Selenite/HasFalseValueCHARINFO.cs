﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000053 RID: 83
[StructLayout(2, Pack = 1, Size = 656)]
internal struct HasFalseValueCHARINFO
{
	// Token: 0x0400017B RID: 379 RVA: 0x000638AD File Offset: 0x00061AAD
	internal static readonly HasFalseValueCHARINFO ICspAsymmetricAlgorithmmowned;
}
