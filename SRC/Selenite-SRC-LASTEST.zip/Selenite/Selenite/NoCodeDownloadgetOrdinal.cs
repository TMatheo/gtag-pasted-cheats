﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000061 RID: 97
[StructLayout(2, Pack = 1, Size = 936)]
internal struct NoCodeDownloadgetOrdinal
{
	// Token: 0x04000189 RID: 393 RVA: 0x0006573D File Offset: 0x0006393D
	internal static readonly NoCodeDownloadgetOrdinal getRegisteredChannelsMemberPrimitiveTyped;
}
