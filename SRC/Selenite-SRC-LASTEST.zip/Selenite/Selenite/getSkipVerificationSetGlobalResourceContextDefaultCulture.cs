﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200005E RID: 94
[StructLayout(2, Pack = 1, Size = 544)]
internal struct getSkipVerificationSetGlobalResourceContextDefaultCulture
{
	// Token: 0x04000186 RID: 390 RVA: 0x0006506D File Offset: 0x0006326D
	internal static readonly getSkipVerificationSetGlobalResourceContextDefaultCulture TokenGroupsAndPrivilegesSyncProcessMessage;
}
