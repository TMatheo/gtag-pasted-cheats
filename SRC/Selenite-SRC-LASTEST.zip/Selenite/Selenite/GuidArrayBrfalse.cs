﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000059 RID: 89
[StructLayout(2, Pack = 1, Size = 408)]
internal struct GuidArrayBrfalse
{
	// Token: 0x04000181 RID: 385 RVA: 0x0006458D File Offset: 0x0006278D
	internal static readonly GuidArrayBrfalse ManifestHashRC;
}
