﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200005F RID: 95
[StructLayout(2, Pack = 1, Size = 664)]
internal struct OneWayIsSingleByte
{
	// Token: 0x04000187 RID: 391 RVA: 0x0006528D File Offset: 0x0006348D
	internal static readonly OneWayIsSingleByte SponsorshipTimeoutgetIsAssemblyNameSetExplicit;
}
