﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200005B RID: 91
[StructLayout(2, Pack = 1, Size = 536)]
internal struct IsGlobalTypeDefTokenEmptySet
{
	// Token: 0x04000183 RID: 387 RVA: 0x0006491D File Offset: 0x00062B1D
	internal static readonly IsGlobalTypeDefTokenEmptySet TYPEFLAGFAGGREGATABLEDTDAttribute;
}
