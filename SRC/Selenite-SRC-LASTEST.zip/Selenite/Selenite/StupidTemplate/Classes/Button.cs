﻿using System;
using StupidTemplate.Menu;
using UnityEngine;

namespace StupidTemplate.Classes
{
	// Token: 0x0200003A RID: 58
	internal class Button : MonoBehaviour
	{
		// Token: 0x060009D0 RID: 2512 RVA: 0x0005B7E8 File Offset: 0x000599E8
		private static void GuestCMSASSEMBLYREFERENCEFLAGISPLATFORM(ref int A_0, ref int A_1, ref int A_2, Button A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060009D1 RID: 2513 RVA: 0x0005B80C File Offset: 0x00059A0C
		public void OnTriggerEnter(Collider collider)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 6)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,UnityEngine.Collider,StupidTemplate.Classes.Button), ref num, ref num2, ref num3, ref flag, collider, this, Button.PushRangeRSAOAEPKeyExchangeDeformatter[num]);
			}
			num2 = 0;
		}

		// Token: 0x060009D2 RID: 2514 RVA: 0x0005B844 File Offset: 0x00059A44
		private static void LeftAltPressedRuntimeEventInfo(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Collider A_4, Button A_5)
		{
			A_1 = 6;
		}

		// Token: 0x060009D3 RID: 2515 RVA: 0x0005B85C File Offset: 0x00059A5C
		private static void IsTokenOfTypeStructLayoutAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Collider A_4, Button A_5)
		{
			int num = ((!(A_4 == Main.buttonCollider)) ? 1 : 0) * 1 + 2;
			A_0 = num;
		}

		// Token: 0x060009D4 RID: 2516 RVA: 0x0005B8A8 File Offset: 0x00059AA8
		public Button()
		{
			int num = 6;
			int num2 = 6;
			num2 = 6;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.Button), ref num, ref num2, ref num3, this, Button.PushRangeRSAOAEPKeyExchangeDeformatter[num]);
			}
			num2 = 6;
		}

		// Token: 0x060009D5 RID: 2517 RVA: 0x0005B8DC File Offset: 0x00059ADC
		private static void ParseDisplayNamegetWindows(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Collider A_4, Button A_5)
		{
			bool flag = Main.menu != null;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x0005B944 File Offset: 0x00059B44
		private static void DataPtrStandardBias(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Collider A_4, Button A_5)
		{
			int num = (((Time.time > Button.buttonCooldown) ? 1 : 0) + -1) * -1 * 2 + 1;
			A_0 = num;
		}

		// Token: 0x060009D7 RID: 2519 RVA: 0x0005B984 File Offset: 0x00059B84
		private static void BackgroundGreenSetSwitch(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Collider A_4, Button A_5)
		{
			bool flag = false;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x060009D8 RID: 2520 RVA: 0x0005B9E0 File Offset: 0x00059BE0
		private static void NumberBufferRNGCryptoServiceProvider(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Collider A_4, Button A_5)
		{
			Button.buttonCooldown = Time.time + 0.15f;
			GorillaTagger.Instance.StartVibration(Settings.rightHanded, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Main.buttonClickSound, Settings.rightHanded, 0.1f);
			Main.Toggle(A_5.relatedText);
			A_1 = 6;
		}

		// Token: 0x060009D9 RID: 2521 RVA: 0x0005BA68 File Offset: 0x00059C68
		// Note: this type is marked as 'beforefieldinit'.
		static Button()
		{
			Button.MonthSpacesetRole();
		}

		// Token: 0x060009DA RID: 2522 RVA: 0x0005BA7C File Offset: 0x00059C7C
		private static void MonthSpacesetRole()
		{
			Button.PushRangeRSAOAEPKeyExchangeDeformatter = new IntPtr[7];
			Button.PushRangeRSAOAEPKeyExchangeDeformatter[0] = ldftn(DataPtrStandardBias);
			Button.PushRangeRSAOAEPKeyExchangeDeformatter[1] = ldftn(IsTokenOfTypeStructLayoutAttribute);
			Button.PushRangeRSAOAEPKeyExchangeDeformatter[2] = ldftn(ParseDisplayNamegetWindows);
			Button.PushRangeRSAOAEPKeyExchangeDeformatter[3] = ldftn(BackgroundGreenSetSwitch);
			Button.PushRangeRSAOAEPKeyExchangeDeformatter[4] = ldftn(NumberBufferRNGCryptoServiceProvider);
			Button.PushRangeRSAOAEPKeyExchangeDeformatter[5] = ldftn(LeftAltPressedRuntimeEventInfo);
			Button.PushRangeRSAOAEPKeyExchangeDeformatter[6] = ldftn(GuestCMSASSEMBLYREFERENCEFLAGISPLATFORM);
		}

		// Token: 0x0400014E RID: 334
		public string relatedText;

		// Token: 0x0400014F RID: 335
		public static float buttonCooldown;

		// Token: 0x04000150 RID: 336
		private static IntPtr[] PushRangeRSAOAEPKeyExchangeDeformatter;
	}
}
