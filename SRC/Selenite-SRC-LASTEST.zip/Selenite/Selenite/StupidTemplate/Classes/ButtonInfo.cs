﻿using System;

namespace StupidTemplate.Classes
{
	// Token: 0x0200003B RID: 59
	public class ButtonInfo
	{
		// Token: 0x060009DB RID: 2523 RVA: 0x0005BB10 File Offset: 0x00059D10
		private static void getLoadedAssemblyDirectoryName(ref int A_0, ref int A_1, ref int A_2, ButtonInfo A_3)
		{
			A_3.buttonText = "-";
			A_3.overlapText = null;
			A_3.method = null;
			A_3.enableMethod = null;
			A_3.disableMethod = null;
			A_3.enabled = false;
			A_3.isTogglable = true;
			A_3.toolTip = "This button doesn't have a tooltip/tutorial.";
			A_3..ctor();
			A_1 = 2;
		}

		// Token: 0x060009DC RID: 2524 RVA: 0x0005BB94 File Offset: 0x00059D94
		public ButtonInfo()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.ButtonInfo), ref num, ref num2, ref num3, this, ButtonInfo.OrdinalRandomizedComparerDebuggerStepThroughAttribute[num]);
			}
			num2 = 0;
		}

		// Token: 0x060009DD RID: 2525 RVA: 0x0005BBC8 File Offset: 0x00059DC8
		// Note: this type is marked as 'beforefieldinit'.
		static ButtonInfo()
		{
			ButtonInfo.getEncodingNameCustomAttributeExtensions();
		}

		// Token: 0x060009DE RID: 2526 RVA: 0x0005BBDC File Offset: 0x00059DDC
		private static void getEncodingNameCustomAttributeExtensions()
		{
			ButtonInfo.OrdinalRandomizedComparerDebuggerStepThroughAttribute = new IntPtr[1];
			ButtonInfo.OrdinalRandomizedComparerDebuggerStepThroughAttribute[0] = ldftn(getLoadedAssemblyDirectoryName);
		}

		// Token: 0x04000151 RID: 337
		public string buttonText;

		// Token: 0x04000152 RID: 338
		public string overlapText;

		// Token: 0x04000153 RID: 339
		public Action method;

		// Token: 0x04000154 RID: 340
		public Action enableMethod;

		// Token: 0x04000155 RID: 341
		public Action disableMethod;

		// Token: 0x04000156 RID: 342
		public bool enabled;

		// Token: 0x04000157 RID: 343
		public bool isTogglable;

		// Token: 0x04000158 RID: 344
		public string toolTip;

		// Token: 0x04000159 RID: 345
		private static IntPtr[] OrdinalRandomizedComparerDebuggerStepThroughAttribute;
	}
}
