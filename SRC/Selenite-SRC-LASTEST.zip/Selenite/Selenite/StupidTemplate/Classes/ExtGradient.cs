﻿using System;
using UnityEngine;

namespace StupidTemplate.Classes
{
	// Token: 0x0200003D RID: 61
	public class ExtGradient
	{
		// Token: 0x060009EE RID: 2542 RVA: 0x0005C080 File Offset: 0x0005A280
		public ExtGradient()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.ExtGradient), ref num, ref num2, ref num3, this, ExtGradient.LocationTYPEFLAGFAGGREGATABLE[num]);
			}
			num2 = 0;
		}

		// Token: 0x060009EF RID: 2543 RVA: 0x0005C0B4 File Offset: 0x0005A2B4
		private static void GetInspectableGetModules(ref int A_0, ref int A_1, ref int A_2, ExtGradient A_3)
		{
			A_3.colors = new GradientColorKey[]
			{
				new GradientColorKey(Color.blue, 0f),
				new GradientColorKey(Color.magenta, 0.5f),
				new GradientColorKey(Color.blue, 1f)
			};
			A_3.isRainbow = false;
			A_3.copyRigColors = false;
			A_3..ctor();
			A_1 = 1;
		}

		// Token: 0x060009F0 RID: 2544 RVA: 0x0005C154 File Offset: 0x0005A354
		// Note: this type is marked as 'beforefieldinit'.
		static ExtGradient()
		{
			ExtGradient.AppDomainManagerInitializationOptionsIIdentityAuthority();
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x0005C168 File Offset: 0x0005A368
		private static void AppDomainManagerInitializationOptionsIIdentityAuthority()
		{
			ExtGradient.LocationTYPEFLAGFAGGREGATABLE = new IntPtr[1];
			ExtGradient.LocationTYPEFLAGFAGGREGATABLE[0] = ldftn(GetInspectableGetModules);
		}

		// Token: 0x0400015D RID: 349
		public GradientColorKey[] colors;

		// Token: 0x0400015E RID: 350
		public bool isRainbow;

		// Token: 0x0400015F RID: 351
		public bool copyRigColors;

		// Token: 0x04000160 RID: 352
		private static IntPtr[] LocationTYPEFLAGFAGGREGATABLE;
	}
}
