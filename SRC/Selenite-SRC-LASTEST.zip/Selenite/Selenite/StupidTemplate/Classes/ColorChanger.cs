﻿using System;
using UnityEngine;

namespace StupidTemplate.Classes
{
	// Token: 0x0200003C RID: 60
	public class ColorChanger : TimedBehaviour
	{
		// Token: 0x060009DF RID: 2527 RVA: 0x0005BC0C File Offset: 0x00059E0C
		private static void getErrorgetConsistencyGuarantee(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref Color A_5, ref bool A_6, ref float A_7, ColorChanger A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060009E0 RID: 2528 RVA: 0x0005BC24 File Offset: 0x00059E24
		private static void SoapTokengetCancellationPending(ref int A_0, ref int A_1, ref int A_2, ColorChanger A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060009E1 RID: 2529 RVA: 0x0005BC48 File Offset: 0x00059E48
		private static void SystemAclPresentFrameworkDescription(ref int A_0, ref int A_1, ref int A_2, ColorChanger A_3)
		{
			A_3.Start();
			A_3.renderer = A_3.GetComponent<Renderer>();
			A_3.Update();
			A_1 = 2;
		}

		// Token: 0x060009E2 RID: 2530 RVA: 0x0005BC88 File Offset: 0x00059E88
		public override void Start()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.ColorChanger), ref num, ref num2, ref num3, this, ColorChanger.getOffsetSafeHeapHandle[num]);
			}
			num2 = 0;
		}

		// Token: 0x060009E3 RID: 2531 RVA: 0x0005BCBC File Offset: 0x00059EBC
		public ColorChanger()
		{
			int num = 9;
			int num2 = 9;
			num2 = 9;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.ColorChanger), ref num, ref num2, ref num3, this, ColorChanger.getOffsetSafeHeapHandle[num]);
			}
			num2 = 9;
		}

		// Token: 0x060009E4 RID: 2532 RVA: 0x0005BCF4 File Offset: 0x00059EF4
		private static void SaveZero(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref Color A_5, ref bool A_6, ref float A_7, ColorChanger A_8)
		{
			bool flag = !A_8.colorInfo.copyRigColors;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 3 + 3;
			A_0 = num;
		}

		// Token: 0x060009E5 RID: 2533 RVA: 0x0005BD60 File Offset: 0x00059F60
		private static void CallConvMaskAsyncTaskMethodBuilder(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref Color A_5, ref bool A_6, ref float A_7, ColorChanger A_8)
		{
			Color color = new Gradient
			{
				colorKeys = A_8.colorInfo.colors
			}.Evaluate(Time.time / 2f % 1f);
			A_5 = color;
			bool isRainbow = A_8.colorInfo.isRainbow;
			A_6 = isRainbow;
			int num = ((!A_6) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x060009E6 RID: 2534 RVA: 0x0005BE08 File Offset: 0x0005A008
		public override void Update()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				Color color;
				bool flag3;
				float num4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,UnityEngine.Color&,System.Boolean&,System.Single&,StupidTemplate.Classes.ColorChanger), ref num, ref num2, ref num3, ref flag, ref flag2, ref color, ref flag3, ref num4, this, ColorChanger.getOffsetSafeHeapHandle[num]);
			}
			num2 = 1;
		}

		// Token: 0x060009E7 RID: 2535 RVA: 0x0005BE48 File Offset: 0x0005A048
		private static void searchOptiongetParent(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref Color A_5, ref bool A_6, ref float A_7, ColorChanger A_8)
		{
			A_8.Update();
			bool flag = A_8.colorInfo != null;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 6 + 2;
			A_0 = num;
		}

		// Token: 0x060009E8 RID: 2536 RVA: 0x0005BEB8 File Offset: 0x0005A0B8
		private static void getCurrencySymbolEncodeTags(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref Color A_5, ref bool A_6, ref float A_7, ColorChanger A_8)
		{
			float num = (float)Time.frameCount / 180f % 1f;
			A_7 = num;
			A_8.renderer.material.color = A_5;
			A_0 = 7;
		}

		// Token: 0x060009E9 RID: 2537 RVA: 0x0005BF14 File Offset: 0x0005A114
		private static void MaxCapacityDynamicDirectory(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref Color A_5, ref bool A_6, ref float A_7, ColorChanger A_8)
		{
			A_8.renderer.material.color = A_5;
			A_0 = 7;
		}

		// Token: 0x060009EA RID: 2538 RVA: 0x0005BF4C File Offset: 0x0005A14C
		private static void IgnoreVisibilityArgRegSetMismatchedKind(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref Color A_5, ref bool A_6, ref float A_7, ColorChanger A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060009EB RID: 2539 RVA: 0x0005BF64 File Offset: 0x0005A164
		private static void FindMethodIsAppEarlierThanSilverlight(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref Color A_5, ref bool A_6, ref float A_7, ColorChanger A_8)
		{
			A_8.renderer.material = GorillaTagger.Instance.offlineVRRig.mainSkin.material;
			A_1 = 0;
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x0005BFA4 File Offset: 0x0005A1A4
		// Note: this type is marked as 'beforefieldinit'.
		static ColorChanger()
		{
			ColorChanger.setUseSaltRequireBraces();
		}

		// Token: 0x060009ED RID: 2541 RVA: 0x0005BFB8 File Offset: 0x0005A1B8
		private static void setUseSaltRequireBraces()
		{
			ColorChanger.getOffsetSafeHeapHandle = new IntPtr[10];
			ColorChanger.getOffsetSafeHeapHandle[0] = ldftn(SystemAclPresentFrameworkDescription);
			ColorChanger.getOffsetSafeHeapHandle[1] = ldftn(searchOptiongetParent);
			ColorChanger.getOffsetSafeHeapHandle[2] = ldftn(SaveZero);
			ColorChanger.getOffsetSafeHeapHandle[3] = ldftn(CallConvMaskAsyncTaskMethodBuilder);
			ColorChanger.getOffsetSafeHeapHandle[4] = ldftn(getCurrencySymbolEncodeTags);
			ColorChanger.getOffsetSafeHeapHandle[5] = ldftn(MaxCapacityDynamicDirectory);
			ColorChanger.getOffsetSafeHeapHandle[6] = ldftn(FindMethodIsAppEarlierThanSilverlight);
			ColorChanger.getOffsetSafeHeapHandle[7] = ldftn(getErrorgetConsistencyGuarantee);
			ColorChanger.getOffsetSafeHeapHandle[8] = ldftn(IgnoreVisibilityArgRegSetMismatchedKind);
			ColorChanger.getOffsetSafeHeapHandle[9] = ldftn(SoapTokengetCancellationPending);
		}

		// Token: 0x0400015A RID: 346
		public Renderer renderer;

		// Token: 0x0400015B RID: 347
		public ExtGradient colorInfo;

		// Token: 0x0400015C RID: 348
		private static IntPtr[] getOffsetSafeHeapHandle;
	}
}
