﻿using System;
using System.Collections.Generic;
using BepInEx;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace StupidTemplate.Classes
{
	// Token: 0x0200003E RID: 62
	internal class RigManager : BaseUnityPlugin
	{
		// Token: 0x060009F2 RID: 2546 RVA: 0x0005C198 File Offset: 0x0005A398
		private static Player getRNGSystemLazyDebugView(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref bool A_7, ref Player A_8, string A_9)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -4 + 31;
			A_0 = num;
			Player result;
			return result;
		}

		// Token: 0x060009F3 RID: 2547 RVA: 0x0005C1D8 File Offset: 0x0005A3D8
		public static VRRig GetVRRigFromPlayer(Player p)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			VRRig result;
			while (num2 != 3)
			{
				int num3;
				VRRig vrrig;
				result = calli(VRRig(System.Int32&,System.Int32&,System.Int32&,VRRig&,Photon.Realtime.Player), ref num, ref num2, ref num3, ref vrrig, p, RigManager.StaticIndexRangePartitionForArrayAllFiles[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060009F4 RID: 2548 RVA: 0x0005C214 File Offset: 0x0005A414
		public static Player GetPlayerFromID(string id)
		{
			int num = 26;
			int num2 = 26;
			num2 = 26;
			Player result;
			while (num2 != 0)
			{
				int num3;
				Player player;
				Player[] array;
				int num4;
				Player player2;
				bool flag;
				Player player3;
				result = calli(Photon.Realtime.Player(System.Int32&,System.Int32&,System.Int32&,Photon.Realtime.Player&,Photon.Realtime.Player[]&,System.Int32&,Photon.Realtime.Player&,System.Boolean&,Photon.Realtime.Player&,System.String), ref num, ref num2, ref num3, ref player, ref array, ref num4, ref player2, ref flag, ref player3, id, RigManager.StaticIndexRangePartitionForArrayAllFiles[num]);
			}
			num2 = 26;
			return result;
		}

		// Token: 0x060009F5 RID: 2549 RVA: 0x0005C25C File Offset: 0x0005A45C
		private static void OaepPreLoad(ref int A_0, ref int A_1, ref int A_2, RigManager A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060009F6 RID: 2550 RVA: 0x0005C280 File Offset: 0x0005A480
		private static VRRig FUNCPUREVIRTUALSMC(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			float maxValue = float.MaxValue;
			A_4 = maxValue;
			VRRig vrrig = null;
			A_5 = vrrig;
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_6 = enumerator;
			A_0 = 9;
			VRRig result;
			return result;
		}

		// Token: 0x060009F7 RID: 2551 RVA: 0x0005C2E8 File Offset: 0x0005A4E8
		private static Player idNumTimesuff(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref Player A_4, bool A_5)
		{
			Player result = A_4;
			A_1 = 0;
			return result;
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0005C308 File Offset: 0x0005A508
		public RigManager()
		{
			int num = 33;
			int num2 = 33;
			num2 = 33;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.RigManager), ref num, ref num2, ref num3, this, RigManager.StaticIndexRangePartitionForArrayAllFiles[num]);
			}
			num2 = 33;
		}

		// Token: 0x060009F9 RID: 2553 RVA: 0x0005C340 File Offset: 0x0005A540
		public static VRRig GetRandomVRRig(bool includeSelf)
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			VRRig result;
			while (num2 != 0)
			{
				int num3;
				VRRig vrrig;
				bool flag;
				VRRig vrrig2;
				bool flag2;
				result = calli(VRRig(System.Int32&,System.Int32&,System.Int32&,VRRig&,System.Boolean&,VRRig&,System.Boolean&,System.Boolean), ref num, ref num2, ref num3, ref vrrig, ref flag, ref vrrig2, ref flag2, includeSelf, RigManager.StaticIndexRangePartitionForArrayAllFiles[num]);
			}
			num2 = 2;
			return result;
		}

		// Token: 0x060009FA RID: 2554 RVA: 0x0005C380 File Offset: 0x0005A580
		private static PhotonView getAsDateBuffer(ref int A_0, ref int A_1, ref int A_2, ref PhotonView A_3, VRRig A_4)
		{
			PhotonView photonView = (PhotonView)Traverse.Create(A_4).Field("photonView").GetValue();
			A_3 = photonView;
			A_0 = 19;
			PhotonView result;
			return result;
		}

		// Token: 0x060009FB RID: 2555 RVA: 0x0005C3CC File Offset: 0x0005A5CC
		private static VRRig GetRuntimePropertyUrlAttribute(ref int A_0, ref int A_1, ref int A_2, ref VRRig A_3, ref bool A_4, ref VRRig A_5, ref bool A_6, bool A_7)
		{
			VRRig randomVRRig = RigManager.GetRandomVRRig(A_7);
			A_5 = randomVRRig;
			A_0 = 7;
			VRRig result;
			return result;
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x0005C404 File Offset: 0x0005A604
		private static Player DataCollectorIgnoreSyncCtx(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref Player A_4, bool A_5)
		{
			Player player = PhotonNetwork.PlayerList[Random.Range(0, PhotonNetwork.PlayerList.Length - 1)];
			A_4 = player;
			A_0 = 23;
			Player result;
			return result;
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x0005C450 File Offset: 0x0005A650
		private static VRRig LastCalledMethodClassKeysOrderedAcrossPartitions(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			A_1 = 4;
			A_2 = 16;
			VRRig result;
			return result;
		}

		// Token: 0x060009FE RID: 2558 RVA: 0x0005C478 File Offset: 0x0005A678
		public static Player GetPlayerFromVRRig(VRRig p)
		{
			int num = 24;
			int num2 = 24;
			num2 = 24;
			Player result;
			while (num2 != 0)
			{
				int num3;
				Player player;
				result = calli(Photon.Realtime.Player(System.Int32&,System.Int32&,System.Int32&,Photon.Realtime.Player&,VRRig), ref num, ref num2, ref num3, ref player, p, RigManager.StaticIndexRangePartitionForArrayAllFiles[num]);
			}
			num2 = 24;
			return result;
		}

		// Token: 0x060009FF RID: 2559 RVA: 0x0005C4B8 File Offset: 0x0005A6B8
		private static VRRig RevertPermitOnlyGetApplicationProperties(ref int A_0, ref int A_1, ref int A_2, ref VRRig A_3, ref bool A_4, ref VRRig A_5, ref bool A_6, bool A_7)
		{
			VRRig vrrig = A_3;
			A_5 = vrrig;
			A_0 = 7;
			VRRig result;
			return result;
		}

		// Token: 0x06000A00 RID: 2560 RVA: 0x0005C4F0 File Offset: 0x0005A6F0
		private static VRRig FileAccessMethodReturnMessageWrapper(ref int A_0, ref int A_1, ref int A_2, ref VRRig A_3, ref bool A_4, ref VRRig A_5, ref bool A_6, bool A_7)
		{
			VRRig vrrig = A_3;
			A_5 = vrrig;
			A_0 = 7;
			VRRig result;
			return result;
		}

		// Token: 0x06000A01 RID: 2561 RVA: 0x0005C528 File Offset: 0x0005A728
		private static VRRig getResourceTypeIdIntDynamicTypeInfo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			int num = (A_6.MoveNext() ? 1 : 0) * -4 + 14;
			A_0 = num;
			VRRig result;
			return result;
		}

		// Token: 0x06000A02 RID: 2562 RVA: 0x0005C574 File Offset: 0x0005A774
		private static PhotonView SetPermissionPOLICYCREATEPRIVILEGE(ref int A_0, ref int A_1, ref int A_2, ref PhotonView A_3, VRRig A_4)
		{
			PhotonView result = A_3;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000A03 RID: 2563 RVA: 0x0005C594 File Offset: 0x0005A794
		private static VRRig CDBurningA(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			VRRig vrrig = A_5;
			A_9 = vrrig;
			A_0 = 17;
			VRRig result;
			return result;
		}

		// Token: 0x06000A04 RID: 2564 RVA: 0x0005C5CC File Offset: 0x0005A7CC
		private static VRRig DisableFilterXmlDecl(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			A_6.Dispose();
			A_1 = 1;
			VRRig result;
			return result;
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x0005C5F8 File Offset: 0x0005A7F8
		private static VRRig FieldTypeMatchExactVersion(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			float num = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, A_7.transform.position);
			A_4 = num;
			VRRig vrrig = A_7;
			A_5 = vrrig;
			int num2 = (A_6.MoveNext() ? 1 : 0) * -4 + 14;
			A_0 = num2;
			VRRig result;
			return result;
		}

		// Token: 0x06000A06 RID: 2566 RVA: 0x0005C69C File Offset: 0x0005A89C
		private static VRRig RandomAccessFromHandle(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			int num = (A_6.MoveNext() ? 1 : 0) * -4 + 14;
			A_0 = num;
			VRRig result;
			return result;
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x0005C6E8 File Offset: 0x0005A8E8
		private static VRRig GetAttributesLockType(ref int A_0, ref int A_1, ref int A_2, ref VRRig A_3, Player A_4)
		{
			VRRig result = A_3;
			A_1 = 3;
			return result;
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x0005C708 File Offset: 0x0005A908
		private static VRRig ThrowOnEventWriteErrorsEventArgs(ref int A_0, ref int A_1, ref int A_2, ref VRRig A_3, ref bool A_4, ref VRRig A_5, ref bool A_6, bool A_7)
		{
			VRRig result = A_5;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000A09 RID: 2569 RVA: 0x0005C728 File Offset: 0x0005A928
		private static Player DateWordTokengrfLocksSupported(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, VRRig A_4)
		{
			Player owner = RigManager.GetPhotonViewFromVRRig(A_4).Owner;
			A_3 = owner;
			A_0 = 25;
			Player result;
			return result;
		}

		// Token: 0x06000A0A RID: 2570 RVA: 0x0005C764 File Offset: 0x0005A964
		private static Player ConcurrentDictionaryWorldSid(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref Player A_4, bool A_5)
		{
			A_3 = A_5;
			int num = ((!A_3) ? 1 : 0) * 1 + 21;
			A_0 = num;
			Player result;
			return result;
		}

		// Token: 0x06000A0B RID: 2571 RVA: 0x0005C7C4 File Offset: 0x0005A9C4
		private static VRRig OnlyGACDomainNeutralIsEntered(ref int A_0, ref int A_1, ref int A_2, ref VRRig A_3, ref bool A_4, ref VRRig A_5, ref bool A_6, bool A_7)
		{
			VRRig vrrig = GorillaParent.instance.vrrigs[Random.Range(0, GorillaParent.instance.vrrigs.Count - 1)];
			A_3 = vrrig;
			A_4 = A_7;
			int num = ((!A_4) ? 1 : 0) * 1 + 3;
			A_0 = num;
			VRRig result;
			return result;
		}

		// Token: 0x06000A0C RID: 2572 RVA: 0x0005C868 File Offset: 0x0005AA68
		public static Player GetRandomPlayer(bool includeSelf)
		{
			int num = 20;
			int num2 = 20;
			num2 = 20;
			Player result;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				Player player;
				result = calli(Photon.Realtime.Player(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,Photon.Realtime.Player&,System.Boolean), ref num, ref num2, ref num3, ref flag, ref player, includeSelf, RigManager.StaticIndexRangePartitionForArrayAllFiles[num]);
			}
			num2 = 20;
			return result;
		}

		// Token: 0x06000A0D RID: 2573 RVA: 0x0005C8A8 File Offset: 0x0005AAA8
		public unsafe static VRRig GetClosestVRRig()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 8;
			int num4 = 8;
			num4 = 8;
			VRRig result;
			try
			{
				IL_17:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num23;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 1)
					{
						num4 = 8;
						if ((int)array[4] != 1)
						{
							num5 = (int)array[7];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num5 + 56 + num2);
								num7 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + (int)array[2] + 56 + num2) + 40 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num7 + 24 + num2);
								if (num8 != -1)
								{
									num9 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num8 + 24 + num2);
									array[2] = num8;
									array[1] = 1;
									num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num8 + 24 + num2);
									goto IL_17;
								}
								num7 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num7 + 40 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[0];
							num9 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num5 + 24 + num2);
							ex3 = ex2;
							array = (object[])array[5];
							array2 = new object[8];
							array2[4] = 0;
							array2[5] = array;
							array2[0] = ex2;
							array2[2] = num5;
							array2[1] = 0;
							array = array2;
							num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num5 + 24 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[6];
							array = (object[])array[5];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							float num14;
							VRRig vrrig;
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig2;
							bool flag;
							VRRig vrrig3;
							result = calli(VRRig(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Single&,VRRig&,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,VRRig&), ref num3, ref num4, ref num13, ex3, ref num14, ref vrrig, ref enumerator, ref vrrig2, ref flag, ref vrrig3, RigManager.StaticIndexRangePartitionForArrayAllFiles[num3]);
							continue;
						}
						num4 = 8;
						num8 = num13;
						num12 = num8;
					}
					num15 = num3;
					num6 = num15;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num17 * 56 + 32 + num2);
						num19 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num17 * 56 + 40 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num9 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num7 * 56 + 16 + num2);
					num20 = num9;
					num19 = num12;
					num18 = 0;
					num17 = 2;
					for (;;)
					{
						num16 = (num18 + num17) / 2;
						num11 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num16 * 56 + 32 + num2);
						num6 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num16 * 56 + 40 + num2);
						if (num19 < num11 + num6)
						{
							if (num11 <= num19)
							{
								break;
							}
							num17 = num16 - 1;
						}
						else
						{
							num18 = num16 + 1;
						}
					}
					num7 = num16;
					num8 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num7 * 56 + 16 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num17 * 56 + 32 + num2);
						num19 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num17 * 56 + 40 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num5 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num7 * 56 + 16 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A7E:
						if (array == null || (int)array[4] == 1)
						{
							num6 = num9;
							while (num6 != num20)
							{
								if (num6 != -1)
								{
									num6 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num6 + 40 + num2);
								}
								else
								{
									num11 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 24 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num20 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 40 + num2);
									goto IL_A7E;
								}
							}
							goto IL_C1C;
						}
						int num21 = (int)array[2];
						int num22;
						if (num20 == -1)
						{
							num22 = -1;
						}
						else
						{
							num23 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 16 + num2);
							num19 = 0;
							num18 = 2;
							for (;;)
							{
								num17 = (num19 + num18) / 2;
								num16 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num17 * 56 + 32 + num2);
								num11 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num17 * 56 + 40 + num2);
								if (num23 < num16 + num11)
								{
									if (num16 <= num23)
									{
										break;
									}
									num18 = num17 - 1;
								}
								else
								{
									num19 = num17 + 1;
								}
							}
							num5 = num17;
							num7 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num5 * 56 + 16 + num2);
							num22 = num7;
						}
						if (num21 == num22)
						{
							num7 = num9;
							while (num7 != num20)
							{
								if (num7 != -1)
								{
									num7 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num7 + 40 + num2);
								}
								else
								{
									num5 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 24 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num20 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 40 + num2);
									goto IL_A7E;
								}
							}
							break;
						}
						if ((int)array[2] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[5];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num5 + 24 + num2);
					array2 = new object[8];
					array2[4] = 1;
					array2[5] = array;
					array2[6] = num12;
					array2[2] = num5;
					array2[1] = 1;
					array = array2;
					num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num5 + 24 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C1C:
					num3 = num12;
					continue;
					Block_62:
					num16 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num11 + 24 + num2);
					array2 = new object[8];
					array2[4] = 1;
					array2[5] = array;
					array2[6] = num12;
					array2[2] = num11;
					array2[1] = 1;
					array = array2;
					num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num11 + 24 + num2);
				}
				num4 = 8;
				return result;
				IL_1D0:
				if (num16 != -1)
				{
					goto IL_1DB;
				}
				goto IL_403;
				IL_1DB:
				num6 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num16 + 64 + num2);
				if (3 == num6)
				{
					goto IL_1FA;
				}
				if (2 == num6)
				{
					goto IL_38C;
				}
				goto IL_403;
				IL_1FA:
				num11 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num16 + 32 + num2);
				if (num11 == -1)
				{
					goto IL_248;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_22E;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_22E:
				if (type.IsInstanceOfType(array2[0]))
				{
					goto IL_248;
				}
				num16 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num16 + 40 + num2);
				goto IL_1D0;
				IL_248:
				num20 = num16;
				num15 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 56 + num2) + 40 + num2);
				num7 = (int)array2[3];
				IL_26C:
				if (num7 != num15)
				{
					goto IL_2EB;
				}
				num17 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 24 + num2);
				ex3 = array2[0];
				array = (object[])array[5];
				object[] array5 = new object[8];
				array5[4] = 0;
				array5[5] = array;
				array5[0] = array2[0];
				array5[3] = (int)array2[3];
				array5[2] = num20;
				array5[1] = 0;
				array = array5;
				num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 24 + num2);
				goto IL_17;
				IL_2EB:
				num9 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num7 + 24 + num2);
				if (num9 == -1)
				{
					goto IL_37A;
				}
				num17 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num9 + 24 + num2);
				array = (object[])array[5];
				array5 = new object[8];
				array5[4] = 0;
				array5[5] = array;
				array5[0] = array2[0];
				array5[3] = (int)array2[3];
				array5[2] = num9;
				array5[7] = num20;
				array5[1] = 1;
				array = array5;
				num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num9 + 24 + num2);
				goto IL_17;
				IL_37A:
				num7 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num7 + 40 + num2);
				goto IL_26C;
				IL_38C:
				num17 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num16 + 8 + num2);
				ex3 = array2[0];
				array = (object[])array[5];
				array5 = new object[8];
				array5[4] = 0;
				array5[5] = array;
				array5[0] = array2[0];
				array5[3] = (int)array2[3];
				array5[2] = num16;
				array5[1] = 2;
				array = array5;
				num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num16 + 8 + num2);
				goto IL_17;
				IL_403:
				array = (object[])array[5];
				ex = array2[0];
				int num24 = (int)array2[3];
				IL_422:
				num16 = num3;
				num17 = num16;
				num18 = 0;
				num19 = 2;
				IL_430:
				num8 = (num18 + num19) / 2;
				num5 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num8 * 56 + 32 + num2);
				num23 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num8 * 56 + 40 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_476;
				}
				if (num5 > num17)
				{
					goto IL_47E;
				}
				num15 = num8;
				num20 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 168 + num15 * 56 + 16 + num2);
				num11 = num20;
				num7 = num11;
				goto IL_4A6;
				IL_476:
				num18 = num8 + 1;
				goto IL_430;
				IL_47E:
				num19 = num8 - 1;
				goto IL_430;
				IL_4A6:
				if (array != null)
				{
					goto IL_4B1;
				}
				goto IL_640;
				IL_4B1:
				if ((int)array[4] != 1)
				{
					goto IL_571;
				}
				int num25 = (int)array[2];
				if (num11 != -1)
				{
					goto IL_4D5;
				}
				int num26 = -1;
				goto IL_558;
				IL_4D5:
				int num27 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num11 + 16 + num2);
				num23 = 0;
				num5 = 2;
				IL_4E8:
				num8 = (num23 + num5) / 2;
				num19 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num8 * 56 + 32 + num2);
				num18 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num8 * 56 + 40 + num2);
				if (num27 >= num19 + num18)
				{
					goto IL_52E;
				}
				if (num19 > num27)
				{
					goto IL_536;
				}
				num20 = num8;
				num15 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num20 * 56 + 16 + num2);
				num26 = num15;
				goto IL_558;
				IL_52E:
				num23 = num8 + 1;
				goto IL_4E8;
				IL_536:
				num5 = num8 - 1;
				goto IL_4E8;
				IL_558:
				if (num25 != num26)
				{
					goto IL_560;
				}
				goto IL_640;
				IL_560:
				array = (object[])array[5];
				goto IL_4A6;
				IL_571:
				num9 = (int)array[1];
				if (num9 == 0 || num9 == 1)
				{
					goto IL_592;
				}
				if (num9 != 2)
				{
					goto IL_591;
				}
				array2 = array;
				num16 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + (int)array2[2] + 40 + num2);
				goto IL_1D0;
				IL_591:
				IL_592:
				int num28 = (int)array[2];
				if (num11 != -1)
				{
					goto IL_5A7;
				}
				int num29 = -1;
				goto IL_62A;
				IL_5A7:
				num17 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num11 + 16 + num2);
				num18 = 0;
				num19 = 2;
				IL_5BA:
				num8 = (num18 + num19) / 2;
				num5 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num8 * 56 + 32 + num2);
				num23 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num8 * 56 + 40 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_600;
				}
				if (num5 > num17)
				{
					goto IL_608;
				}
				num15 = num8;
				num20 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + 336 + num15 * 56 + 16 + num2);
				num29 = num20;
				goto IL_62A;
				IL_600:
				num18 = num8 + 1;
				goto IL_5BA;
				IL_608:
				num19 = num8 - 1;
				goto IL_5BA;
				IL_62A:
				if (num28 != num29)
				{
					goto IL_62F;
				}
				goto IL_640;
				IL_62F:
				array = (object[])array[5];
				goto IL_4A6;
				IL_640:
				if (-1 != num11)
				{
					goto IL_6E4;
				}
				num20 = num7;
				IL_64D:
				if (num20 != -1)
				{
					goto IL_659;
				}
				num10 = 1;
				throw ex;
				IL_659:
				num15 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 24 + num2);
				if (num15 == -1)
				{
					goto IL_6D2;
				}
				num27 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num15 + 24 + num2);
				array2 = new object[8];
				array2[4] = 0;
				array2[5] = array;
				array2[0] = ex;
				array2[3] = num7;
				array2[2] = -1;
				array2[7] = -1;
				array2[1] = 0;
				array = array2;
				num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num15 + 24 + num2);
				goto IL_17;
				IL_6D2:
				num20 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num20 + 40 + num2);
				goto IL_64D;
				IL_6E4:
				num6 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num11 + 48 + num2);
				num17 = num6;
				IL_6F5:
				if (num17 != -1)
				{
					goto IL_70C;
				}
				num11 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num11 + 40 + num2);
				goto IL_4A6;
				IL_70C:
				num19 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num17 + 64 + num2);
				if (3 == num19)
				{
					goto IL_737;
				}
				if (2 == num19)
				{
					goto IL_8A5;
				}
				num11 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num11 + 40 + num2);
				goto IL_4A6;
				IL_737:
				num18 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num17 + 32 + num2);
				if (num18 == -1)
				{
					goto IL_786;
				}
				Type type2;
				if ((type2 = array3[num18]) != null)
				{
					goto IL_76B;
				}
				array3[num18] = Type.GetTypeFromHandle(array4[num18]);
				type2 = array3[num18];
				IL_76B:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_786;
				}
				num17 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num17 + 40 + num2);
				goto IL_6F5;
				IL_786:
				num27 = num17;
				num23 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num27 + 56 + num2) + 40 + num2);
				num5 = (num7 - num24) * ((num24 == -1) ? 1 : 0) + num24;
				IL_7AF:
				if (num5 != num23)
				{
					goto IL_818;
				}
				int num30 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num27 + 24 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[4] = 0;
				array2[5] = array;
				array2[0] = ex;
				array2[3] = num7;
				array2[2] = num27;
				array2[1] = 0;
				array = array2;
				num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num27 + 24 + num2);
				goto IL_17;
				IL_818:
				num8 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num5 + 24 + num2);
				if (num8 == -1)
				{
					goto IL_893;
				}
				num30 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num8 + 24 + num2);
				array2 = new object[8];
				array2[4] = 0;
				array2[5] = array;
				array2[0] = ex;
				array2[3] = num7;
				array2[2] = num8;
				array2[7] = num27;
				array2[1] = 1;
				array = array2;
				num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num8 + 24 + num2);
				goto IL_17;
				IL_893:
				num5 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num5 + 40 + num2);
				goto IL_7AF;
				IL_8A5:
				num30 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num17 + 8 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[4] = 0;
				array2[5] = array;
				array2[0] = ex;
				array2[3] = num7;
				array2[2] = num17;
				array2[1] = 2;
				array = array2;
				num3 = *(ref ITypeLibExporterNotifySinkgetKey.EphemeralKeySetgetCalendarWeekRule + num17 + 8 + num2);
				goto IL_17;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num24 = -1;
					goto IL_422;
				}
				throw ex4;
			}
			return result;
		}

		// Token: 0x06000A0E RID: 2574 RVA: 0x0005D58C File Offset: 0x0005B78C
		private static VRRig getAsDispatchIsMethodOverloaded(ref int A_0, ref int A_1, ref int A_2, ref VRRig A_3, ref bool A_4, ref VRRig A_5, ref bool A_6, bool A_7)
		{
			bool flag = A_3 != GorillaTagger.Instance.offlineVRRig;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 5;
			A_0 = num;
			VRRig result;
			return result;
		}

		// Token: 0x06000A0F RID: 2575 RVA: 0x0005D600 File Offset: 0x0005B800
		private static VRRig HashElementDigestMethodNativeDigits(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			A_0 = 13;
			VRRig result;
			return result;
		}

		// Token: 0x06000A10 RID: 2576 RVA: 0x0005D61C File Offset: 0x0005B81C
		private static Player HandleProcessCorruptedStateExceptionsAttributeResourceManagerGetSatelliteAssemblyFailed(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref bool A_7, ref Player A_8, string A_9)
		{
			Player player = A_3;
			A_8 = player;
			A_0 = 32;
			Player result;
			return result;
		}

		// Token: 0x06000A11 RID: 2577 RVA: 0x0005D654 File Offset: 0x0005B854
		private static VRRig CanTransformMultipleBlocksCDRom(ref int A_0, ref int A_1, ref int A_2, ref VRRig A_3, Player A_4)
		{
			VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(A_4);
			A_3 = vrrig;
			A_0 = 1;
			VRRig result;
			return result;
		}

		// Token: 0x06000A12 RID: 2578 RVA: 0x0005D694 File Offset: 0x0005B894
		private static Player getVariantTypePoint(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref bool A_7, ref Player A_8, string A_9)
		{
			Player result = A_8;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000A13 RID: 2579 RVA: 0x0005D6B4 File Offset: 0x0005B8B4
		private static Player ReleaseThreadCacheOperational(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref bool A_7, ref Player A_8, string A_9)
		{
			Player player = A_6;
			A_3 = player;
			A_0 = 31;
			Player result;
			return result;
		}

		// Token: 0x06000A14 RID: 2580 RVA: 0x0005D6EC File Offset: 0x0005B8EC
		private static Player setDisallowApplicationBaseProbingMessageData(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref Player A_4, bool A_5)
		{
			Player player = PhotonNetwork.PlayerListOthers[Random.Range(0, PhotonNetwork.PlayerListOthers.Length - 1)];
			A_4 = player;
			A_0 = 23;
			Player result;
			return result;
		}

		// Token: 0x06000A15 RID: 2581 RVA: 0x0005D738 File Offset: 0x0005B938
		public static PhotonView GetPhotonViewFromVRRig(VRRig p)
		{
			int num = 18;
			int num2 = 18;
			num2 = 18;
			PhotonView result;
			while (num2 != 0)
			{
				int num3;
				PhotonView photonView;
				result = calli(Photon.Pun.PhotonView(System.Int32&,System.Int32&,System.Int32&,Photon.Pun.PhotonView&,VRRig), ref num, ref num2, ref num3, ref photonView, p, RigManager.StaticIndexRangePartitionForArrayAllFiles[num]);
			}
			num2 = 18;
			return result;
		}

		// Token: 0x06000A16 RID: 2582 RVA: 0x0005D778 File Offset: 0x0005B978
		private static Player TitleValueType(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref bool A_7, ref Player A_8, string A_9)
		{
			Player player = A_4[A_5];
			A_6 = player;
			bool flag = A_6.UserId == A_9;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 28;
			A_0 = num;
			Player result;
			return result;
		}

		// Token: 0x06000A17 RID: 2583 RVA: 0x0005D810 File Offset: 0x0005BA10
		private static Player StatusLevelDefinePInvokeMethod(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref bool A_7, ref Player A_8, string A_9)
		{
			Player player = null;
			A_3 = player;
			Player[] playerList = PhotonNetwork.PlayerList;
			A_4 = playerList;
			int num = 0;
			A_5 = num;
			A_0 = 30;
			Player result;
			return result;
		}

		// Token: 0x06000A18 RID: 2584 RVA: 0x0005D86C File Offset: 0x0005BA6C
		private static Player ProcessMessageTooManyArgs(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, VRRig A_4)
		{
			Player result = A_3;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000A19 RID: 2585 RVA: 0x0005D88C File Offset: 0x0005BA8C
		private static VRRig LocalizedResourcesMethodSemanticsAttributes(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			VRRig result = A_9;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000A1A RID: 2586 RVA: 0x0005D8AC File Offset: 0x0005BAAC
		private static VRRig NaNSymbolCreateFromBinaryForm(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref float A_4, ref VRRig A_5, ref List<VRRig>.Enumerator A_6, ref VRRig A_7, ref bool A_8, ref VRRig A_9)
		{
			VRRig vrrig = A_6.Current;
			A_7 = vrrig;
			bool flag = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, A_7.transform.position) < A_4;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 11;
			A_0 = num;
			VRRig result;
			return result;
		}

		// Token: 0x06000A1B RID: 2587 RVA: 0x0005D958 File Offset: 0x0005BB58
		private static Player IsAllocatedGetMonthsInYear(ref int A_0, ref int A_1, ref int A_2, ref Player A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref bool A_7, ref Player A_8, string A_9)
		{
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -4 + 31;
			A_0 = num2;
			Player result;
			return result;
		}

		// Token: 0x06000A1C RID: 2588 RVA: 0x0005D9BC File Offset: 0x0005BBBC
		// Note: this type is marked as 'beforefieldinit'.
		static RigManager()
		{
			RigManager.OtherPhoneEnumAssemblies();
		}

		// Token: 0x06000A1D RID: 2589 RVA: 0x0005D9D0 File Offset: 0x0005BBD0
		private static void OtherPhoneEnumAssemblies()
		{
			RigManager.StaticIndexRangePartitionForArrayAllFiles = new IntPtr[34];
			RigManager.StaticIndexRangePartitionForArrayAllFiles[0] = ldftn(CanTransformMultipleBlocksCDRom);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[1] = ldftn(GetAttributesLockType);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[2] = ldftn(OnlyGACDomainNeutralIsEntered);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[3] = ldftn(FileAccessMethodReturnMessageWrapper);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[4] = ldftn(getAsDispatchIsMethodOverloaded);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[5] = ldftn(RevertPermitOnlyGetApplicationProperties);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[6] = ldftn(GetRuntimePropertyUrlAttribute);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[7] = ldftn(ThrowOnEventWriteErrorsEventArgs);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[8] = ldftn(FUNCPUREVIRTUALSMC);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[9] = ldftn(HashElementDigestMethodNativeDigits);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[10] = ldftn(NaNSymbolCreateFromBinaryForm);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[11] = ldftn(FieldTypeMatchExactVersion);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[12] = ldftn(RandomAccessFromHandle);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[13] = ldftn(getResourceTypeIdIntDynamicTypeInfo);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[14] = ldftn(LastCalledMethodClassKeysOrderedAcrossPartitions);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[15] = ldftn(DisableFilterXmlDecl);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[16] = ldftn(CDBurningA);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[17] = ldftn(LocalizedResourcesMethodSemanticsAttributes);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[18] = ldftn(getAsDateBuffer);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[19] = ldftn(SetPermissionPOLICYCREATEPRIVILEGE);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[20] = ldftn(ConcurrentDictionaryWorldSid);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[21] = ldftn(DataCollectorIgnoreSyncCtx);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[22] = ldftn(setDisallowApplicationBaseProbingMessageData);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[23] = ldftn(idNumTimesuff);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[24] = ldftn(DateWordTokengrfLocksSupported);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[25] = ldftn(ProcessMessageTooManyArgs);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[26] = ldftn(StatusLevelDefinePInvokeMethod);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[27] = ldftn(TitleValueType);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[28] = ldftn(ReleaseThreadCacheOperational);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[29] = ldftn(IsAllocatedGetMonthsInYear);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[30] = ldftn(getRNGSystemLazyDebugView);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[31] = ldftn(HandleProcessCorruptedStateExceptionsAttributeResourceManagerGetSatelliteAssemblyFailed);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[32] = ldftn(getVariantTypePoint);
			RigManager.StaticIndexRangePartitionForArrayAllFiles[33] = ldftn(OaepPreLoad);
		}

		// Token: 0x04000161 RID: 353
		private static IntPtr[] StaticIndexRangePartitionForArrayAllFiles;
	}
}
