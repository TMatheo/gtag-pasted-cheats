﻿using System;
using UnityEngine;

namespace StupidTemplate.Classes
{
	// Token: 0x0200003F RID: 63
	public class TimedBehaviour : MonoBehaviour
	{
		// Token: 0x06000A1E RID: 2590 RVA: 0x0005DC30 File Offset: 0x0005BE30
		private static void EventTagSectionSecurityContextSource(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, TimedBehaviour A_6)
		{
			A_6.OnLoop();
			A_0 = 6;
		}

		// Token: 0x06000A1F RID: 2591 RVA: 0x0005DC54 File Offset: 0x0005BE54
		private static void InterfaceIsIUnknowngetCurrentId(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, TimedBehaviour A_6)
		{
			A_6.complete = true;
			A_1 = 0;
		}

		// Token: 0x06000A20 RID: 2592 RVA: 0x0005DC80 File Offset: 0x0005BE80
		private static void GetCustomAttributesDataHMACRIPEMD(ref int A_0, ref int A_1, ref int A_2, TimedBehaviour A_3)
		{
			A_3.startTime = Time.time;
			A_1 = 2;
		}

		// Token: 0x06000A21 RID: 2593 RVA: 0x0005DCA8 File Offset: 0x0005BEA8
		private static void DoNotExpandEnvironmentNamesCommandLine(ref int A_0, ref int A_1, ref int A_2, TimedBehaviour A_3)
		{
			A_3.startTime = Time.time;
			A_1 = 0;
		}

		// Token: 0x06000A22 RID: 2594 RVA: 0x0005DCD0 File Offset: 0x0005BED0
		private static void IsLiteralLengthInTextElements(ref int A_0, ref int A_1, ref int A_2, TimedBehaviour A_3)
		{
			A_3.complete = false;
			A_3.loop = true;
			A_3.progress = 0f;
			A_3.paused = false;
			A_3.duration = 2f;
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000A23 RID: 2595 RVA: 0x0005DD38 File Offset: 0x0005BF38
		public TimedBehaviour()
		{
			int num = 10;
			int num2 = 10;
			num2 = 10;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.TimedBehaviour), ref num, ref num2, ref num3, this, TimedBehaviour.EnableJITcompileTrackingTokenUser[num]);
			}
			num2 = 10;
		}

		// Token: 0x06000A24 RID: 2596 RVA: 0x0005DD70 File Offset: 0x0005BF70
		public virtual void Update()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&,StupidTemplate.Classes.TimedBehaviour), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, this, TimedBehaviour.EnableJITcompileTrackingTokenUser[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000A25 RID: 2597 RVA: 0x0005DDAC File Offset: 0x0005BFAC
		private static void DestroyConsistencyGuarantee(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, TimedBehaviour A_6)
		{
			bool flag = A_6.loop;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x06000A26 RID: 2598 RVA: 0x0005DE0C File Offset: 0x0005C00C
		private static void NotImpersonatedNameNotFound(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, TimedBehaviour A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000A27 RID: 2599 RVA: 0x0005DE24 File Offset: 0x0005C024
		private static void StrongNameSignatureVerificationExLevel(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, TimedBehaviour A_6)
		{
			bool flag = !A_6.complete;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 6 + 2;
			A_0 = num;
		}

		// Token: 0x06000A28 RID: 2600 RVA: 0x0005DE8C File Offset: 0x0005C08C
		private static void FindNameIDLFLAGFOUT(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, TimedBehaviour A_6)
		{
			A_6.progress = Mathf.Clamp((Time.time - A_6.startTime) / A_6.duration, 0f, 1f);
			bool flag = Time.time - A_6.startTime > A_6.duration;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 4 + 3;
			A_0 = num;
		}

		// Token: 0x06000A29 RID: 2601 RVA: 0x0005DF30 File Offset: 0x0005C130
		public virtual void OnLoop()
		{
			int num = 9;
			int num2 = 9;
			num2 = 9;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.TimedBehaviour), ref num, ref num2, ref num3, this, TimedBehaviour.EnableJITcompileTrackingTokenUser[num]);
			}
			num2 = 9;
		}

		// Token: 0x06000A2A RID: 2602 RVA: 0x0005DF68 File Offset: 0x0005C168
		private static void ProcessorArchitectureARMMultiDomainHost(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, TimedBehaviour A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000A2B RID: 2603 RVA: 0x0005DF84 File Offset: 0x0005C184
		private static void SerializationNameMakeReadOnly(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, TimedBehaviour A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000A2C RID: 2604 RVA: 0x0005DF9C File Offset: 0x0005C19C
		public virtual void Start()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.TimedBehaviour), ref num, ref num2, ref num3, this, TimedBehaviour.EnableJITcompileTrackingTokenUser[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000A2D RID: 2605 RVA: 0x0005DFD0 File Offset: 0x0005C1D0
		// Note: this type is marked as 'beforefieldinit'.
		static TimedBehaviour()
		{
			TimedBehaviour.GetRuntimeDirectorysetFailedAssemblyInfo();
		}

		// Token: 0x06000A2E RID: 2606 RVA: 0x0005DFE4 File Offset: 0x0005C1E4
		private static void GetRuntimeDirectorysetFailedAssemblyInfo()
		{
			TimedBehaviour.EnableJITcompileTrackingTokenUser = new IntPtr[11];
			TimedBehaviour.EnableJITcompileTrackingTokenUser[0] = ldftn(GetCustomAttributesDataHMACRIPEMD);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[1] = ldftn(StrongNameSignatureVerificationExLevel);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[2] = ldftn(FindNameIDLFLAGFOUT);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[3] = ldftn(DestroyConsistencyGuarantee);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[4] = ldftn(EventTagSectionSecurityContextSource);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[5] = ldftn(InterfaceIsIUnknowngetCurrentId);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[6] = ldftn(ProcessorArchitectureARMMultiDomainHost);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[7] = ldftn(NotImpersonatedNameNotFound);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[8] = ldftn(SerializationNameMakeReadOnly);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[9] = ldftn(DoNotExpandEnvironmentNamesCommandLine);
			TimedBehaviour.EnableJITcompileTrackingTokenUser[10] = ldftn(IsLiteralLengthInTextElements);
		}

		// Token: 0x04000162 RID: 354
		public bool complete;

		// Token: 0x04000163 RID: 355
		public bool loop;

		// Token: 0x04000164 RID: 356
		public float progress;

		// Token: 0x04000165 RID: 357
		protected bool paused;

		// Token: 0x04000166 RID: 358
		protected float startTime;

		// Token: 0x04000167 RID: 359
		protected float duration;

		// Token: 0x04000168 RID: 360
		private static IntPtr[] EnableJITcompileTrackingTokenUser;
	}
}
