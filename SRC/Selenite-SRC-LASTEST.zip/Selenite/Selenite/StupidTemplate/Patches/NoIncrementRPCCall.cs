﻿using System;
using HarmonyLib;
using Photon.Pun;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x0200001B RID: 27
	[HarmonyPatch(typeof(GorillaNot), "IncrementRPCCall", new Type[]
	{
		typeof(PhotonMessageInfo),
		typeof(string)
	})]
	public class NoIncrementRPCCall : MonoBehaviour
	{
		// Token: 0x060001F0 RID: 496 RVA: 0x0000EDE8 File Offset: 0x0000CFE8
		private static bool DelegationgetApartmentState(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x0000EE08 File Offset: 0x0000D008
		private static bool IMPLTYPEFLAGSAggressiveInlining(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x0000EE3C File Offset: 0x0000D03C
		private static void ClosedDelegateOnlyNonUniqueAuthority(ref int A_0, ref int A_1, ref int A_2, NoIncrementRPCCall A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x0000EE60 File Offset: 0x0000D060
		public NoIncrementRPCCall()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.NoIncrementRPCCall), ref num, ref num2, ref num3, this, NoIncrementRPCCall.tdescClientChannelSinkStack[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000EE94 File Offset: 0x0000D094
		private static bool Prefix(PhotonMessageInfo info, string callingMethod = "")
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, NoIncrementRPCCall.tdescClientChannelSinkStack[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x0000EECC File Offset: 0x0000D0CC
		// Note: this type is marked as 'beforefieldinit'.
		static NoIncrementRPCCall()
		{
			NoIncrementRPCCall.GetCallTypeInternalEncoderBestFitFallbackBuffer();
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x0000EEE0 File Offset: 0x0000D0E0
		private static void GetCallTypeInternalEncoderBestFitFallbackBuffer()
		{
			NoIncrementRPCCall.tdescClientChannelSinkStack = new IntPtr[3];
			NoIncrementRPCCall.tdescClientChannelSinkStack[0] = ldftn(IMPLTYPEFLAGSAggressiveInlining);
			NoIncrementRPCCall.tdescClientChannelSinkStack[1] = ldftn(DelegationgetApartmentState);
			NoIncrementRPCCall.tdescClientChannelSinkStack[2] = ldftn(ClosedDelegateOnlyNonUniqueAuthority);
		}

		// Token: 0x04000077 RID: 119
		private static IntPtr[] tdescClientChannelSinkStack;
	}
}
