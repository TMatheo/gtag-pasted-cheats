﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000020 RID: 32
	[HarmonyPatch(typeof(GameObject))]
	[HarmonyPatch("CreatePrimitive", 0)]
	internal class ShaderFix : MonoBehaviour
	{
		// Token: 0x06000212 RID: 530 RVA: 0x0000F434 File Offset: 0x0000D634
		private static void FormatBadDateTimeCalendarILease(ref int A_0, ref int A_1, ref int A_2, ShaderFix A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000213 RID: 531 RVA: 0x0000F458 File Offset: 0x0000D658
		public ShaderFix()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.ShaderFix), ref num, ref num2, ref num3, this, ShaderFix.DefineUninitializedDataCriticalFinalizerObject[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000214 RID: 532 RVA: 0x0000F48C File Offset: 0x0000D68C
		private static void Postfix(GameObject __result)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.GameObject), ref num, ref num2, ref num3, __result, ShaderFix.DefineUninitializedDataCriticalFinalizerObject[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000215 RID: 533 RVA: 0x0000F4C0 File Offset: 0x0000D6C0
		private static void LUIDANDATTRIBUTESReadBlockAsync(ref int A_0, ref int A_1, ref int A_2, GameObject A_3)
		{
			A_3.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
			A_3.GetComponent<Renderer>().material.color = new Color32(byte.MaxValue, 128, 0, 128);
			A_1 = 2;
		}

		// Token: 0x06000216 RID: 534 RVA: 0x0000F528 File Offset: 0x0000D728
		// Note: this type is marked as 'beforefieldinit'.
		static ShaderFix()
		{
			ShaderFix.CTSgetMayLeakOnAbort();
		}

		// Token: 0x06000217 RID: 535 RVA: 0x0000F53C File Offset: 0x0000D73C
		private static void CTSgetMayLeakOnAbort()
		{
			ShaderFix.DefineUninitializedDataCriticalFinalizerObject = new IntPtr[2];
			ShaderFix.DefineUninitializedDataCriticalFinalizerObject[0] = ldftn(LUIDANDATTRIBUTESReadBlockAsync);
			ShaderFix.DefineUninitializedDataCriticalFinalizerObject[1] = ldftn(FormatBadDateTimeCalendarILease);
		}

		// Token: 0x0400007C RID: 124
		private static IntPtr[] DefineUninitializedDataCriticalFinalizerObject;
	}
}
