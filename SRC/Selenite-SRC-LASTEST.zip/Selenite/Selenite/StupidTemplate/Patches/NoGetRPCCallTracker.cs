﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x0200001A RID: 26
	[HarmonyPatch(typeof(GorillaNot), "GetRPCCallTracker")]
	internal class NoGetRPCCallTracker : MonoBehaviour
	{
		// Token: 0x060001E9 RID: 489 RVA: 0x0000ECA0 File Offset: 0x0000CEA0
		private static bool CreateProxyCONNECTDATA(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0000ECC0 File Offset: 0x0000CEC0
		private static bool getContextManifestFlags(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001EB RID: 491 RVA: 0x0000ECF4 File Offset: 0x0000CEF4
		private static void OpenReadOtherNumber(ref int A_0, ref int A_1, ref int A_2, NoGetRPCCallTracker A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001EC RID: 492 RVA: 0x0000ED18 File Offset: 0x0000CF18
		public NoGetRPCCallTracker()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.NoGetRPCCallTracker), ref num, ref num2, ref num3, this, NoGetRPCCallTracker.IncludeMissingTryParseExact[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001ED RID: 493 RVA: 0x0000ED4C File Offset: 0x0000CF4C
		private static bool Prefix()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, NoGetRPCCallTracker.IncludeMissingTryParseExact[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001EE RID: 494 RVA: 0x0000ED84 File Offset: 0x0000CF84
		// Note: this type is marked as 'beforefieldinit'.
		static NoGetRPCCallTracker()
		{
			NoGetRPCCallTracker.RemotingServicesExpandString();
		}

		// Token: 0x060001EF RID: 495 RVA: 0x0000ED98 File Offset: 0x0000CF98
		private static void RemotingServicesExpandString()
		{
			NoGetRPCCallTracker.IncludeMissingTryParseExact = new IntPtr[3];
			NoGetRPCCallTracker.IncludeMissingTryParseExact[0] = ldftn(getContextManifestFlags);
			NoGetRPCCallTracker.IncludeMissingTryParseExact[1] = ldftn(CreateProxyCONNECTDATA);
			NoGetRPCCallTracker.IncludeMissingTryParseExact[2] = ldftn(OpenReadOtherNumber);
		}

		// Token: 0x04000076 RID: 118
		private static IntPtr[] IncludeMissingTryParseExact;
	}
}
