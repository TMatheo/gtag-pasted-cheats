﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x0200001E RID: 30
	[HarmonyPatch(typeof(VRRig), "OnDisable")]
	internal class GhostPatch : MonoBehaviour
	{
		// Token: 0x06000206 RID: 518 RVA: 0x0000F1DC File Offset: 0x0000D3DC
		private static void MngdSafeArrayMarshalerLastAccessTimeUtc(ref int A_0, ref int A_1, ref int A_2, GhostPatch A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000207 RID: 519 RVA: 0x0000F200 File Offset: 0x0000D400
		public GhostPatch()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.GhostPatch), ref num, ref num2, ref num3, this, GhostPatch.DriveInfoHasExtension[num]);
			}
			num2 = 2;
		}

		// Token: 0x06000208 RID: 520 RVA: 0x0000F234 File Offset: 0x0000D434
		private static bool FormatGenericParamHashDefinition(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, VRRig A_4)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x06000209 RID: 521 RVA: 0x0000F254 File Offset: 0x0000D454
		private static bool getCertFileGetNamespace(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, VRRig A_4)
		{
			bool flag = !(A_4 == GorillaTagger.Instance.offlineVRRig);
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x0600020A RID: 522 RVA: 0x0000F29C File Offset: 0x0000D49C
		public static bool Prefix(VRRig __instance)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,VRRig), ref num, ref num2, ref num3, ref flag, __instance, GhostPatch.DriveInfoHasExtension[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x0600020B RID: 523 RVA: 0x0000F2D8 File Offset: 0x0000D4D8
		// Note: this type is marked as 'beforefieldinit'.
		static GhostPatch()
		{
			GhostPatch.IReadOnlyDictionaryValueAtReturn();
		}

		// Token: 0x0600020C RID: 524 RVA: 0x0000F2EC File Offset: 0x0000D4EC
		private static void IReadOnlyDictionaryValueAtReturn()
		{
			GhostPatch.DriveInfoHasExtension = new IntPtr[3];
			GhostPatch.DriveInfoHasExtension[0] = ldftn(getCertFileGetNamespace);
			GhostPatch.DriveInfoHasExtension[1] = ldftn(FormatGenericParamHashDefinition);
			GhostPatch.DriveInfoHasExtension[2] = ldftn(MngdSafeArrayMarshalerLastAccessTimeUtc);
		}

		// Token: 0x0400007A RID: 122
		private static IntPtr[] DriveInfoHasExtension;
	}
}
