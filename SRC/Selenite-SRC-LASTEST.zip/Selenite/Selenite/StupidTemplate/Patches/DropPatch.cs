﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000012 RID: 18
	[HarmonyPatch(typeof(VRRig), "DroppedByPlayer")]
	public class DropPatch
	{
		// Token: 0x060001A0 RID: 416 RVA: 0x0000DD04 File Offset: 0x0000BF04
		public static bool Prefix(VRRig __instance, VRRig grabbedByRig, Vector3 throwVelocity)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 6)
			{
				int num3;
				bool flag;
				bool flag2;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,VRRig), ref num, ref num2, ref num3, ref flag, ref flag2, __instance, DropPatch.VARFLAGFBINDABLEgetIsStopped[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001A1 RID: 417 RVA: 0x0000DD40 File Offset: 0x0000BF40
		private static bool AppendCharApplicationBaseValue(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool result = A_4;
			A_1 = 6;
			return result;
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x0000DD60 File Offset: 0x0000BF60
		private static bool GetDocumentationManifestBuilder(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool flag = false;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 3;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x0000DDC0 File Offset: 0x0000BFC0
		private static bool IsWaitNotificationRequiredOldValue(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			int num = ((!GuardianPatchStuff.enabled) ? 1 : 0) * 1 + 1;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x0000DE08 File Offset: 0x0000C008
		private static void PacketDaysInMonth(ref int A_0, ref int A_1, ref int A_2, DropPatch A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001A5 RID: 421 RVA: 0x0000DE2C File Offset: 0x0000C02C
		private static bool CBCsetDisallowBindingRedirects(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool flag = A_5 == GorillaTagger.Instance.offlineVRRig;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 3;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x0000DEA0 File Offset: 0x0000C0A0
		public DropPatch()
		{
			int num = 6;
			int num2 = 6;
			num2 = 6;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.DropPatch), ref num, ref num2, ref num3, this, DropPatch.VARFLAGFBINDABLEgetIsStopped[num]);
			}
			num2 = 6;
		}

		// Token: 0x060001A7 RID: 423 RVA: 0x0000DED4 File Offset: 0x0000C0D4
		private static bool ThumbprintDeploymentManifestBytes(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool flag = true;
			A_4 = flag;
			A_0 = 5;
			bool result;
			return result;
		}

		// Token: 0x060001A8 RID: 424 RVA: 0x0000DF08 File Offset: 0x0000C108
		private static bool OtherArraygetFrameworkDescription(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool flag = false;
			A_4 = flag;
			A_0 = 5;
			bool result;
			return result;
		}

		// Token: 0x060001A9 RID: 425 RVA: 0x0000DF3C File Offset: 0x0000C13C
		// Note: this type is marked as 'beforefieldinit'.
		static DropPatch()
		{
			DropPatch.MethodSignatureAppendPrivatePath();
		}

		// Token: 0x060001AA RID: 426 RVA: 0x0000DF50 File Offset: 0x0000C150
		private static void MethodSignatureAppendPrivatePath()
		{
			DropPatch.VARFLAGFBINDABLEgetIsStopped = new IntPtr[7];
			DropPatch.VARFLAGFBINDABLEgetIsStopped[0] = ldftn(IsWaitNotificationRequiredOldValue);
			DropPatch.VARFLAGFBINDABLEgetIsStopped[1] = ldftn(CBCsetDisallowBindingRedirects);
			DropPatch.VARFLAGFBINDABLEgetIsStopped[2] = ldftn(GetDocumentationManifestBuilder);
			DropPatch.VARFLAGFBINDABLEgetIsStopped[3] = ldftn(OtherArraygetFrameworkDescription);
			DropPatch.VARFLAGFBINDABLEgetIsStopped[4] = ldftn(ThumbprintDeploymentManifestBytes);
			DropPatch.VARFLAGFBINDABLEgetIsStopped[5] = ldftn(AppendCharApplicationBaseValue);
			DropPatch.VARFLAGFBINDABLEgetIsStopped[6] = ldftn(PacketDaysInMonth);
		}

		// Token: 0x0400006C RID: 108
		private static IntPtr[] VARFLAGFBINDABLEgetIsStopped;
	}
}
