﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000014 RID: 20
	[HarmonyPatch(typeof(GorillaNot), "SendReport")]
	internal class AntiCheat : MonoBehaviour
	{
		// Token: 0x060001BF RID: 447 RVA: 0x0000E4F0 File Offset: 0x0000C6F0
		private static bool getRemotingConfigurationHashElementDigestValue(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0000E524 File Offset: 0x0000C724
		public AntiCheat()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.AntiCheat), ref num, ref num2, ref num3, this, AntiCheat.IsFieldDefExceptionMessage[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0000E558 File Offset: 0x0000C758
		private static bool Prefix(string susReason, string susId, string susNick)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, AntiCheat.IsFieldDefExceptionMessage[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x0000E590 File Offset: 0x0000C790
		private static bool BoxedStoreSubcategoryEnumeration(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x0000E5B0 File Offset: 0x0000C7B0
		private static void LdsfldsetFullDateTimePattern(ref int A_0, ref int A_1, ref int A_2, AntiCheat A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x0000E5D4 File Offset: 0x0000C7D4
		// Note: this type is marked as 'beforefieldinit'.
		static AntiCheat()
		{
			AntiCheat.RecordDelayedFixupParamsArray();
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x0000E5E8 File Offset: 0x0000C7E8
		private static void RecordDelayedFixupParamsArray()
		{
			AntiCheat.IsFieldDefExceptionMessage = new IntPtr[3];
			AntiCheat.IsFieldDefExceptionMessage[0] = ldftn(getRemotingConfigurationHashElementDigestValue);
			AntiCheat.IsFieldDefExceptionMessage[1] = ldftn(BoxedStoreSubcategoryEnumeration);
			AntiCheat.IsFieldDefExceptionMessage[2] = ldftn(LdsfldsetFullDateTimePattern);
		}

		// Token: 0x04000070 RID: 112
		private static IntPtr[] IsFieldDefExceptionMessage;
	}
}
