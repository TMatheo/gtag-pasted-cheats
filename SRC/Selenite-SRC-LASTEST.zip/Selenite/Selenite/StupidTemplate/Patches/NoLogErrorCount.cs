﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000015 RID: 21
	[HarmonyPatch(typeof(GorillaNot), "LogErrorCount")]
	public class NoLogErrorCount : MonoBehaviour
	{
		// Token: 0x060001C6 RID: 454 RVA: 0x0000E638 File Offset: 0x0000C838
		private static bool STOREASSEMBLYIncrementStructFieldCount(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x0000E658 File Offset: 0x0000C858
		private static void PermissionListSetHostExecutionContextManager(ref int A_0, ref int A_1, ref int A_2, NoLogErrorCount A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x0000E67C File Offset: 0x0000C87C
		private static bool Prefix(string logString, string stackTrace, LogType type)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, NoLogErrorCount.SaltsetSoapAction[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x0000E6B4 File Offset: 0x0000C8B4
		public NoLogErrorCount()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.NoLogErrorCount), ref num, ref num2, ref num3, this, NoLogErrorCount.SaltsetSoapAction[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001CA RID: 458 RVA: 0x0000E6E8 File Offset: 0x0000C8E8
		private static bool TripleDESCryptoServiceProviderGetRange(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0000E71C File Offset: 0x0000C91C
		// Note: this type is marked as 'beforefieldinit'.
		static NoLogErrorCount()
		{
			NoLogErrorCount.UtcDateTimeThreadStaticAttribute();
		}

		// Token: 0x060001CC RID: 460 RVA: 0x0000E730 File Offset: 0x0000C930
		private static void UtcDateTimeThreadStaticAttribute()
		{
			NoLogErrorCount.SaltsetSoapAction = new IntPtr[3];
			NoLogErrorCount.SaltsetSoapAction[0] = ldftn(TripleDESCryptoServiceProviderGetRange);
			NoLogErrorCount.SaltsetSoapAction[1] = ldftn(STOREASSEMBLYIncrementStructFieldCount);
			NoLogErrorCount.SaltsetSoapAction[2] = ldftn(PermissionListSetHostExecutionContextManager);
		}

		// Token: 0x04000071 RID: 113
		private static IntPtr[] SaltsetSoapAction;
	}
}
