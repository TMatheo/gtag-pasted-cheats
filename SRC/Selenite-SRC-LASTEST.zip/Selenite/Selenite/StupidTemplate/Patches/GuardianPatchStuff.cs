﻿using System;
using HarmonyLib;

namespace StupidTemplate.Patches
{
	// Token: 0x02000011 RID: 17
	[HarmonyPatch(typeof(VRRig), "GrabbedByPlayer")]
	public class GuardianPatchStuff
	{
		// Token: 0x06000195 RID: 405 RVA: 0x0000DA24 File Offset: 0x0000BC24
		public static bool Prefix(VRRig __instance, VRRig grabbedByRig, bool grabbedBody, bool grabbedLeftHand, bool grabbedWithLeftHand)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 6)
			{
				int num3;
				bool flag;
				bool flag2;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,VRRig), ref num, ref num2, ref num3, ref flag, ref flag2, __instance, GuardianPatchStuff.KeyValuePairResolveString[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x06000196 RID: 406 RVA: 0x0000DA60 File Offset: 0x0000BC60
		public GuardianPatchStuff()
		{
			int num = 6;
			int num2 = 6;
			num2 = 6;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.GuardianPatchStuff), ref num, ref num2, ref num3, this, GuardianPatchStuff.KeyValuePairResolveString[num]);
			}
			num2 = 6;
		}

		// Token: 0x06000197 RID: 407 RVA: 0x0000DA94 File Offset: 0x0000BC94
		private static bool DenySetInstanceInsertLineBreaks(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool flag = A_5 == GorillaTagger.Instance.offlineVRRig;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 3;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x06000198 RID: 408 RVA: 0x0000DB08 File Offset: 0x0000BD08
		private static bool VTDISPATCHVARFLAGFREADONLY(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			int num = ((!GuardianPatchStuff.enabled) ? 1 : 0) * 1 + 1;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x06000199 RID: 409 RVA: 0x0000DB50 File Offset: 0x0000BD50
		private static bool getReturnTypeInternalSink(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool flag = false;
			A_4 = flag;
			A_0 = 5;
			bool result;
			return result;
		}

		// Token: 0x0600019A RID: 410 RVA: 0x0000DB84 File Offset: 0x0000BD84
		private static bool ConvertTimeBySystemTimeZoneIdDescriptionMetadataPublisher(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool flag = true;
			A_4 = flag;
			A_0 = 5;
			bool result;
			return result;
		}

		// Token: 0x0600019B RID: 411 RVA: 0x0000DBB8 File Offset: 0x0000BDB8
		private static bool RegisteredChannelsHeaderName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool result = A_4;
			A_1 = 6;
			return result;
		}

		// Token: 0x0600019C RID: 412 RVA: 0x0000DBD8 File Offset: 0x0000BDD8
		private static void BeginCriticalRegionMaxDegreeOfParallelism(ref int A_0, ref int A_1, ref int A_2, GuardianPatchStuff A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x0600019D RID: 413 RVA: 0x0000DBFC File Offset: 0x0000BDFC
		private static bool setRngInterfaceMarshaler(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, VRRig A_5)
		{
			bool flag = false;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 3;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x0600019E RID: 414 RVA: 0x0000DC5C File Offset: 0x0000BE5C
		// Note: this type is marked as 'beforefieldinit'.
		static GuardianPatchStuff()
		{
			GuardianPatchStuff.GetFormatEncodingNLS();
		}

		// Token: 0x0600019F RID: 415 RVA: 0x0000DC70 File Offset: 0x0000BE70
		private static void GetFormatEncodingNLS()
		{
			GuardianPatchStuff.KeyValuePairResolveString = new IntPtr[7];
			GuardianPatchStuff.KeyValuePairResolveString[0] = ldftn(VTDISPATCHVARFLAGFREADONLY);
			GuardianPatchStuff.KeyValuePairResolveString[1] = ldftn(DenySetInstanceInsertLineBreaks);
			GuardianPatchStuff.KeyValuePairResolveString[2] = ldftn(setRngInterfaceMarshaler);
			GuardianPatchStuff.KeyValuePairResolveString[3] = ldftn(getReturnTypeInternalSink);
			GuardianPatchStuff.KeyValuePairResolveString[4] = ldftn(ConvertTimeBySystemTimeZoneIdDescriptionMetadataPublisher);
			GuardianPatchStuff.KeyValuePairResolveString[5] = ldftn(RegisteredChannelsHeaderName);
			GuardianPatchStuff.KeyValuePairResolveString[6] = ldftn(BeginCriticalRegionMaxDegreeOfParallelism);
		}

		// Token: 0x0400006A RID: 106
		public static bool enabled;

		// Token: 0x0400006B RID: 107
		private static IntPtr[] KeyValuePairResolveString;
	}
}
