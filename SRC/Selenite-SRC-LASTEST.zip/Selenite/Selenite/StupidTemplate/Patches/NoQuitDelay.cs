﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000018 RID: 24
	[HarmonyPatch(typeof(GorillaNot), "QuitDelay", 5)]
	public class NoQuitDelay : MonoBehaviour
	{
		// Token: 0x060001DB RID: 475 RVA: 0x0000EA10 File Offset: 0x0000CC10
		private static bool Prefix()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, NoQuitDelay.AsErrorCurrentAppDomain[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001DC RID: 476 RVA: 0x0000EA48 File Offset: 0x0000CC48
		private static void GetSharedStringMakergetContextProperties(ref int A_0, ref int A_1, ref int A_2, NoQuitDelay A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001DD RID: 477 RVA: 0x0000EA6C File Offset: 0x0000CC6C
		private static bool getSecurityIdentifierTimeSpanThrowStyle(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000EAA0 File Offset: 0x0000CCA0
		private static bool LongPathHelpergetBuild(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001DF RID: 479 RVA: 0x0000EAC0 File Offset: 0x0000CCC0
		public NoQuitDelay()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.NoQuitDelay), ref num, ref num2, ref num3, this, NoQuitDelay.AsErrorCurrentAppDomain[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x0000EAF4 File Offset: 0x0000CCF4
		// Note: this type is marked as 'beforefieldinit'.
		static NoQuitDelay()
		{
			NoQuitDelay.GenericFieldInfoHexIntPtrType();
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x0000EB08 File Offset: 0x0000CD08
		private static void GenericFieldInfoHexIntPtrType()
		{
			NoQuitDelay.AsErrorCurrentAppDomain = new IntPtr[3];
			NoQuitDelay.AsErrorCurrentAppDomain[0] = ldftn(getSecurityIdentifierTimeSpanThrowStyle);
			NoQuitDelay.AsErrorCurrentAppDomain[1] = ldftn(LongPathHelpergetBuild);
			NoQuitDelay.AsErrorCurrentAppDomain[2] = ldftn(GetSharedStringMakergetContextProperties);
		}

		// Token: 0x04000074 RID: 116
		private static IntPtr[] AsErrorCurrentAppDomain;
	}
}
