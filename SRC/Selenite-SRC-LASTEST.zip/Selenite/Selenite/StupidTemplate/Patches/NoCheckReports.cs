﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000017 RID: 23
	[HarmonyPatch(typeof(GorillaNot), "CheckReports", 5)]
	public class NoCheckReports : MonoBehaviour
	{
		// Token: 0x060001D4 RID: 468 RVA: 0x0000E8C8 File Offset: 0x0000CAC8
		private static bool Prefix()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, NoCheckReports.TokenElevationPrecannedResource[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x0000E900 File Offset: 0x0000CB00
		private static void OrdinalIgnoreCaseCreateLinkedTokenSource(ref int A_0, ref int A_1, ref int A_2, NoCheckReports A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x0000E924 File Offset: 0x0000CB24
		private static bool getTypeInformationgetPrivateBinPathProbe(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0000E958 File Offset: 0x0000CB58
		private static bool LinuxTYPEFLAGFREPLACEABLE(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x0000E978 File Offset: 0x0000CB78
		public NoCheckReports()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.NoCheckReports), ref num, ref num2, ref num3, this, NoCheckReports.TokenElevationPrecannedResource[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x0000E9AC File Offset: 0x0000CBAC
		// Note: this type is marked as 'beforefieldinit'.
		static NoCheckReports()
		{
			NoCheckReports.SynchronizeTaskScheduled();
		}

		// Token: 0x060001DA RID: 474 RVA: 0x0000E9C0 File Offset: 0x0000CBC0
		private static void SynchronizeTaskScheduled()
		{
			NoCheckReports.TokenElevationPrecannedResource = new IntPtr[3];
			NoCheckReports.TokenElevationPrecannedResource[0] = ldftn(getTypeInformationgetPrivateBinPathProbe);
			NoCheckReports.TokenElevationPrecannedResource[1] = ldftn(LinuxTYPEFLAGFREPLACEABLE);
			NoCheckReports.TokenElevationPrecannedResource[2] = ldftn(OrdinalIgnoreCaseCreateLinkedTokenSource);
		}

		// Token: 0x04000073 RID: 115
		private static IntPtr[] TokenElevationPrecannedResource;
	}
}
