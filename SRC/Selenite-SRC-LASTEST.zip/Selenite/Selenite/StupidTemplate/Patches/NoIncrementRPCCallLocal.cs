﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000019 RID: 25
	[HarmonyPatch(typeof(GorillaNot), "IncrementRPCCallLocal")]
	public class NoIncrementRPCCallLocal : MonoBehaviour
	{
		// Token: 0x060001E2 RID: 482 RVA: 0x0000EB58 File Offset: 0x0000CD58
		private static bool AddMillisecondsDefineManifestResource(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x0000EB78 File Offset: 0x0000CD78
		private static bool ProcessingConcurrentTasksProgIdRedirectionSection(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x0000EBAC File Offset: 0x0000CDAC
		private static void SoapQNameProxyTypeName(ref int A_0, ref int A_1, ref int A_2, NoIncrementRPCCallLocal A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x0000EBD0 File Offset: 0x0000CDD0
		public NoIncrementRPCCallLocal()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.NoIncrementRPCCallLocal), ref num, ref num2, ref num3, this, NoIncrementRPCCallLocal.GetRectArrayDebugOutChnl[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x0000EC04 File Offset: 0x0000CE04
		private static bool Prefix(PhotonMessageInfoWrapped infoWrapped, string rpcFunction)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, NoIncrementRPCCallLocal.GetRectArrayDebugOutChnl[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x0000EC3C File Offset: 0x0000CE3C
		// Note: this type is marked as 'beforefieldinit'.
		static NoIncrementRPCCallLocal()
		{
			NoIncrementRPCCallLocal.SoapAnyUriwLibFlags();
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x0000EC50 File Offset: 0x0000CE50
		private static void SoapAnyUriwLibFlags()
		{
			NoIncrementRPCCallLocal.GetRectArrayDebugOutChnl = new IntPtr[3];
			NoIncrementRPCCallLocal.GetRectArrayDebugOutChnl[0] = ldftn(ProcessingConcurrentTasksProgIdRedirectionSection);
			NoIncrementRPCCallLocal.GetRectArrayDebugOutChnl[1] = ldftn(AddMillisecondsDefineManifestResource);
			NoIncrementRPCCallLocal.GetRectArrayDebugOutChnl[2] = ldftn(SoapQNameProxyTypeName);
		}

		// Token: 0x04000075 RID: 117
		private static IntPtr[] GetRectArrayDebugOutChnl;
	}
}
