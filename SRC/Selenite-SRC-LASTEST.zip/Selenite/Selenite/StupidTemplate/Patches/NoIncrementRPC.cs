﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x0200001C RID: 28
	[HarmonyPatch(typeof(VRRig), "IncrementRPC", new Type[]
	{
		typeof(PhotonMessageInfoWrapped),
		typeof(string)
	})]
	public class NoIncrementRPC : MonoBehaviour
	{
		// Token: 0x060001F7 RID: 503 RVA: 0x0000EF30 File Offset: 0x0000D130
		private static void WriteThroughgetRootCodeGroup(ref int A_0, ref int A_1, ref int A_2, NoIncrementRPC A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x0000EF54 File Offset: 0x0000D154
		public NoIncrementRPC()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.NoIncrementRPC), ref num, ref num2, ref num3, this, NoIncrementRPC.ContentTypeSystemException[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x0000EF88 File Offset: 0x0000D188
		private static bool getSequencePointCountNegativeInfinity(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001FA RID: 506 RVA: 0x0000EFBC File Offset: 0x0000D1BC
		private static bool Prefix(PhotonMessageInfoWrapped info, string sourceCall)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, NoIncrementRPC.ContentTypeSystemException[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001FB RID: 507 RVA: 0x0000EFF4 File Offset: 0x0000D1F4
		private static bool getGrantedSetWindowsAccountType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001FC RID: 508 RVA: 0x0000F014 File Offset: 0x0000D214
		// Note: this type is marked as 'beforefieldinit'.
		static NoIncrementRPC()
		{
			NoIncrementRPC.CopyTransitionTime();
		}

		// Token: 0x060001FD RID: 509 RVA: 0x0000F028 File Offset: 0x0000D228
		private static void CopyTransitionTime()
		{
			NoIncrementRPC.ContentTypeSystemException = new IntPtr[3];
			NoIncrementRPC.ContentTypeSystemException[0] = ldftn(getSequencePointCountNegativeInfinity);
			NoIncrementRPC.ContentTypeSystemException[1] = ldftn(getGrantedSetWindowsAccountType);
			NoIncrementRPC.ContentTypeSystemException[2] = ldftn(WriteThroughgetRootCodeGroup);
		}

		// Token: 0x04000078 RID: 120
		private static IntPtr[] ContentTypeSystemException;
	}
}
