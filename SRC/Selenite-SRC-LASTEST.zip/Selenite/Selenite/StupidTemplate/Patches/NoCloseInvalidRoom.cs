﻿using System;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000016 RID: 22
	[HarmonyPatch(typeof(GorillaNot), "CloseInvalidRoom")]
	public class NoCloseInvalidRoom : MonoBehaviour
	{
		// Token: 0x060001CD RID: 461 RVA: 0x0000E780 File Offset: 0x0000C980
		private static bool Prefix()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, NoCloseInvalidRoom.IClrStrongNameUsingIntPtrGetTypeKind[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x060001CE RID: 462 RVA: 0x0000E7B8 File Offset: 0x0000C9B8
		private static void PrelinkTokenMandatoryPolicy(ref int A_0, ref int A_1, ref int A_2, NoCloseInvalidRoom A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001CF RID: 463 RVA: 0x0000E7DC File Offset: 0x0000C9DC
		private static bool getTryLengthServicePack(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x0000E810 File Offset: 0x0000CA10
		private static bool CompareInfoSerObjectInfoInit(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0000E830 File Offset: 0x0000CA30
		public NoCloseInvalidRoom()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.NoCloseInvalidRoom), ref num, ref num2, ref num3, this, NoCloseInvalidRoom.IClrStrongNameUsingIntPtrGetTypeKind[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x0000E864 File Offset: 0x0000CA64
		// Note: this type is marked as 'beforefieldinit'.
		static NoCloseInvalidRoom()
		{
			NoCloseInvalidRoom.MemberTypeCurrentContext();
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x0000E878 File Offset: 0x0000CA78
		private static void MemberTypeCurrentContext()
		{
			NoCloseInvalidRoom.IClrStrongNameUsingIntPtrGetTypeKind = new IntPtr[3];
			NoCloseInvalidRoom.IClrStrongNameUsingIntPtrGetTypeKind[0] = ldftn(getTryLengthServicePack);
			NoCloseInvalidRoom.IClrStrongNameUsingIntPtrGetTypeKind[1] = ldftn(CompareInfoSerObjectInfoInit);
			NoCloseInvalidRoom.IClrStrongNameUsingIntPtrGetTypeKind[2] = ldftn(PrelinkTokenMandatoryPolicy);
		}

		// Token: 0x04000072 RID: 114
		private static IntPtr[] IClrStrongNameUsingIntPtrGetTypeKind;
	}
}
