﻿using System;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Notifications;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000010 RID: 16
	[HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerLeftRoom")]
	internal class LeavePatch : MonoBehaviour
	{
		// Token: 0x0600018B RID: 395 RVA: 0x0000D7A4 File Offset: 0x0000B9A4
		private static void Prefix(Player otherPlayer)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 5)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,Photon.Realtime.Player), ref num, ref num2, ref num3, ref flag, otherPlayer, LeavePatch.IHashCodeProviderPostconditionOnException[num]);
			}
			num2 = 0;
		}

		// Token: 0x0600018C RID: 396 RVA: 0x0000D7DC File Offset: 0x0000B9DC
		public LeavePatch()
		{
			int num = 5;
			int num2 = 5;
			num2 = 5;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.LeavePatch), ref num, ref num2, ref num3, this, LeavePatch.IHashCodeProviderPostconditionOnException[num]);
			}
			num2 = 5;
		}

		// Token: 0x0600018D RID: 397 RVA: 0x0000D810 File Offset: 0x0000BA10
		private static void PrefixCodeAssemblyContentType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Player A_4)
		{
			bool flag = false;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 3;
			A_0 = num;
		}

		// Token: 0x0600018E RID: 398 RVA: 0x0000D86C File Offset: 0x0000BA6C
		private static void MemberFilterarrayIndex(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Player A_4)
		{
			int num = ((A_4 == PhotonNetwork.LocalPlayer) * true + true) ? 1 : 0;
			A_0 = num;
		}

		// Token: 0x0600018F RID: 399 RVA: 0x0000D8A0 File Offset: 0x0000BAA0
		private static void scaleTypeAttributes(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Player A_4)
		{
			NotifiLib.SendNotification("[<color=blue>Room</color>]: " + A_4.NickName + " Left");
			LeavePatch.a = A_4;
			A_1 = 5;
		}

		// Token: 0x06000190 RID: 400 RVA: 0x0000D8E0 File Offset: 0x0000BAE0
		private static void FromFileTimeIsAssemblyNameSetExplicit(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Player A_4)
		{
			A_1 = 5;
		}

		// Token: 0x06000191 RID: 401 RVA: 0x0000D8F8 File Offset: 0x0000BAF8
		private static void StateGetSecurityDescriptorSddlForm(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Player A_4)
		{
			bool flag = A_4 != LeavePatch.a;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 3;
			A_0 = num;
		}

		// Token: 0x06000192 RID: 402 RVA: 0x0000D968 File Offset: 0x0000BB68
		private static void GACCgtUn(ref int A_0, ref int A_1, ref int A_2, LeavePatch A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000193 RID: 403 RVA: 0x0000D98C File Offset: 0x0000BB8C
		// Note: this type is marked as 'beforefieldinit'.
		static LeavePatch()
		{
			LeavePatch.ResolvePolicyCMSASSEMBLYREFERENCEFLAGCULTUREWILDCARDED();
		}

		// Token: 0x06000194 RID: 404 RVA: 0x0000D9A0 File Offset: 0x0000BBA0
		private static void ResolvePolicyCMSASSEMBLYREFERENCEFLAGCULTUREWILDCARDED()
		{
			LeavePatch.IHashCodeProviderPostconditionOnException = new IntPtr[6];
			LeavePatch.IHashCodeProviderPostconditionOnException[0] = ldftn(MemberFilterarrayIndex);
			LeavePatch.IHashCodeProviderPostconditionOnException[1] = ldftn(StateGetSecurityDescriptorSddlForm);
			LeavePatch.IHashCodeProviderPostconditionOnException[2] = ldftn(PrefixCodeAssemblyContentType);
			LeavePatch.IHashCodeProviderPostconditionOnException[3] = ldftn(scaleTypeAttributes);
			LeavePatch.IHashCodeProviderPostconditionOnException[4] = ldftn(FromFileTimeIsAssemblyNameSetExplicit);
			LeavePatch.IHashCodeProviderPostconditionOnException[5] = ldftn(GACCgtUn);
		}

		// Token: 0x04000068 RID: 104
		private static Player a;

		// Token: 0x04000069 RID: 105
		private static IntPtr[] IHashCodeProviderPostconditionOnException;
	}
}
