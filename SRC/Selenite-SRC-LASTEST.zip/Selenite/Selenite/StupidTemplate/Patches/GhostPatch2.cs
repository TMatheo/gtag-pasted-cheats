﻿using System;
using HarmonyLib;

namespace StupidTemplate.Patches
{
	// Token: 0x0200001F RID: 31
	[HarmonyPatch(typeof(VRRigJobManager), "DeregisterVRRig")]
	public static class GhostPatch2
	{
		// Token: 0x0600020D RID: 525 RVA: 0x0000F33C File Offset: 0x0000D53C
		private static bool OriginalIssuerRfcDeriveBytes(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, VRRigJobManager A_4)
		{
			bool result = A_3;
			A_1 = 2;
			return result;
		}

		// Token: 0x0600020E RID: 526 RVA: 0x0000F35C File Offset: 0x0000D55C
		private static bool SoapEntitiesIdentityObject(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, VRRigJobManager A_4)
		{
			bool flag = !(A_4 == GorillaTagger.Instance.offlineVRRig);
			A_3 = flag;
			A_0 = 1;
			bool result;
			return result;
		}

		// Token: 0x0600020F RID: 527 RVA: 0x0000F3A4 File Offset: 0x0000D5A4
		public static bool Prefix(VRRigJobManager __instance, VRRig rig)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			bool result;
			while (num2 != 2)
			{
				int num3;
				bool flag;
				result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,VRRigJobManager), ref num, ref num2, ref num3, ref flag, __instance, GhostPatch2.BaseCodePageEncodingIIDIEnumSTOREDEPLOYMENTMETADATAPROPERTY[num]);
			}
			num2 = 0;
			return result;
		}

		// Token: 0x06000210 RID: 528 RVA: 0x0000F3E0 File Offset: 0x0000D5E0
		// Note: this type is marked as 'beforefieldinit'.
		static GhostPatch2()
		{
			GhostPatch2.MulOvfUnsetAssemblyName();
		}

		// Token: 0x06000211 RID: 529 RVA: 0x0000F3F4 File Offset: 0x0000D5F4
		private static void MulOvfUnsetAssemblyName()
		{
			GhostPatch2.BaseCodePageEncodingIIDIEnumSTOREDEPLOYMENTMETADATAPROPERTY = new IntPtr[2];
			GhostPatch2.BaseCodePageEncodingIIDIEnumSTOREDEPLOYMENTMETADATAPROPERTY[0] = ldftn(SoapEntitiesIdentityObject);
			GhostPatch2.BaseCodePageEncodingIIDIEnumSTOREDEPLOYMENTMETADATAPROPERTY[1] = ldftn(OriginalIssuerRfcDeriveBytes);
		}

		// Token: 0x0400007B RID: 123
		private static IntPtr[] BaseCodePageEncodingIIDIEnumSTOREDEPLOYMENTMETADATAPROPERTY;
	}
}
