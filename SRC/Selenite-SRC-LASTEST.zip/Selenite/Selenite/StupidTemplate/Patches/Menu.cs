﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x02000013 RID: 19
	public class Menu : MonoBehaviour
	{
		// Token: 0x060001AB RID: 427 RVA: 0x0000DFE4 File Offset: 0x0000C1E4
		internal static void ApplyHarmonyPatches()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[num]);
			}
			num2 = 2;
		}

		// Token: 0x060001AC RID: 428 RVA: 0x0000E01C File Offset: 0x0000C21C
		private static bool HeaderHandlerOpenStandardOutput(ref int A_0, ref int A_1, ref int A_2)
		{
			bool result = Menu.<IsPatched>k__BackingField;
			A_1 = 1;
			return result;
		}

		// Token: 0x060001AD RID: 429 RVA: 0x0000E038 File Offset: 0x0000C238
		private static void getFriendlyNameTokenPrivileges(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_1 = 0;
		}

		// Token: 0x060001AE RID: 430 RVA: 0x0000E050 File Offset: 0x0000C250
		internal static void RemoveHarmonyPatches()
		{
			int num = 7;
			int num2 = 7;
			num2 = 7;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[num]);
			}
			num2 = 7;
		}

		// Token: 0x060001AF RID: 431 RVA: 0x0000E084 File Offset: 0x0000C284
		public Menu()
		{
			int num = 12;
			int num2 = 12;
			num2 = 12;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.Menu), ref num, ref num2, ref num3, this, Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[num]);
			}
			num2 = 12;
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x0000E0BC File Offset: 0x0000C2BC
		private static void ConfigTreeParserIsCanceled(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			int num = ((Menu.instance == null) ? 1 : 0) * 1 + 8;
			A_0 = num;
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x0000E100 File Offset: 0x0000C300
		private static void getPathgetRootCodeGroup(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			A_1 = 0;
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x0000E118 File Offset: 0x0000C318
		private static void SharedStaticsAboveNormal(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = !Menu.IsPatched;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 3 + 3;
			A_0 = num;
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x0000E17C File Offset: 0x0000C37C
		private static void MethodCallMessageWrapperMoveDirectory(ref int A_0, ref int A_1, ref int A_2, Menu A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x0000E1A0 File Offset: 0x0000C3A0
		private static void ICustomPropertyProviderProxygetFormatJapaneseFirstYearAsANumber(ref int A_0, ref int A_1, ref int A_2, bool A_3)
		{
			Menu.<IsPatched>k__BackingField = A_3;
			A_1 = 0;
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060001B5 RID: 437 RVA: 0x0000E1C0 File Offset: 0x0000C3C0
		// (set) Token: 0x060001B7 RID: 439 RVA: 0x0000E254 File Offset: 0x0000C454
		public static bool IsPatched
		{
			[CompilerGenerated]
			get
			{
				int num = 0;
				int num2 = 0;
				num2 = 0;
				bool result;
				while (num2 != 1)
				{
					int num3;
					result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[num]);
				}
				num2 = 0;
				return result;
			}
			[CompilerGenerated]
			private set
			{
				int num = 1;
				int num2 = 1;
				num2 = 1;
				while (num2 != 0)
				{
					int num3;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean), ref num, ref num2, ref num3, value, Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[num]);
				}
				num2 = 1;
			}
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x0000E1F4 File Offset: 0x0000C3F4
		private static void VisibleToAllHostsInvalidOperationRegRemoveSubKey(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool isPatched = Menu.IsPatched;
			A_3 = isPatched;
			int num = ((!A_3) ? 1 : 0) * 1 + 10;
			A_0 = num;
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x0000E288 File Offset: 0x0000C488
		private static void getAsUintComRedirectionProxy(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			Menu.instance = new Harmony("org.asfewfvdxch.gorillatag.solar");
			Menu.instance.PatchAll(Assembly.GetExecutingAssembly());
			Menu.IsPatched = true;
			A_1 = 0;
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x0000E2CC File Offset: 0x0000C4CC
		private static void EmptyReadOnlyDictionaryInternalLcid(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			Menu.instance.PatchAll(Assembly.GetExecutingAssembly());
			Menu.IsPatched = true;
			A_1 = 0;
		}

		// Token: 0x060001BA RID: 442 RVA: 0x0000E300 File Offset: 0x0000C500
		private static void RegisterDynamicPropertyPOLICYVIEWAUDITINFORMATION(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			Menu.IsPatched = false;
			A_1 = 0;
		}

		// Token: 0x060001BB RID: 443 RVA: 0x0000E324 File Offset: 0x0000C524
		private static void SameMachineDMNd(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = false;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 10;
			A_0 = num;
		}

		// Token: 0x060001BC RID: 444 RVA: 0x0000E380 File Offset: 0x0000C580
		private static void IsRunningDefaultDependencyAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = Menu.instance == null;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x060001BD RID: 445 RVA: 0x0000E3E0 File Offset: 0x0000C5E0
		// Note: this type is marked as 'beforefieldinit'.
		static Menu()
		{
			Menu.COREREMOTINGgetBlockLongPaths();
		}

		// Token: 0x060001BE RID: 446 RVA: 0x0000E3F4 File Offset: 0x0000C5F4
		private static void COREREMOTINGgetBlockLongPaths()
		{
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle = new IntPtr[13];
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[0] = ldftn(HeaderHandlerOpenStandardOutput);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[1] = ldftn(ICustomPropertyProviderProxygetFormatJapaneseFirstYearAsANumber);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[2] = ldftn(SharedStaticsAboveNormal);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[3] = ldftn(IsRunningDefaultDependencyAttribute);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[4] = ldftn(getAsUintComRedirectionProxy);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[5] = ldftn(EmptyReadOnlyDictionaryInternalLcid);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[6] = ldftn(getFriendlyNameTokenPrivileges);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[7] = ldftn(ConfigTreeParserIsCanceled);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[8] = ldftn(VisibleToAllHostsInvalidOperationRegRemoveSubKey);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[9] = ldftn(SameMachineDMNd);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[10] = ldftn(RegisterDynamicPropertyPOLICYVIEWAUDITINFORMATION);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[11] = ldftn(getPathgetRootCodeGroup);
			Menu.setAllFilesDoNotAddrOfCspParentWindowHandle[12] = ldftn(MethodCallMessageWrapperMoveDirectory);
		}

		// Token: 0x0400006E RID: 110
		private static Harmony instance;

		// Token: 0x0400006F RID: 111
		private static IntPtr[] setAllFilesDoNotAddrOfCspParentWindowHandle;
	}
}
