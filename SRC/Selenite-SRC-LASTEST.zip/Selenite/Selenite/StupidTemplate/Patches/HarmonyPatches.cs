﻿using System;
using System.ComponentModel;
using BepInEx;

namespace StupidTemplate.Patches
{
	// Token: 0x0200001D RID: 29
	[Description("m")]
	[BepInPlugin("org.asfewfvdxch.gorillatag.solar", "<b>Solar</b>", "1.0.0")]
	public class HarmonyPatches : BaseUnityPlugin
	{
		// Token: 0x060001FE RID: 510 RVA: 0x0000F078 File Offset: 0x0000D278
		private static void EventSourceAttributeRaiseMethod(ref int A_0, ref int A_1, ref int A_2, HarmonyPatches A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060001FF RID: 511 RVA: 0x0000F09C File Offset: 0x0000D29C
		private void OnEnable()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, HarmonyPatches.MarshaledObjectPOLICYNOTIFICATION[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000200 RID: 512 RVA: 0x0000F0D0 File Offset: 0x0000D2D0
		private static void AddFieldMoveDirectory(ref int A_0, ref int A_1, ref int A_2)
		{
			Menu.RemoveHarmonyPatches();
			A_1 = 0;
		}

		// Token: 0x06000201 RID: 513 RVA: 0x0000F0F0 File Offset: 0x0000D2F0
		private void OnDisable()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, HarmonyPatches.MarshaledObjectPOLICYNOTIFICATION[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0000F124 File Offset: 0x0000D324
		private static void TableCgtUn(ref int A_0, ref int A_1, ref int A_2)
		{
			Menu.ApplyHarmonyPatches();
			A_1 = 2;
		}

		// Token: 0x06000203 RID: 515 RVA: 0x0000F144 File Offset: 0x0000D344
		public HarmonyPatches()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.HarmonyPatches), ref num, ref num2, ref num3, this, HarmonyPatches.MarshaledObjectPOLICYNOTIFICATION[num]);
			}
			num2 = 2;
		}

		// Token: 0x06000204 RID: 516 RVA: 0x0000F178 File Offset: 0x0000D378
		// Note: this type is marked as 'beforefieldinit'.
		static HarmonyPatches()
		{
			HarmonyPatches.QueueProcessMessageFinish();
		}

		// Token: 0x06000205 RID: 517 RVA: 0x0000F18C File Offset: 0x0000D38C
		private static void QueueProcessMessageFinish()
		{
			HarmonyPatches.MarshaledObjectPOLICYNOTIFICATION = new IntPtr[3];
			HarmonyPatches.MarshaledObjectPOLICYNOTIFICATION[0] = ldftn(TableCgtUn);
			HarmonyPatches.MarshaledObjectPOLICYNOTIFICATION[1] = ldftn(AddFieldMoveDirectory);
			HarmonyPatches.MarshaledObjectPOLICYNOTIFICATION[2] = ldftn(EventSourceAttributeRaiseMethod);
		}

		// Token: 0x04000079 RID: 121
		private static IntPtr[] MarshaledObjectPOLICYNOTIFICATION;
	}
}
