﻿using System;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Notifications;
using UnityEngine;

namespace StupidTemplate.Patches
{
	// Token: 0x0200000F RID: 15
	[HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerEnteredRoom")]
	internal class JoinPatch : MonoBehaviour
	{
		// Token: 0x06000183 RID: 387 RVA: 0x0000D5DC File Offset: 0x0000B7DC
		private static void MinuteGlobalSwitch(ref int A_0, ref int A_1, ref int A_2, JoinPatch A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000184 RID: 388 RVA: 0x0000D600 File Offset: 0x0000B800
		public JoinPatch()
		{
			int num = 3;
			int num2 = 3;
			num2 = 3;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Patches.JoinPatch), ref num, ref num2, ref num3, this, JoinPatch.FormatDecimalgetInstance[num]);
			}
			num2 = 3;
		}

		// Token: 0x06000185 RID: 389 RVA: 0x0000D634 File Offset: 0x0000B834
		private static void GenericArraySortHelperPrivateProcessMessage(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Player A_4)
		{
			bool flag = A_4 != JoinPatch.oldnewplayer;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 1;
			A_0 = num;
		}

		// Token: 0x06000186 RID: 390 RVA: 0x0000D6A0 File Offset: 0x0000B8A0
		private static void IEnumVARIANTopDivision(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Player A_4)
		{
			A_1 = 3;
		}

		// Token: 0x06000187 RID: 391 RVA: 0x0000D6B8 File Offset: 0x0000B8B8
		private static void ObjectWithMapAssemIdS(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Player A_4)
		{
			NotifiLib.SendNotification("[<color=blue>Room</color>]: " + A_4.NickName + " Joined");
			JoinPatch.oldnewplayer = A_4;
			A_1 = 3;
		}

		// Token: 0x06000188 RID: 392 RVA: 0x0000D6F8 File Offset: 0x0000B8F8
		private static void Prefix(Player newPlayer)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 3)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,Photon.Realtime.Player), ref num, ref num2, ref num3, ref flag, newPlayer, JoinPatch.FormatDecimalgetInstance[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000189 RID: 393 RVA: 0x0000D730 File Offset: 0x0000B930
		// Note: this type is marked as 'beforefieldinit'.
		static JoinPatch()
		{
			JoinPatch.getIsPropertyDefaultContext();
		}

		// Token: 0x0600018A RID: 394 RVA: 0x0000D744 File Offset: 0x0000B944
		private static void getIsPropertyDefaultContext()
		{
			JoinPatch.FormatDecimalgetInstance = new IntPtr[4];
			JoinPatch.FormatDecimalgetInstance[0] = ldftn(GenericArraySortHelperPrivateProcessMessage);
			JoinPatch.FormatDecimalgetInstance[1] = ldftn(ObjectWithMapAssemIdS);
			JoinPatch.FormatDecimalgetInstance[2] = ldftn(IEnumVARIANTopDivision);
			JoinPatch.FormatDecimalgetInstance[3] = ldftn(MinuteGlobalSwitch);
		}

		// Token: 0x04000066 RID: 102
		private static Player oldnewplayer;

		// Token: 0x04000067 RID: 103
		private static IntPtr[] FormatDecimalgetInstance;
	}
}
