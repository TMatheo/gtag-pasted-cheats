﻿using System;

namespace StupidTemplate
{
	// Token: 0x0200000E RID: 14
	internal class PluginInfo
	{
		// Token: 0x0600017F RID: 383 RVA: 0x0000D540 File Offset: 0x0000B740
		private static void SuspendRequestedCLAIMSECURITYATTRIBUTEFQBNVALUE(ref int A_0, ref int A_1, ref int A_2, PluginInfo A_3)
		{
			A_3..ctor();
			A_1 = 2;
		}

		// Token: 0x06000180 RID: 384 RVA: 0x0000D564 File Offset: 0x0000B764
		public PluginInfo()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.PluginInfo), ref num, ref num2, ref num3, this, PluginInfo.WindowObjectRetval[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000181 RID: 385 RVA: 0x0000D598 File Offset: 0x0000B798
		// Note: this type is marked as 'beforefieldinit'.
		static PluginInfo()
		{
			PluginInfo.IConstructionReturnMessageBestFitEnabled();
		}

		// Token: 0x06000182 RID: 386 RVA: 0x0000D5AC File Offset: 0x0000B7AC
		private static void IConstructionReturnMessageBestFitEnabled()
		{
			PluginInfo.WindowObjectRetval = new IntPtr[1];
			PluginInfo.WindowObjectRetval[0] = ldftn(SuspendRequestedCLAIMSECURITYATTRIBUTEFQBNVALUE);
		}

		// Token: 0x04000061 RID: 97
		public const string GUID = "org.asfewfvdxch.gorillatag.solar";

		// Token: 0x04000062 RID: 98
		public const string Name = "<b>Solar</b>";

		// Token: 0x04000063 RID: 99
		public const string Description = "m";

		// Token: 0x04000064 RID: 100
		public const string Version = "1.0.0";

		// Token: 0x04000065 RID: 101
		private static IntPtr[] WindowObjectRetval;
	}
}
