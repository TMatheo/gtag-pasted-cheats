﻿using System;
using System.Linq;
using BepInEx;
using UnityEngine;
using UnityEngine.UI;

namespace StupidTemplate.Notifications
{
	// Token: 0x02000021 RID: 33
	[BepInPlugin("org.gorillatag.f.notificationsFixed", "NotificationLibraryV2", "1.0.4")]
	public class NotifiLib : BaseUnityPlugin
	{
		// Token: 0x06000218 RID: 536 RVA: 0x0000F57C File Offset: 0x0000D77C
		private static void getIsErrorgetAssemblyReferenceSection(ref int A_0, ref int A_1, ref int A_2, ref string A_3, ref string[] A_4, ref int A_5, ref string A_6, ref bool A_7, int A_8)
		{
			NotifiLib.NotifiText.text = A_3;
			A_1 = 0;
		}

		// Token: 0x06000219 RID: 537 RVA: 0x0000F5A8 File Offset: 0x0000D7A8
		private static void getIsFieldReadOnlyDictionaryHelpers(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			bool flag = !Settings.disableNotifications;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 10 + 18;
			A_0 = num;
		}

		// Token: 0x0600021A RID: 538 RVA: 0x0000F60C File Offset: 0x0000D80C
		private static void DecoderExceptionFallbackBufferTokenHashValue(ref int A_0, ref int A_1, ref int A_2, ref string A_3, ref string[] A_4, ref int A_5, ref string A_6, ref bool A_7, int A_8)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -4 + 35;
			A_0 = num;
		}

		// Token: 0x0600021B RID: 539 RVA: 0x0000F648 File Offset: 0x0000D848
		private static void ToBinarygetEncoderFallback(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_1 = 0;
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000F660 File Offset: 0x0000D860
		private static void getDeclaredFieldsSavePolicy(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_11.Notifilines = null;
			A_11.newtext = "";
			A_11.NotificationDecayTimeCounter = 0;
			A_11.Notifilines = Enumerable.ToArray<string>(Enumerable.Skip<string>(A_11.Testtext.text.Split(Environment.NewLine.ToCharArray()), 1));
			string[] notifilines = A_11.Notifilines;
			A_7 = notifilines;
			int num = 0;
			A_8 = num;
			A_0 = 12;
		}

		// Token: 0x0600021D RID: 541 RVA: 0x0000F704 File Offset: 0x0000D904
		private static void SymmetricAlgorithmParseDisplayName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			bool flag = GameObject.Find("Main Camera") != null;
			A_3 = flag;
			bool flag2 = A_3;
			A_4 = flag2;
			int num = ((!A_4) ? 1 : 0) * 1 + 5;
			A_0 = num;
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0000F78C File Offset: 0x0000D98C
		private static void PathDiscoveryCLRSurrogateEntry(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			bool flag = false;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 3 + 22;
			A_0 = num;
		}

		// Token: 0x0600021F RID: 543 RVA: 0x0000F7E8 File Offset: 0x0000D9E8
		private static void AsTypegetStateMachineType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			A_0 = 19;
		}

		// Token: 0x06000220 RID: 544 RVA: 0x0000F800 File Offset: 0x0000DA00
		private static void ConstructorBuilderSetMethodSourceRange(ref int A_0, ref int A_1, ref int A_2, ref string A_3, ref string[] A_4, ref int A_5, ref string A_6, ref bool A_7, int A_8)
		{
			string text = "";
			A_3 = text;
			string[] array = Enumerable.ToArray<string>(Enumerable.Skip<string>(NotifiLib.NotifiText.text.Split(Environment.NewLine.ToCharArray()), A_8));
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 34;
		}

		// Token: 0x06000221 RID: 545 RVA: 0x0000F880 File Offset: 0x0000DA80
		private static void LastWriteTimeCurrencyNegativePattern(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_11.HUDObj2.transform.position = new Vector3(A_11.MainCamera.transform.position.x, A_11.MainCamera.transform.position.y, A_11.MainCamera.transform.position.z);
			A_11.HUDObj2.transform.rotation = A_11.MainCamera.transform.rotation;
			bool flag = A_11.Testtext.text != "";
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 8 + 7;
			A_0 = num;
		}

		// Token: 0x06000222 RID: 546 RVA: 0x0000F978 File Offset: 0x0000DB78
		private static void IsMemberRefPath(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			NotifiLib.NotifiText.text = NotifiLib.NotifiText.text + A_7;
			NotifiLib.NotifiText.supportRichText = true;
			NotifiLib.PreviousNotifi = A_7;
			A_1 = 4;
			A_2 = 27;
		}

		// Token: 0x06000223 RID: 547 RVA: 0x0000F9DC File Offset: 0x0000DBDC
		private void Awake()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Notifications.NotifiLib), ref num, ref num2, ref num3, this, NotifiLib.InspectableGetAssemblyInformation[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000224 RID: 548 RVA: 0x0000FA10 File Offset: 0x0000DC10
		private static void TryOpenExistingDateTimeFormatInfo(ref int A_0, ref int A_1, ref int A_2, ref Quaternion A_3, ref Vector3 A_4, NotifiLib A_5)
		{
			A_5.MainCamera = GameObject.Find("Main Camera");
			A_5.HUDObj = new GameObject();
			A_5.HUDObj2 = new GameObject();
			A_5.HUDObj2.name = "NOTIFICATIONLIB_HUD_OBJ";
			A_5.HUDObj.name = "NOTIFICATIONLIB_HUD_OBJ";
			A_5.HUDObj.AddComponent<Canvas>();
			A_5.HUDObj.AddComponent<CanvasScaler>();
			A_5.HUDObj.AddComponent<GraphicRaycaster>();
			A_5.HUDObj.GetComponent<Canvas>().enabled = true;
			A_5.HUDObj.GetComponent<Canvas>().renderMode = 2;
			A_5.HUDObj.GetComponent<Canvas>().worldCamera = A_5.MainCamera.GetComponent<Camera>();
			A_5.HUDObj.GetComponent<RectTransform>().sizeDelta = new Vector2(5f, 5f);
			A_5.HUDObj.GetComponent<RectTransform>().position = new Vector3(A_5.MainCamera.transform.position.x, A_5.MainCamera.transform.position.y, A_5.MainCamera.transform.position.z);
			A_5.HUDObj2.transform.position = new Vector3(A_5.MainCamera.transform.position.x, A_5.MainCamera.transform.position.y, A_5.MainCamera.transform.position.z - 4.6f);
			A_5.HUDObj.transform.parent = A_5.HUDObj2.transform;
			A_5.HUDObj.GetComponent<RectTransform>().localPosition = new Vector3(0f, 0f, 1.6f);
			Quaternion rotation = A_5.HUDObj.GetComponent<RectTransform>().rotation;
			A_3 = rotation;
			Vector3 eulerAngles = A_3.eulerAngles;
			A_4 = eulerAngles;
			A_4.y = -270f;
			A_5.HUDObj.transform.localScale = new Vector3(0.65f, 0.65f, 0.65f);
			A_5.HUDObj.GetComponent<RectTransform>().rotation = Quaternion.Euler(A_4);
			A_5.Testtext = new GameObject
			{
				transform = 
				{
					parent = A_5.HUDObj.transform
				}
			}.AddComponent<Text>();
			A_5.Testtext.text = "";
			A_5.Testtext.fontSize = 1;
			A_5.Testtext.font = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/-- PhysicalComputer UI --/keyboard/Buttons/Text/u").GetComponent<Text>().font;
			A_5.Testtext.rectTransform.sizeDelta = new Vector2(260f, 180f);
			A_5.Testtext.alignment = 6;
			A_5.Testtext.rectTransform.localScale = new Vector3(0.01f, 0.01f, 1f);
			A_5.Testtext.rectTransform.localPosition = new Vector3(-1f, -1f, -0.5f);
			A_5.Testtext.material = A_5.AlertText;
			NotifiLib.NotifiText = A_5.Testtext;
			A_1 = 0;
		}

		// Token: 0x06000225 RID: 549 RVA: 0x0000FDF0 File Offset: 0x0000DFF0
		private void FixedUpdate()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				string[] array;
				int num4;
				string text;
				bool flag5;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.String[]&,System.Int32&,System.String&,System.Boolean&,StupidTemplate.Notifications.NotifiLib), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, ref flag4, ref array, ref num4, ref text, ref flag5, this, NotifiLib.InspectableGetAssemblyInformation[num]);
			}
			num2 = 2;
		}

		// Token: 0x06000226 RID: 550 RVA: 0x0000FE34 File Offset: 0x0000E034
		private static void getIsValueCreatedServerAsyncReplyTerminatorSink(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_11.Init();
			A_11.HasInit = true;
			A_11.HUDObj2.transform.position = new Vector3(A_11.MainCamera.transform.position.x, A_11.MainCamera.transform.position.y, A_11.MainCamera.transform.position.z);
			A_11.HUDObj2.transform.rotation = A_11.MainCamera.transform.rotation;
			bool flag = A_11.Testtext.text != "";
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 8 + 7;
			A_0 = num;
		}

		// Token: 0x06000227 RID: 551 RVA: 0x0000FF44 File Offset: 0x0000E144
		private static void getSignatureHour(ref int A_0, ref int A_1, ref int A_2, NotifiLib A_3)
		{
			A_3.AlertText = new Material(Shader.Find("GUI/Text Shader"));
			A_3.NotificationDecayTime = 144;
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000228 RID: 552 RVA: 0x0000FF8C File Offset: 0x0000E18C
		private static void TokenRestrictedSidsAssemblyHashAlgorithm(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			int num = ((!NotifiLib.IsEnabled) ? 1 : 0) * 1 + 20;
			A_0 = num;
		}

		// Token: 0x06000229 RID: 553 RVA: 0x0000FFD0 File Offset: 0x0000E1D0
		private static void CreateConstructionReturnMessageBuiltinNetworkConfigurationOperatorsSid(ref int A_0, ref int A_1, ref int A_2)
		{
			NotifiLib.NoticationThreshold = 30;
			NotifiLib.IsEnabled = true;
			A_1 = 0;
		}

		// Token: 0x0600022A RID: 554 RVA: 0x0000FFFC File Offset: 0x0000E1FC
		private static void PersonalINVOCATIONFLAGSNEEDSECURITY(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			A_1 = 0;
		}

		// Token: 0x0600022B RID: 555 RVA: 0x00010014 File Offset: 0x0000E214
		private static void StackBehaviourTwoLetterISORegionName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_11.NotificationDecayTimeCounter++;
			bool flag = A_11.NotificationDecayTimeCounter > A_11.NotificationDecayTime;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 6 + 8;
			A_0 = num;
		}

		// Token: 0x0600022C RID: 556 RVA: 0x00010098 File Offset: 0x0000E298
		private static void SetSizePageUp(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			A_1 = 0;
		}

		// Token: 0x0600022D RID: 557 RVA: 0x000100B0 File Offset: 0x0000E2B0
		private static void EnvoyInfoIsError(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_0 = 16;
		}

		// Token: 0x0600022E RID: 558 RVA: 0x000100C8 File Offset: 0x0000E2C8
		private static void ObjectProgressOutOfMemory(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			int num = A_8 + 1;
			A_8 = num;
			int num2 = ((A_8 < A_7.Length) ? 1 : 0) * -4 + 13;
			A_0 = num2;
		}

		// Token: 0x0600022F RID: 559 RVA: 0x00010128 File Offset: 0x0000E328
		private static void getGenericTypeArgumentsGetArgument(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			bool flag = !A_7.Contains(Environment.NewLine);
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 23;
			A_0 = num;
		}

		// Token: 0x06000230 RID: 560 RVA: 0x0001019C File Offset: 0x0000E39C
		private static void ReleaseTLibAttrgetGenerated(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			int num = (A_11.HasInit ? 1 : 0) * 1 + 3;
			A_0 = num;
		}

		// Token: 0x06000231 RID: 561 RVA: 0x000101E4 File Offset: 0x0000E3E4
		public static void ClearPastNotifications(int amount)
		{
			int num = 30;
			int num2 = 30;
			num2 = 30;
			while (num2 != 0)
			{
				int num3;
				string text;
				string[] array;
				int num4;
				string text2;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.String&,System.String[]&,System.Int32&,System.String&,System.Boolean&,System.Int32), ref num, ref num2, ref num3, ref text, ref array, ref num4, ref text2, ref flag, amount, NotifiLib.InspectableGetAssemblyInformation[num]);
			}
			num2 = 30;
		}

		// Token: 0x06000232 RID: 562 RVA: 0x00010228 File Offset: 0x0000E428
		private static void IsTokenOfTypeIClientFormatterSinkProvider(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_11.newtext = A_11.newtext + A_9 + "\n";
			int num = A_8 + 1;
			A_8 = num;
			int num2 = ((A_8 < A_7.Length) ? 1 : 0) * -4 + 13;
			A_0 = num2;
		}

		// Token: 0x06000233 RID: 563 RVA: 0x000102AC File Offset: 0x0000E4AC
		// Note: this type is marked as 'beforefieldinit'.
		static NotifiLib()
		{
			NotifiLib.AsinDuplicateEvidenceAction();
			int num = 37;
			int num2 = 37;
			num2 = 37;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, NotifiLib.InspectableGetAssemblyInformation[num]);
			}
			num2 = 37;
		}

		// Token: 0x06000234 RID: 564 RVA: 0x000102E8 File Offset: 0x0000E4E8
		private static void EnumEventsInvalidOperationEnumEnded(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			string text = A_7[A_8];
			A_9 = text;
			bool flag = A_9 != "";
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 1 + 10;
			A_0 = num;
		}

		// Token: 0x06000235 RID: 565 RVA: 0x00010378 File Offset: 0x0000E578
		private static void SpinLockLetterNumber(ref int A_0, ref int A_1, ref int A_2, NotifiLib A_3)
		{
			A_3.Logger.LogInfo("Plugin NotificationLibrary is loaded!");
			A_1 = 2;
		}

		// Token: 0x06000236 RID: 566 RVA: 0x000103A4 File Offset: 0x0000E5A4
		public unsafe static void SendNotification(string NotificationText)
		{
			RuntimeTypeHandle[] array = new RuntimeTypeHandle[1];
			Type[] array2 = new Type[1];
			array[0] = typeof(object).TypeHandle;
			int num = 1;
			int num2 = num * 4;
			int num3 = 17;
			int num4 = 17;
			num4 = 17;
			try
			{
				IL_36:
				int num5;
				int num8;
				int num9;
				int num10;
				int num11;
				int num12;
				int num13;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				object[] array3;
				int num21;
				object[] array4;
				Exception ex;
				while (num4 != 0)
				{
					if (num4 == 4)
					{
						num4 = 17;
						int num6;
						num5 = num6;
						int num7 = num5;
						num8 = num3;
						num9 = num8;
						num5 = 0;
						num10 = 2;
						for (;;)
						{
							num11 = (num5 + num10) / 2;
							num12 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num11 * 80 + 8 + num2);
							num13 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num11 * 80 + num2);
							if (num9 < num12 + num13)
							{
								if (num12 <= num9)
								{
									break;
								}
								num10 = num11 - 1;
							}
							else
							{
								num5 = num11 + 1;
							}
						}
						num14 = num11;
						num15 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num14 * 80 + 64 + num2);
						num16 = num15;
						num13 = num7;
						num12 = 0;
						num11 = 2;
						for (;;)
						{
							num10 = (num12 + num11) / 2;
							num5 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num10 * 80 + 8 + num2);
							num9 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num10 * 80 + num2);
							if (num13 < num5 + num9)
							{
								if (num5 <= num13)
								{
									break;
								}
								num11 = num10 - 1;
							}
							else
							{
								num12 = num10 + 1;
							}
						}
						num14 = num10;
						num17 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num14 * 80 + 64 + num2);
						num15 = num17;
						num9 = num7;
						num5 = 0;
						num10 = 2;
						for (;;)
						{
							num11 = (num5 + num10) / 2;
							num12 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num11 * 72 + 8 + num2);
							num13 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num11 * 72 + num2);
							if (num9 < num12 + num13)
							{
								if (num12 <= num9)
								{
									break;
								}
								num10 = num11 - 1;
							}
							else
							{
								num5 = num11 + 1;
							}
						}
						num14 = num11;
						num18 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num14 * 72 + 56 + num2);
						num17 = num18;
						for (;;)
						{
							IL_92F:
							if (array3 == null || (int)array3[1] == 0)
							{
								num9 = num15;
								while (num9 != num16)
								{
									if (num9 != -1)
									{
										num9 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num9 + num2);
									}
									else
									{
										num5 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + 40 + num2);
										if (num5 != -1)
										{
											goto Block_56;
										}
										num16 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + num2);
										goto IL_92F;
									}
								}
								goto IL_ACD;
							}
							int num19 = (int)array3[7];
							int num20;
							if (num16 == -1)
							{
								num20 = -1;
							}
							else
							{
								num21 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + 32 + num2);
								num13 = 0;
								num12 = 2;
								for (;;)
								{
									num11 = (num13 + num12) / 2;
									num10 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num11 * 72 + 8 + num2);
									num5 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num11 * 72 + num2);
									if (num21 < num10 + num5)
									{
										if (num10 <= num21)
										{
											break;
										}
										num12 = num11 - 1;
									}
									else
									{
										num13 = num11 + 1;
									}
								}
								num18 = num11;
								num14 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num18 * 72 + 56 + num2);
								num20 = num14;
							}
							if (num19 == num20)
							{
								num14 = num15;
								while (num14 != num16)
								{
									if (num14 != -1)
									{
										num14 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num14 + num2);
									}
									else
									{
										num18 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + 40 + num2);
										if (num18 != -1)
										{
											goto Block_52;
										}
										num16 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + num2);
										goto IL_92F;
									}
								}
								break;
							}
							if ((int)array3[7] == num17)
							{
								goto Block_53;
							}
							array3 = (object[])array3[0];
						}
						num3 = num7;
						continue;
						Block_52:
						num9 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num18 + 40 + num2);
						array4 = new object[8];
						array4[1] = 0;
						array4[0] = array3;
						array4[4] = num7;
						array4[7] = num18;
						array4[5] = 0;
						array3 = array4;
						num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num18 + 40 + num2);
						continue;
						Block_53:
						num3 = num7;
						continue;
						IL_ACD:
						num3 = num7;
						continue;
						Block_56:
						num10 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num5 + 40 + num2);
						array4 = new object[8];
						array4[1] = 0;
						array4[0] = array3;
						array4[4] = num7;
						array4[7] = num5;
						array4[5] = 0;
						array3 = array4;
						num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num5 + 40 + num2);
					}
					else
					{
						int num6;
						bool flag;
						bool flag2;
						bool flag3;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Boolean&,System.Boolean&,System.Boolean&,System.String&), ref num3, ref num4, ref num6, ex, ref flag, ref flag2, ref flag3, ref NotificationText, NotifiLib.InspectableGetAssemblyInformation[num3]);
					}
				}
				num4 = 17;
				return;
				IL_95:
				if (num10 != -1)
				{
					goto IL_A0;
				}
				goto IL_2CF;
				IL_A0:
				num9 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num10 + num2);
				if (0 == num9)
				{
					goto IL_BD;
				}
				if (1 == num9)
				{
					goto IL_253;
				}
				goto IL_2CF;
				IL_BD:
				num5 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num10 + 56 + num2);
				if (num5 == -1)
				{
					goto IL_109;
				}
				Type type;
				if ((type = array2[num5]) != null)
				{
					goto IL_EE;
				}
				array2[num5] = Type.GetTypeFromHandle(array[num5]);
				type = array2[num5];
				IL_EE:
				if (type.IsInstanceOfType(array4[2]))
				{
					goto IL_109;
				}
				num10 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num10 + 48 + num2);
				goto IL_95;
				IL_109:
				num16 = num10;
				num8 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + 8 + num2) + num2);
				num14 = (int)array4[6];
				IL_12B:
				if (num14 != num8)
				{
					goto IL_1AD;
				}
				num11 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + 40 + num2);
				ex = array4[2];
				array3 = (object[])array3[0];
				object[] array5 = new object[8];
				array5[1] = 1;
				array5[0] = array3;
				array5[2] = array4[2];
				array5[6] = (int)array4[6];
				array5[7] = num16;
				array5[5] = 2;
				array3 = array5;
				num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + 40 + num2);
				goto IL_36;
				IL_1AD:
				num15 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num14 + 40 + num2);
				if (num15 == -1)
				{
					goto IL_243;
				}
				num11 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num15 + 40 + num2);
				array3 = (object[])array3[0];
				array5 = new object[8];
				array5[1] = 1;
				array5[0] = array3;
				array5[2] = array4[2];
				array5[6] = (int)array4[6];
				array5[7] = num15;
				array5[3] = num16;
				array5[5] = 0;
				array3 = array5;
				num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num15 + 40 + num2);
				goto IL_36;
				IL_243:
				num14 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num14 + num2);
				goto IL_12B;
				IL_253:
				num11 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num10 + 16 + num2);
				ex = array4[2];
				array3 = (object[])array3[0];
				array5 = new object[8];
				array5[1] = 1;
				array5[0] = array3;
				array5[2] = array4[2];
				array5[6] = (int)array4[6];
				array5[7] = num10;
				array5[5] = 1;
				array3 = array5;
				num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num10 + 16 + num2);
				goto IL_36;
				IL_2CF:
				array3 = (object[])array3[0];
				Exception ex2 = array4[2];
				int num22 = (int)array4[6];
				IL_2EE:
				num10 = num3;
				num11 = num10;
				num12 = 0;
				num13 = 2;
				IL_2FD:
				num17 = (num12 + num13) / 2;
				num18 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num17 * 80 + 8 + num2);
				num21 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num17 * 80 + num2);
				if (num11 >= num18 + num21)
				{
					goto IL_33B;
				}
				if (num18 > num11)
				{
					goto IL_343;
				}
				num8 = num17;
				num16 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 112 + num8 * 80 + 64 + num2);
				num5 = num16;
				num14 = num5;
				goto IL_369;
				IL_33B:
				num12 = num17 + 1;
				goto IL_2FD;
				IL_343:
				num13 = num17 - 1;
				goto IL_2FD;
				IL_369:
				if (array3 != null)
				{
					goto IL_374;
				}
				goto IL_503;
				IL_374:
				if ((int)array3[1] != 0)
				{
					goto IL_434;
				}
				int num23 = (int)array3[7];
				if (num5 != -1)
				{
					goto IL_398;
				}
				int num24 = -1;
				goto IL_41B;
				IL_398:
				int num25 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num5 + 32 + num2);
				num21 = 0;
				num18 = 2;
				IL_3AC:
				num17 = (num21 + num18) / 2;
				num13 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num17 * 72 + 8 + num2);
				num12 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num17 * 72 + num2);
				if (num25 >= num13 + num12)
				{
					goto IL_3F0;
				}
				if (num13 > num25)
				{
					goto IL_3F8;
				}
				num16 = num17;
				num8 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num16 * 72 + 56 + num2);
				num24 = num8;
				goto IL_41B;
				IL_3F0:
				num21 = num17 + 1;
				goto IL_3AC;
				IL_3F8:
				num18 = num17 - 1;
				goto IL_3AC;
				IL_41B:
				if (num23 != num24)
				{
					goto IL_423;
				}
				goto IL_503;
				IL_423:
				array3 = (object[])array3[0];
				goto IL_369;
				IL_434:
				num15 = (int)array3[5];
				if (num15 == 2 || num15 == 0)
				{
					goto IL_455;
				}
				if (num15 != 1)
				{
					goto IL_454;
				}
				array4 = array3;
				num10 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + (int)array4[7] + 48 + num2);
				goto IL_95;
				IL_454:
				IL_455:
				int num26 = (int)array3[7];
				if (num5 != -1)
				{
					goto IL_46A;
				}
				int num27 = -1;
				goto IL_4ED;
				IL_46A:
				num11 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num5 + 32 + num2);
				num12 = 0;
				num13 = 2;
				IL_47E:
				num17 = (num12 + num13) / 2;
				num18 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num17 * 72 + 8 + num2);
				num21 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num17 * 72 + num2);
				if (num11 >= num18 + num21)
				{
					goto IL_4C2;
				}
				if (num18 > num11)
				{
					goto IL_4CA;
				}
				num8 = num17;
				num16 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + 352 + num8 * 72 + 56 + num2);
				num27 = num16;
				goto IL_4ED;
				IL_4C2:
				num12 = num17 + 1;
				goto IL_47E;
				IL_4CA:
				num13 = num17 - 1;
				goto IL_47E;
				IL_4ED:
				if (num26 != num27)
				{
					goto IL_4F2;
				}
				goto IL_503;
				IL_4F2:
				array3 = (object[])array3[0];
				goto IL_369;
				IL_503:
				if (-1 != num5)
				{
					goto IL_5A9;
				}
				num16 = num14;
				IL_510:
				if (num16 != -1)
				{
					goto IL_51C;
				}
				int num28 = 1;
				throw ex2;
				IL_51C:
				num8 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + 40 + num2);
				if (num8 == -1)
				{
					goto IL_599;
				}
				num25 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num8 + 40 + num2);
				array4 = new object[8];
				array4[1] = 1;
				array4[0] = array3;
				array4[2] = ex2;
				array4[6] = num14;
				array4[7] = -1;
				array4[3] = -1;
				array4[5] = 2;
				array3 = array4;
				num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num8 + 40 + num2);
				goto IL_36;
				IL_599:
				num16 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num16 + num2);
				goto IL_510;
				IL_5A9:
				num9 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num5 + 8 + num2);
				num11 = num9;
				IL_5BA:
				if (num11 != -1)
				{
					goto IL_5CF;
				}
				num5 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num5 + num2);
				goto IL_369;
				IL_5CF:
				num13 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num11 + num2);
				if (0 == num13)
				{
					goto IL_5F6;
				}
				if (1 == num13)
				{
					goto IL_765;
				}
				num5 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num5 + num2);
				goto IL_369;
				IL_5F6:
				num12 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num11 + 56 + num2);
				if (num12 == -1)
				{
					goto IL_643;
				}
				Type type2;
				if ((type2 = array2[num12]) != null)
				{
					goto IL_627;
				}
				array2[num12] = Type.GetTypeFromHandle(array[num12]);
				type2 = array2[num12];
				IL_627:
				if (type2.IsInstanceOfType(ex2))
				{
					goto IL_643;
				}
				num11 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num11 + 48 + num2);
				goto IL_5BA;
				IL_643:
				num25 = num11;
				num21 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num25 + 8 + num2) + num2);
				num18 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
				IL_66A:
				if (num18 != num21)
				{
					goto IL_6D6;
				}
				int num29 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num25 + 40 + num2);
				ex = ex2;
				array4 = new object[8];
				array4[1] = 1;
				array4[0] = array3;
				array4[2] = ex2;
				array4[6] = num14;
				array4[7] = num25;
				array4[5] = 2;
				array3 = array4;
				num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num25 + 40 + num2);
				goto IL_36;
				IL_6D6:
				num17 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num18 + 40 + num2);
				if (num17 == -1)
				{
					goto IL_755;
				}
				num29 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num17 + 40 + num2);
				array4 = new object[8];
				array4[1] = 1;
				array4[0] = array3;
				array4[2] = ex2;
				array4[6] = num14;
				array4[7] = num17;
				array4[3] = num25;
				array4[5] = 0;
				array3 = array4;
				num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num17 + 40 + num2);
				goto IL_36;
				IL_755:
				num18 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num18 + num2);
				goto IL_66A;
				IL_765:
				num29 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num11 + 16 + num2);
				ex = ex2;
				array4 = new object[8];
				array4[1] = 1;
				array4[0] = array3;
				array4[2] = ex2;
				array4[6] = num14;
				array4[7] = num11;
				array4[5] = 1;
				array3 = array4;
				num3 = *(ref CommonProgramFilesgetSecurityRuleSet.ManifestPathWellKnownObjectMode + num11 + 16 + num2);
				goto IL_36;
			}
			catch (Exception ex3)
			{
				int num28;
				if (num28 != 1)
				{
					Exception ex2 = ex3;
					int num22 = -1;
					goto IL_2EE;
				}
				throw ex3;
			}
		}

		// Token: 0x06000237 RID: 567 RVA: 0x00010F3C File Offset: 0x0000F13C
		private static void ClassPropertyWritergetLabel(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			int num = ((A_8 < A_7.Length) ? 1 : 0) * -4 + 13;
			A_0 = num;
		}

		// Token: 0x06000238 RID: 568 RVA: 0x00010F78 File Offset: 0x0000F178
		public static void ClearAllNotifications()
		{
			int num = 29;
			int num2 = 29;
			num2 = 29;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, NotifiLib.InspectableGetAssemblyInformation[num]);
			}
			num2 = 29;
		}

		// Token: 0x06000239 RID: 569 RVA: 0x00010FB0 File Offset: 0x0000F1B0
		private static void LNativeStackRegister(ref int A_0, ref int A_1, ref int A_2)
		{
			NotifiLib.NotifiText.text = "";
			A_1 = 0;
		}

		// Token: 0x0600023A RID: 570 RVA: 0x00010FD8 File Offset: 0x0000F1D8
		private static void SystemAclAutoInheritRequiredPOLICYCREATEPRIVILEGE(ref int A_0, ref int A_1, ref int A_2, ref string A_3, ref string[] A_4, ref int A_5, ref string A_6, ref bool A_7, int A_8)
		{
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -4 + 35;
			A_0 = num2;
		}

		// Token: 0x0600023B RID: 571 RVA: 0x00011038 File Offset: 0x0000F238
		private static void VARFLAGFREADONLYNotFiniteNumberException(ref int A_0, ref int A_1, ref int A_2, ref string A_3, ref string[] A_4, ref int A_5, ref string A_6, ref bool A_7, int A_8)
		{
			string text = A_3 + A_6 + "\n";
			A_3 = text;
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -4 + 35;
			A_0 = num2;
		}

		// Token: 0x0600023C RID: 572 RVA: 0x000110C4 File Offset: 0x0000F2C4
		private static void FieldNamesgetMethodImplementationFlags(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_11.Testtext.text = A_11.newtext;
			A_0 = 16;
		}

		// Token: 0x0600023D RID: 573 RVA: 0x000110F8 File Offset: 0x0000F2F8
		private static void ThreadPoolDequeueWorkGetKeyList(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			string text = A_7 + Environment.NewLine;
			A_7 = text;
			NotifiLib.NotifiText.text = NotifiLib.NotifiText.text + A_7;
			NotifiLib.NotifiText.supportRichText = true;
			NotifiLib.PreviousNotifi = A_7;
			A_1 = 4;
			A_2 = 27;
		}

		// Token: 0x0600023E RID: 574 RVA: 0x00011184 File Offset: 0x0000F384
		private static void getIsGenericMethodIO(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			A_1 = 4;
			A_2 = 27;
		}

		// Token: 0x0600023F RID: 575 RVA: 0x000111A8 File Offset: 0x0000F3A8
		private static void ArgumentInvalidRegistryKeyPermissionCheckDeploymentMetadataMaximumAgeUnit(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			A_11.NotificationDecayTimeCounter = 0;
			A_1 = 0;
		}

		// Token: 0x06000240 RID: 576 RVA: 0x000111D0 File Offset: 0x0000F3D0
		private static void NormalizationFormSorterGenericArray(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			bool flag = NotifiLib.PreviousNotifi != A_7;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 3 + 22;
			A_0 = num;
		}

		// Token: 0x06000241 RID: 577 RVA: 0x00011240 File Offset: 0x0000F440
		private void Init()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				Quaternion quaternion;
				Vector3 vector;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Quaternion&,UnityEngine.Vector3&,StupidTemplate.Notifications.NotifiLib), ref num, ref num2, ref num3, ref quaternion, ref vector, this, NotifiLib.InspectableGetAssemblyInformation[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000242 RID: 578 RVA: 0x00011278 File Offset: 0x0000F478
		private static void BinaryHeaderEnumAllLocalFiles(ref int A_0, ref int A_1, ref int A_2, ref string A_3, ref string[] A_4, ref int A_5, ref string A_6, ref bool A_7, int A_8)
		{
			string text = A_4[A_5];
			A_6 = text;
			bool flag = A_6 != "";
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 32;
			A_0 = num;
		}

		// Token: 0x06000243 RID: 579 RVA: 0x00011308 File Offset: 0x0000F508
		private static void ReadIntAddCustom(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string A_7)
		{
			Debug.LogError("Notification failed, object probably nil due to third person ; " + A_7);
			A_1 = 4;
			A_2 = 27;
		}

		// Token: 0x06000244 RID: 580 RVA: 0x0001134C File Offset: 0x0000F54C
		private static void GetUserStringFileStatusFlags(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref string[] A_7, ref int A_8, ref string A_9, ref bool A_10, NotifiLib A_11)
		{
			bool flag = false;
			A_3 = flag;
			bool flag2 = A_3;
			A_4 = flag2;
			int num = ((!A_4) ? 1 : 0) * 1 + 5;
			A_0 = num;
		}

		// Token: 0x06000245 RID: 581 RVA: 0x000113C4 File Offset: 0x0000F5C4
		public NotifiLib()
		{
			int num = 36;
			int num2 = 36;
			num2 = 36;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Notifications.NotifiLib), ref num, ref num2, ref num3, this, NotifiLib.InspectableGetAssemblyInformation[num]);
			}
			num2 = 36;
		}

		// Token: 0x06000246 RID: 582 RVA: 0x000113FC File Offset: 0x0000F5FC
		private static void AsinDuplicateEvidenceAction()
		{
			NotifiLib.InspectableGetAssemblyInformation = new IntPtr[38];
			NotifiLib.InspectableGetAssemblyInformation[0] = ldftn(SpinLockLetterNumber);
			NotifiLib.InspectableGetAssemblyInformation[1] = ldftn(TryOpenExistingDateTimeFormatInfo);
			NotifiLib.InspectableGetAssemblyInformation[2] = ldftn(ReleaseTLibAttrgetGenerated);
			NotifiLib.InspectableGetAssemblyInformation[3] = ldftn(SymmetricAlgorithmParseDisplayName);
			NotifiLib.InspectableGetAssemblyInformation[4] = ldftn(GetUserStringFileStatusFlags);
			NotifiLib.InspectableGetAssemblyInformation[5] = ldftn(getIsValueCreatedServerAsyncReplyTerminatorSink);
			NotifiLib.InspectableGetAssemblyInformation[6] = ldftn(LastWriteTimeCurrencyNegativePattern);
			NotifiLib.InspectableGetAssemblyInformation[7] = ldftn(StackBehaviourTwoLetterISORegionName);
			NotifiLib.InspectableGetAssemblyInformation[8] = ldftn(getDeclaredFieldsSavePolicy);
			NotifiLib.InspectableGetAssemblyInformation[9] = ldftn(EnumEventsInvalidOperationEnumEnded);
			NotifiLib.InspectableGetAssemblyInformation[10] = ldftn(IsTokenOfTypeIClientFormatterSinkProvider);
			NotifiLib.InspectableGetAssemblyInformation[11] = ldftn(ObjectProgressOutOfMemory);
			NotifiLib.InspectableGetAssemblyInformation[12] = ldftn(ClassPropertyWritergetLabel);
			NotifiLib.InspectableGetAssemblyInformation[13] = ldftn(FieldNamesgetMethodImplementationFlags);
			NotifiLib.InspectableGetAssemblyInformation[14] = ldftn(EnvoyInfoIsError);
			NotifiLib.InspectableGetAssemblyInformation[15] = ldftn(ArgumentInvalidRegistryKeyPermissionCheckDeploymentMetadataMaximumAgeUnit);
			NotifiLib.InspectableGetAssemblyInformation[16] = ldftn(ToBinarygetEncoderFallback);
			NotifiLib.InspectableGetAssemblyInformation[17] = ldftn(getIsFieldReadOnlyDictionaryHelpers);
			NotifiLib.InspectableGetAssemblyInformation[18] = ldftn(AsTypegetStateMachineType);
			NotifiLib.InspectableGetAssemblyInformation[19] = ldftn(TokenRestrictedSidsAssemblyHashAlgorithm);
			NotifiLib.InspectableGetAssemblyInformation[20] = ldftn(NormalizationFormSorterGenericArray);
			NotifiLib.InspectableGetAssemblyInformation[21] = ldftn(PathDiscoveryCLRSurrogateEntry);
			NotifiLib.InspectableGetAssemblyInformation[22] = ldftn(getGenericTypeArgumentsGetArgument);
			NotifiLib.InspectableGetAssemblyInformation[23] = ldftn(ThreadPoolDequeueWorkGetKeyList);
			NotifiLib.InspectableGetAssemblyInformation[24] = ldftn(IsMemberRefPath);
			NotifiLib.InspectableGetAssemblyInformation[25] = ldftn(getIsGenericMethodIO);
			NotifiLib.InspectableGetAssemblyInformation[26] = ldftn(ReadIntAddCustom);
			NotifiLib.InspectableGetAssemblyInformation[27] = ldftn(SetSizePageUp);
			NotifiLib.InspectableGetAssemblyInformation[28] = ldftn(PersonalINVOCATIONFLAGSNEEDSECURITY);
			NotifiLib.InspectableGetAssemblyInformation[29] = ldftn(LNativeStackRegister);
			NotifiLib.InspectableGetAssemblyInformation[30] = ldftn(ConstructorBuilderSetMethodSourceRange);
			NotifiLib.InspectableGetAssemblyInformation[31] = ldftn(BinaryHeaderEnumAllLocalFiles);
			NotifiLib.InspectableGetAssemblyInformation[32] = ldftn(VARFLAGFREADONLYNotFiniteNumberException);
			NotifiLib.InspectableGetAssemblyInformation[33] = ldftn(SystemAclAutoInheritRequiredPOLICYCREATEPRIVILEGE);
			NotifiLib.InspectableGetAssemblyInformation[34] = ldftn(DecoderExceptionFallbackBufferTokenHashValue);
			NotifiLib.InspectableGetAssemblyInformation[35] = ldftn(getIsErrorgetAssemblyReferenceSection);
			NotifiLib.InspectableGetAssemblyInformation[36] = ldftn(getSignatureHour);
			NotifiLib.InspectableGetAssemblyInformation[37] = ldftn(CreateConstructionReturnMessageBuiltinNetworkConfigurationOperatorsSid);
		}

		// Token: 0x0400007D RID: 125
		private GameObject HUDObj;

		// Token: 0x0400007E RID: 126
		private GameObject HUDObj2;

		// Token: 0x0400007F RID: 127
		private GameObject MainCamera;

		// Token: 0x04000080 RID: 128
		private Text Testtext;

		// Token: 0x04000081 RID: 129
		private Material AlertText;

		// Token: 0x04000082 RID: 130
		private int NotificationDecayTime;

		// Token: 0x04000083 RID: 131
		private int NotificationDecayTimeCounter;

		// Token: 0x04000084 RID: 132
		public static int NoticationThreshold;

		// Token: 0x04000085 RID: 133
		private string[] Notifilines;

		// Token: 0x04000086 RID: 134
		private string newtext;

		// Token: 0x04000087 RID: 135
		public static string PreviousNotifi;

		// Token: 0x04000088 RID: 136
		private bool HasInit;

		// Token: 0x04000089 RID: 137
		private static Text NotifiText;

		// Token: 0x0400008A RID: 138
		public static bool IsEnabled;

		// Token: 0x0400008B RID: 139
		private static IntPtr[] InspectableGetAssemblyInformation;
	}
}
