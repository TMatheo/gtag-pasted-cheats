﻿using System;
using StupidTemplate.Classes;
using StupidTemplate.Mods;

namespace StupidTemplate.Menu
{
	// Token: 0x02000034 RID: 52
	internal class Buttons
	{
		// Token: 0x060007A7 RID: 1959 RVA: 0x000492CC File Offset: 0x000474CC
		// Note: this type is marked as 'beforefieldinit'.
		static Buttons()
		{
			Buttons.ReflectionOnlyNetworkServiceSid();
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				ButtonInfo buttonInfo;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.ButtonInfo&), ref num, ref num2, ref num3, ref buttonInfo, Buttons.NullIIDIEnumSTOREASSEMBLYFILE[num]);
			}
			num2 = 1;
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x00049308 File Offset: 0x00047508
		public Buttons()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Menu.Buttons), ref num, ref num2, ref num3, this, Buttons.NullIIDIEnumSTOREASSEMBLYFILE[num]);
			}
			num2 = 0;
		}

		// Token: 0x060007A9 RID: 1961 RVA: 0x0004933C File Offset: 0x0004753C
		private static void CMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGOPTIONALgetStructuralComparer(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo A_3)
		{
			ButtonInfo[][] array = new ButtonInfo[14][];
			array[0] = new ButtonInfo[]
			{
				new ButtonInfo
				{
					buttonText = "Exploits",
					method = delegate()
					{
						int num28 = 2;
						int num29 = 2;
						num29 = 2;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 2;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Miscellaneous",
					method = delegate()
					{
						int num28 = 3;
						int num29 = 3;
						num29 = 3;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 3;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "World",
					method = delegate()
					{
						int num28 = 4;
						int num29 = 4;
						num29 = 4;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 4;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Players",
					method = delegate()
					{
						int num28 = 5;
						int num29 = 5;
						num29 = 5;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 5;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Legit Bot",
					method = delegate()
					{
						int num28 = 6;
						int num29 = 6;
						num29 = 6;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 6;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Visuals",
					method = delegate()
					{
						int num28 = 7;
						int num29 = 7;
						num29 = 7;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 7;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Rage Cheat",
					method = delegate()
					{
						int num28 = 8;
						int num29 = 8;
						num29 = 8;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 8;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Self",
					method = delegate()
					{
						int num28 = 9;
						int num29 = 9;
						num29 = 9;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 9;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Settings",
					method = delegate()
					{
						int num28 = 10;
						int num29 = 10;
						num29 = 10;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 10;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Guardian Cheats",
					method = delegate()
					{
						int num28 = 11;
						int num29 = 11;
						num29 = 11;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 11;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Projectiles",
					method = delegate()
					{
						int num28 = 12;
						int num29 = 12;
						num29 = 12;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 12;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Fun/Random",
					method = delegate()
					{
						int num28 = 13;
						int num29 = 13;
						num29 = 13;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 13;
					},
					isTogglable = false
				}
			};
			array[1] = new ButtonInfo[]
			{
				new ButtonInfo
				{
					buttonText = "Lag All (<color=red>delay ban?</color>)",
					method = delegate()
					{
						int num28 = 14;
						int num29 = 14;
						num29 = 14;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 14;
					},
					toolTip = "Lags everyone"
				},
				new ButtonInfo
				{
					buttonText = "Lag Gun (<color=red>delay ban?</color>)",
					method = delegate()
					{
						int num28 = 15;
						int num29 = 15;
						num29 = 15;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 15;
					},
					toolTip = "Lags whoever you shoot"
				},
				new ButtonInfo
				{
					buttonText = "Set Master (<color=yellow>modded</color>)",
					method = delegate()
					{
						int num28 = 16;
						int num29 = 16;
						num29 = 16;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 16;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Auto-Set Master (<color=yellow>modded</color>)",
					method = delegate()
					{
						int num28 = 17;
						int num29 = 17;
						num29 = 17;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 17;
					},
					toolTip = "Auto give you master"
				},
				new ButtonInfo
				{
					buttonText = "Unlock All Cosmetics (cs)",
					method = delegate()
					{
						int num28 = 18;
						int num29 = 18;
						num29 = 18;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 18;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Max Quest Score",
					method = delegate()
					{
						int num28 = 19;
						int num29 = 19;
						num29 = 19;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 19;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Spaz Quest Score",
					method = delegate()
					{
						int num28 = 20;
						int num29 = 20;
						num29 = 20;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 20;
					},
					toolTip = "Spazs Quest points"
				},
				new ButtonInfo
				{
					buttonText = "Destroy All",
					method = delegate()
					{
						int num28 = 21;
						int num29 = 21;
						num29 = 21;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 21;
					},
					isTogglable = false
				},
				new ButtonInfo
				{
					buttonText = "Destroy Gun",
					method = delegate()
					{
						int num28 = 22;
						int num29 = 22;
						num29 = 22;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 22;
					},
					toolTip = "Destroy whoever you shoot"
				},
				new ButtonInfo
				{
					buttonText = "Slow All",
					method = delegate()
					{
						int num28 = 23;
						int num29 = 23;
						num29 = 23;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 23;
					},
					toolTip = "Give everyone tag freeze"
				},
				new ButtonInfo
				{
					buttonText = "Slow Gun",
					method = delegate()
					{
						int num28 = 24;
						int num29 = 24;
						num29 = 24;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 24;
					},
					toolTip = "Give whovever you shoot tag freeze"
				}
			};
			int num = 2;
			ButtonInfo[] array2 = new ButtonInfo[11];
			array2[0] = new ButtonInfo
			{
				buttonText = "Flush RPCs",
				method = delegate()
				{
					int num28 = 25;
					int num29 = 25;
					num29 = 25;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 25;
				},
				isTogglable = false
			};
			array2[1] = new ButtonInfo
			{
				buttonText = "Disconnect",
				method = delegate()
				{
					int num28 = 26;
					int num29 = 26;
					num29 = 26;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 26;
				},
				isTogglable = false
			};
			array2[2] = new ButtonInfo
			{
				buttonText = "Join Random Room",
				method = delegate()
				{
					int num28 = 27;
					int num29 = 27;
					num29 = 27;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 27;
				},
				isTogglable = false
			};
			array2[3] = new ButtonInfo
			{
				buttonText = "Join Random Private",
				method = delegate()
				{
					int num28 = 28;
					int num29 = 28;
					num29 = 28;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 28;
				},
				isTogglable = false
			};
			array2[4] = new ButtonInfo
			{
				buttonText = "Join Menu Room",
				method = delegate()
				{
					int num28 = 29;
					int num29 = 29;
					num29 = 29;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 29;
				},
				isTogglable = false
			};
			array2[5] = new ButtonInfo
			{
				buttonText = "Lobby Hop",
				method = delegate()
				{
					int num28 = 30;
					int num29 = 30;
					num29 = 30;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 30;
				},
				toolTip = "Disconnects you then joins a random"
			};
			array2[6] = new ButtonInfo
			{
				buttonText = "Anti Report",
				method = delegate()
				{
					int num28 = 31;
					int num29 = 31;
					num29 = 31;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 31;
				},
				enabled = true,
				toolTip = "Get disconnected when someone reports you"
			};
			int num2 = 7;
			ButtonInfo buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Mute All";
			A_3.method = delegate()
			{
				int num28 = 32;
				int num29 = 32;
				num29 = 32;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 32;
			};
			A_3.disableMethod = new Action(Misc.UnMuteAll);
			A_3.toolTip = "Mute everyone";
			array2[num2] = A_3;
			array2[8] = new ButtonInfo
			{
				buttonText = "Report All",
				method = delegate()
				{
					int num28 = 33;
					int num29 = 33;
					num29 = 33;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 33;
				},
				isTogglable = false
			};
			int num3 = 9;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Disable Network Triggers";
			A_3.method = delegate()
			{
				int num28 = 34;
				int num29 = 34;
				num29 = 34;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 34;
			};
			A_3.disableMethod = new Action(Misc.ent);
			A_3.toolTip = "Walk into other maps without getting disconnected";
			array2[num3] = A_3;
			array2[10] = new ButtonInfo
			{
				buttonText = "Unlock Comp",
				method = delegate()
				{
					int num28 = 35;
					int num29 = 35;
					num29 = 35;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 35;
				},
				isTogglable = false
			};
			array[num] = array2;
			array[3] = new ButtonInfo[]
			{
				new ButtonInfo
				{
					buttonText = "Water Bending",
					method = delegate()
					{
						int num28 = 36;
						int num29 = 36;
						num29 = 36;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 36;
					},
					toolTip = "Grips to splash Water SS"
				},
				new ButtonInfo
				{
					buttonText = "Water Gun",
					method = delegate()
					{
						int num28 = 37;
						int num29 = 37;
						num29 = 37;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 37;
					},
					toolTip = "Splash Water SS on wherever you shoot"
				},
				new ButtonInfo
				{
					buttonText = "Glider Grab",
					method = delegate()
					{
						int num28 = 38;
						int num29 = 38;
						num29 = 38;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 38;
					},
					toolTip = "Grab all gliders in clouds SS"
				},
				new ButtonInfo
				{
					buttonText = "Gliders To Gun",
					method = delegate()
					{
						int num28 = 39;
						int num29 = 39;
						num29 = 39;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 39;
					},
					toolTip = "All gliders in clouds to the gun SS"
				},
				new ButtonInfo
				{
					buttonText = "Glider Spazoid",
					method = delegate()
					{
						int num28 = 40;
						int num29 = 40;
						num29 = 40;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 40;
					},
					toolTip = "Spaz all the gliders in clouds SS"
				}
			};
			array[4] = new ButtonInfo[]
			{
				new ButtonInfo
				{
					buttonText = "Pull Info Gun (Copys To Clipboard + Unity Log)",
					method = delegate()
					{
						int num28 = 41;
						int num29 = 41;
						num29 = 41;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 41;
					},
					toolTip = "Click Ctrl V to see someones info"
				}
			};
			int num4 = 5;
			ButtonInfo[] array3 = new ButtonInfo[6];
			int num5 = 0;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Mosa Booster";
			A_3.method = delegate()
			{
				int num28 = 42;
				int num29 = 42;
				num29 = 42;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 42;
			};
			A_3.disableMethod = new Action(Self.DisableSpeedBoost);
			A_3.toolTip = "Small Speedboost";
			array3[num5] = A_3;
			int num6 = 1;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Steam Arms";
			A_3.method = delegate()
			{
				int num28 = 43;
				int num29 = 43;
				num29 = 43;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 43;
			};
			A_3.disableMethod = new Action(Self.ResetArms);
			A_3.toolTip = "Small long arms";
			array3[num6] = A_3;
			array3[2] = new ButtonInfo
			{
				buttonText = "Low HZ",
				method = delegate()
				{
					int num28 = 44;
					int num29 = 44;
					num29 = 44;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 44;
				},
				toolTip = "Super low FPS"
			};
			int num7 = 3;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Slide Control";
			A_3.method = delegate()
			{
				int num28 = 45;
				int num29 = 45;
				num29 = 45;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 45;
			};
			A_3.disableMethod = new Action(LegitBot.ResetSlideControl);
			A_3.toolTip = "More control on slippery surfaces such as ice";
			array3[num7] = A_3;
			array3[4] = new ButtonInfo
			{
				buttonText = "No Slippery",
				method = delegate()
				{
					int num28 = 46;
					int num29 = 46;
					num29 = 46;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 46;
				},
				toolTip = "Only disables the forest slippery walls for now"
			};
			array3[5] = new ButtonInfo
			{
				buttonText = "Disable Wind Barriers",
				method = delegate()
				{
					int num28 = 47;
					int num29 = 47;
					num29 = 47;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 47;
				},
				toolTip = "Don't think this works :("
			};
			array[num4] = array3;
			int num8 = 6;
			ButtonInfo[] array4 = new ButtonInfo[17];
			int num9 = 0;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Cham ESP";
			A_3.method = delegate()
			{
				int num28 = 48;
				int num29 = 48;
				num29 = 48;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 48;
			};
			A_3.disableMethod = new Action(Visual.ResetChams);
			A_3.toolTip = "Highlights players";
			array4[num9] = A_3;
			array4[1] = new ButtonInfo
			{
				buttonText = "Box ESP",
				method = delegate()
				{
					int num28 = 49;
					int num29 = 49;
					num29 = 49;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 49;
				},
				toolTip = "Highlights Boxes on players"
			};
			array4[2] = new ButtonInfo
			{
				buttonText = "Filled Box ESP",
				method = delegate()
				{
					int num28 = 50;
					int num29 = 50;
					num29 = 50;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 50;
				},
				toolTip = "Highlights Filled Boxes on players"
			};
			array4[3] = new ButtonInfo
			{
				buttonText = "Tracer ESP",
				method = delegate()
				{
					int num28 = 51;
					int num29 = 51;
					num29 = 51;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 51;
				},
				toolTip = "Highlights Lines to players"
			};
			array4[4] = new ButtonInfo
			{
				buttonText = "Line ESP",
				method = delegate()
				{
					int num28 = 52;
					int num29 = 52;
					num29 = 52;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 52;
				},
				toolTip = "Highlights Lines on players"
			};
			array4[5] = new ButtonInfo
			{
				buttonText = "Beacon ESP",
				method = delegate()
				{
					int num28 = 53;
					int num29 = 53;
					num29 = 53;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 53;
				},
				toolTip = "Highlights Beacons on players"
			};
			array4[6] = new ButtonInfo
			{
				buttonText = "Beacon Lines ESP",
				method = delegate()
				{
					int num28 = 54;
					int num29 = 54;
					num29 = 54;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 54;
				},
				toolTip = "Highlights Lines on players"
			};
			array4[7] = new ButtonInfo
			{
				buttonText = "Skeleton ESP",
				method = delegate()
				{
					int num28 = 55;
					int num29 = 55;
					num29 = 55;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 55;
				},
				toolTip = "Highlights Bones on players"
			};
			array4[8] = new ButtonInfo
			{
				buttonText = "Skeleton ESP Self",
				method = delegate()
				{
					int num28 = 56;
					int num29 = 56;
					num29 = 56;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 56;
				},
				toolTip = "Highlights Bones on Self"
			};
			int num10 = 9;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Bread Crumbs ESP";
			A_3.method = delegate()
			{
				int num28 = 57;
				int num29 = 57;
				num29 = 57;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 57;
			};
			A_3.disableMethod = new Action(Visual.DisableBreadCrumbs);
			A_3.toolTip = "Highlights Trails on players";
			array4[num10] = A_3;
			array4[10] = new ButtonInfo
			{
				buttonText = "Limb ESP",
				method = delegate()
				{
					int num28 = 58;
					int num29 = 58;
					num29 = 58;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 58;
				},
				toolTip = "Highlights Limbs on players"
			};
			array4[11] = new ButtonInfo
			{
				buttonText = "Nametag ESP",
				method = delegate()
				{
					int num28 = 59;
					int num29 = 59;
					num29 = 59;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 59;
				},
				toolTip = "Highlights Names on players"
			};
			array4[12] = new ButtonInfo
			{
				buttonText = "Sphere ESP",
				method = delegate()
				{
					int num28 = 60;
					int num29 = 60;
					num29 = 60;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 60;
				},
				toolTip = "Highlights Sphere on players"
			};
			array4[13] = new ButtonInfo
			{
				buttonText = "Sphere 3D ESP",
				method = delegate()
				{
					int num28 = 61;
					int num29 = 61;
					num29 = 61;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 61;
				},
				toolTip = "Highlights 3D Spheres on players"
			};
			array4[14] = new ButtonInfo
			{
				buttonText = "Capsule ESP",
				method = delegate()
				{
					int num28 = 62;
					int num29 = 62;
					num29 = 62;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 62;
				},
				toolTip = "Highlights Capsules on players"
			};
			array4[15] = new ButtonInfo
			{
				buttonText = "Capsule 3D ESP",
				method = delegate()
				{
					int num28 = 63;
					int num29 = 63;
					num29 = 63;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 63;
				},
				toolTip = "Highlights 3D Capsules on players"
			};
			int num11 = 16;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Low GFX";
			A_3.method = delegate()
			{
				int num28 = 64;
				int num29 = 64;
				num29 = 64;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 64;
			};
			A_3.disableMethod = new Action(Visual.nolow);
			A_3.toolTip = "Lower graphics";
			array4[num11] = A_3;
			array[num8] = array4;
			int num12 = 7;
			ButtonInfo[] array5 = new ButtonInfo[8];
			array5[0] = new ButtonInfo
			{
				buttonText = "Tag Gun",
				method = delegate()
				{
					int num28 = 65;
					int num29 = 65;
					num29 = 65;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 65;
				},
				toolTip = "Tag whoever you shoot"
			};
			int num13 = 1;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Tag All";
			A_3.method = delegate()
			{
				int num28 = 66;
				int num29 = 66;
				num29 = 66;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 66;
			};
			A_3.disableMethod = new Action(Tag.FixThisStupidBugOmg);
			A_3.toolTip = "Tags everyone";
			array5[num13] = A_3;
			array5[2] = new ButtonInfo
			{
				buttonText = "Tag Aura",
				method = delegate()
				{
					int num28 = 67;
					int num29 = 67;
					num29 = 67;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 67;
				},
				toolTip = "Hold grip to tag anyone around you"
			};
			int num14 = 3;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Tag Self";
			A_3.method = delegate()
			{
				int num28 = 68;
				int num29 = 68;
				num29 = 68;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 68;
			};
			A_3.disableMethod = new Action(Tag.FixThisStupidBugOmg);
			A_3.toolTip = "Tag yourself";
			array5[num14] = A_3;
			array5[4] = new ButtonInfo
			{
				buttonText = "Anti Tag",
				method = delegate()
				{
					int num28 = 69;
					int num29 = 69;
					num29 = 69;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 69;
				},
				toolTip = "Can't get tagged"
			};
			array5[5] = new ButtonInfo
			{
				buttonText = "Anti-Tag Freeze",
				method = delegate()
				{
					int num28 = 70;
					int num29 = 70;
					num29 = 70;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 70;
				},
				toolTip = "Disable tag freeze effect"
			};
			int num15 = 6;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Rage Tag All (<color=red>d?</color>)";
			A_3.method = delegate()
			{
				int num28 = 71;
				int num29 = 71;
				num29 = 71;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 71;
			};
			A_3.disableMethod = new Action(Tag.FixThisStupidBugOmg);
			A_3.toolTip = "Tag everyone faster and just differently";
			array5[num15] = A_3;
			int num16 = 7;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Spin Bot";
			A_3.method = delegate()
			{
				int num28 = 72;
				int num29 = 72;
				num29 = 72;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 72;
			};
			A_3.disableMethod = new Action(Tag.FixThisStupidBugOmg);
			A_3.toolTip = "Spin yourself";
			array5[num16] = A_3;
			array[num12] = array5;
			int num17 = 8;
			ButtonInfo[] array6 = new ButtonInfo[28];
			array6[0] = new ButtonInfo
			{
				buttonText = "Platforms",
				method = delegate()
				{
					int num28 = 73;
					int num29 = 73;
					num29 = 73;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 73;
				},
				toolTip = "Spawn platforms under your hands"
			};
			int num18 = 1;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Speed Boost";
			A_3.method = delegate()
			{
				int num28 = 74;
				int num29 = 74;
				num29 = 74;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 74;
			};
			A_3.disableMethod = new Action(Self.DisableSpeedBoost);
			A_3.toolTip = "Boosts your speed";
			array6[num18] = A_3;
			int num19 = 2;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Long Arms";
			A_3.method = delegate()
			{
				int num28 = 75;
				int num29 = 75;
				num29 = 75;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 75;
			};
			A_3.disableMethod = new Action(Self.ResetArms);
			A_3.toolTip = "Longer arms";
			array6[num19] = A_3;
			array6[3] = new ButtonInfo
			{
				buttonText = "Fly",
				method = delegate()
				{
					int num28 = 76;
					int num29 = 76;
					num29 = 76;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 76;
				},
				toolTip = "Fly with trigger"
			};
			array6[4] = new ButtonInfo
			{
				buttonText = "Super Monkey",
				method = delegate()
				{
					int num28 = 77;
					int num29 = 77;
					num29 = 77;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 77;
				},
				toolTip = "B to fly, A to toggle zero gravity"
			};
			array6[5] = new ButtonInfo
			{
				buttonText = "Vel Fly",
				method = delegate()
				{
					int num28 = 78;
					int num29 = 78;
					num29 = 78;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 78;
				},
				toolTip = "Fly with velocity"
			};
			array6[6] = new ButtonInfo
			{
				buttonText = "Noclip",
				method = delegate()
				{
					int num28 = 79;
					int num29 = 79;
					num29 = 79;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 79;
				},
				toolTip = "Disable all colliders with A"
			};
			array6[7] = new ButtonInfo
			{
				buttonText = "BHop",
				method = delegate()
				{
					int num28 = 80;
					int num29 = 80;
					num29 = 80;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 80;
				},
				toolTip = "BHop like in CS:GO"
			};
			array6[8] = new ButtonInfo
			{
				buttonText = "No Grav",
				method = delegate()
				{
					int num28 = 81;
					int num29 = 81;
					num29 = 81;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 81;
				},
				toolTip = "I'm in space!"
			};
			array6[9] = new ButtonInfo
			{
				buttonText = "High Grav",
				method = delegate()
				{
					int num28 = 82;
					int num29 = 82;
					num29 = 82;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 82;
				},
				toolTip = "I'm on jupiter!"
			};
			array6[10] = new ButtonInfo
			{
				buttonText = "Reverse Grav",
				method = delegate()
				{
					int num28 = 83;
					int num29 = 83;
					num29 = 83;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 83;
				},
				toolTip = "What's happening!?"
			};
			array6[11] = new ButtonInfo
			{
				buttonText = "Joystick Fly",
				method = delegate()
				{
					int num28 = 84;
					int num29 = 84;
					num29 = 84;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 84;
				},
				toolTip = "I Don't know how to explain this"
			};
			int num20 = 12;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Free-Cam";
			A_3.method = delegate()
			{
				int num28 = 85;
				int num29 = 85;
				num29 = 85;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 85;
			};
			A_3.disableMethod = new Action(Self.FixRIIIIIIIIIIIIIIIIIIIIIII);
			A_3.toolTip = "I Don't know how to explain this";
			array6[num20] = A_3;
			array6[13] = new ButtonInfo
			{
				buttonText = "Grab Self",
				method = delegate()
				{
					int num28 = 86;
					int num29 = 86;
					num29 = 86;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 86;
				},
				toolTip = "Grab your rig with grip"
			};
			array6[14] = new ButtonInfo
			{
				buttonText = "Wall Walk",
				method = delegate()
				{
					int num28 = 87;
					int num29 = 87;
					num29 = 87;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 87;
				},
				toolTip = "Suck into wall using right grip"
			};
			array6[15] = new ButtonInfo
			{
				buttonText = "Rig Gun",
				method = delegate()
				{
					int num28 = 88;
					int num29 = 88;
					num29 = 88;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 88;
				},
				toolTip = "Put your rig to the gun pointer"
			};
			array6[16] = new ButtonInfo
			{
				buttonText = "Iron Monkey",
				method = delegate()
				{
					int num28 = 89;
					int num29 = 89;
					num29 = 89;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 89;
				},
				toolTip = "Grips for thrusters under your hands"
			};
			array6[17] = new ButtonInfo
			{
				buttonText = "Tp Gun",
				method = delegate()
				{
					int num28 = 90;
					int num29 = 90;
					num29 = 90;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 90;
				},
				toolTip = "Teleport to the pointer"
			};
			array6[18] = new ButtonInfo
			{
				buttonText = "Copy Gun",
				method = delegate()
				{
					int num28 = 91;
					int num29 = 91;
					num29 = 91;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 91;
				},
				toolTip = "Copy someones movement"
			};
			array6[19] = new ButtonInfo
			{
				buttonText = "Ghost Rig",
				method = delegate()
				{
					int num28 = 92;
					int num29 = 92;
					num29 = 92;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 92;
				},
				toolTip = "Toggle rig on and off with RT"
			};
			array6[20] = new ButtonInfo
			{
				buttonText = "Invis Rig",
				method = delegate()
				{
					int num28 = 93;
					int num29 = 93;
					num29 = 93;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 93;
				},
				toolTip = "Dissapear on and off with RT"
			};
			array6[21] = new ButtonInfo
			{
				buttonText = "Arms Gun",
				method = delegate()
				{
					int num28 = 94;
					int num29 = 94;
					num29 = 94;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 94;
				},
				toolTip = "Hands to the pointer"
			};
			array6[22] = new ButtonInfo
			{
				buttonText = "Aimbot Gun",
				method = delegate()
				{
					int num28 = 95;
					int num29 = 95;
					num29 = 95;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 95;
				},
				toolTip = "Torso to the player IDRK"
			};
			array6[23] = new ButtonInfo
			{
				buttonText = "Spazoid",
				method = delegate()
				{
					int num28 = 96;
					int num29 = 96;
					num29 = 96;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 96;
				},
				toolTip = "Spaz"
			};
			array6[24] = new ButtonInfo
			{
				buttonText = "Giant",
				method = delegate()
				{
					int num28 = 97;
					int num29 = 97;
					num29 = 97;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 97;
				},
				toolTip = "Gronk"
			};
			array6[25] = new ButtonInfo
			{
				buttonText = "Tiny",
				method = delegate()
				{
					int num28 = 98;
					int num29 = 98;
					num29 = 98;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 98;
				},
				toolTip = "Ant!"
			};
			int num21 = 26;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Become Bees Ghost";
			A_3.method = delegate()
			{
				int num28 = 99;
				int num29 = 99;
				num29 = 99;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 99;
			};
			A_3.disableMethod = new Action(Tag.FixThisStupidBugOmg);
			A_3.toolTip = "Tp rig to random players";
			array6[num21] = A_3;
			array6[27] = new ButtonInfo
			{
				buttonText = "Go To Shadow Relm",
				method = delegate()
				{
					int num28 = 100;
					int num29 = 100;
					num29 = 100;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 100;
				},
				toolTip = "You're Fucked"
			};
			array[num17] = array6;
			int num22 = 9;
			ButtonInfo[] array7 = new ButtonInfo[8];
			int num23 = 0;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Menu Side Bar";
			A_3.method = delegate()
			{
				int num28 = 101;
				int num29 = 101;
				num29 = 101;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 101;
			};
			A_3.disableMethod = new Action(SettingsMods.SideBarOff);
			A_3.enabled = true;
			A_3.toolTip = "Toggle the side bar";
			array7[num23] = A_3;
			int num24 = 1;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Menu Outline";
			A_3.method = delegate()
			{
				int num28 = 102;
				int num29 = 102;
				num29 = 102;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 102;
			};
			A_3.disableMethod = new Action(SettingsMods.NoMenuOutline);
			A_3.enabled = true;
			A_3.toolTip = "Outlines The Menu";
			array7[num24] = A_3;
			int num25 = 2;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Infections Visuals";
			A_3.method = delegate()
			{
				int num28 = 103;
				int num29 = 103;
				num29 = 103;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 103;
			};
			A_3.disableMethod = new Action(SettingsMods.DisableInfectionVisuals);
			A_3.toolTip = "Makes visual so green people are untagged and red people are tagged";
			array7[num25] = A_3;
			array7[3] = new ButtonInfo
			{
				buttonText = "Clear/No Notifs",
				method = delegate()
				{
					int num28 = 104;
					int num29 = 104;
					num29 = 104;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 104;
				},
				toolTip = "Disable me D:"
			};
			array7[4] = new ButtonInfo
			{
				buttonText = "CS",
				overlapText = "Color Scheme: Defualt",
				method = delegate()
				{
					int num28 = 105;
					int num29 = 105;
					num29 = 105;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 105;
				},
				isTogglable = false
			};
			array7[5] = new ButtonInfo
			{
				buttonText = "CBS",
				overlapText = "Toggle Sound: Smooth",
				method = delegate()
				{
					int num28 = 106;
					int num29 = 106;
					num29 = 106;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 106;
				},
				isTogglable = false
			};
			array7[6] = new ButtonInfo
			{
				buttonText = "DB",
				overlapText = "Disconnect Button: Enabled",
				method = delegate()
				{
					int num28 = 107;
					int num29 = 107;
					num29 = 107;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 107;
				},
				isTogglable = false
			};
			array7[7] = new ButtonInfo
			{
				buttonText = "TOD",
				overlapText = "Time Of Day: Untouched",
				method = delegate()
				{
					int num28 = 108;
					int num29 = 108;
					num29 = 108;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 108;
				},
				isTogglable = false
			};
			array[num22] = array7;
			int num26 = 10;
			ButtonInfo[] array8 = new ButtonInfo[9];
			int num27 = 0;
			buttonInfo = new ButtonInfo();
			A_3 = buttonInfo;
			A_3.buttonText = "Get Guardian";
			A_3.method = delegate()
			{
				int num28 = 109;
				int num29 = 109;
				num29 = 109;
				while (num29 != 0)
				{
					int num30;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
				}
				num29 = 109;
			};
			A_3.disableMethod = new Action(Tag.FixThisStupidBugOmg);
			A_3.toolTip = "Become Guardian";
			array8[num27] = A_3;
			array8[1] = new ButtonInfo
			{
				buttonText = "Grab All",
				method = delegate()
				{
					int num28 = 110;
					int num29 = 110;
					num29 = 110;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 110;
				},
				toolTip = "Grab everyone"
			};
			array8[2] = new ButtonInfo
			{
				buttonText = "Grab Gun",
				method = delegate()
				{
					int num28 = 111;
					int num29 = 111;
					num29 = 111;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 111;
				},
				toolTip = "Grab player"
			};
			array8[3] = new ButtonInfo
			{
				buttonText = "Fling All",
				method = delegate()
				{
					int num28 = 112;
					int num29 = 112;
					num29 = 112;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 112;
				},
				toolTip = "Fling everyone"
			};
			array8[4] = new ButtonInfo
			{
				buttonText = "Fling Gun",
				method = delegate()
				{
					int num28 = 113;
					int num29 = 113;
					num29 = 113;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 113;
				},
				toolTip = "Fling player"
			};
			array8[5] = new ButtonInfo
			{
				buttonText = "Quit App All",
				method = delegate()
				{
					int num28 = 114;
					int num29 = 114;
					num29 = 114;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 114;
				},
				toolTip = "Quit everyones game"
			};
			array8[6] = new ButtonInfo
			{
				buttonText = "Quit App Gun",
				method = delegate()
				{
					int num28 = 115;
					int num29 = 115;
					num29 = 115;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 115;
				},
				toolTip = "Quit players game"
			};
			array8[7] = new ButtonInfo
			{
				buttonText = "Break Movement All",
				method = delegate()
				{
					int num28 = 116;
					int num29 = 116;
					num29 = 116;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 116;
				},
				toolTip = "Break everyones movement"
			};
			array8[8] = new ButtonInfo
			{
				buttonText = "Break Movement Gun",
				method = delegate()
				{
					int num28 = 117;
					int num29 = 117;
					num29 = 117;
					while (num29 != 0)
					{
						int num30;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
					}
					num29 = 117;
				},
				toolTip = "Break players movement"
			};
			array[num26] = array8;
			array[11] = new ButtonInfo[]
			{
				new ButtonInfo
				{
					buttonText = "Snowball Spammer (cs)",
					method = delegate()
					{
						int num28 = 118;
						int num29 = 118;
						num29 = 118;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 118;
					},
					toolTip = "Spam snowballs with grip"
				},
				new ButtonInfo
				{
					buttonText = "Waterballoon Spammer (cs)",
					method = delegate()
					{
						int num28 = 119;
						int num29 = 119;
						num29 = 119;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 119;
					},
					toolTip = "Spam Waterballoons with grip"
				},
				new ButtonInfo
				{
					buttonText = "Ice Spammer (cs)",
					method = delegate()
					{
						int num28 = 120;
						int num29 = 120;
						num29 = 120;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 120;
					},
					toolTip = "Spam ice with grip"
				},
				new ButtonInfo
				{
					buttonText = "Snowball Gun (cs)",
					method = delegate()
					{
						int num28 = 121;
						int num29 = 121;
						num29 = 121;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 121;
					},
					toolTip = "Spam snowballs with gun"
				},
				new ButtonInfo
				{
					buttonText = "Waterballoon Gun (cs)",
					method = delegate()
					{
						int num28 = 122;
						int num29 = 122;
						num29 = 122;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 122;
					},
					toolTip = "Spam Balloons with gun"
				},
				new ButtonInfo
				{
					buttonText = "Ice Gun (cs)",
					method = delegate()
					{
						int num28 = 123;
						int num29 = 123;
						num29 = 123;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 123;
					},
					toolTip = "Spam ice with gun"
				},
				new ButtonInfo
				{
					buttonText = "Impact Player Gun (SS)",
					method = delegate()
					{
						int num28 = 124;
						int num29 = 124;
						num29 = 124;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 124;
					},
					toolTip = "Spam impacts on player with gun"
				}
			};
			array[12] = new ButtonInfo[0];
			array[13] = new ButtonInfo[]
			{
				new ButtonInfo
				{
					buttonText = "ExitCat",
					method = delegate()
					{
						int num28 = 125;
						int num29 = 125;
						num29 = 125;
						while (num29 != 0)
						{
							int num30;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num28, ref num29, ref num30, Buttons.<>c.HeaderVersionNumberIEnumConnectionPoints[num28]);
						}
						num29 = 125;
					},
					isTogglable = false
				}
			};
			Buttons.buttons = array;
			A_1 = 0;
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x0004B5C0 File Offset: 0x000497C0
		private static void threadLocalsGetObjectForIUnknown(ref int A_0, ref int A_1, ref int A_2, Buttons A_3)
		{
			A_3..ctor();
			A_1 = 2;
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x0004B5E4 File Offset: 0x000497E4
		private static void ReflectionOnlyNetworkServiceSid()
		{
			Buttons.NullIIDIEnumSTOREASSEMBLYFILE = new IntPtr[2];
			Buttons.NullIIDIEnumSTOREASSEMBLYFILE[0] = ldftn(threadLocalsGetObjectForIUnknown);
			Buttons.NullIIDIEnumSTOREASSEMBLYFILE[1] = ldftn(CMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGOPTIONALgetStructuralComparer);
		}

		// Token: 0x040000E2 RID: 226
		public static ButtonInfo[][] buttons;

		// Token: 0x040000E3 RID: 227
		private static IntPtr[] NullIIDIEnumSTOREASSEMBLYFILE;
	}
}
