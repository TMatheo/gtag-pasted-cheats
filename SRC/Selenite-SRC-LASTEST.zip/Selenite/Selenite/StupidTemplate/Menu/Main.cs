﻿using System;
using System.Linq;
using BepInEx;
using GorillaLocomotion;
using HarmonyLib;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Notifications;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace StupidTemplate.Menu
{
	// Token: 0x02000039 RID: 57
	[HarmonyPatch(typeof(GTPlayer))]
	[HarmonyPatch("LateUpdate", 0)]
	public class Main : MonoBehaviour
	{
		// Token: 0x06000909 RID: 2313 RVA: 0x000515C8 File Offset: 0x0004F7C8
		private static void DisposeHashElementDigestMethod(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = Main.trailMenu;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 11;
			A_0 = num;
		}

		// Token: 0x0600090A RID: 2314 RVA: 0x00051624 File Offset: 0x0004F824
		private static void SecurityAssertCollectFromClientContext(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			NotifiLib.SendNotification("[<color=green>Enabled</color>]: " + A_9.buttonText + ": " + A_9.toolTip);
			bool flag = A_9.enableMethod != null;
			A_13 = flag;
			int num = ((!A_13) ? 1 : 0) * 4 + 148;
			A_0 = num;
		}

		// Token: 0x0600090B RID: 2315 RVA: 0x000516C0 File Offset: 0x0004F8C0
		private static void StrongNameKeyGenEventChannelAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdtext").GetComponent<TMP_Text>().color = Color.white;
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdtext").GetComponent<TMP_Text>().text = "Welcome to the BEST free cheat client, Selenite!\n\n<color=green>[ Credits ]</color>\n<color=yellow>Zenkizs</color> [ Permission for menu layout, Lag Mods ]\n\n\n<color=red>[ DISCLAIMER ]</color>\nBy using the \"Selenite\" product, you acknowledge and agree that you do so at your own risk. You accept full responsibility for any consequences that may arise from its use, including, but not limited to, account suspension or permanent bans. The creators, developers, and distributors of Selenite are not liable for any actions taken against your accounts.";
			bool flag = Settings.stupidpoo == 1;
			A_31 = flag;
			int num = ((!A_31) ? 1 : 0) * 3 + 49;
			A_0 = num;
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x00051758 File Offset: 0x0004F958
		private static void CheckedForAsyncIDefinitionAppId(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			Ray ray = Main.TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
			A_13 = ray;
			bool flag = Physics.Raycast(A_13, ref A_14, 100f);
			A_15 = flag;
			bool flag2 = A_15;
			A_16 = flag2;
			int num = ((!A_16) ? 1 : 0) * 3 + 123;
			A_0 = num;
		}

		// Token: 0x0600090D RID: 2317 RVA: 0x00051810 File Offset: 0x0004FA10
		private static void BleUnsetAsR(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = true;
			A_4 = flag;
			bool key = UnityInput.Current.GetKey(113);
			A_5 = key;
			bool flag2 = Main.menu == null;
			A_6 = flag2;
			int num = ((!A_6) ? 1 : 0) * 7 + 7;
			A_0 = num;
		}

		// Token: 0x0600090E RID: 2318 RVA: 0x000518A8 File Offset: 0x0004FAA8
		private static GradientColorKey[] TextToReferencegetRefusedSet(ref int A_0, ref int A_1, ref int A_2, ref GradientColorKey[] A_3, Color A_4)
		{
			GradientColorKey[] result = A_3;
			A_1 = 0;
			return result;
		}

		// Token: 0x0600090F RID: 2319 RVA: 0x000518C8 File Offset: 0x0004FAC8
		public unsafe static void Prefix()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 0;
			int num4 = 0;
			num4 = 0;
			try
			{
				IL_17:
				int num5;
				int num8;
				int num9;
				int num10;
				int num11;
				int num12;
				int num13;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				object[] array;
				int num21;
				object[] array2;
				Exception ex;
				while (num4 != 56)
				{
					if (num4 == 60)
					{
						num4 = 0;
						int num6;
						num5 = num6;
						int num7 = num5;
						num8 = num3;
						num9 = num8;
						num5 = 0;
						num10 = 6;
						for (;;)
						{
							num11 = (num5 + num10) / 2;
							num12 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num11 * 80 + num2);
							num13 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num11 * 80 + 64 + num2);
							if (num9 < num12 + num13)
							{
								if (num12 <= num9)
								{
									break;
								}
								num10 = num11 - 1;
							}
							else
							{
								num5 = num11 + 1;
							}
						}
						num14 = num11;
						num15 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num14 * 80 + 72 + num2);
						num16 = num15;
						num13 = num7;
						num12 = 0;
						num11 = 6;
						for (;;)
						{
							num10 = (num12 + num11) / 2;
							num5 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num10 * 80 + num2);
							num9 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num10 * 80 + 64 + num2);
							if (num13 < num5 + num9)
							{
								if (num5 <= num13)
								{
									break;
								}
								num11 = num10 - 1;
							}
							else
							{
								num12 = num10 + 1;
							}
						}
						num14 = num10;
						num17 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num14 * 80 + 72 + num2);
						num15 = num17;
						num9 = num7;
						num5 = 0;
						num10 = 6;
						for (;;)
						{
							num11 = (num5 + num10) / 2;
							num12 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num11 * 80 + num2);
							num13 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num11 * 80 + 64 + num2);
							if (num9 < num12 + num13)
							{
								if (num12 <= num9)
								{
									break;
								}
								num10 = num11 - 1;
							}
							else
							{
								num5 = num11 + 1;
							}
						}
						num14 = num11;
						num18 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num14 * 80 + 72 + num2);
						num17 = num18;
						for (;;)
						{
							IL_929:
							if (array == null || (int)array[0] == 0)
							{
								num9 = num15;
								while (num9 != num16)
								{
									if (num9 != -1)
									{
										num9 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num9 + num2);
									}
									else
									{
										num5 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + 32 + num2);
										if (num5 != -1)
										{
											goto Block_56;
										}
										num16 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + num2);
										goto IL_929;
									}
								}
								goto IL_ABB;
							}
							int num19 = (int)array[7];
							int num20;
							if (num16 == -1)
							{
								num20 = -1;
							}
							else
							{
								num21 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + 24 + num2);
								num13 = 0;
								num12 = 6;
								for (;;)
								{
									num11 = (num13 + num12) / 2;
									num10 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num11 * 80 + num2);
									num5 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num11 * 80 + 64 + num2);
									if (num21 < num10 + num5)
									{
										if (num10 <= num21)
										{
											break;
										}
										num12 = num11 - 1;
									}
									else
									{
										num13 = num11 + 1;
									}
								}
								num18 = num11;
								num14 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num18 * 80 + 72 + num2);
								num20 = num14;
							}
							if (num19 == num20)
							{
								num14 = num15;
								while (num14 != num16)
								{
									if (num14 != -1)
									{
										num14 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num14 + num2);
									}
									else
									{
										num18 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + 32 + num2);
										if (num18 != -1)
										{
											goto Block_52;
										}
										num16 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + num2);
										goto IL_929;
									}
								}
								break;
							}
							if ((int)array[7] == num17)
							{
								goto Block_53;
							}
							array = (object[])array[6];
						}
						num3 = num7;
						continue;
						Block_52:
						num9 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num18 + 64 + num2);
						array2 = new object[8];
						array2[0] = 0;
						array2[6] = array;
						array2[4] = num7;
						array2[7] = num18;
						array2[5] = 0;
						array = array2;
						num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num18 + 64 + num2);
						continue;
						Block_53:
						num3 = num7;
						continue;
						IL_ABB:
						num3 = num7;
						continue;
						Block_56:
						num10 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num5 + 64 + num2);
						array2 = new object[8];
						array2[0] = 0;
						array2[6] = array;
						array2[4] = num7;
						array2[7] = num5;
						array2[5] = 0;
						array = array2;
						num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num5 + 64 + num2);
					}
					else
					{
						int num6;
						bool flag;
						bool flag2;
						bool flag3;
						bool flag4;
						bool flag5;
						bool flag6;
						TrailRenderer trailRenderer;
						bool flag7;
						bool flag8;
						Exception ex2;
						bool flag9;
						DateTime dateTime;
						ButtonInfo[][] array3;
						int num22;
						ButtonInfo[] array4;
						ButtonInfo[] array5;
						int num23;
						ButtonInfo buttonInfo;
						bool flag10;
						bool flag11;
						Exception ex3;
						Exception ex4;
						bool flag12;
						float num24;
						bool flag13;
						bool flag14;
						bool flag15;
						bool flag16;
						bool flag17;
						bool flag18;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,UnityEngine.TrailRenderer&,System.Boolean&,System.Boolean&,System.Exception&,System.Boolean&,System.DateTime&,StupidTemplate.Classes.ButtonInfo[][]&,System.Int32&,StupidTemplate.Classes.ButtonInfo[]&,StupidTemplate.Classes.ButtonInfo[]&,System.Int32&,StupidTemplate.Classes.ButtonInfo&,System.Boolean&,System.Boolean&,System.Exception&,System.Exception&,System.Boolean&,System.Single&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num3, ref num4, ref num6, ex, ref flag, ref flag2, ref flag3, ref flag4, ref flag5, ref flag6, ref trailRenderer, ref flag7, ref flag8, ref ex2, ref flag9, ref dateTime, ref array3, ref num22, ref array4, ref array5, ref num23, ref buttonInfo, ref flag10, ref flag11, ref ex3, ref ex4, ref flag12, ref num24, ref flag13, ref flag14, ref flag15, ref flag16, ref flag17, ref flag18, Main.DefineUninitializedDataTypeNameFormatFlags[num3]);
					}
				}
				num4 = 0;
				return;
				IL_A8:
				if (num10 != -1)
				{
					goto IL_B3;
				}
				goto IL_2D2;
				IL_B3:
				num9 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num10 + 80 + num2);
				if (0 == num9)
				{
					goto IL_D2;
				}
				if (4 == num9)
				{
					goto IL_25B;
				}
				goto IL_2D2;
				IL_D2:
				num5 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num10 + 72 + num2);
				if (num5 == -1)
				{
					goto IL_120;
				}
				Type[] array6;
				Type type;
				if ((type = array6[num5]) != null)
				{
					goto IL_106;
				}
				RuntimeTypeHandle[] array7;
				array6[num5] = Type.GetTypeFromHandle(array7[num5]);
				type = array6[num5];
				IL_106:
				if (type.IsInstanceOfType(array2[1]))
				{
					goto IL_120;
				}
				num10 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num10 + 16 + num2);
				goto IL_A8;
				IL_120:
				num16 = num10;
				num8 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + num2) + num2);
				num14 = (int)array2[2];
				IL_13E:
				if (num14 != num8)
				{
					goto IL_1BD;
				}
				num11 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + 64 + num2);
				ex = array2[1];
				array = (object[])array[6];
				object[] array8 = new object[8];
				array8[0] = 1;
				array8[6] = array;
				array8[1] = array2[1];
				array8[2] = (int)array2[2];
				array8[7] = num16;
				array8[5] = 1;
				array = array8;
				num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + 64 + num2);
				goto IL_17;
				IL_1BD:
				num15 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num14 + 32 + num2);
				if (num15 == -1)
				{
					goto IL_24C;
				}
				num11 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num15 + 64 + num2);
				array = (object[])array[6];
				array8 = new object[8];
				array8[0] = 1;
				array8[6] = array;
				array8[1] = array2[1];
				array8[2] = (int)array2[2];
				array8[7] = num15;
				array8[3] = num16;
				array8[5] = 0;
				array = array8;
				num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num15 + 64 + num2);
				goto IL_17;
				IL_24C:
				num14 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num14 + num2);
				goto IL_13E;
				IL_25B:
				num11 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num10 + 8 + num2);
				ex = array2[1];
				array = (object[])array[6];
				array8 = new object[8];
				array8[0] = 1;
				array8[6] = array;
				array8[1] = array2[1];
				array8[2] = (int)array2[2];
				array8[7] = num10;
				array8[5] = 2;
				array = array8;
				num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num10 + 8 + num2);
				goto IL_17;
				IL_2D2:
				array = (object[])array[6];
				Exception ex5 = array2[1];
				int num25 = (int)array2[2];
				IL_2F1:
				num10 = num3;
				num11 = num10;
				num12 = 0;
				num13 = 6;
				IL_2FF:
				num17 = (num12 + num13) / 2;
				num18 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num17 * 80 + num2);
				num21 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num17 * 80 + 64 + num2);
				if (num11 >= num18 + num21)
				{
					goto IL_342;
				}
				if (num18 > num11)
				{
					goto IL_34A;
				}
				num8 = num17;
				num16 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 432 + num8 * 80 + 72 + num2);
				num5 = num16;
				num14 = num5;
				goto IL_372;
				IL_342:
				num12 = num17 + 1;
				goto IL_2FF;
				IL_34A:
				num13 = num17 - 1;
				goto IL_2FF;
				IL_372:
				if (array != null)
				{
					goto IL_37D;
				}
				goto IL_506;
				IL_37D:
				if ((int)array[0] != 0)
				{
					goto IL_43A;
				}
				int num26 = (int)array[7];
				if (num5 != -1)
				{
					goto IL_3A1;
				}
				int num27 = -1;
				goto IL_421;
				IL_3A1:
				int num28 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num5 + 24 + num2);
				num21 = 0;
				num18 = 6;
				IL_3B4:
				num17 = (num21 + num18) / 2;
				num13 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num17 * 80 + num2);
				num12 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num17 * 80 + 64 + num2);
				if (num28 >= num13 + num12)
				{
					goto IL_3F7;
				}
				if (num13 > num28)
				{
					goto IL_3FF;
				}
				num16 = num17;
				num8 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num16 * 80 + 72 + num2);
				num27 = num8;
				goto IL_421;
				IL_3F7:
				num21 = num17 + 1;
				goto IL_3B4;
				IL_3FF:
				num18 = num17 - 1;
				goto IL_3B4;
				IL_421:
				if (num26 != num27)
				{
					goto IL_429;
				}
				goto IL_506;
				IL_429:
				array = (object[])array[6];
				goto IL_372;
				IL_43A:
				num15 = (int)array[5];
				if (num15 == 1 || num15 == 0)
				{
					goto IL_45B;
				}
				if (num15 != 2)
				{
					goto IL_45A;
				}
				array2 = array;
				num10 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + (int)array2[7] + 16 + num2);
				goto IL_A8;
				IL_45A:
				IL_45B:
				int num29 = (int)array[7];
				if (num5 != -1)
				{
					goto IL_470;
				}
				int num30 = -1;
				goto IL_4F0;
				IL_470:
				num11 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num5 + 24 + num2);
				num12 = 0;
				num13 = 6;
				IL_483:
				num17 = (num12 + num13) / 2;
				num18 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num17 * 80 + num2);
				num21 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num17 * 80 + 64 + num2);
				if (num11 >= num18 + num21)
				{
					goto IL_4C6;
				}
				if (num18 > num11)
				{
					goto IL_4CE;
				}
				num8 = num17;
				num16 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + 992 + num8 * 80 + 72 + num2);
				num30 = num16;
				goto IL_4F0;
				IL_4C6:
				num12 = num17 + 1;
				goto IL_483;
				IL_4CE:
				num13 = num17 - 1;
				goto IL_483;
				IL_4F0:
				if (num29 != num30)
				{
					goto IL_4F5;
				}
				goto IL_506;
				IL_4F5:
				array = (object[])array[6];
				goto IL_372;
				IL_506:
				if (-1 != num5)
				{
					goto IL_5A7;
				}
				num16 = num14;
				IL_513:
				if (num16 != -1)
				{
					goto IL_51F;
				}
				int num31 = 1;
				throw ex5;
				IL_51F:
				num8 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + 32 + num2);
				if (num8 == -1)
				{
					goto IL_598;
				}
				num28 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num8 + 64 + num2);
				array2 = new object[8];
				array2[0] = 1;
				array2[6] = array;
				array2[1] = ex5;
				array2[2] = num14;
				array2[7] = -1;
				array2[3] = -1;
				array2[5] = 1;
				array = array2;
				num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num8 + 64 + num2);
				goto IL_17;
				IL_598:
				num16 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num16 + num2);
				goto IL_513;
				IL_5A7:
				num9 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num5 + 40 + num2);
				num11 = num9;
				IL_5B8:
				if (num11 != -1)
				{
					goto IL_5CC;
				}
				num5 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num5 + num2);
				goto IL_372;
				IL_5CC:
				num13 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num11 + 80 + num2);
				if (0 == num13)
				{
					goto IL_5F4;
				}
				if (4 == num13)
				{
					goto IL_759;
				}
				num5 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num5 + num2);
				goto IL_372;
				IL_5F4:
				num12 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num11 + 72 + num2);
				if (num12 == -1)
				{
					goto IL_643;
				}
				Type type2;
				if ((type2 = array6[num12]) != null)
				{
					goto IL_628;
				}
				array6[num12] = Type.GetTypeFromHandle(array7[num12]);
				type2 = array6[num12];
				IL_628:
				if (type2.IsInstanceOfType(ex5))
				{
					goto IL_643;
				}
				num11 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num11 + 16 + num2);
				goto IL_5B8;
				IL_643:
				num28 = num11;
				num21 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num28 + num2) + num2);
				num18 = (num14 - num25) * ((num25 == -1) ? 1 : 0) + num25;
				IL_666:
				if (num18 != num21)
				{
					goto IL_6CF;
				}
				int num32 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num28 + 64 + num2);
				ex = ex5;
				array2 = new object[8];
				array2[0] = 1;
				array2[6] = array;
				array2[1] = ex5;
				array2[2] = num14;
				array2[7] = num28;
				array2[5] = 1;
				array = array2;
				num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num28 + 64 + num2);
				goto IL_17;
				IL_6CF:
				num17 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num18 + 32 + num2);
				if (num17 == -1)
				{
					goto IL_74A;
				}
				num32 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num17 + 64 + num2);
				array2 = new object[8];
				array2[0] = 1;
				array2[6] = array;
				array2[1] = ex5;
				array2[2] = num14;
				array2[7] = num17;
				array2[3] = num28;
				array2[5] = 0;
				array = array2;
				num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num17 + 64 + num2);
				goto IL_17;
				IL_74A:
				num18 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num18 + num2);
				goto IL_666;
				IL_759:
				num32 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num11 + 8 + num2);
				ex = ex5;
				array2 = new object[8];
				array2[0] = 1;
				array2[6] = array;
				array2[1] = ex5;
				array2[2] = num14;
				array2[7] = num11;
				array2[5] = 2;
				array = array2;
				num3 = *(ref DiscretionaryAclProtectedAlt.ImpersonateSystemAcl + num11 + 8 + num2);
				goto IL_17;
			}
			catch (Exception ex6)
			{
				int num31;
				if (num31 != 1)
				{
					Exception ex5 = ex6;
					int num25 = -1;
					goto IL_2F1;
				}
				throw ex6;
			}
		}

		// Token: 0x06000910 RID: 2320 RVA: 0x00052448 File Offset: 0x00050648
		private static void NoStringInterningComponentRelativePath(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 170;
		}

		// Token: 0x06000911 RID: 2321 RVA: 0x00052460 File Offset: 0x00050660
		private static void IsTypeVisibleFromComResize(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			ButtonInfo index = Main.GetIndex(A_16);
			A_9 = index;
			bool flag = A_9 != null;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 22 + 145;
			A_0 = num;
		}

		// Token: 0x06000912 RID: 2322 RVA: 0x000524E0 File Offset: 0x000506E0
		private static void IFormatterflushStream(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			bool flag = Main.returnEnabled;
			A_25 = flag;
			int num = ((!A_25) ? 1 : 0) * 5 + 70;
			A_0 = num;
		}

		// Token: 0x06000913 RID: 2323 RVA: 0x0005253C File Offset: 0x0005073C
		private static void FinalizationHelperCanWrite(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			Main.RecenterMenu(Settings.rightHanded, A_5);
			bool flag = !Main.tick;
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 1 + 16;
			A_0 = num;
		}

		// Token: 0x06000914 RID: 2324 RVA: 0x000525B4 File Offset: 0x000507B4
		private static void HashComRedirectionProxy(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			Main.CreateReference(Settings.rightHanded);
			bool flag = Main.trailMenu;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 11;
			A_0 = num;
		}

		// Token: 0x06000915 RID: 2325 RVA: 0x0005261C File Offset: 0x0005081C
		private static void DestroyCryptoStream(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = A_20 + 1;
			A_20 = num;
			int num2 = ((A_20 < A_19.Length) ? 1 : 0) * -9 + 36;
			A_0 = num2;
		}

		// Token: 0x06000916 RID: 2326 RVA: 0x0005267C File Offset: 0x0005087C
		private static void getPriorityAsyncReplySink(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_9.method.Invoke();
			A_1 = 4;
			A_2 = 164;
		}

		// Token: 0x06000917 RID: 2327 RVA: 0x000526B4 File Offset: 0x000508B4
		private static void ComRegisterFunctionAttributeSpn(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			Debug.LogError(A_16 + " does not exist");
			Main.RecreateMenu();
			A_1 = 0;
		}

		// Token: 0x06000918 RID: 2328 RVA: 0x000526EC File Offset: 0x000508EC
		private static void MinimumRequiredVersionCreateDefaultTypeInfo(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			A_1 = 0;
		}

		// Token: 0x06000919 RID: 2329 RVA: 0x00052704 File Offset: 0x00050904
		private static void IsConsoleEnabledGetRaiseMethod(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_29 = gameObject;
			A_29.transform.parent = Main.menu.transform;
			A_29.transform.rotation = Quaternion.identity;
			A_29.transform.localScale = new Vector3(0.035f, 0.92f, 0.092f);
			A_29.transform.localPosition = new Vector3(0.56f, 0f, -0.55f);
			A_29.GetComponent<Renderer>().material.color = Main.outlineColor;
			ColorChanger colorChanger = A_26.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.buttonColors[0];
			A_8.Start();
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_30 = text;
			A_30.text = "Return";
			A_30.font = Settings.currentFont;
			A_30.fontSize = 1;
			A_30.color = Settings.textColors[0];
			A_30.alignment = 4;
			A_30.resizeTextForBestFit = true;
			A_30.resizeTextMinSize = 0;
			RectTransform component = A_30.GetComponent<RectTransform>();
			A_31 = component;
			A_31.localPosition = Vector3.zero;
			A_31.sizeDelta = new Vector2(0.2f, 0.03f);
			A_31.localPosition = new Vector3(0.064f, 0f, -0.21f);
			A_31.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			GameObject gameObject2 = GameObject.CreatePrimitive(3);
			A_32 = gameObject2;
			bool flag = !UnityInput.Current.GetKey(113);
			A_33 = flag;
			int num = ((!A_33) ? 1 : 0) * 1 + 76;
			A_0 = num;
		}

		// Token: 0x0600091A RID: 2330 RVA: 0x00052A00 File Offset: 0x00050C00
		private static void ThreadAbortExceptionSymbolType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			Main.pageNumber--;
			bool flag = Main.pageNumber < 0;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 138;
			A_0 = num;
		}

		// Token: 0x0600091B RID: 2331 RVA: 0x00052A74 File Offset: 0x00050C74
		private static GradientColorKey[] CFgetIsSecured(ref int A_0, ref int A_1, ref int A_2, ref GradientColorKey[] A_3, Color A_4)
		{
			GradientColorKey[] array = new GradientColorKey[]
			{
				new GradientColorKey(A_4, 0f),
				new GradientColorKey(A_4, 1f)
			};
			A_3 = array;
			A_0 = 172;
			GradientColorKey[] result;
			return result;
		}

		// Token: 0x0600091C RID: 2332 RVA: 0x00052AE0 File Offset: 0x00050CE0
		private static void ResourceManagerAuthorityThisOrganizationSid(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = A_4 | A_5;
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 3 + 15;
			A_0 = num;
		}

		// Token: 0x0600091D RID: 2333 RVA: 0x00052B4C File Offset: 0x00050D4C
		private static void ReasonTokenListCount(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			float num = (Mathf.Sin(Time.time * Main.speed) + 1f) / 2f;
			A_27 = num;
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text").GetComponent<TMP_Text>().color = Color.white;
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text").GetComponent<TMP_Text>().text = "---------------------------------------------\nIf you see this that means the menu COC Text had a error :(\n\nJust read the MOTD for info\n\n\n\n\n\n\n\n\n\nropex was here...";
			bool flag = GameObject.Find("CodeOfConduct") != null;
			A_28 = flag;
			int num2 = ((!A_28) ? 1 : 0) * 1 + 43;
			A_0 = num2;
		}

		// Token: 0x0600091E RID: 2334 RVA: 0x00052C18 File Offset: 0x00050E18
		private static void addCancelKeyPressDeleteLocalDataStore(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_1 = 60;
			A_2 = 40;
		}

		// Token: 0x0600091F RID: 2335 RVA: 0x00052C3C File Offset: 0x00050E3C
		private static void MethodOnTypeBuilderInstantiationLocalSig(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			bool flag = Main.outlineMenu;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 60;
			A_0 = num;
		}

		// Token: 0x06000920 RID: 2336 RVA: 0x00052C98 File Offset: 0x00050E98
		private static void AssertFailuregetIsNotPublic(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(false);
			bool flag = Main.TPC != null;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 10 + 120;
			A_0 = num;
		}

		// Token: 0x06000921 RID: 2337 RVA: 0x00052D24 File Offset: 0x00050F24
		private static void setURINotInProgress(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			Object.Destroy(A_19.GetComponent<Rigidbody>());
			A_19.GetComponent<BoxCollider>().isTrigger = true;
			A_19.transform.parent = Main.menu.transform;
			A_19.transform.rotation = Quaternion.identity;
			A_19.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
			A_19.transform.localPosition = new Vector3(0.56f, 0f, 0.55f);
			A_19.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
			A_19.AddComponent<Button>().relatedText = "Disconnect";
			bool flag = Main.outlineMenu;
			A_21 = flag;
			int num = ((!A_21) ? 1 : 0) * 1 + 67;
			A_0 = num;
		}

		// Token: 0x06000922 RID: 2338 RVA: 0x00052E84 File Offset: 0x00051084
		private static void ValueCountgetGlobalAssemblyCache(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = A_17 + 1;
			A_17 = num;
			int num2 = ((A_17 < A_16.Length) ? 1 : 0) * -12 + 38;
			A_0 = num2;
		}

		// Token: 0x06000923 RID: 2339 RVA: 0x00052EE4 File Offset: 0x000510E4
		private static void MoveDirectoryBaseChannelObjectWithProperties(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			ColorChanger colorChanger = A_32.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.buttonColors[0];
			A_8.Start();
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_11 = text;
			A_11.font = Settings.currentFont;
			A_11.text = ">>>>>>";
			A_11.fontSize = 1;
			A_11.color = Settings.textColors[0];
			A_11.alignment = 4;
			A_11.resizeTextForBestFit = true;
			A_11.resizeTextMinSize = 0;
			RectTransform component = A_11.GetComponent<RectTransform>();
			A_14 = component;
			A_14.localPosition = Vector3.zero;
			A_14.sizeDelta = new Vector2(0.2f, 0.03f);
			A_14.localPosition = new Vector3(0.064f, 0f, 0.065f);
			A_14.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			ButtonInfo[] array = Enumerable.ToArray<ButtonInfo>(Enumerable.Take<ButtonInfo>(Enumerable.Skip<ButtonInfo>(Buttons.buttons[Main.buttonsType], Main.pageNumber * Settings.buttonsPerPage), Settings.buttonsPerPage));
			A_39 = array;
			int num = 0;
			A_40 = num;
			A_0 = 85;
		}

		// Token: 0x06000924 RID: 2340 RVA: 0x000530F8 File Offset: 0x000512F8
		private static void AllocateDataSlotReflectionMemberAccess(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			A_19.layer = 2;
			Object.Destroy(A_19.GetComponent<Rigidbody>());
			A_19.GetComponent<BoxCollider>().isTrigger = true;
			A_19.transform.parent = Main.menu.transform;
			A_19.transform.rotation = Quaternion.identity;
			A_19.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
			A_19.transform.localPosition = new Vector3(0.56f, 0f, 0.55f);
			A_19.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
			A_19.AddComponent<Button>().relatedText = "Disconnect";
			bool flag = Main.outlineMenu;
			A_21 = flag;
			int num = ((!A_21) ? 1 : 0) * 1 + 67;
			A_0 = num;
		}

		// Token: 0x06000925 RID: 2341 RVA: 0x00053270 File Offset: 0x00051470
		private static void EncodedEnumTypeOperational(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_0 = 20;
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x00053288 File Offset: 0x00051488
		private static void RemoveAccessConvertTimeBySystemTimeZoneId(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = A_21.method != null;
			A_23 = flag;
			int num = ((!A_23) ? 1 : 0) * 4 + 29;
			A_0 = num;
		}

		// Token: 0x06000927 RID: 2343 RVA: 0x000532F0 File Offset: 0x000514F0
		private static void AnsiBSTRMarshalercbSizeInstance(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			Object.Destroy(A_3.GetComponent<Rigidbody>());
			A_3.GetComponent<BoxCollider>().isTrigger = true;
			A_3.transform.parent = Main.menu.transform;
			A_3.transform.rotation = Quaternion.identity;
			A_3.transform.localScale = new Vector3(0.09f, 0.8f, 0.075f);
			A_3.transform.localPosition = new Vector3(0.56f, 0f, 0.04f - A_19);
			A_3.AddComponent<Button>().relatedText = A_20.buttonText;
			bool flag = Main.outlineMenu;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 91;
			A_0 = num;
		}

		// Token: 0x06000928 RID: 2344 RVA: 0x00053424 File Offset: 0x00051624
		private static void getLogicalCallContextgetNativeName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			ColorChanger colorChanger = A_26.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.buttonColors[0];
			A_8.Start();
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_30 = text;
			A_30.text = "Return";
			A_30.font = Settings.currentFont;
			A_30.fontSize = 1;
			A_30.color = Settings.textColors[0];
			A_30.alignment = 4;
			A_30.resizeTextForBestFit = true;
			A_30.resizeTextMinSize = 0;
			RectTransform component = A_30.GetComponent<RectTransform>();
			A_31 = component;
			A_31.localPosition = Vector3.zero;
			A_31.sizeDelta = new Vector2(0.2f, 0.03f);
			A_31.localPosition = new Vector3(0.064f, 0f, -0.21f);
			A_31.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_32 = gameObject;
			bool flag = !UnityInput.Current.GetKey(113);
			A_33 = flag;
			int num = ((!A_33) ? 1 : 0) * 1 + 76;
			A_0 = num;
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x00053658 File Offset: 0x00051858
		private static void setDisallowCodeDownloadgetTargetedPatchBand(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			bool flag = A_16 == "NextPage";
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 3 + 141;
			A_0 = num;
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x000536C0 File Offset: 0x000518C0
		private static void getTypeHandleCLRInstanceID(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			bool isTogglable = A_9.isTogglable;
			A_11 = isTogglable;
			int num = ((!A_11) ? 1 : 0) * 14 + 146;
			A_0 = num;
		}

		// Token: 0x0600092B RID: 2347 RVA: 0x00053728 File Offset: 0x00051928
		private static void getIsPrivateCreateActContextParametersSourceDefinitionAppid(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 155;
		}

		// Token: 0x0600092C RID: 2348 RVA: 0x00053740 File Offset: 0x00051940
		private static void DefaultKeySetKeyContainerPermissionAccessEntryEnumerator(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = A_20 + 1;
			A_20 = num;
			int num2 = ((A_20 < A_19.Length) ? 1 : 0) * -9 + 36;
			A_0 = num2;
		}

		// Token: 0x0600092D RID: 2349 RVA: 0x000537A0 File Offset: 0x000519A0
		private static void NoValuePropgetScheduledTasks(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_13.alignment = 4;
			A_13.fontStyle = 0;
			A_13.resizeTextForBestFit = true;
			A_13.resizeTextMinSize = 0;
			RectTransform component = A_13.GetComponent<RectTransform>();
			A_16 = component;
			A_16.localPosition = Vector3.zero;
			A_16.sizeDelta = new Vector2(0.1f, 0.02f);
			A_16.localPosition = new Vector3(0.064f, 0f, 0.031f - A_19 / 2.6f);
			A_16.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			ColorChanger colorChanger = A_3.AddComponent<ColorChanger>();
			A_17 = colorChanger;
			bool enabled = A_20.enabled;
			A_18 = enabled;
			int num = ((!A_18) ? 1 : 0) * 1 + 105;
			A_0 = num;
		}

		// Token: 0x0600092E RID: 2350 RVA: 0x00053918 File Offset: 0x00051B18
		private static void SpaceSeparatorConfig(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_13.color = Settings.textColors[0];
			A_13.alignment = 4;
			A_13.fontStyle = 0;
			A_13.resizeTextForBestFit = true;
			A_13.resizeTextMinSize = 0;
			RectTransform component = A_13.GetComponent<RectTransform>();
			A_16 = component;
			A_16.localPosition = Vector3.zero;
			A_16.sizeDelta = new Vector2(0.1f, 0.02f);
			A_16.localPosition = new Vector3(0.064f, 0f, 0.031f - A_19 / 2.6f);
			A_16.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			ColorChanger colorChanger = A_3.AddComponent<ColorChanger>();
			A_17 = colorChanger;
			bool enabled = A_20.enabled;
			A_18 = enabled;
			int num = ((!A_18) ? 1 : 0) * 1 + 105;
			A_0 = num;
		}

		// Token: 0x0600092F RID: 2351 RVA: 0x00053AB0 File Offset: 0x00051CB0
		private static void setVersiongetBufferWidth(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_0 = 128;
		}

		// Token: 0x06000930 RID: 2352 RVA: 0x00053ACC File Offset: 0x00051CCC
		private static void ForegroundMaskInternalsVisibleToAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_9.disableMethod.Invoke();
			A_1 = 4;
			A_2 = 157;
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x00053B04 File Offset: 0x00051D04
		private static void getLocalSignatureMetadataTokensetMonthGenitiveNames(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_1 = 0;
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x00053B20 File Offset: 0x00051D20
		private static void NowAllocHGlobal(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)").GetComponent<TMP_Text>().text = "[+] [ Selenite ] [+]";
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)").GetComponent<TMP_Text>().color = Main.outlineColor;
			bool flag = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdtext") != null;
			A_30 = flag;
			int num = ((!A_30) ? 1 : 0) * 1 + 47;
			A_0 = num;
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x00053BC4 File Offset: 0x00051DC4
		private static ButtonInfo PrivateImplementationDetailsCMSSCHEMAVERSIONV(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			int num = ((A_7 < A_6.Length) ? 1 : 0) * -4 + 179;
			A_0 = num;
			ButtonInfo result;
			return result;
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x00053C04 File Offset: 0x00051E04
		private static void ResourceManagerLookingForResourceSetCountry(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			GameObject.Find("CodeOfConduct").GetComponent<TMP_Text>().color = Main.outlineColor;
			GameObject.Find("CodeOfConduct").GetComponent<TMP_Text>().text = "[+] [ Selenite ] [+]";
			bool flag = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)") != null;
			A_29 = flag;
			int num = ((!A_29) ? 1 : 0) * 1 + 45;
			A_0 = num;
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x00053CA8 File Offset: 0x00051EA8
		private static ButtonInfo VTCFRSAPKCSSHASignatureDescription(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			int num = ((A_4 < A_3.Length) ? 1 : 0) * -7 + 181;
			A_0 = num;
			ButtonInfo result;
			return result;
		}

		// Token: 0x06000936 RID: 2358 RVA: 0x00053CE8 File Offset: 0x00051EE8
		private static void NonGenericToGenericEnumeratorgetKeySpec(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(true);
			Object.Destroy(Main.menu);
			Main.menu = null;
			Object.Destroy(Main.reference);
			Main.reference = null;
			Main.tick = false;
			A_1 = 60;
			A_2 = 22;
		}

		// Token: 0x06000937 RID: 2359 RVA: 0x00053D64 File Offset: 0x00051F64
		private static void CreatePermanentoInst(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			Main.TPC.transform.position = new Vector3(-999f, -999f, -999f);
			Main.TPC.transform.rotation = Quaternion.identity;
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_9 = gameObject;
			A_9.transform.localScale = new Vector3(10f, 10f, 0.01f);
			A_9.transform.transform.position = Main.TPC.transform.position + Main.TPC.transform.forward;
			A_9.GetComponent<Renderer>().material.color = new Color32((byte)(Settings.backgroundColor.colors[0].color.r * 50f), (byte)(Settings.backgroundColor.colors[0].color.g * 50f), (byte)(Settings.backgroundColor.colors[0].color.b * 50f), byte.MaxValue);
			Object.Destroy(A_9, Time.deltaTime);
			Main.menu.transform.parent = Main.TPC.transform;
			Main.menu.transform.position = Main.TPC.transform.position + Vector3.Scale(Main.TPC.transform.forward, new Vector3(0.5f, 0.5f, 0.5f)) + Vector3.Scale(Main.TPC.transform.up, new Vector3(-0.02f, -0.02f, -0.02f));
			Quaternion rotation = Main.TPC.transform.rotation;
			A_6 = rotation;
			Vector3 eulerAngles = A_6.eulerAngles;
			A_10 = eulerAngles;
			A_10..ctor(A_10.x - 90f, A_10.y + 90f, A_10.z);
			Main.menu.transform.rotation = Quaternion.Euler(A_10);
			bool flag = Main.reference != null;
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 8 + 121;
			A_0 = num;
		}

		// Token: 0x06000938 RID: 2360 RVA: 0x00054054 File Offset: 0x00052254
		private static void getRequestingAssemblyBinaryMethodReturnMessage(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_1 = 60;
			A_2 = 22;
		}

		// Token: 0x06000939 RID: 2361 RVA: 0x00054078 File Offset: 0x00052278
		private static void setTaggetSectionID(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = A_20 + 1;
			A_20 = num;
			int num2 = ((A_20 < A_19.Length) ? 1 : 0) * -9 + 36;
			A_0 = num2;
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x000540D8 File Offset: 0x000522D8
		private static void SubstringEqualsRemotingSurrogate(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_9.enableMethod.Invoke();
			A_1 = 4;
			A_2 = 151;
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x00054110 File Offset: 0x00052310
		private static void TypedValueEnumRunning(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_13.color = Settings.textColors[1];
			A_0 = 103;
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x00054148 File Offset: 0x00052348
		private static ButtonInfo AssemblyDescriptionAttributeFDisplayBind(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			int num = A_4 + 1;
			A_4 = num;
			int num2 = ((A_4 < A_3.Length) ? 1 : 0) * -7 + 181;
			A_0 = num2;
			ButtonInfo result;
			return result;
		}

		// Token: 0x0600093D RID: 2365 RVA: 0x000541AC File Offset: 0x000523AC
		private static void DoNotDisposeIIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGEXACTMATCHREQUIRED(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			Object.Destroy(A_32.GetComponent<Rigidbody>());
			A_32.GetComponent<BoxCollider>().isTrigger = true;
			A_32.transform.parent = Main.menu.transform;
			A_32.transform.rotation = Quaternion.identity;
			A_32.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
			A_32.transform.localPosition = new Vector3(0.56f, 0f, 0.3f);
			A_32.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
			A_32.AddComponent<Button>().relatedText = "PreviousPage";
			bool flag = Main.outlineMenu;
			A_34 = flag;
			int num = ((!A_34) ? 1 : 0) * 1 + 78;
			A_0 = num;
		}

		// Token: 0x0600093E RID: 2366 RVA: 0x0005430C File Offset: 0x0005250C
		private static void MAJORVERSIONGetLibStatistics(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			Main.CreateButton((float)A_40 * 0.13f, A_39[A_40]);
			int num = A_40 + 1;
			A_40 = num;
			bool flag = A_40 < A_39.Length;
			A_41 = flag;
			int num2 = (A_41 ? 1 : 0) * -2 + 86;
			A_0 = num2;
		}

		// Token: 0x0600093F RID: 2367 RVA: 0x000543C4 File Offset: 0x000525C4
		private static void getOSXRIPEMD(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			A_1 = 0;
		}

		// Token: 0x06000940 RID: 2368 RVA: 0x000543DC File Offset: 0x000525DC
		private static void LoadPolicyLevelFromStringPercentPositivePattern(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_0 = 20;
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x000543F8 File Offset: 0x000525F8
		private static void AnyOtherOriginSchemegetConstructionException(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			Main.menu.transform.position = GorillaTagger.Instance.leftHandTransform.position;
			Main.menu.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
			A_0 = 115;
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x00054450 File Offset: 0x00052650
		private static void CMSSECTIONENTRYIDMETADATAgetAbbreviatedMonthNames(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_17.OnTriggerEnter(Main.buttonCollider);
			A_0 = 128;
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x00054480 File Offset: 0x00052680
		private static void setObjectModeSXSINSTALLREFERENCESCHEMESXSSTRONGNAMESIGNEDPRIVATEASSEMBLY(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_13.supportRichText = true;
			A_13.fontSize = 1;
			bool enabled = A_20.enabled;
			A_15 = enabled;
			int num = ((!A_15) ? 1 : 0) * 1 + 101;
			A_0 = num;
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x00054508 File Offset: 0x00052708
		private static void SpngetAccess(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_0 = 19;
		}

		// Token: 0x06000945 RID: 2373 RVA: 0x00054520 File Offset: 0x00052720
		private static ButtonInfo GetAwaiterSignal(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			ButtonInfo buttonInfo = A_6[A_7];
			A_8 = buttonInfo;
			bool flag = A_8.buttonText == A_11;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 176;
			A_0 = num;
			ButtonInfo result;
			return result;
		}

		// Token: 0x06000946 RID: 2374 RVA: 0x000545B8 File Offset: 0x000527B8
		private static void SoapRTLOSVERSIONINFOEX(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/NameTagAnchor/NameTagCanvas/Text Inner") != null;
			A_32 = flag;
			int num = ((!A_32) ? 1 : 0) * 1 + 50;
			A_0 = num;
		}

		// Token: 0x06000947 RID: 2375 RVA: 0x00054620 File Offset: 0x00052820
		private static void InvalidLocalPush(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_5 = gameObject;
			A_5.transform.parent = Main.menu.transform;
			A_5.transform.rotation = Quaternion.identity;
			A_5.transform.localScale = new Vector3(0.095f, 0.32f, 0.97f);
			A_5.transform.localPosition = new Vector3(0.5f, 0.67f, 0f);
			A_5.GetComponent<Renderer>().material.color = Main.outlineColor;
			bool flag = Main.outlineMenu;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 60;
			A_0 = num;
		}

		// Token: 0x06000948 RID: 2376 RVA: 0x00054744 File Offset: 0x00052944
		private static ButtonInfo CountedUtfJsonWhenAll(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			ButtonInfo result = A_10;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x00054764 File Offset: 0x00052964
		private static void MetadataSectionSchemaVersiongetIsParamDef(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text") != null;
			A_26 = flag;
			int num = ((!A_26) ? 1 : 0) * 1 + 41;
			A_0 = num;
		}

		// Token: 0x0600094A RID: 2378 RVA: 0x000547CC File Offset: 0x000529CC
		private static void MarshalNativeToManagedIsolationDllName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = false;
			A_4 = flag;
			bool key = UnityInput.Current.GetKey(113);
			A_5 = key;
			bool flag2 = Main.menu == null;
			A_6 = flag2;
			int num = ((!A_6) ? 1 : 0) * 7 + 7;
			A_0 = num;
		}

		// Token: 0x0600094B RID: 2379 RVA: 0x00054868 File Offset: 0x00052A68
		private static ButtonInfo PidResourceTypeIdStringSize(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			ButtonInfo buttonInfo = A_8;
			A_10 = buttonInfo;
			A_0 = 182;
			ButtonInfo result;
			return result;
		}

		// Token: 0x0600094C RID: 2380 RVA: 0x000548A0 File Offset: 0x00052AA0
		private static void getOffsetsetSerializationFormatter(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_0 = 1;
		}

		// Token: 0x0600094D RID: 2381 RVA: 0x000548B8 File Offset: 0x00052AB8
		private static void GetRuntimeEventsGetRect(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			Main.TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
			A_1 = 4;
			A_2 = 119;
		}

		// Token: 0x0600094E RID: 2382 RVA: 0x000548F0 File Offset: 0x00052AF0
		private static void CreateFilesUseLegacyPathHandling(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			bool flag = !A_20;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 113;
			A_0 = num;
		}

		// Token: 0x0600094F RID: 2383 RVA: 0x00054954 File Offset: 0x00052B54
		private static void DefaultNameClaimTypeEnableEvents(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_1 = 56;
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x0005496C File Offset: 0x00052B6C
		private static void ReadOnlyDictionaryCOREISOSTORE(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			Main.pageNumber = A_4;
			A_0 = 170;
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x00054994 File Offset: 0x00052B94
		private static void ManualResetEventSlimGetSddlForm(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_8 = text;
			A_8.font = Settings.currentFont;
			A_8.text = A_20.buttonText;
			bool flag = A_20.overlapText != null;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 93;
			A_0 = num;
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x00054A54 File Offset: 0x00052C54
		private static void SoapPositiveIntegeratime(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_17.Start();
			A_1 = 0;
		}

		// Token: 0x06000953 RID: 2387 RVA: 0x00054A7C File Offset: 0x00052C7C
		private static void GetHashFromHandleEntryPointNotFoundException(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_0 = 128;
		}

		// Token: 0x06000954 RID: 2388 RVA: 0x00054A94 File Offset: 0x00052C94
		private static void RunContinuationsAsynchronouslyRights(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			ColorChanger colorChanger = Main.menuBackground.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.backgroundColor;
			A_8.Start();
			Main.canvasObject = new GameObject();
			Main.canvasObject.transform.parent = Main.menu.transform;
			Canvas canvas = Main.canvasObject.AddComponent<Canvas>();
			A_9 = canvas;
			CanvasScaler canvasScaler = Main.canvasObject.AddComponent<CanvasScaler>();
			A_10 = canvasScaler;
			Main.canvasObject.AddComponent<GraphicRaycaster>();
			A_9.renderMode = 2;
			A_10.dynamicPixelsPerUnit = 2500f;
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_11 = text;
			A_11.font = Settings.currentFont;
			Text text2 = A_11;
			string text3 = "Selenite - Fps: ";
			float num = Mathf.Ceil(1f / Time.unscaledDeltaTime);
			A_12 = num;
			string text4 = A_12.ToString();
			string text5 = " | Page: ";
			int num2 = Main.pageNumber + 1;
			A_13 = num2;
			text2.text = text3 + text4 + text5 + A_13.ToString();
			A_11.fontSize = 1;
			A_11.color = Settings.textColors[0];
			A_11.supportRichText = true;
			A_11.fontStyle = 0;
			A_11.alignment = 4;
			A_11.resizeTextForBestFit = true;
			A_11.resizeTextMinSize = 0;
			RectTransform component = A_11.GetComponent<RectTransform>();
			A_14 = component;
			A_14.localPosition = Vector3.zero;
			A_14.sizeDelta = new Vector2(0.24f, 0.04f);
			A_14.position = new Vector3(0.06f, 0f, 0.16f);
			A_14.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			bool flag = Main.sideBarEnabled;
			A_15 = flag;
			int num3 = ((!A_15) ? 1 : 0) * 1 + 62;
			A_0 = num3;
		}

		// Token: 0x06000955 RID: 2389 RVA: 0x00054DA0 File Offset: 0x00052FA0
		private static void InternalArrayTypeEgetUniqueKeyContainerName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = (ControllerInputPoller.instance.leftControllerSecondaryButton ? 1 : 0) * 3 + 3;
			A_0 = num;
		}

		// Token: 0x06000956 RID: 2390 RVA: 0x00054DE8 File Offset: 0x00052FE8
		private static void RemotingAssertLogLevel(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = GameObject.Find("CodeOfConduct") != null;
			A_28 = flag;
			int num = ((!A_28) ? 1 : 0) * 1 + 43;
			A_0 = num;
		}

		// Token: 0x06000957 RID: 2391 RVA: 0x00054E50 File Offset: 0x00053050
		private static void KeysNormalizedReason(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, bool A_4)
		{
			Main.reference.GetComponent<Renderer>().material.color = Color.white;
			Main.reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
			Main.reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
			Main.buttonCollider = Main.reference.GetComponent<SphereCollider>();
			A_1 = 0;
		}

		// Token: 0x06000958 RID: 2392 RVA: 0x00054ED8 File Offset: 0x000530D8
		private static void CTSTKINDCOCLASS(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_7 = gameObject;
			A_7.transform.parent = Main.menu.transform;
			A_7.transform.rotation = Quaternion.identity;
			A_7.transform.localScale = new Vector3(0.035f, 0.82f, 0.092f);
			A_7.transform.localPosition = new Vector3(0.56f, 0f, 0.04f - A_19);
			A_7.GetComponent<Renderer>().material.color = Main.outlineColor;
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_8 = text;
			A_8.font = Settings.currentFont;
			A_8.text = A_20.buttonText;
			bool flag = A_20.overlapText != null;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 93;
			A_0 = num;
		}

		// Token: 0x06000959 RID: 2393 RVA: 0x00055064 File Offset: 0x00053264
		public static void RecreateMenu()
		{
			int num = 108;
			int num2 = 108;
			num2 = 108;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 108;
		}

		// Token: 0x0600095A RID: 2394 RVA: 0x0005509C File Offset: 0x0005329C
		private static void NumberFormatInfoReaderWriterLockTimedOutException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			bool disconnectButton = Settings.disconnectButton;
			A_18 = disconnectButton;
			int num = ((!A_18) ? 1 : 0) * 5 + 64;
			A_0 = num;
		}

		// Token: 0x0600095B RID: 2395 RVA: 0x000550F8 File Offset: 0x000532F8
		private static void ProxyAttributeDeletedAccount(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			Text text = Main.fpsObject;
			DateTime now = DateTime.Now;
			A_15 = now;
			text.text = A_15.ToString("MM/dd/yyyy h:mm tt");
			ButtonInfo[][] buttons = Buttons.buttons;
			A_16 = buttons;
			int num = 0;
			A_17 = num;
			A_0 = 37;
		}

		// Token: 0x0600095C RID: 2396 RVA: 0x00055170 File Offset: 0x00053370
		private static void MuiResourceTypeIdStringEntryFieldIdKeyContainerPermissionAttribute(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			bool flag = !Main.checkBoxButtons;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 8 + 90;
			A_0 = num;
		}

		// Token: 0x0600095D RID: 2397 RVA: 0x000551D4 File Offset: 0x000533D4
		private static void ISectionreadPos(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_8.color = Settings.textColors[1];
			A_0 = 97;
		}

		// Token: 0x0600095E RID: 2398 RVA: 0x0005520C File Offset: 0x0005340C
		private static void AsDispatchFoundMonthPatternFlag(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			Main.menu = GameObject.CreatePrimitive(3);
			Object.Destroy(Main.menu.GetComponent<Rigidbody>());
			Object.Destroy(Main.menu.GetComponent<BoxCollider>());
			Object.Destroy(Main.menu.GetComponent<Renderer>());
			Main.menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);
			Main.menuBackground = GameObject.CreatePrimitive(3);
			Main.menuBackground.transform.parent = Main.menu.transform;
			Main.menuBackground.transform.rotation = Quaternion.identity;
			Main.menuBackground.transform.localScale = new Vector3(0.1f, 0.9f, 0.95f);
			Main.menuBackground.GetComponent<Renderer>().material.color = Settings.backgroundColor.colors[0].color;
			Main.menuBackground.transform.position = new Vector3(0.05f, 0f, 0f);
			bool flag = Main.sideBarEnabled;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 3 + 56;
			A_0 = num;
		}

		// Token: 0x0600095F RID: 2399 RVA: 0x00055380 File Offset: 0x00053580
		private static void TypeContractsAreForAnd(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/NameTagAnchor/NameTagCanvas/Text Outer") != null;
			A_33 = flag;
			int num = ((!A_33) ? 1 : 0) * 1 + 53;
			A_0 = num;
		}

		// Token: 0x06000960 RID: 2400 RVA: 0x000553E8 File Offset: 0x000535E8
		private static void ContinueParsingpUint(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			bool isPressed = Mouse.current.leftButton.isPressed;
			A_12 = isPressed;
			int num = ((!A_12) ? 1 : 0) * 5 + 122;
			A_0 = num;
		}

		// Token: 0x06000961 RID: 2401 RVA: 0x00055450 File Offset: 0x00053650
		private static void MemoryFailPointIsNestedFamily(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			Main.sideBar = GameObject.CreatePrimitive(3);
			Main.sideBar.transform.parent = Main.menu.transform;
			Main.sideBar.transform.rotation = Quaternion.identity;
			Main.sideBar.transform.localScale = new Vector3(0.1f, 0.3f, 0.95f);
			Main.sideBar.GetComponent<Renderer>().material.color = Settings.backgroundColor.colors[0].color;
			Main.sideBar.transform.position = new Vector3(0.05f, 0.2f, 0f);
			Main.sideBarLine1 = GameObject.CreatePrimitive(3);
			Main.sideBarLine1.transform.parent = Main.menu.transform;
			Main.sideBarLine1.transform.rotation = Quaternion.identity;
			Main.sideBarLine1.transform.localScale = new Vector3(0.1f, 0.3f, 0.01f);
			Main.sideBarLine1.GetComponent<Renderer>().material.color = Main.outlineColor;
			Main.sideBarLine1.transform.position = new Vector3(0.051f, 0.2f, 0.16f);
			bool flag = Main.outlineMenu;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 57;
			A_0 = num;
		}

		// Token: 0x06000962 RID: 2402 RVA: 0x00055608 File Offset: 0x00053808
		private static void removeReflectionOnlyAssemblyResolveUnsafePack(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_9.enabled = !A_9.enabled;
			bool enabled = A_9.enabled;
			A_12 = enabled;
			int num = ((!A_12) ? 1 : 0) * 6 + 147;
			A_0 = num;
		}

		// Token: 0x06000963 RID: 2403 RVA: 0x00055690 File Offset: 0x00053890
		private static void pOctetStringgetReturnTypeCustomAttributes(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_25 = A_3;
			Debug.LogError(string.Format("{0} // Error with executing mods at {1}: {2}", "<b>Solar</b>", A_25.StackTrace, A_25.Message));
			A_1 = 60;
			A_2 = 40;
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x000556FC File Offset: 0x000538FC
		private static void FORMATFLAGSIBindCtx(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_17.colorInfo = Settings.buttonColors[0];
			A_17.Start();
			A_1 = 0;
		}

		// Token: 0x06000965 RID: 2405 RVA: 0x00055740 File Offset: 0x00053940
		private static void setSecurityZoneBuildVersion(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, bool A_4)
		{
			Main.reference = GameObject.CreatePrimitive(0);
			A_3 = A_4;
			int num = ((!A_3) ? 1 : 0) * 1 + 133;
			A_0 = num;
		}

		// Token: 0x06000966 RID: 2406 RVA: 0x000557AC File Offset: 0x000539AC
		private static void MaxBinaryLengthAddSystemAcl(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			Main.reference.transform.position = new Vector3(999f, -999f, -999f);
			A_1 = 0;
		}

		// Token: 0x06000967 RID: 2407 RVA: 0x000557EC File Offset: 0x000539EC
		private static void SystemEnvironmentDOWNLOAD(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			A_32.layer = 2;
			Object.Destroy(A_32.GetComponent<Rigidbody>());
			A_32.GetComponent<BoxCollider>().isTrigger = true;
			A_32.transform.parent = Main.menu.transform;
			A_32.transform.rotation = Quaternion.identity;
			A_32.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
			A_32.transform.localPosition = new Vector3(0.56f, 0f, 0.3f);
			A_32.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
			A_32.AddComponent<Button>().relatedText = "PreviousPage";
			bool flag = Main.outlineMenu;
			A_34 = flag;
			int num = ((!A_34) ? 1 : 0) * 1 + 78;
			A_0 = num;
		}

		// Token: 0x06000968 RID: 2408 RVA: 0x00055964 File Offset: 0x00053B64
		public static GradientColorKey[] GetSolidGradient(Color color)
		{
			int num = 171;
			int num2 = 171;
			num2 = 171;
			GradientColorKey[] result;
			while (num2 != 0)
			{
				int num3;
				GradientColorKey[] array;
				result = calli(UnityEngine.GradientColorKey[](System.Int32&,System.Int32&,System.Int32&,UnityEngine.GradientColorKey[]&,UnityEngine.Color), ref num, ref num2, ref num3, ref array, color, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 171;
			return result;
		}

		// Token: 0x06000969 RID: 2409 RVA: 0x000559B0 File Offset: 0x00053BB0
		private static void PARAMDESCDelegateWrapper(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 166;
		}

		// Token: 0x0600096A RID: 2410 RVA: 0x000559CC File Offset: 0x00053BCC
		private static void CrossContextChannelPerform(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_32 = gameObject;
			bool flag = !UnityInput.Current.GetKey(113);
			A_33 = flag;
			int num = ((!A_33) ? 1 : 0) * 1 + 76;
			A_0 = num;
		}

		// Token: 0x0600096B RID: 2411 RVA: 0x00055A54 File Offset: 0x00053C54
		// Note: this type is marked as 'beforefieldinit'.
		static Main()
		{
			Main.ProcessMessageFinishGetAbbreviatedDayName();
			int num = 185;
			int num2 = 185;
			num2 = 185;
			while (num2 != 0)
			{
				int num3;
				float num4;
				int num5;
				DateTime dateTime;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Single&,System.Int32&,System.DateTime&), ref num, ref num2, ref num3, ref num4, ref num5, ref dateTime, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 185;
		}

		// Token: 0x0600096C RID: 2412 RVA: 0x00055AA4 File Offset: 0x00053CA4
		private static void TaskToApmgetIsNestedFamily(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			Button component = A_14.transform.gameObject.GetComponent<Button>();
			A_17 = component;
			bool flag = A_17 != null;
			A_18 = flag;
			int num = ((!A_18) ? 1 : 0) * 1 + 124;
			A_0 = num;
		}

		// Token: 0x0600096D RID: 2413 RVA: 0x00055B30 File Offset: 0x00053D30
		public static void CreateMenu()
		{
			int num = 55;
			int num2 = 55;
			num2 = 55;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				GameObject gameObject;
				bool flag3;
				GameObject gameObject2;
				ColorChanger colorChanger;
				Canvas canvas;
				CanvasScaler canvasScaler;
				Text text;
				float num4;
				int num5;
				RectTransform rectTransform;
				bool flag4;
				DateTime dateTime;
				RectTransform rectTransform2;
				bool flag5;
				GameObject gameObject3;
				bool flag6;
				bool flag7;
				GameObject gameObject4;
				Text text2;
				RectTransform rectTransform3;
				bool flag8;
				GameObject gameObject5;
				bool flag9;
				bool flag10;
				GameObject gameObject6;
				Text text3;
				RectTransform rectTransform4;
				GameObject gameObject7;
				bool flag11;
				bool flag12;
				GameObject gameObject8;
				bool flag13;
				bool flag14;
				GameObject gameObject9;
				ButtonInfo[] array;
				int num6;
				bool flag15;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,System.Boolean&,UnityEngine.GameObject&,StupidTemplate.Classes.ColorChanger&,UnityEngine.Canvas&,UnityEngine.UI.CanvasScaler&,UnityEngine.UI.Text&,System.Single&,System.Int32&,UnityEngine.RectTransform&,System.Boolean&,System.DateTime&,UnityEngine.RectTransform&,System.Boolean&,UnityEngine.GameObject&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.UI.Text&,UnityEngine.RectTransform&,System.Boolean&,UnityEngine.GameObject&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.UI.Text&,UnityEngine.RectTransform&,UnityEngine.GameObject&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,StupidTemplate.Classes.ButtonInfo[]&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref gameObject, ref flag3, ref gameObject2, ref colorChanger, ref canvas, ref canvasScaler, ref text, ref num4, ref num5, ref rectTransform, ref flag4, ref dateTime, ref rectTransform2, ref flag5, ref gameObject3, ref flag6, ref flag7, ref gameObject4, ref text2, ref rectTransform3, ref flag8, ref gameObject5, ref flag9, ref flag10, ref gameObject6, ref text3, ref rectTransform4, ref gameObject7, ref flag11, ref flag12, ref gameObject8, ref flag13, ref flag14, ref gameObject9, ref array, ref num6, ref flag15, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 55;
		}

		// Token: 0x0600096E RID: 2414 RVA: 0x00055BB4 File Offset: 0x00053DB4
		private static void PackForNativegetActivityOptions(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref int A_4, ref DateTime A_5)
		{
			Main.pageNumber = 0;
			Main.buttonsType = 0;
			string text = "Selenite - Fps: ";
			float num = Mathf.Ceil(1f / Time.unscaledDeltaTime);
			A_3 = num;
			string text2 = A_3.ToString();
			string text3 = " | Page: ";
			int num2 = Main.pageNumber + 1;
			A_4 = num2;
			Main.name = text + text2 + text3 + A_4.ToString();
			Main.buttonClickSound = 114;
			Main.checkBoxButtons = false;
			Main.outlineColor = new Color32(2, 22, 199, 100);
			Main.tick = false;
			Main.guysiactuallyhate = false;
			Main.trailMenu = false;
			Main.outlineMenu = true;
			Main.cat = "Category_Main";
			DateTime now = DateTime.Now;
			A_5 = now;
			Main.date = A_5.ToString("MM/dd/yyyy h:mm tt");
			Main.sideBarEnabled = true;
			Main.categorys = true;
			Main.returnEnabled = false;
			Main.colorA = Color.white;
			Main.colorB = Color.cyan;
			Main.speed = 2f;
			A_1 = 0;
		}

		// Token: 0x0600096F RID: 2415 RVA: 0x00055D0C File Offset: 0x00053F0C
		private static void ArchitectureDXNN(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_13.text = A_20.overlapText;
			A_13.supportRichText = true;
			A_13.fontSize = 1;
			bool enabled = A_20.enabled;
			A_15 = enabled;
			int num = ((!A_15) ? 1 : 0) * 1 + 101;
			A_0 = num;
		}

		// Token: 0x06000970 RID: 2416 RVA: 0x00055DB0 File Offset: 0x00053FB0
		private static void AppDomainManagerInitializationOptionsgetPayloadNames(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			TrailRenderer trailRenderer = Main.menu.AddComponent<TrailRenderer>();
			A_10 = trailRenderer;
			A_10.startColor = Main.outlineColor;
			A_10.endColor = Main.outlineColor;
			A_10.startWidth = 0.025f;
			A_10.endWidth = 0f;
			A_10.minVertexDistance = 0.05f;
			A_10.material.shader = Shader.Find("Sprites/Default");
			A_10.time = 2f;
			A_0 = 20;
		}

		// Token: 0x06000971 RID: 2417 RVA: 0x00055E88 File Offset: 0x00054088
		private static void INotifyCompletionRemotingAssert(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			Object.Destroy(Main.menu);
			Main.menu = null;
			Main.CreateMenu();
			Main.RecenterMenu(Settings.rightHanded, UnityInput.Current.GetKey(Settings.keyboardButton));
			A_1 = 0;
		}

		// Token: 0x06000972 RID: 2418 RVA: 0x00055ED4 File Offset: 0x000540D4
		private static void IEnumSTORECATEGORYSUBCATEGORYsetVersionCompatibility(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_1 = 4;
			A_2 = 164;
		}

		// Token: 0x06000973 RID: 2419 RVA: 0x00055EFC File Offset: 0x000540FC
		private static void encodingPaddingHelpers(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 166;
		}

		// Token: 0x06000974 RID: 2420 RVA: 0x00055F18 File Offset: 0x00054118
		private static void ModeCNSgetIsUnicodeClass(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = Main.menu != null;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 109;
			A_0 = num;
		}

		// Token: 0x06000975 RID: 2421 RVA: 0x00055F7C File Offset: 0x0005417C
		private static ButtonInfo ThaiBuddhistEraSoapType(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			ButtonInfo buttonInfo = null;
			A_10 = buttonInfo;
			A_0 = 182;
			ButtonInfo result;
			return result;
		}

		// Token: 0x06000976 RID: 2422 RVA: 0x00055FAC File Offset: 0x000541AC
		public unsafe static void Toggle(string buttonText)
		{
			RuntimeTypeHandle[] array = new RuntimeTypeHandle[3];
			Type[] array2 = new Type[3];
			array[0] = typeof(object).TypeHandle;
			array[1] = typeof(object).TypeHandle;
			array[2] = typeof(object).TypeHandle;
			int num = 1;
			int num2 = num * 4;
			int num3 = 136;
			int num4 = 136;
			num4 = 136;
			try
			{
				IL_57:
				int num5;
				int num8;
				int num9;
				int num10;
				int num11;
				int num12;
				int num13;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				object[] array3;
				int num21;
				object[] array4;
				Exception ex;
				while (num4 != 0)
				{
					if (num4 == 4)
					{
						num4 = 136;
						int num6;
						num5 = num6;
						int num7 = num5;
						num8 = num3;
						num9 = num8;
						num5 = 0;
						num10 = 6;
						for (;;)
						{
							num11 = (num5 + num10) / 2;
							num12 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num11 * 48 + 16 + num2);
							num13 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num11 * 48 + 24 + num2);
							if (num9 < num12 + num13)
							{
								if (num12 <= num9)
								{
									break;
								}
								num10 = num11 - 1;
							}
							else
							{
								num5 = num11 + 1;
							}
						}
						num14 = num11;
						num15 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num14 * 48 + 8 + num2);
						num16 = num15;
						num13 = num7;
						num12 = 0;
						num11 = 6;
						for (;;)
						{
							num10 = (num12 + num11) / 2;
							num5 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num10 * 48 + 16 + num2);
							num9 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num10 * 48 + 24 + num2);
							if (num13 < num5 + num9)
							{
								if (num5 <= num13)
								{
									break;
								}
								num11 = num10 - 1;
							}
							else
							{
								num12 = num10 + 1;
							}
						}
						num14 = num10;
						num17 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num14 * 48 + 8 + num2);
						num15 = num17;
						num9 = num7;
						num5 = 0;
						num10 = 6;
						for (;;)
						{
							num11 = (num5 + num10) / 2;
							num12 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num11 * 64 + 16 + num2);
							num13 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num11 * 64 + 32 + num2);
							if (num9 < num12 + num13)
							{
								if (num12 <= num9)
								{
									break;
								}
								num10 = num11 - 1;
							}
							else
							{
								num5 = num11 + 1;
							}
						}
						num14 = num11;
						num18 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num14 * 64 + 8 + num2);
						num17 = num18;
						for (;;)
						{
							IL_9AC:
							if (array3 == null || (int)array3[2] == 0)
							{
								num9 = num15;
								while (num9 != num16)
								{
									if (num9 != -1)
									{
										num9 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num9 + 16 + num2);
									}
									else
									{
										num5 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 8 + num2);
										if (num5 != -1)
										{
											goto Block_56;
										}
										num16 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 16 + num2);
										goto IL_9AC;
									}
								}
								goto IL_B55;
							}
							int num19 = (int)array3[1];
							int num20;
							if (num16 == -1)
							{
								num20 = -1;
							}
							else
							{
								num21 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 40 + num2);
								num13 = 0;
								num12 = 6;
								for (;;)
								{
									num11 = (num13 + num12) / 2;
									num10 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num11 * 64 + 16 + num2);
									num5 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num11 * 64 + 32 + num2);
									if (num21 < num10 + num5)
									{
										if (num10 <= num21)
										{
											break;
										}
										num12 = num11 - 1;
									}
									else
									{
										num13 = num11 + 1;
									}
								}
								num18 = num11;
								num14 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num18 * 64 + 8 + num2);
								num20 = num14;
							}
							if (num19 == num20)
							{
								num14 = num15;
								while (num14 != num16)
								{
									if (num14 != -1)
									{
										num14 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num14 + 16 + num2);
									}
									else
									{
										num18 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 8 + num2);
										if (num18 != -1)
										{
											goto Block_52;
										}
										num16 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 16 + num2);
										goto IL_9AC;
									}
								}
								break;
							}
							if ((int)array3[1] == num17)
							{
								goto Block_53;
							}
							array3 = (object[])array3[4];
						}
						num3 = num7;
						continue;
						Block_52:
						num9 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num18 + 56 + num2);
						array4 = new object[]
						{
							default(object),
							default(object),
							0,
							default(object),
							array3,
							default(object),
							default(object),
							num7
						};
						array4[1] = num18;
						array4[5] = 1;
						array3 = array4;
						num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num18 + 56 + num2);
						continue;
						Block_53:
						num3 = num7;
						continue;
						IL_B55:
						num3 = num7;
						continue;
						Block_56:
						num10 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num5 + 56 + num2);
						array4 = new object[]
						{
							default(object),
							default(object),
							0,
							default(object),
							array3,
							default(object),
							default(object),
							num7
						};
						array4[1] = num5;
						array4[5] = 1;
						array3 = array4;
						num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num5 + 56 + num2);
					}
					else
					{
						int num6;
						int num22;
						bool flag;
						bool flag2;
						bool flag3;
						bool flag4;
						ButtonInfo buttonInfo;
						bool flag5;
						bool flag6;
						bool flag7;
						bool flag8;
						bool flag9;
						bool flag10;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,StupidTemplate.Classes.ButtonInfo&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.String), ref num3, ref num4, ref num6, ex, ref num22, ref flag, ref flag2, ref flag3, ref flag4, ref buttonInfo, ref flag5, ref flag6, ref flag7, ref flag8, ref flag9, ref flag10, buttonText, Main.DefineUninitializedDataTypeNameFormatFlags[num3]);
					}
				}
				num4 = 136;
				return;
				IL_CC:
				if (num10 != -1)
				{
					goto IL_D7;
				}
				goto IL_30E;
				IL_D7:
				num9 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num10 + 48 + num2);
				if (1 == num9)
				{
					goto IL_F7;
				}
				if (3 == num9)
				{
					goto IL_292;
				}
				goto IL_30E;
				IL_F7:
				num5 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num10 + 16 + num2);
				if (num5 == -1)
				{
					goto IL_142;
				}
				Type type;
				if ((type = array2[num5]) != null)
				{
					goto IL_128;
				}
				array2[num5] = Type.GetTypeFromHandle(array[num5]);
				type = array2[num5];
				IL_128:
				if (type.IsInstanceOfType(array4[6]))
				{
					goto IL_142;
				}
				num10 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num10 + 8 + num2);
				goto IL_CC;
				IL_142:
				num16 = num10;
				num8 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 24 + num2) + 16 + num2);
				num14 = (int)array4[0];
				IL_168:
				if (num14 != num8)
				{
					goto IL_1EA;
				}
				num11 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 56 + num2);
				ex = array4[6];
				array3 = (object[])array3[4];
				object[] array5 = new object[8];
				array5[2] = 1;
				array5[4] = array3;
				array5[6] = array4[6];
				array5[0] = (int)array4[0];
				array5[1] = num16;
				array5[5] = 0;
				array3 = array5;
				num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 56 + num2);
				goto IL_57;
				IL_1EA:
				num15 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num14 + 8 + num2);
				if (num15 == -1)
				{
					goto IL_27F;
				}
				num11 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num15 + 56 + num2);
				array3 = (object[])array3[4];
				array5 = new object[8];
				array5[2] = 1;
				array5[4] = array3;
				array5[6] = array4[6];
				array5[0] = (int)array4[0];
				array5[1] = num15;
				array5[3] = num16;
				array5[5] = 1;
				array3 = array5;
				num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num15 + 56 + num2);
				goto IL_57;
				IL_27F:
				num14 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num14 + 16 + num2);
				goto IL_168;
				IL_292:
				num11 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num10 + 40 + num2);
				ex = array4[6];
				array3 = (object[])array3[4];
				array5 = new object[8];
				array5[2] = 1;
				array5[4] = array3;
				array5[6] = array4[6];
				array5[0] = (int)array4[0];
				array5[1] = num10;
				array5[5] = 2;
				array3 = array5;
				num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num10 + 40 + num2);
				goto IL_57;
				IL_30E:
				array3 = (object[])array3[4];
				Exception ex2 = array4[6];
				int num23 = (int)array4[0];
				IL_32D:
				num10 = num3;
				num11 = num10;
				num12 = 0;
				num13 = 6;
				IL_33C:
				num17 = (num12 + num13) / 2;
				num18 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num17 * 48 + 16 + num2);
				num21 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num17 * 48 + 24 + num2);
				if (num11 >= num18 + num21)
				{
					goto IL_384;
				}
				if (num18 > num11)
				{
					goto IL_38C;
				}
				num8 = num17;
				num16 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 456 + num8 * 48 + 8 + num2);
				num5 = num16;
				num14 = num5;
				goto IL_3B4;
				IL_384:
				num12 = num17 + 1;
				goto IL_33C;
				IL_38C:
				num13 = num17 - 1;
				goto IL_33C;
				IL_3B4:
				if (array3 != null)
				{
					goto IL_3BF;
				}
				goto IL_554;
				IL_3BF:
				if ((int)array3[2] != 0)
				{
					goto IL_482;
				}
				int num24 = (int)array3[1];
				if (num5 != -1)
				{
					goto IL_3E3;
				}
				int num25 = -1;
				goto IL_469;
				IL_3E3:
				int num26 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num5 + 40 + num2);
				num21 = 0;
				num18 = 6;
				IL_3F7:
				num17 = (num21 + num18) / 2;
				num13 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num17 * 64 + 16 + num2);
				num12 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num17 * 64 + 32 + num2);
				if (num26 >= num13 + num12)
				{
					goto IL_43F;
				}
				if (num13 > num26)
				{
					goto IL_447;
				}
				num16 = num17;
				num8 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num16 * 64 + 8 + num2);
				num25 = num8;
				goto IL_469;
				IL_43F:
				num21 = num17 + 1;
				goto IL_3F7;
				IL_447:
				num18 = num17 - 1;
				goto IL_3F7;
				IL_469:
				if (num24 != num25)
				{
					goto IL_471;
				}
				goto IL_554;
				IL_471:
				array3 = (object[])array3[4];
				goto IL_3B4;
				IL_482:
				num15 = (int)array3[5];
				if (num15 == 0 || num15 == 1)
				{
					goto IL_4A3;
				}
				if (num15 != 2)
				{
					goto IL_4A2;
				}
				array4 = array3;
				num10 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + (int)array4[1] + 8 + num2);
				goto IL_CC;
				IL_4A2:
				IL_4A3:
				int num27 = (int)array3[1];
				if (num5 != -1)
				{
					goto IL_4B8;
				}
				int num28 = -1;
				goto IL_53E;
				IL_4B8:
				num11 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num5 + 40 + num2);
				num12 = 0;
				num13 = 6;
				IL_4CC:
				num17 = (num12 + num13) / 2;
				num18 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num17 * 64 + 16 + num2);
				num21 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num17 * 64 + 32 + num2);
				if (num11 >= num18 + num21)
				{
					goto IL_514;
				}
				if (num18 > num11)
				{
					goto IL_51C;
				}
				num8 = num17;
				num16 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + 792 + num8 * 64 + 8 + num2);
				num28 = num16;
				goto IL_53E;
				IL_514:
				num12 = num17 + 1;
				goto IL_4CC;
				IL_51C:
				num13 = num17 - 1;
				goto IL_4CC;
				IL_53E:
				if (num27 != num28)
				{
					goto IL_543;
				}
				goto IL_554;
				IL_543:
				array3 = (object[])array3[4];
				goto IL_3B4;
				IL_554:
				if (-1 != num5)
				{
					goto IL_5FC;
				}
				num16 = num14;
				IL_561:
				if (num16 != -1)
				{
					goto IL_56D;
				}
				int num29 = 1;
				throw ex2;
				IL_56D:
				num8 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 8 + num2);
				if (num8 == -1)
				{
					goto IL_5E9;
				}
				num26 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num8 + 56 + num2);
				array4 = new object[8];
				array4[2] = 1;
				array4[4] = array3;
				array4[6] = ex2;
				array4[0] = num14;
				array4[1] = -1;
				array4[3] = -1;
				array4[5] = 0;
				array3 = array4;
				num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num8 + 56 + num2);
				goto IL_57;
				IL_5E9:
				num16 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num16 + 16 + num2);
				goto IL_561;
				IL_5FC:
				num9 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num5 + 32 + num2);
				num11 = num9;
				IL_60E:
				if (num11 != -1)
				{
					goto IL_626;
				}
				num5 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num5 + 16 + num2);
				goto IL_3B4;
				IL_626:
				num13 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num11 + 48 + num2);
				if (1 == num13)
				{
					goto IL_653;
				}
				if (3 == num13)
				{
					goto IL_7C7;
				}
				num5 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num5 + 16 + num2);
				goto IL_3B4;
				IL_653:
				num12 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num11 + 16 + num2);
				if (num12 == -1)
				{
					goto IL_69F;
				}
				Type type2;
				if ((type2 = array2[num12]) != null)
				{
					goto IL_684;
				}
				array2[num12] = Type.GetTypeFromHandle(array[num12]);
				type2 = array2[num12];
				IL_684:
				if (type2.IsInstanceOfType(ex2))
				{
					goto IL_69F;
				}
				num11 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num11 + 8 + num2);
				goto IL_60E;
				IL_69F:
				num26 = num11;
				num21 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + *(ref SourceNameGetClassID.getNewLinegetApplicationId + num26 + 24 + num2) + 16 + num2);
				num18 = (num14 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_6CA:
				if (num18 != num21)
				{
					goto IL_736;
				}
				int num30 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num26 + 56 + num2);
				ex = ex2;
				array4 = new object[8];
				array4[2] = 1;
				array4[4] = array3;
				array4[6] = ex2;
				array4[0] = num14;
				array4[1] = num26;
				array4[5] = 0;
				array3 = array4;
				num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num26 + 56 + num2);
				goto IL_57;
				IL_736:
				num17 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num18 + 8 + num2);
				if (num17 == -1)
				{
					goto IL_7B4;
				}
				num30 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num17 + 56 + num2);
				array4 = new object[8];
				array4[2] = 1;
				array4[4] = array3;
				array4[6] = ex2;
				array4[0] = num14;
				array4[1] = num17;
				array4[3] = num26;
				array4[5] = 1;
				array3 = array4;
				num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num17 + 56 + num2);
				goto IL_57;
				IL_7B4:
				num18 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num18 + 16 + num2);
				goto IL_6CA;
				IL_7C7:
				num30 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num11 + 40 + num2);
				ex = ex2;
				array4 = new object[8];
				array4[2] = 1;
				array4[4] = array3;
				array4[6] = ex2;
				array4[0] = num14;
				array4[1] = num11;
				array4[5] = 2;
				array3 = array4;
				num3 = *(ref SourceNameGetClassID.getNewLinegetApplicationId + num11 + 40 + num2);
				goto IL_57;
			}
			catch (Exception ex3)
			{
				int num29;
				if (num29 != 1)
				{
					Exception ex2 = ex3;
					int num23 = -1;
					goto IL_32D;
				}
				throw ex3;
			}
		}

		// Token: 0x06000977 RID: 2423 RVA: 0x00056BCC File Offset: 0x00054DCC
		private static void getBuildBgtUn(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 168;
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x00056BE8 File Offset: 0x00054DE8
		public static void CreateReference(bool isRightHanded)
		{
			int num = 132;
			int num2 = 132;
			num2 = 132;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean), ref num, ref num2, ref num3, ref flag, isRightHanded, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 132;
		}

		// Token: 0x06000979 RID: 2425 RVA: 0x00056C30 File Offset: 0x00054E30
		private static ButtonInfo LargeObjectHeapCompactionModePrimaryInteropAssemblyAttribute(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			ButtonInfo[] array = A_3[A_4];
			A_5 = array;
			ButtonInfo[] array2 = A_5;
			A_6 = array2;
			int num = 0;
			A_7 = num;
			A_0 = 178;
			ButtonInfo result;
			return result;
		}

		// Token: 0x0600097A RID: 2426 RVA: 0x00056CA4 File Offset: 0x00054EA4
		public Main()
		{
			int num = 184;
			int num2 = 184;
			num2 = 184;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Menu.Main), ref num, ref num2, ref num3, this, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 184;
		}

		// Token: 0x0600097B RID: 2427 RVA: 0x00056CE8 File Offset: 0x00054EE8
		private static void CancellationTokenDictionaryKeyCollection(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			A_26.layer = 2;
			Object.Destroy(A_26.GetComponent<Rigidbody>());
			A_26.GetComponent<BoxCollider>().isTrigger = true;
			A_26.transform.parent = Main.menu.transform;
			A_26.transform.rotation = Quaternion.identity;
			A_26.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
			A_26.transform.localPosition = new Vector3(0.56f, 0f, -0.55f);
			A_26.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
			A_26.AddComponent<Button>().relatedText = "ExitCat";
			bool flag = Main.outlineMenu;
			A_28 = flag;
			int num = ((!A_28) ? 1 : 0) * 1 + 73;
			A_0 = num;
		}

		// Token: 0x0600097C RID: 2428 RVA: 0x00056E60 File Offset: 0x00055060
		private static void EntryPointNotFoundExceptionIIDIEnumSTOREASSEMBLY(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_3.layer = 2;
			bool flag = !Main.checkBoxButtons;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 8 + 90;
			A_0 = num;
		}

		// Token: 0x0600097D RID: 2429 RVA: 0x00056ED8 File Offset: 0x000550D8
		private static void CloneProperties(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			Object.Destroy(A_32.GetComponent<Rigidbody>());
			A_32.GetComponent<BoxCollider>().isTrigger = true;
			A_32.transform.parent = Main.menu.transform;
			A_32.transform.rotation = Quaternion.identity;
			A_32.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
			A_32.transform.localPosition = new Vector3(0.56f, 0f, 0.17f);
			A_32.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
			A_32.AddComponent<Button>().relatedText = "NextPage";
			bool flag = Main.outlineMenu;
			A_37 = flag;
			int num = ((!A_37) ? 1 : 0) * 1 + 82;
			A_0 = num;
		}

		// Token: 0x0600097E RID: 2430 RVA: 0x00057038 File Offset: 0x00055238
		private static void DaylightBiasPm(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/NameTagAnchor/NameTagCanvas/Text Outer").GetComponent<TMP_Text>().text = "<color=black>" + PhotonNetwork.LocalPlayer.NickName + "</color>";
			A_1 = 56;
		}

		// Token: 0x0600097F RID: 2431 RVA: 0x00057080 File Offset: 0x00055280
		private static void ContextPropertiessetSalt(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_1 = 4;
			A_2 = 157;
		}

		// Token: 0x06000980 RID: 2432 RVA: 0x000570A8 File Offset: 0x000552A8
		private static void PermissionSetEnumeratorInternalReserveProcessor(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			bool flag = Main.outlineMenu;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 60;
			A_0 = num;
		}

		// Token: 0x06000981 RID: 2433 RVA: 0x00057104 File Offset: 0x00055304
		private static void setSafeWaitHandlePermissionTokenFactory(ref int A_0, ref int A_1, ref int A_2, Main A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000982 RID: 2434 RVA: 0x00057128 File Offset: 0x00055328
		private static void DTTscale(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_1 = 0;
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x00057140 File Offset: 0x00055340
		private static void SoapPinned(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_21.method.Invoke();
			A_1 = 60;
			A_2 = 32;
		}

		// Token: 0x06000984 RID: 2436 RVA: 0x00057178 File Offset: 0x00055378
		private static void DefineManifestResourceIReportMatchMembershipCondition(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			ButtonInfo buttonInfo = A_19[A_20];
			A_21 = buttonInfo;
			bool enabled = A_21.enabled;
			A_22 = enabled;
			int num = ((!A_22) ? 1 : 0) * 6 + 28;
			A_0 = num;
		}

		// Token: 0x06000985 RID: 2437 RVA: 0x00057204 File Offset: 0x00055404
		private static void AtEntitiesFImmediateBind(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			Main.RecreateMenu();
			A_1 = 0;
		}

		// Token: 0x06000986 RID: 2438 RVA: 0x00057224 File Offset: 0x00055424
		private static void NoUserOverrideVarArgs(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_1 = 0;
		}

		// Token: 0x06000987 RID: 2439 RVA: 0x0005723C File Offset: 0x0005543C
		private static void DocTypeEntryAssembly(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			Main.CreateMenu();
			Main.RecenterMenu(Settings.rightHanded, A_5);
			bool flag = Main.reference == null;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 9;
			A_0 = num;
		}

		// Token: 0x06000988 RID: 2440 RVA: 0x000572B8 File Offset: 0x000554B8
		private static void ManagedPattern(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			Object.Destroy(A_26.GetComponent<Rigidbody>());
			A_26.GetComponent<BoxCollider>().isTrigger = true;
			A_26.transform.parent = Main.menu.transform;
			A_26.transform.rotation = Quaternion.identity;
			A_26.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
			A_26.transform.localPosition = new Vector3(0.56f, 0f, -0.55f);
			A_26.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
			A_26.AddComponent<Button>().relatedText = "ExitCat";
			bool flag = Main.outlineMenu;
			A_28 = flag;
			int num = ((!A_28) ? 1 : 0) * 1 + 73;
			A_0 = num;
		}

		// Token: 0x06000989 RID: 2441 RVA: 0x00057418 File Offset: 0x00055618
		private static void ServerFaultindex(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			ButtonInfo[] array = A_16[A_17];
			A_18 = array;
			ButtonInfo[] array2 = A_18;
			A_19 = array2;
			int num = 0;
			A_20 = num;
			A_0 = 35;
		}

		// Token: 0x0600098A RID: 2442 RVA: 0x00057488 File Offset: 0x00055688
		private static void ScopeTreegetAction(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 169;
		}

		// Token: 0x0600098B RID: 2443 RVA: 0x000574A0 File Offset: 0x000556A0
		private static void LongEnumEqualityComparerAdministerIsolatedStorageByUser(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			Main.pageNumber = 0;
			A_0 = 169;
		}

		// Token: 0x0600098C RID: 2444 RVA: 0x000574C4 File Offset: 0x000556C4
		private static void LdelemNeverCloseOverNull(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = (Settings.rightHanded ? 1 : 0) * 1 + 2;
			A_0 = num;
		}

		// Token: 0x0600098D RID: 2445 RVA: 0x00057508 File Offset: 0x00055708
		private static void RuntimeAssemblyISTOREBINDREFERENCETOASSEMBLYFLAGS(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_0 = 23;
		}

		// Token: 0x0600098E RID: 2446 RVA: 0x00057520 File Offset: 0x00055720
		private static void setAssertionIStructuralComparable(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			ColorChanger colorChanger = A_3.AddComponent<ColorChanger>();
			A_17 = colorChanger;
			bool enabled = A_20.enabled;
			A_18 = enabled;
			int num = ((!A_18) ? 1 : 0) * 1 + 105;
			A_0 = num;
		}

		// Token: 0x0600098F RID: 2447 RVA: 0x000575A0 File Offset: 0x000557A0
		private static void TypeDependencyAttributesetUI(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_0 = 131;
		}

		// Token: 0x06000990 RID: 2448 RVA: 0x000575B8 File Offset: 0x000557B8
		private static void tailHighUMALQURA(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			bool flag = A_40 < A_39.Length;
			A_41 = flag;
			int num = (A_41 ? 1 : 0) * -2 + 86;
			A_0 = num;
		}

		// Token: 0x06000991 RID: 2449 RVA: 0x00057624 File Offset: 0x00055824
		private static void NormalizationFormIFormattable(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = Settings.stupidpoo == 1;
			A_31 = flag;
			int num = ((!A_31) ? 1 : 0) * 3 + 49;
			A_0 = num;
		}

		// Token: 0x06000992 RID: 2450 RVA: 0x00057688 File Offset: 0x00055888
		private static void getBuildNumbergetInvariantCulture(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_3 = gameObject;
			bool flag = !UnityInput.Current.GetKey(113);
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 88;
			A_0 = num;
		}

		// Token: 0x06000993 RID: 2451 RVA: 0x00057710 File Offset: 0x00055910
		private static void SoapServicesgetRequestedExecutionLevel(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 162;
		}

		// Token: 0x06000994 RID: 2452 RVA: 0x00057728 File Offset: 0x00055928
		private static void GetDaysInMonthvalue(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 168;
		}

		// Token: 0x06000995 RID: 2453 RVA: 0x00057740 File Offset: 0x00055940
		private static ButtonInfo GetExceptionCodeLSATRANSLATEDSID(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			ButtonInfo[][] buttons = Buttons.buttons;
			A_3 = buttons;
			int num = 0;
			A_4 = num;
			A_0 = 180;
			ButtonInfo result;
			return result;
		}

		// Token: 0x06000996 RID: 2454 RVA: 0x0005778C File Offset: 0x0005598C
		private static void IsValidAttributeValueAsyncVoidMethodBuilder(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			bool flag = A_9.disableMethod != null;
			A_14 = flag;
			int num = ((!A_14) ? 1 : 0) * 4 + 154;
			A_0 = num;
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x000577F4 File Offset: 0x000559F4
		private static void InternetFormatterAlgorithm(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_19 = gameObject;
			bool flag = !UnityInput.Current.GetKey(113);
			A_20 = flag;
			int num = ((!A_20) ? 1 : 0) * 1 + 65;
			A_0 = num;
		}

		// Token: 0x06000998 RID: 2456 RVA: 0x0005787C File Offset: 0x00055A7C
		private static void getItemByteTokenEncoding(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			Main.RecreateMenu();
			A_1 = 0;
		}

		// Token: 0x06000999 RID: 2457 RVA: 0x0005789C File Offset: 0x00055A9C
		private static void CopyXConstants(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = ((!Settings.rightHanded) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x000578E0 File Offset: 0x00055AE0
		private static void ToLowergetInstalledUICulture(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			Main.menu.transform.position = GorillaTagger.Instance.rightHandTransform.position;
			Quaternion rotation = GorillaTagger.Instance.rightHandTransform.rotation;
			A_6 = rotation;
			Vector3 vector = A_6.eulerAngles;
			A_7 = vector;
			vector = A_7 + new Vector3(0f, 0f, 180f);
			A_7 = vector;
			Main.menu.transform.rotation = Quaternion.Euler(A_7);
			A_0 = 131;
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x000579A4 File Offset: 0x00055BA4
		private static void getHasElementTypeEncryptValue(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_22 = gameObject;
			A_22.transform.parent = Main.menu.transform;
			A_22.transform.rotation = Quaternion.identity;
			A_22.transform.localScale = new Vector3(0.035f, 0.92f, 0.092f);
			A_22.transform.localPosition = new Vector3(0.56f, 0f, 0.55f);
			A_22.GetComponent<Renderer>().material.color = Main.outlineColor;
			ColorChanger colorChanger = A_19.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.buttonColors[0];
			A_8.Start();
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_23 = text;
			A_23.text = "Leave Current";
			A_23.font = Settings.currentFont;
			A_23.fontSize = 1;
			A_23.color = Settings.textColors[0];
			A_23.alignment = 4;
			A_23.resizeTextForBestFit = true;
			A_23.resizeTextMinSize = 0;
			RectTransform component = A_23.GetComponent<RectTransform>();
			A_24 = component;
			A_24.localPosition = Vector3.zero;
			A_24.sizeDelta = new Vector2(0.2f, 0.03f);
			A_24.localPosition = new Vector3(0.064f, 0f, 0.21f);
			A_24.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			bool flag = Main.returnEnabled;
			A_25 = flag;
			int num = ((!A_25) ? 1 : 0) * 5 + 70;
			A_0 = num;
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x00057C74 File Offset: 0x00055E74
		private static void ResourceTableMappingEntryFieldIdLinkedSlot(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)") != null;
			A_29 = flag;
			int num = ((!A_29) ? 1 : 0) * 1 + 45;
			A_0 = num;
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x00057CDC File Offset: 0x00055EDC
		private static void GetLocalsgetRevisionVersion(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 149;
		}

		// Token: 0x0600099E RID: 2462 RVA: 0x00057CF4 File Offset: 0x00055EF4
		private static void DigitValuesSetting(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_24 = A_3;
			Debug.LogError(string.Format("{0} // Error with mod {1} at {2}: {3}", new object[]
			{
				"<b>Solar</b>",
				A_21.buttonText,
				A_24.StackTrace,
				A_24.Message
			}));
			A_1 = 60;
			A_2 = 32;
		}

		// Token: 0x0600099F RID: 2463 RVA: 0x00057D94 File Offset: 0x00055F94
		private static void PropertiesToTestgetAppDomainManagerAssembly(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_35 = gameObject;
			A_35.transform.parent = Main.menu.transform;
			A_35.transform.rotation = Quaternion.identity;
			A_35.transform.localScale = new Vector3(0.035f, 0.82f, 0.092f);
			A_35.transform.localPosition = new Vector3(0.56f, 0f, 0.3f);
			A_35.GetComponent<Renderer>().material.color = Main.outlineColor;
			ColorChanger colorChanger = A_32.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.buttonColors[0];
			A_8.Start();
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_11 = text;
			A_11.font = Settings.currentFont;
			A_11.text = "<<<<<<";
			A_11.fontSize = 1;
			A_11.color = Settings.textColors[0];
			A_11.alignment = 4;
			A_11.resizeTextForBestFit = true;
			A_11.resizeTextMinSize = 0;
			RectTransform component = A_11.GetComponent<RectTransform>();
			A_14 = component;
			A_14.localPosition = Vector3.zero;
			A_14.sizeDelta = new Vector2(0.2f, 0.03f);
			A_14.localPosition = new Vector3(0.064f, 0f, 0.115f);
			A_14.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			GameObject gameObject2 = GameObject.CreatePrimitive(3);
			A_32 = gameObject2;
			bool flag = !UnityInput.Current.GetKey(113);
			A_36 = flag;
			int num = ((!A_36) ? 1 : 0) * 1 + 80;
			A_0 = num;
		}

		// Token: 0x060009A0 RID: 2464 RVA: 0x0005808C File Offset: 0x0005628C
		private static void CONNECTDATAActivatedClientTypeEntry(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_1 = 4;
			A_2 = 151;
		}

		// Token: 0x060009A1 RID: 2465 RVA: 0x000580B4 File Offset: 0x000562B4
		public static ButtonInfo GetIndex(string buttonText)
		{
			int num = 173;
			int num2 = 173;
			num2 = 173;
			ButtonInfo result;
			while (num2 != 0)
			{
				int num3;
				ButtonInfo[][] array;
				int num4;
				ButtonInfo[] array2;
				ButtonInfo[] array3;
				int num5;
				ButtonInfo buttonInfo;
				bool flag;
				ButtonInfo buttonInfo2;
				result = calli(StupidTemplate.Classes.ButtonInfo(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Classes.ButtonInfo[][]&,System.Int32&,StupidTemplate.Classes.ButtonInfo[]&,StupidTemplate.Classes.ButtonInfo[]&,System.Int32&,StupidTemplate.Classes.ButtonInfo&,System.Boolean&,StupidTemplate.Classes.ButtonInfo&,System.String), ref num, ref num2, ref num3, ref array, ref num4, ref array2, ref array3, ref num5, ref buttonInfo, ref flag, ref buttonInfo2, buttonText, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 173;
			return result;
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x0005810C File Offset: 0x0005630C
		private static void CurrentEraWaitOne(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			bool flag = !A_19;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 4 + 112;
			A_0 = num;
		}

		// Token: 0x060009A3 RID: 2467 RVA: 0x00058170 File Offset: 0x00056370
		private static void ApplicationTrustManagerTransliteratedEnglish(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/NameTagAnchor/NameTagCanvas/Text Inner").GetComponent<TMP_Text>().text = "<color=blue>" + PhotonNetwork.LocalPlayer.NickName + "</color>";
			bool flag = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/NameTagAnchor/NameTagCanvas/Text Outer") != null;
			A_33 = flag;
			int num = ((!A_33) ? 1 : 0) * 1 + 53;
			A_0 = num;
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x00058208 File Offset: 0x00056408
		private static void CallConvThiscallNN(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_13 = A_3;
			Debug.LogError(string.Format("{0} // Error initializing at {1}: {2}", "<b>Solar</b>", A_13.StackTrace, A_13.Message));
			A_1 = 60;
			A_2 = 22;
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x00058274 File Offset: 0x00056474
		private static void InternalElementTypeEXmlEntry(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = Main.fpsObject != null;
			A_14 = flag;
			int num = ((!A_14) ? 1 : 0) * 1 + 24;
			A_0 = num;
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x000582D8 File Offset: 0x000564D8
		public unsafe static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition)
		{
			RuntimeTypeHandle[] array = new RuntimeTypeHandle[1];
			Type[] array2 = new Type[1];
			array[0] = typeof(object).TypeHandle;
			int num = 1;
			int num2 = num * 4;
			int num3 = 111;
			int num4 = 111;
			num4 = 111;
			try
			{
				IL_36:
				int num5;
				int num8;
				int num9;
				int num10;
				int num11;
				int num12;
				int num13;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				object[] array3;
				int num21;
				object[] array4;
				Exception ex;
				while (num4 != 0)
				{
					if (num4 == 4)
					{
						num4 = 111;
						int num6;
						num5 = num6;
						int num7 = num5;
						num8 = num3;
						num9 = num8;
						num5 = 0;
						num10 = 2;
						for (;;)
						{
							num11 = (num5 + num10) / 2;
							num12 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num11 * 40 + 8 + num2);
							num13 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num11 * 40 + num2);
							if (num9 < num12 + num13)
							{
								if (num12 <= num9)
								{
									break;
								}
								num10 = num11 - 1;
							}
							else
							{
								num5 = num11 + 1;
							}
						}
						num14 = num11;
						num15 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num14 * 40 + 16 + num2);
						num16 = num15;
						num13 = num7;
						num12 = 0;
						num11 = 2;
						for (;;)
						{
							num10 = (num12 + num11) / 2;
							num5 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num10 * 40 + 8 + num2);
							num9 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num10 * 40 + num2);
							if (num13 < num5 + num9)
							{
								if (num5 <= num13)
								{
									break;
								}
								num11 = num10 - 1;
							}
							else
							{
								num12 = num10 + 1;
							}
						}
						num14 = num10;
						num17 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num14 * 40 + 16 + num2);
						num15 = num17;
						num9 = num7;
						num5 = 0;
						num10 = 2;
						for (;;)
						{
							num11 = (num5 + num10) / 2;
							num12 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num11 * 72 + 16 + num2);
							num13 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num11 * 72 + num2);
							if (num9 < num12 + num13)
							{
								if (num12 <= num9)
								{
									break;
								}
								num10 = num11 - 1;
							}
							else
							{
								num5 = num11 + 1;
							}
						}
						num14 = num11;
						num18 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num14 * 72 + 8 + num2);
						num17 = num18;
						for (;;)
						{
							IL_957:
							if (array3 == null || (int)array3[2] == 0)
							{
								num9 = num15;
								while (num9 != num16)
								{
									if (num9 != -1)
									{
										num9 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num9 + 16 + num2);
									}
									else
									{
										num5 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 8 + num2);
										if (num5 != -1)
										{
											goto Block_56;
										}
										num16 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 16 + num2);
										goto IL_957;
									}
								}
								goto IL_AFD;
							}
							int num19 = (int)array3[1];
							int num20;
							if (num16 == -1)
							{
								num20 = -1;
							}
							else
							{
								num21 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 40 + num2);
								num13 = 0;
								num12 = 2;
								for (;;)
								{
									num11 = (num13 + num12) / 2;
									num10 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num11 * 72 + 16 + num2);
									num5 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num11 * 72 + num2);
									if (num21 < num10 + num5)
									{
										if (num10 <= num21)
										{
											break;
										}
										num12 = num11 - 1;
									}
									else
									{
										num13 = num11 + 1;
									}
								}
								num18 = num11;
								num14 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num18 * 72 + 8 + num2);
								num20 = num14;
							}
							if (num19 == num20)
							{
								num14 = num15;
								while (num14 != num16)
								{
									if (num14 != -1)
									{
										num14 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num14 + 16 + num2);
									}
									else
									{
										num18 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 8 + num2);
										if (num18 != -1)
										{
											goto Block_52;
										}
										num16 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 16 + num2);
										goto IL_957;
									}
								}
								break;
							}
							if ((int)array3[1] == num17)
							{
								goto Block_53;
							}
							array3 = (object[])array3[0];
						}
						num3 = num7;
						continue;
						Block_52:
						num9 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num18 + 48 + num2);
						array4 = new object[8];
						array4[2] = 0;
						array4[0] = array3;
						array4[4] = num7;
						array4[1] = num18;
						array4[6] = 0;
						array3 = array4;
						num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num18 + 48 + num2);
						continue;
						Block_53:
						num3 = num7;
						continue;
						IL_AFD:
						num3 = num7;
						continue;
						Block_56:
						num10 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num5 + 48 + num2);
						array4 = new object[8];
						array4[2] = 0;
						array4[0] = array3;
						array4[4] = num7;
						array4[1] = num5;
						array4[6] = 0;
						array3 = array4;
						num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num5 + 48 + num2);
					}
					else
					{
						int num6;
						bool flag;
						bool flag2;
						Quaternion quaternion;
						Vector3 vector;
						bool flag3;
						GameObject gameObject;
						Vector3 vector2;
						bool flag4;
						bool flag5;
						Ray ray;
						RaycastHit raycastHit;
						bool flag6;
						bool flag7;
						Button button;
						bool flag8;
						calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Boolean&,System.Boolean&,UnityEngine.Quaternion&,UnityEngine.Vector3&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.Vector3&,System.Boolean&,System.Boolean&,UnityEngine.Ray&,UnityEngine.RaycastHit&,System.Boolean&,System.Boolean&,StupidTemplate.Classes.Button&,System.Boolean&,System.Boolean,System.Boolean), ref num3, ref num4, ref num6, ex, ref flag, ref flag2, ref quaternion, ref vector, ref flag3, ref gameObject, ref vector2, ref flag4, ref flag5, ref ray, ref raycastHit, ref flag6, ref flag7, ref button, ref flag8, isKeyboardCondition, isRightHanded, Main.DefineUninitializedDataTypeNameFormatFlags[num3]);
					}
				}
				num4 = 111;
				return;
				IL_AD:
				if (num10 != -1)
				{
					goto IL_B8;
				}
				goto IL_2EC;
				IL_B8:
				num9 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num10 + num2);
				if (1 == num9)
				{
					goto IL_D5;
				}
				if (0 == num9)
				{
					goto IL_270;
				}
				goto IL_2EC;
				IL_D5:
				num5 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num10 + 8 + num2);
				if (num5 == -1)
				{
					goto IL_120;
				}
				Type type;
				if ((type = array2[num5]) != null)
				{
					goto IL_105;
				}
				array2[num5] = Type.GetTypeFromHandle(array[num5]);
				type = array2[num5];
				IL_105:
				if (type.IsInstanceOfType(array4[7]))
				{
					goto IL_120;
				}
				num10 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num10 + 24 + num2);
				goto IL_AD;
				IL_120:
				num16 = num10;
				num8 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 16 + num2) + 16 + num2);
				num14 = (int)array4[3];
				IL_146:
				if (num14 != num8)
				{
					goto IL_1C8;
				}
				num11 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 48 + num2);
				ex = array4[7];
				array3 = (object[])array3[0];
				object[] array5 = new object[8];
				array5[2] = 1;
				array5[0] = array3;
				array5[7] = array4[7];
				array5[3] = (int)array4[3];
				array5[1] = num16;
				array5[6] = 2;
				array3 = array5;
				num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 48 + num2);
				goto IL_36;
				IL_1C8:
				num15 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num14 + 8 + num2);
				if (num15 == -1)
				{
					goto IL_25D;
				}
				num11 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num15 + 48 + num2);
				array3 = (object[])array3[0];
				array5 = new object[8];
				array5[2] = 1;
				array5[0] = array3;
				array5[7] = array4[7];
				array5[3] = (int)array4[3];
				array5[1] = num15;
				array5[5] = num16;
				array5[6] = 0;
				array3 = array5;
				num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num15 + 48 + num2);
				goto IL_36;
				IL_25D:
				num14 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num14 + 16 + num2);
				goto IL_146;
				IL_270:
				num11 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num10 + 56 + num2);
				ex = array4[7];
				array3 = (object[])array3[0];
				array5 = new object[8];
				array5[2] = 1;
				array5[0] = array3;
				array5[7] = array4[7];
				array5[3] = (int)array4[3];
				array5[1] = num10;
				array5[6] = 1;
				array3 = array5;
				num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num10 + 56 + num2);
				goto IL_36;
				IL_2EC:
				array3 = (object[])array3[0];
				Exception ex2 = array4[7];
				int num22 = (int)array4[3];
				IL_30B:
				num10 = num3;
				num11 = num10;
				num12 = 0;
				num13 = 2;
				IL_31A:
				num17 = (num12 + num13) / 2;
				num18 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num17 * 40 + 8 + num2);
				num21 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num17 * 40 + num2);
				if (num11 >= num18 + num21)
				{
					goto IL_358;
				}
				if (num18 > num11)
				{
					goto IL_360;
				}
				num8 = num17;
				num16 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 120 + num8 * 40 + 16 + num2);
				num5 = num16;
				num14 = num5;
				goto IL_386;
				IL_358:
				num12 = num17 + 1;
				goto IL_31A;
				IL_360:
				num13 = num17 - 1;
				goto IL_31A;
				IL_386:
				if (array3 != null)
				{
					goto IL_391;
				}
				goto IL_520;
				IL_391:
				if ((int)array3[2] != 0)
				{
					goto IL_451;
				}
				int num23 = (int)array3[1];
				if (num5 != -1)
				{
					goto IL_3B5;
				}
				int num24 = -1;
				goto IL_438;
				IL_3B5:
				int num25 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num5 + 40 + num2);
				num21 = 0;
				num18 = 2;
				IL_3C9:
				num17 = (num21 + num18) / 2;
				num13 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num17 * 72 + 16 + num2);
				num12 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num17 * 72 + num2);
				if (num25 >= num13 + num12)
				{
					goto IL_40E;
				}
				if (num13 > num25)
				{
					goto IL_416;
				}
				num16 = num17;
				num8 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num16 * 72 + 8 + num2);
				num24 = num8;
				goto IL_438;
				IL_40E:
				num21 = num17 + 1;
				goto IL_3C9;
				IL_416:
				num18 = num17 - 1;
				goto IL_3C9;
				IL_438:
				if (num23 != num24)
				{
					goto IL_440;
				}
				goto IL_520;
				IL_440:
				array3 = (object[])array3[0];
				goto IL_386;
				IL_451:
				num15 = (int)array3[6];
				if (num15 == 2 || num15 == 0)
				{
					goto IL_472;
				}
				if (num15 != 1)
				{
					goto IL_471;
				}
				array4 = array3;
				num10 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + (int)array4[1] + 24 + num2);
				goto IL_AD;
				IL_471:
				IL_472:
				int num26 = (int)array3[1];
				if (num5 != -1)
				{
					goto IL_487;
				}
				int num27 = -1;
				goto IL_50A;
				IL_487:
				num11 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num5 + 40 + num2);
				num12 = 0;
				num13 = 2;
				IL_49B:
				num17 = (num12 + num13) / 2;
				num18 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num17 * 72 + 16 + num2);
				num21 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num17 * 72 + num2);
				if (num11 >= num18 + num21)
				{
					goto IL_4E0;
				}
				if (num18 > num11)
				{
					goto IL_4E8;
				}
				num8 = num17;
				num16 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + 240 + num8 * 72 + 8 + num2);
				num27 = num16;
				goto IL_50A;
				IL_4E0:
				num12 = num17 + 1;
				goto IL_49B;
				IL_4E8:
				num13 = num17 - 1;
				goto IL_49B;
				IL_50A:
				if (num26 != num27)
				{
					goto IL_50F;
				}
				goto IL_520;
				IL_50F:
				array3 = (object[])array3[0];
				goto IL_386;
				IL_520:
				if (-1 != num5)
				{
					goto IL_5C8;
				}
				num16 = num14;
				IL_52D:
				if (num16 != -1)
				{
					goto IL_539;
				}
				int num28 = 1;
				throw ex2;
				IL_539:
				num8 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 8 + num2);
				if (num8 == -1)
				{
					goto IL_5B5;
				}
				num25 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num8 + 48 + num2);
				array4 = new object[8];
				array4[2] = 1;
				array4[0] = array3;
				array4[7] = ex2;
				array4[3] = num14;
				array4[1] = -1;
				array4[5] = -1;
				array4[6] = 2;
				array3 = array4;
				num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num8 + 48 + num2);
				goto IL_36;
				IL_5B5:
				num16 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num16 + 16 + num2);
				goto IL_52D;
				IL_5C8:
				num9 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num5 + num2);
				num11 = num9;
				IL_5D7:
				if (num11 != -1)
				{
					goto IL_5EF;
				}
				num5 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num5 + 16 + num2);
				goto IL_386;
				IL_5EF:
				num13 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num11 + num2);
				if (1 == num13)
				{
					goto IL_619;
				}
				if (0 == num13)
				{
					goto IL_78D;
				}
				num5 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num5 + 16 + num2);
				goto IL_386;
				IL_619:
				num12 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num11 + 8 + num2);
				if (num12 == -1)
				{
					goto IL_665;
				}
				Type type2;
				if ((type2 = array2[num12]) != null)
				{
					goto IL_649;
				}
				array2[num12] = Type.GetTypeFromHandle(array[num12]);
				type2 = array2[num12];
				IL_649:
				if (type2.IsInstanceOfType(ex2))
				{
					goto IL_665;
				}
				num11 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num11 + 24 + num2);
				goto IL_5D7;
				IL_665:
				num25 = num11;
				num21 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num25 + 16 + num2) + 16 + num2);
				num18 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
				IL_690:
				if (num18 != num21)
				{
					goto IL_6FC;
				}
				int num29 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num25 + 48 + num2);
				ex = ex2;
				array4 = new object[8];
				array4[2] = 1;
				array4[0] = array3;
				array4[7] = ex2;
				array4[3] = num14;
				array4[1] = num25;
				array4[6] = 2;
				array3 = array4;
				num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num25 + 48 + num2);
				goto IL_36;
				IL_6FC:
				num17 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num18 + 8 + num2);
				if (num17 == -1)
				{
					goto IL_77A;
				}
				num29 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num17 + 48 + num2);
				array4 = new object[8];
				array4[2] = 1;
				array4[0] = array3;
				array4[7] = ex2;
				array4[3] = num14;
				array4[1] = num17;
				array4[5] = num25;
				array4[6] = 0;
				array3 = array4;
				num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num17 + 48 + num2);
				goto IL_36;
				IL_77A:
				num18 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num18 + 16 + num2);
				goto IL_690;
				IL_78D:
				num29 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num11 + 56 + num2);
				ex = ex2;
				array4 = new object[8];
				array4[2] = 1;
				array4[0] = array3;
				array4[7] = ex2;
				array4[3] = num14;
				array4[1] = num11;
				array4[6] = 1;
				array3 = array4;
				num3 = *(ref getSuiteNameSetPermission.DiscardBufferedDataCMSHASHTRANSFORMIDENTITY + num11 + 56 + num2);
				goto IL_36;
			}
			catch (Exception ex3)
			{
				int num28;
				if (num28 != 1)
				{
					Exception ex2 = ex3;
					int num22 = -1;
					goto IL_30B;
				}
				throw ex3;
			}
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x00058EA0 File Offset: 0x000570A0
		private static void MaxDegreeOfParallelismEVENTACTIVITYCTRLSETID(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_17.colorInfo = Settings.buttonColors[1];
			A_0 = 107;
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x00058ED4 File Offset: 0x000570D4
		private static void getMutexRightsgetXmlNsForClrTypeWithAssembly(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 168;
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x00058EF0 File Offset: 0x000570F0
		private static void getStructuralComparersetEmbedded(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdtext") != null;
			A_30 = flag;
			int num = ((!A_30) ? 1 : 0) * 1 + 47;
			A_0 = num;
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x00058F58 File Offset: 0x00057158
		private static void MemberChildStoreTransactionData(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, bool A_4)
		{
			Main.reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
			Main.reference.GetComponent<Renderer>().material.color = Color.white;
			Main.reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
			Main.reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
			Main.buttonCollider = Main.reference.GetComponent<SphereCollider>();
			A_1 = 0;
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x00058FFC File Offset: 0x000571FC
		private static void setUseSaltMuiResourceTypeIdIntIntegerIds(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			Main.pageNumber++;
			bool flag = Main.pageNumber > A_4;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 142;
			A_0 = num;
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x00059074 File Offset: 0x00057274
		private static void WindowsPrincipalDelegateEntry(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			Main.RecreateMenu();
			A_1 = 0;
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x00059094 File Offset: 0x00057294
		private static void OpenWriteCngSignatureID(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			ColorChanger colorChanger = A_32.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.buttonColors[0];
			A_8.Start();
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_11 = text;
			A_11.font = Settings.currentFont;
			A_11.text = "<<<<<<";
			A_11.fontSize = 1;
			A_11.color = Settings.textColors[0];
			A_11.alignment = 4;
			A_11.resizeTextForBestFit = true;
			A_11.resizeTextMinSize = 0;
			RectTransform component = A_11.GetComponent<RectTransform>();
			A_14 = component;
			A_14.localPosition = Vector3.zero;
			A_14.sizeDelta = new Vector2(0.2f, 0.03f);
			A_14.localPosition = new Vector3(0.064f, 0f, 0.115f);
			A_14.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_32 = gameObject;
			bool flag = !UnityInput.Current.GetKey(113);
			A_36 = flag;
			int num = ((!A_36) ? 1 : 0) * 1 + 80;
			A_0 = num;
		}

		// Token: 0x060009AE RID: 2478 RVA: 0x000592C8 File Offset: 0x000574C8
		private static void PrepareConstrainedRegionsSameDomain(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool rightControllerSecondaryButton = ControllerInputPoller.instance.rightControllerSecondaryButton;
			A_4 = rightControllerSecondaryButton;
			bool key = UnityInput.Current.GetKey(113);
			A_5 = key;
			bool flag = Main.menu == null;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 7;
			A_0 = num;
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x00059370 File Offset: 0x00057570
		private static void ConverterTYPEFLAGFPREDECLID(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_1 = 60;
			A_2 = 22;
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x00059394 File Offset: 0x00057594
		private static void ReserveProcessorasyncWaiter(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			Main.fpsObject = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			Main.fpsObject.font = Settings.currentFont;
			Text text = Main.fpsObject;
			DateTime now = DateTime.Now;
			A_16 = now;
			text.text = A_16.ToString("MM/dd/yyyy h:mm tt");
			Main.fpsObject.color = Settings.textColors[0];
			Main.fpsObject.fontSize = 1;
			Main.fpsObject.supportRichText = true;
			Main.fpsObject.fontStyle = 0;
			Main.fpsObject.alignment = 4;
			Main.fpsObject.horizontalOverflow = 1;
			Main.fpsObject.resizeTextForBestFit = true;
			Main.fpsObject.resizeTextMinSize = 0;
			RectTransform component = Main.fpsObject.GetComponent<RectTransform>();
			A_17 = component;
			A_17.localPosition = Vector3.zero;
			A_17.sizeDelta = new Vector2(0.26f, 0.01f);
			A_17.position = new Vector3(0.06f, 0.2f, 0.17f);
			A_17.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			bool disconnectButton = Settings.disconnectButton;
			A_18 = disconnectButton;
			int num = ((!A_18) ? 1 : 0) * 5 + 64;
			A_0 = num;
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x00059578 File Offset: 0x00057778
		private static void StreamingContextIsAutoClass(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = ((A_17 < A_16.Length) ? 1 : 0) * -12 + 38;
			A_0 = num;
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x000595B4 File Offset: 0x000577B4
		private static void CULTURESavePolicyLevel(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			ColorChanger colorChanger = A_19.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.buttonColors[0];
			A_8.Start();
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_23 = text;
			A_23.text = "Leave Current";
			A_23.font = Settings.currentFont;
			A_23.fontSize = 1;
			A_23.color = Settings.textColors[0];
			A_23.alignment = 4;
			A_23.resizeTextForBestFit = true;
			A_23.resizeTextMinSize = 0;
			RectTransform component = A_23.GetComponent<RectTransform>();
			A_24 = component;
			A_24.localPosition = Vector3.zero;
			A_24.sizeDelta = new Vector2(0.2f, 0.03f);
			A_24.localPosition = new Vector3(0.064f, 0f, 0.21f);
			A_24.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			bool flag = Main.returnEnabled;
			A_25 = flag;
			int num = ((!A_25) ? 1 : 0) * 5 + 70;
			A_0 = num;
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x000597BC File Offset: 0x000579BC
		private static void getCryptoKeySecurityEvidence(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_1 = 0;
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x000597D8 File Offset: 0x000579D8
		private static void opLessThanOrEqualSingleArrayTypeInfo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			int num = (Buttons.buttons[Main.buttonsType].Length + Settings.buttonsPerPage - 1) / Settings.buttonsPerPage - 1;
			A_4 = num;
			bool flag = A_16 == "PreviousPage";
			A_5 = flag;
			int num2 = ((!A_5) ? 1 : 0) * 3 + 137;
			A_0 = num2;
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x00059874 File Offset: 0x00057A74
		public static void RPCProtection()
		{
			int num = 183;
			int num2 = 183;
			num2 = 183;
			while (num2 != 0)
			{
				int num3;
				GorillaNot gorillaNot;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,GorillaNot&), ref num, ref num2, ref num3, ref gorillaNot, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 183;
		}

		// Token: 0x060009B6 RID: 2486 RVA: 0x000598B8 File Offset: 0x00057AB8
		private static void ReturnGetModule(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 159;
		}

		// Token: 0x060009B7 RID: 2487 RVA: 0x000598D0 File Offset: 0x00057AD0
		private static void BestFitEnabledsetPrivateBinPath(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = A_4 | A_5;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 5 + 8;
			A_0 = num;
		}

		// Token: 0x060009B8 RID: 2488 RVA: 0x0005993C File Offset: 0x00057B3C
		private static void IsDiscretionaryAclCanonicalgetIdentities(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			bool flag = A_9.method != null;
			A_15 = flag;
			int num = ((!A_15) ? 1 : 0) * 4 + 161;
			A_0 = num;
		}

		// Token: 0x060009B9 RID: 2489 RVA: 0x000599A4 File Offset: 0x00057BA4
		private static void getFieldHandleGetAuditRules(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_26 = gameObject;
			bool flag = !UnityInput.Current.GetKey(113);
			A_27 = flag;
			int num = ((!A_27) ? 1 : 0) * 1 + 71;
			A_0 = num;
		}

		// Token: 0x060009BA RID: 2490 RVA: 0x00059A2C File Offset: 0x00057C2C
		private static void CMSSECTIONIDPROGIDREDIRECTIONSECTIONCanceled(ref int A_0, ref int A_1, ref int A_2, ref GorillaNot A_3)
		{
			GorillaNot instance = GorillaNot.instance;
			A_3 = instance;
			A_3.rpcErrorMax = int.MaxValue;
			A_3.rpcCallLimit = int.MaxValue;
			A_3.logErrorMax = int.MaxValue;
			PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
			PhotonNetwork.QuickResends = int.MaxValue;
			PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
			PhotonNetwork.RemoveBufferedRPCs(GorillaTagger.Instance.myVRRig.ViewID, null, null);
			PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
			PhotonNetwork.SendAllOutgoingCommands();
			GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
			A_1 = 0;
		}

		// Token: 0x060009BB RID: 2491 RVA: 0x00059AF8 File Offset: 0x00057CF8
		private static void OpenRemoteBaseKeyLockAssemblyPath(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_38 = gameObject;
			A_38.transform.parent = Main.menu.transform;
			A_38.transform.rotation = Quaternion.identity;
			A_38.transform.localScale = new Vector3(0.035f, 0.82f, 0.092f);
			A_38.transform.localPosition = new Vector3(0.56f, 0f, 0.17f);
			A_38.GetComponent<Renderer>().material.color = Main.outlineColor;
			ColorChanger colorChanger = A_32.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.buttonColors[0];
			A_8.Start();
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_11 = text;
			A_11.font = Settings.currentFont;
			A_11.text = ">>>>>>";
			A_11.fontSize = 1;
			A_11.color = Settings.textColors[0];
			A_11.alignment = 4;
			A_11.resizeTextForBestFit = true;
			A_11.resizeTextMinSize = 0;
			RectTransform component = A_11.GetComponent<RectTransform>();
			A_14 = component;
			A_14.localPosition = Vector3.zero;
			A_14.sizeDelta = new Vector2(0.2f, 0.03f);
			A_14.localPosition = new Vector3(0.064f, 0f, 0.065f);
			A_14.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			ButtonInfo[] array = Enumerable.ToArray<ButtonInfo>(Enumerable.Take<ButtonInfo>(Enumerable.Skip<ButtonInfo>(Buttons.buttons[Main.buttonsType], Main.pageNumber * Settings.buttonsPerPage), Settings.buttonsPerPage));
			A_39 = array;
			int num = 0;
			A_40 = num;
			A_0 = 85;
		}

		// Token: 0x060009BC RID: 2492 RVA: 0x00059DD4 File Offset: 0x00057FD4
		private static void getDependentOSDataTrustedCredentialManagerAccess(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			A_32.layer = 2;
			Object.Destroy(A_32.GetComponent<Rigidbody>());
			A_32.GetComponent<BoxCollider>().isTrigger = true;
			A_32.transform.parent = Main.menu.transform;
			A_32.transform.rotation = Quaternion.identity;
			A_32.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
			A_32.transform.localPosition = new Vector3(0.56f, 0f, 0.17f);
			A_32.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
			A_32.AddComponent<Button>().relatedText = "NextPage";
			bool flag = Main.outlineMenu;
			A_37 = flag;
			int num = ((!A_37) ? 1 : 0) * 1 + 82;
			A_0 = num;
		}

		// Token: 0x060009BD RID: 2493 RVA: 0x00059F4C File Offset: 0x0005814C
		private static void ImpersonationKeyContainerPermissionAttribute(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_8.alignment = 4;
			A_8.fontStyle = 0;
			A_8.resizeTextForBestFit = true;
			A_8.resizeTextMinSize = 0;
			RectTransform component = A_8.GetComponent<RectTransform>();
			A_11 = component;
			A_11.localPosition = Vector3.zero;
			A_11.sizeDelta = new Vector2(0.2f, 0.03f);
			A_11.localPosition = new Vector3(0.064f, 0f, 0.017f - A_19 / 2.6f);
			A_11.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			A_0 = 104;
		}

		// Token: 0x060009BE RID: 2494 RVA: 0x0005A05C File Offset: 0x0005825C
		private static void IConstructionReturnMessageHasProperties(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_0 = 117;
		}

		// Token: 0x060009BF RID: 2495 RVA: 0x0005A074 File Offset: 0x00058274
		private static void PtrToStructureFileIOPermissionAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			A_0 = 30;
		}

		// Token: 0x060009C0 RID: 2496 RVA: 0x0005A08C File Offset: 0x0005828C
		private static void FullTrustZoneTrustedNamedPermissionSets(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 159;
		}

		// Token: 0x060009C1 RID: 2497 RVA: 0x0005A0A8 File Offset: 0x000582A8
		private static void CRYPTOIDINFONumberNegativePattern(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref Quaternion A_6, ref Vector3 A_7, ref bool A_8, ref GameObject A_9, ref Vector3 A_10, ref bool A_11, ref bool A_12, ref Ray A_13, ref RaycastHit A_14, ref bool A_15, ref bool A_16, ref Button A_17, ref bool A_18, bool A_19, bool A_20)
		{
			A_1 = 4;
			A_2 = 119;
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x0005A0D0 File Offset: 0x000582D0
		private static void AuditRuleFactoryCdecl(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			Object.Destroy(A_3.GetComponent<Rigidbody>());
			A_3.GetComponent<BoxCollider>().isTrigger = true;
			A_3.transform.parent = Main.menu.transform;
			A_3.transform.rotation = Quaternion.identity;
			A_3.transform.localScale = new Vector3(0.09f, 0.08f, 0.08f);
			A_3.transform.localPosition = new Vector3(0.56f, 0.314f, 0.08f - A_19);
			A_3.AddComponent<Button>().relatedText = A_20.buttonText;
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_12 = gameObject;
			A_12.transform.parent = Main.menu.transform;
			A_12.transform.rotation = Quaternion.identity;
			A_12.transform.localScale = new Vector3(0.035f, 0.092f, 0.092f);
			A_12.transform.localPosition = new Vector3(0.56f, 0.314f, 0.08f - A_19);
			A_12.GetComponent<Renderer>().material.color = Main.outlineColor;
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_13 = text;
			A_13.font = Settings.currentFont;
			A_13.text = A_20.buttonText;
			bool flag = A_20.overlapText != null;
			A_14 = flag;
			int num = ((!A_14) ? 1 : 0) * 1 + 99;
			A_0 = num;
		}

		// Token: 0x060009C3 RID: 2499 RVA: 0x0005A330 File Offset: 0x00058530
		private static void CodeConnectAccessUnsafeToString(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			Main.tick = true;
			A_0 = 19;
		}

		// Token: 0x060009C4 RID: 2500 RVA: 0x0005A354 File Offset: 0x00058554
		private static void setTargetStrongNameFreeBuffer(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref int A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref ButtonInfo A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, string A_16)
		{
			A_0 = 166;
		}

		// Token: 0x060009C5 RID: 2501 RVA: 0x0005A36C File Offset: 0x0005856C
		private static void SystemAclDefaultedGetHINSTANCE(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			bool flag = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/NameTagAnchor/NameTagCanvas/Text Outer") != null;
			A_33 = flag;
			int num = ((!A_33) ? 1 : 0) * 1 + 53;
			A_0 = num;
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x0005A3D4 File Offset: 0x000585D4
		private static void TypeFilterItemInfo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			ButtonInfo[][] buttons = Buttons.buttons;
			A_16 = buttons;
			int num = 0;
			A_17 = num;
			A_0 = 37;
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x0005A418 File Offset: 0x00058618
		private static ButtonInfo FUNCFLAGFDEFAULTBINDGetClassID(ref int A_0, ref int A_1, ref int A_2, ref ButtonInfo[][] A_3, ref int A_4, ref ButtonInfo[] A_5, ref ButtonInfo[] A_6, ref int A_7, ref ButtonInfo A_8, ref bool A_9, ref ButtonInfo A_10, string A_11)
		{
			int num = A_7 + 1;
			A_7 = num;
			int num2 = ((A_7 < A_6.Length) ? 1 : 0) * -4 + 179;
			A_0 = num2;
			ButtonInfo result;
			return result;
		}

		// Token: 0x060009C8 RID: 2504 RVA: 0x0005A47C File Offset: 0x0005867C
		private static void getPMDesignatorgetExceptionState(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_8.supportRichText = true;
			A_8.fontSize = 1;
			bool enabled = A_20.enabled;
			A_10 = enabled;
			int num = ((!A_10) ? 1 : 0) * 1 + 95;
			A_0 = num;
		}

		// Token: 0x060009C9 RID: 2505 RVA: 0x0005A504 File Offset: 0x00058704
		private static void SegmentExceptionDispatchInfo(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_8.text = A_20.overlapText;
			A_8.supportRichText = true;
			A_8.fontSize = 1;
			bool enabled = A_20.enabled;
			A_10 = enabled;
			int num = ((!A_10) ? 1 : 0) * 1 + 95;
			A_0 = num;
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x0005A5A8 File Offset: 0x000587A8
		private static void FlattenHierarchyCharSetAuto(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, bool A_4)
		{
			Main.reference.transform.parent = GorillaTagger.Instance.leftHandTransform;
			A_0 = 135;
		}

		// Token: 0x060009CB RID: 2507 RVA: 0x0005A5DC File Offset: 0x000587DC
		public static void CreateButton(float offset, ButtonInfo method)
		{
			int num = 87;
			int num2 = 87;
			num2 = 87;
			while (num2 != 0)
			{
				int num3;
				GameObject gameObject;
				bool flag;
				bool flag2;
				bool flag3;
				GameObject gameObject2;
				Text text;
				bool flag4;
				bool flag5;
				RectTransform rectTransform;
				GameObject gameObject3;
				Text text2;
				bool flag6;
				bool flag7;
				RectTransform rectTransform2;
				ColorChanger colorChanger;
				bool flag8;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.GameObject&,System.Boolean&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.UI.Text&,System.Boolean&,System.Boolean&,UnityEngine.RectTransform&,UnityEngine.GameObject&,UnityEngine.UI.Text&,System.Boolean&,System.Boolean&,UnityEngine.RectTransform&,StupidTemplate.Classes.ColorChanger&,System.Boolean&,System.Single,StupidTemplate.Classes.ButtonInfo), ref num, ref num2, ref num3, ref gameObject, ref flag, ref flag2, ref flag3, ref gameObject2, ref text, ref flag4, ref flag5, ref rectTransform, ref gameObject3, ref text2, ref flag6, ref flag7, ref rectTransform2, ref colorChanger, ref flag8, offset, method, Main.DefineUninitializedDataTypeNameFormatFlags[num]);
			}
			num2 = 87;
		}

		// Token: 0x060009CC RID: 2508 RVA: 0x0005A634 File Offset: 0x00058834
		private static void getFusionLogGetInArg(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref TrailRenderer A_10, ref bool A_11, ref bool A_12, ref Exception A_13, ref bool A_14, ref DateTime A_15, ref ButtonInfo[][] A_16, ref int A_17, ref ButtonInfo[] A_18, ref ButtonInfo[] A_19, ref int A_20, ref ButtonInfo A_21, ref bool A_22, ref bool A_23, ref Exception A_24, ref Exception A_25, ref bool A_26, ref float A_27, ref bool A_28, ref bool A_29, ref bool A_30, ref bool A_31, ref bool A_32, ref bool A_33)
		{
			int num = ((A_20 < A_19.Length) ? 1 : 0) * -9 + 36;
			A_0 = num;
		}

		// Token: 0x060009CD RID: 2509 RVA: 0x0005A670 File Offset: 0x00058870
		private static void SerializedStoreExecuteKey(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref bool A_6, ref GameObject A_7, ref ColorChanger A_8, ref Canvas A_9, ref CanvasScaler A_10, ref Text A_11, ref float A_12, ref int A_13, ref RectTransform A_14, ref bool A_15, ref DateTime A_16, ref RectTransform A_17, ref bool A_18, ref GameObject A_19, ref bool A_20, ref bool A_21, ref GameObject A_22, ref Text A_23, ref RectTransform A_24, ref bool A_25, ref GameObject A_26, ref bool A_27, ref bool A_28, ref GameObject A_29, ref Text A_30, ref RectTransform A_31, ref GameObject A_32, ref bool A_33, ref bool A_34, ref GameObject A_35, ref bool A_36, ref bool A_37, ref GameObject A_38, ref ButtonInfo[] A_39, ref int A_40, ref bool A_41)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_7 = gameObject;
			A_7.transform.parent = Main.menu.transform;
			A_7.transform.rotation = Quaternion.identity;
			A_7.transform.localScale = new Vector3(0.095f, 0.92f, 0.97f);
			A_7.transform.localPosition = new Vector3(0.5f, 0f, 0f);
			A_7.GetComponent<Renderer>().material.color = Main.outlineColor;
			ColorChanger colorChanger = Main.menuBackground.AddComponent<ColorChanger>();
			A_8 = colorChanger;
			A_8.colorInfo = Settings.backgroundColor;
			A_8.Start();
			Main.canvasObject = new GameObject();
			Main.canvasObject.transform.parent = Main.menu.transform;
			Canvas canvas = Main.canvasObject.AddComponent<Canvas>();
			A_9 = canvas;
			CanvasScaler canvasScaler = Main.canvasObject.AddComponent<CanvasScaler>();
			A_10 = canvasScaler;
			Main.canvasObject.AddComponent<GraphicRaycaster>();
			A_9.renderMode = 2;
			A_10.dynamicPixelsPerUnit = 2500f;
			Text text = new GameObject
			{
				transform = 
				{
					parent = Main.canvasObject.transform
				}
			}.AddComponent<Text>();
			A_11 = text;
			A_11.font = Settings.currentFont;
			Text text2 = A_11;
			string text3 = "Selenite - Fps: ";
			float num = Mathf.Ceil(1f / Time.unscaledDeltaTime);
			A_12 = num;
			string text4 = A_12.ToString();
			string text5 = " | Page: ";
			int num2 = Main.pageNumber + 1;
			A_13 = num2;
			text2.text = text3 + text4 + text5 + A_13.ToString();
			A_11.fontSize = 1;
			A_11.color = Settings.textColors[0];
			A_11.supportRichText = true;
			A_11.fontStyle = 0;
			A_11.alignment = 4;
			A_11.resizeTextForBestFit = true;
			A_11.resizeTextMinSize = 0;
			RectTransform component = A_11.GetComponent<RectTransform>();
			A_14 = component;
			A_14.localPosition = Vector3.zero;
			A_14.sizeDelta = new Vector2(0.24f, 0.04f);
			A_14.position = new Vector3(0.06f, 0f, 0.16f);
			A_14.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			bool flag = Main.sideBarEnabled;
			A_15 = flag;
			int num3 = ((!A_15) ? 1 : 0) * 1 + 62;
			A_0 = num3;
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x0005AA40 File Offset: 0x00058C40
		private static void InvalidOperationEnumOpCantHappenThaiBuddhistCalendar(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref GameObject A_7, ref Text A_8, ref bool A_9, ref bool A_10, ref RectTransform A_11, ref GameObject A_12, ref Text A_13, ref bool A_14, ref bool A_15, ref RectTransform A_16, ref ColorChanger A_17, ref bool A_18, float A_19, ButtonInfo A_20)
		{
			A_8.color = Settings.textColors[0];
			A_8.alignment = 4;
			A_8.fontStyle = 0;
			A_8.resizeTextForBestFit = true;
			A_8.resizeTextMinSize = 0;
			RectTransform component = A_8.GetComponent<RectTransform>();
			A_11 = component;
			A_11.localPosition = Vector3.zero;
			A_11.sizeDelta = new Vector2(0.2f, 0.03f);
			A_11.localPosition = new Vector3(0.064f, 0f, 0.017f - A_19 / 2.6f);
			A_11.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			A_0 = 104;
		}

		// Token: 0x060009CF RID: 2511 RVA: 0x0005AB70 File Offset: 0x00058D70
		private static void ProcessMessageFinishGetAbbreviatedDayName()
		{
			Main.DefineUninitializedDataTypeNameFormatFlags = new IntPtr[186];
			Main.DefineUninitializedDataTypeNameFormatFlags[0] = ldftn(getOffsetsetSerializationFormatter);
			Main.DefineUninitializedDataTypeNameFormatFlags[1] = ldftn(LdelemNeverCloseOverNull);
			Main.DefineUninitializedDataTypeNameFormatFlags[2] = ldftn(InternalArrayTypeEgetUniqueKeyContainerName);
			Main.DefineUninitializedDataTypeNameFormatFlags[3] = ldftn(CopyXConstants);
			Main.DefineUninitializedDataTypeNameFormatFlags[4] = ldftn(PrepareConstrainedRegionsSameDomain);
			Main.DefineUninitializedDataTypeNameFormatFlags[5] = ldftn(MarshalNativeToManagedIsolationDllName);
			Main.DefineUninitializedDataTypeNameFormatFlags[6] = ldftn(BleUnsetAsR);
			Main.DefineUninitializedDataTypeNameFormatFlags[7] = ldftn(BestFitEnabledsetPrivateBinPath);
			Main.DefineUninitializedDataTypeNameFormatFlags[8] = ldftn(DocTypeEntryAssembly);
			Main.DefineUninitializedDataTypeNameFormatFlags[9] = ldftn(HashComRedirectionProxy);
			Main.DefineUninitializedDataTypeNameFormatFlags[10] = ldftn(DisposeHashElementDigestMethod);
			Main.DefineUninitializedDataTypeNameFormatFlags[11] = ldftn(AppDomainManagerInitializationOptionsgetPayloadNames);
			Main.DefineUninitializedDataTypeNameFormatFlags[12] = ldftn(LoadPolicyLevelFromStringPercentPositivePattern);
			Main.DefineUninitializedDataTypeNameFormatFlags[13] = ldftn(EncodedEnumTypeOperational);
			Main.DefineUninitializedDataTypeNameFormatFlags[14] = ldftn(ResourceManagerAuthorityThisOrganizationSid);
			Main.DefineUninitializedDataTypeNameFormatFlags[15] = ldftn(FinalizationHelperCanWrite);
			Main.DefineUninitializedDataTypeNameFormatFlags[16] = ldftn(CodeConnectAccessUnsafeToString);
			Main.DefineUninitializedDataTypeNameFormatFlags[17] = ldftn(SpngetAccess);
			Main.DefineUninitializedDataTypeNameFormatFlags[18] = ldftn(NonGenericToGenericEnumeratorgetKeySpec);
			Main.DefineUninitializedDataTypeNameFormatFlags[19] = ldftn(getRequestingAssemblyBinaryMethodReturnMessage);
			Main.DefineUninitializedDataTypeNameFormatFlags[20] = ldftn(ConverterTYPEFLAGFPREDECLID);
			Main.DefineUninitializedDataTypeNameFormatFlags[21] = ldftn(CallConvThiscallNN);
			Main.DefineUninitializedDataTypeNameFormatFlags[22] = ldftn(RuntimeAssemblyISTOREBINDREFERENCETOASSEMBLYFLAGS);
			Main.DefineUninitializedDataTypeNameFormatFlags[23] = ldftn(InternalElementTypeEXmlEntry);
			Main.DefineUninitializedDataTypeNameFormatFlags[24] = ldftn(ProxyAttributeDeletedAccount);
			Main.DefineUninitializedDataTypeNameFormatFlags[25] = ldftn(TypeFilterItemInfo);
			Main.DefineUninitializedDataTypeNameFormatFlags[26] = ldftn(ServerFaultindex);
			Main.DefineUninitializedDataTypeNameFormatFlags[27] = ldftn(DefineManifestResourceIReportMatchMembershipCondition);
			Main.DefineUninitializedDataTypeNameFormatFlags[28] = ldftn(RemoveAccessConvertTimeBySystemTimeZoneId);
			Main.DefineUninitializedDataTypeNameFormatFlags[29] = ldftn(PtrToStructureFileIOPermissionAttribute);
			Main.DefineUninitializedDataTypeNameFormatFlags[30] = ldftn(SoapPinned);
			Main.DefineUninitializedDataTypeNameFormatFlags[31] = ldftn(DigitValuesSetting);
			Main.DefineUninitializedDataTypeNameFormatFlags[32] = ldftn(setTaggetSectionID);
			Main.DefineUninitializedDataTypeNameFormatFlags[33] = ldftn(DefaultKeySetKeyContainerPermissionAccessEntryEnumerator);
			Main.DefineUninitializedDataTypeNameFormatFlags[34] = ldftn(DestroyCryptoStream);
			Main.DefineUninitializedDataTypeNameFormatFlags[35] = ldftn(getFusionLogGetInArg);
			Main.DefineUninitializedDataTypeNameFormatFlags[36] = ldftn(ValueCountgetGlobalAssemblyCache);
			Main.DefineUninitializedDataTypeNameFormatFlags[37] = ldftn(StreamingContextIsAutoClass);
			Main.DefineUninitializedDataTypeNameFormatFlags[38] = ldftn(addCancelKeyPressDeleteLocalDataStore);
			Main.DefineUninitializedDataTypeNameFormatFlags[39] = ldftn(pOctetStringgetReturnTypeCustomAttributes);
			Main.DefineUninitializedDataTypeNameFormatFlags[40] = ldftn(MetadataSectionSchemaVersiongetIsParamDef);
			Main.DefineUninitializedDataTypeNameFormatFlags[41] = ldftn(ReasonTokenListCount);
			Main.DefineUninitializedDataTypeNameFormatFlags[42] = ldftn(RemotingAssertLogLevel);
			Main.DefineUninitializedDataTypeNameFormatFlags[43] = ldftn(ResourceManagerLookingForResourceSetCountry);
			Main.DefineUninitializedDataTypeNameFormatFlags[44] = ldftn(ResourceTableMappingEntryFieldIdLinkedSlot);
			Main.DefineUninitializedDataTypeNameFormatFlags[45] = ldftn(NowAllocHGlobal);
			Main.DefineUninitializedDataTypeNameFormatFlags[46] = ldftn(getStructuralComparersetEmbedded);
			Main.DefineUninitializedDataTypeNameFormatFlags[47] = ldftn(StrongNameKeyGenEventChannelAttribute);
			Main.DefineUninitializedDataTypeNameFormatFlags[48] = ldftn(NormalizationFormIFormattable);
			Main.DefineUninitializedDataTypeNameFormatFlags[49] = ldftn(SoapRTLOSVERSIONINFOEX);
			Main.DefineUninitializedDataTypeNameFormatFlags[50] = ldftn(ApplicationTrustManagerTransliteratedEnglish);
			Main.DefineUninitializedDataTypeNameFormatFlags[51] = ldftn(TypeContractsAreForAnd);
			Main.DefineUninitializedDataTypeNameFormatFlags[52] = ldftn(SystemAclDefaultedGetHINSTANCE);
			Main.DefineUninitializedDataTypeNameFormatFlags[53] = ldftn(DaylightBiasPm);
			Main.DefineUninitializedDataTypeNameFormatFlags[54] = ldftn(DefaultNameClaimTypeEnableEvents);
			Main.DefineUninitializedDataTypeNameFormatFlags[55] = ldftn(AsDispatchFoundMonthPatternFlag);
			Main.DefineUninitializedDataTypeNameFormatFlags[56] = ldftn(MemoryFailPointIsNestedFamily);
			Main.DefineUninitializedDataTypeNameFormatFlags[57] = ldftn(InvalidLocalPush);
			Main.DefineUninitializedDataTypeNameFormatFlags[58] = ldftn(MethodOnTypeBuilderInstantiationLocalSig);
			Main.DefineUninitializedDataTypeNameFormatFlags[59] = ldftn(PermissionSetEnumeratorInternalReserveProcessor);
			Main.DefineUninitializedDataTypeNameFormatFlags[60] = ldftn(SerializedStoreExecuteKey);
			Main.DefineUninitializedDataTypeNameFormatFlags[61] = ldftn(RunContinuationsAsynchronouslyRights);
			Main.DefineUninitializedDataTypeNameFormatFlags[62] = ldftn(ReserveProcessorasyncWaiter);
			Main.DefineUninitializedDataTypeNameFormatFlags[63] = ldftn(NumberFormatInfoReaderWriterLockTimedOutException);
			Main.DefineUninitializedDataTypeNameFormatFlags[64] = ldftn(InternetFormatterAlgorithm);
			Main.DefineUninitializedDataTypeNameFormatFlags[65] = ldftn(AllocateDataSlotReflectionMemberAccess);
			Main.DefineUninitializedDataTypeNameFormatFlags[66] = ldftn(setURINotInProgress);
			Main.DefineUninitializedDataTypeNameFormatFlags[67] = ldftn(getHasElementTypeEncryptValue);
			Main.DefineUninitializedDataTypeNameFormatFlags[68] = ldftn(CULTURESavePolicyLevel);
			Main.DefineUninitializedDataTypeNameFormatFlags[69] = ldftn(IFormatterflushStream);
			Main.DefineUninitializedDataTypeNameFormatFlags[70] = ldftn(getFieldHandleGetAuditRules);
			Main.DefineUninitializedDataTypeNameFormatFlags[71] = ldftn(CancellationTokenDictionaryKeyCollection);
			Main.DefineUninitializedDataTypeNameFormatFlags[72] = ldftn(ManagedPattern);
			Main.DefineUninitializedDataTypeNameFormatFlags[73] = ldftn(IsConsoleEnabledGetRaiseMethod);
			Main.DefineUninitializedDataTypeNameFormatFlags[74] = ldftn(getLogicalCallContextgetNativeName);
			Main.DefineUninitializedDataTypeNameFormatFlags[75] = ldftn(CrossContextChannelPerform);
			Main.DefineUninitializedDataTypeNameFormatFlags[76] = ldftn(SystemEnvironmentDOWNLOAD);
			Main.DefineUninitializedDataTypeNameFormatFlags[77] = ldftn(DoNotDisposeIIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGEXACTMATCHREQUIRED);
			Main.DefineUninitializedDataTypeNameFormatFlags[78] = ldftn(PropertiesToTestgetAppDomainManagerAssembly);
			Main.DefineUninitializedDataTypeNameFormatFlags[79] = ldftn(OpenWriteCngSignatureID);
			Main.DefineUninitializedDataTypeNameFormatFlags[80] = ldftn(getDependentOSDataTrustedCredentialManagerAccess);
			Main.DefineUninitializedDataTypeNameFormatFlags[81] = ldftn(CloneProperties);
			Main.DefineUninitializedDataTypeNameFormatFlags[82] = ldftn(OpenRemoteBaseKeyLockAssemblyPath);
			Main.DefineUninitializedDataTypeNameFormatFlags[83] = ldftn(MoveDirectoryBaseChannelObjectWithProperties);
			Main.DefineUninitializedDataTypeNameFormatFlags[84] = ldftn(MAJORVERSIONGetLibStatistics);
			Main.DefineUninitializedDataTypeNameFormatFlags[85] = ldftn(tailHighUMALQURA);
			Main.DefineUninitializedDataTypeNameFormatFlags[86] = ldftn(getOSXRIPEMD);
			Main.DefineUninitializedDataTypeNameFormatFlags[87] = ldftn(getBuildNumbergetInvariantCulture);
			Main.DefineUninitializedDataTypeNameFormatFlags[88] = ldftn(EntryPointNotFoundExceptionIIDIEnumSTOREASSEMBLY);
			Main.DefineUninitializedDataTypeNameFormatFlags[89] = ldftn(MuiResourceTypeIdStringEntryFieldIdKeyContainerPermissionAttribute);
			Main.DefineUninitializedDataTypeNameFormatFlags[90] = ldftn(AnsiBSTRMarshalercbSizeInstance);
			Main.DefineUninitializedDataTypeNameFormatFlags[91] = ldftn(CTSTKINDCOCLASS);
			Main.DefineUninitializedDataTypeNameFormatFlags[92] = ldftn(ManualResetEventSlimGetSddlForm);
			Main.DefineUninitializedDataTypeNameFormatFlags[93] = ldftn(SegmentExceptionDispatchInfo);
			Main.DefineUninitializedDataTypeNameFormatFlags[94] = ldftn(getPMDesignatorgetExceptionState);
			Main.DefineUninitializedDataTypeNameFormatFlags[95] = ldftn(ISectionreadPos);
			Main.DefineUninitializedDataTypeNameFormatFlags[96] = ldftn(InvalidOperationEnumOpCantHappenThaiBuddhistCalendar);
			Main.DefineUninitializedDataTypeNameFormatFlags[97] = ldftn(ImpersonationKeyContainerPermissionAttribute);
			Main.DefineUninitializedDataTypeNameFormatFlags[98] = ldftn(AuditRuleFactoryCdecl);
			Main.DefineUninitializedDataTypeNameFormatFlags[99] = ldftn(ArchitectureDXNN);
			Main.DefineUninitializedDataTypeNameFormatFlags[100] = ldftn(setObjectModeSXSINSTALLREFERENCESCHEMESXSSTRONGNAMESIGNEDPRIVATEASSEMBLY);
			Main.DefineUninitializedDataTypeNameFormatFlags[101] = ldftn(TypedValueEnumRunning);
			Main.DefineUninitializedDataTypeNameFormatFlags[102] = ldftn(SpaceSeparatorConfig);
			Main.DefineUninitializedDataTypeNameFormatFlags[103] = ldftn(NoValuePropgetScheduledTasks);
			Main.DefineUninitializedDataTypeNameFormatFlags[104] = ldftn(setAssertionIStructuralComparable);
			Main.DefineUninitializedDataTypeNameFormatFlags[105] = ldftn(MaxDegreeOfParallelismEVENTACTIVITYCTRLSETID);
			Main.DefineUninitializedDataTypeNameFormatFlags[106] = ldftn(FORMATFLAGSIBindCtx);
			Main.DefineUninitializedDataTypeNameFormatFlags[107] = ldftn(SoapPositiveIntegeratime);
			Main.DefineUninitializedDataTypeNameFormatFlags[108] = ldftn(ModeCNSgetIsUnicodeClass);
			Main.DefineUninitializedDataTypeNameFormatFlags[109] = ldftn(INotifyCompletionRemotingAssert);
			Main.DefineUninitializedDataTypeNameFormatFlags[110] = ldftn(MinimumRequiredVersionCreateDefaultTypeInfo);
			Main.DefineUninitializedDataTypeNameFormatFlags[111] = ldftn(CurrentEraWaitOne);
			Main.DefineUninitializedDataTypeNameFormatFlags[112] = ldftn(CreateFilesUseLegacyPathHandling);
			Main.DefineUninitializedDataTypeNameFormatFlags[113] = ldftn(AnyOtherOriginSchemegetConstructionException);
			Main.DefineUninitializedDataTypeNameFormatFlags[114] = ldftn(ToLowergetInstalledUICulture);
			Main.DefineUninitializedDataTypeNameFormatFlags[115] = ldftn(TypeDependencyAttributesetUI);
			Main.DefineUninitializedDataTypeNameFormatFlags[116] = ldftn(IConstructionReturnMessageHasProperties);
			Main.DefineUninitializedDataTypeNameFormatFlags[117] = ldftn(GetRuntimeEventsGetRect);
			Main.DefineUninitializedDataTypeNameFormatFlags[118] = ldftn(CRYPTOIDINFONumberNegativePattern);
			Main.DefineUninitializedDataTypeNameFormatFlags[119] = ldftn(AssertFailuregetIsNotPublic);
			Main.DefineUninitializedDataTypeNameFormatFlags[120] = ldftn(CreatePermanentoInst);
			Main.DefineUninitializedDataTypeNameFormatFlags[121] = ldftn(ContinueParsingpUint);
			Main.DefineUninitializedDataTypeNameFormatFlags[122] = ldftn(CheckedForAsyncIDefinitionAppId);
			Main.DefineUninitializedDataTypeNameFormatFlags[123] = ldftn(TaskToApmgetIsNestedFamily);
			Main.DefineUninitializedDataTypeNameFormatFlags[124] = ldftn(CMSSECTIONENTRYIDMETADATAgetAbbreviatedMonthNames);
			Main.DefineUninitializedDataTypeNameFormatFlags[125] = ldftn(setVersiongetBufferWidth);
			Main.DefineUninitializedDataTypeNameFormatFlags[126] = ldftn(GetHashFromHandleEntryPointNotFoundException);
			Main.DefineUninitializedDataTypeNameFormatFlags[127] = ldftn(MaxBinaryLengthAddSystemAcl);
			Main.DefineUninitializedDataTypeNameFormatFlags[128] = ldftn(getCryptoKeySecurityEvidence);
			Main.DefineUninitializedDataTypeNameFormatFlags[129] = ldftn(getLocalSignatureMetadataTokensetMonthGenitiveNames);
			Main.DefineUninitializedDataTypeNameFormatFlags[130] = ldftn(NoUserOverrideVarArgs);
			Main.DefineUninitializedDataTypeNameFormatFlags[131] = ldftn(DTTscale);
			Main.DefineUninitializedDataTypeNameFormatFlags[132] = ldftn(setSecurityZoneBuildVersion);
			Main.DefineUninitializedDataTypeNameFormatFlags[133] = ldftn(FlattenHierarchyCharSetAuto);
			Main.DefineUninitializedDataTypeNameFormatFlags[134] = ldftn(MemberChildStoreTransactionData);
			Main.DefineUninitializedDataTypeNameFormatFlags[135] = ldftn(KeysNormalizedReason);
			Main.DefineUninitializedDataTypeNameFormatFlags[136] = ldftn(opLessThanOrEqualSingleArrayTypeInfo);
			Main.DefineUninitializedDataTypeNameFormatFlags[137] = ldftn(ThreadAbortExceptionSymbolType);
			Main.DefineUninitializedDataTypeNameFormatFlags[138] = ldftn(ReadOnlyDictionaryCOREISOSTORE);
			Main.DefineUninitializedDataTypeNameFormatFlags[139] = ldftn(NoStringInterningComponentRelativePath);
			Main.DefineUninitializedDataTypeNameFormatFlags[140] = ldftn(setDisallowCodeDownloadgetTargetedPatchBand);
			Main.DefineUninitializedDataTypeNameFormatFlags[141] = ldftn(setUseSaltMuiResourceTypeIdIntIntegerIds);
			Main.DefineUninitializedDataTypeNameFormatFlags[142] = ldftn(LongEnumEqualityComparerAdministerIsolatedStorageByUser);
			Main.DefineUninitializedDataTypeNameFormatFlags[143] = ldftn(ScopeTreegetAction);
			Main.DefineUninitializedDataTypeNameFormatFlags[144] = ldftn(IsTypeVisibleFromComResize);
			Main.DefineUninitializedDataTypeNameFormatFlags[145] = ldftn(getTypeHandleCLRInstanceID);
			Main.DefineUninitializedDataTypeNameFormatFlags[146] = ldftn(removeReflectionOnlyAssemblyResolveUnsafePack);
			Main.DefineUninitializedDataTypeNameFormatFlags[147] = ldftn(SecurityAssertCollectFromClientContext);
			Main.DefineUninitializedDataTypeNameFormatFlags[148] = ldftn(GetLocalsgetRevisionVersion);
			Main.DefineUninitializedDataTypeNameFormatFlags[149] = ldftn(SubstringEqualsRemotingSurrogate);
			Main.DefineUninitializedDataTypeNameFormatFlags[150] = ldftn(CONNECTDATAActivatedClientTypeEntry);
			Main.DefineUninitializedDataTypeNameFormatFlags[151] = ldftn(FullTrustZoneTrustedNamedPermissionSets);
			Main.DefineUninitializedDataTypeNameFormatFlags[152] = ldftn(ReturnGetModule);
			Main.DefineUninitializedDataTypeNameFormatFlags[153] = ldftn(IsValidAttributeValueAsyncVoidMethodBuilder);
			Main.DefineUninitializedDataTypeNameFormatFlags[154] = ldftn(getIsPrivateCreateActContextParametersSourceDefinitionAppid);
			Main.DefineUninitializedDataTypeNameFormatFlags[155] = ldftn(ForegroundMaskInternalsVisibleToAttribute);
			Main.DefineUninitializedDataTypeNameFormatFlags[156] = ldftn(ContextPropertiessetSalt);
			Main.DefineUninitializedDataTypeNameFormatFlags[157] = ldftn(PARAMDESCDelegateWrapper);
			Main.DefineUninitializedDataTypeNameFormatFlags[158] = ldftn(encodingPaddingHelpers);
			Main.DefineUninitializedDataTypeNameFormatFlags[159] = ldftn(setTargetStrongNameFreeBuffer);
			Main.DefineUninitializedDataTypeNameFormatFlags[160] = ldftn(IsDiscretionaryAclCanonicalgetIdentities);
			Main.DefineUninitializedDataTypeNameFormatFlags[161] = ldftn(SoapServicesgetRequestedExecutionLevel);
			Main.DefineUninitializedDataTypeNameFormatFlags[162] = ldftn(getPriorityAsyncReplySink);
			Main.DefineUninitializedDataTypeNameFormatFlags[163] = ldftn(IEnumSTORECATEGORYSUBCATEGORYsetVersionCompatibility);
			Main.DefineUninitializedDataTypeNameFormatFlags[164] = ldftn(getMutexRightsgetXmlNsForClrTypeWithAssembly);
			Main.DefineUninitializedDataTypeNameFormatFlags[165] = ldftn(getBuildBgtUn);
			Main.DefineUninitializedDataTypeNameFormatFlags[166] = ldftn(GetDaysInMonthvalue);
			Main.DefineUninitializedDataTypeNameFormatFlags[167] = ldftn(ComRegisterFunctionAttributeSpn);
			Main.DefineUninitializedDataTypeNameFormatFlags[168] = ldftn(WindowsPrincipalDelegateEntry);
			Main.DefineUninitializedDataTypeNameFormatFlags[169] = ldftn(getItemByteTokenEncoding);
			Main.DefineUninitializedDataTypeNameFormatFlags[170] = ldftn(AtEntitiesFImmediateBind);
			Main.DefineUninitializedDataTypeNameFormatFlags[171] = ldftn(CFgetIsSecured);
			Main.DefineUninitializedDataTypeNameFormatFlags[172] = ldftn(TextToReferencegetRefusedSet);
			Main.DefineUninitializedDataTypeNameFormatFlags[173] = ldftn(GetExceptionCodeLSATRANSLATEDSID);
			Main.DefineUninitializedDataTypeNameFormatFlags[174] = ldftn(LargeObjectHeapCompactionModePrimaryInteropAssemblyAttribute);
			Main.DefineUninitializedDataTypeNameFormatFlags[175] = ldftn(GetAwaiterSignal);
			Main.DefineUninitializedDataTypeNameFormatFlags[176] = ldftn(PidResourceTypeIdStringSize);
			Main.DefineUninitializedDataTypeNameFormatFlags[177] = ldftn(FUNCFLAGFDEFAULTBINDGetClassID);
			Main.DefineUninitializedDataTypeNameFormatFlags[178] = ldftn(PrivateImplementationDetailsCMSSCHEMAVERSIONV);
			Main.DefineUninitializedDataTypeNameFormatFlags[179] = ldftn(AssemblyDescriptionAttributeFDisplayBind);
			Main.DefineUninitializedDataTypeNameFormatFlags[180] = ldftn(VTCFRSAPKCSSHASignatureDescription);
			Main.DefineUninitializedDataTypeNameFormatFlags[181] = ldftn(ThaiBuddhistEraSoapType);
			Main.DefineUninitializedDataTypeNameFormatFlags[182] = ldftn(CountedUtfJsonWhenAll);
			Main.DefineUninitializedDataTypeNameFormatFlags[183] = ldftn(CMSSECTIONIDPROGIDREDIRECTIONSECTIONCanceled);
			Main.DefineUninitializedDataTypeNameFormatFlags[184] = ldftn(setSafeWaitHandlePermissionTokenFactory);
			Main.DefineUninitializedDataTypeNameFormatFlags[185] = ldftn(PackForNativegetActivityOptions);
		}

		// Token: 0x04000126 RID: 294
		public static GameObject menu;

		// Token: 0x04000127 RID: 295
		public static GameObject menuBackground;

		// Token: 0x04000128 RID: 296
		public static GameObject reference;

		// Token: 0x04000129 RID: 297
		public static GameObject canvasObject;

		// Token: 0x0400012A RID: 298
		public static GameObject StumpOBJ;

		// Token: 0x0400012B RID: 299
		public static GameObject sideBar;

		// Token: 0x0400012C RID: 300
		public static GameObject sideBarLine1;

		// Token: 0x0400012D RID: 301
		public static SphereCollider buttonCollider;

		// Token: 0x0400012E RID: 302
		public static Camera TPC;

		// Token: 0x0400012F RID: 303
		public static Text fpsObject;

		// Token: 0x04000130 RID: 304
		public static Text fpsObject2;

		// Token: 0x04000131 RID: 305
		public static Text fpsObject3;

		// Token: 0x04000132 RID: 306
		public static Text fpsObject4;

		// Token: 0x04000133 RID: 307
		public static Text fpsObject5;

		// Token: 0x04000134 RID: 308
		public static Text fpsObject6;

		// Token: 0x04000135 RID: 309
		public static Text fpsObject7;

		// Token: 0x04000136 RID: 310
		public static Text fpsObject8;

		// Token: 0x04000137 RID: 311
		public static Text fpsObject9;

		// Token: 0x04000138 RID: 312
		public static Text refresher10;

		// Token: 0x04000139 RID: 313
		public static int pageNumber;

		// Token: 0x0400013A RID: 314
		public static int buttonsType;

		// Token: 0x0400013B RID: 315
		public static string name;

		// Token: 0x0400013C RID: 316
		public static int buttonClickSound;

		// Token: 0x0400013D RID: 317
		public static bool checkBoxButtons;

		// Token: 0x0400013E RID: 318
		public static Color32 outlineColor;

		// Token: 0x0400013F RID: 319
		private static bool tick;

		// Token: 0x04000140 RID: 320
		private static bool guysiactuallyhate;

		// Token: 0x04000141 RID: 321
		public static bool trailMenu;

		// Token: 0x04000142 RID: 322
		public static bool outlineMenu;

		// Token: 0x04000143 RID: 323
		public static string cat;

		// Token: 0x04000144 RID: 324
		public static string date;

		// Token: 0x04000145 RID: 325
		public static bool sideBarEnabled;

		// Token: 0x04000146 RID: 326
		private static float splashtimeout;

		// Token: 0x04000147 RID: 327
		private static Material mat;

		// Token: 0x04000148 RID: 328
		public static bool categorys;

		// Token: 0x04000149 RID: 329
		public static bool returnEnabled;

		// Token: 0x0400014A RID: 330
		public static Color colorA;

		// Token: 0x0400014B RID: 331
		public static Color colorB;

		// Token: 0x0400014C RID: 332
		public static float speed;

		// Token: 0x0400014D RID: 333
		private static IntPtr[] DefineUninitializedDataTypeNameFormatFlags;
	}
}
