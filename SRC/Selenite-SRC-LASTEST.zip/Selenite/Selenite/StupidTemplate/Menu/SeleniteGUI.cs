﻿using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx;
using GorillaNetworking;
using Photon.Pun;
using UnityEngine;

namespace StupidTemplate.Menu
{
	// Token: 0x02000036 RID: 54
	[BepInPlugin("com.selenite.SeleniteGUI", "Selenite GUI", "1.2.0")]
	public class SeleniteGUI : BaseUnityPlugin
	{
		// Token: 0x060008A9 RID: 2217 RVA: 0x0004E9D8 File Offset: 0x0004CBD8
		private static void IsolatedStoragePermissionApplicationNameValue(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			GUILayout.Space(10f);
			GUILayout.Label("Enter Text:", Array.Empty<GUILayoutOption>());
			string text = GUILayout.TextField(A_8.inputText, Array.Empty<GUILayoutOption>());
			A_4 = text;
			text = A_4.ToUpper();
			A_4 = text;
			text = new string(Enumerable.ToArray<char>(Enumerable.Where<char>(A_4, delegate(char c)
			{
				int num2 = 2;
				int num3 = 2;
				num3 = 2;
				bool result;
				while (num3 != 0)
				{
					int num4;
					result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Char), ref num2, ref num3, ref num4, c, SeleniteGUI.<>c.EnumerableToBindableIterableAdapterIsLittleEndian[num2]);
				}
				num3 = 2;
				return result;
			})));
			A_4 = text;
			bool flag = A_4.Length > 12;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 25;
			A_0 = num;
		}

		// Token: 0x060008AA RID: 2218 RVA: 0x0004EAEC File Offset: 0x0004CCEC
		// Note: this type is marked as 'beforefieldinit'.
		static SeleniteGUI()
		{
			SeleniteGUI.ReAllocCoTaskMemgetOpCodeType();
			int num = 45;
			int num2 = 45;
			num2 = 45;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 45;
		}

		// Token: 0x060008AB RID: 2219 RVA: 0x0004EB28 File Offset: 0x0004CD28
		private static void WhitespaceAsynchronous(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			int num = ((A_7 == 1) ? 1 : 0) * 2 + 18;
			A_0 = num;
		}

		// Token: 0x060008AC RID: 2220 RVA: 0x0004EB60 File Offset: 0x0004CD60
		private static void SafeProcessHandleResourceTableMappingEntryFieldId(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			bool flag = A_3 < A_8.tabNames.Length;
			A_5 = flag;
			int num = (A_5 ? 1 : 0) * -4 + 15;
			A_0 = num;
		}

		// Token: 0x060008AD RID: 2221 RVA: 0x0004EBCC File Offset: 0x0004CDCC
		private static void AllowPartiallyTrustedCallersAttributeCMSENTRYPOINTFLAGHOSTINBROWSER(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x0004EBE4 File Offset: 0x0004CDE4
		private void Update()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Menu.SeleniteGUI), ref num, ref num2, ref num3, this, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 1;
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x0004EC18 File Offset: 0x0004CE18
		private static void IEnumSTORECATEGORYANSIX(ref int A_0, ref int A_1, ref int A_2, SeleniteGUI A_3)
		{
			A_3.tabButtonT2D = SeleniteGUI.MakeSolidColorTexture(Settings.backgroundColor.colors[0].color, 1, 1);
			A_1 = 0;
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x0004EC64 File Offset: 0x0004CE64
		private static void InvariantCultureIgnoreCasegetDomainPolicy(ref int A_0, ref int A_1, ref int A_2, ref Event A_3, ref bool A_4, ref bool A_5, ref float A_6, SeleniteGUI A_7)
		{
			A_7.tabButtonStyle = new GUIStyle(GUI.skin.button)
			{
				normal = 
				{
					background = A_7.tabButtonT2D
				},
				hover = 
				{
					background = A_7.tabButtonT2D
				},
				active = 
				{
					background = A_7.onButtonT2D
				},
				onNormal = 
				{
					background = A_7.tabButtonT2D
				},
				onHover = 
				{
					background = A_7.tabButtonT2D
				},
				onActive = 
				{
					background = A_7.onButtonT2D
				}
			};
			int num = A_7.windowID;
			Rect rect = A_7.windowRect;
			GUI.WindowFunction windowFunction = new GUI.WindowFunction(A_7.DrawWindow);
			string text = "<b><color=white>Selenite - Fps: ";
			float num2 = Mathf.Ceil(1f / Time.unscaledDeltaTime);
			A_6 = num2;
			A_7.windowRect = GUI.Window(num, rect, windowFunction, text + A_6.ToString() + " | F1 To Close</color></b>", A_7.blackWindowStyle);
			A_1 = 0;
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x0004ED84 File Offset: 0x0004CF84
		private static void ASMCACHERTLOSVERSIONINFOEX(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			GUILayout.Space(10f);
			bool flag = GUILayout.Button("Set Name", A_8.tabButtonStyle, Array.Empty<GUILayoutOption>());
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 29;
			A_0 = num;
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x0004EE00 File Offset: 0x0004D000
		private static Texture2D wMajorVerNumParseFailureKind(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, Color A_10)
		{
			Texture2D result = A_7;
			A_1 = 0;
			return result;
		}

		// Token: 0x060008B3 RID: 2227 RVA: 0x0004EE20 File Offset: 0x0004D020
		private static void TypesWhenNeededBinaryCrossAppDomainString(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			bool flag = GUI.Toggle(new Rect((float)(10 + A_3 * 120), 30f, 100f, 25f), A_8.currentTab == A_3, A_8.tabNames[A_3], A_8.tabButtonStyle);
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 12;
			A_0 = num;
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x0004EED8 File Offset: 0x0004D0D8
		private static Texture2D GetMethodBaseCursorLeft(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, ref Color A_10)
		{
			bool flag = A_5 < A_4.Length;
			A_6 = flag;
			int num = (A_6 ? 1 : 0) * -2 + 42;
			A_0 = num;
			Texture2D result;
			return result;
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x0004EF48 File Offset: 0x0004D148
		private void DrawSettingsTab()
		{
			int num = 31;
			int num2 = 31;
			num2 = 31;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,StupidTemplate.Menu.SeleniteGUI), ref num, ref num2, ref num3, ref flag, this, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 31;
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x0004EF84 File Offset: 0x0004D184
		private static Texture2D PoprefpopipopiIIDGuid(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, Color A_10)
		{
			bool flag = A_5 < A_4.Length;
			A_6 = flag;
			int num = (A_6 ? 1 : 0) * -2 + 37;
			A_0 = num;
			Texture2D result;
			return result;
		}

		// Token: 0x060008B7 RID: 2231 RVA: 0x0004EFF4 File Offset: 0x0004D1F4
		private static void getWebNamegetIsBitProcess(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, SeleniteGUI A_4)
		{
			Settings.ChangeButtonSound();
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Main.buttonClickSound, Settings.rightHanded, 0.1f);
			A_1 = 0;
		}

		// Token: 0x060008B8 RID: 2232 RVA: 0x0004F034 File Offset: 0x0004D234
		private static void AllowThousandsThisCall(ref int A_0, ref int A_1, ref int A_2, ref Event A_3, ref bool A_4, ref bool A_5, ref float A_6, SeleniteGUI A_7)
		{
			bool flag = false;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 5;
			A_0 = num;
		}

		// Token: 0x060008B9 RID: 2233 RVA: 0x0004F090 File Offset: 0x0004D290
		private static Texture2D getOutArgCountCaseInsensitiveHashCodeProvider(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, ref Color A_10)
		{
			Texture2D texture2D = new Texture2D(A_8, A_9, 4, false);
			A_3 = texture2D;
			A_10.a = 0.8f;
			Color[] array = new Color[A_8 * A_9];
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 41;
			Texture2D result;
			return result;
		}

		// Token: 0x060008BA RID: 2234 RVA: 0x0004F118 File Offset: 0x0004D318
		private static void LocalActivatorCORESERVER(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			int num = A_3 + 1;
			A_3 = num;
			bool flag = A_3 < A_8.tabNames.Length;
			A_5 = flag;
			int num2 = (A_5 ? 1 : 0) * -4 + 15;
			A_0 = num2;
		}

		// Token: 0x060008BB RID: 2235 RVA: 0x0004F1A8 File Offset: 0x0004D3A8
		private static void AppendTextsetObjectAceType(ref int A_0, ref int A_1, ref int A_2)
		{
			SeleniteGUI.tick = false;
			SeleniteGUI.tick1 = false;
			SeleniteGUI.tick2 = false;
			SeleniteGUI.tick3 = false;
			SeleniteGUI.tick4 = false;
			SeleniteGUI.tick5 = false;
			SeleniteGUI.tick6 = false;
			SeleniteGUI.tick7 = false;
			SeleniteGUI.tick8 = false;
			SeleniteGUI.tick9 = false;
			SeleniteGUI.tick10 = false;
			SeleniteGUI.tick11 = false;
			SeleniteGUI.tick12 = false;
			SeleniteGUI.tick13 = false;
			SeleniteGUI.bones = new int[]
			{
				4,
				3,
				5,
				4,
				19,
				18,
				20,
				19,
				3,
				18,
				21,
				20,
				22,
				21,
				25,
				21,
				29,
				21,
				31,
				29,
				27,
				25,
				24,
				22,
				6,
				5,
				7,
				6,
				10,
				6,
				14,
				6,
				16,
				14,
				12,
				10,
				9,
				7
			};
			A_1 = 0;
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x0004F268 File Offset: 0x0004D468
		private static void WaitHandleCannotBeOpenedExceptionValueLength(ref int A_0, ref int A_1, ref int A_2, ref Event A_3, ref bool A_4, ref bool A_5, ref float A_6, SeleniteGUI A_7)
		{
			A_7.showUI = !A_7.showUI;
			bool flag = !A_7.showUI;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 7;
			A_0 = num;
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x0004F2EC File Offset: 0x0004D4EC
		private static void opIncrementEncodingNLS(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			A_8.Logger.LogInfo(string.Format("Slider: {0:F2}, God Mode: {1}, Name: {2}", A_8.sliderValue, A_8.checkboxValue, A_8.inputText));
			PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(A_8.inputText, 0);
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Main.buttonClickSound, Settings.rightHanded, 0.1f);
			GUILayout.Space(10f);
			bool flag = GUILayout.Button("Set Name", A_8.tabButtonStyle, Array.Empty<GUILayoutOption>());
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 29;
			A_0 = num;
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x0004F3E0 File Offset: 0x0004D5E0
		private static void ActivationTypeXDQ(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			A_8.currentTab = A_3;
			int num = A_3 + 1;
			A_3 = num;
			bool flag = A_3 < A_8.tabNames.Length;
			A_5 = flag;
			int num2 = (A_5 ? 1 : 0) * -4 + 15;
			A_0 = num2;
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x0004F484 File Offset: 0x0004D684
		private static Texture2D EqualsExactHebrewValue(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, ref Color A_10)
		{
			A_3.SetPixels(A_4);
			A_3.Apply();
			Texture2D texture2D = A_3;
			A_7 = texture2D;
			A_0 = 43;
			Texture2D result;
			return result;
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x0004F4E0 File Offset: 0x0004D6E0
		private static void EntryAllocateNativeOverlapped(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			GorillaComputer.instance.currentName = A_8.inputText;
			PhotonNetwork.LocalPlayer.NickName = A_8.inputText;
			GorillaComputer.instance.offlineVRRigNametagText.text = A_8.inputText;
			GorillaComputer.instance.savedName = A_8.inputText;
			PlayerPrefs.SetString("playerName", A_8.inputText);
			PlayerPrefs.Save();
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Main.buttonClickSound, Settings.rightHanded, 0.1f);
			A_1 = 0;
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x0004F58C File Offset: 0x0004D78C
		private static void SetObjectUriForMarshalCompilerMarshalOverride(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			A_8.DrawSettingsTab();
			A_0 = 21;
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x0004F5B0 File Offset: 0x0004D7B0
		private static void XDQBuiltInPermissionIndex(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			GUILayout.Label("Current Tab: Misc", Array.Empty<GUILayoutOption>());
			bool flag = GUILayout.Button("Disconnect", A_8.tabButtonStyle, Array.Empty<GUILayoutOption>());
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 23;
			A_0 = num;
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x0004F630 File Offset: 0x0004D830
		private void DrawMiscTab()
		{
			int num = 22;
			int num2 = 22;
			num2 = 22;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				string text;
				bool flag2;
				bool flag3;
				bool flag4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.String&,System.Boolean&,System.Boolean&,System.Boolean&,StupidTemplate.Menu.SeleniteGUI), ref num, ref num2, ref num3, ref flag, ref text, ref flag2, ref flag3, ref flag4, this, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 22;
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x0004F674 File Offset: 0x0004D874
		private static void HeadersEndsetSecurityIdentifier(ref int A_0, ref int A_1, ref int A_2, ref Event A_3, ref bool A_4, ref bool A_5, ref float A_6, SeleniteGUI A_7)
		{
			A_1 = 0;
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x0004F68C File Offset: 0x0004D88C
		private static void SystemDirectoryDirectoryNotFoundException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			A_8.inputText = A_4;
			GUILayout.Space(10f);
			bool flag = GUILayout.Button("Join Room", A_8.tabButtonStyle, Array.Empty<GUILayoutOption>());
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 27;
			A_0 = num;
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x0004F718 File Offset: 0x0004D918
		private static void GetILOffsetSecurityElement(ref int A_0, ref int A_1, ref int A_2, SeleniteGUI A_3)
		{
			A_3.blackWindowStyle = new GUIStyle();
			A_3.blackWindowStyle.normal.background = SeleniteGUI.MakeSolidColorTextureT(Settings.backgroundColor.colors[0].color, 1, 1);
			A_3.tabButtonT2D = SeleniteGUI.MakeSolidColorTextureT(Main.outlineColor, 1, 1);
			A_1 = 2;
		}

		// Token: 0x060008C7 RID: 2247 RVA: 0x0004F79C File Offset: 0x0004D99C
		private static void getVisualizerTypeNameMethodDef(ref int A_0, ref int A_1, ref int A_2, ref Event A_3, ref bool A_4, ref bool A_5, ref float A_6, SeleniteGUI A_7)
		{
			A_0 = 9;
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x0004F7B4 File Offset: 0x0004D9B4
		private static Texture2D ExecutionContextSwitchergetExternalProcessMgmt(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, Color A_10)
		{
			A_3.SetPixels(A_4);
			A_3.Apply();
			Texture2D texture2D = A_3;
			A_7 = texture2D;
			A_0 = 38;
			Texture2D result;
			return result;
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x0004F810 File Offset: 0x0004DA10
		private static void TimeZoneInformationIVectorViewToIBindableVectorViewAdapter(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			A_0 = 17;
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x0004F828 File Offset: 0x0004DA28
		private static void setWindowHeightfVersioned(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			int num = 0;
			A_3 = num;
			A_0 = 14;
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x0004F858 File Offset: 0x0004DA58
		private static void DisableEventMINORVERSION(ref int A_0, ref int A_1, ref int A_2, ref Event A_3, ref bool A_4, ref bool A_5, ref float A_6, SeleniteGUI A_7)
		{
			Event current = Event.current;
			A_3 = current;
			int num = (((A_3.type == 4) ? 1 : 0) + -1) * -1 * 1 + 3;
			A_0 = num;
		}

		// Token: 0x060008CC RID: 2252 RVA: 0x0004F8B8 File Offset: 0x0004DAB8
		private static Texture2D MakeSolidColorTextureT(Color color, int width = 1, int height = 1)
		{
			int num = 39;
			int num2 = 39;
			num2 = 39;
			Texture2D result;
			while (num2 != 0)
			{
				int num3;
				Texture2D texture2D;
				Color[] array;
				int num4;
				bool flag;
				Texture2D texture2D2;
				result = calli(UnityEngine.Texture2D(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Texture2D&,UnityEngine.Color[]&,System.Int32&,System.Boolean&,UnityEngine.Texture2D&,System.Int32,System.Int32,UnityEngine.Color&), ref num, ref num2, ref num3, ref texture2D, ref array, ref num4, ref flag, ref texture2D2, width, height, ref color, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 39;
			return result;
		}

		// Token: 0x060008CD RID: 2253 RVA: 0x0004F900 File Offset: 0x0004DB00
		private void OnGUI()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				Event @event;
				bool flag;
				bool flag2;
				float num4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Event&,System.Boolean&,System.Boolean&,System.Single&,StupidTemplate.Menu.SeleniteGUI), ref num, ref num2, ref num3, ref @event, ref flag, ref flag2, ref num4, this, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 2;
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x0004F93C File Offset: 0x0004DB3C
		private static void IterationCountUnwrap(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, SeleniteGUI A_4)
		{
			GUILayout.Label("Current Tab: Settings", Array.Empty<GUILayoutOption>());
			bool flag = GUILayout.Button("Change Toggle Sound", A_4.tabButtonStyle, Array.Empty<GUILayoutOption>());
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 32;
			A_0 = num;
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x0004F9BC File Offset: 0x0004DBBC
		private static void EmptyTypesgetPMDesignator(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			GUILayout.BeginArea(new Rect(10f, 60f, A_8.windowRect.width - 20f, A_8.windowRect.height - 70f));
			A_8.guiScrollPos = GUILayout.BeginScrollView(A_8.guiScrollPos, false, true, Array.Empty<GUILayoutOption>());
			int num = A_8.currentTab;
			A_6 = num;
			int num2 = A_6;
			A_7 = num2;
			int num3 = ((A_7 == 0) ? 1 : 0) * 3 + 16;
			A_0 = num3;
		}

		// Token: 0x060008D0 RID: 2256 RVA: 0x0004FA98 File Offset: 0x0004DC98
		private static void EnumerableToIterableAdaptergetParent(ref int A_0, ref int A_1, ref int A_2, SeleniteGUI A_3)
		{
			A_3.showUI = true;
			A_3.guiScrollPos = Vector2.zero;
			A_3.windowRect = new Rect(10f, 10f, 800f, 600f);
			A_3.windowID = 4321;
			A_3.currentTab = 0;
			A_3.tabNames = new string[]
			{
				"Misc",
				"Settings",
				"Visuals",
				"Exploits"
			};
			A_3.sliderValue = 0.5f;
			A_3.checkboxValue = false;
			A_3.checkboxValue1 = false;
			A_3.checkboxValue2 = false;
			A_3.checkboxValue3 = false;
			A_3.checkboxValue4 = false;
			A_3.skib = false;
			A_3.skib1 = false;
			A_3.skib2 = false;
			A_3.skib3 = false;
			A_3.skib4 = false;
			A_3.skib5 = false;
			A_3.skib6 = false;
			A_3.skib7 = false;
			A_3.skib8 = false;
			A_3.skib9 = false;
			A_3.inputText = "";
			List<string> list = new List<string>();
			list.Add("Option A");
			list.Add("Option B");
			list.Add("Option C");
			A_3.dropdownOptions = list;
			A_3.dropdownOpen = false;
			A_3.selectedDropdownIndex = 0;
			A_3.dropdownAnimationProgress = 0f;
			A_3.dropdownAnimationTimer = 0f;
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x0004FCB0 File Offset: 0x0004DEB0
		private static void RegistryHashElementEntry(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, SeleniteGUI A_4)
		{
			A_1 = 0;
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x0004FCC8 File Offset: 0x0004DEC8
		public SeleniteGUI()
		{
			int num = 44;
			int num2 = 44;
			num2 = 44;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Menu.SeleniteGUI), ref num, ref num2, ref num3, this, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 44;
		}

		// Token: 0x060008D3 RID: 2259 RVA: 0x0004FD00 File Offset: 0x0004DF00
		private static void AclRevisionPrint(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			PhotonNetwork.Disconnect();
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(Main.buttonClickSound, Settings.rightHanded, 0.1f);
			GUILayout.Space(10f);
			GUILayout.Label("Enter Text:", Array.Empty<GUILayoutOption>());
			string text = GUILayout.TextField(A_8.inputText, Array.Empty<GUILayoutOption>());
			A_4 = text;
			text = A_4.ToUpper();
			A_4 = text;
			text = new string(Enumerable.ToArray<char>(Enumerable.Where<char>(A_4, delegate(char c)
			{
				int num2 = 2;
				int num3 = 2;
				num3 = 2;
				bool result;
				while (num3 != 0)
				{
					int num4;
					result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Char), ref num2, ref num3, ref num4, c, SeleniteGUI.<>c.EnumerableToBindableIterableAdapterIsLittleEndian[num2]);
				}
				num3 = 2;
				return result;
			})));
			A_4 = text;
			bool flag = A_4.Length > 12;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 25;
			A_0 = num;
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x0004FE3C File Offset: 0x0004E03C
		private static Texture2D EnclosingMarkCreationTimeUtc(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, Color A_10)
		{
			A_4[A_5] = A_10;
			int num = A_5 + 1;
			A_5 = num;
			bool flag = A_5 < A_4.Length;
			A_6 = flag;
			int num2 = (A_6 ? 1 : 0) * -2 + 37;
			A_0 = num2;
			Texture2D result;
			return result;
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x0004FEE8 File Offset: 0x0004E0E8
		private void DrawWindow(int id)
		{
			int num = 10;
			int num2 = 10;
			num2 = 10;
			while (num2 != 0)
			{
				int num3;
				int num4;
				bool flag;
				bool flag2;
				int num5;
				int num6;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Int32&,System.Int32&,StupidTemplate.Menu.SeleniteGUI), ref num, ref num2, ref num3, ref num4, ref flag, ref flag2, ref num5, ref num6, this, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 10;
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x0004FF2C File Offset: 0x0004E12C
		private static Texture2D OnDeserializingAttributeAssemblyReferenceDependentAssemblyResourceFallbackCulture(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, ref Color A_10)
		{
			A_4[A_5] = A_10;
			int num = A_5 + 1;
			A_5 = num;
			bool flag = A_5 < A_4.Length;
			A_6 = flag;
			int num2 = (A_6 ? 1 : 0) * -2 + 42;
			A_0 = num2;
			Texture2D result;
			return result;
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x0004FFDC File Offset: 0x0004E1DC
		private static void NativeBufferLoadFrom(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			GUILayout.EndScrollView();
			GUILayout.EndArea();
			GUI.DragWindow(new Rect(0f, 0f, A_8.windowRect.width, 25f));
			A_1 = 0;
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x00050028 File Offset: 0x0004E228
		private static void DefineMethodOverrideSecurityRuleSet(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref string A_4, ref bool A_5, ref bool A_6, ref bool A_7, SeleniteGUI A_8)
		{
			string text = A_4.Substring(0, 12);
			A_4 = text;
			A_8.inputText = A_4;
			GUILayout.Space(10f);
			bool flag = GUILayout.Button("Join Room", A_8.tabButtonStyle, Array.Empty<GUILayoutOption>());
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 27;
			A_0 = num;
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x000500DC File Offset: 0x0004E2DC
		private static void SortableDateTimePatternToStringArray(ref int A_0, ref int A_1, ref int A_2, ref Event A_3, ref bool A_4, ref bool A_5, ref float A_6, SeleniteGUI A_7)
		{
			bool flag = A_3.keyCode == 282;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 5;
			A_0 = num;
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x0005014C File Offset: 0x0004E34C
		private static void CMSENTRYPOINTFLAGCUSTOMUXgetSortId(ref int A_0, ref int A_1, ref int A_2, ref Event A_3, ref bool A_4, ref bool A_5, ref float A_6, SeleniteGUI A_7)
		{
			bool flag = !A_7.showUI;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 7;
			A_0 = num;
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x000501B4 File Offset: 0x0004E3B4
		private static Texture2D setParametersGetSingle(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, ref Color A_10)
		{
			Texture2D result = A_7;
			A_1 = 0;
			return result;
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x000501D4 File Offset: 0x0004E3D4
		private void Awake()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Menu.SeleniteGUI), ref num, ref num2, ref num3, this, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 0;
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x00050208 File Offset: 0x0004E408
		private static Texture2D MakeSolidColorTexture(Color color, int width = 1, int height = 1)
		{
			int num = 34;
			int num2 = 34;
			num2 = 34;
			Texture2D result;
			while (num2 != 0)
			{
				int num3;
				Texture2D texture2D;
				Color[] array;
				int num4;
				bool flag;
				Texture2D texture2D2;
				result = calli(UnityEngine.Texture2D(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Texture2D&,UnityEngine.Color[]&,System.Int32&,System.Boolean&,UnityEngine.Texture2D&,System.Int32,System.Int32,UnityEngine.Color), ref num, ref num2, ref num3, ref texture2D, ref array, ref num4, ref flag, ref texture2D2, width, height, color, SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[num]);
			}
			num2 = 34;
			return result;
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x00050250 File Offset: 0x0004E450
		private static void IsPinnedAtId(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			A_8.DrawMiscTab();
			A_0 = 21;
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x00050274 File Offset: 0x0004E474
		private static void getIsSerializableIDLFLAG(ref int A_0, ref int A_1, ref int A_2, ref int A_3, ref bool A_4, ref bool A_5, ref int A_6, ref int A_7, SeleniteGUI A_8)
		{
			A_0 = 21;
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x0005028C File Offset: 0x0004E48C
		private static Texture2D TokenSourceGetZoneAndOrigin(ref int A_0, ref int A_1, ref int A_2, ref Texture2D A_3, ref Color[] A_4, ref int A_5, ref bool A_6, ref Texture2D A_7, int A_8, int A_9, Color A_10)
		{
			Texture2D texture2D = new Texture2D(A_8, A_9);
			A_3 = texture2D;
			Color[] array = new Color[A_8 * A_9];
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 36;
			Texture2D result;
			return result;
		}

		// Token: 0x060008E1 RID: 2273 RVA: 0x000502FC File Offset: 0x0004E4FC
		private static void ReAllocCoTaskMemgetOpCodeType()
		{
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames = new IntPtr[46];
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[0] = ldftn(GetILOffsetSecurityElement);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[1] = ldftn(IEnumSTORECATEGORYANSIX);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[2] = ldftn(DisableEventMINORVERSION);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[3] = ldftn(SortableDateTimePatternToStringArray);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[4] = ldftn(AllowThousandsThisCall);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[5] = ldftn(WaitHandleCannotBeOpenedExceptionValueLength);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[6] = ldftn(CMSENTRYPOINTFLAGCUSTOMUXgetSortId);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[7] = ldftn(getVisualizerTypeNameMethodDef);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[8] = ldftn(InvariantCultureIgnoreCasegetDomainPolicy);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[9] = ldftn(HeadersEndsetSecurityIdentifier);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[10] = ldftn(setWindowHeightfVersioned);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[11] = ldftn(TypesWhenNeededBinaryCrossAppDomainString);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[12] = ldftn(ActivationTypeXDQ);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[13] = ldftn(LocalActivatorCORESERVER);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[14] = ldftn(SafeProcessHandleResourceTableMappingEntryFieldId);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[15] = ldftn(EmptyTypesgetPMDesignator);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[16] = ldftn(TimeZoneInformationIVectorViewToIBindableVectorViewAdapter);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[17] = ldftn(WhitespaceAsynchronous);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[18] = ldftn(getIsSerializableIDLFLAG);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[19] = ldftn(IsPinnedAtId);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[20] = ldftn(SetObjectUriForMarshalCompilerMarshalOverride);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[21] = ldftn(NativeBufferLoadFrom);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[22] = ldftn(XDQBuiltInPermissionIndex);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[23] = ldftn(AclRevisionPrint);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[24] = ldftn(IsolatedStoragePermissionApplicationNameValue);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[25] = ldftn(DefineMethodOverrideSecurityRuleSet);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[26] = ldftn(SystemDirectoryDirectoryNotFoundException);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[27] = ldftn(opIncrementEncodingNLS);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[28] = ldftn(ASMCACHERTLOSVERSIONINFOEX);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[29] = ldftn(EntryAllocateNativeOverlapped);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[30] = ldftn(AllowPartiallyTrustedCallersAttributeCMSENTRYPOINTFLAGHOSTINBROWSER);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[31] = ldftn(IterationCountUnwrap);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[32] = ldftn(getWebNamegetIsBitProcess);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[33] = ldftn(RegistryHashElementEntry);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[34] = ldftn(TokenSourceGetZoneAndOrigin);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[35] = ldftn(EnclosingMarkCreationTimeUtc);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[36] = ldftn(PoprefpopipopiIIDGuid);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[37] = ldftn(ExecutionContextSwitchergetExternalProcessMgmt);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[38] = ldftn(wMajorVerNumParseFailureKind);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[39] = ldftn(getOutArgCountCaseInsensitiveHashCodeProvider);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[40] = ldftn(OnDeserializingAttributeAssemblyReferenceDependentAssemblyResourceFallbackCulture);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[41] = ldftn(GetMethodBaseCursorLeft);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[42] = ldftn(EqualsExactHebrewValue);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[43] = ldftn(setParametersGetSingle);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[44] = ldftn(EnumerableToIterableAdaptergetParent);
			SeleniteGUI.INVOCATIONFLAGSSPECIALFIELDFieldNames[45] = ldftn(AppendTextsetObjectAceType);
		}

		// Token: 0x040000E6 RID: 230
		private bool showUI;

		// Token: 0x040000E7 RID: 231
		private Vector2 guiScrollPos;

		// Token: 0x040000E8 RID: 232
		private Rect windowRect;

		// Token: 0x040000E9 RID: 233
		private int windowID;

		// Token: 0x040000EA RID: 234
		private int currentTab;

		// Token: 0x040000EB RID: 235
		private string[] tabNames;

		// Token: 0x040000EC RID: 236
		private float sliderValue;

		// Token: 0x040000ED RID: 237
		private bool checkboxValue;

		// Token: 0x040000EE RID: 238
		private bool checkboxValue1;

		// Token: 0x040000EF RID: 239
		private bool checkboxValue2;

		// Token: 0x040000F0 RID: 240
		private bool checkboxValue3;

		// Token: 0x040000F1 RID: 241
		private bool checkboxValue4;

		// Token: 0x040000F2 RID: 242
		private bool skib;

		// Token: 0x040000F3 RID: 243
		private bool skib1;

		// Token: 0x040000F4 RID: 244
		private bool skib2;

		// Token: 0x040000F5 RID: 245
		private bool skib3;

		// Token: 0x040000F6 RID: 246
		private bool skib4;

		// Token: 0x040000F7 RID: 247
		private bool skib5;

		// Token: 0x040000F8 RID: 248
		private bool skib6;

		// Token: 0x040000F9 RID: 249
		private bool skib7;

		// Token: 0x040000FA RID: 250
		private bool skib8;

		// Token: 0x040000FB RID: 251
		private bool skib9;

		// Token: 0x040000FC RID: 252
		private string inputText;

		// Token: 0x040000FD RID: 253
		private List<string> dropdownOptions;

		// Token: 0x040000FE RID: 254
		private bool dropdownOpen;

		// Token: 0x040000FF RID: 255
		private int selectedDropdownIndex;

		// Token: 0x04000100 RID: 256
		private float dropdownAnimationProgress;

		// Token: 0x04000101 RID: 257
		private const float dropdownAnimationDuration = 0.3f;

		// Token: 0x04000102 RID: 258
		private float dropdownAnimationTimer;

		// Token: 0x04000103 RID: 259
		private Font arialFont;

		// Token: 0x04000104 RID: 260
		private Texture2D blackTex;

		// Token: 0x04000105 RID: 261
		private GUIStyle blackWindowStyle;

		// Token: 0x04000106 RID: 262
		private GUIStyle grayWindowStyle;

		// Token: 0x04000107 RID: 263
		private GUIStyle transparentButtonStyle;

		// Token: 0x04000108 RID: 264
		private Texture2D fuck;

		// Token: 0x04000109 RID: 265
		private GUIStyle grayButtonStyle;

		// Token: 0x0400010A RID: 266
		private static bool tick;

		// Token: 0x0400010B RID: 267
		private static bool tick1;

		// Token: 0x0400010C RID: 268
		private static bool tick2;

		// Token: 0x0400010D RID: 269
		private static bool tick3;

		// Token: 0x0400010E RID: 270
		private static bool tick4;

		// Token: 0x0400010F RID: 271
		private static bool tick5;

		// Token: 0x04000110 RID: 272
		private static bool tick6;

		// Token: 0x04000111 RID: 273
		private static bool tick7;

		// Token: 0x04000112 RID: 274
		private static bool tick8;

		// Token: 0x04000113 RID: 275
		private static bool tick9;

		// Token: 0x04000114 RID: 276
		private static bool tick10;

		// Token: 0x04000115 RID: 277
		private static bool tick11;

		// Token: 0x04000116 RID: 278
		private static bool tick12;

		// Token: 0x04000117 RID: 279
		private static bool tick13;

		// Token: 0x04000118 RID: 280
		public static int[] bones;

		// Token: 0x04000119 RID: 281
		private float Shittymethod;

		// Token: 0x0400011A RID: 282
		private float splashtimeout;

		// Token: 0x0400011B RID: 283
		private GUIStyle tabButtonStyle;

		// Token: 0x0400011C RID: 284
		private Texture2D tabButtonT2D;

		// Token: 0x0400011D RID: 285
		private Texture2D onButtonT2D;

		// Token: 0x0400011E RID: 286
		private static IntPtr[] INVOCATIONFLAGSSPECIALFIELDFieldNames;
	}
}
