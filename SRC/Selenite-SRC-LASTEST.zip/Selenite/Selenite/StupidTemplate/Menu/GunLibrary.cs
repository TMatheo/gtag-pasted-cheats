﻿using System;
using GorillaLocomotion;
using UnityEngine;

namespace StupidTemplate.Menu
{
	// Token: 0x02000038 RID: 56
	internal class GunLibrary
	{
		// Token: 0x060008E9 RID: 2281 RVA: 0x00050784 File Offset: 0x0004E984
		public static void CreateGun(Action ActivateMod, bool LockOnVRRigg)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 27)
			{
				int num3;
				bool flag;
				bool flag2;
				RaycastHit raycastHit;
				GameObject gameObject;
				LineRenderer lineRenderer;
				bool flag3;
				bool flag4;
				bool flag5;
				bool flag6;
				bool flag7;
				bool flag8;
				bool flag9;
				RaycastHit raycastHit2;
				GameObject gameObject2;
				LineRenderer lineRenderer2;
				bool flag10;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,UnityEngine.RaycastHit&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,UnityEngine.RaycastHit&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,System.Boolean&,System.Boolean,System.Action), ref num, ref num2, ref num3, ref flag, ref flag2, ref raycastHit, ref gameObject, ref lineRenderer, ref flag3, ref flag4, ref flag5, ref flag6, ref flag7, ref flag8, ref flag9, ref raycastHit2, ref gameObject2, ref lineRenderer2, ref flag10, LockOnVRRigg, ActivateMod, GunLibrary.RefFlagsGetType[num]);
			}
			num2 = 0;
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x000507DC File Offset: 0x0004E9DC
		private static void IFormattableCULTURE(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			GunLibrary.LockOnVRRig = A_5.collider.GetComponentInParent<VRRig>();
			bool flag = GunLibrary.LockOnVRRig == GorillaTagger.Instance.offlineVRRig;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 1 + 7;
			A_0 = num;
		}

		// Token: 0x060008EB RID: 2283 RVA: 0x0005085C File Offset: 0x0004EA5C
		private static void MEMBERIDNILDsaKeyValue(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_1 = 27;
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x00050874 File Offset: 0x0004EA74
		private static void getRefusedSetFlushAsync(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_0 = 11;
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x00050890 File Offset: 0x0004EA90
		private static void CompatibleFrameworksDataPrimaryInteropAssemblyAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			bool flag = A_5.collider.GetComponentInParent<VRRig>() != null;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 3 + 6;
			A_0 = num;
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x00050900 File Offset: 0x0004EB00
		private static void StrongNameSignatureSizeRequestingAssembly(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_14 = rightGrab;
			int num = ((!A_14) ? 1 : 0) * 3 + 22;
			A_0 = num;
		}

		// Token: 0x060008EF RID: 2287 RVA: 0x00050964 File Offset: 0x0004EB64
		private static void IMPLTYPEFLAGFRESTRICTEDGetRawCertDataString(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			GunLibrary.Pointer.transform.position = GunLibrary.LockOnVRRig.transform.position;
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 5 + 12;
			A_0 = num;
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x000509F0 File Offset: 0x0004EBF0
		private static void GetHeadersSoapNormalizedString(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			GunLibrary.Pointer.transform.position = GunLibrary.LockOnVRRig.transform.position;
			A_7.SetPosition(0, GTPlayer.Instance.rightControllerTransform.position);
			A_7.SetPosition(1, GunLibrary.LockOnVRRig.transform.position);
			A_20.Invoke();
			A_0 = 19;
		}

		// Token: 0x060008F1 RID: 2289 RVA: 0x00050A7C File Offset: 0x0004EC7C
		private static void COREENDOFSTREAMAwayFromZero(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			bool flag = GunLibrary.LockOnVRRig != null;
			A_13 = flag;
			int num = ((!A_13) ? 1 : 0) * 1 + 18;
			A_0 = num;
		}

		// Token: 0x060008F2 RID: 2290 RVA: 0x00050AE0 File Offset: 0x0004ECE0
		public GunLibrary()
		{
			int num = 27;
			int num2 = 27;
			num2 = 27;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Menu.GunLibrary), ref num, ref num2, ref num3, this, GunLibrary.RefFlagsGetType[num]);
			}
			num2 = 27;
		}

		// Token: 0x060008F3 RID: 2291 RVA: 0x00050B18 File Offset: 0x0004ED18
		private static void InvalidOperationEnumNotStartedSeparatorTokenMask(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			int num = ((!A_19) ? 1 : 0) * 1 + 13;
			A_0 = num;
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x00050B5C File Offset: 0x0004ED5C
		private static void ArgArrayPlusOffTooSmallGetEnumeratord(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_0 = 19;
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x00050B74 File Offset: 0x0004ED74
		private static void ToBaseCharArrayRecover(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_20.Invoke();
			A_1 = 27;
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x00050B9C File Offset: 0x0004ED9C
		private static void PrepareConstrainedRegionsNoOPTrySetException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			GunLibrary.LockOnVRRig = null;
			A_0 = 26;
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x00050BBC File Offset: 0x0004EDBC
		private static void setUnrestrictedNonUniqueAuthority(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_1 = 27;
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x00050BD8 File Offset: 0x0004EDD8
		private static void getScopeNameTryRemove(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			GunLibrary.Pointer.transform.position = A_5.point;
			int num = ((!A_19) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x060008F9 RID: 2297 RVA: 0x00050C34 File Offset: 0x0004EE34
		private static void getChannelUrisCallvirt(ref int A_0, ref int A_1, ref int A_2, GunLibrary A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060008FA RID: 2298 RVA: 0x00050C58 File Offset: 0x0004EE58
		private static void getDateBindToMoniker(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			bool flag = false;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 3 + 6;
			A_0 = num;
		}

		// Token: 0x060008FB RID: 2299 RVA: 0x00050CB4 File Offset: 0x0004EEB4
		private static void getIssuerGeneric(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_3 = A_19;
			int num = ((!A_3) ? 1 : 0) * 20 + 1;
			A_0 = num;
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x00050D10 File Offset: 0x0004EF10
		private static void UnregisterChannelgetPrivateBinPath(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_4 = rightGrab;
			int num = ((!A_4) ? 1 : 0) * 18 + 2;
			A_0 = num;
		}

		// Token: 0x060008FD RID: 2301 RVA: 0x00050D74 File Offset: 0x0004EF74
		private static void ThaiBuddhistEraDescriptionMetadataPublisher(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_1 = 27;
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x00050D8C File Offset: 0x0004EF8C
		private static void LoosesetNoPrompt(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			GunLibrary.LockOnVRRig = null;
			A_0 = 26;
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x00050DB0 File Offset: 0x0004EFB0
		private static void IsNewContextOKAssumeNegative(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			bool flag = false;
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 1 + 15;
			A_0 = num;
		}

		// Token: 0x06000900 RID: 2304 RVA: 0x00050E0C File Offset: 0x0004F00C
		private static void AssemblyReferenceDependentAssemblyCodebaseChannel(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_0 = 11;
		}

		// Token: 0x06000901 RID: 2305 RVA: 0x00050E24 File Offset: 0x0004F024
		private static void AbsentOriginSchemeISerializationRootObject(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_0 = 26;
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x00050E3C File Offset: 0x0004F03C
		private static void MscorlibDictionaryKeyCollectionDebugViewCSharp(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			Physics.Raycast(GTPlayer.Instance.rightControllerTransform.position - GTPlayer.Instance.rightControllerTransform.up, -GTPlayer.Instance.rightControllerTransform.up, ref A_5);
			GunLibrary.Pointer = GameObject.CreatePrimitive(0);
			GunLibrary.Pointer.GetComponent<Renderer>().material.color = Main.outlineColor;
			GunLibrary.Pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			GunLibrary.Pointer.transform.position = A_5.point;
			Object.Destroy(GunLibrary.Pointer.GetComponent<SphereCollider>());
			Object.Destroy(GunLibrary.Pointer, Time.deltaTime);
			GameObject gameObject = new GameObject();
			A_6 = gameObject;
			LineRenderer lineRenderer = A_6.AddComponent<LineRenderer>();
			A_7 = lineRenderer;
			A_7.SetPosition(0, GTPlayer.Instance.rightControllerTransform.position);
			A_7.SetPosition(1, GunLibrary.Pointer.transform.position);
			A_7.startColor = Main.outlineColor;
			A_7.endColor = Main.outlineColor;
			A_7.material.shader = Shader.Find("GUI/Text Shader");
			A_7.endWidth = 0.01f;
			A_7.startWidth = 0.01f;
			Object.Destroy(A_7, Time.deltaTime);
			GunLibrary.Pointer.transform.position = A_5.point;
			bool flag = GunLibrary.LockOnVRRig == null;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 7 + 3;
			A_0 = num;
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x0005108C File Offset: 0x0004F28C
		private static void IsReadOnlyAttributeGetDeclaredEvent(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 5 + 12;
			A_0 = num;
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x000510F8 File Offset: 0x0004F2F8
		private static void SetSignatureDefineInitializedData(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			A_0 = 26;
		}

		// Token: 0x06000905 RID: 2309 RVA: 0x00051114 File Offset: 0x0004F314
		private static void MacOSXRootCodeGroup(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			Physics.Raycast(GTPlayer.Instance.rightControllerTransform.position - GTPlayer.Instance.rightControllerTransform.up, -GTPlayer.Instance.rightControllerTransform.up, ref A_15);
			GunLibrary.Pointer = GameObject.CreatePrimitive(0);
			GunLibrary.Pointer.GetComponent<Renderer>().material.color = Main.outlineColor;
			GunLibrary.Pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			GunLibrary.Pointer.transform.position = A_15.point;
			Object.Destroy(GunLibrary.Pointer.GetComponent<SphereCollider>());
			Object.Destroy(GunLibrary.Pointer, Time.deltaTime);
			GameObject gameObject = new GameObject();
			A_16 = gameObject;
			LineRenderer lineRenderer = A_16.AddComponent<LineRenderer>();
			A_17 = lineRenderer;
			A_17.SetPosition(0, GTPlayer.Instance.rightControllerTransform.position);
			A_17.SetPosition(1, GunLibrary.Pointer.transform.position);
			A_17.startColor = Main.outlineColor;
			A_17.endColor = Main.outlineColor;
			A_17.material.shader = Shader.Find("GUI/Text Shader");
			A_17.endWidth = 0.01f;
			A_17.startWidth = 0.01f;
			Object.Destroy(A_17, Time.deltaTime);
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_18 = flag;
			int num = ((!A_18) ? 1 : 0) * 1 + 23;
			A_0 = num;
		}

		// Token: 0x06000906 RID: 2310 RVA: 0x00051354 File Offset: 0x0004F554
		private static void GetNativeDataSizeTryDequeueIf(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref RaycastHit A_5, ref GameObject A_6, ref LineRenderer A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref RaycastHit A_15, ref GameObject A_16, ref LineRenderer A_17, ref bool A_18, bool A_19, Action A_20)
		{
			bool flag = GunLibrary.LockOnVRRig != null;
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 1 + 15;
			A_0 = num;
		}

		// Token: 0x06000907 RID: 2311 RVA: 0x000513BC File Offset: 0x0004F5BC
		// Note: this type is marked as 'beforefieldinit'.
		static GunLibrary()
		{
			GunLibrary.AsIObjectAceFlags();
		}

		// Token: 0x06000908 RID: 2312 RVA: 0x000513D0 File Offset: 0x0004F5D0
		private static void AsIObjectAceFlags()
		{
			GunLibrary.RefFlagsGetType = new IntPtr[28];
			GunLibrary.RefFlagsGetType[0] = ldftn(getIssuerGeneric);
			GunLibrary.RefFlagsGetType[1] = ldftn(UnregisterChannelgetPrivateBinPath);
			GunLibrary.RefFlagsGetType[2] = ldftn(MscorlibDictionaryKeyCollectionDebugViewCSharp);
			GunLibrary.RefFlagsGetType[3] = ldftn(getScopeNameTryRemove);
			GunLibrary.RefFlagsGetType[4] = ldftn(CompatibleFrameworksDataPrimaryInteropAssemblyAttribute);
			GunLibrary.RefFlagsGetType[5] = ldftn(getDateBindToMoniker);
			GunLibrary.RefFlagsGetType[6] = ldftn(IFormattableCULTURE);
			GunLibrary.RefFlagsGetType[7] = ldftn(PrepareConstrainedRegionsNoOPTrySetException);
			GunLibrary.RefFlagsGetType[8] = ldftn(getRefusedSetFlushAsync);
			GunLibrary.RefFlagsGetType[9] = ldftn(AssemblyReferenceDependentAssemblyCodebaseChannel);
			GunLibrary.RefFlagsGetType[10] = ldftn(IMPLTYPEFLAGFRESTRICTEDGetRawCertDataString);
			GunLibrary.RefFlagsGetType[11] = ldftn(IsReadOnlyAttributeGetDeclaredEvent);
			GunLibrary.RefFlagsGetType[12] = ldftn(InvalidOperationEnumNotStartedSeparatorTokenMask);
			GunLibrary.RefFlagsGetType[13] = ldftn(GetNativeDataSizeTryDequeueIf);
			GunLibrary.RefFlagsGetType[14] = ldftn(IsNewContextOKAssumeNegative);
			GunLibrary.RefFlagsGetType[15] = ldftn(GetHeadersSoapNormalizedString);
			GunLibrary.RefFlagsGetType[16] = ldftn(ArgArrayPlusOffTooSmallGetEnumeratord);
			GunLibrary.RefFlagsGetType[17] = ldftn(COREENDOFSTREAMAwayFromZero);
			GunLibrary.RefFlagsGetType[18] = ldftn(LoosesetNoPrompt);
			GunLibrary.RefFlagsGetType[19] = ldftn(SetSignatureDefineInitializedData);
			GunLibrary.RefFlagsGetType[20] = ldftn(AbsentOriginSchemeISerializationRootObject);
			GunLibrary.RefFlagsGetType[21] = ldftn(StrongNameSignatureSizeRequestingAssembly);
			GunLibrary.RefFlagsGetType[22] = ldftn(MacOSXRootCodeGroup);
			GunLibrary.RefFlagsGetType[23] = ldftn(ToBaseCharArrayRecover);
			GunLibrary.RefFlagsGetType[24] = ldftn(setUnrestrictedNonUniqueAuthority);
			GunLibrary.RefFlagsGetType[25] = ldftn(MEMBERIDNILDsaKeyValue);
			GunLibrary.RefFlagsGetType[26] = ldftn(ThaiBuddhistEraDescriptionMetadataPublisher);
			GunLibrary.RefFlagsGetType[27] = ldftn(getChannelUrisCallvirt);
		}

		// Token: 0x04000122 RID: 290
		public static VRRig LockOnVRRig;

		// Token: 0x04000123 RID: 291
		public static bool ActivateMod;

		// Token: 0x04000124 RID: 292
		public static GameObject Pointer;

		// Token: 0x04000125 RID: 293
		private static IntPtr[] RefFlagsGetType;
	}
}
