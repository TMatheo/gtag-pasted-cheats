﻿using System;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using UnityEngine;

namespace StupidTemplate
{
	// Token: 0x0200000D RID: 13
	internal class Settings
	{
		// Token: 0x0600013A RID: 314 RVA: 0x0000B468 File Offset: 0x00009668
		public Settings()
		{
			int num = 57;
			int num2 = 57;
			num2 = 57;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Settings), ref num, ref num2, ref num3, this, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 57;
		}

		// Token: 0x0600013B RID: 315 RVA: 0x0000B4A0 File Offset: 0x000096A0
		private static void EventMetadataAllowTrailingWhite(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = Settings.buttonsound == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 6;
			A_0 = num;
		}

		// Token: 0x0600013C RID: 316 RVA: 0x0000B504 File Offset: 0x00009704
		private static void ISponsorStelem(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			Settings.timething++;
			bool flag = Settings.timething > A_3.Length;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 42;
			A_0 = num;
		}

		// Token: 0x0600013D RID: 317 RVA: 0x0000B580 File Offset: 0x00009780
		private static void GetComponentPayloadPathCompatibilityFlag(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = Settings.buttonsound == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x0600013E RID: 318 RVA: 0x0000B5E4 File Offset: 0x000097E4
		private static void DNdgetIsSystemAclCanonical(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			string[] array = new string[]
			{
				"Smooth",
				"KB",
				"Button"
			};
			A_3 = array;
			bool flag = A_3.Length != 0;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 9 + 1;
			A_0 = num;
		}

		// Token: 0x0600013F RID: 319 RVA: 0x0000B68C File Offset: 0x0000988C
		private static void SqrtExceptionTypeToken(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Main.buttonClickSound = 66;
			bool flag = Settings.buttonsound == 3;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 8;
			A_0 = num;
		}

		// Token: 0x06000140 RID: 320 RVA: 0x0000B6FC File Offset: 0x000098FC
		private static void StopRequestedgetShortTimePattern(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Settings.stupidpoo++;
			bool flag = Settings.stupidpoo > A_3.Length;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 31;
			A_0 = num;
		}

		// Token: 0x06000141 RID: 321 RVA: 0x0000B778 File Offset: 0x00009978
		private static void FilterTasksFromWorkItemsdDirectoryObjectSecurity(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Settings.backgroundColor = new ExtGradient
			{
				colors = Main.GetSolidGradient(new Color32(0, 0, 74, byte.MaxValue))
			};
			Settings.buttonColors = new ExtGradient[]
			{
				new ExtGradient
				{
					colors = Main.GetSolidGradient(new Color32(0, 0, 74, byte.MaxValue))
				},
				new ExtGradient
				{
					colors = Main.GetSolidGradient(new Color32(0, 0, 74, byte.MaxValue))
				}
			};
			Settings.textColors = new Color[]
			{
				Color.white,
				Color.blue
			};
			Main.outlineColor = new Color32(2, 22, 199, byte.MaxValue);
			bool flag = Settings.stupidpoo == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 35;
			A_0 = num;
		}

		// Token: 0x06000142 RID: 322 RVA: 0x0000B8D8 File Offset: 0x00009AD8
		private static void ThreadPoolSetLastAccessTime(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			string[] array = new string[]
			{
				"Untouched",
				"Day",
				"Morning",
				"Noon",
				"Night"
			};
			A_3 = array;
			bool flag = A_3.Length != 0;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 13 + 41;
			A_0 = num;
		}

		// Token: 0x06000143 RID: 323 RVA: 0x0000B998 File Offset: 0x00009B98
		private static void ScopeActionDSASignatureDescription(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Settings.stupid++;
			bool flag = Settings.stupid > A_3.Length;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 22;
			A_0 = num;
		}

		// Token: 0x06000144 RID: 324 RVA: 0x0000BA14 File Offset: 0x00009C14
		private static void getDetailDYN(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			A_1 = 0;
		}

		// Token: 0x06000145 RID: 325 RVA: 0x0000BA2C File Offset: 0x00009C2C
		private static void DefaultValueGetSignatureFromToken(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = Settings.stupidpoo == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 33;
			A_0 = num;
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0000BA90 File Offset: 0x00009C90
		private static void TerminalServerSidEuropeanNumberTerminator(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			bool flag = Settings.timething == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 44;
			A_0 = num;
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0000BAF4 File Offset: 0x00009CF4
		private static void getCreationTimeUtcSecurityDocumentElement(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			bool flag = Settings.timething == 5;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 1 + 52;
			A_0 = num;
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0000BB58 File Offset: 0x00009D58
		private static void OpenMethodLoaderMaximum(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			bool flag = Settings.timething == 3;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 48;
			A_0 = num;
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0000BBBC File Offset: 0x00009DBC
		private static void addAssemblyLoadLongLength(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Main.GetIndex("CB").overlapText = "Button Type: " + A_3[Settings.stupid - 1];
			A_1 = 0;
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0000BC04 File Offset: 0x00009E04
		private static void OperationCompletedsetKeySpec(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.trailMenu = false;
			A_1 = 0;
		}

		// Token: 0x0600014B RID: 331 RVA: 0x0000BC28 File Offset: 0x00009E28
		private static void TaskSchedulerAwaitTaskContinuationIsWeakKey(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Main.GetIndex("CS").overlapText = "Color Scheme: " + A_3[Settings.stupidpoo - 1];
			A_1 = 0;
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0000BC70 File Offset: 0x00009E70
		private static void getKeyDataGetObject(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Settings.backgroundColor = new ExtGradient
			{
				colors = Main.GetSolidGradient(new Color32(42, 0, 74, byte.MaxValue))
			};
			Settings.buttonColors = new ExtGradient[]
			{
				new ExtGradient
				{
					colors = Main.GetSolidGradient(new Color32(42, 0, 74, byte.MaxValue))
				},
				new ExtGradient
				{
					colors = Main.GetSolidGradient(new Color32(42, 0, 74, byte.MaxValue))
				}
			};
			Settings.textColors = new Color[]
			{
				Color.white,
				Color.green
			};
			Main.outlineColor = new Color32(112, 0, 196, byte.MaxValue);
			bool flag = Settings.stupidpoo == 3;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 37;
			A_0 = num;
		}

		// Token: 0x0600014D RID: 333 RVA: 0x0000BDD0 File Offset: 0x00009FD0
		private static void OptionalPermissionsActivatedClientTypeEntry(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Settings.backgroundColor = new ExtGradient
			{
				colors = Main.GetSolidGradient(new Color32(18, 18, 18, byte.MaxValue))
			};
			Settings.buttonColors = new ExtGradient[]
			{
				new ExtGradient
				{
					colors = Main.GetSolidGradient(new Color32(18, 18, 18, byte.MaxValue))
				},
				new ExtGradient
				{
					colors = Main.GetSolidGradient(new Color32(18, 18, 18, byte.MaxValue))
				}
			};
			Settings.textColors = new Color[]
			{
				Color.white,
				Color.gray
			};
			Main.outlineColor = new Color32(41, 41, 41, byte.MaxValue);
			Main.GetIndex("CS").overlapText = "Color Scheme: " + A_3[Settings.stupidpoo - 1];
			A_1 = 0;
		}

		// Token: 0x0600014E RID: 334 RVA: 0x0000BF14 File Offset: 0x0000A114
		private static void ThrowOnEventWriteErrorsG(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool flag = Settings.stupid == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 26;
			A_0 = num;
		}

		// Token: 0x0600014F RID: 335 RVA: 0x0000BF78 File Offset: 0x0000A178
		private static void getCounterSectionAsyncWorkItem(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Settings.INC = 1;
			bool flag = Settings.INC == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 15;
			A_0 = num;
		}

		// Token: 0x06000150 RID: 336 RVA: 0x0000BFE8 File Offset: 0x0000A1E8
		private static void UnSafeCharBufferRng(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Settings.buttonsound++;
			bool flag = Settings.buttonsound > A_3.Length;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 2;
			A_0 = num;
		}

		// Token: 0x06000151 RID: 337 RVA: 0x0000C064 File Offset: 0x0000A264
		public static void ChangeTime()
		{
			int num = 40;
			int num2 = 40;
			num2 = 40;
			while (num2 != 0)
			{
				int num3;
				string[] array;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				bool flag5;
				bool flag6;
				bool flag7;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.String[]&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref array, ref flag, ref flag2, ref flag3, ref flag4, ref flag5, ref flag6, ref flag7, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 40;
		}

		// Token: 0x06000152 RID: 338 RVA: 0x0000C0AC File Offset: 0x0000A2AC
		private static void getChannelSinkChainCurrentThread(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Settings.stupidpoo = 1;
			bool flag = Settings.stupidpoo == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 33;
			A_0 = num;
		}

		// Token: 0x06000153 RID: 339 RVA: 0x0000C11C File Offset: 0x0000A31C
		private static void StoreAssemblyFileEnumerationgetPackingSize(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			Main.GetIndex("TOD").overlapText = "Time Of Day: " + A_3[Settings.timething - 1];
			A_1 = 0;
		}

		// Token: 0x06000154 RID: 340 RVA: 0x0000C164 File Offset: 0x0000A364
		private static void ReadPermissionsNativeRegisterStack(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Main.GetIndex("CBS").overlapText = "Toggle Sound: " + A_3[Settings.buttonsound - 1];
			A_1 = 11;
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0000C1AC File Offset: 0x0000A3AC
		private static void MillisecondsIDeferredDisposable(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Main.buttonClickSound = 114;
			bool flag = Settings.buttonsound == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 6;
			A_0 = num;
		}

		// Token: 0x06000156 RID: 342 RVA: 0x0000C21C File Offset: 0x0000A41C
		private static void EmptyTypesWinBuiltinTerminalServerLicenseServersSid(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			BetterDayNightManager.instance.SetTimeOfDay(3);
			bool flag = Settings.timething == 3;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 48;
			A_0 = num;
		}

		// Token: 0x06000157 RID: 343 RVA: 0x0000C294 File Offset: 0x0000A494
		private static void InternalsVisibleToAttributeConstructorInfo(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Settings.disconnectButton = true;
			bool flag = Settings.INC == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 17;
			A_0 = num;
		}

		// Token: 0x06000158 RID: 344 RVA: 0x0000C304 File Offset: 0x0000A504
		private static void SpinLockGetResourceString(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool flag = Settings.stupid == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 24;
			A_0 = num;
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0000C368 File Offset: 0x0000A568
		private static void MetadataSectionRuntimeImageVersiongetDayNames(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			BetterDayNightManager.instance.SetTimeOfDay(0);
			Main.GetIndex("TOD").overlapText = "Time Of Day: " + A_3[Settings.timething - 1];
			A_1 = 0;
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0000C3C4 File Offset: 0x0000A5C4
		private static void VarpopgetIsClass(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.backgroundColor = new ExtGradient
			{
				colors = Main.GetSolidGradient(new Color32(0, 0, 74, byte.MaxValue))
			};
			Settings.buttonColors = new ExtGradient[]
			{
				new ExtGradient
				{
					colors = Main.GetSolidGradient(new Color32(0, 0, 74, byte.MaxValue))
				},
				new ExtGradient
				{
					colors = Main.GetSolidGradient(new Color32(0, 0, 74, byte.MaxValue))
				}
			};
			Settings.textColors = new Color[]
			{
				Color.white,
				Color.blue
			};
			Settings.currentFont = (Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font);
			Settings.fpsCounter = true;
			Settings.disconnectButton = true;
			Settings.rightHanded = false;
			Settings.disableNotifications = false;
			Settings.keyboardButton = 113;
			Settings.menuSize = new Vector3(0.1f, 1f, 1f);
			Settings.buttonsPerPage = 4;
			Settings.buttonsound = 1;
			Settings.INC = 1;
			Settings.stupid = 1;
			Settings.stupidpoo = 1;
			Settings.timething = 1;
			A_1 = 0;
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0000C55C File Offset: 0x0000A75C
		private static void TasksFlowActivityIdserr(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			A_1 = 0;
		}

		// Token: 0x0600015C RID: 348 RVA: 0x0000C574 File Offset: 0x0000A774
		private static void GetTypeInfoCountsetUserQuota(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			bool flag = Settings.timething == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 46;
			A_0 = num;
		}

		// Token: 0x0600015D RID: 349 RVA: 0x0000C5D8 File Offset: 0x0000A7D8
		private static void PROCESSORIDARRAYQ(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Main.checkBoxButtons = false;
			bool flag = Settings.stupid == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 26;
			A_0 = num;
		}

		// Token: 0x0600015E RID: 350 RVA: 0x0000C648 File Offset: 0x0000A848
		private static void XmlToFieldTypeMapSystemTime(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Settings.stupid = 1;
			bool flag = Settings.stupid == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 24;
			A_0 = num;
		}

		// Token: 0x0600015F RID: 351 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
		private static void IterationCountDiscretionaryAclUntrusted(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			BetterDayNightManager.instance.SetTimeOfDay(5);
			bool flag = Settings.timething == 5;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 1 + 52;
			A_0 = num;
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0000C730 File Offset: 0x0000A930
		private static void TaskNodegetTarget(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Settings.INC++;
			bool flag = Settings.INC > A_3.Length;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 13;
			A_0 = num;
		}

		// Token: 0x06000161 RID: 353 RVA: 0x0000C7AC File Offset: 0x0000A9AC
		private static void getEndOffsetRemoting(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x06000162 RID: 354 RVA: 0x0000C7C4 File Offset: 0x0000A9C4
		private static void ApplicationInlineI(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			string[] array = new string[]
			{
				"Selenite",
				"Sapphire",
				"OnyX"
			};
			A_3 = array;
			bool flag = A_3.Length != 0;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 9 + 30;
			A_0 = num;
		}

		// Token: 0x06000163 RID: 355 RVA: 0x0000C86C File Offset: 0x0000AA6C
		private static void GetUserStoreForApplicationPrivilegeName(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Main.checkBoxButtons = true;
			Main.GetIndex("CB").overlapText = "Button Type: " + A_3[Settings.stupid - 1];
			A_1 = 0;
		}

		// Token: 0x06000164 RID: 356 RVA: 0x0000C8C0 File Offset: 0x0000AAC0
		private static void getAttributeStringResolveAsmEvent(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Settings.buttonsound = 1;
			bool flag = Settings.buttonsound == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x06000165 RID: 357 RVA: 0x0000C930 File Offset: 0x0000AB30
		public static void NoMenuTrail()
		{
			int num = 56;
			int num2 = 56;
			num2 = 56;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 56;
		}

		// Token: 0x06000166 RID: 358 RVA: 0x0000C968 File Offset: 0x0000AB68
		private static void CodePageIsolatedStorageFilePermissionAttribute(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			A_1 = 0;
		}

		// Token: 0x06000167 RID: 359 RVA: 0x0000C980 File Offset: 0x0000AB80
		private static void NotOnCanceledWritableType(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 11;
		}

		// Token: 0x06000168 RID: 360 RVA: 0x0000C998 File Offset: 0x0000AB98
		// Note: this type is marked as 'beforefieldinit'.
		static Settings()
		{
			Settings.PropertyTokenGetCommandLineArgs();
			int num = 58;
			int num2 = 58;
			num2 = 58;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 58;
		}

		// Token: 0x06000169 RID: 361 RVA: 0x0000C9D4 File Offset: 0x0000ABD4
		private static void getSectionIDInvalidOleVariantTypeException(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool flag = Settings.INC == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 17;
			A_0 = num;
		}

		// Token: 0x0600016A RID: 362 RVA: 0x0000CA38 File Offset: 0x0000AC38
		private static void GetClientContextSinkgetWriterSeqNum(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			BetterDayNightManager.instance.SetTimeOfDay(10);
			bool flag = Settings.timething == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 46;
			A_0 = num;
		}

		// Token: 0x0600016B RID: 363 RVA: 0x0000CAB0 File Offset: 0x0000ACB0
		private static void IsParamDefStoreOperationMetadataProperty(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Main.buttonClickSound = 67;
			Main.GetIndex("CBS").overlapText = "Toggle Sound: " + A_3[Settings.buttonsound - 1];
			A_1 = 11;
		}

		// Token: 0x0600016C RID: 364 RVA: 0x0000CB04 File Offset: 0x0000AD04
		private static void RequestedExecutionLevelHeaderName(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			bool flag = Settings.timething == 4;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 50;
			A_0 = num;
		}

		// Token: 0x0600016D RID: 365 RVA: 0x0000CB68 File Offset: 0x0000AD68
		private static void IsPinvokeImplFloat(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			string[] array = new string[]
			{
				"Enabled",
				"Disabled"
			};
			A_3 = array;
			bool flag = A_3.Length != 0;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 7 + 12;
			A_0 = num;
		}

		// Token: 0x0600016E RID: 366 RVA: 0x0000CC04 File Offset: 0x0000AE04
		private static void CreateDigestUrlAttribute(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = Settings.stupidpoo == 2;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 35;
			A_0 = num;
		}

		// Token: 0x0600016F RID: 367 RVA: 0x0000CC68 File Offset: 0x0000AE68
		public static void ChangeButton()
		{
			int num = 20;
			int num2 = 20;
			num2 = 20;
			while (num2 != 0)
			{
				int num3;
				string[] array;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.String[]&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref array, ref flag, ref flag2, ref flag3, ref flag4, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 20;
		}

		// Token: 0x06000170 RID: 368 RVA: 0x0000CCA8 File Offset: 0x0000AEA8
		private static void TraceGuidQueryProcessIAssemblyRequestEntry(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			Settings.timething = 1;
			bool flag = Settings.timething == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 44;
			A_0 = num;
		}

		// Token: 0x06000171 RID: 369 RVA: 0x0000CD18 File Offset: 0x0000AF18
		public static void ChangeDisconnectButtonValue()
		{
			int num = 11;
			int num2 = 11;
			num2 = 11;
			while (num2 != 0)
			{
				int num3;
				string[] array;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.String[]&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref array, ref flag, ref flag2, ref flag3, ref flag4, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 11;
		}

		// Token: 0x06000172 RID: 370 RVA: 0x0000CD58 File Offset: 0x0000AF58
		private static void opDivisionWindowsDeviceClaim(ref int A_0, ref int A_1, ref int A_2, Settings A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000173 RID: 371 RVA: 0x0000CD7C File Offset: 0x0000AF7C
		private static void setRestrictedMemberAccessResourceManagerNotCreatingResourceSet(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			string[] array = new string[]
			{
				"Default",
				"Checkbox"
			};
			A_3 = array;
			bool flag = A_3.Length != 0;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 7 + 21;
			A_0 = num;
		}

		// Token: 0x06000174 RID: 372 RVA: 0x0000CE18 File Offset: 0x0000B018
		private static void getFormCleanupUnusedObjectsInCurrentContext(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = Settings.buttonsound == 3;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 8;
			A_0 = num;
		}

		// Token: 0x06000175 RID: 373 RVA: 0x0000CE7C File Offset: 0x0000B07C
		public static void ChangeScheme()
		{
			int num = 29;
			int num2 = 29;
			num2 = 29;
			while (num2 != 0)
			{
				int num3;
				string[] array;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				bool flag5;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.String[]&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref array, ref flag, ref flag2, ref flag3, ref flag4, ref flag5, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 29;
		}

		// Token: 0x06000176 RID: 374 RVA: 0x0000CEC0 File Offset: 0x0000B0C0
		private static void AwaitTaskContinuationScheduledNextActivator(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Settings.disconnectButton = false;
			Main.GetIndex("DB").overlapText = "Disconnect Button: " + A_3[Settings.INC - 1];
			A_1 = 0;
		}

		// Token: 0x06000177 RID: 375 RVA: 0x0000CF14 File Offset: 0x0000B114
		public static void MenuTrail()
		{
			int num = 55;
			int num2 = 55;
			num2 = 55;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 55;
		}

		// Token: 0x06000178 RID: 376 RVA: 0x0000CF4C File Offset: 0x0000B14C
		private static void BindHandleContract(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.trailMenu = true;
			A_1 = 0;
		}

		// Token: 0x06000179 RID: 377 RVA: 0x0000CF70 File Offset: 0x0000B170
		private static void AccesssetLastAccessTime(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			Main.GetIndex("DB").overlapText = "Disconnect Button: " + A_3[Settings.INC - 1];
			A_1 = 0;
		}

		// Token: 0x0600017A RID: 378 RVA: 0x0000CFB8 File Offset: 0x0000B1B8
		private static void DeploymentMetadataMinimumRequiredVersionBufferHeight(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10)
		{
			BetterDayNightManager.instance.SetTimeOfDay(2);
			bool flag = Settings.timething == 4;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 50;
			A_0 = num;
		}

		// Token: 0x0600017B RID: 379 RVA: 0x0000D030 File Offset: 0x0000B230
		private static void EndGetRequestStreamgetIsFieldDef(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = Settings.stupidpoo == 3;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 37;
			A_0 = num;
		}

		// Token: 0x0600017C RID: 380 RVA: 0x0000D094 File Offset: 0x0000B294
		public static void ChangeButtonSound()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 11)
			{
				int num3;
				string[] array;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				bool flag5;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.String[]&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref array, ref flag, ref flag2, ref flag3, ref flag4, ref flag5, Settings.StreamWriterOperationCanceledException[num]);
			}
			num2 = 0;
		}

		// Token: 0x0600017D RID: 381 RVA: 0x0000D0D4 File Offset: 0x0000B2D4
		private static void ReturnValueInlineUserMessage(ref int A_0, ref int A_1, ref int A_2, ref string[] A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool flag = Settings.INC == 1;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 15;
			A_0 = num;
		}

		// Token: 0x0600017E RID: 382 RVA: 0x0000D138 File Offset: 0x0000B338
		private static void PropertyTokenGetCommandLineArgs()
		{
			Settings.StreamWriterOperationCanceledException = new IntPtr[59];
			Settings.StreamWriterOperationCanceledException[0] = ldftn(DNdgetIsSystemAclCanonical);
			Settings.StreamWriterOperationCanceledException[1] = ldftn(UnSafeCharBufferRng);
			Settings.StreamWriterOperationCanceledException[2] = ldftn(getAttributeStringResolveAsmEvent);
			Settings.StreamWriterOperationCanceledException[3] = ldftn(GetComponentPayloadPathCompatibilityFlag);
			Settings.StreamWriterOperationCanceledException[4] = ldftn(MillisecondsIDeferredDisposable);
			Settings.StreamWriterOperationCanceledException[5] = ldftn(EventMetadataAllowTrailingWhite);
			Settings.StreamWriterOperationCanceledException[6] = ldftn(SqrtExceptionTypeToken);
			Settings.StreamWriterOperationCanceledException[7] = ldftn(getFormCleanupUnusedObjectsInCurrentContext);
			Settings.StreamWriterOperationCanceledException[8] = ldftn(IsParamDefStoreOperationMetadataProperty);
			Settings.StreamWriterOperationCanceledException[9] = ldftn(ReadPermissionsNativeRegisterStack);
			Settings.StreamWriterOperationCanceledException[10] = ldftn(NotOnCanceledWritableType);
			Settings.StreamWriterOperationCanceledException[11] = ldftn(IsPinvokeImplFloat);
			Settings.StreamWriterOperationCanceledException[12] = ldftn(TaskNodegetTarget);
			Settings.StreamWriterOperationCanceledException[13] = ldftn(getCounterSectionAsyncWorkItem);
			Settings.StreamWriterOperationCanceledException[14] = ldftn(ReturnValueInlineUserMessage);
			Settings.StreamWriterOperationCanceledException[15] = ldftn(InternalsVisibleToAttributeConstructorInfo);
			Settings.StreamWriterOperationCanceledException[16] = ldftn(getSectionIDInvalidOleVariantTypeException);
			Settings.StreamWriterOperationCanceledException[17] = ldftn(AwaitTaskContinuationScheduledNextActivator);
			Settings.StreamWriterOperationCanceledException[18] = ldftn(AccesssetLastAccessTime);
			Settings.StreamWriterOperationCanceledException[19] = ldftn(TasksFlowActivityIdserr);
			Settings.StreamWriterOperationCanceledException[20] = ldftn(setRestrictedMemberAccessResourceManagerNotCreatingResourceSet);
			Settings.StreamWriterOperationCanceledException[21] = ldftn(ScopeActionDSASignatureDescription);
			Settings.StreamWriterOperationCanceledException[22] = ldftn(XmlToFieldTypeMapSystemTime);
			Settings.StreamWriterOperationCanceledException[23] = ldftn(SpinLockGetResourceString);
			Settings.StreamWriterOperationCanceledException[24] = ldftn(PROCESSORIDARRAYQ);
			Settings.StreamWriterOperationCanceledException[25] = ldftn(ThrowOnEventWriteErrorsG);
			Settings.StreamWriterOperationCanceledException[26] = ldftn(GetUserStoreForApplicationPrivilegeName);
			Settings.StreamWriterOperationCanceledException[27] = ldftn(addAssemblyLoadLongLength);
			Settings.StreamWriterOperationCanceledException[28] = ldftn(getDetailDYN);
			Settings.StreamWriterOperationCanceledException[29] = ldftn(ApplicationInlineI);
			Settings.StreamWriterOperationCanceledException[30] = ldftn(StopRequestedgetShortTimePattern);
			Settings.StreamWriterOperationCanceledException[31] = ldftn(getChannelSinkChainCurrentThread);
			Settings.StreamWriterOperationCanceledException[32] = ldftn(DefaultValueGetSignatureFromToken);
			Settings.StreamWriterOperationCanceledException[33] = ldftn(FilterTasksFromWorkItemsdDirectoryObjectSecurity);
			Settings.StreamWriterOperationCanceledException[34] = ldftn(CreateDigestUrlAttribute);
			Settings.StreamWriterOperationCanceledException[35] = ldftn(getKeyDataGetObject);
			Settings.StreamWriterOperationCanceledException[36] = ldftn(EndGetRequestStreamgetIsFieldDef);
			Settings.StreamWriterOperationCanceledException[37] = ldftn(OptionalPermissionsActivatedClientTypeEntry);
			Settings.StreamWriterOperationCanceledException[38] = ldftn(TaskSchedulerAwaitTaskContinuationIsWeakKey);
			Settings.StreamWriterOperationCanceledException[39] = ldftn(getEndOffsetRemoting);
			Settings.StreamWriterOperationCanceledException[40] = ldftn(ThreadPoolSetLastAccessTime);
			Settings.StreamWriterOperationCanceledException[41] = ldftn(ISponsorStelem);
			Settings.StreamWriterOperationCanceledException[42] = ldftn(TraceGuidQueryProcessIAssemblyRequestEntry);
			Settings.StreamWriterOperationCanceledException[43] = ldftn(TerminalServerSidEuropeanNumberTerminator);
			Settings.StreamWriterOperationCanceledException[44] = ldftn(GetClientContextSinkgetWriterSeqNum);
			Settings.StreamWriterOperationCanceledException[45] = ldftn(GetTypeInfoCountsetUserQuota);
			Settings.StreamWriterOperationCanceledException[46] = ldftn(EmptyTypesWinBuiltinTerminalServerLicenseServersSid);
			Settings.StreamWriterOperationCanceledException[47] = ldftn(OpenMethodLoaderMaximum);
			Settings.StreamWriterOperationCanceledException[48] = ldftn(DeploymentMetadataMinimumRequiredVersionBufferHeight);
			Settings.StreamWriterOperationCanceledException[49] = ldftn(RequestedExecutionLevelHeaderName);
			Settings.StreamWriterOperationCanceledException[50] = ldftn(IterationCountDiscretionaryAclUntrusted);
			Settings.StreamWriterOperationCanceledException[51] = ldftn(getCreationTimeUtcSecurityDocumentElement);
			Settings.StreamWriterOperationCanceledException[52] = ldftn(MetadataSectionRuntimeImageVersiongetDayNames);
			Settings.StreamWriterOperationCanceledException[53] = ldftn(StoreAssemblyFileEnumerationgetPackingSize);
			Settings.StreamWriterOperationCanceledException[54] = ldftn(CodePageIsolatedStorageFilePermissionAttribute);
			Settings.StreamWriterOperationCanceledException[55] = ldftn(BindHandleContract);
			Settings.StreamWriterOperationCanceledException[56] = ldftn(OperationCompletedsetKeySpec);
			Settings.StreamWriterOperationCanceledException[57] = ldftn(opDivisionWindowsDeviceClaim);
			Settings.StreamWriterOperationCanceledException[58] = ldftn(VarpopgetIsClass);
		}

		// Token: 0x04000050 RID: 80
		public static ExtGradient backgroundColor;

		// Token: 0x04000051 RID: 81
		public static ExtGradient[] buttonColors;

		// Token: 0x04000052 RID: 82
		public static Color[] textColors;

		// Token: 0x04000053 RID: 83
		public static Font currentFont;

		// Token: 0x04000054 RID: 84
		public static bool fpsCounter;

		// Token: 0x04000055 RID: 85
		public static bool disconnectButton;

		// Token: 0x04000056 RID: 86
		public static bool rightHanded;

		// Token: 0x04000057 RID: 87
		public static bool disableNotifications;

		// Token: 0x04000058 RID: 88
		public static KeyCode keyboardButton;

		// Token: 0x04000059 RID: 89
		public static Vector3 menuSize;

		// Token: 0x0400005A RID: 90
		public static int buttonsPerPage;

		// Token: 0x0400005B RID: 91
		public static int buttonsound;

		// Token: 0x0400005C RID: 92
		public static int INC;

		// Token: 0x0400005D RID: 93
		public static int stupid;

		// Token: 0x0400005E RID: 94
		public static int stupidpoo;

		// Token: 0x0400005F RID: 95
		public static int timething;

		// Token: 0x04000060 RID: 96
		private static IntPtr[] StreamWriterOperationCanceledException;
	}
}
