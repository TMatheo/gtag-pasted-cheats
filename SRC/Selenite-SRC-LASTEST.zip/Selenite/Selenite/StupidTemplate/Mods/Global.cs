﻿using System;
using StupidTemplate.Menu;

namespace StupidTemplate.Mods
{
	// Token: 0x02000032 RID: 50
	internal class Global
	{
		// Token: 0x06000769 RID: 1897 RVA: 0x000484CC File Offset: 0x000466CC
		public Global()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.Global), ref num, ref num2, ref num3, this, Global.WhiteVirtual[num]);
			}
			num2 = 1;
		}

		// Token: 0x0600076A RID: 1898 RVA: 0x00048500 File Offset: 0x00046700
		private static void CodePageDataFileHeaderSeparator(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.returnEnabled = false;
			Main.cat = "Category_Main";
			Main.buttonsType = 0;
			Main.pageNumber = 0;
			A_1 = 1;
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x00048540 File Offset: 0x00046740
		public static void ReturnHome()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Global.WhiteVirtual[num]);
			}
			num2 = 0;
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x00048574 File Offset: 0x00046774
		private static void setCodeBaseRegistrationServices(ref int A_0, ref int A_1, ref int A_2, Global A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x00048598 File Offset: 0x00046798
		// Note: this type is marked as 'beforefieldinit'.
		static Global()
		{
			Global.ResWFilegetExternalThreading();
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x000485AC File Offset: 0x000467AC
		private static void ResWFilegetExternalThreading()
		{
			Global.WhiteVirtual = new IntPtr[2];
			Global.WhiteVirtual[0] = ldftn(CodePageDataFileHeaderSeparator);
			Global.WhiteVirtual[1] = ldftn(setCodeBaseRegistrationServices);
		}

		// Token: 0x040000E0 RID: 224
		private static IntPtr[] WhiteVirtual;
	}
}
