﻿using System;
using System.Collections.Generic;
using GorillaLocomotion;
using GorillaLocomotion.Gameplay;
using GorillaNetworking;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using UnityEngine;

namespace StupidTemplate.Mods
{
	// Token: 0x02000029 RID: 41
	internal class RPCStuff
	{
		// Token: 0x060005B3 RID: 1459 RVA: 0x00039168 File Offset: 0x00037368
		private static void IChannelDataStoreSupportsLastError(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref float A_5, ref float A_6, ref float A_7, ref bool A_8)
		{
			float time = Time.time;
			A_3 = time;
			float num = Mathf.PingPong(A_3 * 0.1f, 0.3f);
			A_4 = num;
			float num2 = Mathf.PingPong(A_3 * 0.1f + 0.1f, 0.1f);
			A_5 = num2;
			float num3 = Mathf.PingPong(A_3 * 0.1f + 1f, 1f);
			A_6 = num3;
			float num4 = (float)Time.frameCount / 180f % 1f;
			A_7 = num4;
			bool inRoom = PhotonNetwork.InRoom;
			A_8 = inRoom;
			int num5 = ((!A_8) ? 1 : 0) * 1 + 1;
			A_0 = num5;
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x00039288 File Offset: 0x00037488
		public static void BlindGun()
		{
			int num = 86;
			int num2 = 86;
			num2 = 86;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 86;
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x000392C0 File Offset: 0x000374C0
		private static void setVolumeLabelLongPathFile(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			GorillaRopeSwing gorillaRopeSwing = A_4[A_5];
			A_6 = gorillaRopeSwing;
			PhotonView photonView = RopeSwingManager.instance.photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = 0;
			object[] array = new object[5];
			array[0] = A_6.ropeId;
			array[1] = 1;
			array[2] = new Vector3(0f, 100f, 1f);
			array[3] = true;
			photonView.RPC(text, rpcTarget, array);
			Main.RPCProtection();
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 46;
			A_0 = num2;
		}

		// Token: 0x060005B6 RID: 1462 RVA: 0x000393C8 File Offset: 0x000375C8
		private static void NativeVariantConstructorName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			A_7.gameObject.transform.position = GTPlayer.Instance.rightControllerTransform.position;
			int num = A_6 + 1;
			A_6 = num;
			int num2 = ((A_6 < A_5.Length) ? 1 : 0) * -4 + 67;
			A_0 = num2;
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x00039450 File Offset: 0x00037650
		private static void setControlAppDomainFind(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			int num = (((Time.time > RPCStuff.splashtimeout + 0.1f) ? 1 : 0) + -1) * -1 * 1 + 17;
			A_0 = num;
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x00039498 File Offset: 0x00037698
		private static void setLastWriteTimeSECURITYLOGONSESSIONDATA(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool inRoom = PhotonNetwork.InRoom;
			A_3 = inRoom;
			int num = ((!A_3) ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x060005B9 RID: 1465 RVA: 0x000394F4 File Offset: 0x000376F4
		public static void StrobeMonkey()
		{
			int num = 3;
			int num2 = 3;
			num2 = 3;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 3;
		}

		// Token: 0x060005BA RID: 1466 RVA: 0x00039528 File Offset: 0x00037728
		public static void SplashGun()
		{
			int num = 15;
			int num2 = 15;
			num2 = 15;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 15;
		}

		// Token: 0x060005BB RID: 1467 RVA: 0x00039560 File Offset: 0x00037760
		private static void AsyncMessageHelperIServerFormatterSinkProvider(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.1f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 88;
			A_0 = num;
		}

		// Token: 0x060005BC RID: 1468 RVA: 0x000395CC File Offset: 0x000377CC
		private static void setOutputEncodingSetInterfaceConstraints(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<CosmeticsController.CosmeticItem>.Enumerator A_4, ref CosmeticsController.CosmeticItem A_5, ref Action<string> A_6)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -2 + 123;
			A_0 = num;
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x00039614 File Offset: 0x00037814
		private static void SecureStringToGlobalAllocAnsiGetOrderableDynamicPartitions(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			RPCStuff.splashtimeout = Time.time;
			GliderHoldable[] array = Object.FindObjectsOfType<GliderHoldable>();
			A_5 = array;
			int num = 0;
			A_6 = num;
			A_0 = 66;
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x00039664 File Offset: 0x00037864
		private static void FilterAttributeGetSoapActionFromMethodBase(ref int A_0, ref int A_1, ref int A_2, ref GorillaRopeSwing[] A_3, ref int A_4, ref GorillaRopeSwing A_5)
		{
			GorillaRopeSwing gorillaRopeSwing = A_3[A_4];
			A_5 = gorillaRopeSwing;
			PhotonView photonView = RopeSwingManager.instance.photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = 0;
			object[] array = new object[5];
			array[0] = A_5.ropeId;
			array[1] = 1;
			array[2] = new Vector3(1E-12f, 1E-12f, 1E-12f);
			array[3] = true;
			photonView.RPC(text, rpcTarget, array);
			Main.RPCProtection();
			int num = A_4 + 1;
			A_4 = num;
			int num2 = ((A_4 < A_3.Length) ? 1 : 0) * -2 + 102;
			A_0 = num2;
		}

		// Token: 0x060005BF RID: 1471 RVA: 0x0003976C File Offset: 0x0003796C
		private static void InternetCacheRemoveOnLogSwitchLevel(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			GliderHoldable gliderHoldable = A_5[A_6];
			A_7 = gliderHoldable;
			bool flag = A_7.GetView.Owner == PhotonNetwork.LocalPlayer;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 64;
			A_0 = num;
		}

		// Token: 0x060005C0 RID: 1472 RVA: 0x00039804 File Offset: 0x00037A04
		private static void CMSTIMEUNITTYPEDAYSgetAutoFlush(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			int num = ((A_6 < A_5.Length) ? 1 : 0) * -4 + 67;
			A_0 = num;
		}

		// Token: 0x060005C1 RID: 1473 RVA: 0x00039840 File Offset: 0x00037A40
		private static void VTUNKNOWNgetPreviousValue(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.1f;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 6 + 71;
			A_0 = num;
		}

		// Token: 0x060005C2 RID: 1474 RVA: 0x000398AC File Offset: 0x00037AAC
		private static void GetApartmentStateLastNodeType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			GliderHoldable gliderHoldable = A_11[A_12];
			A_13 = gliderHoldable;
			bool flag = A_13.GetView.Owner == PhotonNetwork.LocalPlayer;
			A_14 = flag;
			int num = ((!A_14) ? 1 : 0) * 1 + 73;
			A_0 = num;
		}

		// Token: 0x060005C3 RID: 1475 RVA: 0x00039944 File Offset: 0x00037B44
		private static void ToDateTimeOverlapped(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			GorillaRopeSwing gorillaRopeSwing = A_4[A_5];
			A_6 = gorillaRopeSwing;
			PhotonView photonView = RopeSwingManager.instance.photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = 0;
			object[] array = new object[5];
			array[0] = A_6.ropeId;
			array[1] = 1;
			array[2] = new Vector3(100f, 100f, 100f);
			array[3] = true;
			photonView.RPC(text, rpcTarget, array);
			Main.RPCProtection();
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 113;
			A_0 = num2;
		}

		// Token: 0x060005C4 RID: 1476 RVA: 0x00039A4C File Offset: 0x00037C4C
		private static void JaggedCorElementType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			GorillaRopeSwing gorillaRopeSwing = A_4[A_5];
			A_6 = gorillaRopeSwing;
			PhotonView photonView = RopeSwingManager.instance.photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = 0;
			object[] array = new object[5];
			array[0] = A_6.ropeId;
			array[1] = 1;
			array[2] = new Vector3(0f, -100f, 1f);
			array[3] = true;
			photonView.RPC(text, rpcTarget, array);
			Main.RPCProtection();
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 52;
			A_0 = num2;
		}

		// Token: 0x060005C5 RID: 1477 RVA: 0x00039B54 File Offset: 0x00037D54
		private static void TargetTypeAssemblyGetInArgName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 91;
			A_0 = num;
		}

		// Token: 0x060005C6 RID: 1478 RVA: 0x00039B90 File Offset: 0x00037D90
		private static void DialupSidInterfaceTypeAttribute(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 15;
				int num2 = 15;
				num2 = 15;
				while (num2 != 0)
				{
					int num3;
					bool flag;
					GliderHoldable[] array;
					int num4;
					GliderHoldable gliderHoldable;
					bool flag2;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GliderHoldable[]&,System.Int32&,GliderHoldable&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gliderHoldable, ref flag2, RPCStuff.<>c.IIdentityGetValueNames[num]);
				}
				num2 = 15;
			}, true);
			A_1 = 0;
		}

		// Token: 0x060005C7 RID: 1479 RVA: 0x00039BD8 File Offset: 0x00037DD8
		private static void DefaultBinderNotImplementedException(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<CosmeticsController.CosmeticItem>.Enumerator A_4, ref CosmeticsController.CosmeticItem A_5, ref Action<string> A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005C8 RID: 1480 RVA: 0x00039BF0 File Offset: 0x00037DF0
		private static void DynamicPartitionerForArrayIsEnum(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			RPCStuff.splashtimeout = Time.time;
			NotifiLib.SendNotification("<color=red>Anti Ban will not be executed while not being in a room, please join a room!");
			A_1 = 0;
		}

		// Token: 0x060005C9 RID: 1481 RVA: 0x00039C20 File Offset: 0x00037E20
		private static void MicrosoftTelemetryDependentOSMetadataDescription(ref int A_0, ref int A_1, ref int A_2, ref GorillaRopeSwing[] A_3, ref int A_4, ref GorillaRopeSwing A_5)
		{
			GorillaRopeSwing gorillaRopeSwing = A_3[A_4];
			A_5 = gorillaRopeSwing;
			PhotonNetwork.Disconnect();
			int num = A_4 + 1;
			A_4 = num;
			int num2 = ((A_4 < A_3.Length) ? 1 : 0) * -2 + 118;
			A_0 = num2;
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x00039CA8 File Offset: 0x00037EA8
		private static void GetTypeCompAssignPrimaryToken(ref int A_0, ref int A_1, ref int A_2, ref GorillaRopeSwing[] A_3, ref int A_4, ref GorillaRopeSwing A_5)
		{
			A_1 = 0;
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x00039CC0 File Offset: 0x00037EC0
		private static void TypeLibFuncAttributeNodeEnumerator(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 52;
			A_0 = num;
		}

		// Token: 0x060005CC RID: 1484 RVA: 0x00039CFC File Offset: 0x00037EFC
		public static void GliderGun()
		{
			int num = 85;
			int num2 = 85;
			num2 = 85;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 85;
		}

		// Token: 0x060005CD RID: 1485 RVA: 0x00039D34 File Offset: 0x00037F34
		private static void getOffendingNumberIsolatedStorageSecurityOptions(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<CosmeticsController.CosmeticItem>.Enumerator A_4, ref CosmeticsController.CosmeticItem A_5, ref Action<string> A_6)
		{
			Action onCosmeticsUpdated = CosmeticsController.instance.OnCosmeticsUpdated;
			if (onCosmeticsUpdated == null)
			{
				A_0 = 126;
				return;
			}
			onCosmeticsUpdated.Invoke();
			A_1 = 0;
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x00039D70 File Offset: 0x00037F70
		private static void StringToLongEncoderReplacementFallback(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.3f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 55;
			A_0 = num;
		}

		// Token: 0x060005CF RID: 1487 RVA: 0x00039DDC File Offset: 0x00037FDC
		private static void CompressedStackMemoryFailPoint(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			A_6 = rightControllerPrimaryButton;
			int num = ((!A_6) ? 1 : 0) * 1 + 24;
			A_0 = num;
		}

		// Token: 0x060005D0 RID: 1488 RVA: 0x00039E40 File Offset: 0x00038040
		private static void getRegistryKeySectionCreateWrapperOfType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			A_1 = 0;
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x00039E58 File Offset: 0x00038058
		private static void VTSTREAMgetMaxStackSize(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x00039E70 File Offset: 0x00038070
		private static void DependentOSMetadataSupportUrlINVOCATIONFLAGSRISKYMETHOD(ref int A_0, ref int A_1, ref int A_2, ref GliderHoldable[] A_3, ref int A_4, ref GliderHoldable A_5, ref bool A_6)
		{
			A_5.gameObject.transform.rotation = Random.rotation;
			int num = A_4 + 1;
			A_4 = num;
			int num2 = ((A_4 < A_3.Length) ? 1 : 0) * -4 + 84;
			A_0 = num2;
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x00039EF0 File Offset: 0x000380F0
		private static void ManifestResourceWinNT(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			A_13.gameObject.transform.position = GTPlayer.Instance.leftControllerTransform.position;
			int num = A_12 + 1;
			A_12 = num;
			int num2 = ((A_12 < A_11.Length) ? 1 : 0) * -4 + 76;
			A_0 = num2;
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x00039F78 File Offset: 0x00038178
		public static void RopesSpaz()
		{
			int num = 87;
			int num2 = 87;
			num2 = 87;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 87;
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x00039FB8 File Offset: 0x000381B8
		public static void RopesJiggle()
		{
			int num = 54;
			int num2 = 54;
			num2 = 54;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 54;
		}

		// Token: 0x060005D6 RID: 1494 RVA: 0x00039FF8 File Offset: 0x000381F8
		private static void getCanWriteRemotingProxy(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			RPCStuff.splashtimeout = Time.time;
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 51;
		}

		// Token: 0x060005D7 RID: 1495 RVA: 0x0003A048 File Offset: 0x00038248
		private static void MinValueaddCancelKeyPress(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x0003A060 File Offset: 0x00038260
		public static void AntiBan()
		{
			int num = 29;
			int num2 = 29;
			num2 = 29;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaNot gorillaNot;
				bool flag2;
				PhotonView photonView;
				bool flag3;
				bool flag4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaNot&,System.Boolean&,Photon.Pun.PhotonView&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref gorillaNot, ref flag2, ref photonView, ref flag3, ref flag4, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 29;
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x0003A0A4 File Offset: 0x000382A4
		private static void EmptySetINVOCATIONFLAGSFIELDSPECIALCAST(ref int A_0, ref int A_1, ref int A_2, ref GliderHoldable[] A_3, ref int A_4, ref GliderHoldable A_5, ref bool A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x0003A0BC File Offset: 0x000382BC
		private static void CanTransformMultipleBlocksTypesAlways(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = PhotonNetwork.NetworkingClient.LoadBalancingPeer.QueuedOutgoingCommands > 0;
			A_7 = flag;
			int num = (A_7 ? 1 : 0) * -2 + 37;
			A_0 = num;
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x0003A128 File Offset: 0x00038328
		private static void InProcessHandlerEventHandler(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			A_1 = 0;
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x0003A140 File Offset: 0x00038340
		private static void DebuggerBrowsableStateNotEscaped(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			A_1 = 0;
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x0003A158 File Offset: 0x00038358
		private static void localFinallyIStructuralEquatable(ref int A_0, ref int A_1, ref int A_2, ref GorillaRopeSwing[] A_3, ref int A_4, ref GorillaRopeSwing A_5)
		{
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_3 = array;
			int num = 0;
			A_4 = num;
			A_0 = 101;
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x0003A1A0 File Offset: 0x000383A0
		private static void UnboxStateOrProvince(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<CosmeticsController.CosmeticItem>.Enumerator A_4, ref CosmeticsController.CosmeticItem A_5, ref Action<string> A_6)
		{
			List<CosmeticsController.CosmeticItem>.Enumerator enumerator = CosmeticsController.instance.allCosmetics.GetEnumerator();
			A_4 = enumerator;
			A_0 = 120;
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x0003A1DC File Offset: 0x000383DC
		private static void EnhancedKeyUsageUrl(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005E0 RID: 1504 RVA: 0x0003A1F4 File Offset: 0x000383F4
		private static void HostSecurityManagerNullableComparer(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x0003A20C File Offset: 0x0003840C
		private static void AuthenticodeWindowsRuntimeImportAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_9 = leftGrab;
			int num = ((!A_9) ? 1 : 0) * 8 + 70;
			A_0 = num;
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x0003A270 File Offset: 0x00038470
		private static void DecoderFallbackBufferStructureToPtr(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x0003A288 File Offset: 0x00038488
		public static void GliderSpazoid()
		{
			int num = 79;
			int num2 = 79;
			num2 = 79;
			while (num2 != 0)
			{
				int num3;
				GliderHoldable[] array;
				int num4;
				GliderHoldable gliderHoldable;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,GliderHoldable[]&,System.Int32&,GliderHoldable&,System.Boolean&), ref num, ref num2, ref num3, ref array, ref num4, ref gliderHoldable, ref flag, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 79;
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x0003A2C8 File Offset: 0x000384C8
		private static void IetfLanguageTagReadToEndAsyncd(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<CosmeticsController.CosmeticItem>.Enumerator A_4, ref CosmeticsController.CosmeticItem A_5, ref Action<string> A_6)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x0003A2F0 File Offset: 0x000384F0
		private static void VARFLAGFNONBROWSABLEObjectDisposedException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x0003A308 File Offset: 0x00038508
		private static void getIsContainergetUrl(ref int A_0, ref int A_1, ref int A_2, RPCStuff A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060005E7 RID: 1511 RVA: 0x0003A32C File Offset: 0x0003852C
		private static void AcquireFull(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			RPCStuff.splashtimeout = Time.time;
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 106;
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x0003A37C File Offset: 0x0003857C
		public static void RopeSlow()
		{
			int num = 93;
			int num2 = 93;
			num2 = 93;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 93;
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x0003A3BC File Offset: 0x000385BC
		private static void setPermissionStateLayoutKind(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			RPCStuff.splashtimeout = Time.time;
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_4 = rightGrab;
			int num = ((!A_4) ? 1 : 0) * 1 + 10;
			A_0 = num;
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x0003A42C File Offset: 0x0003862C
		private static void bufferSizeISymbolScope(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			RPCStuff.splashtimeout = Time.time;
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 90;
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x0003A47C File Offset: 0x0003867C
		private static void RedirectedGuidModeKR(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = true;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 33;
			A_0 = num;
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x0003A4D8 File Offset: 0x000386D8
		private static void getResourceManagerControlGetVarDesc(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_5 = leftGrab;
			int num = ((!A_5) ? 1 : 0) * 1 + 22;
			A_0 = num;
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x0003A53C File Offset: 0x0003873C
		private static void DelayPromiseAssemblyIsolationByRoamingUser(ref int A_0, ref int A_1, ref int A_2, ref GorillaRopeSwing[] A_3, ref int A_4, ref GorillaRopeSwing A_5)
		{
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_3 = array;
			int num = 0;
			A_4 = num;
			A_0 = 117;
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x0003A584 File Offset: 0x00038784
		private static void GetFramesChannelDataStore(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = PhotonNetwork.LocalPlayer == null;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 33;
			A_0 = num;
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x0003A5E8 File Offset: 0x000387E8
		private static void GetBooleanOffsetToStringData(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref float A_5, ref float A_6, ref float A_7, ref bool A_8)
		{
			A_1 = 3;
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x0003A600 File Offset: 0x00038800
		private static void ConvertTypeLibToAssemblygetOSDescription(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			A_1 = 0;
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x0003A618 File Offset: 0x00038818
		private static void LargeObjectHeapCompactionModeHasSecurity(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			RPCStuff.splashtimeout = Time.time;
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 57;
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x0003A668 File Offset: 0x00038868
		private static void GetEffectiveDateStringMax(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref float A_5, ref float A_6, ref float A_7, ref bool A_8)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", 0, new object[]
			{
				A_4,
				A_6,
				A_5
			});
			Main.RPCProtection();
			PlayerPrefs.Save();
			A_1 = 3;
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x0003A6F0 File Offset: 0x000388F0
		private static void DynamicBaseLargestWindowWidth(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool inRoom = PhotonNetwork.InRoom;
			A_3 = inRoom;
			int num = ((!A_3) ? 1 : 0) * 9 + 19;
			A_0 = num;
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x0003A750 File Offset: 0x00038950
		public static void RopesUp()
		{
			int num = 42;
			int num2 = 42;
			num2 = 42;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 42;
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x0003A790 File Offset: 0x00038990
		private static void SurrogateSelectorRegisterObject(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_5 = leftGrab;
			int num = ((!A_5) ? 1 : 0) * 1 + 12;
			A_0 = num;
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x0003A7F4 File Offset: 0x000389F4
		private static void RevisionNumberIsUsedUp(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x0003A80C File Offset: 0x00038A0C
		private static void StringBuilderIDeferredDisposable(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			PhotonView photonViewFromVRRig = RigManager.GetPhotonViewFromVRRig(GorillaTagger.Instance.offlineVRRig);
			A_6 = photonViewFromVRRig;
			A_4.rpcErrorMax = int.MaxValue;
			A_4.rpcCallLimit = int.MaxValue;
			A_4.logErrorMax = int.MaxValue;
			PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
			PhotonNetwork.QuickResends = int.MaxValue;
			PhotonNetwork.NetworkingClient.LoadBalancingPeer.DisconnectTimeout = int.MaxValue;
			PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
			PhotonNetwork.OpRemoveCompleteCacheOfPlayer(PhotonNetwork.LocalPlayer.ActorNumber);
			A_0 = 36;
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x0003A8C8 File Offset: 0x00038AC8
		public static void RopesLowGravity()
		{
			int num = 103;
			int num2 = 103;
			num2 = 103;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 103;
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x0003A908 File Offset: 0x00038B08
		public static void SplashHands()
		{
			int num = 6;
			int num2 = 6;
			num2 = 6;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 6;
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x0003A940 File Offset: 0x00038B40
		private static void PropertyBuilderGREGORIANXLITFRENCH(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			GorillaRopeSwing gorillaRopeSwing = A_4[A_5];
			A_6 = gorillaRopeSwing;
			PhotonView photonView = RopeSwingManager.instance.photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = 0;
			object[] array = new object[5];
			array[0] = A_6.ropeId;
			array[1] = 1;
			array[2] = new Vector3(0f, 1E-12f, 1f);
			array[3] = true;
			photonView.RPC(text, rpcTarget, array);
			Main.RPCProtection();
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 107;
			A_0 = num2;
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x0003AA48 File Offset: 0x00038C48
		private static void CModReqdTotalSeconds(ref int A_0, ref int A_1, ref int A_2, ref GorillaRopeSwing[] A_3, ref int A_4, ref GorillaRopeSwing A_5)
		{
			int num = ((A_4 < A_3.Length) ? 1 : 0) * -2 + 118;
			A_0 = num;
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x0003AA84 File Offset: 0x00038C84
		private static void ByteTypeInfoEventAttributes(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_1 = 0;
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x0003AA9C File Offset: 0x00038C9C
		private static void VarArgMethodGetAttributes(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool flag = false;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 9 + 19;
			A_0 = num;
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x0003AAF8 File Offset: 0x00038CF8
		private static void AllInternalsVisiblegetTraceLevel(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_9 = leftGrab;
			int num = ((!A_9) ? 1 : 0) * 8 + 70;
			A_0 = num;
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x0003AB5C File Offset: 0x00038D5C
		private static void CheckDemandsetXmlElementName(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 7;
				int num2 = 7;
				num2 = 7;
				while (num2 != 0)
				{
					int num3;
					bool flag;
					GliderHoldable[] array;
					int num4;
					GliderHoldable gliderHoldable;
					bool flag2;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GliderHoldable[]&,System.Int32&,GliderHoldable&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gliderHoldable, ref flag2, RPCStuff.<>c.IIdentityGetValueNames[num]);
				}
				num2 = 7;
			}, false);
			A_1 = 0;
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x0003ABA4 File Offset: 0x00038DA4
		private static void ObjectStringExecutionContext(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<CosmeticsController.CosmeticItem>.Enumerator A_4, ref CosmeticsController.CosmeticItem A_5, ref Action<string> A_6)
		{
			A_1 = 3;
			A_2 = 125;
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x0003ABC8 File Offset: 0x00038DC8
		private static void IDeferredDisposablesetTypeInfo(ref int A_0, ref int A_1, ref int A_2, ref GorillaRopeSwing[] A_3, ref int A_4, ref GorillaRopeSwing A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x0003ABE0 File Offset: 0x00038DE0
		private static void getKeysOrderedInEachPartitionConvertToUtf(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			int num = ((A_12 < A_11.Length) ? 1 : 0) * -4 + 76;
			A_0 = num;
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x0003AC1C File Offset: 0x00038E1C
		private static void ObjectAceTypeCustomAttributeEncoding(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			bool leftControllerSecondaryButton = ControllerInputPoller.instance.leftControllerSecondaryButton;
			A_7 = leftControllerSecondaryButton;
			int num = ((!A_7) ? 1 : 0) * 1 + 26;
			A_0 = num;
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x0003AC80 File Offset: 0x00038E80
		public static void GliderGrab()
		{
			int num = 60;
			int num2 = 60;
			num2 = 60;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				GliderHoldable[] array;
				int num4;
				GliderHoldable gliderHoldable;
				bool flag3;
				bool flag4;
				bool flag5;
				GliderHoldable[] array2;
				int num5;
				GliderHoldable gliderHoldable2;
				bool flag6;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,GliderHoldable[]&,System.Int32&,GliderHoldable&,System.Boolean&,System.Boolean&,System.Boolean&,GliderHoldable[]&,System.Int32&,GliderHoldable&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref array, ref num4, ref gliderHoldable, ref flag3, ref flag4, ref flag5, ref array2, ref num5, ref gliderHoldable2, ref flag6, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 60;
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x0003ACD0 File Offset: 0x00038ED0
		private static void TypeFilterConsistencyGuarantee(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool inRoom = PhotonNetwork.InRoom;
			A_3 = inRoom;
			int num = ((!A_3) ? 1 : 0) * 5 + 9;
			A_0 = num;
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x0003AD30 File Offset: 0x00038F30
		private static void matchMuiResourceTypeIdIntEntryFieldId(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			GorillaRopeSwing gorillaRopeSwing = A_4[A_5];
			A_6 = gorillaRopeSwing;
			PhotonView photonView = RopeSwingManager.instance.photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = 0;
			object[] array = new object[5];
			array[0] = A_6.ropeId;
			array[1] = 1;
			array[2] = new Vector3(1E-12f, 1E-12f, 1E-12f);
			array[3] = true;
			photonView.RPC(text, rpcTarget, array);
			Main.RPCProtection();
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 97;
			A_0 = num2;
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x0003AE38 File Offset: 0x00039038
		private static void EventMetadataStaticIndexRangePartitionForArray(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			int num = (((Time.time > RPCStuff.splashtimeout + 0.1f) ? 1 : 0) + -1) * -1 * 1 + 7;
			A_0 = num;
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x0003AE80 File Offset: 0x00039080
		private static void addCancelKeyPressIsTypeDef(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			PhotonNetwork.SendAllOutgoingCommands();
			bool flag = PhotonNetwork.NetworkingClient.LoadBalancingPeer.QueuedOutgoingCommands > 0;
			A_7 = flag;
			int num = (A_7 ? 1 : 0) * -2 + 37;
			A_0 = num;
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x0003AEF4 File Offset: 0x000390F4
		private static void PureAttributeAssemblyBuilder(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x0003AF0C File Offset: 0x0003910C
		private static void SendToSecureStringToCoTaskMemAnsi(ref int A_0, ref int A_1, ref int A_2, ref GliderHoldable[] A_3, ref int A_4, ref GliderHoldable A_5, ref bool A_6)
		{
			int num = ((A_4 < A_3.Length) ? 1 : 0) * -4 + 84;
			A_0 = num;
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x0003AF48 File Offset: 0x00039148
		private static void GetAssemblyNameToXmlString(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 113;
			A_0 = num;
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x0003AF84 File Offset: 0x00039184
		public static void GoonSplashes()
		{
			int num = 16;
			int num2 = 16;
			num2 = 16;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				bool flag5;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, ref flag4, ref flag5, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 16;
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x0003AFC4 File Offset: 0x000391C4
		private static void PermissionTypegetAssemblyRequestSection(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x0003AFDC File Offset: 0x000391DC
		private static void SafeArraySubTypeautoFlush(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			PhotonNetwork.OpCleanRpcBuffer(A_6);
			PhotonNetwork.OpRemoveCompleteCache();
			PhotonNetwork.NetworkingClient.LoadBalancingPeer.TransportProtocol = 0;
			PhotonNetwork.NetworkingClient.LoadBalancingPeer.LimitOfUnreliableCommands = int.MaxValue;
			A_4.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
			PhotonNetwork.NetworkingClient.LoadBalancingPeer.DisconnectTimeout = int.MaxValue;
			PhotonNetwork.NetworkingClient.LoadBalancingPeer.WarningSize = int.MaxValue;
			PhotonNetwork.NetworkingClient.LoadBalancingPeer.TimePingInterval = 1;
			CustomSerializer.ByteSerialize(PhotonNetwork.NetworkingClient.LoadBalancingPeer.ByteArraySlicePool);
			PhotonNetwork.NetworkingClient.LoadBalancingPeer.TrafficStatsEnabled = false;
			A_0 = 41;
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x0003B0B4 File Offset: 0x000392B4
		private static void getPermitOnlySetInstanceCreateFlags(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<CosmeticsController.CosmeticItem>.Enumerator A_4, ref CosmeticsController.CosmeticItem A_5, ref Action<string> A_6)
		{
			CosmeticsController.CosmeticItem cosmeticItem = A_4.Current;
			A_5 = cosmeticItem;
			Action<string> action = delegate(string itemId)
			{
				int num2 = 23;
				int num3 = 23;
				num3 = 23;
				while (num3 != 0)
				{
					int num4;
					bool flag;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.String), ref num2, ref num3, ref num4, ref flag, itemId, RPCStuff.<>c.IIdentityGetValueNames[num2]);
				}
				num3 = 23;
			};
			A_6 = action;
			A_6.Invoke(A_5.itemName);
			int num = (A_4.MoveNext() ? 1 : 0) * -2 + 123;
			A_0 = num;
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x0003B168 File Offset: 0x00039368
		private static void GetAmbiguousTimeOffsetsIsSystemMoniker(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 3f;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 39;
			A_0 = num;
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x0003B1D4 File Offset: 0x000393D4
		private static void collectionSignal(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			GorillaRopeSwing gorillaRopeSwing = A_4[A_5];
			A_6 = gorillaRopeSwing;
			PhotonView photonView = RopeSwingManager.instance.photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = 0;
			object[] array = new object[5];
			array[0] = A_6.ropeId;
			array[1] = 1;
			array[2] = new Vector3(0f, -100f, 1f);
			array[3] = true;
			photonView.RPC(text, rpcTarget, array);
			Main.RPCProtection();
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 58;
			A_0 = num2;
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x0003B2DC File Offset: 0x000394DC
		private static void IClientChannelSinkStackgetHashSize(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x0003B2F4 File Offset: 0x000394F4
		private static void BinaryCrossAppDomainStringgetSupportUrl(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.1f;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 6 + 62;
			A_0 = num;
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x0003B360 File Offset: 0x00039560
		public RPCStuff()
		{
			int num = 127;
			int num2 = 127;
			num2 = 127;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.RPCStuff), ref num, ref num2, ref num3, this, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 127;
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x0003B398 File Offset: 0x00039598
		private static void ModesetFilterLevel(ref int A_0, ref int A_1, ref int A_2, ref GliderHoldable[] A_3, ref int A_4, ref GliderHoldable A_5, ref bool A_6)
		{
			GliderHoldable[] array = Object.FindObjectsOfType<GliderHoldable>();
			A_3 = array;
			int num = 0;
			A_4 = num;
			A_0 = 83;
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x0003B3E0 File Offset: 0x000395E0
		public static void RopeFreeze()
		{
			int num = 99;
			int num2 = 99;
			num2 = 99;
			while (num2 != 0)
			{
				int num3;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 99;
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x0003B41C File Offset: 0x0003961C
		private static void CaptureOffsetTrustedCredentialManagerAccess(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x0003B434 File Offset: 0x00039634
		private static void TokenGroupsSiteServerAuthority(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", 0, new object[]
			{
				Random.value,
				Random.value,
				Random.value
			});
			Main.RPCProtection();
			PlayerPrefs.Save();
			A_1 = 0;
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x0003B4B0 File Offset: 0x000396B0
		private static void AddSurrogateSerializedStreamHeaderEnd(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			RPCStuff.splashtimeout = Time.time;
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 96;
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x0003B500 File Offset: 0x00039700
		public static void RopesDown()
		{
			int num = 48;
			int num2 = 48;
			num2 = 48;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 48;
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x0003B540 File Offset: 0x00039740
		public static void SetMas()
		{
			int num = 115;
			int num2 = 115;
			num2 = 115;
			while (num2 != 0)
			{
				int num3;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 115;
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x0003B57C File Offset: 0x0003977C
		private static void EndChildrenCallbackRequiredContract(ref int A_0, ref int A_1, ref int A_2, ref GorillaRopeSwing[] A_3, ref int A_4, ref GorillaRopeSwing A_5)
		{
			int num = ((A_4 < A_3.Length) ? 1 : 0) * -2 + 102;
			A_0 = num;
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x0003B5B8 File Offset: 0x000397B8
		private static void MakeStringActivityInfo(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", 0, new object[]
			{
				GorillaTagger.Instance.offlineVRRig.leftHandTransform.position,
				GorillaTagger.Instance.offlineVRRig.leftHandTransform.rotation,
				400f,
				100f,
				true,
				true
			});
			Main.RPCProtection();
			A_1 = 0;
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x0003B680 File Offset: 0x00039880
		private static void TraceOperationEndLatinEncoding(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			bool inRoom = PhotonNetwork.InRoom;
			A_3 = inRoom;
			int num = ((!A_3) ? 1 : 0) * 8 + 30;
			A_0 = num;
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x0003B6DC File Offset: 0x000398DC
		private static void CustomErrorsModeSecurityContext(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.1f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 104;
			A_0 = num;
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x0003B748 File Offset: 0x00039948
		private static void ISTOREENUMFILESFLAGINCLUDEMISSINGFILESSetPrincipalPolicy(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.1f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 94;
			A_0 = num;
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x0003B7B4 File Offset: 0x000399B4
		private static void PermitOnlyGetRawCertData(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			RPCStuff.splashtimeout = Time.time;
			GliderHoldable[] array = Object.FindObjectsOfType<GliderHoldable>();
			A_11 = array;
			int num = 0;
			A_12 = num;
			A_0 = 75;
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x0003B804 File Offset: 0x00039A04
		private static void BakeIsSecurityCritical(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x0003B81C File Offset: 0x00039A1C
		private static void CMSASSEMBLYREFERENCEFLAGCULTUREWILDCARDEDgetTransform(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 2;
				int num2 = 2;
				num2 = 2;
				while (num2 != 0)
				{
					int num3;
					bool flag;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, RPCStuff.<>c.IIdentityGetValueNames[num]);
				}
				num2 = 2;
			}, false);
			A_1 = 0;
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x0003B864 File Offset: 0x00039A64
		public static void RGBMonkey()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 3)
			{
				int num3;
				float num4;
				float num5;
				float num6;
				float num7;
				float num8;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Single&,System.Single&,System.Single&,System.Single&,System.Single&,System.Boolean&), ref num, ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref flag, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x0003B8A4 File Offset: 0x00039AA4
		private static void SortDynamicAssemblyFlags(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			A_1 = 0;
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x0003B8C0 File Offset: 0x00039AC0
		private static void UsersStackCrawlMarkHandle(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", 0, new object[]
			{
				GorillaTagger.Instance.offlineVRRig.rightHandTransform.position,
				GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation,
				4f,
				100f,
				true,
				true
			});
			Main.RPCProtection();
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_5 = leftGrab;
			int num = ((!A_5) ? 1 : 0) * 1 + 22;
			A_0 = num;
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x0003B9D4 File Offset: 0x00039BD4
		private static void ProfileSingleProcesscharPos(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", 0, new object[]
			{
				GorillaTagger.Instance.offlineVRRig.leftHandTransform.position,
				GorillaTagger.Instance.offlineVRRig.leftHandTransform.rotation,
				400f,
				100f,
				false,
				false
			});
			Main.RPCProtection();
			A_1 = 0;
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x0003BA9C File Offset: 0x00039C9C
		private static void getOptionalPermissionsgetSupportsDynamicPartitions(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.1f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 49;
			A_0 = num;
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x0003BB08 File Offset: 0x00039D08
		private static void ActivityOptionsEnumFields(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x0003BB20 File Offset: 0x00039D20
		private static void setUINativeOffset(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_1 = 0;
		}

		// Token: 0x0600062B RID: 1579 RVA: 0x0003BB38 File Offset: 0x00039D38
		private static void CMSSECTIONENTRYIDMETADATAImporterEventKind(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x0003BB50 File Offset: 0x00039D50
		private static void TokenGroupsRemotingFieldCachedData(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			GorillaNot instance = GorillaNot.instance;
			A_4 = instance;
			int num = ((A_4 == null) ? 1 : 0) * 1 + 31;
			A_0 = num;
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x0003BBB4 File Offset: 0x00039DB4
		private static void AddWeeksSymDocumentType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			int num = A_12 + 1;
			A_12 = num;
			int num2 = ((A_12 < A_11.Length) ? 1 : 0) * -4 + 76;
			A_0 = num2;
		}

		// Token: 0x0600062E RID: 1582 RVA: 0x0003BC14 File Offset: 0x00039E14
		private static void SpinUntilExtensibleClassFactory(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.1f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 110;
			A_0 = num;
		}

		// Token: 0x0600062F RID: 1583 RVA: 0x0003BC80 File Offset: 0x00039E80
		private static void IChannelPROCESSORIDARRAY(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool flag = false;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 5 + 9;
			A_0 = num;
		}

		// Token: 0x06000630 RID: 1584 RVA: 0x0003BCDC File Offset: 0x00039EDC
		private static void ClaimsGetBaseException(ref int A_0, ref int A_1, ref int A_2, ref GliderHoldable[] A_3, ref int A_4, ref GliderHoldable A_5, ref bool A_6)
		{
			int num = A_4 + 1;
			A_4 = num;
			int num2 = ((A_4 < A_3.Length) ? 1 : 0) * -4 + 84;
			A_0 = num2;
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x0003BD3C File Offset: 0x00039F3C
		private static void DuplicateIdentityOptionAboveNormal(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			RPCStuff.splashtimeout = Time.time;
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_4 = rightGrab;
			int num = ((!A_4) ? 1 : 0) * 1 + 20;
			A_0 = num;
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x0003BDAC File Offset: 0x00039FAC
		private static void FlushAsyncInternaldDisposition(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_9 = leftGrab;
			int num = ((!A_9) ? 1 : 0) * 8 + 70;
			A_0 = num;
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x0003BE10 File Offset: 0x0003A010
		private static void ThreadStartExceptionStreamWriterBufferedDataLost(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaNot A_4, ref bool A_5, ref PhotonView A_6, ref bool A_7, ref bool A_8)
		{
			A_0 = 41;
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x0003BE28 File Offset: 0x0003A028
		public unsafe static void UnlockAllCosmetics()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 119;
			int num4 = 119;
			num4 = 119;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 119;
						if ((int)array[2] != 0)
						{
							num5 = (int)array[0];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num5 + 24 + num2);
								num7 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + (int)array[4] + 24 + num2) + 16 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num7 + 8 + num2);
								if (num8 != -1)
								{
									num9 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num8 + 64 + num2);
									array[4] = num8;
									array[7] = 0;
									num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num8 + 64 + num2);
									goto IL_1A;
								}
								num7 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num7 + 16 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[6];
							num9 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num5 + 64 + num2);
							ex3 = ex2;
							array = (object[])array[3];
							array2 = new object[8];
							array2[2] = 1;
							array2[3] = array;
							array2[6] = ex2;
							array2[4] = num5;
							array2[7] = 2;
							array = array2;
							num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num5 + 64 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[1];
							array = (object[])array[3];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							List<CosmeticsController.CosmeticItem>.Enumerator enumerator;
							CosmeticsController.CosmeticItem cosmeticItem;
							Action<string> action;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<GorillaNetworking.CosmeticsController/CosmeticItem>&,GorillaNetworking.CosmeticsController/CosmeticItem&,System.Action`1<System.String>&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref cosmeticItem, ref action, RPCStuff.NoCustomMarshalSkip[num3]);
							continue;
						}
						num4 = 119;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num16 * 56 + 16 + num2);
						num18 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num16 * 56 + 24 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num7 * 56 + 8 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num15 * 56 + 16 + num2);
						num6 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num15 * 56 + 24 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num7 * 56 + 8 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num16 * 72 + 16 + num2);
						num18 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num16 * 72 + 24 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num7 * 72 + 32 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A79:
						if (array == null || (int)array[2] == 0)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num6 + 16 + num2);
								}
								else
								{
									num11 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 8 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 16 + num2);
									goto IL_A79;
								}
							}
							goto IL_C16;
						}
						int num20 = (int)array[4];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 48 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num16 * 72 + 16 + num2);
								num11 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num16 * 72 + 24 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num5 * 72 + 32 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num7 + 16 + num2);
								}
								else
								{
									num5 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 8 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 16 + num2);
									goto IL_A79;
								}
							}
							break;
						}
						if ((int)array[4] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[3];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num5 + 64 + num2);
					array2 = new object[8];
					array2[2] = 0;
					array2[3] = array;
					array2[1] = num12;
					array2[4] = num5;
					array2[7] = 0;
					array = array2;
					num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num5 + 64 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C16:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num11 + 64 + num2);
					array2 = new object[8];
					array2[2] = 0;
					array2[3] = array;
					array2[1] = num12;
					array2[4] = num11;
					array2[7] = 0;
					array = array2;
					num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num11 + 64 + num2);
				}
				num4 = 119;
				return;
				IL_1CD:
				if (num15 != -1)
				{
					goto IL_1D8;
				}
				goto IL_401;
				IL_1D8:
				num6 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num15 + 32 + num2);
				if (1 == num6)
				{
					goto IL_1F7;
				}
				if (2 == num6)
				{
					goto IL_388;
				}
				goto IL_401;
				IL_1F7:
				num11 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num15 + 16 + num2);
				if (num11 == -1)
				{
					goto IL_245;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_22B;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_22B:
				if (type.IsInstanceOfType(array2[6]))
				{
					goto IL_245;
				}
				num15 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num15 + 48 + num2);
				goto IL_1CD;
				IL_245:
				num19 = num15;
				num14 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 24 + num2) + 16 + num2);
				num7 = (int)array2[5];
				IL_269:
				if (num7 != num14)
				{
					goto IL_2E8;
				}
				num16 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 64 + num2);
				ex3 = array2[6];
				array = (object[])array[3];
				object[] array5 = new object[8];
				array5[2] = 1;
				array5[3] = array;
				array5[6] = array2[6];
				array5[5] = (int)array2[5];
				array5[4] = num19;
				array5[7] = 2;
				array = array5;
				num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 64 + num2);
				goto IL_1A;
				IL_2E8:
				num9 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num7 + 8 + num2);
				if (num9 == -1)
				{
					goto IL_376;
				}
				num16 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num9 + 64 + num2);
				array = (object[])array[3];
				array5 = new object[8];
				array5[2] = 1;
				array5[3] = array;
				array5[6] = array2[6];
				array5[5] = (int)array2[5];
				array5[4] = num9;
				array5[0] = num19;
				array5[7] = 0;
				array = array5;
				num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num9 + 64 + num2);
				goto IL_1A;
				IL_376:
				num7 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num7 + 16 + num2);
				goto IL_269;
				IL_388:
				num16 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num15 + 72 + num2);
				ex3 = array2[6];
				array = (object[])array[3];
				array5 = new object[8];
				array5[2] = 1;
				array5[3] = array;
				array5[6] = array2[6];
				array5[5] = (int)array2[5];
				array5[4] = num15;
				array5[7] = 1;
				array = array5;
				num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num15 + 72 + num2);
				goto IL_1A;
				IL_401:
				array = (object[])array[3];
				ex = array2[6];
				int num23 = (int)array2[5];
				IL_420:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_42E:
				num8 = (num17 + num18) / 2;
				num5 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num8 * 56 + 16 + num2);
				num22 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num8 * 56 + 24 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_474;
				}
				if (num5 > num16)
				{
					goto IL_47C;
				}
				num14 = num8;
				num19 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 136 + num14 * 56 + 8 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4A3;
				IL_474:
				num17 = num8 + 1;
				goto IL_42E;
				IL_47C:
				num18 = num8 - 1;
				goto IL_42E;
				IL_4A3:
				if (array != null)
				{
					goto IL_4AE;
				}
				goto IL_63D;
				IL_4AE:
				if ((int)array[2] != 0)
				{
					goto IL_56E;
				}
				int num24 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_4D2;
				}
				int num25 = -1;
				goto IL_555;
				IL_4D2:
				int num26 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num11 + 48 + num2);
				num22 = 0;
				num5 = 2;
				IL_4E5:
				num8 = (num22 + num5) / 2;
				num18 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num8 * 72 + 16 + num2);
				num17 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num8 * 72 + 24 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_52B;
				}
				if (num18 > num26)
				{
					goto IL_533;
				}
				num19 = num8;
				num14 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num19 * 72 + 32 + num2);
				num25 = num14;
				goto IL_555;
				IL_52B:
				num22 = num8 + 1;
				goto IL_4E5;
				IL_533:
				num5 = num8 - 1;
				goto IL_4E5;
				IL_555:
				if (num24 != num25)
				{
					goto IL_55D;
				}
				goto IL_63D;
				IL_55D:
				array = (object[])array[3];
				goto IL_4A3;
				IL_56E:
				num9 = (int)array[7];
				if (num9 == 2 || num9 == 0)
				{
					goto IL_58F;
				}
				if (num9 != 1)
				{
					goto IL_58E;
				}
				array2 = array;
				num15 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + (int)array2[4] + 48 + num2);
				goto IL_1CD;
				IL_58E:
				IL_58F:
				int num27 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_5A4;
				}
				int num28 = -1;
				goto IL_627;
				IL_5A4:
				num16 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num11 + 48 + num2);
				num17 = 0;
				num18 = 2;
				IL_5B7:
				num8 = (num17 + num18) / 2;
				num5 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num8 * 72 + 16 + num2);
				num22 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num8 * 72 + 24 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5FD;
				}
				if (num5 > num16)
				{
					goto IL_605;
				}
				num14 = num8;
				num19 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + 304 + num14 * 72 + 32 + num2);
				num28 = num19;
				goto IL_627;
				IL_5FD:
				num17 = num8 + 1;
				goto IL_5B7;
				IL_605:
				num18 = num8 - 1;
				goto IL_5B7;
				IL_627:
				if (num27 != num28)
				{
					goto IL_62C;
				}
				goto IL_63D;
				IL_62C:
				array = (object[])array[3];
				goto IL_4A3;
				IL_63D:
				if (-1 != num11)
				{
					goto IL_6E0;
				}
				num19 = num7;
				IL_64A:
				if (num19 != -1)
				{
					goto IL_656;
				}
				num10 = 1;
				throw ex;
				IL_656:
				num14 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 8 + num2);
				if (num14 == -1)
				{
					goto IL_6CE;
				}
				num26 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num14 + 64 + num2);
				array2 = new object[8];
				array2[2] = 1;
				array2[3] = array;
				array2[6] = ex;
				array2[5] = num7;
				array2[4] = -1;
				array2[0] = -1;
				array2[7] = 2;
				array = array2;
				num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num14 + 64 + num2);
				goto IL_1A;
				IL_6CE:
				num19 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num19 + 16 + num2);
				goto IL_64A;
				IL_6E0:
				num6 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num11 + 24 + num2);
				num16 = num6;
				IL_6F1:
				if (num16 != -1)
				{
					goto IL_708;
				}
				num11 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num11 + 16 + num2);
				goto IL_4A3;
				IL_708:
				num18 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num16 + 32 + num2);
				if (1 == num18)
				{
					goto IL_733;
				}
				if (2 == num18)
				{
					goto IL_8A0;
				}
				num11 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num11 + 16 + num2);
				goto IL_4A3;
				IL_733:
				num17 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num16 + 16 + num2);
				if (num17 == -1)
				{
					goto IL_782;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_767;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_767:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_782;
				}
				num16 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num16 + 48 + num2);
				goto IL_6F1;
				IL_782:
				num26 = num16;
				num22 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num26 + 24 + num2) + 16 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7AB:
				if (num5 != num22)
				{
					goto IL_814;
				}
				int num29 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num26 + 64 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[2] = 1;
				array2[3] = array;
				array2[6] = ex;
				array2[5] = num7;
				array2[4] = num26;
				array2[7] = 2;
				array = array2;
				num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num26 + 64 + num2);
				goto IL_1A;
				IL_814:
				num8 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num5 + 8 + num2);
				if (num8 == -1)
				{
					goto IL_88E;
				}
				num29 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num8 + 64 + num2);
				array2 = new object[8];
				array2[2] = 1;
				array2[3] = array;
				array2[6] = ex;
				array2[5] = num7;
				array2[4] = num8;
				array2[0] = num26;
				array2[7] = 0;
				array = array2;
				num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num8 + 64 + num2);
				goto IL_1A;
				IL_88E:
				num5 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num5 + 16 + num2);
				goto IL_7AB;
				IL_8A0:
				num29 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num16 + 72 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[2] = 1;
				array2[3] = array;
				array2[6] = ex;
				array2[5] = num7;
				array2[4] = num16;
				array2[7] = 1;
				array = array2;
				num3 = *(ref OemPlussetCreate.SetGenericParameterAttributessetCurrencyPositivePattern + num16 + 72 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_420;
				}
				throw ex4;
			}
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0003CB04 File Offset: 0x0003AD04
		private static void MagicNumberINVOKEFUNC(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			RPCStuff.splashtimeout = Time.time;
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 112;
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x0003CB54 File Offset: 0x0003AD54
		private static void IPersistFileStreamWriter(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 97;
			A_0 = num;
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x0003CB90 File Offset: 0x0003AD90
		private static void MinorVersionsetHex(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", 0, new object[]
			{
				GorillaTagger.Instance.offlineVRRig.rightHandTransform.position,
				GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation,
				4f,
				100f,
				false,
				false
			});
			Main.RPCProtection();
			bool leftControllerSecondaryButton = ControllerInputPoller.instance.leftControllerSecondaryButton;
			A_7 = leftControllerSecondaryButton;
			int num = ((!A_7) ? 1 : 0) * 1 + 26;
			A_0 = num;
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x0003CCA4 File Offset: 0x0003AEA4
		private static void ByteTokenEncodingUseLeapYearMonth(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 107;
			A_0 = num;
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x0003CCE0 File Offset: 0x0003AEE0
		private static void IDispatchConstantAttributeDefineLiteral(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x0003CCF8 File Offset: 0x0003AEF8
		private static void XmlNsForClrTypeWithAssemblysetDigitSubstitution(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<CosmeticsController.CosmeticItem>.Enumerator A_4, ref CosmeticsController.CosmeticItem A_5, ref Action<string> A_6)
		{
			A_0 = 122;
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x0003CD10 File Offset: 0x0003AF10
		private static void MemberEndsetHostCanGenerate(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			RPCStuff.splashtimeout = Time.time;
			GorillaRopeSwing[] array = Object.FindObjectsOfType<GorillaRopeSwing>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 45;
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x0003CD60 File Offset: 0x0003AF60
		private static void FieldDefgetCategoryMembershipData(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			int num = A_6 + 1;
			A_6 = num;
			int num2 = ((A_6 < A_5.Length) ? 1 : 0) * -4 + 67;
			A_0 = num2;
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x0003CDC0 File Offset: 0x0003AFC0
		private static void OutputBlockSizeDeclaredNestedTypes(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 8 + 61;
			A_0 = num;
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0003CE24 File Offset: 0x0003B024
		private static void CORESERVERDebuggerDisplayAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", 0, new object[]
			{
				GorillaTagger.Instance.offlineVRRig.rightHandTransform.position,
				GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation,
				400f,
				100f,
				false,
				false
			});
			Main.RPCProtection();
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_5 = leftGrab;
			int num = ((!A_5) ? 1 : 0) * 1 + 12;
			A_0 = num;
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x0003CF38 File Offset: 0x0003B138
		private static void SetServerIdentityVARFLAGFDEFAULTBIND(ref int A_0, ref int A_1, ref int A_2, ref GliderHoldable[] A_3, ref int A_4, ref GliderHoldable A_5, ref bool A_6)
		{
			GliderHoldable gliderHoldable = A_3[A_4];
			A_5 = gliderHoldable;
			bool flag = A_5.GetView.Owner == PhotonNetwork.LocalPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 81;
			A_0 = num;
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x0003CFD0 File Offset: 0x0003B1D0
		private static void EqualityComparerGetRuntimeEvent(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GliderHoldable[] A_5, ref int A_6, ref GliderHoldable A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref GliderHoldable[] A_11, ref int A_12, ref GliderHoldable A_13, ref bool A_14)
		{
			A_1 = 0;
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x0003CFE8 File Offset: 0x0003B1E8
		private static void NumberTokenComRedirectionProxy(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			GorillaRopeSwing gorillaRopeSwing = A_4[A_5];
			A_6 = gorillaRopeSwing;
			PhotonView photonView = RopeSwingManager.instance.photonView;
			string text = "SetVelocity";
			RpcTarget rpcTarget = 0;
			object[] array = new object[5];
			array[0] = A_6.ropeId;
			array[1] = 1;
			array[2] = new Vector3(Random.Range(-360f, 360f), Random.Range(-360f, 360f), Random.Range(-360f, 360f));
			array[3] = true;
			photonView.RPC(text, rpcTarget, array);
			Main.RPCProtection();
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 91;
			A_0 = num2;
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x0003D110 File Offset: 0x0003B310
		private static void BackgroundRedMakeString(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x0003D128 File Offset: 0x0003B328
		public static void RopeFling()
		{
			int num = 109;
			int num2 = 109;
			num2 = 109;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaRopeSwing[] array;
				int num4;
				GorillaRopeSwing gorillaRopeSwing;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaLocomotion.Gameplay.GorillaRopeSwing[]&,System.Int32&,GorillaLocomotion.Gameplay.GorillaRopeSwing&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaRopeSwing, RPCStuff.NoCustomMarshalSkip[num]);
			}
			num2 = 109;
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x0003D168 File Offset: 0x0003B368
		private static void setEventChannelTypegetArgs(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 58;
			A_0 = num;
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x0003D1A4 File Offset: 0x0003B3A4
		private static void HashElementTransformMethodBuilderInstantiation(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 46;
			A_0 = num;
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x0003D1E0 File Offset: 0x0003B3E0
		private static void setXmlNamespaceAccessDeniedCallbackObject(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", 0, new object[]
			{
				GorillaTagger.Instance.offlineVRRig.leftHandTransform.position,
				GorillaTagger.Instance.offlineVRRig.leftHandTransform.rotation,
				400f,
				100f,
				false,
				false
			});
			Main.RPCProtection();
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			A_6 = rightControllerPrimaryButton;
			int num = ((!A_6) ? 1 : 0) * 1 + 24;
			A_0 = num;
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x0003D2F4 File Offset: 0x0003B4F4
		private static void StrongNamePublicKeyBlobCapsLock(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaRopeSwing[] A_4, ref int A_5, ref GorillaRopeSwing A_6)
		{
			bool flag = Time.time > RPCStuff.splashtimeout + 0.1f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 43;
			A_0 = num;
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x0003D360 File Offset: 0x0003B560
		// Note: this type is marked as 'beforefieldinit'.
		static RPCStuff()
		{
			RPCStuff.InfiniteTimeSpanInfrastructure();
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x0003D374 File Offset: 0x0003B574
		private static void InfiniteTimeSpanInfrastructure()
		{
			RPCStuff.NoCustomMarshalSkip = new IntPtr[128];
			RPCStuff.NoCustomMarshalSkip[0] = ldftn(IChannelDataStoreSupportsLastError);
			RPCStuff.NoCustomMarshalSkip[1] = ldftn(GetEffectiveDateStringMax);
			RPCStuff.NoCustomMarshalSkip[2] = ldftn(GetBooleanOffsetToStringData);
			RPCStuff.NoCustomMarshalSkip[3] = ldftn(setLastWriteTimeSECURITYLOGONSESSIONDATA);
			RPCStuff.NoCustomMarshalSkip[4] = ldftn(TokenGroupsSiteServerAuthority);
			RPCStuff.NoCustomMarshalSkip[5] = ldftn(getRegistryKeySectionCreateWrapperOfType);
			RPCStuff.NoCustomMarshalSkip[6] = ldftn(EventMetadataStaticIndexRangePartitionForArray);
			RPCStuff.NoCustomMarshalSkip[7] = ldftn(TypeFilterConsistencyGuarantee);
			RPCStuff.NoCustomMarshalSkip[8] = ldftn(IChannelPROCESSORIDARRAY);
			RPCStuff.NoCustomMarshalSkip[9] = ldftn(setPermissionStateLayoutKind);
			RPCStuff.NoCustomMarshalSkip[10] = ldftn(CORESERVERDebuggerDisplayAttribute);
			RPCStuff.NoCustomMarshalSkip[11] = ldftn(SurrogateSelectorRegisterObject);
			RPCStuff.NoCustomMarshalSkip[12] = ldftn(ProfileSingleProcesscharPos);
			RPCStuff.NoCustomMarshalSkip[13] = ldftn(setUINativeOffset);
			RPCStuff.NoCustomMarshalSkip[14] = ldftn(ByteTypeInfoEventAttributes);
			RPCStuff.NoCustomMarshalSkip[15] = ldftn(CMSASSEMBLYREFERENCEFLAGCULTUREWILDCARDEDgetTransform);
			RPCStuff.NoCustomMarshalSkip[16] = ldftn(setControlAppDomainFind);
			RPCStuff.NoCustomMarshalSkip[17] = ldftn(DynamicBaseLargestWindowWidth);
			RPCStuff.NoCustomMarshalSkip[18] = ldftn(VarArgMethodGetAttributes);
			RPCStuff.NoCustomMarshalSkip[19] = ldftn(DuplicateIdentityOptionAboveNormal);
			RPCStuff.NoCustomMarshalSkip[20] = ldftn(UsersStackCrawlMarkHandle);
			RPCStuff.NoCustomMarshalSkip[21] = ldftn(getResourceManagerControlGetVarDesc);
			RPCStuff.NoCustomMarshalSkip[22] = ldftn(setXmlNamespaceAccessDeniedCallbackObject);
			RPCStuff.NoCustomMarshalSkip[23] = ldftn(CompressedStackMemoryFailPoint);
			RPCStuff.NoCustomMarshalSkip[24] = ldftn(MinorVersionsetHex);
			RPCStuff.NoCustomMarshalSkip[25] = ldftn(ObjectAceTypeCustomAttributeEncoding);
			RPCStuff.NoCustomMarshalSkip[26] = ldftn(MakeStringActivityInfo);
			RPCStuff.NoCustomMarshalSkip[27] = ldftn(ConvertTypeLibToAssemblygetOSDescription);
			RPCStuff.NoCustomMarshalSkip[28] = ldftn(DebuggerBrowsableStateNotEscaped);
			RPCStuff.NoCustomMarshalSkip[29] = ldftn(TraceOperationEndLatinEncoding);
			RPCStuff.NoCustomMarshalSkip[30] = ldftn(TokenGroupsRemotingFieldCachedData);
			RPCStuff.NoCustomMarshalSkip[31] = ldftn(GetFramesChannelDataStore);
			RPCStuff.NoCustomMarshalSkip[32] = ldftn(RedirectedGuidModeKR);
			RPCStuff.NoCustomMarshalSkip[33] = ldftn(ThreadStartExceptionStreamWriterBufferedDataLost);
			RPCStuff.NoCustomMarshalSkip[34] = ldftn(StringBuilderIDeferredDisposable);
			RPCStuff.NoCustomMarshalSkip[35] = ldftn(addCancelKeyPressIsTypeDef);
			RPCStuff.NoCustomMarshalSkip[36] = ldftn(CanTransformMultipleBlocksTypesAlways);
			RPCStuff.NoCustomMarshalSkip[37] = ldftn(SafeArraySubTypeautoFlush);
			RPCStuff.NoCustomMarshalSkip[38] = ldftn(GetAmbiguousTimeOffsetsIsSystemMoniker);
			RPCStuff.NoCustomMarshalSkip[39] = ldftn(DynamicPartitionerForArrayIsEnum);
			RPCStuff.NoCustomMarshalSkip[40] = ldftn(PureAttributeAssemblyBuilder);
			RPCStuff.NoCustomMarshalSkip[41] = ldftn(BakeIsSecurityCritical);
			RPCStuff.NoCustomMarshalSkip[42] = ldftn(StrongNamePublicKeyBlobCapsLock);
			RPCStuff.NoCustomMarshalSkip[43] = ldftn(MemberEndsetHostCanGenerate);
			RPCStuff.NoCustomMarshalSkip[44] = ldftn(setVolumeLabelLongPathFile);
			RPCStuff.NoCustomMarshalSkip[45] = ldftn(HashElementTransformMethodBuilderInstantiation);
			RPCStuff.NoCustomMarshalSkip[46] = ldftn(CMSSECTIONENTRYIDMETADATAImporterEventKind);
			RPCStuff.NoCustomMarshalSkip[47] = ldftn(CaptureOffsetTrustedCredentialManagerAccess);
			RPCStuff.NoCustomMarshalSkip[48] = ldftn(getOptionalPermissionsgetSupportsDynamicPartitions);
			RPCStuff.NoCustomMarshalSkip[49] = ldftn(getCanWriteRemotingProxy);
			RPCStuff.NoCustomMarshalSkip[50] = ldftn(JaggedCorElementType);
			RPCStuff.NoCustomMarshalSkip[51] = ldftn(TypeLibFuncAttributeNodeEnumerator);
			RPCStuff.NoCustomMarshalSkip[52] = ldftn(PermissionTypegetAssemblyRequestSection);
			RPCStuff.NoCustomMarshalSkip[53] = ldftn(EnhancedKeyUsageUrl);
			RPCStuff.NoCustomMarshalSkip[54] = ldftn(StringToLongEncoderReplacementFallback);
			RPCStuff.NoCustomMarshalSkip[55] = ldftn(LargeObjectHeapCompactionModeHasSecurity);
			RPCStuff.NoCustomMarshalSkip[56] = ldftn(collectionSignal);
			RPCStuff.NoCustomMarshalSkip[57] = ldftn(setEventChannelTypegetArgs);
			RPCStuff.NoCustomMarshalSkip[58] = ldftn(IClientChannelSinkStackgetHashSize);
			RPCStuff.NoCustomMarshalSkip[59] = ldftn(ActivityOptionsEnumFields);
			RPCStuff.NoCustomMarshalSkip[60] = ldftn(OutputBlockSizeDeclaredNestedTypes);
			RPCStuff.NoCustomMarshalSkip[61] = ldftn(BinaryCrossAppDomainStringgetSupportUrl);
			RPCStuff.NoCustomMarshalSkip[62] = ldftn(SecureStringToGlobalAllocAnsiGetOrderableDynamicPartitions);
			RPCStuff.NoCustomMarshalSkip[63] = ldftn(InternetCacheRemoveOnLogSwitchLevel);
			RPCStuff.NoCustomMarshalSkip[64] = ldftn(NativeVariantConstructorName);
			RPCStuff.NoCustomMarshalSkip[65] = ldftn(FieldDefgetCategoryMembershipData);
			RPCStuff.NoCustomMarshalSkip[66] = ldftn(CMSTIMEUNITTYPEDAYSgetAutoFlush);
			RPCStuff.NoCustomMarshalSkip[67] = ldftn(AuthenticodeWindowsRuntimeImportAttribute);
			RPCStuff.NoCustomMarshalSkip[68] = ldftn(AllInternalsVisiblegetTraceLevel);
			RPCStuff.NoCustomMarshalSkip[69] = ldftn(FlushAsyncInternaldDisposition);
			RPCStuff.NoCustomMarshalSkip[70] = ldftn(VTUNKNOWNgetPreviousValue);
			RPCStuff.NoCustomMarshalSkip[71] = ldftn(PermitOnlyGetRawCertData);
			RPCStuff.NoCustomMarshalSkip[72] = ldftn(GetApartmentStateLastNodeType);
			RPCStuff.NoCustomMarshalSkip[73] = ldftn(ManifestResourceWinNT);
			RPCStuff.NoCustomMarshalSkip[74] = ldftn(AddWeeksSymDocumentType);
			RPCStuff.NoCustomMarshalSkip[75] = ldftn(getKeysOrderedInEachPartitionConvertToUtf);
			RPCStuff.NoCustomMarshalSkip[76] = ldftn(SortDynamicAssemblyFlags);
			RPCStuff.NoCustomMarshalSkip[77] = ldftn(EqualityComparerGetRuntimeEvent);
			RPCStuff.NoCustomMarshalSkip[78] = ldftn(InProcessHandlerEventHandler);
			RPCStuff.NoCustomMarshalSkip[79] = ldftn(ModesetFilterLevel);
			RPCStuff.NoCustomMarshalSkip[80] = ldftn(SetServerIdentityVARFLAGFDEFAULTBIND);
			RPCStuff.NoCustomMarshalSkip[81] = ldftn(DependentOSMetadataSupportUrlINVOCATIONFLAGSRISKYMETHOD);
			RPCStuff.NoCustomMarshalSkip[82] = ldftn(ClaimsGetBaseException);
			RPCStuff.NoCustomMarshalSkip[83] = ldftn(SendToSecureStringToCoTaskMemAnsi);
			RPCStuff.NoCustomMarshalSkip[84] = ldftn(EmptySetINVOCATIONFLAGSFIELDSPECIALCAST);
			RPCStuff.NoCustomMarshalSkip[85] = ldftn(CheckDemandsetXmlElementName);
			RPCStuff.NoCustomMarshalSkip[86] = ldftn(DialupSidInterfaceTypeAttribute);
			RPCStuff.NoCustomMarshalSkip[87] = ldftn(AsyncMessageHelperIServerFormatterSinkProvider);
			RPCStuff.NoCustomMarshalSkip[88] = ldftn(bufferSizeISymbolScope);
			RPCStuff.NoCustomMarshalSkip[89] = ldftn(NumberTokenComRedirectionProxy);
			RPCStuff.NoCustomMarshalSkip[90] = ldftn(TargetTypeAssemblyGetInArgName);
			RPCStuff.NoCustomMarshalSkip[91] = ldftn(MinValueaddCancelKeyPress);
			RPCStuff.NoCustomMarshalSkip[92] = ldftn(HostSecurityManagerNullableComparer);
			RPCStuff.NoCustomMarshalSkip[93] = ldftn(ISTOREENUMFILESFLAGINCLUDEMISSINGFILESSetPrincipalPolicy);
			RPCStuff.NoCustomMarshalSkip[94] = ldftn(AddSurrogateSerializedStreamHeaderEnd);
			RPCStuff.NoCustomMarshalSkip[95] = ldftn(matchMuiResourceTypeIdIntEntryFieldId);
			RPCStuff.NoCustomMarshalSkip[96] = ldftn(IPersistFileStreamWriter);
			RPCStuff.NoCustomMarshalSkip[97] = ldftn(BackgroundRedMakeString);
			RPCStuff.NoCustomMarshalSkip[98] = ldftn(IDispatchConstantAttributeDefineLiteral);
			RPCStuff.NoCustomMarshalSkip[99] = ldftn(localFinallyIStructuralEquatable);
			RPCStuff.NoCustomMarshalSkip[100] = ldftn(FilterAttributeGetSoapActionFromMethodBase);
			RPCStuff.NoCustomMarshalSkip[101] = ldftn(EndChildrenCallbackRequiredContract);
			RPCStuff.NoCustomMarshalSkip[102] = ldftn(IDeferredDisposablesetTypeInfo);
			RPCStuff.NoCustomMarshalSkip[103] = ldftn(CustomErrorsModeSecurityContext);
			RPCStuff.NoCustomMarshalSkip[104] = ldftn(AcquireFull);
			RPCStuff.NoCustomMarshalSkip[105] = ldftn(PropertyBuilderGREGORIANXLITFRENCH);
			RPCStuff.NoCustomMarshalSkip[106] = ldftn(ByteTokenEncodingUseLeapYearMonth);
			RPCStuff.NoCustomMarshalSkip[107] = ldftn(RevisionNumberIsUsedUp);
			RPCStuff.NoCustomMarshalSkip[108] = ldftn(VTSTREAMgetMaxStackSize);
			RPCStuff.NoCustomMarshalSkip[109] = ldftn(SpinUntilExtensibleClassFactory);
			RPCStuff.NoCustomMarshalSkip[110] = ldftn(MagicNumberINVOKEFUNC);
			RPCStuff.NoCustomMarshalSkip[111] = ldftn(ToDateTimeOverlapped);
			RPCStuff.NoCustomMarshalSkip[112] = ldftn(GetAssemblyNameToXmlString);
			RPCStuff.NoCustomMarshalSkip[113] = ldftn(VARFLAGFNONBROWSABLEObjectDisposedException);
			RPCStuff.NoCustomMarshalSkip[114] = ldftn(DecoderFallbackBufferStructureToPtr);
			RPCStuff.NoCustomMarshalSkip[115] = ldftn(DelayPromiseAssemblyIsolationByRoamingUser);
			RPCStuff.NoCustomMarshalSkip[116] = ldftn(MicrosoftTelemetryDependentOSMetadataDescription);
			RPCStuff.NoCustomMarshalSkip[117] = ldftn(CModReqdTotalSeconds);
			RPCStuff.NoCustomMarshalSkip[118] = ldftn(GetTypeCompAssignPrimaryToken);
			RPCStuff.NoCustomMarshalSkip[119] = ldftn(UnboxStateOrProvince);
			RPCStuff.NoCustomMarshalSkip[120] = ldftn(XmlNsForClrTypeWithAssemblysetDigitSubstitution);
			RPCStuff.NoCustomMarshalSkip[121] = ldftn(getPermitOnlySetInstanceCreateFlags);
			RPCStuff.NoCustomMarshalSkip[122] = ldftn(setOutputEncodingSetInterfaceConstraints);
			RPCStuff.NoCustomMarshalSkip[123] = ldftn(ObjectStringExecutionContext);
			RPCStuff.NoCustomMarshalSkip[124] = ldftn(IetfLanguageTagReadToEndAsyncd);
			RPCStuff.NoCustomMarshalSkip[125] = ldftn(getOffendingNumberIsolatedStorageSecurityOptions);
			RPCStuff.NoCustomMarshalSkip[126] = ldftn(DefaultBinderNotImplementedException);
			RPCStuff.NoCustomMarshalSkip[127] = ldftn(getIsContainergetUrl);
		}

		// Token: 0x040000C2 RID: 194
		private static float splashtimeout;

		// Token: 0x040000C3 RID: 195
		private static IntPtr[] NoCustomMarshalSkip;
	}
}
