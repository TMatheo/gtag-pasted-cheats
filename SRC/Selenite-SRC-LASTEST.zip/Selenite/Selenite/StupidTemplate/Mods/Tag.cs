﻿using System;
using System.Collections.Generic;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using UnityEngine;

namespace StupidTemplate.Mods
{
	// Token: 0x0200002D RID: 45
	internal class Tag
	{
		// Token: 0x0600069E RID: 1694 RVA: 0x0003F984 File Offset: 0x0003DB84
		private static void FactoryMagicNumber(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 10 + 37;
			A_0 = num;
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x0003F9F4 File Offset: 0x0003DBF4
		private static void RemotingTypeCachedDataECB(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			int num = (A_10.MoveNext() ? 1 : 0) * -11 + 29;
			A_0 = num;
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x0003FA3C File Offset: 0x0003DC3C
		public unsafe static void TagSelf()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 32;
			int num4 = 32;
			num4 = 32;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 1)
					{
						num4 = 32;
						if ((int)array[5] != 1)
						{
							num5 = (int)array[1];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num5 + 40 + num2);
								num7 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + (int)array[6] + 40 + num2) + 40 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num7 + 56 + num2);
								if (num8 != -1)
								{
									num9 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num8 + 24 + num2);
									array[6] = num8;
									array[3] = 1;
									num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num8 + 24 + num2);
									goto IL_1A;
								}
								num7 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num7 + 40 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[2];
							num9 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num5 + 24 + num2);
							ex3 = ex2;
							array = (object[])array[0];
							array2 = new object[8];
							array2[5] = 0;
							array2[0] = array;
							array2[2] = ex2;
							array2[6] = num5;
							array2[3] = 2;
							array = array2;
							num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num5 + 24 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[4];
							array = (object[])array[0];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							bool flag3;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref flag3, Tag.SetAccessControlUser[num3]);
							continue;
						}
						num4 = 32;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num16 * 72 + 40 + num2);
						num18 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num16 * 72 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num7 * 72 + 56 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num15 * 72 + 40 + num2);
						num6 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num15 * 72 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num7 * 72 + 56 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num16 * 64 + 40 + num2);
						num18 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num16 * 64 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num7 * 64 + 48 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A69:
						if (array == null || (int)array[5] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num6 + 40 + num2);
								}
								else
								{
									num11 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 56 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 40 + num2);
									goto IL_A69;
								}
							}
							goto IL_C04;
						}
						int num20 = (int)array[6];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 32 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num16 * 64 + 40 + num2);
								num11 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num16 * 64 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num5 * 64 + 48 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num7 + 40 + num2);
								}
								else
								{
									num5 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 56 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 40 + num2);
									goto IL_A69;
								}
							}
							break;
						}
						if ((int)array[6] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[0];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num5 + 24 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[0] = array;
					array2[4] = num12;
					array2[6] = num5;
					array2[3] = 1;
					array = array2;
					num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num5 + 24 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C04:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num11 + 24 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[0] = array;
					array2[4] = num12;
					array2[6] = num11;
					array2[3] = 1;
					array = array2;
					num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num11 + 24 + num2);
				}
				num4 = 32;
				return;
				IL_1D2:
				if (num15 != -1)
				{
					goto IL_1DD;
				}
				goto IL_404;
				IL_1DD:
				num6 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num15 + num2);
				if (3 == num6)
				{
					goto IL_1F9;
				}
				if (0 == num6)
				{
					goto IL_38B;
				}
				goto IL_404;
				IL_1F9:
				num11 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num15 + 48 + num2);
				if (num11 == -1)
				{
					goto IL_247;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_22D;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_22D:
				if (type.IsInstanceOfType(array2[2]))
				{
					goto IL_247;
				}
				num15 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num15 + 56 + num2);
				goto IL_1D2;
				IL_247:
				num19 = num15;
				num14 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 40 + num2) + 40 + num2);
				num7 = (int)array2[7];
				IL_26B:
				if (num7 != num14)
				{
					goto IL_2EA;
				}
				num16 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 24 + num2);
				ex3 = array2[2];
				array = (object[])array[0];
				object[] array5 = new object[8];
				array5[5] = 0;
				array5[0] = array;
				array5[2] = array2[2];
				array5[7] = (int)array2[7];
				array5[6] = num19;
				array5[3] = 2;
				array = array5;
				num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 24 + num2);
				goto IL_1A;
				IL_2EA:
				num9 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num7 + 56 + num2);
				if (num9 == -1)
				{
					goto IL_379;
				}
				num16 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num9 + 24 + num2);
				array = (object[])array[0];
				array5 = new object[8];
				array5[5] = 0;
				array5[0] = array;
				array5[2] = array2[2];
				array5[7] = (int)array2[7];
				array5[6] = num9;
				array5[1] = num19;
				array5[3] = 1;
				array = array5;
				num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num9 + 24 + num2);
				goto IL_1A;
				IL_379:
				num7 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num7 + 40 + num2);
				goto IL_26B;
				IL_38B:
				num16 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num15 + 16 + num2);
				ex3 = array2[2];
				array = (object[])array[0];
				array5 = new object[8];
				array5[5] = 0;
				array5[0] = array;
				array5[2] = array2[2];
				array5[7] = (int)array2[7];
				array5[6] = num15;
				array5[3] = 0;
				array = array5;
				num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num15 + 16 + num2);
				goto IL_1A;
				IL_404:
				array = (object[])array[0];
				ex = array2[2];
				int num23 = (int)array2[7];
				IL_423:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_431:
				num8 = (num17 + num18) / 2;
				num5 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num8 * 72 + 40 + num2);
				num22 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num8 * 72 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_474;
				}
				if (num5 > num16)
				{
					goto IL_47C;
				}
				num14 = num8;
				num19 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 136 + num14 * 72 + 56 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4A4;
				IL_474:
				num17 = num8 + 1;
				goto IL_431;
				IL_47C:
				num18 = num8 - 1;
				goto IL_431;
				IL_4A4:
				if (array != null)
				{
					goto IL_4AF;
				}
				goto IL_638;
				IL_4AF:
				if ((int)array[5] != 1)
				{
					goto IL_56C;
				}
				int num24 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_4D3;
				}
				int num25 = -1;
				goto IL_553;
				IL_4D3:
				int num26 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num11 + 32 + num2);
				num22 = 0;
				num5 = 2;
				IL_4E6:
				num8 = (num22 + num5) / 2;
				num18 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num8 * 64 + 40 + num2);
				num17 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num8 * 64 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_529;
				}
				if (num18 > num26)
				{
					goto IL_531;
				}
				num19 = num8;
				num14 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num19 * 64 + 48 + num2);
				num25 = num14;
				goto IL_553;
				IL_529:
				num22 = num8 + 1;
				goto IL_4E6;
				IL_531:
				num5 = num8 - 1;
				goto IL_4E6;
				IL_553:
				if (num24 != num25)
				{
					goto IL_55B;
				}
				goto IL_638;
				IL_55B:
				array = (object[])array[0];
				goto IL_4A4;
				IL_56C:
				num9 = (int)array[3];
				if (num9 == 2 || num9 == 1)
				{
					goto IL_58D;
				}
				if (num9 != 0)
				{
					goto IL_58C;
				}
				array2 = array;
				num15 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + (int)array2[6] + 56 + num2);
				goto IL_1D2;
				IL_58C:
				IL_58D:
				int num27 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_5A2;
				}
				int num28 = -1;
				goto IL_622;
				IL_5A2:
				num16 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num11 + 32 + num2);
				num17 = 0;
				num18 = 2;
				IL_5B5:
				num8 = (num17 + num18) / 2;
				num5 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num8 * 64 + 40 + num2);
				num22 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num8 * 64 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5F8;
				}
				if (num5 > num16)
				{
					goto IL_600;
				}
				num14 = num8;
				num19 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + 352 + num14 * 64 + 48 + num2);
				num28 = num19;
				goto IL_622;
				IL_5F8:
				num17 = num8 + 1;
				goto IL_5B5;
				IL_600:
				num18 = num8 - 1;
				goto IL_5B5;
				IL_622:
				if (num27 != num28)
				{
					goto IL_627;
				}
				goto IL_638;
				IL_627:
				array = (object[])array[0];
				goto IL_4A4;
				IL_638:
				if (-1 != num11)
				{
					goto IL_6DC;
				}
				num19 = num7;
				IL_645:
				if (num19 != -1)
				{
					goto IL_651;
				}
				num10 = 1;
				throw ex;
				IL_651:
				num14 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 56 + num2);
				if (num14 == -1)
				{
					goto IL_6CA;
				}
				num26 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num14 + 24 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[0] = array;
				array2[2] = ex;
				array2[7] = num7;
				array2[6] = -1;
				array2[1] = -1;
				array2[3] = 2;
				array = array2;
				num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num14 + 24 + num2);
				goto IL_1A;
				IL_6CA:
				num19 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num19 + 40 + num2);
				goto IL_645;
				IL_6DC:
				num6 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num11 + num2);
				num16 = num6;
				IL_6EA:
				if (num16 != -1)
				{
					goto IL_701;
				}
				num11 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num11 + 40 + num2);
				goto IL_4A4;
				IL_701:
				num18 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num16 + num2);
				if (3 == num18)
				{
					goto IL_729;
				}
				if (0 == num18)
				{
					goto IL_897;
				}
				num11 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num11 + 40 + num2);
				goto IL_4A4;
				IL_729:
				num17 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num16 + 48 + num2);
				if (num17 == -1)
				{
					goto IL_778;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_75D;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_75D:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_778;
				}
				num16 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num16 + 56 + num2);
				goto IL_6EA;
				IL_778:
				num26 = num16;
				num22 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num26 + 40 + num2) + 40 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7A1:
				if (num5 != num22)
				{
					goto IL_80A;
				}
				int num29 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num26 + 24 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[0] = array;
				array2[2] = ex;
				array2[7] = num7;
				array2[6] = num26;
				array2[3] = 2;
				array = array2;
				num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num26 + 24 + num2);
				goto IL_1A;
				IL_80A:
				num8 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num5 + 56 + num2);
				if (num8 == -1)
				{
					goto IL_885;
				}
				num29 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num8 + 24 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[0] = array;
				array2[2] = ex;
				array2[7] = num7;
				array2[6] = num8;
				array2[1] = num26;
				array2[3] = 1;
				array = array2;
				num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num8 + 24 + num2);
				goto IL_1A;
				IL_885:
				num5 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num5 + 40 + num2);
				goto IL_7A1;
				IL_897:
				num29 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num16 + 16 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[0] = array;
				array2[2] = ex;
				array2[7] = num7;
				array2[6] = num16;
				array2[3] = 0;
				array = array2;
				num3 = *(ref getSkipVerificationSetGlobalResourceContextDefaultCulture.TokenGroupsAndPrivilegesSyncProcessMessage + num16 + 16 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_423;
				}
				throw ex4;
			}
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x00040708 File Offset: 0x0003E908
		private static void GetFileLineNumbergetIsBrowserSave(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			A_1 = 36;
			A_2 = 31;
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x0004072C File Offset: 0x0003E92C
		private static void LockTypeGetParamCustData(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			A_10.Dispose();
			A_1 = 34;
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x00040754 File Offset: 0x0003E954
		private static void EqualsGetDomain(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 40;
				int num2 = 40;
				num2 = 40;
				while (num2 != 0)
				{
					int num3;
					VRRig vrrig;
					int num4;
					Player player;
					bool flag;
					int num5;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,VRRig&,System.Int32&,Photon.Realtime.Player&,System.Boolean&,System.Int32&), ref num, ref num2, ref num3, ref vrrig, ref num4, ref player, ref flag, ref num5, Tag.<>c.WindowsSubAuthorityCMSASSEMBLYDEPLOYMENTFLAGDISALLOWURLACTIVATION[num]);
				}
				num2 = 40;
			}, true);
			A_1 = 0;
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x0004079C File Offset: 0x0003E99C
		private static void ContainsValueFullTypeName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 4;
			A_2 = 51;
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x000407C0 File Offset: 0x0003E9C0
		private static void SystemAclPresentNestedType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 72;
			A_0 = num;
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x00040808 File Offset: 0x0003EA08
		private static void getTargetTypeNameIsLetterOrDigit(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -7 + 107;
			A_0 = num2;
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x00040868 File Offset: 0x0003EA68
		private static void POLICYSETAUDITREQUIREMENTSWellKnownClientTypeEntry(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			int num = (A_10.MoveNext() ? 1 : 0) * -11 + 29;
			A_0 = num;
		}

		// Token: 0x060006A8 RID: 1704 RVA: 0x000408B0 File Offset: 0x0003EAB0
		private static void TanhIsFamilyAndAssembly(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			A_0 = 94;
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x000408C8 File Offset: 0x0003EAC8
		private static void DescriptionMetadataErrorReportUrlMetadataEnumResult(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 33;
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x00040904 File Offset: 0x0003EB04
		private static void SkipsetShortestDayNames(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			A_1 = 36;
			A_2 = 16;
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x00040928 File Offset: 0x0003EB28
		private static void MutexTryCodeHelperReturnType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			int num = ((!A_5.mainSkin.material.name.Contains("fected")) ? 1 : 0) * 1 + 58;
			A_0 = num;
		}

		// Token: 0x060006AC RID: 1708 RVA: 0x00040988 File Offset: 0x0003EB88
		private static void UpnResourceTypeIdInt(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			A_1 = 0;
		}

		// Token: 0x060006AD RID: 1709 RVA: 0x000409A0 File Offset: 0x0003EBA0
		public unsafe static void TagAura()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 52;
			int num4 = 52;
			num4 = 52;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num21;
				int num24;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 52;
						if ((int)array[7] != 1)
						{
							num5 = (int)array[0];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num5 + 88 + num2);
								num7 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + (int)array[6] + 88 + num2) + 80 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num7 + 72 + num2);
								if (num8 != -1)
								{
									num9 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num8 + 72 + num2);
									array[6] = num8;
									array[4] = 2;
									num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num8 + 72 + num2);
									goto IL_1A;
								}
								num7 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num7 + 80 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[2];
							num9 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num5 + 72 + num2);
							ex3 = ex2;
							array = (object[])array[5];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								0
							};
							array2[5] = array;
							array2[2] = ex2;
							array2[6] = num5;
							array2[4] = 0;
							array = array2;
							num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num5 + 72 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[1];
							array = (object[])array[5];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							bool flag3;
							bool flag4;
							float num14;
							float num15;
							bool flag5;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Single&,System.Single&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref flag3, ref flag4, ref num14, ref num15, ref flag5, Tag.SetAccessControlUser[num3]);
							continue;
						}
						num4 = 52;
						num8 = num13;
						num12 = num8;
					}
					num16 = num3;
					num6 = num16;
					num11 = 0;
					num17 = 2;
					for (;;)
					{
						num18 = (num11 + num17) / 2;
						num19 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num18 * 80 + 72 + num2);
						num20 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num18 * 80 + 48 + num2);
						if (num6 < num19 + num20)
						{
							if (num19 <= num6)
							{
								break;
							}
							num17 = num18 - 1;
						}
						else
						{
							num11 = num18 + 1;
						}
					}
					num7 = num18;
					num9 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num7 * 80 + 64 + num2);
					num21 = num9;
					num20 = num12;
					num19 = 0;
					num18 = 2;
					for (;;)
					{
						num17 = (num19 + num18) / 2;
						num11 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num17 * 80 + 72 + num2);
						num6 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num17 * 80 + 48 + num2);
						if (num20 < num11 + num6)
						{
							if (num11 <= num20)
							{
								break;
							}
							num18 = num17 - 1;
						}
						else
						{
							num19 = num17 + 1;
						}
					}
					num7 = num17;
					num8 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num7 * 80 + 64 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num17 = 2;
					for (;;)
					{
						num18 = (num11 + num17) / 2;
						num19 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num18 * 80 + 72 + num2);
						num20 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num18 * 80 + 48 + num2);
						if (num6 < num19 + num20)
						{
							if (num19 <= num6)
							{
								break;
							}
							num17 = num18 - 1;
						}
						else
						{
							num11 = num18 + 1;
						}
					}
					num7 = num18;
					num5 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num7 * 80 + 64 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A8C:
						if (array == null || (int)array[7] == 1)
						{
							num6 = num9;
							while (num6 != num21)
							{
								if (num6 != -1)
								{
									num6 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num6 + 80 + num2);
								}
								else
								{
									num11 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 72 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num21 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 80 + num2);
									goto IL_A8C;
								}
							}
							goto IL_C2A;
						}
						int num22 = (int)array[6];
						int num23;
						if (num21 == -1)
						{
							num23 = -1;
						}
						else
						{
							num24 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 64 + num2);
							num20 = 0;
							num19 = 2;
							for (;;)
							{
								num18 = (num20 + num19) / 2;
								num17 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num18 * 80 + 72 + num2);
								num11 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num18 * 80 + 48 + num2);
								if (num24 < num17 + num11)
								{
									if (num17 <= num24)
									{
										break;
									}
									num19 = num18 - 1;
								}
								else
								{
									num20 = num18 + 1;
								}
							}
							num5 = num18;
							num7 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num5 * 80 + 64 + num2);
							num23 = num7;
						}
						if (num22 == num23)
						{
							num7 = num9;
							while (num7 != num21)
							{
								if (num7 != -1)
								{
									num7 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num7 + 80 + num2);
								}
								else
								{
									num5 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 72 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num21 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 80 + num2);
									goto IL_A8C;
								}
							}
							break;
						}
						if ((int)array[6] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[5];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num5 + 72 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						1
					};
					array2[5] = array;
					array2[1] = num12;
					array2[6] = num5;
					array2[4] = 2;
					array = array2;
					num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num5 + 72 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C2A:
					num3 = num12;
					continue;
					Block_62:
					num17 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num11 + 72 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						1
					};
					array2[5] = array;
					array2[1] = num12;
					array2[6] = num11;
					array2[4] = 2;
					array = array2;
					num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num11 + 72 + num2);
				}
				num4 = 52;
				return;
				IL_1DA:
				if (num17 != -1)
				{
					goto IL_1E5;
				}
				goto IL_40F;
				IL_1E5:
				num6 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num17 + 56 + num2);
				if (4 == num6)
				{
					goto IL_204;
				}
				if (2 == num6)
				{
					goto IL_396;
				}
				goto IL_40F;
				IL_204:
				num11 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num17 + 80 + num2);
				if (num11 == -1)
				{
					goto IL_252;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_238;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_238:
				if (type.IsInstanceOfType(array2[2]))
				{
					goto IL_252;
				}
				num17 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num17 + 64 + num2);
				goto IL_1DA;
				IL_252:
				num21 = num17;
				num16 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 88 + num2) + 80 + num2);
				num7 = (int)array2[3];
				IL_276:
				if (num7 != num16)
				{
					goto IL_2F5;
				}
				num18 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 72 + num2);
				ex3 = array2[2];
				array = (object[])array[5];
				object[] array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[5] = array;
				array5[2] = array2[2];
				array5[3] = (int)array2[3];
				array5[6] = num21;
				array5[4] = 0;
				array = array5;
				num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 72 + num2);
				goto IL_1A;
				IL_2F5:
				num9 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num7 + 72 + num2);
				if (num9 == -1)
				{
					goto IL_384;
				}
				num18 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num9 + 72 + num2);
				array = (object[])array[5];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[5] = array;
				array5[2] = array2[2];
				array5[3] = (int)array2[3];
				array5[6] = num9;
				array5[0] = num21;
				array5[4] = 2;
				array = array5;
				num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num9 + 72 + num2);
				goto IL_1A;
				IL_384:
				num7 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num7 + 80 + num2);
				goto IL_276;
				IL_396:
				num18 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num17 + 32 + num2);
				ex3 = array2[2];
				array = (object[])array[5];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[5] = array;
				array5[2] = array2[2];
				array5[3] = (int)array2[3];
				array5[6] = num17;
				array5[4] = 1;
				array = array5;
				num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num17 + 32 + num2);
				goto IL_1A;
				IL_40F:
				array = (object[])array[5];
				ex = array2[2];
				int num25 = (int)array2[3];
				IL_42E:
				num17 = num3;
				num18 = num17;
				num19 = 0;
				num20 = 2;
				IL_43C:
				num8 = (num19 + num20) / 2;
				num5 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num8 * 80 + 72 + num2);
				num24 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num8 * 80 + 48 + num2);
				if (num18 >= num5 + num24)
				{
					goto IL_482;
				}
				if (num5 > num18)
				{
					goto IL_48A;
				}
				num16 = num8;
				num21 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 184 + num16 * 80 + 64 + num2);
				num11 = num21;
				num7 = num11;
				goto IL_4B2;
				IL_482:
				num19 = num8 + 1;
				goto IL_43C;
				IL_48A:
				num20 = num8 - 1;
				goto IL_43C;
				IL_4B2:
				if (array != null)
				{
					goto IL_4BD;
				}
				goto IL_64C;
				IL_4BD:
				if ((int)array[7] != 1)
				{
					goto IL_57D;
				}
				int num26 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_4E1;
				}
				int num27 = -1;
				goto IL_564;
				IL_4E1:
				int num28 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num11 + 64 + num2);
				num24 = 0;
				num5 = 2;
				IL_4F4:
				num8 = (num24 + num5) / 2;
				num20 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num8 * 80 + 72 + num2);
				num19 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num8 * 80 + 48 + num2);
				if (num28 >= num20 + num19)
				{
					goto IL_53A;
				}
				if (num20 > num28)
				{
					goto IL_542;
				}
				num21 = num8;
				num16 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num21 * 80 + 64 + num2);
				num27 = num16;
				goto IL_564;
				IL_53A:
				num24 = num8 + 1;
				goto IL_4F4;
				IL_542:
				num5 = num8 - 1;
				goto IL_4F4;
				IL_564:
				if (num26 != num27)
				{
					goto IL_56C;
				}
				goto IL_64C;
				IL_56C:
				array = (object[])array[5];
				goto IL_4B2;
				IL_57D:
				num9 = (int)array[4];
				if (num9 == 0 || num9 == 2)
				{
					goto IL_59E;
				}
				if (num9 != 1)
				{
					goto IL_59D;
				}
				array2 = array;
				num17 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + (int)array2[6] + 64 + num2);
				goto IL_1DA;
				IL_59D:
				IL_59E:
				int num29 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_5B3;
				}
				int num30 = -1;
				goto IL_636;
				IL_5B3:
				num18 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num11 + 64 + num2);
				num19 = 0;
				num20 = 2;
				IL_5C6:
				num8 = (num19 + num20) / 2;
				num5 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num8 * 80 + 72 + num2);
				num24 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num8 * 80 + 48 + num2);
				if (num18 >= num5 + num24)
				{
					goto IL_60C;
				}
				if (num5 > num18)
				{
					goto IL_614;
				}
				num16 = num8;
				num21 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + 424 + num16 * 80 + 64 + num2);
				num30 = num21;
				goto IL_636;
				IL_60C:
				num19 = num8 + 1;
				goto IL_5C6;
				IL_614:
				num20 = num8 - 1;
				goto IL_5C6;
				IL_636:
				if (num29 != num30)
				{
					goto IL_63B;
				}
				goto IL_64C;
				IL_63B:
				array = (object[])array[5];
				goto IL_4B2;
				IL_64C:
				if (-1 != num11)
				{
					goto IL_6F0;
				}
				num21 = num7;
				IL_659:
				if (num21 != -1)
				{
					goto IL_665;
				}
				num10 = 1;
				throw ex;
				IL_665:
				num16 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 72 + num2);
				if (num16 == -1)
				{
					goto IL_6DE;
				}
				num28 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num16 + 72 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[5] = array;
				array2[2] = ex;
				array2[3] = num7;
				array2[6] = -1;
				array2[0] = -1;
				array2[4] = 0;
				array = array2;
				num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num16 + 72 + num2);
				goto IL_1A;
				IL_6DE:
				num21 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num21 + 80 + num2);
				goto IL_659;
				IL_6F0:
				num6 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num11 + 56 + num2);
				num18 = num6;
				IL_701:
				if (num18 != -1)
				{
					goto IL_718;
				}
				num11 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num11 + 80 + num2);
				goto IL_4B2;
				IL_718:
				num20 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num18 + 56 + num2);
				if (4 == num20)
				{
					goto IL_743;
				}
				if (2 == num20)
				{
					goto IL_8B1;
				}
				num11 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num11 + 80 + num2);
				goto IL_4B2;
				IL_743:
				num19 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num18 + 80 + num2);
				if (num19 == -1)
				{
					goto IL_792;
				}
				Type type2;
				if ((type2 = array3[num19]) != null)
				{
					goto IL_777;
				}
				array3[num19] = Type.GetTypeFromHandle(array4[num19]);
				type2 = array3[num19];
				IL_777:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_792;
				}
				num18 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num18 + 64 + num2);
				goto IL_701;
				IL_792:
				num28 = num18;
				num24 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num28 + 88 + num2) + 80 + num2);
				num5 = (num7 - num25) * ((num25 == -1) ? 1 : 0) + num25;
				IL_7BB:
				if (num5 != num24)
				{
					goto IL_824;
				}
				int num31 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num28 + 72 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[5] = array;
				array2[2] = ex;
				array2[3] = num7;
				array2[6] = num28;
				array2[4] = 0;
				array = array2;
				num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num28 + 72 + num2);
				goto IL_1A;
				IL_824:
				num8 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num5 + 72 + num2);
				if (num8 == -1)
				{
					goto IL_89F;
				}
				num31 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num8 + 72 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[5] = array;
				array2[2] = ex;
				array2[3] = num7;
				array2[6] = num8;
				array2[0] = num28;
				array2[4] = 2;
				array = array2;
				num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num8 + 72 + num2);
				goto IL_1A;
				IL_89F:
				num5 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num5 + 80 + num2);
				goto IL_7BB;
				IL_8B1:
				num31 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num18 + 32 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[5] = array;
				array2[2] = ex;
				array2[3] = num7;
				array2[6] = num18;
				array2[4] = 1;
				array = array2;
				num3 = *(ref OneWayIsSingleByte.SponsorshipTimeoutgetIsAssemblyNameSetExplicit + num18 + 32 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num25 = -1;
					goto IL_42E;
				}
				throw ex4;
			}
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x00041690 File Offset: 0x0003F890
		private static void OperatingSystemSecurityControlEvidence(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			A_0 = 71;
		}

		// Token: 0x060006AF RID: 1711 RVA: 0x000416A8 File Offset: 0x0003F8A8
		private static void IDeploymentMetadataEntryFromUnixTimeMilliseconds(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 76;
		}

		// Token: 0x060006B0 RID: 1712 RVA: 0x000416E4 File Offset: 0x0003F8E4
		private static void getCapacityGetMethodImplementationFlags(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			A_1 = 4;
			A_2 = 97;
		}

		// Token: 0x060006B1 RID: 1713 RVA: 0x00041708 File Offset: 0x0003F908
		private static void EventDataGetNativeOffset(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 13 + 57;
			A_0 = num;
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x00041778 File Offset: 0x0003F978
		private static void RemoveChildTrace(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("fected");
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 4 + 7;
			A_0 = num;
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x000417F8 File Offset: 0x0003F9F8
		private static void FlowActivityIfNeededIsAppEarlierThanWindowsPhoneMango(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -15 + 49;
			A_0 = num;
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x00041840 File Offset: 0x0003FA40
		private unsafe static void vmTpInitializedIsResource(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 1;
				int num2 = num * 4;
				int num3 = 2;
				int num4 = 2;
				num4 = 2;
				try
				{
					IL_17:
					object[] array;
					int num5;
					int num6;
					int num7;
					int num8;
					int num9;
					int num10;
					Exception ex;
					Exception ex3;
					object[] array2;
					int num11;
					int num14;
					int num15;
					int num16;
					int num17;
					int num18;
					int num19;
					int num22;
					while (num4 != 0)
					{
						int num12;
						if (num4 == 32)
						{
							num4 = 2;
							if ((int)array[5] != 1)
							{
								num5 = (int)array[1];
								if (num5 == -1)
								{
									num6 = -1;
									num7 = -1;
								}
								else
								{
									num6 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num5 + 64 + num2);
									num7 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + (int)array[2] + 64 + num2) + 56 + num2);
								}
								while (num7 != num6)
								{
									num8 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num7 + 24 + num2);
									if (num8 != -1)
									{
										num9 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num8 + 40 + num2);
										array[2] = num8;
										array[3] = 2;
										num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num8 + 40 + num2);
										goto IL_17;
									}
									num7 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num7 + 56 + num2);
								}
								if (num5 == -1)
								{
									num10 = 1;
									throw ex;
								}
								Exception ex2 = (Exception)array[7];
								num9 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num5 + 40 + num2);
								ex3 = ex2;
								array = (object[])array[4];
								array2 = new object[8];
								array2[5] = 0;
								array2[4] = array;
								array2[7] = ex2;
								array2[2] = num5;
								array2[3] = 0;
								array = array2;
								num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num5 + 40 + num2);
								continue;
							}
							else
							{
								num11 = (int)array[6];
								array = (object[])array[4];
								num12 = num11;
							}
						}
						else
						{
							int num13;
							if (num4 != 34)
							{
								bool flag;
								List<VRRig>.Enumerator enumerator;
								VRRig vrrig;
								bool flag2;
								bool flag3;
								bool flag4;
								List<VRRig>.Enumerator enumerator2;
								VRRig vrrig2;
								bool flag5;
								bool flag6;
								calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Boolean&,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Boolean&,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref flag, ref enumerator, ref vrrig, ref flag2, ref flag3, ref flag4, ref enumerator2, ref vrrig2, ref flag5, ref flag6, Tag.<>c.WindowsSubAuthorityCMSASSEMBLYDEPLOYMENTFLAGDISALLOWURLACTIVATION[num3]);
								continue;
							}
							num4 = 2;
							num8 = num13;
							num12 = num8;
						}
						num14 = num3;
						num6 = num14;
						num11 = 0;
						num15 = 4;
						for (;;)
						{
							num16 = (num11 + num15) / 2;
							num17 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num16 * 56 + 40 + num2);
							num18 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num16 * 56 + 24 + num2);
							if (num6 < num17 + num18)
							{
								if (num17 <= num6)
								{
									break;
								}
								num15 = num16 - 1;
							}
							else
							{
								num11 = num16 + 1;
							}
						}
						num7 = num16;
						num9 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num7 * 56 + 16 + num2);
						num19 = num9;
						num18 = num12;
						num17 = 0;
						num16 = 4;
						for (;;)
						{
							num15 = (num17 + num16) / 2;
							num11 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num15 * 56 + 40 + num2);
							num6 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num15 * 56 + 24 + num2);
							if (num18 < num11 + num6)
							{
								if (num11 <= num18)
								{
									break;
								}
								num16 = num15 - 1;
							}
							else
							{
								num17 = num15 + 1;
							}
						}
						num7 = num15;
						num8 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num7 * 56 + 16 + num2);
						num9 = num8;
						num6 = num12;
						num11 = 0;
						num15 = 4;
						for (;;)
						{
							num16 = (num11 + num15) / 2;
							num17 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num16 * 64 + 40 + num2);
							num18 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num16 * 64 + 32 + num2);
							if (num6 < num17 + num18)
							{
								if (num17 <= num6)
								{
									break;
								}
								num15 = num16 - 1;
							}
							else
							{
								num11 = num16 + 1;
							}
						}
						num7 = num16;
						num5 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num7 * 64 + 16 + num2);
						num8 = num5;
						for (;;)
						{
							IL_A81:
							if (array == null || (int)array[5] == 1)
							{
								num6 = num9;
								while (num6 != num19)
								{
									if (num6 != -1)
									{
										num6 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num6 + 56 + num2);
									}
									else
									{
										num11 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 24 + num2);
										if (num11 != -1)
										{
											goto Block_62;
										}
										num19 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 56 + num2);
										goto IL_A81;
									}
								}
								goto IL_C1F;
							}
							int num20 = (int)array[2];
							int num21;
							if (num19 == -1)
							{
								num21 = -1;
							}
							else
							{
								num22 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 32 + num2);
								num18 = 0;
								num17 = 4;
								for (;;)
								{
									num16 = (num18 + num17) / 2;
									num15 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num16 * 64 + 40 + num2);
									num11 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num16 * 64 + 32 + num2);
									if (num22 < num15 + num11)
									{
										if (num15 <= num22)
										{
											break;
										}
										num17 = num16 - 1;
									}
									else
									{
										num18 = num16 + 1;
									}
								}
								num5 = num16;
								num7 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num5 * 64 + 16 + num2);
								num21 = num7;
							}
							if (num20 == num21)
							{
								num7 = num9;
								while (num7 != num19)
								{
									if (num7 != -1)
									{
										num7 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num7 + 56 + num2);
									}
									else
									{
										num5 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 24 + num2);
										if (num5 != -1)
										{
											goto Block_58;
										}
										num19 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 56 + num2);
										goto IL_A81;
									}
								}
								break;
							}
							if ((int)array[2] == num8)
							{
								goto Block_59;
							}
							array = (object[])array[4];
						}
						num3 = num12;
						continue;
						Block_58:
						num6 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num5 + 40 + num2);
						array2 = new object[8];
						array2[5] = 1;
						array2[4] = array;
						array2[6] = num12;
						array2[2] = num5;
						array2[3] = 2;
						array = array2;
						num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num5 + 40 + num2);
						continue;
						Block_59:
						num3 = num12;
						continue;
						IL_C1F:
						num3 = num12;
						continue;
						Block_62:
						num15 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num11 + 40 + num2);
						array2 = new object[8];
						array2[5] = 1;
						array2[4] = array;
						array2[6] = num12;
						array2[2] = num11;
						array2[3] = 2;
						array = array2;
						num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num11 + 40 + num2);
					}
					num4 = 2;
					return;
					IL_1D5:
					if (num15 != -1)
					{
						goto IL_1E0;
					}
					goto IL_407;
					IL_1E0:
					num6 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num15 + 48 + num2);
					if (3 == num6)
					{
						goto IL_1FF;
					}
					if (2 == num6)
					{
						goto IL_38E;
					}
					goto IL_407;
					IL_1FF:
					num11 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num15 + 24 + num2);
					if (num11 == -1)
					{
						goto IL_24A;
					}
					Type[] array3;
					Type type;
					if ((type = array3[num11]) != null)
					{
						goto IL_233;
					}
					RuntimeTypeHandle[] array4;
					array3[num11] = Type.GetTypeFromHandle(array4[num11]);
					type = array3[num11];
					IL_233:
					if (type.IsInstanceOfType(array2[7]))
					{
						goto IL_24A;
					}
					num15 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num15 + num2);
					goto IL_1D5;
					IL_24A:
					num19 = num15;
					num14 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 64 + num2) + 56 + num2);
					num7 = (int)array2[0];
					IL_26E:
					if (num7 != num14)
					{
						goto IL_2ED;
					}
					num16 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 40 + num2);
					ex3 = array2[7];
					array = (object[])array[4];
					object[] array5 = new object[8];
					array5[5] = 0;
					array5[4] = array;
					array5[7] = array2[7];
					array5[0] = (int)array2[0];
					array5[2] = num19;
					array5[3] = 0;
					array = array5;
					num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 40 + num2);
					goto IL_17;
					IL_2ED:
					num9 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num7 + 24 + num2);
					if (num9 == -1)
					{
						goto IL_37C;
					}
					num16 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num9 + 40 + num2);
					array = (object[])array[4];
					array5 = new object[8];
					array5[5] = 0;
					array5[4] = array;
					array5[7] = array2[7];
					array5[0] = (int)array2[0];
					array5[2] = num9;
					array5[1] = num19;
					array5[3] = 2;
					array = array5;
					num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num9 + 40 + num2);
					goto IL_17;
					IL_37C:
					num7 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num7 + 56 + num2);
					goto IL_26E;
					IL_38E:
					num16 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num15 + 72 + num2);
					ex3 = array2[7];
					array = (object[])array[4];
					array5 = new object[8];
					array5[5] = 0;
					array5[4] = array;
					array5[7] = array2[7];
					array5[0] = (int)array2[0];
					array5[2] = num15;
					array5[3] = 1;
					array = array5;
					num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num15 + 72 + num2);
					goto IL_17;
					IL_407:
					array = (object[])array[4];
					ex = array2[7];
					int num23 = (int)array2[0];
					IL_426:
					num15 = num3;
					num16 = num15;
					num17 = 0;
					num18 = 4;
					IL_434:
					num8 = (num17 + num18) / 2;
					num5 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num8 * 56 + 40 + num2);
					num22 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num8 * 56 + 24 + num2);
					if (num16 >= num5 + num22)
					{
						goto IL_47A;
					}
					if (num5 > num16)
					{
						goto IL_482;
					}
					num14 = num8;
					num19 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 336 + num14 * 56 + 16 + num2);
					num11 = num19;
					num7 = num11;
					goto IL_4AA;
					IL_47A:
					num17 = num8 + 1;
					goto IL_434;
					IL_482:
					num18 = num8 - 1;
					goto IL_434;
					IL_4AA:
					if (array != null)
					{
						goto IL_4B5;
					}
					goto IL_644;
					IL_4B5:
					if ((int)array[5] != 1)
					{
						goto IL_575;
					}
					int num24 = (int)array[2];
					if (num11 != -1)
					{
						goto IL_4D9;
					}
					int num25 = -1;
					goto IL_55C;
					IL_4D9:
					int num26 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num11 + 32 + num2);
					num22 = 0;
					num5 = 4;
					IL_4EC:
					num8 = (num22 + num5) / 2;
					num18 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num8 * 64 + 40 + num2);
					num17 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num8 * 64 + 32 + num2);
					if (num26 >= num18 + num17)
					{
						goto IL_532;
					}
					if (num18 > num26)
					{
						goto IL_53A;
					}
					num19 = num8;
					num14 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num19 * 64 + 16 + num2);
					num25 = num14;
					goto IL_55C;
					IL_532:
					num22 = num8 + 1;
					goto IL_4EC;
					IL_53A:
					num5 = num8 - 1;
					goto IL_4EC;
					IL_55C:
					if (num24 != num25)
					{
						goto IL_564;
					}
					goto IL_644;
					IL_564:
					array = (object[])array[4];
					goto IL_4AA;
					IL_575:
					num9 = (int)array[3];
					if (num9 == 0 || num9 == 2)
					{
						goto IL_596;
					}
					if (num9 != 1)
					{
						goto IL_595;
					}
					array2 = array;
					num15 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + (int)array2[2] + num2);
					goto IL_1D5;
					IL_595:
					IL_596:
					int num27 = (int)array[2];
					if (num11 != -1)
					{
						goto IL_5AB;
					}
					int num28 = -1;
					goto IL_62E;
					IL_5AB:
					num16 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num11 + 32 + num2);
					num17 = 0;
					num18 = 4;
					IL_5BE:
					num8 = (num17 + num18) / 2;
					num5 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num8 * 64 + 40 + num2);
					num22 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num8 * 64 + 32 + num2);
					if (num16 >= num5 + num22)
					{
						goto IL_604;
					}
					if (num5 > num16)
					{
						goto IL_60C;
					}
					num14 = num8;
					num19 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + 616 + num14 * 64 + 16 + num2);
					num28 = num19;
					goto IL_62E;
					IL_604:
					num17 = num8 + 1;
					goto IL_5BE;
					IL_60C:
					num18 = num8 - 1;
					goto IL_5BE;
					IL_62E:
					if (num27 != num28)
					{
						goto IL_633;
					}
					goto IL_644;
					IL_633:
					array = (object[])array[4];
					goto IL_4AA;
					IL_644:
					if (-1 != num11)
					{
						goto IL_6E8;
					}
					num19 = num7;
					IL_651:
					if (num19 != -1)
					{
						goto IL_65D;
					}
					num10 = 1;
					throw ex;
					IL_65D:
					num14 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 24 + num2);
					if (num14 == -1)
					{
						goto IL_6D6;
					}
					num26 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num14 + 40 + num2);
					array2 = new object[8];
					array2[5] = 0;
					array2[4] = array;
					array2[7] = ex;
					array2[0] = num7;
					array2[2] = -1;
					array2[1] = -1;
					array2[3] = 0;
					array = array2;
					num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num14 + 40 + num2);
					goto IL_17;
					IL_6D6:
					num19 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num19 + 56 + num2);
					goto IL_651;
					IL_6E8:
					num6 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num11 + 40 + num2);
					num16 = num6;
					IL_6F9:
					if (num16 != -1)
					{
						goto IL_710;
					}
					num11 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num11 + 56 + num2);
					goto IL_4AA;
					IL_710:
					num18 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num16 + 48 + num2);
					if (3 == num18)
					{
						goto IL_73B;
					}
					if (2 == num18)
					{
						goto IL_8A6;
					}
					num11 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num11 + 56 + num2);
					goto IL_4AA;
					IL_73B:
					num17 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num16 + 24 + num2);
					if (num17 == -1)
					{
						goto IL_787;
					}
					Type type2;
					if ((type2 = array3[num17]) != null)
					{
						goto IL_76F;
					}
					array3[num17] = Type.GetTypeFromHandle(array4[num17]);
					type2 = array3[num17];
					IL_76F:
					if (type2.IsInstanceOfType(ex))
					{
						goto IL_787;
					}
					num16 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num16 + num2);
					goto IL_6F9;
					IL_787:
					num26 = num16;
					num22 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num26 + 64 + num2) + 56 + num2);
					num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
					IL_7B0:
					if (num5 != num22)
					{
						goto IL_819;
					}
					int num29 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num26 + 40 + num2);
					ex3 = ex;
					array2 = new object[8];
					array2[5] = 0;
					array2[4] = array;
					array2[7] = ex;
					array2[0] = num7;
					array2[2] = num26;
					array2[3] = 0;
					array = array2;
					num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num26 + 40 + num2);
					goto IL_17;
					IL_819:
					num8 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num5 + 24 + num2);
					if (num8 == -1)
					{
						goto IL_894;
					}
					num29 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num8 + 40 + num2);
					array2 = new object[8];
					array2[5] = 0;
					array2[4] = array;
					array2[7] = ex;
					array2[0] = num7;
					array2[2] = num8;
					array2[1] = num26;
					array2[3] = 2;
					array = array2;
					num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num8 + 40 + num2);
					goto IL_17;
					IL_894:
					num5 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num5 + 56 + num2);
					goto IL_7B0;
					IL_8A6:
					num29 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num16 + 72 + num2);
					ex3 = ex;
					array2 = new object[8];
					array2[5] = 0;
					array2[4] = array;
					array2[7] = ex;
					array2[0] = num7;
					array2[2] = num16;
					array2[3] = 1;
					array = array2;
					num3 = *(ref NoCodeDownloadgetOrdinal.getRegisteredChannelsMemberPrimitiveTyped + num16 + 72 + num2);
					goto IL_17;
				}
				catch (Exception ex4)
				{
					int num10;
					if (num10 != 1)
					{
						Exception ex = ex4;
						int num23 = -1;
						goto IL_426;
					}
					throw ex4;
				}
			}, true);
			A_1 = 1;
		}

		// Token: 0x060006B5 RID: 1717 RVA: 0x00041888 File Offset: 0x0003FA88
		private static void ResourceManagerNotCreatingResourceSetMode(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			A_4.Dispose();
			A_1 = 34;
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x000418B0 File Offset: 0x0003FAB0
		private static void ServerCallbackOSX(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_0 = 48;
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x000418C8 File Offset: 0x0003FAC8
		private static void getTotalHoursgetMinimumLevel(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			A_4.Dispose();
			A_1 = 3;
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x000418F0 File Offset: 0x0003FAF0
		private static void PreferredBitTimeSpanRawInfo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 78;
			A_0 = num;
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x00041958 File Offset: 0x0003FB58
		public static void FixThisStupidBugOmg()
		{
			int num = 111;
			int num2 = 111;
			num2 = 111;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Tag.SetAccessControlUser[num]);
			}
			num2 = 111;
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x00041990 File Offset: 0x0003FB90
		private static void taskApplication(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			bool flag = true;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 9 + 83;
			A_0 = num;
		}

		// Token: 0x060006BB RID: 1723 RVA: 0x000419EC File Offset: 0x0003FBEC
		private static void mretValApplicationBasePath(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			float num = Vector3.Distance(A_5.bodyTransform.position, GTPlayer.Instance.bodyCollider.transform.position);
			A_9 = num;
			float num2 = 3.5f;
			A_10 = num2;
			bool flag = A_9 < A_10;
			A_11 = flag;
			int num3 = ((!A_11) ? 1 : 0) * 1 + 87;
			A_0 = num3;
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x00041AAC File Offset: 0x0003FCAC
		public unsafe static void AntiTag()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 75;
			int num4 = 75;
			num4 = 75;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num21;
				int num24;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 3)
					{
						num4 = 75;
						if ((int)array[1] != 0)
						{
							num5 = (int)array[2];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num5 + 16 + num2);
								num7 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + (int)array[4] + 16 + num2) + 8 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num7 + 24 + num2);
								if (num8 != -1)
								{
									num9 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num8 + 40 + num2);
									array[4] = num8;
									array[3] = 0;
									num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num8 + 40 + num2);
									goto IL_1A;
								}
								num7 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num7 + 8 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[5];
							num9 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num5 + 40 + num2);
							ex3 = ex2;
							array = (object[])array[6];
							array2 = new object[8];
							array2[1] = 1;
							array2[6] = array;
							array2[5] = ex2;
							array2[4] = num5;
							array2[3] = 1;
							array = array2;
							num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num5 + 40 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[7];
							array = (object[])array[6];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							bool flag3;
							float num14;
							float num15;
							bool flag4;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Boolean&,System.Single&,System.Single&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref flag3, ref num14, ref num15, ref flag4, Tag.SetAccessControlUser[num3]);
							continue;
						}
						num4 = 75;
						num8 = num13;
						num12 = num8;
					}
					num16 = num3;
					num6 = num16;
					num11 = 0;
					num17 = 2;
					for (;;)
					{
						num18 = (num11 + num17) / 2;
						num19 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num18 * 64 + 8 + num2);
						num20 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num18 * 64 + 48 + num2);
						if (num6 < num19 + num20)
						{
							if (num19 <= num6)
							{
								break;
							}
							num17 = num18 - 1;
						}
						else
						{
							num11 = num18 + 1;
						}
					}
					num7 = num18;
					num9 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num7 * 64 + 32 + num2);
					num21 = num9;
					num20 = num12;
					num19 = 0;
					num18 = 2;
					for (;;)
					{
						num17 = (num19 + num18) / 2;
						num11 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num17 * 64 + 8 + num2);
						num6 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num17 * 64 + 48 + num2);
						if (num20 < num11 + num6)
						{
							if (num11 <= num20)
							{
								break;
							}
							num18 = num17 - 1;
						}
						else
						{
							num19 = num17 + 1;
						}
					}
					num7 = num17;
					num8 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num7 * 64 + 32 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num17 = 2;
					for (;;)
					{
						num18 = (num11 + num17) / 2;
						num19 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num18 * 64 + 8 + num2);
						num20 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num18 * 64 + 48 + num2);
						if (num6 < num19 + num20)
						{
							if (num19 <= num6)
							{
								break;
							}
							num17 = num18 - 1;
						}
						else
						{
							num11 = num18 + 1;
						}
					}
					num7 = num18;
					num5 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num7 * 64 + 32 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A72:
						if (array == null || (int)array[1] == 0)
						{
							num6 = num9;
							while (num6 != num21)
							{
								if (num6 != -1)
								{
									num6 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num6 + 8 + num2);
								}
								else
								{
									num11 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 24 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num21 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 8 + num2);
									goto IL_A72;
								}
							}
							goto IL_C0C;
						}
						int num22 = (int)array[4];
						int num23;
						if (num21 == -1)
						{
							num23 = -1;
						}
						else
						{
							num24 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 32 + num2);
							num20 = 0;
							num19 = 2;
							for (;;)
							{
								num18 = (num20 + num19) / 2;
								num17 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num18 * 64 + 8 + num2);
								num11 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num18 * 64 + 48 + num2);
								if (num24 < num17 + num11)
								{
									if (num17 <= num24)
									{
										break;
									}
									num19 = num18 - 1;
								}
								else
								{
									num20 = num18 + 1;
								}
							}
							num5 = num18;
							num7 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num5 * 64 + 32 + num2);
							num23 = num7;
						}
						if (num22 == num23)
						{
							num7 = num9;
							while (num7 != num21)
							{
								if (num7 != -1)
								{
									num7 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num7 + 8 + num2);
								}
								else
								{
									num5 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 24 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num21 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 8 + num2);
									goto IL_A72;
								}
							}
							break;
						}
						if ((int)array[4] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[6];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num5 + 40 + num2);
					array2 = new object[]
					{
						default(object),
						0,
						default(object),
						default(object),
						default(object),
						default(object),
						array,
						num12
					};
					array2[4] = num5;
					array2[3] = 0;
					array = array2;
					num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num5 + 40 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C0C:
					num3 = num12;
					continue;
					Block_62:
					num17 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num11 + 40 + num2);
					array2 = new object[]
					{
						default(object),
						0,
						default(object),
						default(object),
						default(object),
						default(object),
						array,
						num12
					};
					array2[4] = num11;
					array2[3] = 0;
					array = array2;
					num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num11 + 40 + num2);
				}
				num4 = 75;
				return;
				IL_1D3:
				if (num17 != -1)
				{
					goto IL_1DE;
				}
				goto IL_403;
				IL_1DE:
				num6 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num17 + 72 + num2);
				if (0 == num6)
				{
					goto IL_1FD;
				}
				if (4 == num6)
				{
					goto IL_38A;
				}
				goto IL_403;
				IL_1FD:
				num11 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num17 + 48 + num2);
				if (num11 == -1)
				{
					goto IL_248;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_231;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_231:
				if (type.IsInstanceOfType(array2[5]))
				{
					goto IL_248;
				}
				num17 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num17 + num2);
				goto IL_1D3;
				IL_248:
				num21 = num17;
				num16 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 16 + num2) + 8 + num2);
				num7 = (int)array2[0];
				IL_26B:
				if (num7 != num16)
				{
					goto IL_2EA;
				}
				num18 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 40 + num2);
				ex3 = array2[5];
				array = (object[])array[6];
				object[] array5 = new object[8];
				array5[1] = 1;
				array5[6] = array;
				array5[5] = array2[5];
				array5[0] = (int)array2[0];
				array5[4] = num21;
				array5[3] = 1;
				array = array5;
				num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 40 + num2);
				goto IL_1A;
				IL_2EA:
				num9 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num7 + 24 + num2);
				if (num9 == -1)
				{
					goto IL_379;
				}
				num18 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num9 + 40 + num2);
				array = (object[])array[6];
				array5 = new object[8];
				array5[1] = 1;
				array5[6] = array;
				array5[5] = array2[5];
				array5[0] = (int)array2[0];
				array5[4] = num9;
				array5[2] = num21;
				array5[3] = 0;
				array = array5;
				num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num9 + 40 + num2);
				goto IL_1A;
				IL_379:
				num7 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num7 + 8 + num2);
				goto IL_26B;
				IL_38A:
				num18 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num17 + 56 + num2);
				ex3 = array2[5];
				array = (object[])array[6];
				array5 = new object[8];
				array5[1] = 1;
				array5[6] = array;
				array5[5] = array2[5];
				array5[0] = (int)array2[0];
				array5[4] = num17;
				array5[3] = 2;
				array = array5;
				num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num17 + 56 + num2);
				goto IL_1A;
				IL_403:
				array = (object[])array[6];
				ex = array2[5];
				int num25 = (int)array2[0];
				IL_422:
				num17 = num3;
				num18 = num17;
				num19 = 0;
				num20 = 2;
				IL_430:
				num8 = (num19 + num20) / 2;
				num5 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num8 * 64 + 8 + num2);
				num24 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num8 * 64 + 48 + num2);
				if (num18 >= num5 + num24)
				{
					goto IL_475;
				}
				if (num5 > num18)
				{
					goto IL_47D;
				}
				num16 = num8;
				num21 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 152 + num16 * 64 + 32 + num2);
				num11 = num21;
				num7 = num11;
				goto IL_4A5;
				IL_475:
				num19 = num8 + 1;
				goto IL_430;
				IL_47D:
				num20 = num8 - 1;
				goto IL_430;
				IL_4A5:
				if (array != null)
				{
					goto IL_4B0;
				}
				goto IL_63D;
				IL_4B0:
				if ((int)array[1] != 0)
				{
					goto IL_56F;
				}
				int num26 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_4D4;
				}
				int num27 = -1;
				goto IL_556;
				IL_4D4:
				int num28 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num11 + 32 + num2);
				num24 = 0;
				num5 = 2;
				IL_4E7:
				num8 = (num24 + num5) / 2;
				num20 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num8 * 64 + 8 + num2);
				num19 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num8 * 64 + 48 + num2);
				if (num28 >= num20 + num19)
				{
					goto IL_52C;
				}
				if (num20 > num28)
				{
					goto IL_534;
				}
				num21 = num8;
				num16 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num21 * 64 + 32 + num2);
				num27 = num16;
				goto IL_556;
				IL_52C:
				num24 = num8 + 1;
				goto IL_4E7;
				IL_534:
				num5 = num8 - 1;
				goto IL_4E7;
				IL_556:
				if (num26 != num27)
				{
					goto IL_55E;
				}
				goto IL_63D;
				IL_55E:
				array = (object[])array[6];
				goto IL_4A5;
				IL_56F:
				num9 = (int)array[3];
				if (num9 == 1 || num9 == 0)
				{
					goto IL_590;
				}
				if (num9 != 2)
				{
					goto IL_58F;
				}
				array2 = array;
				num17 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + (int)array2[4] + num2);
				goto IL_1D3;
				IL_58F:
				IL_590:
				int num29 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_5A5;
				}
				int num30 = -1;
				goto IL_627;
				IL_5A5:
				num18 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num11 + 32 + num2);
				num19 = 0;
				num20 = 2;
				IL_5B8:
				num8 = (num19 + num20) / 2;
				num5 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num8 * 64 + 8 + num2);
				num24 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num8 * 64 + 48 + num2);
				if (num18 >= num5 + num24)
				{
					goto IL_5FD;
				}
				if (num5 > num18)
				{
					goto IL_605;
				}
				num16 = num8;
				num21 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + 344 + num16 * 64 + 32 + num2);
				num30 = num21;
				goto IL_627;
				IL_5FD:
				num19 = num8 + 1;
				goto IL_5B8;
				IL_605:
				num20 = num8 - 1;
				goto IL_5B8;
				IL_627:
				if (num29 != num30)
				{
					goto IL_62C;
				}
				goto IL_63D;
				IL_62C:
				array = (object[])array[6];
				goto IL_4A5;
				IL_63D:
				if (-1 != num11)
				{
					goto IL_6E0;
				}
				num21 = num7;
				IL_64A:
				if (num21 != -1)
				{
					goto IL_656;
				}
				num10 = 1;
				throw ex;
				IL_656:
				num16 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 24 + num2);
				if (num16 == -1)
				{
					goto IL_6CF;
				}
				num28 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num16 + 40 + num2);
				array2 = new object[8];
				array2[1] = 1;
				array2[6] = array;
				array2[5] = ex;
				array2[0] = num7;
				array2[4] = -1;
				array2[2] = -1;
				array2[3] = 1;
				array = array2;
				num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num16 + 40 + num2);
				goto IL_1A;
				IL_6CF:
				num21 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num21 + 8 + num2);
				goto IL_64A;
				IL_6E0:
				num6 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num11 + 40 + num2);
				num18 = num6;
				IL_6F1:
				if (num18 != -1)
				{
					goto IL_707;
				}
				num11 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num11 + 8 + num2);
				goto IL_4A5;
				IL_707:
				num20 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num18 + 72 + num2);
				if (0 == num20)
				{
					goto IL_731;
				}
				if (4 == num20)
				{
					goto IL_89A;
				}
				num11 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num11 + 8 + num2);
				goto IL_4A5;
				IL_731:
				num19 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num18 + 48 + num2);
				if (num19 == -1)
				{
					goto IL_77D;
				}
				Type type2;
				if ((type2 = array3[num19]) != null)
				{
					goto IL_765;
				}
				array3[num19] = Type.GetTypeFromHandle(array4[num19]);
				type2 = array3[num19];
				IL_765:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_77D;
				}
				num18 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num18 + num2);
				goto IL_6F1;
				IL_77D:
				num28 = num18;
				num24 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num28 + 16 + num2) + 8 + num2);
				num5 = (num7 - num25) * ((num25 == -1) ? 1 : 0) + num25;
				IL_7A5:
				if (num5 != num24)
				{
					goto IL_80E;
				}
				int num31 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num28 + 40 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[1] = 1;
				array2[6] = array;
				array2[5] = ex;
				array2[0] = num7;
				array2[4] = num28;
				array2[3] = 1;
				array = array2;
				num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num28 + 40 + num2);
				goto IL_1A;
				IL_80E:
				num8 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num5 + 24 + num2);
				if (num8 == -1)
				{
					goto IL_889;
				}
				num31 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num8 + 40 + num2);
				array2 = new object[8];
				array2[1] = 1;
				array2[6] = array;
				array2[5] = ex;
				array2[0] = num7;
				array2[4] = num8;
				array2[2] = num28;
				array2[3] = 0;
				array = array2;
				num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num8 + 40 + num2);
				goto IL_1A;
				IL_889:
				num5 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num5 + 8 + num2);
				goto IL_7A5;
				IL_89A:
				num31 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num18 + 56 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[1] = 1;
				array2[6] = array;
				array2[5] = ex;
				array2[0] = num7;
				array2[4] = num18;
				array2[3] = 2;
				array = array2;
				num3 = *(ref ProgIdRedirectionEntrydwReserved.AsAnyMarshalerBitArray + num18 + 56 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num25 = -1;
					goto IL_422;
				}
				throw ex4;
			}
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x0004277C File Offset: 0x0004097C
		private static void SEPDateOrOffsetInstances(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060006BE RID: 1726 RVA: 0x00042794 File Offset: 0x00040994
		private static void AuthenticatedCBC(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -15 + 49;
			A_0 = num;
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x000427DC File Offset: 0x000409DC
		private static void msystemTimeZonesMethodBuilderInstantiation(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 10 + 37;
			A_0 = num;
		}

		// Token: 0x060006C0 RID: 1728 RVA: 0x00042838 File Offset: 0x00040A38
		private static void TypeLibraryOpenRead(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			int num = (A_10.MoveNext() ? 1 : 0) * -11 + 29;
			A_0 = num;
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x00042880 File Offset: 0x00040A80
		private static void GetTypeInfoCountCreated(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			int num = ((A_8 < A_7.Length) ? 1 : 0) * -4 + 105;
			A_0 = num;
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x000428BC File Offset: 0x00040ABC
		private static void MinEventLogClassic(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -15 + 49;
			A_0 = num;
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x00042904 File Offset: 0x00040B04
		private static void ContinueWithWhenAny(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x0004292C File Offset: 0x00040B2C
		private static void DynamicPartitionerForArrayNotSerialized(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			GorillaTagManager[] array = Object.FindObjectsOfType<GorillaTagManager>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 106;
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x00042974 File Offset: 0x00040B74
		private static void DTTWriteTo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			bool flag = !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It");
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 4 + 86;
			A_0 = num;
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x000429FC File Offset: 0x00040BFC
		private static void ContractFailedEventArgsForkJoin(ref int A_0, ref int A_1, ref int A_2)
		{
			Tag.datdwe = "do the thing :D";
			A_1 = 0;
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x00042A20 File Offset: 0x00040C20
		private static void grfModeSetObjectUriForMarshal(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -11 + 14;
			A_0 = num;
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x00042A68 File Offset: 0x00040C68
		private static void getIsExplicitLayoutAccountDomainSid(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			bool flag = true;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 5 + 63;
			A_0 = num;
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x00042AC4 File Offset: 0x00040CC4
		private static void IsolatedStorageFileBleS(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			A_1 = 0;
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x00042ADC File Offset: 0x00040CDC
		private static void reservedUndock(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			int num = (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") ? 1 : 0) * 1 + 61;
			A_0 = num;
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x00042B3C File Offset: 0x00040D3C
		private static void GetHINSTANCEcollection(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			int num = ((!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected")) ? 1 : 0) * 1 + 84;
			A_0 = num;
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x00042B9C File Offset: 0x00040D9C
		private static void SiteMembershipConditionUTFEncodingSealed(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			A_0 = 28;
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x00042BB4 File Offset: 0x00040DB4
		private static void getDayOfYearHexadecimal(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			bool flag = true;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 9 + 60;
			A_0 = num;
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x00042C10 File Offset: 0x00040E10
		private static void CrossContextChannelTrademark(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -11 + 14;
			A_0 = num;
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x00042C58 File Offset: 0x00040E58
		private static void RSAPKCSSignatureDescriptionAddressOfMember(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			Main.GetIndex("Tag All").enabled = false;
			Main.RecreateMenu();
			int num = (A_10.MoveNext() ? 1 : 0) * -11 + 29;
			A_0 = num;
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x00042CBC File Offset: 0x00040EBC
		private static void SHACryptoServiceProviderSzArray(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 2;
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x00042CF8 File Offset: 0x00040EF8
		private static void GuidPropertySetDMNd(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			GorillaTagManager gorillaTagManager = A_4[A_5];
			A_6 = gorillaTagManager;
			Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
			A_7 = playerListOthers;
			int num = 0;
			A_8 = num;
			A_0 = 104;
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x00042D64 File Offset: 0x00040F64
		public static void MatGun()
		{
			int num = 109;
			int num2 = 109;
			num2 = 109;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Tag.SetAccessControlUser[num]);
			}
			num2 = 109;
		}

		// Token: 0x060006D3 RID: 1747 RVA: 0x00042D9C File Offset: 0x00040F9C
		public unsafe static void TagAll()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 1;
			int num4 = 1;
			num4 = 1;
			try
			{
				IL_17:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 34)
					{
						num4 = 1;
						if ((int)array[6] != 1)
						{
							num5 = (int)array[3];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num5 + 64 + num2);
								num7 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + (int)array[1] + 64 + num2) + 56 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num7 + 8 + num2);
								if (num8 != -1)
								{
									num9 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num8 + 24 + num2);
									array[1] = num8;
									array[2] = 2;
									num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num8 + 24 + num2);
									goto IL_17;
								}
								num7 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num7 + 56 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[5];
							num9 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num5 + 24 + num2);
							ex3 = ex2;
							array = (object[])array[4];
							array2 = new object[8];
							array2[6] = 0;
							array2[4] = array;
							array2[5] = ex2;
							array2[1] = num5;
							array2[2] = 0;
							array = array2;
							num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num5 + 24 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[0];
							array = (object[])array[4];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 36)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							bool flag3;
							Vector3 vector;
							List<VRRig>.Enumerator enumerator2;
							VRRig vrrig2;
							bool flag4;
							bool flag5;
							bool flag6;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Boolean&,UnityEngine.Vector3&,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref flag3, ref vector, ref enumerator2, ref vrrig2, ref flag4, ref flag5, ref flag6, Tag.SetAccessControlUser[num3]);
							continue;
						}
						num4 = 1;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 4;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num16 * 48 + 32 + num2);
						num18 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num16 * 48 + 24 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num7 * 48 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 4;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num15 * 48 + 32 + num2);
						num6 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num15 * 48 + 24 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num7 * 48 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 4;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num16 * 48 + 32 + num2);
						num18 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num16 * 48 + 24 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num7 * 48 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A76:
						if (array == null || (int)array[6] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num6 + 56 + num2);
								}
								else
								{
									num11 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 8 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 56 + num2);
									goto IL_A76;
								}
							}
							goto IL_C10;
						}
						int num20 = (int)array[1];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 24 + num2);
							num18 = 0;
							num17 = 4;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num16 * 48 + 32 + num2);
								num11 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num16 * 48 + 24 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num5 * 48 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num7 + 56 + num2);
								}
								else
								{
									num5 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 8 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 56 + num2);
									goto IL_A76;
								}
							}
							break;
						}
						if ((int)array[1] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[4];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num5 + 24 + num2);
					array2 = new object[8];
					array2[6] = 1;
					array2[4] = array;
					array2[0] = num12;
					array2[1] = num5;
					array2[2] = 2;
					array = array2;
					num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num5 + 24 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C10:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num11 + 24 + num2);
					array2 = new object[8];
					array2[6] = 1;
					array2[4] = array;
					array2[0] = num12;
					array2[1] = num11;
					array2[2] = 2;
					array = array2;
					num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num11 + 24 + num2);
				}
				num4 = 1;
				return;
				IL_1D9:
				if (num15 != -1)
				{
					goto IL_1E4;
				}
				goto IL_40D;
				IL_1E4:
				num6 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num15 + 48 + num2);
				if (3 == num6)
				{
					goto IL_203;
				}
				if (2 == num6)
				{
					goto IL_394;
				}
				goto IL_40D;
				IL_203:
				num11 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num15 + 16 + num2);
				if (num11 == -1)
				{
					goto IL_251;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_237;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_237:
				if (type.IsInstanceOfType(array2[5]))
				{
					goto IL_251;
				}
				num15 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num15 + 80 + num2);
				goto IL_1D9;
				IL_251:
				num19 = num15;
				num14 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 64 + num2) + 56 + num2);
				num7 = (int)array2[7];
				IL_275:
				if (num7 != num14)
				{
					goto IL_2F4;
				}
				num16 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 24 + num2);
				ex3 = array2[5];
				array = (object[])array[4];
				object[] array5 = new object[8];
				array5[6] = 0;
				array5[4] = array;
				array5[5] = array2[5];
				array5[7] = (int)array2[7];
				array5[1] = num19;
				array5[2] = 0;
				array = array5;
				num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 24 + num2);
				goto IL_17;
				IL_2F4:
				num9 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num7 + 8 + num2);
				if (num9 == -1)
				{
					goto IL_382;
				}
				num16 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num9 + 24 + num2);
				array = (object[])array[4];
				array5 = new object[8];
				array5[6] = 0;
				array5[4] = array;
				array5[5] = array2[5];
				array5[7] = (int)array2[7];
				array5[1] = num9;
				array5[3] = num19;
				array5[2] = 2;
				array = array5;
				num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num9 + 24 + num2);
				goto IL_17;
				IL_382:
				num7 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num7 + 56 + num2);
				goto IL_275;
				IL_394:
				num16 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num15 + 56 + num2);
				ex3 = array2[5];
				array = (object[])array[4];
				array5 = new object[8];
				array5[6] = 0;
				array5[4] = array;
				array5[5] = array2[5];
				array5[7] = (int)array2[7];
				array5[1] = num15;
				array5[2] = 1;
				array = array5;
				num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num15 + 56 + num2);
				goto IL_17;
				IL_40D:
				array = (object[])array[4];
				ex = array2[5];
				int num23 = (int)array2[7];
				IL_42C:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 4;
				IL_43A:
				num8 = (num17 + num18) / 2;
				num5 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num8 * 48 + 32 + num2);
				num22 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num8 * 48 + 24 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_480;
				}
				if (num5 > num16)
				{
					goto IL_488;
				}
				num14 = num8;
				num19 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 336 + num14 * 48 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4AD;
				IL_480:
				num17 = num8 + 1;
				goto IL_43A;
				IL_488:
				num18 = num8 - 1;
				goto IL_43A;
				IL_4AD:
				if (array != null)
				{
					goto IL_4B8;
				}
				goto IL_641;
				IL_4B8:
				if ((int)array[6] != 1)
				{
					goto IL_575;
				}
				int num24 = (int)array[1];
				if (num11 != -1)
				{
					goto IL_4DC;
				}
				int num25 = -1;
				goto IL_55C;
				IL_4DC:
				int num26 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num11 + 24 + num2);
				num22 = 0;
				num5 = 4;
				IL_4EF:
				num8 = (num22 + num5) / 2;
				num18 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num8 * 48 + 32 + num2);
				num17 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num8 * 48 + 24 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_535;
				}
				if (num18 > num26)
				{
					goto IL_53D;
				}
				num19 = num8;
				num14 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num19 * 48 + num2);
				num25 = num14;
				goto IL_55C;
				IL_535:
				num22 = num8 + 1;
				goto IL_4EF;
				IL_53D:
				num5 = num8 - 1;
				goto IL_4EF;
				IL_55C:
				if (num24 != num25)
				{
					goto IL_564;
				}
				goto IL_641;
				IL_564:
				array = (object[])array[4];
				goto IL_4AD;
				IL_575:
				num9 = (int)array[2];
				if (num9 == 0 || num9 == 2)
				{
					goto IL_596;
				}
				if (num9 != 1)
				{
					goto IL_595;
				}
				array2 = array;
				num15 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + (int)array2[1] + 80 + num2);
				goto IL_1D9;
				IL_595:
				IL_596:
				int num27 = (int)array[1];
				if (num11 != -1)
				{
					goto IL_5AB;
				}
				int num28 = -1;
				goto IL_62B;
				IL_5AB:
				num16 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num11 + 24 + num2);
				num17 = 0;
				num18 = 4;
				IL_5BE:
				num8 = (num17 + num18) / 2;
				num5 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num8 * 48 + 32 + num2);
				num22 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num8 * 48 + 24 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_604;
				}
				if (num5 > num16)
				{
					goto IL_60C;
				}
				num14 = num8;
				num19 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + 576 + num14 * 48 + num2);
				num28 = num19;
				goto IL_62B;
				IL_604:
				num17 = num8 + 1;
				goto IL_5BE;
				IL_60C:
				num18 = num8 - 1;
				goto IL_5BE;
				IL_62B:
				if (num27 != num28)
				{
					goto IL_630;
				}
				goto IL_641;
				IL_630:
				array = (object[])array[4];
				goto IL_4AD;
				IL_641:
				if (-1 != num11)
				{
					goto IL_6E4;
				}
				num19 = num7;
				IL_64E:
				if (num19 != -1)
				{
					goto IL_65A;
				}
				num10 = 1;
				throw ex;
				IL_65A:
				num14 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 8 + num2);
				if (num14 == -1)
				{
					goto IL_6D2;
				}
				num26 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num14 + 24 + num2);
				array2 = new object[8];
				array2[6] = 0;
				array2[4] = array;
				array2[5] = ex;
				array2[7] = num7;
				array2[1] = -1;
				array2[3] = -1;
				array2[2] = 0;
				array = array2;
				num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num14 + 24 + num2);
				goto IL_17;
				IL_6D2:
				num19 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num19 + 56 + num2);
				goto IL_64E;
				IL_6E4:
				num6 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num11 + 40 + num2);
				num16 = num6;
				IL_6F5:
				if (num16 != -1)
				{
					goto IL_70C;
				}
				num11 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num11 + 56 + num2);
				goto IL_4AD;
				IL_70C:
				num18 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num16 + 48 + num2);
				if (3 == num18)
				{
					goto IL_737;
				}
				if (2 == num18)
				{
					goto IL_8A4;
				}
				num11 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num11 + 56 + num2);
				goto IL_4AD;
				IL_737:
				num17 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num16 + 16 + num2);
				if (num17 == -1)
				{
					goto IL_786;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_76B;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_76B:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_786;
				}
				num16 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num16 + 80 + num2);
				goto IL_6F5;
				IL_786:
				num26 = num16;
				num22 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num26 + 64 + num2) + 56 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7AF:
				if (num5 != num22)
				{
					goto IL_818;
				}
				int num29 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num26 + 24 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[6] = 0;
				array2[4] = array;
				array2[5] = ex;
				array2[7] = num7;
				array2[1] = num26;
				array2[2] = 0;
				array = array2;
				num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num26 + 24 + num2);
				goto IL_17;
				IL_818:
				num8 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num5 + 8 + num2);
				if (num8 == -1)
				{
					goto IL_892;
				}
				num29 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num8 + 24 + num2);
				array2 = new object[8];
				array2[6] = 0;
				array2[4] = array;
				array2[5] = ex;
				array2[7] = num7;
				array2[1] = num8;
				array2[3] = num26;
				array2[2] = 2;
				array = array2;
				num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num8 + 24 + num2);
				goto IL_17;
				IL_892:
				num5 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num5 + 56 + num2);
				goto IL_7AF;
				IL_8A4:
				num29 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num16 + 56 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[6] = 0;
				array2[4] = array;
				array2[5] = ex;
				array2[7] = num7;
				array2[1] = num16;
				array2[2] = 1;
				array = array2;
				num3 = *(ref getResourceExposureLevelRegistryOptions.HResultExceptionMarshalerRSACspObject + num16 + 56 + num2);
				goto IL_17;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_42C;
				}
				throw ex4;
			}
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x00043A70 File Offset: 0x00041C70
		private static void MonitoringSurvivedProcessMemorySizeLocalPush(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 4;
			A_0 = num;
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x00043AD8 File Offset: 0x00041CD8
		private static void PrivateBinPathProbeValueWaitDelegate(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -7 + 107;
			A_0 = num;
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x00043B14 File Offset: 0x00041D14
		private static void IsGenericParameterThreadTransferReceiveObj(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			bool flag = false;
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 6 + 21;
			A_0 = num;
		}

		// Token: 0x060006D7 RID: 1751 RVA: 0x00043B70 File Offset: 0x00041D70
		private static void ParameterAttributesHasFieldRVA(ref int A_0, ref int A_1, ref int A_2)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			A_1 = 0;
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x00043BA0 File Offset: 0x00041DA0
		private static void SoapAttributeValueType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			GTPlayer.Instance.rightControllerTransform.position = A_11.transform.position;
			A_0 = 25;
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x00043BDC File Offset: 0x00041DDC
		private static void IEnumDefinitionIdentityEmbedded(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			GorillaTagger.Instance.offlineVRRig.transform.position = A_5.rightHandTransform.position;
			A_0 = 45;
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x00043C34 File Offset: 0x00041E34
		private static void ViewAclgetSpecialKey(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = true;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 43;
			A_0 = num;
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x00043C90 File Offset: 0x00041E90
		private static void AngleDTDSubset(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 72;
			A_0 = num;
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x00043CD8 File Offset: 0x00041ED8
		private static void TypesWhenNeededsetKeySize(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = ((!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected")) ? 1 : 0) * 1 + 41;
			A_0 = num;
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x00043D38 File Offset: 0x00041F38
		private static void setExternalThreadingSetOnCountdownMres(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 53;
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x00043D74 File Offset: 0x00041F74
		private static void SystemAlarmCallbacksetUri(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			bool flag = !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 5 + 63;
			A_0 = num;
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x00043DFC File Offset: 0x00041FFC
		private static void setVersionSecurityPermissionFlag(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 95;
			A_0 = num;
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x00043E44 File Offset: 0x00042044
		private static void removeProcessExitMessageData(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			bool flag = true;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 4 + 86;
			A_0 = num;
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x00043EA0 File Offset: 0x000420A0
		private static void GetSerialNumberDateTimeToken(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			float num = Vector3.Distance(A_5.bodyTransform.position, GTPlayer.Instance.bodyCollider.transform.position);
			A_10 = num;
			float num2 = 3.5f;
			A_11 = num2;
			bool flag = A_10 < A_11;
			A_12 = flag;
			int num3 = ((!A_12) ? 1 : 0) * 1 + 65;
			A_0 = num3;
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x00043F60 File Offset: 0x00042160
		private static void SmuggledMethodCallMessageCalendarId(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			A_0 = 91;
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x00043F78 File Offset: 0x00042178
		private static void VTBLOBgetCurrentSize(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 95;
			A_0 = num;
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x00043FC0 File Offset: 0x000421C0
		private static void GREGORIANXLITENGLISHgetNextActivator(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			Main.GetIndex("Anti Tag").enabled = false;
			Main.RecreateMenu();
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 95;
			A_0 = num;
		}

		// Token: 0x060006E5 RID: 1765 RVA: 0x0004403C File Offset: 0x0004223C
		private static void getDeviceClaimsdSuppressMessageAttribute(ref int A_0, ref int A_1, ref int A_2, Tag A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x00044060 File Offset: 0x00042260
		private static void DefaultInterfaceMinute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			int num = (A_5.mainSkin.material.name.Contains("fected") ? 1 : 0) * 1 + 81;
			A_0 = num;
		}

		// Token: 0x060006E7 RID: 1767 RVA: 0x000440C0 File Offset: 0x000422C0
		private static void getInfrastructureAreAccessRulesCanonical(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			VRRig vrrig = A_10.Current;
			A_11 = vrrig;
			int num = (A_11.isOfflineVRRig ? 1 : 0) * 1 + 19;
			A_0 = num;
		}

		// Token: 0x060006E8 RID: 1768 RVA: 0x00044128 File Offset: 0x00042328
		private static void SynchronizedClientContextSinkTimeZoneKeyName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 72;
			A_0 = num;
		}

		// Token: 0x060006E9 RID: 1769 RVA: 0x00044170 File Offset: 0x00042370
		private static void NullReferenceExceptionSetApartmentState(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -11 + 14;
			A_0 = num;
		}

		// Token: 0x060006EA RID: 1770 RVA: 0x000441B8 File Offset: 0x000423B8
		private static void FeedbackSizereserved(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 72;
			A_0 = num;
		}

		// Token: 0x060006EB RID: 1771 RVA: 0x00044200 File Offset: 0x00042400
		private static void StrongNameHelpersGenericTypeParameters(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 35;
			A_0 = num;
		}

		// Token: 0x060006EC RID: 1772 RVA: 0x00044268 File Offset: 0x00042468
		private static void JavaMaxChunkSize(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_5.mainSkin.material.name.Contains("fected") ? 1 : 0) * 1 + 38;
			A_0 = num;
		}

		// Token: 0x060006ED RID: 1773 RVA: 0x000442C8 File Offset: 0x000424C8
		private static void CLRSurrogateEntryTimeZoneKeyName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			GTPlayer.Instance.rightControllerTransform.position = A_5.bodyTransform.position;
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 72;
			A_0 = num;
		}

		// Token: 0x060006EE RID: 1774 RVA: 0x00044338 File Offset: 0x00042538
		private static void JAPANBootstrapConext(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			A_0 = 13;
		}

		// Token: 0x060006EF RID: 1775 RVA: 0x00044350 File Offset: 0x00042550
		private static void LinkedSlotManifestError(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			Tag.splashtimeout = Time.time;
			A_6.currentInfected.Add(A_9);
			A_6.currentInfected.Remove(A_9);
			Main.RPCProtection();
			int num = A_8 + 1;
			A_8 = num;
			int num2 = ((A_8 < A_7.Length) ? 1 : 0) * -4 + 105;
			A_0 = num2;
		}

		// Token: 0x060006F0 RID: 1776 RVA: 0x00044404 File Offset: 0x00042604
		public Tag()
		{
			int num = 112;
			int num2 = 112;
			num2 = 112;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.Tag), ref num, ref num2, ref num3, this, Tag.SetAccessControlUser[num]);
			}
			num2 = 112;
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x0004443C File Offset: 0x0004263C
		private static void IWinRTClassActivatorgetChannelUris(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = true;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 6 + 40;
			A_0 = num;
		}

		// Token: 0x060006F2 RID: 1778 RVA: 0x00044498 File Offset: 0x00042698
		private static void TypeNameFormatFlagsUserQuota(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 6 + 6;
			A_0 = num;
		}

		// Token: 0x060006F3 RID: 1779 RVA: 0x000444F4 File Offset: 0x000426F4
		private static void BUILDNUMBERStandard(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 55;
			A_0 = num;
		}

		// Token: 0x060006F4 RID: 1780 RVA: 0x0004455C File Offset: 0x0004275C
		private static void CultureNameResourceSetPairParsedMonthName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -11 + 14;
			A_0 = num;
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x000445A4 File Offset: 0x000427A4
		private static void ClassTypeAssemblyTrademarkAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			Main.GetIndex("Tag Self").enabled = false;
			Main.RecreateMenu();
			int num = (A_4.MoveNext() ? 1 : 0) * -15 + 49;
			A_0 = num;
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x00044620 File Offset: 0x00042820
		private static void IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSidldescType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 13 + 80;
			A_0 = num;
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x00044690 File Offset: 0x00042890
		private static void ThisCallScopeTree(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 13 + 57;
			A_0 = num;
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x000446EC File Offset: 0x000428EC
		private static void fullPathSparseFile(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("It");
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 9 + 60;
			A_0 = num;
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x00044770 File Offset: 0x00042970
		private static void MVarIsLittleEndian(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			bool flag = GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 8;
			A_0 = num;
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x000447EC File Offset: 0x000429EC
		private static void ResolveTypeKeepAlive(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue);
			A_0 = 89;
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x00044844 File Offset: 0x00042A44
		private static void getIsReadygetNoAsyncCurrentCulture(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			A_1 = 3;
			A_2 = 74;
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x00044868 File Offset: 0x00042A68
		private static void SelectMethodDisableEvent(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			Vector3 vector = A_5.transform.position - new Vector3(0f, 3f, 0f);
			A_9 = vector;
			GorillaTagger.Instance.offlineVRRig.transform.position = A_9;
			GTPlayer.Instance.rightControllerTransform.position = A_5.transform.position;
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			A_0 = 10;
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x0004492C File Offset: 0x00042B2C
		public static void MatAll()
		{
			int num = 98;
			int num2 = 98;
			num2 = 98;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaTagManager[] array;
				int num4;
				GorillaTagManager gorillaTagManager;
				Player[] array2;
				int num5;
				Player player;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaTagManager[]&,System.Int32&,GorillaTagManager&,Photon.Realtime.Player[]&,System.Int32&,Photon.Realtime.Player&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaTagManager, ref array2, ref num5, ref player, ref flag2, Tag.SetAccessControlUser[num]);
			}
			num2 = 98;
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x00044974 File Offset: 0x00042B74
		private static void NotFiniteNumberExceptionPopDirectionIsolate(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 95;
			A_0 = num;
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x000449BC File Offset: 0x00042BBC
		private static void PtrToStringBSTRWrapNonExceptionThrows(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			A_0 = 91;
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x000449EC File Offset: 0x00042BEC
		private static void getMemberCountWinCE(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			A_1 = 0;
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x00044A04 File Offset: 0x00042C04
		private static void IsCompatibilityBehaviorDefinedLPStruct(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_4.Dispose();
			A_1 = 1;
		}

		// Token: 0x06000702 RID: 1794 RVA: 0x00044A2C File Offset: 0x00042C2C
		private static void FromIdPercentSymbol(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			A_1 = 0;
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x00044A44 File Offset: 0x00042C44
		private static void PageUpgetLoadFrom(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			bool flag = GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It");
			A_14 = flag;
			int num = ((!A_14) ? 1 : 0) * 1 + 23;
			A_0 = num;
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x00044AC0 File Offset: 0x00042CC0
		private static void getEventProviderRuntimeFieldHandle(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			bool flag = !A_11.mainSkin.material.name.Contains("It");
			A_13 = flag;
			int num = ((!A_13) ? 1 : 0) * 4 + 22;
			A_0 = num;
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x00044B40 File Offset: 0x00042D40
		private static void ProxySidMuiResourceTypeIdIntIntegerIds(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			bool flag = A_5.mainSkin.material.name.Contains("It");
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 9 + 83;
			A_0 = num;
		}

		// Token: 0x06000706 RID: 1798 RVA: 0x00044BC0 File Offset: 0x00042DC0
		private static void MidpointRoundingGetEnumUnderlyingType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -15 + 49;
			A_0 = num;
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x00044C08 File Offset: 0x00042E08
		private static void InfoSoapIsTransient(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 32;
				int num2 = 32;
				num2 = 32;
				while (num2 != 0)
				{
					int num3;
					VRRig vrrig;
					int num4;
					Player player;
					bool flag;
					GorillaTagManager[] array;
					int num5;
					GorillaTagManager gorillaTagManager;
					bool flag2;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,VRRig&,System.Int32&,Photon.Realtime.Player&,System.Boolean&,GorillaTagManager[]&,System.Int32&,GorillaTagManager&,System.Boolean&), ref num, ref num2, ref num3, ref vrrig, ref num4, ref player, ref flag, ref array, ref num5, ref gorillaTagManager, ref flag2, Tag.<>c.WindowsSubAuthorityCMSASSEMBLYDEPLOYMENTFLAGDISALLOWURLACTIVATION[num]);
				}
				num2 = 32;
			}, true);
			A_1 = 0;
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x00044C50 File Offset: 0x00042E50
		private static void CreateComInstanceFromEventTags(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			Player player = A_7[A_8];
			A_9 = player;
			bool flag = Time.time > Tag.splashtimeout + 0.3f;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 1 + 102;
			A_0 = num;
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x00044CE0 File Offset: 0x00042EE0
		private static void NDataUTFEncoding(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 72;
			A_0 = num;
		}

		// Token: 0x0600070A RID: 1802 RVA: 0x00044D2C File Offset: 0x00042F2C
		private static void getBuildNumberUnknownWrapper(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			int num = (A_10.MoveNext() ? 1 : 0) * -11 + 29;
			A_0 = num;
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x00044D74 File Offset: 0x00042F74
		private static void GetXsdTypesetIdentityObject(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = A_5.mainSkin.material.name.Contains("It");
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 6 + 40;
			A_0 = num;
		}

		// Token: 0x0600070C RID: 1804 RVA: 0x00044DF4 File Offset: 0x00042FF4
		public static void IDGun()
		{
			int num = 110;
			int num2 = 110;
			num2 = 110;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Tag.SetAccessControlUser[num]);
			}
			num2 = 110;
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x00044E2C File Offset: 0x0004302C
		private static void GetSignatureFileIOPermissionAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			bool flag = !A_11.isMyPlayer;
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 6 + 21;
			A_0 = num;
		}

		// Token: 0x0600070E RID: 1806 RVA: 0x00044E9C File Offset: 0x0004309C
		private static void AppDomainManagerTypegetProcessId(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			bool isMasterClient = PhotonNetwork.IsMasterClient;
			A_3 = isMasterClient;
			int num = ((!A_3) ? 1 : 0) * 9 + 99;
			A_0 = num;
		}

		// Token: 0x0600070F RID: 1807 RVA: 0x00044EF8 File Offset: 0x000430F8
		private static void DeferredDisposableLifetimegetMaxCharCount(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			A_1 = 0;
		}

		// Token: 0x06000710 RID: 1808 RVA: 0x00044F10 File Offset: 0x00043110
		private static void SerialNumbergetOaepSHA(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_9 = rightGrab;
			int num = ((!A_9) ? 1 : 0) * 3 + 64;
			A_0 = num;
		}

		// Token: 0x06000711 RID: 1809 RVA: 0x00044F74 File Offset: 0x00043174
		private static void precisionSystemMaxDBCSCharSize(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 13 + 80;
			A_0 = num;
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x00044FD0 File Offset: 0x000431D0
		private static void AddressFieldYearEnd(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It");
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 43;
			A_0 = num;
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x00045058 File Offset: 0x00043258
		private static void MonitoringSurvivedProcessMemorySizeTimeZoneInfoOptions(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 6 + 6;
			A_0 = num;
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x000450C8 File Offset: 0x000432C8
		private static void GetFileNamesContravariant(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref float A_9, ref float A_10, ref bool A_11)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 95;
			A_0 = num;
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x00045110 File Offset: 0x00043310
		// Note: this type is marked as 'beforefieldinit'.
		static Tag()
		{
			Tag.AsCyFLicensed();
			int num = 113;
			int num2 = 113;
			num2 = 113;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Tag.SetAccessControlUser[num]);
			}
			num2 = 113;
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x0004514C File Offset: 0x0004334C
		private static void LdlenOriginalIssuerEqualsIssuer(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref float A_10, ref float A_11, ref bool A_12)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 72;
			A_0 = num;
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x00045198 File Offset: 0x00043398
		public static void TagGun()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Tag.SetAccessControlUser[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000718 RID: 1816 RVA: 0x000451CC File Offset: 0x000433CC
		private static void ChunkNumberIFileAssociationEntry(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			NotifiLib.SendNotification("You are not tagged!");
			Main.GetIndex("Tag All").enabled = false;
			Main.RecreateMenu();
			int num = (A_4.MoveNext() ? 1 : 0) * -11 + 14;
			A_0 = num;
		}

		// Token: 0x06000719 RID: 1817 RVA: 0x0004523C File Offset: 0x0004343C
		private static void getRenewalTimesetPartialTrustVisibleAssemblies(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref Vector3 A_9, ref List<VRRig>.Enumerator A_10, ref VRRig A_11, ref bool A_12, ref bool A_13, ref bool A_14)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_10 = enumerator;
			A_0 = 17;
		}

		// Token: 0x0600071A RID: 1818 RVA: 0x00045278 File Offset: 0x00043478
		private static void FormattableStringreserved(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaTagManager[] A_4, ref int A_5, ref GorillaTagManager A_6, ref Player[] A_7, ref int A_8, ref Player A_9, ref bool A_10)
		{
			int num = A_8 + 1;
			A_8 = num;
			int num2 = ((A_8 < A_7.Length) ? 1 : 0) * -4 + 105;
			A_0 = num2;
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x000452D8 File Offset: 0x000434D8
		private static void AsCyFLicensed()
		{
			Tag.SetAccessControlUser = new IntPtr[114];
			Tag.SetAccessControlUser[0] = ldftn(vmTpInitializedIsResource);
			Tag.SetAccessControlUser[1] = ldftn(SHACryptoServiceProviderSzArray);
			Tag.SetAccessControlUser[2] = ldftn(JAPANBootstrapConext);
			Tag.SetAccessControlUser[3] = ldftn(MonitoringSurvivedProcessMemorySizeLocalPush);
			Tag.SetAccessControlUser[4] = ldftn(MonitoringSurvivedProcessMemorySizeTimeZoneInfoOptions);
			Tag.SetAccessControlUser[5] = ldftn(TypeNameFormatFlagsUserQuota);
			Tag.SetAccessControlUser[6] = ldftn(RemoveChildTrace);
			Tag.SetAccessControlUser[7] = ldftn(MVarIsLittleEndian);
			Tag.SetAccessControlUser[8] = ldftn(SelectMethodDisableEvent);
			Tag.SetAccessControlUser[9] = ldftn(ChunkNumberIFileAssociationEntry);
			Tag.SetAccessControlUser[10] = ldftn(grfModeSetObjectUriForMarshal);
			Tag.SetAccessControlUser[11] = ldftn(CrossContextChannelTrademark);
			Tag.SetAccessControlUser[12] = ldftn(NullReferenceExceptionSetApartmentState);
			Tag.SetAccessControlUser[13] = ldftn(CultureNameResourceSetPairParsedMonthName);
			Tag.SetAccessControlUser[14] = ldftn(SkipsetShortestDayNames);
			Tag.SetAccessControlUser[15] = ldftn(ResourceManagerNotCreatingResourceSetMode);
			Tag.SetAccessControlUser[16] = ldftn(getRenewalTimesetPartialTrustVisibleAssemblies);
			Tag.SetAccessControlUser[17] = ldftn(SiteMembershipConditionUTFEncodingSealed);
			Tag.SetAccessControlUser[18] = ldftn(getInfrastructureAreAccessRulesCanonical);
			Tag.SetAccessControlUser[19] = ldftn(GetSignatureFileIOPermissionAttribute);
			Tag.SetAccessControlUser[20] = ldftn(IsGenericParameterThreadTransferReceiveObj);
			Tag.SetAccessControlUser[21] = ldftn(getEventProviderRuntimeFieldHandle);
			Tag.SetAccessControlUser[22] = ldftn(PageUpgetLoadFrom);
			Tag.SetAccessControlUser[23] = ldftn(SoapAttributeValueType);
			Tag.SetAccessControlUser[24] = ldftn(RSAPKCSSignatureDescriptionAddressOfMember);
			Tag.SetAccessControlUser[25] = ldftn(TypeLibraryOpenRead);
			Tag.SetAccessControlUser[26] = ldftn(getBuildNumberUnknownWrapper);
			Tag.SetAccessControlUser[27] = ldftn(RemotingTypeCachedDataECB);
			Tag.SetAccessControlUser[28] = ldftn(POLICYSETAUDITREQUIREMENTSWellKnownClientTypeEntry);
			Tag.SetAccessControlUser[29] = ldftn(GetFileLineNumbergetIsBrowserSave);
			Tag.SetAccessControlUser[30] = ldftn(LockTypeGetParamCustData);
			Tag.SetAccessControlUser[31] = ldftn(UpnResourceTypeIdInt);
			Tag.SetAccessControlUser[32] = ldftn(DescriptionMetadataErrorReportUrlMetadataEnumResult);
			Tag.SetAccessControlUser[33] = ldftn(ServerCallbackOSX);
			Tag.SetAccessControlUser[34] = ldftn(StrongNameHelpersGenericTypeParameters);
			Tag.SetAccessControlUser[35] = ldftn(FactoryMagicNumber);
			Tag.SetAccessControlUser[36] = ldftn(msystemTimeZonesMethodBuilderInstantiation);
			Tag.SetAccessControlUser[37] = ldftn(JavaMaxChunkSize);
			Tag.SetAccessControlUser[38] = ldftn(GetXsdTypesetIdentityObject);
			Tag.SetAccessControlUser[39] = ldftn(IWinRTClassActivatorgetChannelUris);
			Tag.SetAccessControlUser[40] = ldftn(TypesWhenNeededsetKeySize);
			Tag.SetAccessControlUser[41] = ldftn(AddressFieldYearEnd);
			Tag.SetAccessControlUser[42] = ldftn(ViewAclgetSpecialKey);
			Tag.SetAccessControlUser[43] = ldftn(IEnumDefinitionIdentityEmbedded);
			Tag.SetAccessControlUser[44] = ldftn(ClassTypeAssemblyTrademarkAttribute);
			Tag.SetAccessControlUser[45] = ldftn(AuthenticatedCBC);
			Tag.SetAccessControlUser[46] = ldftn(MidpointRoundingGetEnumUnderlyingType);
			Tag.SetAccessControlUser[47] = ldftn(FlowActivityIfNeededIsAppEarlierThanWindowsPhoneMango);
			Tag.SetAccessControlUser[48] = ldftn(MinEventLogClassic);
			Tag.SetAccessControlUser[49] = ldftn(ContainsValueFullTypeName);
			Tag.SetAccessControlUser[50] = ldftn(IsCompatibilityBehaviorDefinedLPStruct);
			Tag.SetAccessControlUser[51] = ldftn(SEPDateOrOffsetInstances);
			Tag.SetAccessControlUser[52] = ldftn(setExternalThreadingSetOnCountdownMres);
			Tag.SetAccessControlUser[53] = ldftn(OperatingSystemSecurityControlEvidence);
			Tag.SetAccessControlUser[54] = ldftn(BUILDNUMBERStandard);
			Tag.SetAccessControlUser[55] = ldftn(EventDataGetNativeOffset);
			Tag.SetAccessControlUser[56] = ldftn(ThisCallScopeTree);
			Tag.SetAccessControlUser[57] = ldftn(MutexTryCodeHelperReturnType);
			Tag.SetAccessControlUser[58] = ldftn(fullPathSparseFile);
			Tag.SetAccessControlUser[59] = ldftn(getDayOfYearHexadecimal);
			Tag.SetAccessControlUser[60] = ldftn(reservedUndock);
			Tag.SetAccessControlUser[61] = ldftn(SystemAlarmCallbacksetUri);
			Tag.SetAccessControlUser[62] = ldftn(getIsExplicitLayoutAccountDomainSid);
			Tag.SetAccessControlUser[63] = ldftn(SerialNumbergetOaepSHA);
			Tag.SetAccessControlUser[64] = ldftn(GetSerialNumberDateTimeToken);
			Tag.SetAccessControlUser[65] = ldftn(CLRSurrogateEntryTimeZoneKeyName);
			Tag.SetAccessControlUser[66] = ldftn(NDataUTFEncoding);
			Tag.SetAccessControlUser[67] = ldftn(LdlenOriginalIssuerEqualsIssuer);
			Tag.SetAccessControlUser[68] = ldftn(SynchronizedClientContextSinkTimeZoneKeyName);
			Tag.SetAccessControlUser[69] = ldftn(FeedbackSizereserved);
			Tag.SetAccessControlUser[70] = ldftn(AngleDTDSubset);
			Tag.SetAccessControlUser[71] = ldftn(SystemAclPresentNestedType);
			Tag.SetAccessControlUser[72] = ldftn(getIsReadygetNoAsyncCurrentCulture);
			Tag.SetAccessControlUser[73] = ldftn(ContinueWithWhenAny);
			Tag.SetAccessControlUser[74] = ldftn(DeferredDisposableLifetimegetMaxCharCount);
			Tag.SetAccessControlUser[75] = ldftn(IDeploymentMetadataEntryFromUnixTimeMilliseconds);
			Tag.SetAccessControlUser[76] = ldftn(TanhIsFamilyAndAssembly);
			Tag.SetAccessControlUser[77] = ldftn(PreferredBitTimeSpanRawInfo);
			Tag.SetAccessControlUser[78] = ldftn(IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSidldescType);
			Tag.SetAccessControlUser[79] = ldftn(precisionSystemMaxDBCSCharSize);
			Tag.SetAccessControlUser[80] = ldftn(DefaultInterfaceMinute);
			Tag.SetAccessControlUser[81] = ldftn(ProxySidMuiResourceTypeIdIntIntegerIds);
			Tag.SetAccessControlUser[82] = ldftn(taskApplication);
			Tag.SetAccessControlUser[83] = ldftn(GetHINSTANCEcollection);
			Tag.SetAccessControlUser[84] = ldftn(DTTWriteTo);
			Tag.SetAccessControlUser[85] = ldftn(removeProcessExitMessageData);
			Tag.SetAccessControlUser[86] = ldftn(mretValApplicationBasePath);
			Tag.SetAccessControlUser[87] = ldftn(ResolveTypeKeepAlive);
			Tag.SetAccessControlUser[88] = ldftn(PtrToStringBSTRWrapNonExceptionThrows);
			Tag.SetAccessControlUser[89] = ldftn(SmuggledMethodCallMessageCalendarId);
			Tag.SetAccessControlUser[90] = ldftn(GREGORIANXLITENGLISHgetNextActivator);
			Tag.SetAccessControlUser[91] = ldftn(NotFiniteNumberExceptionPopDirectionIsolate);
			Tag.SetAccessControlUser[92] = ldftn(GetFileNamesContravariant);
			Tag.SetAccessControlUser[93] = ldftn(VTBLOBgetCurrentSize);
			Tag.SetAccessControlUser[94] = ldftn(setVersionSecurityPermissionFlag);
			Tag.SetAccessControlUser[95] = ldftn(getCapacityGetMethodImplementationFlags);
			Tag.SetAccessControlUser[96] = ldftn(getTotalHoursgetMinimumLevel);
			Tag.SetAccessControlUser[97] = ldftn(getMemberCountWinCE);
			Tag.SetAccessControlUser[98] = ldftn(AppDomainManagerTypegetProcessId);
			Tag.SetAccessControlUser[99] = ldftn(DynamicPartitionerForArrayNotSerialized);
			Tag.SetAccessControlUser[100] = ldftn(GuidPropertySetDMNd);
			Tag.SetAccessControlUser[101] = ldftn(CreateComInstanceFromEventTags);
			Tag.SetAccessControlUser[102] = ldftn(LinkedSlotManifestError);
			Tag.SetAccessControlUser[103] = ldftn(FormattableStringreserved);
			Tag.SetAccessControlUser[104] = ldftn(GetTypeInfoCountCreated);
			Tag.SetAccessControlUser[105] = ldftn(getTargetTypeNameIsLetterOrDigit);
			Tag.SetAccessControlUser[106] = ldftn(PrivateBinPathProbeValueWaitDelegate);
			Tag.SetAccessControlUser[107] = ldftn(FromIdPercentSymbol);
			Tag.SetAccessControlUser[108] = ldftn(IsolatedStorageFileBleS);
			Tag.SetAccessControlUser[109] = ldftn(InfoSoapIsTransient);
			Tag.SetAccessControlUser[110] = ldftn(EqualsGetDomain);
			Tag.SetAccessControlUser[111] = ldftn(ParameterAttributesHasFieldRVA);
			Tag.SetAccessControlUser[112] = ldftn(getDeviceClaimsdSuppressMessageAttribute);
			Tag.SetAccessControlUser[113] = ldftn(ContractFailedEventArgsForkJoin);
		}

		// Token: 0x040000D2 RID: 210
		private static float splashtimeout;

		// Token: 0x040000D3 RID: 211
		public static string datdwe;

		// Token: 0x040000D4 RID: 212
		private static IntPtr[] SetAccessControlUser;
	}
}
