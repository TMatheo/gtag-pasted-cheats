﻿using System;

namespace StupidTemplate.Mods
{
	// Token: 0x0200002F RID: 47
	internal class Random
	{
		// Token: 0x06000751 RID: 1873 RVA: 0x00047BA8 File Offset: 0x00045DA8
		private static void UseNetCoreTimerReleaseAllResources(ref int A_0, ref int A_1, ref int A_2, Random A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000752 RID: 1874 RVA: 0x00047BCC File Offset: 0x00045DCC
		public static void Test()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Random.GetNextArgIStateManager[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x00047C00 File Offset: 0x00045E00
		private static void setSecurityIdentifiergetIsMailNewsDisplay(ref int A_0, ref int A_1, ref int A_2)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			RigDisabled.Hands();
			A_1 = 2;
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x00047C34 File Offset: 0x00045E34
		public Random()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.Random), ref num, ref num2, ref num3, this, Random.GetNextArgIStateManager[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x00047C68 File Offset: 0x00045E68
		// Note: this type is marked as 'beforefieldinit'.
		static Random()
		{
			Random.CompletiongetBlockSize();
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x00047C7C File Offset: 0x00045E7C
		private static void CompletiongetBlockSize()
		{
			Random.GetNextArgIStateManager = new IntPtr[2];
			Random.GetNextArgIStateManager[0] = ldftn(setSecurityIdentifiergetIsMailNewsDisplay);
			Random.GetNextArgIStateManager[1] = ldftn(UseNetCoreTimerReleaseAllResources);
		}

		// Token: 0x040000DC RID: 220
		private static IntPtr[] GetNextArgIStateManager;
	}
}
