﻿using System;
using EloranProjs;
using GorillaLocomotion;
using Photon.Pun;
using StupidTemplate.Menu;
using UnityEngine;

namespace StupidTemplate.Mods
{
	// Token: 0x0200002B RID: 43
	internal class Projectile
	{
		// Token: 0x0600066B RID: 1643 RVA: 0x0003E874 File Offset: 0x0003CA74
		public static void BalloonSpam()
		{
			int num = 5;
			int num2 = 5;
			num2 = 5;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				float num4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Single&), ref num, ref num2, ref num3, ref flag, ref flag2, ref num4, Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[num]);
			}
			num2 = 5;
		}

		// Token: 0x0600066C RID: 1644 RVA: 0x0003E8AC File Offset: 0x0003CAAC
		public static void BalloonGun()
		{
			int num = 16;
			int num2 = 16;
			num2 = 16;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[num]);
			}
			num2 = 16;
		}

		// Token: 0x0600066D RID: 1645 RVA: 0x0003E8E4 File Offset: 0x0003CAE4
		private static void AssemblyReferenceEntryToStringHelperFunc(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 5;
				int num2 = 5;
				num2 = 5;
				while (num2 != 0)
				{
					int num3;
					bool flag;
					float num4;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Single&), ref num, ref num2, ref num3, ref flag, ref num4, Projectile.<>c.BgtSHaveTime[num]);
				}
				num2 = 5;
			}, false);
			A_1 = 0;
		}

		// Token: 0x0600066E RID: 1646 RVA: 0x0003E92C File Offset: 0x0003CB2C
		private static void HashElementsgetArgumentType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			A_1 = 5;
		}

		// Token: 0x0600066F RID: 1647 RVA: 0x0003E944 File Offset: 0x0003CB44
		public static void IceSpam()
		{
			int num = 10;
			int num2 = 10;
			num2 = 10;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				float num4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Single&), ref num, ref num2, ref num3, ref flag, ref flag2, ref num4, Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[num]);
			}
			num2 = 10;
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x0003E980 File Offset: 0x0003CB80
		private static void setUseMachineKeyStoregetIsJITOptimizerDisabled(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x0003E998 File Offset: 0x0003CB98
		private static void getAsUintJulianCenturies(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			Projectile.splashtimeout = Time.time;
			float num = (float)Time.frameCount / 180f % 1f;
			A_5 = num;
			ProjectileLib.LaunchProjectile(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false), -1674517839, Color.HSVToRGB(A_5, 1f, 1f), PhotonNetwork.LocalPlayer);
			A_1 = 0;
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x0003EA3C File Offset: 0x0003CC3C
		private static void memidGlobalResourceContextBestFitCultureInfo(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			bool flag = Time.time > Projectile.splashtimeout + 0.05f;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 2;
			A_0 = num;
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x0003EAA8 File Offset: 0x0003CCA8
		private static void AssemblyReferenceDependentAssemblyGroupExecuteWorkItem(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 3 + 1;
			A_0 = num;
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x0003EB0C File Offset: 0x0003CD0C
		public static void SnowballSpam()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 5)
			{
				int num3;
				bool flag;
				bool flag2;
				float num4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Single&), ref num, ref num2, ref num3, ref flag, ref flag2, ref num4, Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x0003EB44 File Offset: 0x0003CD44
		public static void SnowballGun()
		{
			int num = 15;
			int num2 = 15;
			num2 = 15;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[num]);
			}
			num2 = 15;
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x0003EB7C File Offset: 0x0003CD7C
		private static void getWorkingSetMagenta(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			bool flag = Time.time > Projectile.splashtimeout + 0.05f;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 12;
			A_0 = num;
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x0003EBE8 File Offset: 0x0003CDE8
		private static void DuplicateIdentityOptionIsSubsetOfType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			bool flag = Time.time > Projectile.splashtimeout + 0.05f;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 7;
			A_0 = num;
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x0003EC54 File Offset: 0x0003CE54
		private static void VARFLAGFREADONLYgetNewEnum(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x0003EC6C File Offset: 0x0003CE6C
		private static void getIsDynamicInlineType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 3 + 6;
			A_0 = num;
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x0003ECD0 File Offset: 0x0003CED0
		private static void DescriptionMetadataProductSafeLsaLogonProcessHandle(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 3 + 11;
			A_0 = num;
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x0003ED34 File Offset: 0x0003CF34
		private static void WinSSetSymCustomAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			A_1 = 5;
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x0003ED4C File Offset: 0x0003CF4C
		public static void IceGun()
		{
			int num = 17;
			int num2 = 17;
			num2 = 17;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[num]);
			}
			num2 = 17;
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x0003ED84 File Offset: 0x0003CF84
		private static void IsSignatureIsClosed(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			A_1 = 0;
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x0003ED9C File Offset: 0x0003CF9C
		public static void ImpactGun()
		{
			int num = 18;
			int num2 = 18;
			num2 = 18;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[num]);
			}
			num2 = 18;
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x0003EDD4 File Offset: 0x0003CFD4
		private static void setCodeBaseManageVolume(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			Projectile.splashtimeout = Time.time;
			float num = (float)Time.frameCount / 180f % 1f;
			A_5 = num;
			ProjectileLib.LaunchProjectile(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false), -1671677000, Color.HSVToRGB(A_5, 1f, 1f), PhotonNetwork.LocalPlayer);
			A_1 = 0;
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x0003EE78 File Offset: 0x0003D078
		private static void GetOffsetAssemblyReferenceDependentAssemblySize(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 2;
				int num2 = 2;
				num2 = 2;
				while (num2 != 0)
				{
					int num3;
					bool flag;
					float num4;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Single&), ref num, ref num2, ref num3, ref flag, ref num4, Projectile.<>c.BgtSHaveTime[num]);
				}
				num2 = 2;
			}, false);
			A_1 = 0;
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x0003EEC0 File Offset: 0x0003D0C0
		public Projectile()
		{
			int num = 19;
			int num2 = 19;
			num2 = 19;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.Projectile), ref num, ref num2, ref num3, this, Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[num]);
			}
			num2 = 19;
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x0003EEF8 File Offset: 0x0003D0F8
		private static void ExplicitgetFusionLog(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x0003EF10 File Offset: 0x0003D110
		private static void RoleClaimTypeAssemblyPathLock(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref float A_5)
		{
			Projectile.splashtimeout = Time.time;
			float num = (float)Time.frameCount / 180f % 1f;
			A_5 = num;
			ProjectileLib.LaunchProjectile(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false), -675036877, Color.HSVToRGB(A_5, 1f, 1f), PhotonNetwork.LocalPlayer);
			A_1 = 5;
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x0003EFB4 File Offset: 0x0003D1B4
		private static void PopipoprsetWindowLeft(ref int A_0, ref int A_1, ref int A_2, Projectile A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x0003EFD8 File Offset: 0x0003D1D8
		private static void ExtensionOrAttributeObjectHolderList(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 8;
				int num2 = 8;
				num2 = 8;
				while (num2 != 0)
				{
					int num3;
					bool flag;
					float num4;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Single&), ref num, ref num2, ref num3, ref flag, ref num4, Projectile.<>c.BgtSHaveTime[num]);
				}
				num2 = 8;
			}, false);
			A_1 = 0;
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x0003F020 File Offset: 0x0003D220
		private static void EncoderFromBaseTransformMode(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 11;
				int num2 = 11;
				num2 = 11;
				while (num2 != 0)
				{
					int num3;
					bool flag;
					float num4;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Single&), ref num, ref num2, ref num3, ref flag, ref num4, Projectile.<>c.BgtSHaveTime[num]);
				}
				num2 = 11;
			}, true);
			A_1 = 0;
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x0003F068 File Offset: 0x0003D268
		// Note: this type is marked as 'beforefieldinit'.
		static Projectile()
		{
			Projectile.StrongNameGetBlobFileExists();
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x0003F07C File Offset: 0x0003D27C
		private static void StrongNameGetBlobFileExists()
		{
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION = new IntPtr[20];
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[0] = ldftn(AssemblyReferenceDependentAssemblyGroupExecuteWorkItem);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[1] = ldftn(memidGlobalResourceContextBestFitCultureInfo);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[2] = ldftn(RoleClaimTypeAssemblyPathLock);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[3] = ldftn(WinSSetSymCustomAttribute);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[4] = ldftn(HashElementsgetArgumentType);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[5] = ldftn(getIsDynamicInlineType);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[6] = ldftn(DuplicateIdentityOptionIsSubsetOfType);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[7] = ldftn(getAsUintJulianCenturies);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[8] = ldftn(VARFLAGFREADONLYgetNewEnum);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[9] = ldftn(ExplicitgetFusionLog);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[10] = ldftn(DescriptionMetadataProductSafeLsaLogonProcessHandle);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[11] = ldftn(getWorkingSetMagenta);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[12] = ldftn(setCodeBaseManageVolume);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[13] = ldftn(setUseMachineKeyStoregetIsJITOptimizerDisabled);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[14] = ldftn(IsSignatureIsClosed);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[15] = ldftn(GetOffsetAssemblyReferenceDependentAssemblySize);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[16] = ldftn(AssemblyReferenceEntryToStringHelperFunc);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[17] = ldftn(ExtensionOrAttributeObjectHolderList);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[18] = ldftn(EncoderFromBaseTransformMode);
			Projectile.getCommandLineCMSSECTIONIDCOUNTERSECTION[19] = ldftn(PopipoprsetWindowLeft);
		}

		// Token: 0x040000CA RID: 202
		private static float splashtimeout;

		// Token: 0x040000CB RID: 203
		private static IntPtr[] getCommandLineCMSSECTIONIDCOUNTERSECTION;
	}
}
