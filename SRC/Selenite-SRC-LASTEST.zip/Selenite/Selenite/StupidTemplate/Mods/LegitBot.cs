﻿using System;
using GorillaLocomotion;
using UnityEngine;

namespace StupidTemplate.Mods
{
	// Token: 0x02000027 RID: 39
	internal class LegitBot
	{
		// Token: 0x0600046F RID: 1135 RVA: 0x00021308 File Offset: 0x0001F508
		private static void IsInvalidCDSCollectionETWBCLProvider(ref int A_0, ref int A_1, ref int A_2)
		{
			GameObject.Find("pit lower slippery wall").GetComponent<GorillaSurfaceOverride>().slidePercentageOverride = 0f;
			GameObject.Find("pit lower slippery wall").GetComponent<GorillaSurfaceOverride>().overrideIndex = 0;
			GameObject.Find("pit upper slippery wall").GetComponent<GorillaSurfaceOverride>().slidePercentageOverride = 0f;
			GameObject.Find("pit upper slippery wall").GetComponent<GorillaSurfaceOverride>().overrideIndex = 0;
			A_1 = 0;
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x00021384 File Offset: 0x0001F584
		public static void NoWind()
		{
			int num = 3;
			int num2 = 3;
			num2 = 3;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[num]);
			}
			num2 = 3;
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x000213B8 File Offset: 0x0001F5B8
		public static void NoSlipWalls()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[num]);
			}
			num2 = 2;
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x000213EC File Offset: 0x0001F5EC
		private static void VersioningHelperHS(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.slideControl = 0.01f;
			A_1 = 0;
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x00021414 File Offset: 0x0001F614
		private static void DangerousGetRawSecurityContextWindowClassHostDll(ref int A_0, ref int A_1, ref int A_2)
		{
			GameObject.Find("ForceVolumesOcean_Combo_V2").SetActive(false);
			GameObject.Find("Forest_ForceVolumes").SetActive(false);
			GameObject.Find("WindForceVolume_v2_Prefab").SetActive(false);
			GameObject.Find("WindForceVolume_v2_Prefab (1)").SetActive(false);
			GameObject.Find("Canyon_ForceVolumes").SetActive(false);
			GameObject.Find("ForceVolumesMetro_Rivers").SetActive(false);
			GameObject.Find("Mountain_ForceVolumes").SetActive(false);
			A_1 = 0;
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x000214C0 File Offset: 0x0001F6C0
		private static void EffectiveKeySizesetTypeInfo(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.slideControl = 1E+21f;
			A_1 = 1;
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x000214E8 File Offset: 0x0001F6E8
		public LegitBot()
		{
			int num = 4;
			int num2 = 4;
			num2 = 4;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.LegitBot), ref num, ref num2, ref num3, this, LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[num]);
			}
			num2 = 4;
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x0002151C File Offset: 0x0001F71C
		public static void ResetSlideControl()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x00021550 File Offset: 0x0001F750
		public static void SlideControl()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x00021584 File Offset: 0x0001F784
		private static void EndDTDSubsetDefineGenericParameters(ref int A_0, ref int A_1, ref int A_2, LegitBot A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x000215A8 File Offset: 0x0001F7A8
		// Note: this type is marked as 'beforefieldinit'.
		static LegitBot()
		{
			LegitBot.addReflectionOnlyAssemblyResolveAceType();
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x000215BC File Offset: 0x0001F7BC
		private static void addReflectionOnlyAssemblyResolveAceType()
		{
			LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback = new IntPtr[5];
			LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[0] = ldftn(EffectiveKeySizesetTypeInfo);
			LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[1] = ldftn(VersioningHelperHS);
			LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[2] = ldftn(IsInvalidCDSCollectionETWBCLProvider);
			LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[3] = ldftn(DangerousGetRawSecurityContextWindowClassHostDll);
			LegitBot.getDoNotAddrOfCspParentWindowHandleErrorCallback[4] = ldftn(EndDTDSubsetDefineGenericParameters);
		}

		// Token: 0x040000BB RID: 187
		private static IntPtr[] getDoNotAddrOfCspParentWindowHandleErrorCallback;
	}
}
