﻿using System;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Menu;
using UnityEngine;

namespace StupidTemplate.Mods
{
	// Token: 0x02000031 RID: 49
	internal class tTest
	{
		// Token: 0x0600075D RID: 1885 RVA: 0x000480B4 File Offset: 0x000462B4
		public tTest()
		{
			int num = 6;
			int num2 = 6;
			num2 = 6;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.tTest), ref num, ref num2, ref num3, this, tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[num]);
			}
			num2 = 6;
		}

		// Token: 0x0600075E RID: 1886 RVA: 0x000480E8 File Offset: 0x000462E8
		public static void poo()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[num]);
			}
			num2 = 1;
		}

		// Token: 0x0600075F RID: 1887 RVA: 0x00048120 File Offset: 0x00046320
		private static void FieldMetadataIsField(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			tTest.splashtimeout = Time.time;
			tTest.LaunchBigSnowball(GTPlayer.Instance.rightControllerTransform.position, Vector3.zero, 50f, null);
			A_1 = 0;
		}

		// Token: 0x06000760 RID: 1888 RVA: 0x00048164 File Offset: 0x00046364
		private static void CurrencyNegativePatternInvokeMethod(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_1 = 0;
		}

		// Token: 0x06000761 RID: 1889 RVA: 0x0004817C File Offset: 0x0004637C
		public static void LaunchBigSnowball(Vector3 Pos, Vector3 Vel, float Scale, Player Target = null)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				GrowingSnowballThrowable growingSnowballThrowable;
				PhotonEvent photonEvent;
				RaiseEventOptions raiseEventOptions;
				SendOptions sendOptions;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,GrowingSnowballThrowable&,PhotonEvent&,Photon.Realtime.RaiseEventOptions&,ExitGames.Client.Photon.SendOptions&,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,Photon.Realtime.Player), ref num, ref num2, ref num3, ref growingSnowballThrowable, ref photonEvent, ref raiseEventOptions, ref sendOptions, Pos, Vel, Scale, Target, tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000762 RID: 1890 RVA: 0x000481BC File Offset: 0x000463BC
		private static void GenericAllHashHelpers(ref int A_0, ref int A_1, ref int A_2, ref GrowingSnowballThrowable A_3, ref PhotonEvent A_4, ref RaiseEventOptions A_5, ref SendOptions A_6, Vector3 A_7, Vector3 A_8, float A_9, Player A_10)
		{
			GrowingSnowballThrowable component = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/GrowingSnowballRightAnchor(Clone)/LMACF. RIGHT.").GetComponent<GrowingSnowballThrowable>();
			A_3 = component;
			PhotonEvent photonEvent = (PhotonEvent)Traverse.Create(A_3).Field("snowballThrowEvent").GetValue();
			A_4 = photonEvent;
			byte b = 176;
			object obj = new object[]
			{
				(int)Traverse.Create(A_4).Field("_eventId").GetValue(),
				A_7,
				A_8,
				A_9
			};
			RaiseEventOptions raiseEventOptions = new RaiseEventOptions();
			A_5 = raiseEventOptions;
			A_5.TargetActors = new int[]
			{
				A_10.ActorNumber
			};
			RaiseEventOptions raiseEventOptions2 = A_5;
			A_6 = default(SendOptions);
			A_6.Reliability = false;
			A_6.Encrypt = true;
			PhotonNetwork.RaiseEvent(b, obj, raiseEventOptions2, A_6);
			Main.RPCProtection();
			A_1 = 2;
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x00048318 File Offset: 0x00046518
		private static void ATTTypePEPlus(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_1 = 0;
		}

		// Token: 0x06000764 RID: 1892 RVA: 0x00048330 File Offset: 0x00046530
		private static void GetTypesPublic(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = Time.time > tTest.splashtimeout + 1f;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 3;
			A_0 = num;
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x0004839C File Offset: 0x0004659C
		private static void TraceLoggingTypeInfoFindFirst(ref int A_0, ref int A_1, ref int A_2, tTest A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x000483C0 File Offset: 0x000465C0
		private static void getNextActivatorIDictionary(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 3 + 2;
			A_0 = num;
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x00048424 File Offset: 0x00046624
		// Note: this type is marked as 'beforefieldinit'.
		static tTest()
		{
			tTest.pValueIDLFLAGNONE();
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x00048438 File Offset: 0x00046638
		private static void pValueIDLFLAGNONE()
		{
			tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY = new IntPtr[7];
			tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[0] = ldftn(GenericAllHashHelpers);
			tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[1] = ldftn(getNextActivatorIDictionary);
			tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[2] = ldftn(GetTypesPublic);
			tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[3] = ldftn(FieldMetadataIsField);
			tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[4] = ldftn(ATTTypePEPlus);
			tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[5] = ldftn(CurrencyNegativePatternInvokeMethod);
			tTest.DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY[6] = ldftn(TraceLoggingTypeInfoFindFirst);
		}

		// Token: 0x040000DE RID: 222
		private static float splashtimeout;

		// Token: 0x040000DF RID: 223
		private static IntPtr[] DXMNNSTOREASSEMBLYSTATUSMANIFESTONLY;
	}
}
