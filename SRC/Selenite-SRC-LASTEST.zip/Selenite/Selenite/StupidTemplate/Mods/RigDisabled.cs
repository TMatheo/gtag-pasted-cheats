﻿using System;
using GorillaLocomotion;
using UnityEngine;

namespace StupidTemplate.Mods
{
	// Token: 0x02000030 RID: 48
	internal class RigDisabled
	{
		// Token: 0x06000757 RID: 1879 RVA: 0x00047CBC File Offset: 0x00045EBC
		private static void DisableOptimizationsTokenRestrictedSids(ref int A_0, ref int A_1, ref int A_2, RigDisabled A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x00047CE0 File Offset: 0x00045EE0
		public static void Hands()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				GameObject gameObject;
				GameObject gameObject2;
				GameObject gameObject3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.GameObject&,UnityEngine.GameObject&,UnityEngine.GameObject&), ref num, ref num2, ref num3, ref gameObject, ref gameObject2, ref gameObject3, RigDisabled.SemaphoreSlimWebpage[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x00047D18 File Offset: 0x00045F18
		private static void InspectableFileIOAccess(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref GameObject A_4, ref GameObject A_5)
		{
			GameObject gameObject = GameObject.CreatePrimitive(0);
			A_3 = gameObject;
			A_3.transform.position = GTPlayer.Instance.rightControllerTransform.position;
			A_3.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			A_3.GetComponent<Renderer>().material.color = GorillaTagger.Instance.offlineVRRig.mainSkin.material.color;
			GameObject gameObject2 = GameObject.CreatePrimitive(0);
			A_4 = gameObject2;
			A_4.transform.position = GTPlayer.Instance.leftControllerTransform.position;
			A_4.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			A_4.GetComponent<Renderer>().material.color = GorillaTagger.Instance.offlineVRRig.mainSkin.material.color;
			GameObject gameObject3 = GameObject.CreatePrimitive(1);
			A_5 = gameObject3;
			A_5.transform.position = GTPlayer.Instance.bodyCollider.transform.position;
			A_5.transform.localScale = new Vector3(0.35f, 0.35f, 0.35f);
			A_5.GetComponent<Renderer>().material.color = GorillaTagger.Instance.offlineVRRig.mainSkin.material.color;
			Object.Destroy(A_3, Time.deltaTime);
			Object.Destroy(A_4, Time.deltaTime);
			Object.Destroy(A_5, Time.deltaTime);
			Object.Destroy(A_3.GetComponent<MeshCollider>());
			Object.Destroy(A_3.GetComponent<Collider>());
			Object.Destroy(A_3.GetComponent<BoxCollider>());
			Object.Destroy(A_3.GetComponent<SphereCollider>());
			Object.Destroy(A_4.GetComponent<MeshCollider>());
			Object.Destroy(A_4.GetComponent<Collider>());
			Object.Destroy(A_4.GetComponent<BoxCollider>());
			Object.Destroy(A_4.GetComponent<SphereCollider>());
			Object.Destroy(A_5.GetComponent<MeshCollider>());
			Object.Destroy(A_5.GetComponent<Collider>());
			Object.Destroy(A_5.GetComponent<BoxCollider>());
			Object.Destroy(A_5.GetComponent<SphereCollider>());
			A_1 = 2;
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x0004802C File Offset: 0x0004622C
		public RigDisabled()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.RigDisabled), ref num, ref num2, ref num3, this, RigDisabled.SemaphoreSlimWebpage[num]);
			}
			num2 = 1;
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x00048060 File Offset: 0x00046260
		// Note: this type is marked as 'beforefieldinit'.
		static RigDisabled()
		{
			RigDisabled.CountdownEventAnonymousSid();
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x00048074 File Offset: 0x00046274
		private static void CountdownEventAnonymousSid()
		{
			RigDisabled.SemaphoreSlimWebpage = new IntPtr[2];
			RigDisabled.SemaphoreSlimWebpage[0] = ldftn(InspectableFileIOAccess);
			RigDisabled.SemaphoreSlimWebpage[1] = ldftn(DisableOptimizationsTokenRestrictedSids);
		}

		// Token: 0x040000DD RID: 221
		private static IntPtr[] SemaphoreSlimWebpage;
	}
}
