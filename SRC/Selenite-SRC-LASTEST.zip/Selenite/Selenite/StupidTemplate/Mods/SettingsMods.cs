﻿using System;
using StupidTemplate.Menu;

namespace StupidTemplate.Mods
{
	// Token: 0x02000033 RID: 51
	internal class SettingsMods
	{
		// Token: 0x0600076F RID: 1903 RVA: 0x000485EC File Offset: 0x000467EC
		public static void Self()
		{
			int num = 7;
			int num2 = 7;
			num2 = 7;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 7;
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x00048620 File Offset: 0x00046820
		private static void RuntimeFieldInfoEventChannelType(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.outlineMenu = true;
			A_1 = 0;
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x00048644 File Offset: 0x00046844
		public static void MenuOutline()
		{
			int num = 24;
			int num2 = 24;
			num2 = 24;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 24;
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x0004867C File Offset: 0x0004687C
		private static void BaseOctetPassesActivityFilter(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.sideBarEnabled = false;
			A_1 = 0;
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x000486A0 File Offset: 0x000468A0
		public static void LegitBot()
		{
			int num = 4;
			int num2 = 4;
			num2 = 4;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 4;
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x000486D4 File Offset: 0x000468D4
		private static void TAIWANLUNISOLARIsinst(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.disableNotifications = false;
			A_1 = 0;
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x000486F8 File Offset: 0x000468F8
		private static void IsTokenProperlyAssignedCreateCodeGroup(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.fpsCounter = true;
			A_1 = 0;
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x0004871C File Offset: 0x0004691C
		private static void TimerHolderPkcs(ref int A_0, ref int A_1, ref int A_2)
		{
			Visual.infectionESP = true;
			A_1 = 0;
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x00048740 File Offset: 0x00046940
		public static void NoMenuOutline()
		{
			int num = 25;
			int num2 = 25;
			num2 = 25;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 25;
		}

		// Token: 0x06000778 RID: 1912 RVA: 0x00048778 File Offset: 0x00046978
		private static void IdentityReferenceCollectionsetWrite(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.outlineMenu = false;
			A_1 = 0;
		}

		// Token: 0x06000779 RID: 1913 RVA: 0x0004879C File Offset: 0x0004699C
		private static void InvalidOperationEmptyQueueRootDirectory(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Visuals";
			Main.buttonsType = 6;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x0600077A RID: 1914 RVA: 0x000487DC File Offset: 0x000469DC
		private static void ResolveMatchingCodeGroupsPrevStack(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.disconnectButton = true;
			A_1 = 0;
		}

		// Token: 0x0600077B RID: 1915 RVA: 0x00048800 File Offset: 0x00046A00
		public static void FunRandom()
		{
			int num = 11;
			int num2 = 11;
			num2 = 11;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 11;
		}

		// Token: 0x0600077C RID: 1916 RVA: 0x00048838 File Offset: 0x00046A38
		public static void EnableDisconnectButton()
		{
			int num = 18;
			int num2 = 18;
			num2 = 18;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 18;
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x00048870 File Offset: 0x00046A70
		public SettingsMods()
		{
			int num = 26;
			int num2 = 26;
			num2 = 26;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.SettingsMods), ref num, ref num2, ref num3, this, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 26;
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x000488A8 File Offset: 0x00046AA8
		public static void Config()
		{
			int num = 8;
			int num2 = 8;
			num2 = 8;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 8;
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x000488DC File Offset: 0x00046ADC
		private static void LPWStrInternalEncoderBestFitFallback(ref int A_0, ref int A_1, ref int A_2)
		{
			Visual.infectionESP = false;
			A_1 = 0;
		}

		// Token: 0x06000780 RID: 1920 RVA: 0x00048900 File Offset: 0x00046B00
		public static void LeftHand()
		{
			int num = 13;
			int num2 = 13;
			num2 = 13;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 13;
		}

		// Token: 0x06000781 RID: 1921 RVA: 0x00048938 File Offset: 0x00046B38
		private static void ParseInstallerReference(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.disconnectButton = false;
			A_1 = 0;
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x0004895C File Offset: 0x00046B5C
		public static void World()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 2;
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x00048990 File Offset: 0x00046B90
		public static void SideBarOff()
		{
			int num = 21;
			int num2 = 21;
			num2 = 21;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 21;
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x000489C8 File Offset: 0x00046BC8
		public static void InfectionVisuals()
		{
			int num = 22;
			int num2 = 22;
			num2 = 22;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 22;
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x00048A00 File Offset: 0x00046C00
		public static void Proj()
		{
			int num = 10;
			int num2 = 10;
			num2 = 10;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 10;
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x00048A38 File Offset: 0x00046C38
		public static void Exploits()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x00048A6C File Offset: 0x00046C6C
		private static void SystemAlarmDateTimeTypeInfo(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Fun/Random";
			Main.buttonsType = 12;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00048AAC File Offset: 0x00046CAC
		private static void getKeyStoreStringInfo(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.rightHanded = false;
			A_1 = 0;
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x00048AD0 File Offset: 0x00046CD0
		private static void DefaultRoleClaimTypeConfigId(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.disableNotifications = true;
			A_1 = 0;
		}

		// Token: 0x0600078A RID: 1930 RVA: 0x00048AF4 File Offset: 0x00046CF4
		private static void VARFLAGFDEFAULTBINDExplicitLayout(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Players";
			Main.buttonsType = 4;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x0600078B RID: 1931 RVA: 0x00048B34 File Offset: 0x00046D34
		public static void DisableNotifications()
		{
			int num = 17;
			int num2 = 17;
			num2 = 17;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 17;
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x00048B6C File Offset: 0x00046D6C
		private static void UnsafeLoadFromISTOREENUMASSEMBLIESFLAGMATCHSERVICING(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Self";
			Main.buttonsType = 8;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x00048BAC File Offset: 0x00046DAC
		public static void RightHand()
		{
			int num = 12;
			int num2 = 12;
			num2 = 12;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 12;
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x00048BE4 File Offset: 0x00046DE4
		private static void CLRSurrogateSectionSHACryptoServiceProvider(ref int A_0, ref int A_1, ref int A_2, SettingsMods A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x00048C08 File Offset: 0x00046E08
		public static void EnableNotifications()
		{
			int num = 16;
			int num2 = 16;
			num2 = 16;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 16;
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x00048C40 File Offset: 0x00046E40
		public static void RageCheat()
		{
			int num = 6;
			int num2 = 6;
			num2 = 6;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 6;
		}

		// Token: 0x06000791 RID: 1937 RVA: 0x00048C74 File Offset: 0x00046E74
		private static void PrivilegeNameValueList(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Legit+Bot";
			Main.buttonsType = 5;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x06000792 RID: 1938 RVA: 0x00048CB4 File Offset: 0x00046EB4
		private static void getLocalPathPartitioner(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.sideBarEnabled = true;
			Main.RecreateMenu();
			A_1 = 0;
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x00048CDC File Offset: 0x00046EDC
		public static void DisableDisconnectButton()
		{
			int num = 19;
			int num2 = 19;
			num2 = 19;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 19;
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x00048D14 File Offset: 0x00046F14
		private static void threadLocalsIsAppEarlierThanSilverlight(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Rage+Cheat";
			Main.buttonsType = 7;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x06000795 RID: 1941 RVA: 0x00048D54 File Offset: 0x00046F54
		private static void IAsyncResultIsFamilyOrAssembly(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.returnEnabled = true;
			Main.cat = "Category_Misc";
			Main.buttonsType = 2;
			Main.pageNumber = 0;
			A_1 = 0;
		}

		// Token: 0x06000796 RID: 1942 RVA: 0x00048D94 File Offset: 0x00046F94
		public static void Visuals()
		{
			int num = 5;
			int num2 = 5;
			num2 = 5;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 5;
		}

		// Token: 0x06000797 RID: 1943 RVA: 0x00048DC8 File Offset: 0x00046FC8
		public static void DisableFPSCounter()
		{
			int num = 15;
			int num2 = 15;
			num2 = 15;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 15;
		}

		// Token: 0x06000798 RID: 1944 RVA: 0x00048E00 File Offset: 0x00047000
		public static void Misc()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000799 RID: 1945 RVA: 0x00048E34 File Offset: 0x00047034
		public static void EnableFPSCounter()
		{
			int num = 14;
			int num2 = 14;
			num2 = 14;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 14;
		}

		// Token: 0x0600079A RID: 1946 RVA: 0x00048E6C File Offset: 0x0004706C
		public static void Guardian()
		{
			int num = 9;
			int num2 = 9;
			num2 = 9;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 9;
		}

		// Token: 0x0600079B RID: 1947 RVA: 0x00048EA4 File Offset: 0x000470A4
		private static void getTrackResurrectionCLRSurrogateClassName(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Guardian";
			Main.buttonsType = 10;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x0600079C RID: 1948 RVA: 0x00048EE4 File Offset: 0x000470E4
		private static void getRemaininggetIsFamilyAndAssembly(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.rightHanded = true;
			A_1 = 0;
		}

		// Token: 0x0600079D RID: 1949 RVA: 0x00048F08 File Offset: 0x00047108
		public static void Players()
		{
			int num = 3;
			int num2 = 3;
			num2 = 3;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 3;
		}

		// Token: 0x0600079E RID: 1950 RVA: 0x00048F3C File Offset: 0x0004713C
		public static void SideBarOn()
		{
			int num = 20;
			int num2 = 20;
			num2 = 20;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 20;
		}

		// Token: 0x0600079F RID: 1951 RVA: 0x00048F74 File Offset: 0x00047174
		private static void CompoundAceTypeCommonAcl(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Configuration";
			Main.buttonsType = 9;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x060007A0 RID: 1952 RVA: 0x00048FB4 File Offset: 0x000471B4
		public static void DisableInfectionVisuals()
		{
			int num = 23;
			int num2 = 23;
			num2 = 23;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[num]);
			}
			num2 = 23;
		}

		// Token: 0x060007A1 RID: 1953 RVA: 0x00048FEC File Offset: 0x000471EC
		private static void localInitsetVersion(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Exploits";
			Main.buttonsType = 1;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 1;
		}

		// Token: 0x060007A2 RID: 1954 RVA: 0x0004902C File Offset: 0x0004722C
		private static void setHostContextMidday(ref int A_0, ref int A_1, ref int A_2)
		{
			Settings.fpsCounter = false;
			A_1 = 0;
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x00049050 File Offset: 0x00047250
		private static void ClassInterfaceTypeEqualityComparer(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_Projectiles";
			Main.buttonsType = 11;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x00049090 File Offset: 0x00047290
		private static void DeconstructWriteIntPtr(ref int A_0, ref int A_1, ref int A_2)
		{
			Main.cat = "Category_World";
			Main.buttonsType = 3;
			Main.pageNumber = 0;
			Main.returnEnabled = true;
			A_1 = 0;
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x000490D0 File Offset: 0x000472D0
		// Note: this type is marked as 'beforefieldinit'.
		static SettingsMods()
		{
			SettingsMods.CMSSECTIONIDCOMPATIBLEFRAMEWORKSSECTIONgetAllowUnassigned();
		}

		// Token: 0x060007A6 RID: 1958 RVA: 0x000490E4 File Offset: 0x000472E4
		private static void CMSSECTIONIDCOMPATIBLEFRAMEWORKSSECTIONgetAllowUnassigned()
		{
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation = new IntPtr[27];
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[0] = ldftn(localInitsetVersion);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[1] = ldftn(IAsyncResultIsFamilyOrAssembly);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[2] = ldftn(DeconstructWriteIntPtr);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[3] = ldftn(VARFLAGFDEFAULTBINDExplicitLayout);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[4] = ldftn(PrivilegeNameValueList);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[5] = ldftn(InvalidOperationEmptyQueueRootDirectory);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[6] = ldftn(threadLocalsIsAppEarlierThanSilverlight);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[7] = ldftn(UnsafeLoadFromISTOREENUMASSEMBLIESFLAGMATCHSERVICING);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[8] = ldftn(CompoundAceTypeCommonAcl);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[9] = ldftn(getTrackResurrectionCLRSurrogateClassName);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[10] = ldftn(ClassInterfaceTypeEqualityComparer);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[11] = ldftn(SystemAlarmDateTimeTypeInfo);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[12] = ldftn(getRemaininggetIsFamilyAndAssembly);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[13] = ldftn(getKeyStoreStringInfo);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[14] = ldftn(IsTokenProperlyAssignedCreateCodeGroup);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[15] = ldftn(setHostContextMidday);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[16] = ldftn(TAIWANLUNISOLARIsinst);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[17] = ldftn(DefaultRoleClaimTypeConfigId);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[18] = ldftn(ResolveMatchingCodeGroupsPrevStack);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[19] = ldftn(ParseInstallerReference);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[20] = ldftn(getLocalPathPartitioner);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[21] = ldftn(BaseOctetPassesActivityFilter);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[22] = ldftn(TimerHolderPkcs);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[23] = ldftn(LPWStrInternalEncoderBestFitFallback);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[24] = ldftn(RuntimeFieldInfoEventChannelType);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[25] = ldftn(IdentityReferenceCollectionsetWrite);
			SettingsMods.UrlIdentityPermissionAttributeOpenPunctuation[26] = ldftn(CLRSurrogateSectionSHACryptoServiceProvider);
		}

		// Token: 0x040000E1 RID: 225
		private static IntPtr[] UrlIdentityPermissionAttributeOpenPunctuation;
	}
}
