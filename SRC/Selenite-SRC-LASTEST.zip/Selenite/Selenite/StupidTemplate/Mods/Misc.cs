﻿using System;
using System.Collections.Generic;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Notifications;
using UnityEngine;

namespace StupidTemplate.Mods
{
	// Token: 0x02000026 RID: 38
	internal class Misc
	{
		// Token: 0x06000407 RID: 1031 RVA: 0x0001C250 File Offset: 0x0001A450
		private static void getXmlNsForClrTypeWithNsAndAssemblyAppContextSwitches(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			A_0 = 30;
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x0001C268 File Offset: 0x0001A468
		private static void SoapLanguagegetXsdType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -8 + 51;
			A_0 = num2;
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0001C2C8 File Offset: 0x0001A4C8
		private static void getIsNotPublicActivationTypeName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			bool flag = true;
			A_14 = flag;
			int num = ((!A_14) ? 1 : 0) * 1 + 22;
			A_0 = num;
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0001C324 File Offset: 0x0001A524
		private static void SetSymAttributeGetComInterfaceForObject(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(Misc.GenerateRandomString(4), 0);
			A_1 = 0;
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0001C358 File Offset: 0x0001A558
		private static void ApplicationTrustCollectionMatchAllVersions(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			List<GorillaPlayerScoreboardLine>.Enumerator enumerator = GorillaScoreboardTotalUpdater.allScoreboardLines.GetEnumerator();
			A_4 = enumerator;
			A_0 = 36;
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0001C38C File Offset: 0x0001A58C
		private static void InteractiveMissingFieldException(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetworkController.Instance.AttemptToJoinPublicRoom(GorillaComputer.instance.GetJoinTriggerForZone(PhotonNetworkController.Instance.currentJoinTrigger.networkZone), 0);
			A_1 = 0;
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x0001C3D4 File Offset: 0x0001A5D4
		private static void UtcValueFixupEnum(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			VRRig vrrig = A_8.Current;
			A_9 = vrrig;
			int num = (A_9.isOfflineVRRig ? 1 : 0) * 1 + 17;
			A_0 = num;
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0001C43C File Offset: 0x0001A63C
		private static void FormIdnaEuropeanNumber(ref int A_0, ref int A_1, ref int A_2)
		{
			Misc.cosmetictrigger.SetActive(false);
			A_1 = 0;
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x0001C464 File Offset: 0x0001A664
		private static void getGrantedSetRaiseContractFailedEvent(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			A_8.Dispose();
			A_1 = 4;
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x0001C48C File Offset: 0x0001A68C
		private static void getCultureInfoParentWindowHandle(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			Player player = A_4[A_5];
			A_6 = player;
			GorillaNot.instance.SendReport("Cheating", A_6.UserId, A_6.NickName);
			GorillaNot.instance.SendReport("Toxicity", A_6.UserId, A_6.NickName);
			GorillaNot.instance.SendReport("HateSpeech", A_6.UserId, A_6.NickName);
			List<GorillaPlayerScoreboardLine>.Enumerator enumerator = GorillaScoreboardTotalUpdater.allScoreboardLines.GetEnumerator();
			A_7 = enumerator;
			A_0 = 44;
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x0001C570 File Offset: 0x0001A770
		private static void EnclosingMarkTRACEENABLEINFO(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			PhotonNetworkController.Instance.AttemptToJoinPublicRoom(GorillaComputer.instance.GetJoinTriggerForZone(PhotonNetworkController.Instance.currentJoinTrigger.networkZone), 0);
			A_1 = 0;
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x0001C5B8 File Offset: 0x0001A7B8
		public static void Disconnect()
		{
			int num = 5;
			int num2 = 5;
			num2 = 5;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 5;
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x0001C5EC File Offset: 0x0001A7EC
		private static void CMSASSEMBLYREFERENCEFLAGFOLLOWAppDomainUnloadedException(ref int A_0, ref int A_1, ref int A_2)
		{
			Misc.trigger.SetActive(true);
			A_1 = 0;
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x0001C614 File Offset: 0x0001A814
		private static void ToUnixTimeSecondssetChannelData(ref int A_0, ref int A_1, ref int A_2)
		{
			Misc.trigger = GameObject.Find("JoinRoomTriggers_Prefab");
			Misc.cosmetictrigger = GameObject.Find("Cosmetics Room Triggers");
			Misc.chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".ToCharArray();
			A_1 = 0;
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x0001C658 File Offset: 0x0001A858
		private static string NestedFamilyGivenName(ref int A_0, ref int A_1, ref int A_2, ref Random A_3, ref char[] A_4, ref int A_5, ref bool A_6, ref string A_7, int A_8)
		{
			bool flag = A_5 < A_8;
			A_6 = flag;
			int num = (A_6 ? 1 : 0) * -2 + 73;
			A_0 = num;
			string result;
			return result;
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x0001C6C4 File Offset: 0x0001A8C4
		private static void GetArrayMethodTokenIsolatedStoragePermissionAttribute(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetwork.ConnectToRegion("usw");
			A_1 = 0;
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x0001C6E8 File Offset: 0x0001A8E8
		private static void SetLocalSignaturegetRestrictedMemberAccess(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			List<GorillaPlayerScoreboardLine>.Enumerator enumerator = GorillaScoreboardTotalUpdater.allScoreboardLines.GetEnumerator();
			A_4 = enumerator;
			A_0 = 53;
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x0001C71C File Offset: 0x0001A91C
		private static string IMuiResourceIdLookupMapEntrygetReflectedType(ref int A_0, ref int A_1, ref int A_2, ref string A_3)
		{
			string result = A_3;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x0001C73C File Offset: 0x0001A93C
		private static void GenericsMuiResourceTypeIdIntEntryFieldId(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool inRoom = PhotonNetwork.InRoom;
			A_3 = inRoom;
			int num = ((!A_3) ? 1 : 0) * 1 + 8;
			A_0 = num;
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x0001C798 File Offset: 0x0001A998
		private static void GetAttributeLengthInTextElements(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			bool flag = A_12 < A_13;
			A_14 = flag;
			int num = ((!A_14) ? 1 : 0) * 1 + 22;
			A_0 = num;
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x0001C808 File Offset: 0x0001AA08
		// Note: this type is marked as 'beforefieldinit'.
		static Misc()
		{
			Misc.AlgorithmTypesetRenewOnCallTime();
			int num = 76;
			int num2 = 76;
			num2 = 76;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 76;
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x0001C844 File Offset: 0x0001AA44
		private static void SafeHandleStopped(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			PhotonNetwork.Disconnect();
			int num = (A_8.MoveNext() ? 1 : 0) * -10 + 26;
			A_0 = num;
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x0001C894 File Offset: 0x0001AA94
		private static void getIsNestedEventToken(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			A_1 = 0;
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x0001C8AC File Offset: 0x0001AAAC
		public static void JoinMenuCode()
		{
			int num = 60;
			int num2 = 60;
			num2 = 60;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 60;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0001C8E4 File Offset: 0x0001AAE4
		public static void GrabServersAdress()
		{
			int num = 34;
			int num2 = 34;
			num2 = 34;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 34;
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x0001C91C File Offset: 0x0001AB1C
		private static string setAsDispatchgetIsSecured(ref int A_0, ref int A_1, ref int A_2, ref Random A_3, ref char[] A_4, ref int A_5, ref bool A_6, ref string A_7, int A_8)
		{
			Random random = new Random();
			A_3 = random;
			char[] array = new char[A_8];
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 72;
			string result;
			return result;
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x0001C980 File Offset: 0x0001AB80
		private static void MuiResourceMapResourceTypeIdStringMethodCallMessageWrapper(ref int A_0, ref int A_1, ref int A_2, Misc A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x0001C9A4 File Offset: 0x0001ABA4
		private static void CustomAttributeDataCloseNamespace(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			A_1 = 5;
			A_2 = 28;
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x0001C9C8 File Offset: 0x0001ABC8
		private static void DataAvailableIVectorViewToIReadOnlyListAdapter(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -8 + 51;
			A_0 = num;
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x0001CA04 File Offset: 0x0001AC04
		private static string setOffsetHighGetTypeCode(ref int A_0, ref int A_1, ref int A_2, ref Random A_3, ref char[] A_4, ref int A_5, ref bool A_6, ref string A_7, int A_8)
		{
			string text = new string(A_4);
			A_7 = text;
			A_0 = 74;
			string result;
			return result;
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0001CA40 File Offset: 0x0001AC40
		public static void No()
		{
			int num = 4;
			int num2 = 4;
			num2 = 4;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 4;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0001CA74 File Offset: 0x0001AC74
		public static void GetComp()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 2)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x0001CAA8 File Offset: 0x0001ACA8
		private static void PurgeAccessRulesname(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			bool flag = false;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 5 + 19;
			A_0 = num;
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0001CB04 File Offset: 0x0001AD04
		private static void SecurityExceptionSetAsNULL(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetwork.Disconnect();
			PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("PARANOIA", 0);
			A_1 = 0;
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x0001CB3C File Offset: 0x0001AD3C
		private static void getUseSaltgetCommand(ref int A_0, ref int A_1, ref int A_2)
		{
			GorillaComputer.instance.allowedInCompetitive = true;
			PlayerPrefs.SetInt("allowedInCompetitive", 1);
			PlayerPrefs.Save();
			A_1 = 0;
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0001CB7C File Offset: 0x0001AD7C
		public unsafe static void MuteAll()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 35;
			int num4 = 35;
			num4 = 35;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 35;
						if ((int)array[5] != 1)
						{
							num5 = (int)array[1];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num5 + 56 + num2);
								num7 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + (int)array[4] + 56 + num2) + 56 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num7 + 40 + num2);
								if (num8 != -1)
								{
									num9 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num8 + 72 + num2);
									array[4] = num8;
									array[7] = 2;
									num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num8 + 72 + num2);
									goto IL_1A;
								}
								num7 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num7 + 56 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[0];
							num9 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num5 + 72 + num2);
							ex3 = ex2;
							array = (object[])array[3];
							array2 = new object[8];
							array2[5] = 0;
							array2[3] = array;
							array2[0] = ex2;
							array2[4] = num5;
							array2[7] = 1;
							array = array2;
							num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num5 + 72 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[6];
							array = (object[])array[3];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							List<GorillaPlayerScoreboardLine>.Enumerator enumerator;
							GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<GorillaPlayerScoreboardLine>&,GorillaPlayerScoreboardLine&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref gorillaPlayerScoreboardLine, Misc.NDataIsGenericMethod[num3]);
							continue;
						}
						num4 = 35;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num16 * 64 + 40 + num2);
						num18 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num16 * 64 + 24 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num7 * 64 + 32 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num15 * 64 + 40 + num2);
						num6 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num15 * 64 + 24 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num7 * 64 + 32 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num16 * 80 + 56 + num2);
						num18 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num16 * 80 + 24 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num7 * 80 + 40 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A7A:
						if (array == null || (int)array[5] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num6 + 56 + num2);
								}
								else
								{
									num11 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 40 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 56 + num2);
									goto IL_A7A;
								}
							}
							goto IL_C18;
						}
						int num20 = (int)array[4];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 72 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num16 * 80 + 56 + num2);
								num11 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num16 * 80 + 24 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num5 * 80 + 40 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num7 + 56 + num2);
								}
								else
								{
									num5 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 40 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 56 + num2);
									goto IL_A7A;
								}
							}
							break;
						}
						if ((int)array[4] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[3];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num5 + 72 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[3] = array;
					array2[6] = num12;
					array2[4] = num5;
					array2[7] = 2;
					array = array2;
					num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num5 + 72 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C18:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num11 + 72 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[3] = array;
					array2[6] = num12;
					array2[4] = num11;
					array2[7] = 2;
					array = array2;
					num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num11 + 72 + num2);
				}
				num4 = 35;
				return;
				IL_1CC:
				if (num15 != -1)
				{
					goto IL_1D7;
				}
				goto IL_3FF;
				IL_1D7:
				num6 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num15 + 24 + num2);
				if (3 == num6)
				{
					goto IL_1F6;
				}
				if (1 == num6)
				{
					goto IL_388;
				}
				goto IL_3FF;
				IL_1F6:
				num11 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num15 + 40 + num2);
				if (num11 == -1)
				{
					goto IL_244;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_22A;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_22A:
				if (type.IsInstanceOfType(array2[0]))
				{
					goto IL_244;
				}
				num15 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num15 + 48 + num2);
				goto IL_1CC;
				IL_244:
				num19 = num15;
				num14 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 56 + num2) + 56 + num2);
				num7 = (int)array2[2];
				IL_268:
				if (num7 != num14)
				{
					goto IL_2E7;
				}
				num16 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 72 + num2);
				ex3 = array2[0];
				array = (object[])array[3];
				object[] array5 = new object[8];
				array5[5] = 0;
				array5[3] = array;
				array5[0] = array2[0];
				array5[2] = (int)array2[2];
				array5[4] = num19;
				array5[7] = 1;
				array = array5;
				num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 72 + num2);
				goto IL_1A;
				IL_2E7:
				num9 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num7 + 40 + num2);
				if (num9 == -1)
				{
					goto IL_376;
				}
				num16 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num9 + 72 + num2);
				array = (object[])array[3];
				array5 = new object[8];
				array5[5] = 0;
				array5[3] = array;
				array5[0] = array2[0];
				array5[2] = (int)array2[2];
				array5[4] = num9;
				array5[1] = num19;
				array5[7] = 2;
				array = array5;
				num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num9 + 72 + num2);
				goto IL_1A;
				IL_376:
				num7 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num7 + 56 + num2);
				goto IL_268;
				IL_388:
				num16 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num15 + 8 + num2);
				ex3 = array2[0];
				array = (object[])array[3];
				array5 = new object[8];
				array5[5] = 0;
				array5[3] = array;
				array5[0] = array2[0];
				array5[2] = (int)array2[2];
				array5[4] = num15;
				array5[7] = 0;
				array = array5;
				num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num15 + 8 + num2);
				goto IL_1A;
				IL_3FF:
				array = (object[])array[3];
				ex = array2[0];
				int num23 = (int)array2[2];
				IL_41E:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_42C:
				num8 = (num17 + num18) / 2;
				num5 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num8 * 64 + 40 + num2);
				num22 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num8 * 64 + 24 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_472;
				}
				if (num5 > num16)
				{
					goto IL_47A;
				}
				num14 = num8;
				num19 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 160 + num14 * 64 + 32 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4A2;
				IL_472:
				num17 = num8 + 1;
				goto IL_42C;
				IL_47A:
				num18 = num8 - 1;
				goto IL_42C;
				IL_4A2:
				if (array != null)
				{
					goto IL_4AD;
				}
				goto IL_63C;
				IL_4AD:
				if ((int)array[5] != 1)
				{
					goto IL_56D;
				}
				int num24 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_4D1;
				}
				int num25 = -1;
				goto IL_554;
				IL_4D1:
				int num26 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num11 + 72 + num2);
				num22 = 0;
				num5 = 2;
				IL_4E4:
				num8 = (num22 + num5) / 2;
				num18 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num8 * 80 + 56 + num2);
				num17 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num8 * 80 + 24 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_52A;
				}
				if (num18 > num26)
				{
					goto IL_532;
				}
				num19 = num8;
				num14 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num19 * 80 + 40 + num2);
				num25 = num14;
				goto IL_554;
				IL_52A:
				num22 = num8 + 1;
				goto IL_4E4;
				IL_532:
				num5 = num8 - 1;
				goto IL_4E4;
				IL_554:
				if (num24 != num25)
				{
					goto IL_55C;
				}
				goto IL_63C;
				IL_55C:
				array = (object[])array[3];
				goto IL_4A2;
				IL_56D:
				num9 = (int)array[7];
				if (num9 == 1 || num9 == 2)
				{
					goto IL_58E;
				}
				if (num9 != 0)
				{
					goto IL_58D;
				}
				array2 = array;
				num15 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + (int)array2[4] + 48 + num2);
				goto IL_1CC;
				IL_58D:
				IL_58E:
				int num27 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_5A3;
				}
				int num28 = -1;
				goto IL_626;
				IL_5A3:
				num16 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num11 + 72 + num2);
				num17 = 0;
				num18 = 2;
				IL_5B6:
				num8 = (num17 + num18) / 2;
				num5 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num8 * 80 + 56 + num2);
				num22 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num8 * 80 + 24 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5FC;
				}
				if (num5 > num16)
				{
					goto IL_604;
				}
				num14 = num8;
				num19 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + 352 + num14 * 80 + 40 + num2);
				num28 = num19;
				goto IL_626;
				IL_5FC:
				num17 = num8 + 1;
				goto IL_5B6;
				IL_604:
				num18 = num8 - 1;
				goto IL_5B6;
				IL_626:
				if (num27 != num28)
				{
					goto IL_62B;
				}
				goto IL_63C;
				IL_62B:
				array = (object[])array[3];
				goto IL_4A2;
				IL_63C:
				if (-1 != num11)
				{
					goto IL_6E0;
				}
				num19 = num7;
				IL_649:
				if (num19 != -1)
				{
					goto IL_655;
				}
				num10 = 1;
				throw ex;
				IL_655:
				num14 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 40 + num2);
				if (num14 == -1)
				{
					goto IL_6CE;
				}
				num26 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num14 + 72 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[3] = array;
				array2[0] = ex;
				array2[2] = num7;
				array2[4] = -1;
				array2[1] = -1;
				array2[7] = 1;
				array = array2;
				num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num14 + 72 + num2);
				goto IL_1A;
				IL_6CE:
				num19 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num19 + 56 + num2);
				goto IL_649;
				IL_6E0:
				num6 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num11 + 24 + num2);
				num16 = num6;
				IL_6F1:
				if (num16 != -1)
				{
					goto IL_708;
				}
				num11 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num11 + 56 + num2);
				goto IL_4A2;
				IL_708:
				num18 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num16 + 24 + num2);
				if (3 == num18)
				{
					goto IL_733;
				}
				if (1 == num18)
				{
					goto IL_8A1;
				}
				num11 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num11 + 56 + num2);
				goto IL_4A2;
				IL_733:
				num17 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num16 + 40 + num2);
				if (num17 == -1)
				{
					goto IL_782;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_767;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_767:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_782;
				}
				num16 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num16 + 48 + num2);
				goto IL_6F1;
				IL_782:
				num26 = num16;
				num22 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num26 + 56 + num2) + 56 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7AB:
				if (num5 != num22)
				{
					goto IL_814;
				}
				int num29 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num26 + 72 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[3] = array;
				array2[0] = ex;
				array2[2] = num7;
				array2[4] = num26;
				array2[7] = 1;
				array = array2;
				num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num26 + 72 + num2);
				goto IL_1A;
				IL_814:
				num8 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num5 + 40 + num2);
				if (num8 == -1)
				{
					goto IL_88F;
				}
				num29 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num8 + 72 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[3] = array;
				array2[0] = ex;
				array2[2] = num7;
				array2[4] = num8;
				array2[1] = num26;
				array2[7] = 2;
				array = array2;
				num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num8 + 72 + num2);
				goto IL_1A;
				IL_88F:
				num5 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num5 + 56 + num2);
				goto IL_7AB;
				IL_8A1:
				num29 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num16 + 8 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[3] = array;
				array2[0] = ex;
				array2[2] = num7;
				array2[4] = num16;
				array2[7] = 0;
				array = array2;
				num3 = *(ref IOCompletionCallbackGetRuntimeProperty.DoubleArrayCOMServerImplementedClsid + num16 + 8 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_41E;
				}
				throw ex4;
			}
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x0001D85C File Offset: 0x0001BA5C
		public static void ConnectToAUServers()
		{
			int num = 65;
			int num2 = 65;
			num2 = 65;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 65;
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0001D894 File Offset: 0x0001BA94
		private static void IApplicationTrustManagergetMDStreamVersion(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			A_7.Dispose();
			A_1 = 4;
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x0001D8BC File Offset: 0x0001BABC
		public static void JoinRandom()
		{
			int num = 6;
			int num2 = 6;
			num2 = 6;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 6;
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x0001D8F0 File Offset: 0x0001BAF0
		private static void SharedIntNewobj(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			float num = Vector3.Distance(A_9.rightHandTransform.position, A_7.position);
			A_11 = num;
			float num2 = Vector3.Distance(A_9.leftHandTransform.position, A_7.position);
			A_12 = num2;
			float num3 = 1.25f;
			A_13 = num3;
			int num4 = (((A_11 < A_13) * true) ? 1 : 0) + 20;
			A_0 = num4;
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x0001D9B0 File Offset: 0x0001BBB0
		private static void EncodedTypeNever(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			A_4.Dispose();
			A_1 = 1;
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x0001D9D8 File Offset: 0x0001BBD8
		private static void UnrestrictedIsolatedStorageCheckOpenSubKeyPermission(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetwork.ConnectToRegion("eu");
			A_1 = 0;
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x0001D9FC File Offset: 0x0001BBFC
		public static void ConnectToUSWServers()
		{
			int num = 64;
			int num2 = 64;
			num2 = 64;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 64;
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x0001DA34 File Offset: 0x0001BC34
		private static void LocalBoolExclusiveScheduler(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine = A_4.Current;
			A_5 = gorillaPlayerScoreboardLine;
			bool flag = A_5.linePlayer == NetworkSystem.Instance.LocalPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 15 + 14;
			A_0 = num;
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x0001DAC0 File Offset: 0x0001BCC0
		public unsafe static void ReportAll()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 42;
			int num4 = 42;
			num4 = 42;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num23;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 42;
						if ((int)array[4] != 1)
						{
							num5 = (int)array[2];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num5 + 56 + num2);
								num7 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + (int)array[0] + 56 + num2) + 40 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num7 + num2);
								if (num8 != -1)
								{
									num9 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num8 + 8 + num2);
									array[0] = num8;
									array[1] = 1;
									num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num8 + 8 + num2);
									goto IL_1A;
								}
								num7 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num7 + 40 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[7];
							num9 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num5 + 8 + num2);
							ex3 = ex2;
							array = (object[])array[6];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								default(object),
								0,
								default(object),
								array,
								ex2
							};
							array2[0] = num5;
							array2[1] = 0;
							array = array2;
							num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num5 + 8 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[3];
							array = (object[])array[6];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							Player[] array3;
							int num14;
							Player player;
							List<GorillaPlayerScoreboardLine>.Enumerator enumerator;
							GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,Photon.Realtime.Player[]&,System.Int32&,Photon.Realtime.Player&,System.Collections.Generic.List`1/Enumerator<GorillaPlayerScoreboardLine>&,GorillaPlayerScoreboardLine&), ref num3, ref num4, ref num13, ex3, ref array3, ref num14, ref player, ref enumerator, ref gorillaPlayerScoreboardLine, Misc.NDataIsGenericMethod[num3]);
							continue;
						}
						num4 = 42;
						num8 = num13;
						num12 = num8;
					}
					num15 = num3;
					num6 = num15;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num17 * 40 + 16 + num2);
						num19 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num17 * 40 + 32 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num9 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num7 * 40 + num2);
					num20 = num9;
					num19 = num12;
					num18 = 0;
					num17 = 2;
					for (;;)
					{
						num16 = (num18 + num17) / 2;
						num11 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num16 * 40 + 16 + num2);
						num6 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num16 * 40 + 32 + num2);
						if (num19 < num11 + num6)
						{
							if (num11 <= num19)
							{
								break;
							}
							num17 = num16 - 1;
						}
						else
						{
							num18 = num16 + 1;
						}
					}
					num7 = num16;
					num8 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num7 * 40 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num17 * 40 + 16 + num2);
						num19 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num17 * 40 + 32 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num5 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num7 * 40 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A50:
						if (array == null || (int)array[4] == 1)
						{
							num6 = num9;
							while (num6 != num20)
							{
								if (num6 != -1)
								{
									num6 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num6 + 40 + num2);
								}
								else
								{
									num11 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num20 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + 40 + num2);
									goto IL_A50;
								}
							}
							goto IL_BE5;
						}
						int num21 = (int)array[0];
						int num22;
						if (num20 == -1)
						{
							num22 = -1;
						}
						else
						{
							num23 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + 8 + num2);
							num19 = 0;
							num18 = 2;
							for (;;)
							{
								num17 = (num19 + num18) / 2;
								num16 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num17 * 40 + 16 + num2);
								num11 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num17 * 40 + 32 + num2);
								if (num23 < num16 + num11)
								{
									if (num16 <= num23)
									{
										break;
									}
									num18 = num17 - 1;
								}
								else
								{
									num19 = num17 + 1;
								}
							}
							num5 = num17;
							num7 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num5 * 40 + num2);
							num22 = num7;
						}
						if (num21 == num22)
						{
							num7 = num9;
							while (num7 != num20)
							{
								if (num7 != -1)
								{
									num7 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num7 + 40 + num2);
								}
								else
								{
									num5 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num20 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + 40 + num2);
									goto IL_A50;
								}
							}
							break;
						}
						if ((int)array[0] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[6];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num5 + 8 + num2);
					array2 = new object[8];
					array2[4] = 1;
					array2[6] = array;
					array2[3] = num12;
					array2[0] = num5;
					array2[1] = 1;
					array = array2;
					num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num5 + 8 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_BE5:
					num3 = num12;
					continue;
					Block_62:
					num16 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num11 + 8 + num2);
					array2 = new object[8];
					array2[4] = 1;
					array2[6] = array;
					array2[3] = num12;
					array2[0] = num11;
					array2[1] = 1;
					array = array2;
					num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num11 + 8 + num2);
				}
				num4 = 42;
				return;
				IL_1CB:
				if (num16 != -1)
				{
					goto IL_1D6;
				}
				goto IL_3F6;
				IL_1D6:
				num6 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num16 + 88 + num2);
				if (2 == num6)
				{
					goto IL_1F5;
				}
				if (4 == num6)
				{
					goto IL_37D;
				}
				goto IL_3F6;
				IL_1F5:
				num11 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num16 + num2);
				if (num11 == -1)
				{
					goto IL_240;
				}
				Type[] array4;
				Type type;
				if ((type = array4[num11]) != null)
				{
					goto IL_226;
				}
				RuntimeTypeHandle[] array5;
				array4[num11] = Type.GetTypeFromHandle(array5[num11]);
				type = array4[num11];
				IL_226:
				if (type.IsInstanceOfType(array2[7]))
				{
					goto IL_240;
				}
				num16 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num16 + 64 + num2);
				goto IL_1CB;
				IL_240:
				num20 = num16;
				num15 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + 56 + num2) + 40 + num2);
				num7 = (int)array2[5];
				IL_264:
				if (num7 != num15)
				{
					goto IL_2E1;
				}
				num17 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + 8 + num2);
				ex3 = array2[7];
				array = (object[])array[6];
				object[] array6 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					array2[7]
				};
				array6[5] = (int)array2[5];
				array6[0] = num20;
				array6[1] = 0;
				array = array6;
				num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + 8 + num2);
				goto IL_1A;
				IL_2E1:
				num9 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num7 + num2);
				if (num9 == -1)
				{
					goto IL_36B;
				}
				num17 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num9 + 8 + num2);
				array = (object[])array[6];
				array6 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					array2[7]
				};
				array6[5] = (int)array2[5];
				array6[0] = num9;
				array6[2] = num20;
				array6[1] = 1;
				array = array6;
				num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num9 + 8 + num2);
				goto IL_1A;
				IL_36B:
				num7 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num7 + 40 + num2);
				goto IL_264;
				IL_37D:
				num17 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num16 + 96 + num2);
				ex3 = array2[7];
				array = (object[])array[6];
				array6 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					array2[7]
				};
				array6[5] = (int)array2[5];
				array6[0] = num16;
				array6[1] = 2;
				array = array6;
				num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num16 + 96 + num2);
				goto IL_1A;
				IL_3F6:
				array = (object[])array[6];
				ex = array2[7];
				int num24 = (int)array2[5];
				IL_415:
				num16 = num3;
				num17 = num16;
				num18 = 0;
				num19 = 2;
				IL_423:
				num8 = (num18 + num19) / 2;
				num5 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num8 * 40 + 16 + num2);
				num23 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num8 * 40 + 32 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_469;
				}
				if (num5 > num17)
				{
					goto IL_471;
				}
				num15 = num8;
				num20 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 176 + num15 * 40 + num2);
				num11 = num20;
				num7 = num11;
				goto IL_496;
				IL_469:
				num18 = num8 + 1;
				goto IL_423;
				IL_471:
				num19 = num8 - 1;
				goto IL_423;
				IL_496:
				if (array != null)
				{
					goto IL_4A1;
				}
				goto IL_628;
				IL_4A1:
				if ((int)array[4] != 1)
				{
					goto IL_55D;
				}
				int num25 = (int)array[0];
				if (num11 != -1)
				{
					goto IL_4C5;
				}
				int num26 = -1;
				goto IL_544;
				IL_4C5:
				int num27 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num11 + 8 + num2);
				num23 = 0;
				num5 = 2;
				IL_4D7:
				num8 = (num23 + num5) / 2;
				num19 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num8 * 40 + 16 + num2);
				num18 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num8 * 40 + 32 + num2);
				if (num27 >= num19 + num18)
				{
					goto IL_51D;
				}
				if (num19 > num27)
				{
					goto IL_525;
				}
				num20 = num8;
				num15 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num20 * 40 + num2);
				num26 = num15;
				goto IL_544;
				IL_51D:
				num23 = num8 + 1;
				goto IL_4D7;
				IL_525:
				num5 = num8 - 1;
				goto IL_4D7;
				IL_544:
				if (num25 != num26)
				{
					goto IL_54C;
				}
				goto IL_628;
				IL_54C:
				array = (object[])array[6];
				goto IL_496;
				IL_55D:
				num9 = (int)array[1];
				if (num9 == 0 || num9 == 1)
				{
					goto IL_57E;
				}
				if (num9 != 2)
				{
					goto IL_57D;
				}
				array2 = array;
				num16 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + (int)array2[0] + 64 + num2);
				goto IL_1CB;
				IL_57D:
				IL_57E:
				int num28 = (int)array[0];
				if (num11 != -1)
				{
					goto IL_593;
				}
				int num29 = -1;
				goto IL_612;
				IL_593:
				num17 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num11 + 8 + num2);
				num18 = 0;
				num19 = 2;
				IL_5A5:
				num8 = (num18 + num19) / 2;
				num5 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num8 * 40 + 16 + num2);
				num23 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num8 * 40 + 32 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_5EB;
				}
				if (num5 > num17)
				{
					goto IL_5F3;
				}
				num15 = num8;
				num20 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + 296 + num15 * 40 + num2);
				num29 = num20;
				goto IL_612;
				IL_5EB:
				num18 = num8 + 1;
				goto IL_5A5;
				IL_5F3:
				num19 = num8 - 1;
				goto IL_5A5;
				IL_612:
				if (num28 != num29)
				{
					goto IL_617;
				}
				goto IL_628;
				IL_617:
				array = (object[])array[6];
				goto IL_496;
				IL_628:
				if (-1 != num11)
				{
					goto IL_6C7;
				}
				num20 = num7;
				IL_635:
				if (num20 != -1)
				{
					goto IL_641;
				}
				num10 = 1;
				throw ex;
				IL_641:
				num15 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + num2);
				if (num15 == -1)
				{
					goto IL_6B5;
				}
				num27 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num15 + 8 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					ex
				};
				array2[5] = num7;
				array2[0] = -1;
				array2[2] = -1;
				array2[1] = 0;
				array = array2;
				num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num15 + 8 + num2);
				goto IL_1A;
				IL_6B5:
				num20 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num20 + 40 + num2);
				goto IL_635;
				IL_6C7:
				num6 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num11 + 56 + num2);
				num17 = num6;
				IL_6D8:
				if (num17 != -1)
				{
					goto IL_6EF;
				}
				num11 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num11 + 40 + num2);
				goto IL_496;
				IL_6EF:
				num19 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num17 + 88 + num2);
				if (2 == num19)
				{
					goto IL_71A;
				}
				if (4 == num19)
				{
					goto IL_87E;
				}
				num11 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num11 + 40 + num2);
				goto IL_496;
				IL_71A:
				num18 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num17 + num2);
				if (num18 == -1)
				{
					goto IL_766;
				}
				Type type2;
				if ((type2 = array4[num18]) != null)
				{
					goto IL_74B;
				}
				array4[num18] = Type.GetTypeFromHandle(array5[num18]);
				type2 = array4[num18];
				IL_74B:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_766;
				}
				num17 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num17 + 64 + num2);
				goto IL_6D8;
				IL_766:
				num27 = num17;
				num23 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num27 + 56 + num2) + 40 + num2);
				num5 = (num7 - num24) * ((num24 == -1) ? 1 : 0) + num24;
				IL_78F:
				if (num5 != num23)
				{
					goto IL_7F6;
				}
				int num30 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num27 + 8 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					ex
				};
				array2[5] = num7;
				array2[0] = num27;
				array2[1] = 0;
				array = array2;
				num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num27 + 8 + num2);
				goto IL_1A;
				IL_7F6:
				num8 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num5 + num2);
				if (num8 == -1)
				{
					goto IL_86C;
				}
				num30 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num8 + 8 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					ex
				};
				array2[5] = num7;
				array2[0] = num8;
				array2[2] = num27;
				array2[1] = 1;
				array = array2;
				num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num8 + 8 + num2);
				goto IL_1A;
				IL_86C:
				num5 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num5 + 40 + num2);
				goto IL_78F;
				IL_87E:
				num30 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num17 + 96 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					ex
				};
				array2[5] = num7;
				array2[0] = num17;
				array2[1] = 2;
				array = array2;
				num3 = *(ref getDoNotAddrOfCspParentWindowHandleBraceFormat.NoAccessRegisterWaitForSingleObject + num17 + 96 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num24 = -1;
					goto IL_415;
				}
				throw ex4;
			}
		}

		// Token: 0x06000434 RID: 1076 RVA: 0x0001E768 File Offset: 0x0001C968
		private static void BrowserStopAssociates(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -2 + 56;
			A_0 = num;
		}

		// Token: 0x06000435 RID: 1077 RVA: 0x0001E7B0 File Offset: 0x0001C9B0
		public static void dnt()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x0001E7E4 File Offset: 0x0001C9E4
		private static void OnDeserializedClassesRoot(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			A_0 = 55;
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x0001E7FC File Offset: 0x0001C9FC
		private static void setTargetFrameworkNameUnionCodeGroup(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 31;
			A_0 = num;
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0001E844 File Offset: 0x0001CA44
		private static void AbsentOriginSchemegetDeclaredNestedTypesd(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			int num = (A_7.MoveNext() ? 1 : 0) * -2 + 47;
			A_0 = num;
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x0001E88C File Offset: 0x0001CA8C
		public unsafe static void AntiReport()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 11;
			int num4 = 11;
			num4 = 11;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num17;
				int num18;
				int num19;
				int num20;
				int num21;
				int num22;
				int num25;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 11;
						if ((int)array[2] != 0)
						{
							num5 = (int)array[0];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num5 + 32 + num2);
								num7 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + (int)array[3] + 32 + num2) + 16 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num7 + 24 + num2);
								if (num8 != -1)
								{
									num9 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num8 + 48 + num2);
									array[3] = num8;
									array[4] = 1;
									num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num8 + 48 + num2);
									goto IL_1A;
								}
								num7 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num7 + 16 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[7];
							num9 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num5 + 48 + num2);
							ex3 = ex2;
							array = (object[])array[6];
							array2 = new object[]
							{
								default(object),
								default(object),
								1,
								default(object),
								default(object),
								default(object),
								array,
								ex2
							};
							array2[3] = num5;
							array2[4] = 0;
							array = array2;
							num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num5 + 48 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[5];
							array = (object[])array[6];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 5)
						{
							List<GorillaPlayerScoreboardLine>.Enumerator enumerator;
							GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine;
							bool flag;
							Transform transform;
							List<VRRig>.Enumerator enumerator2;
							VRRig vrrig;
							bool flag2;
							float num14;
							float num15;
							float num16;
							bool flag3;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<GorillaPlayerScoreboardLine>&,GorillaPlayerScoreboardLine&,System.Boolean&,UnityEngine.Transform&,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Single&,System.Single&,System.Single&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref gorillaPlayerScoreboardLine, ref flag, ref transform, ref enumerator2, ref vrrig, ref flag2, ref num14, ref num15, ref num16, ref flag3, Misc.NDataIsGenericMethod[num3]);
							continue;
						}
						num4 = 11;
						num8 = num13;
						num12 = num8;
					}
					num17 = num3;
					num6 = num17;
					num11 = 0;
					num18 = 4;
					for (;;)
					{
						num19 = (num11 + num18) / 2;
						num20 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num19 * 56 + 16 + num2);
						num21 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num19 * 56 + 40 + num2);
						if (num6 < num20 + num21)
						{
							if (num20 <= num6)
							{
								break;
							}
							num18 = num19 - 1;
						}
						else
						{
							num11 = num19 + 1;
						}
					}
					num7 = num19;
					num9 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num7 * 56 + 8 + num2);
					num22 = num9;
					num21 = num12;
					num20 = 0;
					num19 = 4;
					for (;;)
					{
						num18 = (num20 + num19) / 2;
						num11 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num18 * 56 + 16 + num2);
						num6 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num18 * 56 + 40 + num2);
						if (num21 < num11 + num6)
						{
							if (num11 <= num21)
							{
								break;
							}
							num19 = num18 - 1;
						}
						else
						{
							num20 = num18 + 1;
						}
					}
					num7 = num18;
					num8 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num7 * 56 + 8 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num18 = 4;
					for (;;)
					{
						num19 = (num11 + num18) / 2;
						num20 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num19 * 56 + 16 + num2);
						num21 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num19 * 56 + 40 + num2);
						if (num6 < num20 + num21)
						{
							if (num20 <= num6)
							{
								break;
							}
							num18 = num19 - 1;
						}
						else
						{
							num11 = num19 + 1;
						}
					}
					num7 = num19;
					num5 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num7 * 56 + 8 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A8A:
						if (array == null || (int)array[2] == 0)
						{
							num6 = num9;
							while (num6 != num22)
							{
								if (num6 != -1)
								{
									num6 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num6 + 16 + num2);
								}
								else
								{
									num11 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 24 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num22 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 16 + num2);
									goto IL_A8A;
								}
							}
							goto IL_C27;
						}
						int num23 = (int)array[3];
						int num24;
						if (num22 == -1)
						{
							num24 = -1;
						}
						else
						{
							num25 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 32 + num2);
							num21 = 0;
							num20 = 4;
							for (;;)
							{
								num19 = (num21 + num20) / 2;
								num18 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num19 * 56 + 16 + num2);
								num11 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num19 * 56 + 40 + num2);
								if (num25 < num18 + num11)
								{
									if (num18 <= num25)
									{
										break;
									}
									num20 = num19 - 1;
								}
								else
								{
									num21 = num19 + 1;
								}
							}
							num5 = num19;
							num7 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num5 * 56 + 8 + num2);
							num24 = num7;
						}
						if (num23 == num24)
						{
							num7 = num9;
							while (num7 != num22)
							{
								if (num7 != -1)
								{
									num7 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num7 + 16 + num2);
								}
								else
								{
									num5 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 24 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num22 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 16 + num2);
									goto IL_A8A;
								}
							}
							break;
						}
						if ((int)array[3] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[6];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num5 + 48 + num2);
					array2 = new object[8];
					array2[2] = 0;
					array2[6] = array;
					array2[5] = num12;
					array2[3] = num5;
					array2[4] = 1;
					array = array2;
					num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num5 + 48 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C27:
					num3 = num12;
					continue;
					Block_62:
					num18 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num11 + 48 + num2);
					array2 = new object[8];
					array2[2] = 0;
					array2[6] = array;
					array2[5] = num12;
					array2[3] = num11;
					array2[4] = 1;
					array = array2;
					num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num11 + 48 + num2);
				}
				num4 = 11;
				return;
				IL_1DE:
				if (num18 != -1)
				{
					goto IL_1E9;
				}
				goto IL_413;
				IL_1E9:
				num6 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num18 + 72 + num2);
				if (1 == num6)
				{
					goto IL_208;
				}
				if (3 == num6)
				{
					goto IL_39A;
				}
				goto IL_413;
				IL_208:
				num11 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num18 + 24 + num2);
				if (num11 == -1)
				{
					goto IL_256;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_23C;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_23C:
				if (type.IsInstanceOfType(array2[7]))
				{
					goto IL_256;
				}
				num18 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num18 + 56 + num2);
				goto IL_1DE;
				IL_256:
				num22 = num18;
				num17 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 32 + num2) + 16 + num2);
				num7 = (int)array2[1];
				IL_27A:
				if (num7 != num17)
				{
					goto IL_2F9;
				}
				num19 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 48 + num2);
				ex3 = array2[7];
				array = (object[])array[6];
				object[] array5 = new object[]
				{
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array,
					array2[7]
				};
				array5[1] = (int)array2[1];
				array5[3] = num22;
				array5[4] = 0;
				array = array5;
				num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 48 + num2);
				goto IL_1A;
				IL_2F9:
				num9 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num7 + 24 + num2);
				if (num9 == -1)
				{
					goto IL_388;
				}
				num19 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num9 + 48 + num2);
				array = (object[])array[6];
				array5 = new object[]
				{
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array,
					array2[7]
				};
				array5[1] = (int)array2[1];
				array5[3] = num9;
				array5[0] = num22;
				array5[4] = 1;
				array = array5;
				num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num9 + 48 + num2);
				goto IL_1A;
				IL_388:
				num7 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num7 + 16 + num2);
				goto IL_27A;
				IL_39A:
				num19 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num18 + 88 + num2);
				ex3 = array2[7];
				array = (object[])array[6];
				array5 = new object[]
				{
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array,
					array2[7]
				};
				array5[1] = (int)array2[1];
				array5[3] = num18;
				array5[4] = 2;
				array = array5;
				num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num18 + 88 + num2);
				goto IL_1A;
				IL_413:
				array = (object[])array[6];
				ex = array2[7];
				int num26 = (int)array2[1];
				IL_432:
				num18 = num3;
				num19 = num18;
				num20 = 0;
				num21 = 4;
				IL_440:
				num8 = (num20 + num21) / 2;
				num5 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num8 * 56 + 16 + num2);
				num25 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num8 * 56 + 40 + num2);
				if (num19 >= num5 + num25)
				{
					goto IL_486;
				}
				if (num5 > num19)
				{
					goto IL_48E;
				}
				num17 = num8;
				num22 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 320 + num17 * 56 + 8 + num2);
				num11 = num22;
				num7 = num11;
				goto IL_4B5;
				IL_486:
				num20 = num8 + 1;
				goto IL_440;
				IL_48E:
				num21 = num8 - 1;
				goto IL_440;
				IL_4B5:
				if (array != null)
				{
					goto IL_4C0;
				}
				goto IL_64D;
				IL_4C0:
				if ((int)array[2] != 0)
				{
					goto IL_57F;
				}
				int num27 = (int)array[3];
				if (num11 != -1)
				{
					goto IL_4E4;
				}
				int num28 = -1;
				goto IL_566;
				IL_4E4:
				int num29 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num11 + 32 + num2);
				num25 = 0;
				num5 = 4;
				IL_4F7:
				num8 = (num25 + num5) / 2;
				num21 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num8 * 56 + 16 + num2);
				num20 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num8 * 56 + 40 + num2);
				if (num29 >= num21 + num20)
				{
					goto IL_53D;
				}
				if (num21 > num29)
				{
					goto IL_545;
				}
				num22 = num8;
				num17 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num22 * 56 + 8 + num2);
				num28 = num17;
				goto IL_566;
				IL_53D:
				num25 = num8 + 1;
				goto IL_4F7;
				IL_545:
				num5 = num8 - 1;
				goto IL_4F7;
				IL_566:
				if (num27 != num28)
				{
					goto IL_56E;
				}
				goto IL_64D;
				IL_56E:
				array = (object[])array[6];
				goto IL_4B5;
				IL_57F:
				num9 = (int)array[4];
				if (num9 == 0 || num9 == 1)
				{
					goto IL_5A0;
				}
				if (num9 != 2)
				{
					goto IL_59F;
				}
				array2 = array;
				num18 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + (int)array2[3] + 56 + num2);
				goto IL_1DE;
				IL_59F:
				IL_5A0:
				int num30 = (int)array[3];
				if (num11 != -1)
				{
					goto IL_5B5;
				}
				int num31 = -1;
				goto IL_637;
				IL_5B5:
				num19 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num11 + 32 + num2);
				num20 = 0;
				num21 = 4;
				IL_5C8:
				num8 = (num20 + num21) / 2;
				num5 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num8 * 56 + 16 + num2);
				num25 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num8 * 56 + 40 + num2);
				if (num19 >= num5 + num25)
				{
					goto IL_60E;
				}
				if (num5 > num19)
				{
					goto IL_616;
				}
				num17 = num8;
				num22 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + 600 + num17 * 56 + 8 + num2);
				num31 = num22;
				goto IL_637;
				IL_60E:
				num20 = num8 + 1;
				goto IL_5C8;
				IL_616:
				num21 = num8 - 1;
				goto IL_5C8;
				IL_637:
				if (num30 != num31)
				{
					goto IL_63C;
				}
				goto IL_64D;
				IL_63C:
				array = (object[])array[6];
				goto IL_4B5;
				IL_64D:
				if (-1 != num11)
				{
					goto IL_6F1;
				}
				num22 = num7;
				IL_65A:
				if (num22 != -1)
				{
					goto IL_666;
				}
				num10 = 1;
				throw ex;
				IL_666:
				num17 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 24 + num2);
				if (num17 == -1)
				{
					goto IL_6DF;
				}
				num29 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num17 + 48 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array,
					ex
				};
				array2[1] = num7;
				array2[3] = -1;
				array2[0] = -1;
				array2[4] = 0;
				array = array2;
				num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num17 + 48 + num2);
				goto IL_1A;
				IL_6DF:
				num22 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num22 + 16 + num2);
				goto IL_65A;
				IL_6F1:
				num6 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num11 + 48 + num2);
				num19 = num6;
				IL_702:
				if (num19 != -1)
				{
					goto IL_719;
				}
				num11 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num11 + 16 + num2);
				goto IL_4B5;
				IL_719:
				num21 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num19 + 72 + num2);
				if (1 == num21)
				{
					goto IL_744;
				}
				if (3 == num21)
				{
					goto IL_8B2;
				}
				num11 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num11 + 16 + num2);
				goto IL_4B5;
				IL_744:
				num20 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num19 + 24 + num2);
				if (num20 == -1)
				{
					goto IL_793;
				}
				Type type2;
				if ((type2 = array3[num20]) != null)
				{
					goto IL_778;
				}
				array3[num20] = Type.GetTypeFromHandle(array4[num20]);
				type2 = array3[num20];
				IL_778:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_793;
				}
				num19 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num19 + 56 + num2);
				goto IL_702;
				IL_793:
				num29 = num19;
				num25 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num29 + 32 + num2) + 16 + num2);
				num5 = (num7 - num26) * ((num26 == -1) ? 1 : 0) + num26;
				IL_7BC:
				if (num5 != num25)
				{
					goto IL_825;
				}
				int num32 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num29 + 48 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array,
					ex
				};
				array2[1] = num7;
				array2[3] = num29;
				array2[4] = 0;
				array = array2;
				num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num29 + 48 + num2);
				goto IL_1A;
				IL_825:
				num8 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num5 + 24 + num2);
				if (num8 == -1)
				{
					goto IL_8A0;
				}
				num32 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num8 + 48 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array,
					ex
				};
				array2[1] = num7;
				array2[3] = num8;
				array2[0] = num29;
				array2[4] = 1;
				array = array2;
				num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num8 + 48 + num2);
				goto IL_1A;
				IL_8A0:
				num5 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num5 + 16 + num2);
				goto IL_7BC;
				IL_8B2:
				num32 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num19 + 88 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array,
					ex
				};
				array2[1] = num7;
				array2[3] = num19;
				array2[4] = 2;
				array = array2;
				num3 = *(ref getSystemDirectoryFreeHString.PercentNegativePatternGetSymAttribute + num19 + 88 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num26 = -1;
					goto IL_432;
				}
				throw ex4;
			}
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x0001F578 File Offset: 0x0001D778
		private static void IsConstVersionAdded(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("<$SELENITE$>", 0);
			A_1 = 0;
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0001F5A8 File Offset: 0x0001D7A8
		private static void IsCurrentActivityActivegetSupportsDaylightSavingTime(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			A_0 = 46;
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x0001F5C0 File Offset: 0x0001D7C0
		private static void getLoaderExceptionsGetMinThreads(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			int num = (A_8.MoveNext() ? 1 : 0) * -10 + 26;
			A_0 = num;
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x0001F608 File Offset: 0x0001D808
		private static string GetCharsStsfld(ref int A_0, ref int A_1, ref int A_2, ref Random A_3, ref char[] A_4, ref int A_5, ref bool A_6, ref string A_7, int A_8)
		{
			A_4[A_5] = Misc.chars[A_3.Next(Misc.chars.Length)];
			int num = A_5 + 1;
			A_5 = num;
			bool flag = A_5 < A_8;
			A_6 = flag;
			int num2 = (A_6 ? 1 : 0) * -2 + 73;
			A_0 = num2;
			string result;
			return result;
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x0001F6C4 File Offset: 0x0001D8C4
		private static void ISymbolVariableIsStatic(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -2 + 39;
			A_0 = num;
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x0001F70C File Offset: 0x0001D90C
		public Misc()
		{
			int num = 75;
			int num2 = 75;
			num2 = 75;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.Misc), ref num, ref num2, ref num3, this, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 75;
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x0001F744 File Offset: 0x0001D944
		private static void getCategoryMembershipSectionGetSymWriter(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x0001F75C File Offset: 0x0001D95C
		private static void StrongNameSignatureGenerationFromFileTimeUtc(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			bool flag = !A_9.isMyPlayer;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 5 + 19;
			A_0 = num;
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0001F7CC File Offset: 0x0001D9CC
		public static void LobbyHop()
		{
			int num = 7;
			int num2 = 7;
			num2 = 7;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 7;
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x0001F800 File Offset: 0x0001DA00
		private static void AsDateStrict(ref int A_0, ref int A_1, ref int A_2, ref string A_3)
		{
			string name = PhotonNetwork.CurrentLobby.Name;
			A_3 = name;
			PhotonNetwork.Disconnect();
			PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(A_3, 0);
			A_1 = 0;
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x0001F854 File Offset: 0x0001DA54
		private static void getChannelSchemeGetFault(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			int num = (A_8.MoveNext() ? 1 : 0) * -10 + 26;
			A_0 = num;
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0001F89C File Offset: 0x0001DA9C
		private static void getXmlElementNameInvalidPathChars(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetwork.Disconnect();
			A_1 = 0;
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x0001F8BC File Offset: 0x0001DABC
		private static void IsolationInteropHebrewToken(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetwork.ConnectToRegion("au");
			A_1 = 0;
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x0001F8E0 File Offset: 0x0001DAE0
		public static void ConnectToUSServers()
		{
			int num = 63;
			int num2 = 63;
			num2 = 63;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 63;
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x0001F918 File Offset: 0x0001DB18
		private static void ParallelLoopResultCkfinite(ref int A_0, ref int A_1, ref int A_2)
		{
			PhotonNetwork.ConnectToRegion("us");
			A_1 = 0;
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0001F93C File Offset: 0x0001DB3C
		private static void UnlockSTOREASSEMBLYSTATUSMANIFESTONLY(ref int A_0, ref int A_1, ref int A_2)
		{
			Misc.cosmetictrigger.SetActive(true);
			A_1 = 0;
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x0001F964 File Offset: 0x0001DB64
		public unsafe static void UnMuteAll()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 52;
			int num4 = 52;
			num4 = 52;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 1)
					{
						num4 = 52;
						if ((int)array[4] != 1)
						{
							num5 = (int)array[2];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num5 + 56 + num2);
								num7 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + (int)array[0] + 56 + num2) + 40 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num7 + num2);
								if (num8 != -1)
								{
									num9 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num8 + 8 + num2);
									array[0] = num8;
									array[1] = 1;
									num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num8 + 8 + num2);
									goto IL_1A;
								}
								num7 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num7 + 40 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[7];
							num9 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num5 + 8 + num2);
							ex3 = ex2;
							array = (object[])array[6];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								default(object),
								0,
								default(object),
								array,
								ex2
							};
							array2[0] = num5;
							array2[1] = 0;
							array = array2;
							num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num5 + 8 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[3];
							array = (object[])array[6];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							List<GorillaPlayerScoreboardLine>.Enumerator enumerator;
							GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<GorillaPlayerScoreboardLine>&,GorillaPlayerScoreboardLine&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref gorillaPlayerScoreboardLine, Misc.NDataIsGenericMethod[num3]);
							continue;
						}
						num4 = 52;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num16 * 40 + 16 + num2);
						num18 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num16 * 40 + 32 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num7 * 40 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num15 * 40 + 16 + num2);
						num6 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num15 * 40 + 32 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num7 * 40 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num16 * 40 + 16 + num2);
						num18 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num16 * 40 + 32 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num7 * 40 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A4A:
						if (array == null || (int)array[4] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num6 + 40 + num2);
								}
								else
								{
									num11 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + 40 + num2);
									goto IL_A4A;
								}
							}
							goto IL_BDF;
						}
						int num20 = (int)array[0];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + 8 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num16 * 40 + 16 + num2);
								num11 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num16 * 40 + 32 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num5 * 40 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num7 + 40 + num2);
								}
								else
								{
									num5 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + 40 + num2);
									goto IL_A4A;
								}
							}
							break;
						}
						if ((int)array[0] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[6];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num5 + 8 + num2);
					array2 = new object[8];
					array2[4] = 1;
					array2[6] = array;
					array2[3] = num12;
					array2[0] = num5;
					array2[1] = 1;
					array = array2;
					num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num5 + 8 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_BDF:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num11 + 8 + num2);
					array2 = new object[8];
					array2[4] = 1;
					array2[6] = array;
					array2[3] = num12;
					array2[0] = num11;
					array2[1] = 1;
					array = array2;
					num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num11 + 8 + num2);
				}
				num4 = 52;
				return;
				IL_1C5:
				if (num15 != -1)
				{
					goto IL_1D0;
				}
				goto IL_3F0;
				IL_1D0:
				num6 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num15 + 88 + num2);
				if (2 == num6)
				{
					goto IL_1EF;
				}
				if (4 == num6)
				{
					goto IL_377;
				}
				goto IL_3F0;
				IL_1EF:
				num11 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num15 + num2);
				if (num11 == -1)
				{
					goto IL_23A;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_220;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_220:
				if (type.IsInstanceOfType(array2[7]))
				{
					goto IL_23A;
				}
				num15 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num15 + 64 + num2);
				goto IL_1C5;
				IL_23A:
				num19 = num15;
				num14 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + 56 + num2) + 40 + num2);
				num7 = (int)array2[5];
				IL_25E:
				if (num7 != num14)
				{
					goto IL_2DB;
				}
				num16 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + 8 + num2);
				ex3 = array2[7];
				array = (object[])array[6];
				object[] array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					array2[7]
				};
				array5[5] = (int)array2[5];
				array5[0] = num19;
				array5[1] = 0;
				array = array5;
				num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + 8 + num2);
				goto IL_1A;
				IL_2DB:
				num9 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num7 + num2);
				if (num9 == -1)
				{
					goto IL_365;
				}
				num16 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num9 + 8 + num2);
				array = (object[])array[6];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					array2[7]
				};
				array5[5] = (int)array2[5];
				array5[0] = num9;
				array5[2] = num19;
				array5[1] = 1;
				array = array5;
				num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num9 + 8 + num2);
				goto IL_1A;
				IL_365:
				num7 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num7 + 40 + num2);
				goto IL_25E;
				IL_377:
				num16 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num15 + 96 + num2);
				ex3 = array2[7];
				array = (object[])array[6];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					array2[7]
				};
				array5[5] = (int)array2[5];
				array5[0] = num15;
				array5[1] = 2;
				array = array5;
				num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num15 + 96 + num2);
				goto IL_1A;
				IL_3F0:
				array = (object[])array[6];
				ex = array2[7];
				int num23 = (int)array2[5];
				IL_40F:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_41D:
				num8 = (num17 + num18) / 2;
				num5 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num8 * 40 + 16 + num2);
				num22 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num8 * 40 + 32 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_463;
				}
				if (num5 > num16)
				{
					goto IL_46B;
				}
				num14 = num8;
				num19 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 176 + num14 * 40 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_490;
				IL_463:
				num17 = num8 + 1;
				goto IL_41D;
				IL_46B:
				num18 = num8 - 1;
				goto IL_41D;
				IL_490:
				if (array != null)
				{
					goto IL_49B;
				}
				goto IL_622;
				IL_49B:
				if ((int)array[4] != 1)
				{
					goto IL_557;
				}
				int num24 = (int)array[0];
				if (num11 != -1)
				{
					goto IL_4BF;
				}
				int num25 = -1;
				goto IL_53E;
				IL_4BF:
				int num26 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num11 + 8 + num2);
				num22 = 0;
				num5 = 2;
				IL_4D1:
				num8 = (num22 + num5) / 2;
				num18 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num8 * 40 + 16 + num2);
				num17 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num8 * 40 + 32 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_517;
				}
				if (num18 > num26)
				{
					goto IL_51F;
				}
				num19 = num8;
				num14 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num19 * 40 + num2);
				num25 = num14;
				goto IL_53E;
				IL_517:
				num22 = num8 + 1;
				goto IL_4D1;
				IL_51F:
				num5 = num8 - 1;
				goto IL_4D1;
				IL_53E:
				if (num24 != num25)
				{
					goto IL_546;
				}
				goto IL_622;
				IL_546:
				array = (object[])array[6];
				goto IL_490;
				IL_557:
				num9 = (int)array[1];
				if (num9 == 0 || num9 == 1)
				{
					goto IL_578;
				}
				if (num9 != 2)
				{
					goto IL_577;
				}
				array2 = array;
				num15 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + (int)array2[0] + 64 + num2);
				goto IL_1C5;
				IL_577:
				IL_578:
				int num27 = (int)array[0];
				if (num11 != -1)
				{
					goto IL_58D;
				}
				int num28 = -1;
				goto IL_60C;
				IL_58D:
				num16 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num11 + 8 + num2);
				num17 = 0;
				num18 = 2;
				IL_59F:
				num8 = (num17 + num18) / 2;
				num5 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num8 * 40 + 16 + num2);
				num22 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num8 * 40 + 32 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5E5;
				}
				if (num5 > num16)
				{
					goto IL_5ED;
				}
				num14 = num8;
				num19 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + 296 + num14 * 40 + num2);
				num28 = num19;
				goto IL_60C;
				IL_5E5:
				num17 = num8 + 1;
				goto IL_59F;
				IL_5ED:
				num18 = num8 - 1;
				goto IL_59F;
				IL_60C:
				if (num27 != num28)
				{
					goto IL_611;
				}
				goto IL_622;
				IL_611:
				array = (object[])array[6];
				goto IL_490;
				IL_622:
				if (-1 != num11)
				{
					goto IL_6C1;
				}
				num19 = num7;
				IL_62F:
				if (num19 != -1)
				{
					goto IL_63B;
				}
				num10 = 1;
				throw ex;
				IL_63B:
				num14 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + num2);
				if (num14 == -1)
				{
					goto IL_6AF;
				}
				num26 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num14 + 8 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					ex
				};
				array2[5] = num7;
				array2[0] = -1;
				array2[2] = -1;
				array2[1] = 0;
				array = array2;
				num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num14 + 8 + num2);
				goto IL_1A;
				IL_6AF:
				num19 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num19 + 40 + num2);
				goto IL_62F;
				IL_6C1:
				num6 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num11 + 56 + num2);
				num16 = num6;
				IL_6D2:
				if (num16 != -1)
				{
					goto IL_6E9;
				}
				num11 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num11 + 40 + num2);
				goto IL_490;
				IL_6E9:
				num18 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num16 + 88 + num2);
				if (2 == num18)
				{
					goto IL_714;
				}
				if (4 == num18)
				{
					goto IL_878;
				}
				num11 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num11 + 40 + num2);
				goto IL_490;
				IL_714:
				num17 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num16 + num2);
				if (num17 == -1)
				{
					goto IL_760;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_745;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_745:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_760;
				}
				num16 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num16 + 64 + num2);
				goto IL_6D2;
				IL_760:
				num26 = num16;
				num22 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num26 + 56 + num2) + 40 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_789:
				if (num5 != num22)
				{
					goto IL_7F0;
				}
				int num29 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num26 + 8 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					ex
				};
				array2[5] = num7;
				array2[0] = num26;
				array2[1] = 0;
				array = array2;
				num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num26 + 8 + num2);
				goto IL_1A;
				IL_7F0:
				num8 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num5 + num2);
				if (num8 == -1)
				{
					goto IL_866;
				}
				num29 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num8 + 8 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					ex
				};
				array2[5] = num7;
				array2[0] = num8;
				array2[2] = num26;
				array2[1] = 1;
				array = array2;
				num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num8 + 8 + num2);
				goto IL_1A;
				IL_866:
				num5 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num5 + 40 + num2);
				goto IL_789;
				IL_878:
				num29 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num16 + 96 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					array,
					ex
				};
				array2[5] = num7;
				array2[0] = num16;
				array2[1] = 2;
				array = array2;
				num3 = *(ref DecoderAuthenticationInstant.AppendFormatSetOpaque + num16 + 96 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_40F;
				}
				throw ex4;
			}
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x00020604 File Offset: 0x0001E804
		public static void ent()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 2;
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x00020638 File Offset: 0x0001E838
		private static void IApplicationContextConfigure(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			A_1 = 4;
			A_2 = 58;
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x0002065C File Offset: 0x0001E85C
		private static void ThreeLetterISOLanguageNameGetDefaultReader(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			List<GorillaPlayerScoreboardLine>.Enumerator enumerator = GorillaScoreboardTotalUpdater.allScoreboardLines.GetEnumerator();
			A_4 = enumerator;
			A_0 = 12;
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x00020690 File Offset: 0x0001E890
		public static string GenerateRandomString(int length = 4)
		{
			int num = 70;
			int num2 = 70;
			num2 = 70;
			string result;
			while (num2 != 0)
			{
				int num3;
				Random random;
				char[] array;
				int num4;
				bool flag;
				string text;
				result = calli(System.String(System.Int32&,System.Int32&,System.Int32&,System.Random&,System.Char[]&,System.Int32&,System.Boolean&,System.String&,System.Int32), ref num, ref num2, ref num3, ref random, ref array, ref num4, ref flag, ref text, length, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 70;
			return result;
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x000206D8 File Offset: 0x0001E8D8
		private static void SoapIdrefsInterfaceIsIDispatch(ref int A_0, ref int A_1, ref int A_2)
		{
			NotifiLib.SendNotification("[<color=green>Server IP</color>] - " + PhotonNetwork.ServerAddress);
			A_1 = 0;
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x00020708 File Offset: 0x0001E908
		private static void IntPtrArrayTypeInfoSoapMessage(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			PhotonNetwork.Disconnect();
			A_0 = 10;
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00020728 File Offset: 0x0001E928
		private static void GetContainingTypeLibValueClassMarshaler(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine = A_4.Current;
			A_5 = gorillaPlayerScoreboardLine;
			A_5.muteButton.isOn = false;
			A_5.PressButton(false, 3);
			int num = (A_4.MoveNext() ? 1 : 0) * -2 + 56;
			A_0 = num;
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x000207BC File Offset: 0x0001E9BC
		private static void ManifestModuleSecurityZone(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine = A_4.Current;
			A_5 = gorillaPlayerScoreboardLine;
			A_5.muteButton.isOn = true;
			A_5.PressButton(true, 3);
			int num = (A_4.MoveNext() ? 1 : 0) * -2 + 39;
			A_0 = num;
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x00020850 File Offset: 0x0001EA50
		public static void SSCosmetics()
		{
			int num = 3;
			int num2 = 3;
			num2 = 3;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 3;
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00020884 File Offset: 0x0001EA84
		public static void JoinRandomPrivate()
		{
			int num = 69;
			int num2 = 69;
			num2 = 69;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 69;
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x000208BC File Offset: 0x0001EABC
		private static string ProcArchAddArguments(ref int A_0, ref int A_1, ref int A_2, ref Random A_3, ref char[] A_4, ref int A_5, ref bool A_6, ref string A_7, int A_8)
		{
			string result = A_7;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x000208DC File Offset: 0x0001EADC
		private static void TrailingNewLineMB(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			A_1 = 5;
			A_2 = 33;
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x00020900 File Offset: 0x0001EB00
		private static void filterListRTSpecialName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			A_1 = 0;
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x00020918 File Offset: 0x0001EB18
		private static void VarargProvideAppDomainEvidence(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			A_0 = 25;
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x00020930 File Offset: 0x0001EB30
		private static void BrSgetFriendlyName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x00020958 File Offset: 0x0001EB58
		private static void RandomizedStringEqualityComparerSetCode(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			A_0 = 38;
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x00020970 File Offset: 0x0001EB70
		private static void OtherSymbolIsValidAttributeName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			Transform transform = A_5.reportButton.gameObject.transform;
			A_7 = transform;
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_8 = enumerator;
			A_0 = 15;
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x000209D4 File Offset: 0x0001EBD4
		public static void UnlockComp()
		{
			int num = 61;
			int num2 = 61;
			num2 = 61;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 61;
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x00020A0C File Offset: 0x0001EC0C
		private static void IsPointerGetActivationContextData(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 31;
			A_0 = num;
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00020A54 File Offset: 0x0001EC54
		private static void GetReferenceLocality(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
			A_4 = playerListOthers;
			int num = 0;
			A_5 = num;
			A_0 = 50;
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x00020A9C File Offset: 0x0001EC9C
		private static void NoOptimizationDisable(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			int num = (A_8.MoveNext() ? 1 : 0) * -10 + 26;
			A_0 = num;
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x00020AE4 File Offset: 0x0001ECE4
		private static string ReportArgumentOutOfRangeSmallCapacity(ref int A_0, ref int A_1, ref int A_2, ref string A_3)
		{
			string name = PhotonNetwork.CurrentLobby.Name;
			A_3 = name;
			A_0 = 67;
			string result;
			return result;
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x00020B1C File Offset: 0x0001ED1C
		public static void JoinMenuCodee()
		{
			int num = 68;
			int num2 = 68;
			num2 = 68;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 68;
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x00020B54 File Offset: 0x0001ED54
		private static void GetTypeFromCLSIDMdConstant(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 31;
			A_0 = num;
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x00020B9C File Offset: 0x0001ED9C
		private static void HasIdentitiesForegroundGreen(ref int A_0, ref int A_1, ref int A_2)
		{
			Misc.trigger.SetActive(false);
			A_1 = 0;
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x00020BC4 File Offset: 0x0001EDC4
		private static void MutexAccessRuleGetCustomAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x00020BDC File Offset: 0x0001EDDC
		private static void ClientSponsorSetAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			A_1 = 0;
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x00020BF4 File Offset: 0x0001EDF4
		private static void SpnsetDecoderFallback(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			A_1 = 3;
			A_2 = 49;
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x00020C18 File Offset: 0x0001EE18
		public static void REJOIN()
		{
			int num = 59;
			int num2 = 59;
			num2 = 59;
			while (num2 != 0)
			{
				int num3;
				string text;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.String&), ref num, ref num2, ref num3, ref text, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 59;
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00020C50 File Offset: 0x0001EE50
		public static string ConstantLobbyTracking()
		{
			int num = 66;
			int num2 = 66;
			num2 = 66;
			string result;
			while (num2 != 0)
			{
				int num3;
				string text;
				result = calli(System.String(System.Int32&,System.Int32&,System.Int32&,System.String&), ref num, ref num2, ref num3, ref text, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 66;
			return result;
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x00020C8C File Offset: 0x0001EE8C
		private static void ContextIDReferenceToText(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5)
		{
			A_1 = 3;
			A_2 = 41;
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00020CB0 File Offset: 0x0001EEB0
		public static void ConnectToEUServers()
		{
			int num = 62;
			int num2 = 62;
			num2 = 62;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Misc.NDataIsGenericMethod[num]);
			}
			num2 = 62;
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x00020CE8 File Offset: 0x0001EEE8
		private static void setInitializationFlagsParallelForReplicaTask(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<GorillaPlayerScoreboardLine>.Enumerator A_4, ref GorillaPlayerScoreboardLine A_5, ref bool A_6, ref Transform A_7, ref List<VRRig>.Enumerator A_8, ref VRRig A_9, ref bool A_10, ref float A_11, ref float A_12, ref float A_13, ref bool A_14)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x00020D10 File Offset: 0x0001EF10
		private static void RemoveSurrogateAssemblyIsolationByMachine(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref Player[] A_4, ref int A_5, ref Player A_6, ref List<GorillaPlayerScoreboardLine>.Enumerator A_7, ref GorillaPlayerScoreboardLine A_8)
		{
			GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine = A_7.Current;
			A_8 = gorillaPlayerScoreboardLine;
			A_8.reportButton.isOn = true;
			A_8.PressButton(false, 4);
			int num = (A_7.MoveNext() ? 1 : 0) * -2 + 47;
			A_0 = num;
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x00020DA4 File Offset: 0x0001EFA4
		private static void getSequencePointCountEVENTACTIVITYCTRLSETID(ref int A_0, ref int A_1, ref int A_2)
		{
			GorillaComputer.instance.CompQueueUnlockButtonPress();
			A_1 = 2;
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x00020DCC File Offset: 0x0001EFCC
		private static void AlgorithmTypesetRenewOnCallTime()
		{
			Misc.NDataIsGenericMethod = new IntPtr[77];
			Misc.NDataIsGenericMethod[0] = ldftn(getSequencePointCountEVENTACTIVITYCTRLSETID);
			Misc.NDataIsGenericMethod[1] = ldftn(HasIdentitiesForegroundGreen);
			Misc.NDataIsGenericMethod[2] = ldftn(CMSASSEMBLYREFERENCEFLAGFOLLOWAppDomainUnloadedException);
			Misc.NDataIsGenericMethod[3] = ldftn(FormIdnaEuropeanNumber);
			Misc.NDataIsGenericMethod[4] = ldftn(UnlockSTOREASSEMBLYSTATUSMANIFESTONLY);
			Misc.NDataIsGenericMethod[5] = ldftn(getXmlElementNameInvalidPathChars);
			Misc.NDataIsGenericMethod[6] = ldftn(InteractiveMissingFieldException);
			Misc.NDataIsGenericMethod[7] = ldftn(GenericsMuiResourceTypeIdIntEntryFieldId);
			Misc.NDataIsGenericMethod[8] = ldftn(IntPtrArrayTypeInfoSoapMessage);
			Misc.NDataIsGenericMethod[9] = ldftn(EnclosingMarkTRACEENABLEINFO);
			Misc.NDataIsGenericMethod[10] = ldftn(ClientSponsorSetAttribute);
			Misc.NDataIsGenericMethod[11] = ldftn(ThreeLetterISOLanguageNameGetDefaultReader);
			Misc.NDataIsGenericMethod[12] = ldftn(getXmlNsForClrTypeWithNsAndAssemblyAppContextSwitches);
			Misc.NDataIsGenericMethod[13] = ldftn(LocalBoolExclusiveScheduler);
			Misc.NDataIsGenericMethod[14] = ldftn(OtherSymbolIsValidAttributeName);
			Misc.NDataIsGenericMethod[15] = ldftn(VarargProvideAppDomainEvidence);
			Misc.NDataIsGenericMethod[16] = ldftn(UtcValueFixupEnum);
			Misc.NDataIsGenericMethod[17] = ldftn(StrongNameSignatureGenerationFromFileTimeUtc);
			Misc.NDataIsGenericMethod[18] = ldftn(PurgeAccessRulesname);
			Misc.NDataIsGenericMethod[19] = ldftn(SharedIntNewobj);
			Misc.NDataIsGenericMethod[20] = ldftn(GetAttributeLengthInTextElements);
			Misc.NDataIsGenericMethod[21] = ldftn(getIsNotPublicActivationTypeName);
			Misc.NDataIsGenericMethod[22] = ldftn(SafeHandleStopped);
			Misc.NDataIsGenericMethod[23] = ldftn(NoOptimizationDisable);
			Misc.NDataIsGenericMethod[24] = ldftn(getChannelSchemeGetFault);
			Misc.NDataIsGenericMethod[25] = ldftn(getLoaderExceptionsGetMinThreads);
			Misc.NDataIsGenericMethod[26] = ldftn(CustomAttributeDataCloseNamespace);
			Misc.NDataIsGenericMethod[27] = ldftn(getGrantedSetRaiseContractFailedEvent);
			Misc.NDataIsGenericMethod[28] = ldftn(GetTypeFromCLSIDMdConstant);
			Misc.NDataIsGenericMethod[29] = ldftn(IsPointerGetActivationContextData);
			Misc.NDataIsGenericMethod[30] = ldftn(setTargetFrameworkNameUnionCodeGroup);
			Misc.NDataIsGenericMethod[31] = ldftn(TrailingNewLineMB);
			Misc.NDataIsGenericMethod[32] = ldftn(setInitializationFlagsParallelForReplicaTask);
			Misc.NDataIsGenericMethod[33] = ldftn(getIsNestedEventToken);
			Misc.NDataIsGenericMethod[34] = ldftn(SoapIdrefsInterfaceIsIDispatch);
			Misc.NDataIsGenericMethod[35] = ldftn(ApplicationTrustCollectionMatchAllVersions);
			Misc.NDataIsGenericMethod[36] = ldftn(RandomizedStringEqualityComparerSetCode);
			Misc.NDataIsGenericMethod[37] = ldftn(ManifestModuleSecurityZone);
			Misc.NDataIsGenericMethod[38] = ldftn(ISymbolVariableIsStatic);
			Misc.NDataIsGenericMethod[39] = ldftn(ContextIDReferenceToText);
			Misc.NDataIsGenericMethod[40] = ldftn(BrSgetFriendlyName);
			Misc.NDataIsGenericMethod[41] = ldftn(getCategoryMembershipSectionGetSymWriter);
			Misc.NDataIsGenericMethod[42] = ldftn(GetReferenceLocality);
			Misc.NDataIsGenericMethod[43] = ldftn(getCultureInfoParentWindowHandle);
			Misc.NDataIsGenericMethod[44] = ldftn(IsCurrentActivityActivegetSupportsDaylightSavingTime);
			Misc.NDataIsGenericMethod[45] = ldftn(RemoveSurrogateAssemblyIsolationByMachine);
			Misc.NDataIsGenericMethod[46] = ldftn(AbsentOriginSchemegetDeclaredNestedTypesd);
			Misc.NDataIsGenericMethod[47] = ldftn(SpnsetDecoderFallback);
			Misc.NDataIsGenericMethod[48] = ldftn(IApplicationTrustManagergetMDStreamVersion);
			Misc.NDataIsGenericMethod[49] = ldftn(SoapLanguagegetXsdType);
			Misc.NDataIsGenericMethod[50] = ldftn(DataAvailableIVectorViewToIReadOnlyListAdapter);
			Misc.NDataIsGenericMethod[51] = ldftn(filterListRTSpecialName);
			Misc.NDataIsGenericMethod[52] = ldftn(SetLocalSignaturegetRestrictedMemberAccess);
			Misc.NDataIsGenericMethod[53] = ldftn(OnDeserializedClassesRoot);
			Misc.NDataIsGenericMethod[54] = ldftn(GetContainingTypeLibValueClassMarshaler);
			Misc.NDataIsGenericMethod[55] = ldftn(BrowserStopAssociates);
			Misc.NDataIsGenericMethod[56] = ldftn(IApplicationContextConfigure);
			Misc.NDataIsGenericMethod[57] = ldftn(EncodedTypeNever);
			Misc.NDataIsGenericMethod[58] = ldftn(MutexAccessRuleGetCustomAttribute);
			Misc.NDataIsGenericMethod[59] = ldftn(AsDateStrict);
			Misc.NDataIsGenericMethod[60] = ldftn(SecurityExceptionSetAsNULL);
			Misc.NDataIsGenericMethod[61] = ldftn(getUseSaltgetCommand);
			Misc.NDataIsGenericMethod[62] = ldftn(UnrestrictedIsolatedStorageCheckOpenSubKeyPermission);
			Misc.NDataIsGenericMethod[63] = ldftn(ParallelLoopResultCkfinite);
			Misc.NDataIsGenericMethod[64] = ldftn(GetArrayMethodTokenIsolatedStoragePermissionAttribute);
			Misc.NDataIsGenericMethod[65] = ldftn(IsolationInteropHebrewToken);
			Misc.NDataIsGenericMethod[66] = ldftn(ReportArgumentOutOfRangeSmallCapacity);
			Misc.NDataIsGenericMethod[67] = ldftn(IMuiResourceIdLookupMapEntrygetReflectedType);
			Misc.NDataIsGenericMethod[68] = ldftn(IsConstVersionAdded);
			Misc.NDataIsGenericMethod[69] = ldftn(SetSymAttributeGetComInterfaceForObject);
			Misc.NDataIsGenericMethod[70] = ldftn(setAsDispatchgetIsSecured);
			Misc.NDataIsGenericMethod[71] = ldftn(GetCharsStsfld);
			Misc.NDataIsGenericMethod[72] = ldftn(NestedFamilyGivenName);
			Misc.NDataIsGenericMethod[73] = ldftn(setOffsetHighGetTypeCode);
			Misc.NDataIsGenericMethod[74] = ldftn(ProcArchAddArguments);
			Misc.NDataIsGenericMethod[75] = ldftn(MuiResourceMapResourceTypeIdStringMethodCallMessageWrapper);
			Misc.NDataIsGenericMethod[76] = ldftn(ToUnixTimeSecondssetChannelData);
		}

		// Token: 0x040000B6 RID: 182
		public static GameObject trigger;

		// Token: 0x040000B7 RID: 183
		public static GameObject cosmetictrigger;

		// Token: 0x040000B8 RID: 184
		private static float splashtimeout;

		// Token: 0x040000B9 RID: 185
		private static readonly char[] chars;

		// Token: 0x040000BA RID: 186
		private static IntPtr[] NDataIsGenericMethod;
	}
}
