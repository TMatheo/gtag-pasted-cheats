﻿using System;
using BepInEx;
using GorillaLocomotion;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using UnityEngine;
using Valve.VR;

namespace StupidTemplate.Mods
{
	// Token: 0x02000024 RID: 36
	internal class Self
	{
		// Token: 0x0600031B RID: 795 RVA: 0x00016BF8 File Offset: 0x00014DF8
		private static void EventHandleMarkAborted(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			A_1 = 0;
		}

		// Token: 0x0600031C RID: 796 RVA: 0x00016C10 File Offset: 0x00014E10
		public static void TagBees()
		{
			int num = 170;
			int num2 = 170;
			num2 = 170;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				VRRig vrrig;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,VRRig&), ref num, ref num2, ref num3, ref flag, ref vrrig, Self.IsBoxedRequires[num]);
			}
			num2 = 170;
		}

		// Token: 0x0600031D RID: 797 RVA: 0x00016C58 File Offset: 0x00014E58
		private static void asyncResultStringWriter(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_0 = 47;
		}

		// Token: 0x0600031E RID: 798 RVA: 0x00016C70 File Offset: 0x00014E70
		private static void IEnumSTOREDEPLOYMENTMETADATAPROPERTYProviderDefined(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			GorillaSurfaceOverride[] array = Resources.FindObjectsOfTypeAll<GorillaSurfaceOverride>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 58;
		}

		// Token: 0x0600031F RID: 799 RVA: 0x00016CB8 File Offset: 0x00014EB8
		private static void GetRandomFileNameOrderablePartitioner(ref int A_0, ref int A_1, ref int A_2)
		{
			Self.isFlying = false;
			Self.wasPrimaryButtonPressed = false;
			Self.p = false;
			Self.speed = 1.2f;
			Self.fat = false;
			Self.trail = new TrailRenderer();
			Self.trail2 = new TrailRenderer();
			Self.isGhostMonkeActive = false;
			Self.wasRightTriggerPressed = false;
			Self.IsInvisMonkeActive = false;
			Self.wasRightTriggerPressedd = false;
			Self.PlatLEnabled = false;
			Self.PlatREnabled = false;
			Self.newColor = Color.blue;
			A_1 = 0;
		}

		// Token: 0x06000320 RID: 800 RVA: 0x00016D5C File Offset: 0x00014F5C
		public static void Spin()
		{
			int num = 168;
			int num2 = 168;
			num2 = 168;
			while (num2 != 0)
			{
				int num3;
				Quaternion quaternion;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Quaternion&), ref num, ref num2, ref num3, ref quaternion, Self.IsBoxedRequires[num]);
			}
			num2 = 168;
		}

		// Token: 0x06000321 RID: 801 RVA: 0x00016DA0 File Offset: 0x00014FA0
		private static void AppendCharInternalImpl(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			A_0 = 39;
		}

		// Token: 0x06000322 RID: 802 RVA: 0x00016DB8 File Offset: 0x00014FB8
		private static void MachineAccountXdrString(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_0 = 129;
		}

		// Token: 0x06000323 RID: 803 RVA: 0x00016DD0 File Offset: 0x00014FD0
		private static void UnicodeByteArraygetTryOffset(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref VRRig A_4)
		{
			Self.splashtimeout = Time.time;
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			VRRig randomVRRig = RigManager.GetRandomVRRig(false);
			A_4 = randomVRRig;
			GorillaTagger.Instance.offlineVRRig.transform.position = A_4.transform.position + new Vector3(0f, 1f, 0f);
			GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position += new Vector3(0f, 5f, 0f);
			GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position += new Vector3(0f, 5f, 0f);
			GTPlayer.Instance.rightControllerTransform.position = A_4.transform.position;
			A_1 = 0;
		}

		// Token: 0x06000324 RID: 804 RVA: 0x00016F04 File Offset: 0x00015104
		public static void WallWalk()
		{
			int num = 89;
			int num2 = 89;
			num2 = 89;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, Self.IsBoxedRequires[num]);
			}
			num2 = 89;
		}

		// Token: 0x06000325 RID: 805 RVA: 0x00016F40 File Offset: 0x00015140
		private static void GetStringgetAsyncWaitHandle(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(10f * GorillaTagger.Instance.rightHandTransform.right, 5);
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(32, Settings.rightHanded, 0.1f);
			GorillaTagger.Instance.StartVibration(Settings.rightHanded, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
			Self.trail2 = ComponentUtils.AddComponent<TrailRenderer>(GorillaTagger.Instance.offlineVRRig.rightHandTransform);
			Self.trail2.startColor = new Color32(byte.MaxValue, 140, 0, byte.MaxValue);
			Self.trail2.endColor = new Color32(byte.MaxValue, 140, 0, byte.MaxValue);
			Self.trail2.startWidth = 0.05f;
			Self.trail2.endWidth = 0f;
			Self.trail2.minVertexDistance = 0.05f;
			Self.trail2.material.shader = Shader.Find("GUI/Text Shader");
			Self.trail2.time = 2f;
			A_0 = 81;
		}

		// Token: 0x06000326 RID: 806 RVA: 0x000170A0 File Offset: 0x000152A0
		public static void LongArms()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 2;
		}

		// Token: 0x06000327 RID: 807 RVA: 0x000170D4 File Offset: 0x000152D4
		private static void DirectoryFinalizationHelper(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			typeof(GTPlayer).GetField("nativeScale", 36).SetValue(GTPlayer.Instance, 1f);
			A_0 = 150;
		}

		// Token: 0x06000328 RID: 808 RVA: 0x0001711C File Offset: 0x0001531C
		private static void ProtectedResourcesLongList(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_3 = leftGrab;
			int num = ((!A_3) ? 1 : 0) * 1 + 76;
			A_0 = num;
		}

		// Token: 0x06000329 RID: 809 RVA: 0x00017180 File Offset: 0x00015380
		private static void PropertyInfoStringToHGlobalUni(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position;
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			A_1 = 0;
		}

		// Token: 0x0600032A RID: 810 RVA: 0x000171D4 File Offset: 0x000153D4
		public static void BarkFly()
		{
			int num = 139;
			int num2 = 139;
			num2 = 139;
			while (num2 != 0)
			{
				int num3;
				Rigidbody rigidbody;
				Vector2 vector;
				float num4;
				Vector3 vector2;
				Vector3 vector3;
				Vector3 vector4;
				Vector3 vector5;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Rigidbody&,UnityEngine.Vector2&,System.Single&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&), ref num, ref num2, ref num3, ref rigidbody, ref vector, ref num4, ref vector2, ref vector3, ref vector4, ref vector5, Self.IsBoxedRequires[num]);
			}
			num2 = 139;
		}

		// Token: 0x0600032B RID: 811 RVA: 0x00017224 File Offset: 0x00015424
		public static void ToggleFly()
		{
			int num = 24;
			int num2 = 24;
			num2 = 24;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, Self.IsBoxedRequires[num]);
			}
			num2 = 24;
		}

		// Token: 0x0600032C RID: 812 RVA: 0x00017260 File Offset: 0x00015460
		public static void DisableSpeedBoost()
		{
			int num = 67;
			int num2 = 67;
			num2 = 67;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaSurfaceOverride[] array;
				int num4;
				GorillaSurfaceOverride gorillaSurfaceOverride;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaSurfaceOverride[]&,System.Int32&,GorillaSurfaceOverride&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaSurfaceOverride, Self.IsBoxedRequires[num]);
			}
			num2 = 67;
		}

		// Token: 0x0600032D RID: 813 RVA: 0x000172A0 File Offset: 0x000154A0
		public static void Fly()
		{
			int num = 6;
			int num2 = 6;
			num2 = 6;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, Self.IsBoxedRequires[num]);
			}
			num2 = 6;
		}

		// Token: 0x0600032E RID: 814 RVA: 0x000172D4 File Offset: 0x000154D4
		private static void SavePolicyHasCurrent(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref VRRig A_4)
		{
			A_1 = 0;
		}

		// Token: 0x0600032F RID: 815 RVA: 0x000172EC File Offset: 0x000154EC
		private static void CalendarWeekRuleIAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGS(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 5;
				int num2 = 5;
				num2 = 5;
				while (num2 != 0)
				{
					int num3;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.<>c.RunAndSaveCreateNew[num]);
				}
				num2 = 5;
			}, false);
			A_1 = 0;
		}

		// Token: 0x06000330 RID: 816 RVA: 0x00017334 File Offset: 0x00015534
		public static void Bees()
		{
			int num = 162;
			int num2 = 162;
			num2 = 162;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				VRRig vrrig;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,VRRig&), ref num, ref num2, ref num3, ref flag, ref flag2, ref vrrig, Self.IsBoxedRequires[num]);
			}
			num2 = 162;
		}

		// Token: 0x06000331 RID: 817 RVA: 0x0001737C File Offset: 0x0001557C
		private static void TypeLibrarygetChannelUris(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool key = UnityInput.Current.GetKey(119);
			A_3 = key;
			int num = ((!A_3) ? 1 : 0) * 1 + 106;
			A_0 = num;
		}

		// Token: 0x06000332 RID: 818 RVA: 0x000173E4 File Offset: 0x000155E4
		public static void FixRIIIIIIIIIIIIIIIIIIIIIII()
		{
			int num = 141;
			int num2 = 141;
			num2 = 141;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 141;
		}

		// Token: 0x06000333 RID: 819 RVA: 0x00017428 File Offset: 0x00015628
		public static void NoGravity()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000334 RID: 820 RVA: 0x0001745C File Offset: 0x0001565C
		public static void BHopV2()
		{
			int num = 14;
			int num2 = 14;
			num2 = 14;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 14;
		}

		// Token: 0x06000335 RID: 821 RVA: 0x00017494 File Offset: 0x00015694
		private static void MEMORYBASICINFORMATIONKOREANLUNISOLAR(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_1 = 0;
		}

		// Token: 0x06000336 RID: 822 RVA: 0x000174AC File Offset: 0x000156AC
		public static void SmolMonkey()
		{
			int num = 152;
			int num2 = 152;
			num2 = 152;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, Self.IsBoxedRequires[num]);
			}
			num2 = 152;
		}

		// Token: 0x06000337 RID: 823 RVA: 0x000174F4 File Offset: 0x000156F4
		private static void AssemblyAlgorithmIdAttributesetAllowMultiple(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			typeof(GTPlayer).GetField("nativeScale", 36).SetValue(GTPlayer.Instance, 1f);
			A_0 = 160;
		}

		// Token: 0x06000338 RID: 824 RVA: 0x0001753C File Offset: 0x0001573C
		private static void PopipopipopiStandalone(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			int num = ((A_8 < A_7.Length) ? 1 : 0) * -2 + 38;
			A_0 = num;
		}

		// Token: 0x06000339 RID: 825 RVA: 0x00017578 File Offset: 0x00015778
		private static void TrustManagerUIContextReadArray(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 2;
				int num2 = 2;
				num2 = 2;
				while (num2 != 0)
				{
					int num3;
					bool flag;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, Self.<>c.RunAndSaveCreateNew[num]);
				}
				num2 = 2;
			}, false);
			A_1 = 0;
		}

		// Token: 0x0600033A RID: 826 RVA: 0x000175C0 File Offset: 0x000157C0
		private static void UnrecognizedInterfaceType(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
			A_1 = 0;
		}

		// Token: 0x0600033B RID: 827 RVA: 0x000175FC File Offset: 0x000157FC
		private static void MscorlibKeyedCollectionDebugViewLengthInTextElements(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			GorillaSurfaceOverride gorillaSurfaceOverride = A_4[A_5];
			A_6 = gorillaSurfaceOverride;
			A_6.extraVelMaxMultiplier = 3f;
			Self.fat = true;
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 65;
			A_0 = num2;
		}

		// Token: 0x0600033C RID: 828 RVA: 0x0001769C File Offset: 0x0001589C
		// Note: this type is marked as 'beforefieldinit'.
		static Self()
		{
			Self.InvalidPathCharsConstructorCall();
			int num = 174;
			int num2 = 174;
			num2 = 174;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 174;
		}

		// Token: 0x0600033D RID: 829 RVA: 0x000176E4 File Offset: 0x000158E4
		public static void GhostMonke()
		{
			int num = 95;
			int num2 = 95;
			num2 = 95;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, Self.IsBoxedRequires[num]);
			}
			num2 = 95;
		}

		// Token: 0x0600033E RID: 830 RVA: 0x00017720 File Offset: 0x00015920
		private static void SXTasksSetActivityIds(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			Self.isFlying = !Self.isFlying;
			bool flag = Self.isFlying;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 22;
			A_0 = num;
		}

		// Token: 0x0600033F RID: 831 RVA: 0x00017790 File Offset: 0x00015990
		private static void BStrWrapperReleaseTypeAttr(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool rightHanded = Settings.rightHanded;
			A_3 = rightHanded;
			int num = ((!A_3) ? 1 : 0) * 4 + 153;
			A_0 = num;
		}

		// Token: 0x06000340 RID: 832 RVA: 0x000177EC File Offset: 0x000159EC
		private static void GetXmlElementForInteropTypeStoreOperationMetadataProperty(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			bool flag = !Self.fat;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 62;
			A_0 = num;
		}

		// Token: 0x06000341 RID: 833 RVA: 0x00017850 File Offset: 0x00015A50
		private static void TRACEGUIDINFODataCollectionStop(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 7;
			A_0 = num;
		}

		// Token: 0x06000342 RID: 834 RVA: 0x000178BC File Offset: 0x00015ABC
		private static void GetEnumeratorDelegateEnumCategories(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x06000343 RID: 835 RVA: 0x000178D8 File Offset: 0x00015AD8
		private static void setTextCountedMbcsXml(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			GTPlayer.Instance.GetComponent<Rigidbody>().velocity += GTPlayer.Instance.GetComponent<Rigidbody>().transform.right * 0.1f;
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_4 = leftGrab;
			int num = ((!A_4) ? 1 : 0) * 1 + 92;
			A_0 = num;
		}

		// Token: 0x06000344 RID: 836 RVA: 0x00017978 File Offset: 0x00015B78
		private static void LockNumberBufferToDecimal(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000345 RID: 837 RVA: 0x00017990 File Offset: 0x00015B90
		private static void InitialCountGetView(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_4 = leftGrab;
			int num = ((!A_4) ? 1 : 0) * 1 + 86;
			A_0 = num;
		}

		// Token: 0x06000346 RID: 838 RVA: 0x00017A0C File Offset: 0x00015C0C
		private static void getFullDateTimePatternsetItem(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
			NotifiLib.SendNotification("[<color=yellow>Set Master</color>]: You are now master client!");
			A_0 = 135;
		}

		// Token: 0x06000347 RID: 839 RVA: 0x00017A3C File Offset: 0x00015C3C
		private static void OtherPunctuationgetHashName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			GorillaSurfaceOverride[] array = Resources.FindObjectsOfTypeAll<GorillaSurfaceOverride>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 70;
		}

		// Token: 0x06000348 RID: 840 RVA: 0x00017A84 File Offset: 0x00015C84
		private static void CollectionMemoryCopy(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool key = UnityInput.Current.GetKey(32);
			A_7 = key;
			int num = ((!A_7) ? 1 : 0) * 1 + 114;
			A_0 = num;
		}

		// Token: 0x06000349 RID: 841 RVA: 0x00017AEC File Offset: 0x00015CEC
		private static void IsCopyConstructedCreateQualifiedName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x0600034A RID: 842 RVA: 0x00017B04 File Offset: 0x00015D04
		private static void getStoreSecurityControlPrincipal(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.transform.localScale = new Vector3(1.4f, 1.4f, 1.4f);
			A_1 = 0;
		}

		// Token: 0x0600034B RID: 843 RVA: 0x00017B40 File Offset: 0x00015D40
		private static void RegistryKeySectionValidateSlot(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_1 = 0;
		}

		// Token: 0x0600034C RID: 844 RVA: 0x00017B58 File Offset: 0x00015D58
		public static void ReverseGravity()
		{
			int num = 5;
			int num2 = 5;
			num2 = 5;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 5;
		}

		// Token: 0x0600034D RID: 845 RVA: 0x00017B8C File Offset: 0x00015D8C
		private static void GetDeclaredMethodsdRaiseOnSerializedEvent(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * 0.3f;
			GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			A_1 = 0;
		}

		// Token: 0x0600034E RID: 846 RVA: 0x00017BF4 File Offset: 0x00015DF4
		public static void SuperMonkey()
		{
			int num = 15;
			int num2 = 15;
			num2 = 15;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, ref flag4, Self.IsBoxedRequires[num]);
			}
			num2 = 15;
		}

		// Token: 0x0600034F RID: 847 RVA: 0x00017C34 File Offset: 0x00015E34
		private static void FUNCFLAGFNONBROWSABLEIMessageSink(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool platREnabled = Self.PlatREnabled;
			A_8 = platREnabled;
			int num = ((!A_8) ? 1 : 0) * 1 + 52;
			A_0 = num;
		}

		// Token: 0x06000350 RID: 848 RVA: 0x00017C90 File Offset: 0x00015E90
		private static void EncryptValueClassInterfaceAttribute(ref int A_0, ref int A_1, ref int A_2, Self A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000351 RID: 849 RVA: 0x00017CB4 File Offset: 0x00015EB4
		private static void getDriveTypeUIntArrayTypeInfo(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x06000352 RID: 850 RVA: 0x00017CD0 File Offset: 0x00015ED0
		private static void getPropertyTypegetTypeContainingContracts(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			NotifiLib.SendNotification("[<color=yellow>Set Master</color>]: You are not in a modded lobby!");
			A_1 = 0;
		}

		// Token: 0x06000353 RID: 851 RVA: 0x00017CF4 File Offset: 0x00015EF4
		private static void MonitoringSurvivedMemorySizeAllocateDataSlot(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			GTPlayer.Instance.GetComponent<Rigidbody>().velocity += GTPlayer.Instance.headCollider.transform.forward * 0.3f;
			A_1 = 0;
		}

		// Token: 0x06000354 RID: 852 RVA: 0x00017D48 File Offset: 0x00015F48
		private static void AdviseCMSUSAGEPATTERN(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_0 = 29;
		}

		// Token: 0x06000355 RID: 853 RVA: 0x00017D60 File Offset: 0x00015F60
		private static void PathInternalIsGlobalTypeDefToken(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool platLEnabled = Self.PlatLEnabled;
			A_5 = platLEnabled;
			int num = ((!A_5) ? 1 : 0) * 1 + 45;
			A_0 = num;
		}

		// Token: 0x06000356 RID: 854 RVA: 0x00017DBC File Offset: 0x00015FBC
		private static void IsSemiWeakKeySEHException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00017DD4 File Offset: 0x00015FD4
		private static void getDefaultGetTagForElement(ref int A_0, ref int A_1, ref int A_2)
		{
			Self.BarkFly();
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			A_1 = 0;
		}

		// Token: 0x06000358 RID: 856 RVA: 0x00017E08 File Offset: 0x00016008
		private static void SymbolTokenDigit(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref VRRig A_5)
		{
			Self.splashtimeout = Time.time;
			bool inRoom = PhotonNetwork.InRoom;
			A_4 = inRoom;
			int num = ((!A_4) ? 1 : 0) * 1 + 164;
			A_0 = num;
		}

		// Token: 0x06000359 RID: 857 RVA: 0x00017E70 File Offset: 0x00016070
		private static void ServicePackMinoraddResourceResolve(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref VRRig A_5)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			VRRig randomVRRig = RigManager.GetRandomVRRig(false);
			A_5 = randomVRRig;
			GorillaTagger.Instance.offlineVRRig.transform.position = A_5.transform.position + new Vector3(0f, 1f, 0f);
			GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = A_5.transform.position;
			GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = A_5.transform.position;
			A_0 = 166;
		}

		// Token: 0x0600035A RID: 858 RVA: 0x00017F60 File Offset: 0x00016160
		private static void ContinuationTaskFromTaskToValueTuple(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			GorillaSurfaceOverride gorillaSurfaceOverride = A_4[A_5];
			A_6 = gorillaSurfaceOverride;
			A_6.extraVelMaxMultiplier = 1f;
			Self.fat = false;
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 71;
			A_0 = num2;
		}

		// Token: 0x0600035B RID: 859 RVA: 0x00018000 File Offset: 0x00016200
		public Self()
		{
			int num = 173;
			int num2 = 173;
			num2 = 173;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.Self), ref num, ref num2, ref num3, this, Self.IsBoxedRequires[num]);
			}
			num2 = 173;
		}

		// Token: 0x0600035C RID: 860 RVA: 0x00018044 File Offset: 0x00016244
		private static void FileAssociationDefaultIconToLowerInvariant(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_1 = 0;
		}

		// Token: 0x0600035D RID: 861 RVA: 0x0001805C File Offset: 0x0001625C
		private static void ConsumptionScopegetQuota(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Object.Destroy(Self.PlatR);
			Self.PlatREnabled = false;
			A_1 = 0;
		}

		// Token: 0x0600035E RID: 862 RVA: 0x0001808C File Offset: 0x0001628C
		private static void ApplicationStateAccessDenied(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool key = UnityInput.Current.GetKey(97);
			A_4 = key;
			int num = ((!A_4) ? 1 : 0) * 1 + 108;
			A_0 = num;
		}

		// Token: 0x0600035F RID: 863 RVA: 0x000180F4 File Offset: 0x000162F4
		public static void BigMonkey()
		{
			int num = 142;
			int num2 = 142;
			num2 = 142;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, Self.IsBoxedRequires[num]);
			}
			num2 = 142;
		}

		// Token: 0x06000360 RID: 864 RVA: 0x0001813C File Offset: 0x0001633C
		private static void EventWaitHandleSecurityIsSecurityCritical(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 7;
				int num2 = 7;
				num2 = 7;
				while (num2 != 0)
				{
					int num3;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.<>c.RunAndSaveCreateNew[num]);
				}
				num2 = 7;
			}, true);
			A_1 = 0;
		}

		// Token: 0x06000361 RID: 865 RVA: 0x00018184 File Offset: 0x00016384
		private static void LineNoSTOREASSEMBLYFILESTATUSFLAGPRESENT(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * 0.1f;
			A_1 = 0;
		}

		// Token: 0x06000362 RID: 866 RVA: 0x000181D8 File Offset: 0x000163D8
		private static void SetterActivatedClientTypeEntry(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			MeshCollider[] array = Object.FindObjectsOfType<MeshCollider>();
			A_7 = array;
			int num = 0;
			A_8 = num;
			A_0 = 37;
		}

		// Token: 0x06000363 RID: 867 RVA: 0x00018220 File Offset: 0x00016420
		private static void SignatureSuccess(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 6;
				int num2 = 6;
				num2 = 6;
				while (num2 != 0)
				{
					int num3;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.<>c.RunAndSaveCreateNew[num]);
				}
				num2 = 6;
			}, false);
			A_1 = 0;
		}

		// Token: 0x06000364 RID: 868 RVA: 0x00018268 File Offset: 0x00016468
		private static void AbortCOMServerEntry(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = false;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 103;
			A_0 = num;
		}

		// Token: 0x06000365 RID: 869 RVA: 0x000182C4 File Offset: 0x000164C4
		private static void AuthenticatedUserSidSelectMethod(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref VRRig A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000366 RID: 870 RVA: 0x000182DC File Offset: 0x000164DC
		private static void FOleAutomationGetInteropFieldTypeAndNameFromXmlElement(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool key = UnityInput.Current.GetKey(115);
			A_5 = key;
			int num = ((!A_5) ? 1 : 0) * 1 + 110;
			A_0 = num;
		}

		// Token: 0x06000367 RID: 871 RVA: 0x00018344 File Offset: 0x00016544
		public static void CopyMovementGun()
		{
			int num = 136;
			int num2 = 136;
			num2 = 136;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 136;
		}

		// Token: 0x06000368 RID: 872 RVA: 0x00018388 File Offset: 0x00016588
		private static void NumberNegativePatternResourceManagerNotCreatingResourceSet(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			typeof(GTPlayer).GetField("nativeScale", 36).SetValue(GTPlayer.Instance, 1f);
			A_0 = 146;
		}

		// Token: 0x06000369 RID: 873 RVA: 0x000183D0 File Offset: 0x000165D0
		private static void GetValueListSuccess(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.leftControllerTransform.position;
			A_0 = 88;
		}

		// Token: 0x0600036A RID: 874 RVA: 0x00018424 File Offset: 0x00016624
		public static void Free()
		{
			int num = 140;
			int num2 = 140;
			num2 = 140;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 140;
		}

		// Token: 0x0600036B RID: 875 RVA: 0x00018468 File Offset: 0x00016668
		private static void FoundYearPatternFlaggetIsCompatibilityBehaviorDefined(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool flag = A_3;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 26;
			A_0 = num;
		}

		// Token: 0x0600036C RID: 876 RVA: 0x000184C8 File Offset: 0x000166C8
		private static void getKeywordsFoundEndOfHebrewNumber(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 1 + 90;
			A_0 = num;
		}

		// Token: 0x0600036D RID: 877 RVA: 0x0001852C File Offset: 0x0001672C
		private static void GetHandleSafeThreadHandle(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 59;
			A_0 = num;
		}

		// Token: 0x0600036E RID: 878 RVA: 0x00018568 File Offset: 0x00016768
		private static void GetMillisecondssetExternalProcessMgmt(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_0 = 151;
		}

		// Token: 0x0600036F RID: 879 RVA: 0x00018580 File Offset: 0x00016780
		private static void getSecurityZoneIsClrTypeNamespace(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			bool rightControllerSecondaryButton = ControllerInputPoller.instance.rightControllerSecondaryButton;
			A_3 = rightControllerSecondaryButton;
			int num = ((!A_3) ? 1 : 0) * 1 + 16;
			A_0 = num;
		}

		// Token: 0x06000370 RID: 880 RVA: 0x000185E4 File Offset: 0x000167E4
		private static void VtableLayoutMaskDSAParameters(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool flag = true;
			A_3 = flag;
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			A_4 = rightControllerPrimaryButton;
			int num = ((!A_4) ? 1 : 0) * 3 + 25;
			A_0 = num;
		}

		// Token: 0x06000371 RID: 881 RVA: 0x00018660 File Offset: 0x00016860
		private static void getProtectedResourcesCreateAnySchemeAccess(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000372 RID: 882 RVA: 0x00018678 File Offset: 0x00016878
		private static void SearchResultHandlerExecution(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000373 RID: 883 RVA: 0x00018690 File Offset: 0x00016890
		private static void MEMORYSTATUSEXLdsfld(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.rightControllerTransform.position;
			A_0 = 85;
		}

		// Token: 0x06000374 RID: 884 RVA: 0x000186E4 File Offset: 0x000168E4
		private static void CdsSyncEtwBCLProviderReleaseWriterLock(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			GorillaTagger.Instance.rigidbody.transform.position += GTPlayer.Instance.rightControllerTransform.parent.forward * Time.deltaTime * -15f;
			A_0 = 120;
		}

		// Token: 0x06000375 RID: 885 RVA: 0x00018748 File Offset: 0x00016948
		private static void TryPopDTDAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = !PhotonNetwork.IsMasterClient;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 125;
			A_0 = num;
		}

		// Token: 0x06000376 RID: 886 RVA: 0x000187AC File Offset: 0x000169AC
		public static void ResetArms()
		{
			int num = 3;
			int num2 = 3;
			num2 = 3;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 3;
		}

		// Token: 0x06000377 RID: 887 RVA: 0x000187E0 File Offset: 0x000169E0
		private static void RandomlyGeneratedCreateSecurityElement(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			NotifiLib.SendNotification("[<color=yellow>Set Master</color>]: You are not in a modded lobby!");
			A_1 = 0;
		}

		// Token: 0x06000378 RID: 888 RVA: 0x00018804 File Offset: 0x00016A04
		public static void HighGravity()
		{
			int num = 4;
			int num2 = 4;
			num2 = 4;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 4;
		}

		// Token: 0x06000379 RID: 889 RVA: 0x00018838 File Offset: 0x00016A38
		private static void getDeltaLastAccessTime(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = true;
			A_1 = 0;
		}

		// Token: 0x0600037A RID: 890 RVA: 0x00018868 File Offset: 0x00016A68
		public static void AutoSet()
		{
			int num = 130;
			int num2 = 130;
			num2 = 130;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, Self.IsBoxedRequires[num]);
			}
			num2 = 130;
		}

		// Token: 0x0600037B RID: 891 RVA: 0x000188B0 File Offset: 0x00016AB0
		public static void SigSpeedBoost()
		{
			int num = 61;
			int num2 = 61;
			num2 = 61;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaSurfaceOverride[] array;
				int num4;
				GorillaSurfaceOverride gorillaSurfaceOverride;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaSurfaceOverride[]&,System.Int32&,GorillaSurfaceOverride&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaSurfaceOverride, Self.IsBoxedRequires[num]);
			}
			num2 = 61;
		}

		// Token: 0x0600037C RID: 892 RVA: 0x000188F0 File Offset: 0x00016AF0
		private static void LUIDSerializationMissingKeys(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = !PhotonNetwork.IsMasterClient;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 132;
			A_0 = num;
		}

		// Token: 0x0600037D RID: 893 RVA: 0x00018954 File Offset: 0x00016B54
		private static void OffsetHighHasLocalValues(ref int A_0, ref int A_1, ref int A_2)
		{
			Camera.main.transform.rotation = Random.rotation;
			A_1 = 0;
		}

		// Token: 0x0600037E RID: 894 RVA: 0x00018984 File Offset: 0x00016B84
		private static void lcidEntryPointEntry(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			bool flag = Self.isFlying;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 22;
			A_0 = num;
		}

		// Token: 0x0600037F RID: 895 RVA: 0x000189E0 File Offset: 0x00016BE0
		private static void ParentIndexgetEnglishName(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			Object.Destroy(GorillaTagger.Instance.offlineVRRig.rightHandTransform.GetComponent<TrailRenderer>());
			A_1 = 0;
		}

		// Token: 0x06000380 RID: 896 RVA: 0x00018A14 File Offset: 0x00016C14
		private static void IFieldInfoLdcIM(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			bool flag = Self.fat;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 68;
			A_0 = num;
		}

		// Token: 0x06000381 RID: 897 RVA: 0x00018A70 File Offset: 0x00016C70
		private static void ClaimsPrincipalSelectorFormat(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = false;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 98;
			A_0 = num;
		}

		// Token: 0x06000382 RID: 898 RVA: 0x00018ACC File Offset: 0x00016CCC
		private static void getExclusiveSchedulerCultureAwareRandomizedComparer(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * 0.3f;
			GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			A_4 = rightControllerPrimaryButton;
			int num = ((!A_4) ? 1 : 0) * 1 + 18;
			A_0 = num;
		}

		// Token: 0x06000383 RID: 899 RVA: 0x00018B80 File Offset: 0x00016D80
		public static void Set()
		{
			int num = 123;
			int num2 = 123;
			num2 = 123;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, Self.IsBoxedRequires[num]);
			}
			num2 = 123;
		}

		// Token: 0x06000384 RID: 900 RVA: 0x00018BBC File Offset: 0x00016DBC
		private static void GenericPrincipalISTOREENUMASSEMBLIESFLAGS(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			GTPlayer.Instance.GetComponent<Rigidbody>().velocity += GTPlayer.Instance.GetComponent<Rigidbody>().transform.right * -0.1f;
			A_1 = 0;
		}

		// Token: 0x06000385 RID: 901 RVA: 0x00018C10 File Offset: 0x00016E10
		private static void InlineValueMethodSpec(ref int A_0, ref int A_1, ref int A_2, ref Rigidbody A_3, ref Vector2 A_4, ref float A_5, ref Vector3 A_6, ref Vector3 A_7, ref Vector3 A_8, ref Vector3 A_9)
		{
			Self.NoGravity();
			Rigidbody attachedRigidbody = GTPlayer.Instance.bodyCollider.attachedRigidbody;
			A_3 = attachedRigidbody;
			Vector2 axis = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.GetAxis(1);
			A_4 = axis;
			float y = SteamVR_Actions.gorillaTag_RightJoystick2DAxis.GetAxis(2).y;
			A_5 = y;
			A_6..ctor(A_4.x, A_5, A_4.y);
			Vector3 forward = GTPlayer.Instance.bodyCollider.transform.forward;
			A_7 = forward;
			A_7.y = 0f;
			Vector3 right = GTPlayer.Instance.bodyCollider.transform.right;
			A_8 = right;
			A_8.y = 0f;
			Vector3 vector = A_6.x * A_8 + A_5 * Vector3.up + A_6.z * A_7;
			A_9 = vector;
			vector = A_9 * (GTPlayer.Instance.scale * 10f);
			A_9 = vector;
			A_3.velocity = Vector3.Lerp(A_3.velocity, A_9, 0.1f);
			A_1 = 0;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x00018DEC File Offset: 0x00016FEC
		private static void getEventHandleIntPtrPrivateScope(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			GorillaSurfaceOverride gorillaSurfaceOverride = A_4[A_5];
			A_6 = gorillaSurfaceOverride;
			A_6.extraVelMaxMultiplier = Self.speed;
			Self.fat = true;
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 59;
			A_0 = num2;
		}

		// Token: 0x06000387 RID: 903 RVA: 0x00018E8C File Offset: 0x0001708C
		private static void ParamsArraySetField(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_4 = leftGrab;
			int num = ((!A_4) ? 1 : 0) * 1 + 86;
			A_0 = num;
		}

		// Token: 0x06000388 RID: 904 RVA: 0x00018EF0 File Offset: 0x000170F0
		private static void UnsafeQueueUserWorkItemOffendingNumber(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_1 = 0;
		}

		// Token: 0x06000389 RID: 905 RVA: 0x00018F08 File Offset: 0x00017108
		private static void MonitoringIsEnabledsetTypeInformation(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(-Physics.gravity, 5);
			Self.wasPrimaryButtonPressed = A_4;
			A_1 = 0;
		}

		// Token: 0x0600038A RID: 906 RVA: 0x00018F50 File Offset: 0x00017150
		private static void FusionAbandonedMutexException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x0600038B RID: 907 RVA: 0x00018F68 File Offset: 0x00017168
		private static void getOSDescriptionAssumeNegative(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref VRRig A_5)
		{
			A_1 = 0;
		}

		// Token: 0x0600038C RID: 908 RVA: 0x00018F80 File Offset: 0x00017180
		public static void wasdfly()
		{
			int num = 105;
			int num2 = 105;
			num2 = 105;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				bool flag5;
				bool flag6;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, ref flag4, ref flag5, ref flag6, Self.IsBoxedRequires[num]);
			}
			num2 = 105;
		}

		// Token: 0x0600038D RID: 909 RVA: 0x00018FC4 File Offset: 0x000171C4
		private static void ObjectStringRuntimeResourceSet(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.down * (Time.deltaTime * (15f / Time.deltaTime)), 5);
			A_1 = 0;
		}

		// Token: 0x0600038E RID: 910 RVA: 0x00019014 File Offset: 0x00017214
		private static void getAccessControlTypeFor(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			MeshCollider[] array = Object.FindObjectsOfType<MeshCollider>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 33;
		}

		// Token: 0x0600038F RID: 911 RVA: 0x0001905C File Offset: 0x0001725C
		private static void CreateFilesIComparer(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref VRRig A_5)
		{
			bool flag = Time.time > Self.splashtimeout + 0.3f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 163;
			A_0 = num;
		}

		// Token: 0x06000390 RID: 912 RVA: 0x000190C8 File Offset: 0x000172C8
		private static void LoadPolicyLevelFromFilesetCustomErrorsMode(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 101;
			A_0 = num;
		}

		// Token: 0x06000391 RID: 913 RVA: 0x00019134 File Offset: 0x00017334
		private static void WaitOpenExisting(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = !Self.wasRightTriggerPressedd;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 103;
			A_0 = num;
		}

		// Token: 0x06000392 RID: 914 RVA: 0x0001919C File Offset: 0x0001739C
		private static void DigestMethodNullableComparer(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool rightHanded = Settings.rightHanded;
			A_3 = rightHanded;
			int num = ((!A_3) ? 1 : 0) * 4 + 143;
			A_0 = num;
		}

		// Token: 0x06000393 RID: 915 RVA: 0x000191F8 File Offset: 0x000173F8
		public static void SpeedBoost()
		{
			int num = 55;
			int num2 = 55;
			num2 = 55;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GorillaSurfaceOverride[] array;
				int num4;
				GorillaSurfaceOverride gorillaSurfaceOverride;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,GorillaSurfaceOverride[]&,System.Int32&,GorillaSurfaceOverride&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref gorillaSurfaceOverride, Self.IsBoxedRequires[num]);
			}
			num2 = 55;
		}

		// Token: 0x06000394 RID: 916 RVA: 0x00019238 File Offset: 0x00017438
		private static void GetMethodBaseDP(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_3 = leftGrab;
			int num = ((!A_3) ? 1 : 0) * 3 + 41;
			A_0 = num;
		}

		// Token: 0x06000395 RID: 917 RVA: 0x0001929C File Offset: 0x0001749C
		private static void eventMessageBeginGetRequestStream(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref VRRig A_4)
		{
			bool flag = Time.time > Self.splashtimeout + 0.05f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 171;
			A_0 = num;
		}

		// Token: 0x06000396 RID: 918 RVA: 0x00019308 File Offset: 0x00017508
		private static void GetExportedTypesIsEnabled(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 96;
			A_0 = num;
		}

		// Token: 0x06000397 RID: 919 RVA: 0x00019374 File Offset: 0x00017574
		private static void CompilationRelaxationsWinapi(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_0 = 54;
		}

		// Token: 0x06000398 RID: 920 RVA: 0x0001938C File Offset: 0x0001758C
		public static void NoCollide()
		{
			int num = 30;
			int num2 = 30;
			num2 = 30;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				MeshCollider[] array;
				int num4;
				MeshCollider meshCollider;
				MeshCollider[] array2;
				int num5;
				MeshCollider meshCollider2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,UnityEngine.MeshCollider[]&,System.Int32&,UnityEngine.MeshCollider&,UnityEngine.MeshCollider[]&,System.Int32&,UnityEngine.MeshCollider&), ref num, ref num2, ref num3, ref flag, ref array, ref num4, ref meshCollider, ref array2, ref num5, ref meshCollider2, Self.IsBoxedRequires[num]);
			}
			num2 = 30;
		}

		// Token: 0x06000399 RID: 921 RVA: 0x000193D0 File Offset: 0x000175D0
		public static void InvisMonke()
		{
			int num = 100;
			int num2 = 100;
			num2 = 100;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, Self.IsBoxedRequires[num]);
			}
			num2 = 100;
		}

		// Token: 0x0600039A RID: 922 RVA: 0x0001940C File Offset: 0x0001760C
		public static void TPGun()
		{
			int num = 73;
			int num2 = 73;
			num2 = 73;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 73;
		}

		// Token: 0x0600039B RID: 923 RVA: 0x00019444 File Offset: 0x00017644
		private static void TraceOperationEndDocType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_0 = 135;
		}

		// Token: 0x0600039C RID: 924 RVA: 0x0001945C File Offset: 0x0001765C
		private static void IsErrorRedirectedgetRemotingConfiguration(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			typeof(GTPlayer).GetField("nativeScale", 36).SetValue(GTPlayer.Instance, 5f);
			A_1 = 0;
		}

		// Token: 0x0600039D RID: 925 RVA: 0x000194A4 File Offset: 0x000176A4
		private static void getRevisionVersiongetDateEnd(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool rightControllerSecondaryButton = ControllerInputPoller.instance.rightControllerSecondaryButton;
			A_4 = rightControllerSecondaryButton;
			int num = ((!A_4) ? 1 : 0) * 1 + 144;
			A_0 = num;
		}

		// Token: 0x0600039E RID: 926 RVA: 0x00019508 File Offset: 0x00017708
		private static void AnonymousSidgetDaylightTransitionStart(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			GorillaTagger.Instance.rigidbody.transform.position += GTPlayer.Instance.rightControllerTransform.parent.right * Time.deltaTime * 15f;
			A_0 = 119;
		}

		// Token: 0x0600039F RID: 927 RVA: 0x0001956C File Offset: 0x0001776C
		private static void UseDllDirectoryForDependenciesAppDomainInitializerInfo(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			bool flag = false;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 20;
			A_0 = num;
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x000195C8 File Offset: 0x000177C8
		private static void BackgroundIntensityUSEROBJECTFLAGS(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(-Physics.gravity, 5);
			A_1 = 1;
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x00019600 File Offset: 0x00017800
		private static void setCompoundAceTypeUnwrapPromise(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref VRRig A_5)
		{
			Main.GetIndex("Become Bees Ghost").enabled = false;
			A_1 = 0;
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x00019630 File Offset: 0x00017830
		private static void CallingConventionUnregisterChannel(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x00019648 File Offset: 0x00017848
		private static void ResourceManagerGetSatelliteAssemblySucceededSetKey(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool leftControllerSecondaryButton = ControllerInputPoller.instance.leftControllerSecondaryButton;
			A_5 = leftControllerSecondaryButton;
			int num = ((!A_5) ? 1 : 0) * 1 + 148;
			A_0 = num;
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x000196AC File Offset: 0x000178AC
		private static void AllowOnlyFipsAlgorithmsLanguageVendor(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool key = UnityInput.Current.GetKey(99);
			A_8 = key;
			int num = ((!A_8) ? 1 : 0) * 1 + 116;
			A_0 = num;
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x00019714 File Offset: 0x00017914
		private static void getEventHandlerTypeBestFitMask(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			GorillaSurfaceOverride[] array = Resources.FindObjectsOfTypeAll<GorillaSurfaceOverride>();
			A_4 = array;
			int num = 0;
			A_5 = num;
			A_0 = 64;
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x0001975C File Offset: 0x0001795C
		private static void StructuralEqualityComparerIsTokenOfType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_0 = 161;
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x00019774 File Offset: 0x00017974
		private static void getInstanceProviderType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = NetworkSystem.Instance.GameModeString.Contains("MODDED_");
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 124;
			A_0 = num;
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x000197E0 File Offset: 0x000179E0
		private static void IReportMatchMembershipConditionDescriptor(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x000197F8 File Offset: 0x000179F8
		private static void ConvIReflectionEmit(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00019810 File Offset: 0x00017A10
		private static void setPrivateBinPathAddAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_4 = rightGrab;
			int num = ((!A_4) ? 1 : 0) * 1 + 79;
			A_0 = num;
		}

		// Token: 0x060003AB RID: 939 RVA: 0x00019874 File Offset: 0x00017A74
		private static void XmlNsForClrTypeWithAssemblyDNd(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_1 = 0;
		}

		// Token: 0x060003AC RID: 940 RVA: 0x0001988C File Offset: 0x00017A8C
		private static void getProxyTypeNamegetDebuggingFlags(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 71;
			A_0 = num;
		}

		// Token: 0x060003AD RID: 941 RVA: 0x000198C8 File Offset: 0x00017AC8
		private static void getLengthFirstFourDayWeek(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			A_4 = leftGrab;
			int num = ((!A_4) ? 1 : 0) * 1 + 92;
			A_0 = num;
		}

		// Token: 0x060003AE RID: 942 RVA: 0x0001992C File Offset: 0x00017B2C
		public static void ShadowRelm()
		{
			int num = 12;
			int num2 = 12;
			num2 = 12;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 12;
		}

		// Token: 0x060003AF RID: 943 RVA: 0x00019964 File Offset: 0x00017B64
		private static void SetAccessRuleSecurityContextSource(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Self.PlatL = GameObject.CreatePrimitive(3);
			Self.PlatL.GetComponent<Renderer>().material.color = Main.outlineColor;
			Self.PlatL.transform.localScale = new Vector3(0.0125f, 0.28f, 0.3825f);
			Self.PlatL.transform.position = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, -0.07f, 0f);
			Self.PlatL.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
			Self.PlatLEnabled = true;
			A_0 = 47;
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00019A4C File Offset: 0x00017C4C
		public static void Goon()
		{
			int num = 82;
			int num2 = 82;
			num2 = 82;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, Self.IsBoxedRequires[num]);
			}
			num2 = 82;
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x00019A88 File Offset: 0x00017C88
		private static void ClassInterfaceTypeSetThrowOnRelative(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_1 = 0;
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x00019AA0 File Offset: 0x00017CA0
		private static void TKINDINTERFACEVARCONST(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			A_3 = rightControllerPrimaryButton;
			int num = ((!A_3) ? 1 : 0) * 4 + 31;
			A_0 = num;
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x00019B04 File Offset: 0x00017D04
		private static void MaskGenerationMethodGetObjectForNativeVariant(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			A_1 = 0;
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x00019B1C File Offset: 0x00017D1C
		private static void getProcessIdOemMinus(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			A_1 = 0;
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x00019B34 File Offset: 0x00017D34
		private static void MTACorrectionAlgorithm(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 34;
			A_0 = num;
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x00019B70 File Offset: 0x00017D70
		private static void getTargetedPatchBandSoapFieldAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x00019B88 File Offset: 0x00017D88
		public static void VelFly()
		{
			int num = 9;
			int num2 = 9;
			num2 = 9;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, Self.IsBoxedRequires[num]);
			}
			num2 = 9;
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x00019BC0 File Offset: 0x00017DC0
		public static void Spazoid()
		{
			int num = 138;
			int num2 = 138;
			num2 = 138;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 138;
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x00019C04 File Offset: 0x00017E04
		private static void setNumberDecimalSeparatorAtNotation(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060003BA RID: 954 RVA: 0x00019C20 File Offset: 0x00017E20
		private static void CheckOpenSubKeyPermissionGenerated(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			GorillaTagger.Instance.rigidbody.transform.position += new Vector3(0f, Time.deltaTime * 15f);
			A_0 = 118;
		}

		// Token: 0x060003BB RID: 955 RVA: 0x00019C70 File Offset: 0x00017E70
		private static void SystemAlarmCallbackObjectgetLoadFrom(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			GorillaTagger.Instance.rigidbody.transform.position += new Vector3(0f, Time.deltaTime * -15f);
			A_1 = 0;
		}

		// Token: 0x060003BC RID: 956 RVA: 0x00019CC4 File Offset: 0x00017EC4
		private static void CurrentPrincipalFileStreamAsyncResult(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.GetComponent<Rigidbody>().velocity += GTPlayer.Instance.headCollider.transform.forward * 0.1f;
			A_1 = 0;
		}

		// Token: 0x060003BD RID: 957 RVA: 0x00019D18 File Offset: 0x00017F18
		private static void AssemblyLoadEventArgsNotAPortableExecutableImage(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			MeshCollider meshCollider = A_4[A_5];
			A_6 = meshCollider;
			A_6.enabled = false;
			int num = A_5 + 1;
			A_5 = num;
			int num2 = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 34;
			A_0 = num2;
		}

		// Token: 0x060003BE RID: 958 RVA: 0x00019DB0 File Offset: 0x00017FB0
		private static void getInArgsDns(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * 0.3f;
			GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			bool flag = false;
			A_3 = flag;
			A_0 = 29;
		}

		// Token: 0x060003BF RID: 959 RVA: 0x00019E30 File Offset: 0x00018030
		public static void RigGun()
		{
			int num = 74;
			int num2 = 74;
			num2 = 74;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 74;
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x00019E68 File Offset: 0x00018068
		private static void YearEndgetCancellationToken(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool flag = true;
			A_3 = flag;
			A_1 = 0;
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x00019E98 File Offset: 0x00018098
		private static void GetKeyAlgorithmParametersAccessAllowedCompound(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref MeshCollider[] A_4, ref int A_5, ref MeshCollider A_6, ref MeshCollider[] A_7, ref int A_8, ref MeshCollider A_9)
		{
			MeshCollider meshCollider = A_7[A_8];
			A_9 = meshCollider;
			A_9.enabled = true;
			int num = A_8 + 1;
			A_8 = num;
			int num2 = ((A_8 < A_7.Length) ? 1 : 0) * -2 + 38;
			A_0 = num2;
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x00019F30 File Offset: 0x00018130
		private static void NoGCInProgressConcurrentExclusiveSchedulerPair(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x00019F4C File Offset: 0x0001814C
		private static void setTitleCurrentlyExecutingTaskCount(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool leftControllerSecondaryButton = ControllerInputPoller.instance.leftControllerSecondaryButton;
			A_5 = leftControllerSecondaryButton;
			int num = ((!A_5) ? 1 : 0) * 1 + 158;
			A_0 = num;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x00019FB0 File Offset: 0x000181B0
		public static void Aimbot()
		{
			int num = 137;
			int num2 = 137;
			num2 = 137;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 137;
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x00019FF4 File Offset: 0x000181F4
		private static void PurgeAuditRulesGetStringArray(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_6 = rightGrab;
			int num = ((!A_6) ? 1 : 0) * 3 + 48;
			A_0 = num;
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x0001A058 File Offset: 0x00018258
		public static void IronMNonkdeye()
		{
			int num = 75;
			int num2 = 75;
			num2 = 75;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, Self.IsBoxedRequires[num]);
			}
			num2 = 75;
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0001A094 File Offset: 0x00018294
		private static void ValueClassMarshalergetMethodHandle(ref int A_0, ref int A_1, ref int A_2, ref Quaternion A_3)
		{
			GorillaTagger.Instance.offlineVRRig.enabled = false;
			GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.bodyCollider.transform.position;
			Transform transform = GorillaTagger.Instance.offlineVRRig.transform;
			Quaternion rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
			A_3 = rotation;
			transform.rotation = Quaternion.Euler(A_3.eulerAngles + new Vector3(0f, 10f, 0f));
			GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * -3f;
			GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * 3f;
			A_1 = 0;
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x0001A1F8 File Offset: 0x000183F8
		private static void getMonitoringSurvivedProcessMemorySizeDateTimeFormatInfoScanner(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = !Self.wasRightTriggerPressed;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 98;
			A_0 = num;
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x0001A260 File Offset: 0x00018460
		private static void EtwSessiongetIterationCount(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool key = UnityInput.Current.GetKey(100);
			A_6 = key;
			int num = ((!A_6) ? 1 : 0) * 1 + 112;
			A_0 = num;
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0001A2C8 File Offset: 0x000184C8
		private static void opGreaterThanIsReadOnlyAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(10f * -GorillaTagger.Instance.leftHandTransform.right, 5);
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(32, !Settings.rightHanded, 0.1f);
			GorillaTagger.Instance.StartVibration(!Settings.rightHanded, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
			Self.trail = ComponentUtils.AddComponent<TrailRenderer>(GorillaTagger.Instance.offlineVRRig.leftHandTransform);
			Self.trail.startColor = new Color32(byte.MaxValue, 140, 0, byte.MaxValue);
			Self.trail.endColor = new Color32(byte.MaxValue, 140, 0, byte.MaxValue);
			Self.trail.startWidth = 0.05f;
			Self.trail.endWidth = 0f;
			Self.trail.minVertexDistance = 0.05f;
			Self.trail.material.shader = Shader.Find("GUI/Text Shader");
			Self.trail.time = 2f;
			A_0 = 78;
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0001A43C File Offset: 0x0001863C
		private static void NewPermissionElementEventToken(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			A_1 = 0;
		}

		// Token: 0x060003CC RID: 972 RVA: 0x0001A454 File Offset: 0x00018654
		public static void Platforms()
		{
			int num = 40;
			int num2 = 40;
			num2 = 40;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				bool flag3;
				bool flag4;
				bool flag5;
				bool flag6;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref flag2, ref flag3, ref flag4, ref flag5, ref flag6, Self.IsBoxedRequires[num]);
			}
			num2 = 40;
		}

		// Token: 0x060003CD RID: 973 RVA: 0x0001A498 File Offset: 0x00018698
		private static void PreferFairnessSoapNmtoken(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.transform.localScale = new Vector3(1f, 1f, 1f);
			A_1 = 0;
		}

		// Token: 0x060003CE RID: 974 RVA: 0x0001A4D4 File Offset: 0x000186D4
		private static void AssertSecurityManager(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !Self.PlatLEnabled;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 1 + 42;
			A_0 = num;
		}

		// Token: 0x060003CF RID: 975 RVA: 0x0001A538 File Offset: 0x00018738
		private static void EncodingCharBufferVTI(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.disableMovement = false;
			A_1 = 0;
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x0001A560 File Offset: 0x00018760
		private static void InlineFieldCountedMbcsString(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Self.PlatR = GameObject.CreatePrimitive(3);
			Self.PlatR.GetComponent<Renderer>().material.color = Main.outlineColor;
			Self.PlatR.transform.localScale = new Vector3(0.0125f, 0.28f, 0.3825f);
			Self.PlatR.transform.position = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -0.07f, 0f);
			Self.PlatR.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
			Self.PlatREnabled = true;
			Self.PlatLEnabled = true;
			A_0 = 54;
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x0001A650 File Offset: 0x00018850
		private static void getPermitOnlySetInstanceCertFile(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			typeof(GTPlayer).GetField("nativeScale", 36).SetValue(GTPlayer.Instance, 0.3f);
			A_0 = 161;
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x0001A698 File Offset: 0x00018898
		private static void ExportEnumEvents(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 10;
			A_0 = num;
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0001A704 File Offset: 0x00018904
		private static void WinSEmptyCAHolder(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			bool flag = !Self.wasPrimaryButtonPressed;
			A_5 = flag;
			int num = ((!A_5) ? 1 : 0) * 1 + 20;
			A_0 = num;
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0001A76C File Offset: 0x0001896C
		private static void setDateSeparatorClosePunctuation(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 1 + 83;
			A_0 = num;
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0001A7D0 File Offset: 0x000189D0
		private static void EntryPointFlagsGetRootObject(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
			NotifiLib.SendNotification("[<color=yellow>Set Master</color>]: You are now master client!");
			A_0 = 127;
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0001A800 File Offset: 0x00018A00
		private static void getIsAnsiClassgetIsProperty(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_1 = 0;
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x0001A818 File Offset: 0x00018A18
		private static void InteropWindowsFqbnVersion(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !Self.PlatREnabled;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 49;
			A_0 = num;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x0001A87C File Offset: 0x00018A7C
		private static void CCSYSCALLprimes(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			Object.Destroy(GorillaTagger.Instance.offlineVRRig.leftHandTransform.GetComponent<TrailRenderer>());
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_4 = rightGrab;
			int num = ((!A_4) ? 1 : 0) * 1 + 79;
			A_0 = num;
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0001A8FC File Offset: 0x00018AFC
		private static void GetRemoveMethodgetSkipVerification(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			NotifiLib.SendNotification("[<color=yellow>Set Master</color>]: You are already master client!");
			A_0 = 129;
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0001A924 File Offset: 0x00018B24
		private static void setAbbreviatedMonthNamesStringIds(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			Self.wasRightTriggerPressedd = A_3;
			A_1 = 0;
		}

		// Token: 0x060003DB RID: 987 RVA: 0x0001A94C File Offset: 0x00018B4C
		private static void OptionsCurrentDomain(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_6 = rightGrab;
			int num = ((!A_6) ? 1 : 0) * 3 + 48;
			A_0 = num;
		}

		// Token: 0x060003DC RID: 988 RVA: 0x0001A9B0 File Offset: 0x00018BB0
		private static void getLastAccessTimegetIsSecurityCritical(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			bool flag = NetworkSystem.Instance.GameModeString.Contains("MODDED_");
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 3 + 131;
			A_0 = num;
		}

		// Token: 0x060003DD RID: 989 RVA: 0x0001AA1C File Offset: 0x00018C1C
		private static void AddWeeksPause(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			bool flag = !Self.fat;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 56;
			A_0 = num;
		}

		// Token: 0x060003DE RID: 990 RVA: 0x0001AA80 File Offset: 0x00018C80
		private static void AsyncDispatchMessagePi(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			Self.wasPrimaryButtonPressed = A_4;
			A_1 = 0;
		}

		// Token: 0x060003DF RID: 991 RVA: 0x0001AAA8 File Offset: 0x00018CA8
		private static void CreationTimegetChannelPriority(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			typeof(GTPlayer).GetField("nativeScale", 36).SetValue(GTPlayer.Instance, 5f);
			A_0 = 151;
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x0001AAF0 File Offset: 0x00018CF0
		private static void ObjectSecurityFreeHGlobal(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			A_1 = 0;
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x0001AB08 File Offset: 0x00018D08
		private static void ForceLibrarySemanticsGenerateGuidForType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			typeof(GTPlayer).GetField("nativeScale", 36).SetValue(GTPlayer.Instance, 1f);
			A_0 = 156;
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x0001AB50 File Offset: 0x00018D50
		private static void setCompoundAceTypeAssemblyRef(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Object.Destroy(Self.PlatL);
			Self.PlatLEnabled = false;
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_6 = rightGrab;
			int num = ((!A_6) ? 1 : 0) * 3 + 48;
			A_0 = num;
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x0001ABCC File Offset: 0x00018DCC
		private static void setPriorityTask(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			A_1 = 0;
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x0001ABE4 File Offset: 0x00018DE4
		private static void DisallowAppBaseProbingValueFullTrustZoneTrusted(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			Self.isGhostMonkeActive = !Self.isGhostMonkeActive;
			GorillaTagger.Instance.offlineVRRig.enabled = !Self.isGhostMonkeActive;
			Self.wasRightTriggerPressed = A_3;
			A_1 = 0;
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x0001AC38 File Offset: 0x00018E38
		private static void getBinaryLengthXmlIgnoreMemberAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6)
		{
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			A_4 = rightControllerPrimaryButton;
			int num = ((!A_4) ? 1 : 0) * 1 + 18;
			A_0 = num;
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x0001AC9C File Offset: 0x00018E9C
		private static void UIntegerDebuggingFlags(ref int A_0, ref int A_1, ref int A_2)
		{
			GunLibrary.CreateGun(delegate
			{
				int num = 8;
				int num2 = 8;
				num2 = 8;
				while (num2 != 0)
				{
					int num3;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.<>c.RunAndSaveCreateNew[num]);
				}
				num2 = 8;
			}, true);
			A_1 = 0;
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x0001ACE4 File Offset: 0x00018EE4
		private static void LayoutKindNoScrubData(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.transform.position += new Vector3(float.NegativeInfinity, float.NegativeInfinity, float.NegativeInfinity);
			A_1 = 0;
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x0001AD2C File Offset: 0x00018F2C
		public static void HandGun()
		{
			int num = 94;
			int num2 = 94;
			num2 = 94;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 94;
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x0001AD64 File Offset: 0x00018F64
		private static void ConverterRemoveEventHandler(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GorillaSurfaceOverride[] A_4, ref int A_5, ref GorillaSurfaceOverride A_6)
		{
			int num = ((A_5 < A_4.Length) ? 1 : 0) * -2 + 65;
			A_0 = num;
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x0001ADA0 File Offset: 0x00018FA0
		private static void RequestingAssemblyAsync(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			Self.wasRightTriggerPressed = A_3;
			A_1 = 0;
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x0001ADC8 File Offset: 0x00018FC8
		private static void CreateAppDomainLevelOSVERSIONINFOEX(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			typeof(GTPlayer).GetField("nativeScale", 36).SetValue(GTPlayer.Instance, 0.3f);
			A_1 = 0;
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x0001AE10 File Offset: 0x00019010
		public static void SteamArms()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 1;
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x0001AE44 File Offset: 0x00019044
		private static void setFirstPermissionThatFailedOutAttribute(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4)
		{
			Self.IsInvisMonkeActive = !Self.IsInvisMonkeActive;
			GorillaTagger.Instance.offlineVRRig.enabled = !Self.IsInvisMonkeActive;
			GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue);
			Self.wasRightTriggerPressedd = A_3;
			A_1 = 0;
		}

		// Token: 0x060003EE RID: 1006 RVA: 0x0001AEC4 File Offset: 0x000190C4
		private static void SuspendRequestedFamily(ref int A_0, ref int A_1, ref int A_2, ref bool A_3)
		{
			A_1 = 0;
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x0001AEDC File Offset: 0x000190DC
		private static void CompletegetUseStdAsciiRules(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5)
		{
			bool rightControllerSecondaryButton = ControllerInputPoller.instance.rightControllerSecondaryButton;
			A_4 = rightControllerSecondaryButton;
			int num = ((!A_4) ? 1 : 0) * 1 + 154;
			A_0 = num;
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x0001AF40 File Offset: 0x00019140
		private static void KerbSmartCardLogonToLongDateString(ref int A_0, ref int A_1, ref int A_2)
		{
			GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (6.5f / Time.deltaTime)), 5);
			GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(-Physics.gravity, 5);
			A_1 = 0;
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x0001AFAC File Offset: 0x000191AC
		private static void GetDynamicSinkRemotingXmlConfigFileParser(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			GorillaTagger.Instance.rigidbody.transform.position += GTPlayer.Instance.rightControllerTransform.parent.forward * Time.deltaTime * 15f;
			A_0 = 122;
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x0001B010 File Offset: 0x00019210
		private static void setLockedIFormattable(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			GorillaTagger.Instance.rigidbody.transform.position += GTPlayer.Instance.rightControllerTransform.parent.right * Time.deltaTime * -15f;
			A_0 = 121;
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x0001B074 File Offset: 0x00019274
		public static void DisableTagFreeze()
		{
			int num = 169;
			int num2 = 169;
			num2 = 169;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 169;
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x0001B0B8 File Offset: 0x000192B8
		public static void BHopV1()
		{
			int num = 13;
			int num2 = 13;
			num2 = 13;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Self.IsBoxedRequires[num]);
			}
			num2 = 13;
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x0001B0F0 File Offset: 0x000192F0
		private static void InvalidPathCharsConstructorCall()
		{
			Self.IsBoxedRequires = new IntPtr[175];
			Self.IsBoxedRequires[0] = ldftn(BackgroundIntensityUSEROBJECTFLAGS);
			Self.IsBoxedRequires[1] = ldftn(UnrecognizedInterfaceType);
			Self.IsBoxedRequires[2] = ldftn(getStoreSecurityControlPrincipal);
			Self.IsBoxedRequires[3] = ldftn(PreferFairnessSoapNmtoken);
			Self.IsBoxedRequires[4] = ldftn(ObjectStringRuntimeResourceSet);
			Self.IsBoxedRequires[5] = ldftn(KerbSmartCardLogonToLongDateString);
			Self.IsBoxedRequires[6] = ldftn(TRACEGUIDINFODataCollectionStop);
			Self.IsBoxedRequires[7] = ldftn(GetDeclaredMethodsdRaiseOnSerializedEvent);
			Self.IsBoxedRequires[8] = ldftn(getProcessIdOemMinus);
			Self.IsBoxedRequires[9] = ldftn(ExportEnumEvents);
			Self.IsBoxedRequires[10] = ldftn(MonitoringSurvivedMemorySizeAllocateDataSlot);
			Self.IsBoxedRequires[11] = ldftn(SuspendRequestedFamily);
			Self.IsBoxedRequires[12] = ldftn(LayoutKindNoScrubData);
			Self.IsBoxedRequires[13] = ldftn(LineNoSTOREASSEMBLYFILESTATUSFLAGPRESENT);
			Self.IsBoxedRequires[14] = ldftn(CurrentPrincipalFileStreamAsyncResult);
			Self.IsBoxedRequires[15] = ldftn(getSecurityZoneIsClrTypeNamespace);
			Self.IsBoxedRequires[16] = ldftn(getExclusiveSchedulerCultureAwareRandomizedComparer);
			Self.IsBoxedRequires[17] = ldftn(getBinaryLengthXmlIgnoreMemberAttribute);
			Self.IsBoxedRequires[18] = ldftn(WinSEmptyCAHolder);
			Self.IsBoxedRequires[19] = ldftn(UseDllDirectoryForDependenciesAppDomainInitializerInfo);
			Self.IsBoxedRequires[20] = ldftn(SXTasksSetActivityIds);
			Self.IsBoxedRequires[21] = ldftn(lcidEntryPointEntry);
			Self.IsBoxedRequires[22] = ldftn(MonitoringIsEnabledsetTypeInformation);
			Self.IsBoxedRequires[23] = ldftn(AsyncDispatchMessagePi);
			Self.IsBoxedRequires[24] = ldftn(VtableLayoutMaskDSAParameters);
			Self.IsBoxedRequires[25] = ldftn(FoundYearPatternFlaggetIsCompatibilityBehaviorDefined);
			Self.IsBoxedRequires[26] = ldftn(getInArgsDns);
			Self.IsBoxedRequires[27] = ldftn(AdviseCMSUSAGEPATTERN);
			Self.IsBoxedRequires[28] = ldftn(YearEndgetCancellationToken);
			Self.IsBoxedRequires[29] = ldftn(XmlNsForClrTypeWithAssemblyDNd);
			Self.IsBoxedRequires[30] = ldftn(TKINDINTERFACEVARCONST);
			Self.IsBoxedRequires[31] = ldftn(getAccessControlTypeFor);
			Self.IsBoxedRequires[32] = ldftn(AssemblyLoadEventArgsNotAPortableExecutableImage);
			Self.IsBoxedRequires[33] = ldftn(MTACorrectionAlgorithm);
			Self.IsBoxedRequires[34] = ldftn(AppendCharInternalImpl);
			Self.IsBoxedRequires[35] = ldftn(SetterActivatedClientTypeEntry);
			Self.IsBoxedRequires[36] = ldftn(GetKeyAlgorithmParametersAccessAllowedCompound);
			Self.IsBoxedRequires[37] = ldftn(PopipopipopiStandalone);
			Self.IsBoxedRequires[38] = ldftn(MaskGenerationMethodGetObjectForNativeVariant);
			Self.IsBoxedRequires[39] = ldftn(EventHandleMarkAborted);
			Self.IsBoxedRequires[40] = ldftn(GetMethodBaseDP);
			Self.IsBoxedRequires[41] = ldftn(AssertSecurityManager);
			Self.IsBoxedRequires[42] = ldftn(SetAccessRuleSecurityContextSource);
			Self.IsBoxedRequires[43] = ldftn(asyncResultStringWriter);
			Self.IsBoxedRequires[44] = ldftn(PathInternalIsGlobalTypeDefToken);
			Self.IsBoxedRequires[45] = ldftn(setCompoundAceTypeAssemblyRef);
			Self.IsBoxedRequires[46] = ldftn(PurgeAuditRulesGetStringArray);
			Self.IsBoxedRequires[47] = ldftn(OptionsCurrentDomain);
			Self.IsBoxedRequires[48] = ldftn(InteropWindowsFqbnVersion);
			Self.IsBoxedRequires[49] = ldftn(InlineFieldCountedMbcsString);
			Self.IsBoxedRequires[50] = ldftn(CompilationRelaxationsWinapi);
			Self.IsBoxedRequires[51] = ldftn(FUNCFLAGFNONBROWSABLEIMessageSink);
			Self.IsBoxedRequires[52] = ldftn(ConsumptionScopegetQuota);
			Self.IsBoxedRequires[53] = ldftn(IsCopyConstructedCreateQualifiedName);
			Self.IsBoxedRequires[54] = ldftn(getTargetedPatchBandSoapFieldAttribute);
			Self.IsBoxedRequires[55] = ldftn(AddWeeksPause);
			Self.IsBoxedRequires[56] = ldftn(IEnumSTOREDEPLOYMENTMETADATAPROPERTYProviderDefined);
			Self.IsBoxedRequires[57] = ldftn(getEventHandleIntPtrPrivateScope);
			Self.IsBoxedRequires[58] = ldftn(GetHandleSafeThreadHandle);
			Self.IsBoxedRequires[59] = ldftn(IsSemiWeakKeySEHException);
			Self.IsBoxedRequires[60] = ldftn(ConvIReflectionEmit);
			Self.IsBoxedRequires[61] = ldftn(GetXmlElementForInteropTypeStoreOperationMetadataProperty);
			Self.IsBoxedRequires[62] = ldftn(getEventHandlerTypeBestFitMask);
			Self.IsBoxedRequires[63] = ldftn(MscorlibKeyedCollectionDebugViewLengthInTextElements);
			Self.IsBoxedRequires[64] = ldftn(ConverterRemoveEventHandler);
			Self.IsBoxedRequires[65] = ldftn(IReportMatchMembershipConditionDescriptor);
			Self.IsBoxedRequires[66] = ldftn(SearchResultHandlerExecution);
			Self.IsBoxedRequires[67] = ldftn(IFieldInfoLdcIM);
			Self.IsBoxedRequires[68] = ldftn(OtherPunctuationgetHashName);
			Self.IsBoxedRequires[69] = ldftn(ContinuationTaskFromTaskToValueTuple);
			Self.IsBoxedRequires[70] = ldftn(getProxyTypeNamegetDebuggingFlags);
			Self.IsBoxedRequires[71] = ldftn(setPriorityTask);
			Self.IsBoxedRequires[72] = ldftn(LockNumberBufferToDecimal);
			Self.IsBoxedRequires[73] = ldftn(TrustManagerUIContextReadArray);
			Self.IsBoxedRequires[74] = ldftn(CalendarWeekRuleIAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGS);
			Self.IsBoxedRequires[75] = ldftn(ProtectedResourcesLongList);
			Self.IsBoxedRequires[76] = ldftn(opGreaterThanIsReadOnlyAttribute);
			Self.IsBoxedRequires[77] = ldftn(CCSYSCALLprimes);
			Self.IsBoxedRequires[78] = ldftn(setPrivateBinPathAddAttribute);
			Self.IsBoxedRequires[79] = ldftn(GetStringgetAsyncWaitHandle);
			Self.IsBoxedRequires[80] = ldftn(ParentIndexgetEnglishName);
			Self.IsBoxedRequires[81] = ldftn(UnsafeQueueUserWorkItemOffendingNumber);
			Self.IsBoxedRequires[82] = ldftn(setDateSeparatorClosePunctuation);
			Self.IsBoxedRequires[83] = ldftn(MEMORYSTATUSEXLdsfld);
			Self.IsBoxedRequires[84] = ldftn(InitialCountGetView);
			Self.IsBoxedRequires[85] = ldftn(ParamsArraySetField);
			Self.IsBoxedRequires[86] = ldftn(GetValueListSuccess);
			Self.IsBoxedRequires[87] = ldftn(getDeltaLastAccessTime);
			Self.IsBoxedRequires[88] = ldftn(ClassInterfaceTypeSetThrowOnRelative);
			Self.IsBoxedRequires[89] = ldftn(getKeywordsFoundEndOfHebrewNumber);
			Self.IsBoxedRequires[90] = ldftn(setTextCountedMbcsXml);
			Self.IsBoxedRequires[91] = ldftn(getLengthFirstFourDayWeek);
			Self.IsBoxedRequires[92] = ldftn(GenericPrincipalISTOREENUMASSEMBLIESFLAGS);
			Self.IsBoxedRequires[93] = ldftn(MEMORYBASICINFORMATIONKOREANLUNISOLAR);
			Self.IsBoxedRequires[94] = ldftn(SignatureSuccess);
			Self.IsBoxedRequires[95] = ldftn(GetExportedTypesIsEnabled);
			Self.IsBoxedRequires[96] = ldftn(getMonitoringSurvivedProcessMemorySizeDateTimeFormatInfoScanner);
			Self.IsBoxedRequires[97] = ldftn(ClaimsPrincipalSelectorFormat);
			Self.IsBoxedRequires[98] = ldftn(DisallowAppBaseProbingValueFullTrustZoneTrusted);
			Self.IsBoxedRequires[99] = ldftn(RequestingAssemblyAsync);
			Self.IsBoxedRequires[100] = ldftn(LoadPolicyLevelFromFilesetCustomErrorsMode);
			Self.IsBoxedRequires[101] = ldftn(WaitOpenExisting);
			Self.IsBoxedRequires[102] = ldftn(AbortCOMServerEntry);
			Self.IsBoxedRequires[103] = ldftn(setFirstPermissionThatFailedOutAttribute);
			Self.IsBoxedRequires[104] = ldftn(setAbbreviatedMonthNamesStringIds);
			Self.IsBoxedRequires[105] = ldftn(TypeLibrarygetChannelUris);
			Self.IsBoxedRequires[106] = ldftn(GetDynamicSinkRemotingXmlConfigFileParser);
			Self.IsBoxedRequires[107] = ldftn(ApplicationStateAccessDenied);
			Self.IsBoxedRequires[108] = ldftn(setLockedIFormattable);
			Self.IsBoxedRequires[109] = ldftn(FOleAutomationGetInteropFieldTypeAndNameFromXmlElement);
			Self.IsBoxedRequires[110] = ldftn(CdsSyncEtwBCLProviderReleaseWriterLock);
			Self.IsBoxedRequires[111] = ldftn(EtwSessiongetIterationCount);
			Self.IsBoxedRequires[112] = ldftn(AnonymousSidgetDaylightTransitionStart);
			Self.IsBoxedRequires[113] = ldftn(CollectionMemoryCopy);
			Self.IsBoxedRequires[114] = ldftn(CheckOpenSubKeyPermissionGenerated);
			Self.IsBoxedRequires[115] = ldftn(AllowOnlyFipsAlgorithmsLanguageVendor);
			Self.IsBoxedRequires[116] = ldftn(SystemAlarmCallbackObjectgetLoadFrom);
			Self.IsBoxedRequires[117] = ldftn(getDriveTypeUIntArrayTypeInfo);
			Self.IsBoxedRequires[118] = ldftn(NoGCInProgressConcurrentExclusiveSchedulerPair);
			Self.IsBoxedRequires[119] = ldftn(GetEnumeratorDelegateEnumCategories);
			Self.IsBoxedRequires[120] = ldftn(setNumberDecimalSeparatorAtNotation);
			Self.IsBoxedRequires[121] = ldftn(FusionAbandonedMutexException);
			Self.IsBoxedRequires[122] = ldftn(CallingConventionUnregisterChannel);
			Self.IsBoxedRequires[123] = ldftn(getInstanceProviderType);
			Self.IsBoxedRequires[124] = ldftn(TryPopDTDAttribute);
			Self.IsBoxedRequires[125] = ldftn(EntryPointFlagsGetRootObject);
			Self.IsBoxedRequires[126] = ldftn(GetRemoveMethodgetSkipVerification);
			Self.IsBoxedRequires[127] = ldftn(MachineAccountXdrString);
			Self.IsBoxedRequires[128] = ldftn(RandomlyGeneratedCreateSecurityElement);
			Self.IsBoxedRequires[129] = ldftn(getIsAnsiClassgetIsProperty);
			Self.IsBoxedRequires[130] = ldftn(getLastAccessTimegetIsSecurityCritical);
			Self.IsBoxedRequires[131] = ldftn(LUIDSerializationMissingKeys);
			Self.IsBoxedRequires[132] = ldftn(getFullDateTimePatternsetItem);
			Self.IsBoxedRequires[133] = ldftn(TraceOperationEndDocType);
			Self.IsBoxedRequires[134] = ldftn(getPropertyTypegetTypeContainingContracts);
			Self.IsBoxedRequires[135] = ldftn(ObjectSecurityFreeHGlobal);
			Self.IsBoxedRequires[136] = ldftn(EventWaitHandleSecurityIsSecurityCritical);
			Self.IsBoxedRequires[137] = ldftn(UIntegerDebuggingFlags);
			Self.IsBoxedRequires[138] = ldftn(OffsetHighHasLocalValues);
			Self.IsBoxedRequires[139] = ldftn(InlineValueMethodSpec);
			Self.IsBoxedRequires[140] = ldftn(getDefaultGetTagForElement);
			Self.IsBoxedRequires[141] = ldftn(PropertyInfoStringToHGlobalUni);
			Self.IsBoxedRequires[142] = ldftn(DigestMethodNullableComparer);
			Self.IsBoxedRequires[143] = ldftn(getRevisionVersiongetDateEnd);
			Self.IsBoxedRequires[144] = ldftn(NumberNegativePatternResourceManagerNotCreatingResourceSet);
			Self.IsBoxedRequires[145] = ldftn(CreationTimegetChannelPriority);
			Self.IsBoxedRequires[146] = ldftn(GetMillisecondssetExternalProcessMgmt);
			Self.IsBoxedRequires[147] = ldftn(ResourceManagerGetSatelliteAssemblySucceededSetKey);
			Self.IsBoxedRequires[148] = ldftn(DirectoryFinalizationHelper);
			Self.IsBoxedRequires[149] = ldftn(IsErrorRedirectedgetRemotingConfiguration);
			Self.IsBoxedRequires[150] = ldftn(getProtectedResourcesCreateAnySchemeAccess);
			Self.IsBoxedRequires[151] = ldftn(FileAssociationDefaultIconToLowerInvariant);
			Self.IsBoxedRequires[152] = ldftn(BStrWrapperReleaseTypeAttr);
			Self.IsBoxedRequires[153] = ldftn(CompletegetUseStdAsciiRules);
			Self.IsBoxedRequires[154] = ldftn(ForceLibrarySemanticsGenerateGuidForType);
			Self.IsBoxedRequires[155] = ldftn(getPermitOnlySetInstanceCertFile);
			Self.IsBoxedRequires[156] = ldftn(StructuralEqualityComparerIsTokenOfType);
			Self.IsBoxedRequires[157] = ldftn(setTitleCurrentlyExecutingTaskCount);
			Self.IsBoxedRequires[158] = ldftn(AssemblyAlgorithmIdAttributesetAllowMultiple);
			Self.IsBoxedRequires[159] = ldftn(CreateAppDomainLevelOSVERSIONINFOEX);
			Self.IsBoxedRequires[160] = ldftn(NewPermissionElementEventToken);
			Self.IsBoxedRequires[161] = ldftn(RegistryKeySectionValidateSlot);
			Self.IsBoxedRequires[162] = ldftn(CreateFilesIComparer);
			Self.IsBoxedRequires[163] = ldftn(SymbolTokenDigit);
			Self.IsBoxedRequires[164] = ldftn(ServicePackMinoraddResourceResolve);
			Self.IsBoxedRequires[165] = ldftn(setCompoundAceTypeUnwrapPromise);
			Self.IsBoxedRequires[166] = ldftn(getOSDescriptionAssumeNegative);
			Self.IsBoxedRequires[167] = ldftn(AuthenticatedUserSidSelectMethod);
			Self.IsBoxedRequires[168] = ldftn(ValueClassMarshalergetMethodHandle);
			Self.IsBoxedRequires[169] = ldftn(EncodingCharBufferVTI);
			Self.IsBoxedRequires[170] = ldftn(eventMessageBeginGetRequestStream);
			Self.IsBoxedRequires[171] = ldftn(UnicodeByteArraygetTryOffset);
			Self.IsBoxedRequires[172] = ldftn(SavePolicyHasCurrent);
			Self.IsBoxedRequires[173] = ldftn(EncryptValueClassInterfaceAttribute);
			Self.IsBoxedRequires[174] = ldftn(GetRandomFileNameOrderablePartitioner);
		}

		// Token: 0x04000099 RID: 153
		private static bool isFlying;

		// Token: 0x0400009A RID: 154
		private static bool wasPrimaryButtonPressed;

		// Token: 0x0400009B RID: 155
		public static bool p;

		// Token: 0x0400009C RID: 156
		public static float speed;

		// Token: 0x0400009D RID: 157
		public static bool fat;

		// Token: 0x0400009E RID: 158
		private static float splashtimeout;

		// Token: 0x0400009F RID: 159
		public static TrailRenderer trail;

		// Token: 0x040000A0 RID: 160
		public static TrailRenderer trail2;

		// Token: 0x040000A1 RID: 161
		private static bool isGhostMonkeActive;

		// Token: 0x040000A2 RID: 162
		private static bool wasRightTriggerPressed;

		// Token: 0x040000A3 RID: 163
		private static bool IsInvisMonkeActive;

		// Token: 0x040000A4 RID: 164
		private static bool wasRightTriggerPressedd;

		// Token: 0x040000A5 RID: 165
		public static GameObject PlatL;

		// Token: 0x040000A6 RID: 166
		public static bool PlatLEnabled;

		// Token: 0x040000A7 RID: 167
		public static GameObject PlatR;

		// Token: 0x040000A8 RID: 168
		public static bool PlatREnabled;

		// Token: 0x040000A9 RID: 169
		private static string hexColorCode;

		// Token: 0x040000AA RID: 170
		private static Color newColor;

		// Token: 0x040000AB RID: 171
		public bool platL;

		// Token: 0x040000AC RID: 172
		public bool platR;

		// Token: 0x040000AD RID: 173
		private static bool isToggledButtonEnabled;

		// Token: 0x040000AE RID: 174
		private static IntPtr[] IsBoxedRequires;
	}
}
