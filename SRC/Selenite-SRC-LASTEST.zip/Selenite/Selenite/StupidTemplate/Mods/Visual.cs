﻿using System;
using System.Collections.Generic;
using System.Linq;
using GorillaExtensions;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Menu;
using TMPro;
using UnityEngine;

namespace StupidTemplate.Mods
{
	// Token: 0x02000028 RID: 40
	internal class Visual
	{
		// Token: 0x0600047B RID: 1147 RVA: 0x00021630 File Offset: 0x0001F830
		private static void HandledRsaFull(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 143;
			A_0 = num;
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x00021678 File Offset: 0x0001F878
		private static void GetCallTypegetCurrencyGroupSizes(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			A_1 = 0;
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00021690 File Offset: 0x0001F890
		private static void setClipboardVARFLAGFHIDDEN(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 50;
			A_0 = num;
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x000216F8 File Offset: 0x0001F8F8
		private static void EnumPropertiesGetDaysInMonth(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			GameObject gameObject = new GameObject("Line");
			A_7 = gameObject;
			A_7.transform.localScale = new Vector3(0.001f, 0.001f, 0.001f);
			LineRenderer lineRenderer = A_7.AddComponent<LineRenderer>();
			A_8 = lineRenderer;
			A_8.SetPosition(0, GorillaTagger.Instance.offlineVRRig.bodyTransform.position + new Vector3(0f, float.MaxValue, 0f));
			A_8.SetPosition(1, A_5.transform.position);
			A_8.startWidth = 0.001f;
			A_8.endWidth = 0.001f;
			A_8.material.shader = Shader.Find("GUI/Text Shader");
			float num = 0f;
			A_9 = num;
			num = A_9 + Time.deltaTime;
			A_9 = num;
			A_8.material.color = Color.white;
			Object.Destroy(A_7, Time.deltaTime);
			int num2 = (A_4.MoveNext() ? 1 : 0) * -6 + 268;
			A_0 = num2;
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x000218B4 File Offset: 0x0001FAB4
		private static void ServiceCreatePermissionSet(ref int A_0, ref int A_1, ref int A_2, ref Renderer[] A_3, ref int A_4, ref Renderer A_5)
		{
			Renderer renderer = A_3[A_4];
			A_5 = renderer;
			A_5.material.shader = Shader.Find("GUI/Text Shader");
			int num = A_4 + 1;
			A_4 = num;
			int num2 = ((A_4 < A_3.Length) ? 1 : 0) * -2 + 274;
			A_0 = num2;
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x00021954 File Offset: 0x0001FB54
		private static void ParameterTokenIsField(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 237;
			A_0 = num;
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x000219C4 File Offset: 0x0001FBC4
		private static void SqmsetGroup(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_1 = 1;
			A_2 = 173;
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x000219E8 File Offset: 0x0001FBE8
		private static void setAssemblyEvidenceGenerateAppDomainEvidence(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -19 + 102;
			A_0 = num;
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x00021A30 File Offset: 0x0001FC30
		private static void getDataNever(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 160;
			A_0 = num;
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x00021A78 File Offset: 0x0001FC78
		private static void getCalendarTypeApplicationTrust(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			bool flag = !Visual.infectionESP;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 135;
			A_0 = num;
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x00021ADC File Offset: 0x0001FCDC
		private static void getPropertyNamePARAMFLAGFLCID(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			A_0 = 119;
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x00021AF4 File Offset: 0x0001FCF4
		private static void ITupleInternalVisibleToAllHosts(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 24;
			A_0 = num;
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x00021B50 File Offset: 0x0001FD50
		private static void FromCanceledgetPublisher(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GameObject A_4, ref Rigidbody A_5, ref TrailRenderer A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x00021B68 File Offset: 0x0001FD68
		private static void AutoDualsetSoapAction(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			A_0 = 256;
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x00021B80 File Offset: 0x0001FD80
		private static void getTypeTokenBuiltinAccountOperatorsSid(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 193;
			A_0 = num;
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x00021BC8 File Offset: 0x0001FDC8
		public unsafe static void Nametags()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 19;
			int num4 = 19;
			num4 = 19;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num23;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 3)
					{
						num4 = 19;
						if ((int)array[5] != 1)
						{
							num5 = (int)array[1];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num5 + 48 + num2);
								num7 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + (int)array[6] + 48 + num2) + 40 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num7 + 48 + num2);
								if (num8 != -1)
								{
									num9 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num8 + num2);
									array[6] = num8;
									array[0] = 1;
									num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num8 + num2);
									goto IL_1A;
								}
								num7 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num7 + 40 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[3];
							num9 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num5 + num2);
							ex3 = ex2;
							array = (object[])array[2];
							array2 = new object[8];
							array2[5] = 0;
							array2[2] = array;
							array2[3] = ex2;
							array2[6] = num5;
							array2[0] = 2;
							array = array2;
							num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num5 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[4];
							array = (object[])array[2];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							int num14;
							Player player;
							GameObject gameObject;
							TextMeshPro textMeshPro;
							Transform transform;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Int32&,Photon.Realtime.Player&,UnityEngine.GameObject&,TMPro.TextMeshPro&,UnityEngine.Transform&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref num14, ref player, ref gameObject, ref textMeshPro, ref transform, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 19;
						num8 = num13;
						num12 = num8;
					}
					num15 = num3;
					num6 = num15;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num17 * 72 + 40 + num2);
						num19 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num17 * 72 + 24 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num9 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num7 * 72 + 48 + num2);
					num20 = num9;
					num19 = num12;
					num18 = 0;
					num17 = 2;
					for (;;)
					{
						num16 = (num18 + num17) / 2;
						num11 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num16 * 72 + 40 + num2);
						num6 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num16 * 72 + 24 + num2);
						if (num19 < num11 + num6)
						{
							if (num11 <= num19)
							{
								break;
							}
							num17 = num16 - 1;
						}
						else
						{
							num18 = num16 + 1;
						}
					}
					num7 = num16;
					num8 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num7 * 72 + 48 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num17 * 40 + 24 + num2);
						num19 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num17 * 40 + 8 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num5 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num7 * 40 + 32 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A57:
						if (array == null || (int)array[5] == 1)
						{
							num6 = num9;
							while (num6 != num20)
							{
								if (num6 != -1)
								{
									num6 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num6 + 40 + num2);
								}
								else
								{
									num11 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + 48 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num20 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + 40 + num2);
									goto IL_A57;
								}
							}
							goto IL_BEB;
						}
						int num21 = (int)array[6];
						int num22;
						if (num20 == -1)
						{
							num22 = -1;
						}
						else
						{
							num23 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + num2);
							num19 = 0;
							num18 = 2;
							for (;;)
							{
								num17 = (num19 + num18) / 2;
								num16 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num17 * 40 + 24 + num2);
								num11 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num17 * 40 + 8 + num2);
								if (num23 < num16 + num11)
								{
									if (num16 <= num23)
									{
										break;
									}
									num18 = num17 - 1;
								}
								else
								{
									num19 = num17 + 1;
								}
							}
							num5 = num17;
							num7 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num5 * 40 + 32 + num2);
							num22 = num7;
						}
						if (num21 == num22)
						{
							num7 = num9;
							while (num7 != num20)
							{
								if (num7 != -1)
								{
									num7 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num7 + 40 + num2);
								}
								else
								{
									num5 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + 48 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num20 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + 40 + num2);
									goto IL_A57;
								}
							}
							break;
						}
						if ((int)array[6] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[2];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num5 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[2] = array;
					array2[4] = num12;
					array2[6] = num5;
					array2[0] = 1;
					array = array2;
					num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num5 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_BEB:
					num3 = num12;
					continue;
					Block_62:
					num16 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num11 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[2] = array;
					array2[4] = num12;
					array2[6] = num11;
					array2[0] = 1;
					array = array2;
					num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num11 + num2);
				}
				num4 = 19;
				return;
				IL_1CC:
				if (num16 != -1)
				{
					goto IL_1D7;
				}
				goto IL_3F5;
				IL_1D7:
				num6 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num16 + 24 + num2);
				if (3 == num6)
				{
					goto IL_1F6;
				}
				if (1 == num6)
				{
					goto IL_37C;
				}
				goto IL_3F5;
				IL_1F6:
				num11 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num16 + 56 + num2);
				if (num11 == -1)
				{
					goto IL_244;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_22A;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_22A:
				if (type.IsInstanceOfType(array2[3]))
				{
					goto IL_244;
				}
				num16 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num16 + 72 + num2);
				goto IL_1CC;
				IL_244:
				num20 = num16;
				num15 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + 48 + num2) + 40 + num2);
				num7 = (int)array2[7];
				IL_268:
				if (num7 != num15)
				{
					goto IL_2E1;
				}
				num17 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + num2);
				ex3 = array2[3];
				array = (object[])array[2];
				object[] array5 = new object[8];
				array5[5] = 0;
				array5[2] = array;
				array5[3] = array2[3];
				array5[7] = (int)array2[7];
				array5[6] = num20;
				array5[0] = 2;
				array = array5;
				num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + num2);
				goto IL_1A;
				IL_2E1:
				num9 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num7 + 48 + num2);
				if (num9 == -1)
				{
					goto IL_36A;
				}
				num17 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num9 + num2);
				array = (object[])array[2];
				array5 = new object[8];
				array5[5] = 0;
				array5[2] = array;
				array5[3] = array2[3];
				array5[7] = (int)array2[7];
				array5[6] = num9;
				array5[1] = num20;
				array5[0] = 1;
				array = array5;
				num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num9 + num2);
				goto IL_1A;
				IL_36A:
				num7 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num7 + 40 + num2);
				goto IL_268;
				IL_37C:
				num17 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num16 + 32 + num2);
				ex3 = array2[3];
				array = (object[])array[2];
				array5 = new object[8];
				array5[5] = 0;
				array5[2] = array;
				array5[3] = array2[3];
				array5[7] = (int)array2[7];
				array5[6] = num16;
				array5[0] = 0;
				array = array5;
				num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num16 + 32 + num2);
				goto IL_1A;
				IL_3F5:
				array = (object[])array[2];
				ex = array2[3];
				int num24 = (int)array2[7];
				IL_414:
				num16 = num3;
				num17 = num16;
				num18 = 0;
				num19 = 2;
				IL_422:
				num8 = (num18 + num19) / 2;
				num5 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num8 * 72 + 40 + num2);
				num23 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num8 * 72 + 24 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_468;
				}
				if (num5 > num17)
				{
					goto IL_470;
				}
				num15 = num8;
				num20 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 152 + num15 * 72 + 48 + num2);
				num11 = num20;
				num7 = num11;
				goto IL_498;
				IL_468:
				num18 = num8 + 1;
				goto IL_422;
				IL_470:
				num19 = num8 - 1;
				goto IL_422;
				IL_498:
				if (array != null)
				{
					goto IL_4A3;
				}
				goto IL_62A;
				IL_4A3:
				if ((int)array[5] != 1)
				{
					goto IL_55F;
				}
				int num25 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_4C7;
				}
				int num26 = -1;
				goto IL_546;
				IL_4C7:
				int num27 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num11 + num2);
				num23 = 0;
				num5 = 2;
				IL_4D7:
				num8 = (num23 + num5) / 2;
				num19 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num8 * 40 + 24 + num2);
				num18 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num8 * 40 + 8 + num2);
				if (num27 >= num19 + num18)
				{
					goto IL_51C;
				}
				if (num19 > num27)
				{
					goto IL_524;
				}
				num20 = num8;
				num15 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num20 * 40 + 32 + num2);
				num26 = num15;
				goto IL_546;
				IL_51C:
				num23 = num8 + 1;
				goto IL_4D7;
				IL_524:
				num5 = num8 - 1;
				goto IL_4D7;
				IL_546:
				if (num25 != num26)
				{
					goto IL_54E;
				}
				goto IL_62A;
				IL_54E:
				array = (object[])array[2];
				goto IL_498;
				IL_55F:
				num9 = (int)array[0];
				if (num9 == 2 || num9 == 1)
				{
					goto IL_580;
				}
				if (num9 != 0)
				{
					goto IL_57F;
				}
				array2 = array;
				num16 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + (int)array2[6] + 72 + num2);
				goto IL_1CC;
				IL_57F:
				IL_580:
				int num28 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_595;
				}
				int num29 = -1;
				goto IL_614;
				IL_595:
				num17 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num11 + num2);
				num18 = 0;
				num19 = 2;
				IL_5A5:
				num8 = (num18 + num19) / 2;
				num5 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num8 * 40 + 24 + num2);
				num23 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num8 * 40 + 8 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_5EA;
				}
				if (num5 > num17)
				{
					goto IL_5F2;
				}
				num15 = num8;
				num20 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + 368 + num15 * 40 + 32 + num2);
				num29 = num20;
				goto IL_614;
				IL_5EA:
				num18 = num8 + 1;
				goto IL_5A5;
				IL_5F2:
				num19 = num8 - 1;
				goto IL_5A5;
				IL_614:
				if (num28 != num29)
				{
					goto IL_619;
				}
				goto IL_62A;
				IL_619:
				array = (object[])array[2];
				goto IL_498;
				IL_62A:
				if (-1 != num11)
				{
					goto IL_6C8;
				}
				num20 = num7;
				IL_637:
				if (num20 != -1)
				{
					goto IL_643;
				}
				num10 = 1;
				throw ex;
				IL_643:
				num15 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + 48 + num2);
				if (num15 == -1)
				{
					goto IL_6B6;
				}
				num27 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num15 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[2] = array;
				array2[3] = ex;
				array2[7] = num7;
				array2[6] = -1;
				array2[1] = -1;
				array2[0] = 2;
				array = array2;
				num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num15 + num2);
				goto IL_1A;
				IL_6B6:
				num20 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num20 + 40 + num2);
				goto IL_637;
				IL_6C8:
				num6 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num11 + 24 + num2);
				num17 = num6;
				IL_6D9:
				if (num17 != -1)
				{
					goto IL_6F0;
				}
				num11 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num11 + 40 + num2);
				goto IL_498;
				IL_6F0:
				num19 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num17 + 24 + num2);
				if (3 == num19)
				{
					goto IL_71B;
				}
				if (1 == num19)
				{
					goto IL_87D;
				}
				num11 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num11 + 40 + num2);
				goto IL_498;
				IL_71B:
				num18 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num17 + 56 + num2);
				if (num18 == -1)
				{
					goto IL_76A;
				}
				Type type2;
				if ((type2 = array3[num18]) != null)
				{
					goto IL_74F;
				}
				array3[num18] = Type.GetTypeFromHandle(array4[num18]);
				type2 = array3[num18];
				IL_74F:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_76A;
				}
				num17 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num17 + 72 + num2);
				goto IL_6D9;
				IL_76A:
				num27 = num17;
				num23 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num27 + 48 + num2) + 40 + num2);
				num5 = (num7 - num24) * ((num24 == -1) ? 1 : 0) + num24;
				IL_793:
				if (num5 != num23)
				{
					goto IL_7F6;
				}
				int num30 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num27 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[2] = array;
				array2[3] = ex;
				array2[7] = num7;
				array2[6] = num27;
				array2[0] = 2;
				array = array2;
				num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num27 + num2);
				goto IL_1A;
				IL_7F6:
				num8 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num5 + 48 + num2);
				if (num8 == -1)
				{
					goto IL_86B;
				}
				num30 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num8 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[2] = array;
				array2[3] = ex;
				array2[7] = num7;
				array2[6] = num8;
				array2[1] = num27;
				array2[0] = 1;
				array = array2;
				num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num8 + num2);
				goto IL_1A;
				IL_86B:
				num5 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num5 + 40 + num2);
				goto IL_793;
				IL_87D:
				num30 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num17 + 32 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[2] = array;
				array2[3] = ex;
				array2[7] = num7;
				array2[6] = num17;
				array2[0] = 0;
				array = array2;
				num3 = *(ref SubscribeGetRefTypeOfImplType.getUserClaimsdSuppressFinalize + num17 + 32 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num24 = -1;
					goto IL_414;
				}
				throw ex4;
			}
		}

		// Token: 0x0600048B RID: 1163 RVA: 0x00022874 File Offset: 0x00020A74
		private static void RemotingExceptionCurrentUICulture(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 160;
			A_0 = num;
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x000228BC File Offset: 0x00020ABC
		private static void AsIntGetContextNameObject(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 204;
			A_0 = num;
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x00022904 File Offset: 0x00020B04
		private static void FailureReleaseAllResources(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 0;
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x0002291C File Offset: 0x00020B1C
		public unsafe static void Chams()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 2;
			int num4 = 2;
			num4 = 2;
			try
			{
				IL_17:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 19)
					{
						num4 = 2;
						if ((int)array[2] != 0)
						{
							num5 = (int)array[1];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num5 + 24 + num2);
								num7 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + (int)array[4] + 24 + num2) + 16 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num7 + 24 + num2);
								if (num8 != -1)
								{
									num9 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num8 + 64 + num2);
									array[4] = num8;
									array[5] = 0;
									num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num8 + 64 + num2);
									goto IL_17;
								}
								num7 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num7 + 16 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[0];
							num9 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num5 + 64 + num2);
							ex3 = ex2;
							array = (object[])array[6];
							array2 = new object[8];
							array2[2] = 1;
							array2[6] = array;
							array2[0] = ex2;
							array2[4] = num5;
							array2[5] = 1;
							array = array2;
							num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num5 + 64 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[3];
							array = (object[])array[6];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 22)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							bool flag3;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref flag3, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 2;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num16 * 64 + 16 + num2);
						num18 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num16 * 64 + 48 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num7 * 64 + 32 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num15 * 64 + 16 + num2);
						num6 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num15 * 64 + 48 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num7 * 64 + 32 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num16 * 72 + 16 + num2);
						num18 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num16 * 72 + 48 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num7 * 72 + 32 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A7C:
						if (array == null || (int)array[2] == 0)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num6 + 16 + num2);
								}
								else
								{
									num11 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 24 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 16 + num2);
									goto IL_A7C;
								}
							}
							goto IL_C1A;
						}
						int num20 = (int)array[4];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 32 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num16 * 72 + 16 + num2);
								num11 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num16 * 72 + 48 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num5 * 72 + 32 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num7 + 16 + num2);
								}
								else
								{
									num5 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 24 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 16 + num2);
									goto IL_A7C;
								}
							}
							break;
						}
						if ((int)array[4] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[6];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num5 + 64 + num2);
					array2 = new object[8];
					array2[2] = 0;
					array2[6] = array;
					array2[3] = num12;
					array2[4] = num5;
					array2[5] = 0;
					array = array2;
					num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num5 + 64 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C1A:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num11 + 64 + num2);
					array2 = new object[8];
					array2[2] = 0;
					array2[6] = array;
					array2[3] = num12;
					array2[4] = num11;
					array2[5] = 0;
					array = array2;
					num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num11 + 64 + num2);
				}
				num4 = 2;
				return;
				IL_1CE:
				if (num15 != -1)
				{
					goto IL_1D9;
				}
				goto IL_401;
				IL_1D9:
				num6 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num15 + 72 + num2);
				if (1 == num6)
				{
					goto IL_1F8;
				}
				if (3 == num6)
				{
					goto IL_38A;
				}
				goto IL_401;
				IL_1F8:
				num11 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num15 + 48 + num2);
				if (num11 == -1)
				{
					goto IL_246;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_22C;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_22C:
				if (type.IsInstanceOfType(array2[0]))
				{
					goto IL_246;
				}
				num15 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num15 + 88 + num2);
				goto IL_1CE;
				IL_246:
				num19 = num15;
				num14 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 24 + num2) + 16 + num2);
				num7 = (int)array2[7];
				IL_26A:
				if (num7 != num14)
				{
					goto IL_2E9;
				}
				num16 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 64 + num2);
				ex3 = array2[0];
				array = (object[])array[6];
				object[] array5 = new object[8];
				array5[2] = 1;
				array5[6] = array;
				array5[0] = array2[0];
				array5[7] = (int)array2[7];
				array5[4] = num19;
				array5[5] = 1;
				array = array5;
				num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 64 + num2);
				goto IL_17;
				IL_2E9:
				num9 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num7 + 24 + num2);
				if (num9 == -1)
				{
					goto IL_378;
				}
				num16 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num9 + 64 + num2);
				array = (object[])array[6];
				array5 = new object[8];
				array5[2] = 1;
				array5[6] = array;
				array5[0] = array2[0];
				array5[7] = (int)array2[7];
				array5[4] = num9;
				array5[1] = num19;
				array5[5] = 0;
				array = array5;
				num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num9 + 64 + num2);
				goto IL_17;
				IL_378:
				num7 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num7 + 16 + num2);
				goto IL_26A;
				IL_38A:
				num16 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num15 + 8 + num2);
				ex3 = array2[0];
				array = (object[])array[6];
				array5 = new object[8];
				array5[2] = 1;
				array5[6] = array;
				array5[0] = array2[0];
				array5[7] = (int)array2[7];
				array5[4] = num15;
				array5[5] = 2;
				array = array5;
				num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num15 + 8 + num2);
				goto IL_17;
				IL_401:
				array = (object[])array[6];
				ex = array2[0];
				int num23 = (int)array2[7];
				IL_420:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_42E:
				num8 = (num17 + num18) / 2;
				num5 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num8 * 64 + 16 + num2);
				num22 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num8 * 64 + 48 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_474;
				}
				if (num5 > num16)
				{
					goto IL_47C;
				}
				num14 = num8;
				num19 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 152 + num14 * 64 + 32 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4A4;
				IL_474:
				num17 = num8 + 1;
				goto IL_42E;
				IL_47C:
				num18 = num8 - 1;
				goto IL_42E;
				IL_4A4:
				if (array != null)
				{
					goto IL_4AF;
				}
				goto IL_63E;
				IL_4AF:
				if ((int)array[2] != 0)
				{
					goto IL_56F;
				}
				int num24 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_4D3;
				}
				int num25 = -1;
				goto IL_556;
				IL_4D3:
				int num26 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num11 + 32 + num2);
				num22 = 0;
				num5 = 2;
				IL_4E6:
				num8 = (num22 + num5) / 2;
				num18 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num8 * 72 + 16 + num2);
				num17 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num8 * 72 + 48 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_52C;
				}
				if (num18 > num26)
				{
					goto IL_534;
				}
				num19 = num8;
				num14 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num19 * 72 + 32 + num2);
				num25 = num14;
				goto IL_556;
				IL_52C:
				num22 = num8 + 1;
				goto IL_4E6;
				IL_534:
				num5 = num8 - 1;
				goto IL_4E6;
				IL_556:
				if (num24 != num25)
				{
					goto IL_55E;
				}
				goto IL_63E;
				IL_55E:
				array = (object[])array[6];
				goto IL_4A4;
				IL_56F:
				num9 = (int)array[5];
				if (num9 == 1 || num9 == 0)
				{
					goto IL_590;
				}
				if (num9 != 2)
				{
					goto IL_58F;
				}
				array2 = array;
				num15 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + (int)array2[4] + 88 + num2);
				goto IL_1CE;
				IL_58F:
				IL_590:
				int num27 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_5A5;
				}
				int num28 = -1;
				goto IL_628;
				IL_5A5:
				num16 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num11 + 32 + num2);
				num17 = 0;
				num18 = 2;
				IL_5B8:
				num8 = (num17 + num18) / 2;
				num5 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num8 * 72 + 16 + num2);
				num22 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num8 * 72 + 48 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5FE;
				}
				if (num5 > num16)
				{
					goto IL_606;
				}
				num14 = num8;
				num19 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + 344 + num14 * 72 + 32 + num2);
				num28 = num19;
				goto IL_628;
				IL_5FE:
				num17 = num8 + 1;
				goto IL_5B8;
				IL_606:
				num18 = num8 - 1;
				goto IL_5B8;
				IL_628:
				if (num27 != num28)
				{
					goto IL_62D;
				}
				goto IL_63E;
				IL_62D:
				array = (object[])array[6];
				goto IL_4A4;
				IL_63E:
				if (-1 != num11)
				{
					goto IL_6E2;
				}
				num19 = num7;
				IL_64B:
				if (num19 != -1)
				{
					goto IL_657;
				}
				num10 = 1;
				throw ex;
				IL_657:
				num14 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 24 + num2);
				if (num14 == -1)
				{
					goto IL_6D0;
				}
				num26 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num14 + 64 + num2);
				array2 = new object[8];
				array2[2] = 1;
				array2[6] = array;
				array2[0] = ex;
				array2[7] = num7;
				array2[4] = -1;
				array2[1] = -1;
				array2[5] = 1;
				array = array2;
				num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num14 + 64 + num2);
				goto IL_17;
				IL_6D0:
				num19 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num19 + 16 + num2);
				goto IL_64B;
				IL_6E2:
				num6 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num11 + 40 + num2);
				num16 = num6;
				IL_6F3:
				if (num16 != -1)
				{
					goto IL_70A;
				}
				num11 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num11 + 16 + num2);
				goto IL_4A4;
				IL_70A:
				num18 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num16 + 72 + num2);
				if (1 == num18)
				{
					goto IL_735;
				}
				if (3 == num18)
				{
					goto IL_8A3;
				}
				num11 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num11 + 16 + num2);
				goto IL_4A4;
				IL_735:
				num17 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num16 + 48 + num2);
				if (num17 == -1)
				{
					goto IL_784;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_769;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_769:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_784;
				}
				num16 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num16 + 88 + num2);
				goto IL_6F3;
				IL_784:
				num26 = num16;
				num22 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num26 + 24 + num2) + 16 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7AD:
				if (num5 != num22)
				{
					goto IL_816;
				}
				int num29 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num26 + 64 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[2] = 1;
				array2[6] = array;
				array2[0] = ex;
				array2[7] = num7;
				array2[4] = num26;
				array2[5] = 1;
				array = array2;
				num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num26 + 64 + num2);
				goto IL_17;
				IL_816:
				num8 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num5 + 24 + num2);
				if (num8 == -1)
				{
					goto IL_891;
				}
				num29 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num8 + 64 + num2);
				array2 = new object[8];
				array2[2] = 1;
				array2[6] = array;
				array2[0] = ex;
				array2[7] = num7;
				array2[4] = num8;
				array2[1] = num26;
				array2[5] = 0;
				array = array2;
				num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num8 + 64 + num2);
				goto IL_17;
				IL_891:
				num5 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num5 + 16 + num2);
				goto IL_7AD;
				IL_8A3:
				num29 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num16 + 8 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[2] = 1;
				array2[6] = array;
				array2[0] = ex;
				array2[7] = num7;
				array2[4] = num16;
				array2[5] = 2;
				array = array2;
				num3 = *(ref CreateActContextParametersSourceClose.GetGenericParameterConstraintsSafeHandle + num16 + 8 + num2);
				goto IL_17;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_420;
				}
				throw ex4;
			}
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x000235FC File Offset: 0x000217FC
		private static void GetReferenceGuidScheme(ref int A_0, ref int A_1, ref int A_2, ref VRRig[] A_3, ref int A_4, ref VRRig A_5, ref GameObject A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x00023614 File Offset: 0x00021814
		private static void ReadBufferAsyncdAccountOperator(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			bool flag = !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 4 + 111;
			A_0 = num;
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x00023698 File Offset: 0x00021898
		private static void FileIOPermissionAttributeFNonExtensible(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_1 = 1;
			A_2 = 57;
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x000236BC File Offset: 0x000218BC
		private static void CryptoKeyRightsDoubleArray(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			bool flag = A_9 < Enumerable.Count<int>(Visual.bones);
			A_11 = flag;
			int num = (A_11 ? 1 : 0) * -2 + 88;
			A_0 = num;
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x00023728 File Offset: 0x00021928
		private static void SecurityStateNotContentIndexed(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			A_4.Dispose();
			A_1 = 2;
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x00023750 File Offset: 0x00021950
		private static void setSerializationFormatterIntegerIdsSize(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 44;
			A_0 = num;
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x00023798 File Offset: 0x00021998
		private static void TaskExceptionHolderBge(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 2;
			A_2 = 162;
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x000237BC File Offset: 0x000219BC
		private static void IAsyncStateMachineAdd(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 3;
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x000237F8 File Offset: 0x000219F8
		private static void GetXsdTypeIsFixedDateRule(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_5.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
			A_5.mainSkin.material.color = Color.green;
			A_0 = 12;
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x00023854 File Offset: 0x00021A54
		private static void cNamedArgsGetEventToken(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -19 + 102;
			A_0 = num;
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x000238A0 File Offset: 0x00021AA0
		private static void InvalidOperationEmptyStackMRMDictionary(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 0;
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x000238B8 File Offset: 0x00021AB8
		private static void StindRefDispatchReplyMessage(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			A_1 = 0;
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x000238D0 File Offset: 0x00021AD0
		private static void AllowLeadingWhiteStaticIndexRangePartition(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x000238F8 File Offset: 0x00021AF8
		private static void FormatLiteralsSafeSubWindows(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_1 = 2;
			A_2 = 80;
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0002391C File Offset: 0x00021B1C
		private static void TokenTypeXConstants(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 201;
			A_0 = num;
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x00023978 File Offset: 0x00021B78
		private static void IsAttachedgetRenewalTime(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 223;
			A_0 = num;
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x000239E8 File Offset: 0x00021BE8
		private static void NumEndBinaryCrossAppDomainAssembly(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 160;
			A_0 = num;
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x00023A30 File Offset: 0x00021C30
		private static void LocalMachineGetObjectValue(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 175;
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x00023A6C File Offset: 0x00021C6C
		private static void AllCriticalIsLittleEndian(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(A_5.mainSkin.bones[Visual.bones[A_17]].gameObject);
			A_16 = orAddComponent;
			A_16.startWidth = 0.015f;
			A_16.endWidth = 0.015f;
			A_16.startColor = Color.red;
			A_16.endColor = Color.red;
			A_16.material.shader = Shader.Find("GUI/Text Shader");
			A_16.SetPosition(0, A_5.mainSkin.bones[Visual.bones[A_17]].position);
			A_16.SetPosition(1, A_5.mainSkin.bones[Visual.bones[A_17 + 1]].position);
			Object.Destroy(A_16, Time.deltaTime);
			int num = A_17 + 2;
			A_17 = num;
			bool flag = A_17 < Enumerable.Count<int>(Visual.bones);
			A_18 = flag;
			int num2 = (A_18 ? 1 : 0) * -2 + 97;
			A_0 = num2;
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x00023C38 File Offset: 0x00021E38
		private static void AppDomainManagerAssemblySilent(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			A_1 = 0;
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x00023C50 File Offset: 0x00021E50
		private static void SetErrorbuffer(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 237;
			A_0 = num;
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00023CAC File Offset: 0x00021EAC
		private static void BuiltinReplicatorSidTokenUser(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Visual.trail = ComponentUtils.AddComponent<TrailRenderer>(A_5);
			Visual.trail.startColor = Main.outlineColor;
			Visual.trail.endColor = Main.outlineColor;
			Visual.trail.startWidth = 0.05f;
			Visual.trail.endWidth = 0f;
			Visual.trail.minVertexDistance = 0.05f;
			Visual.trail.material.shader = Shader.Find("GUI/Text Shader");
			Visual.trail.time = 2f;
			A_0 = 157;
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x00023D5C File Offset: 0x00021F5C
		private static void DefaultContextUnboxAny(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			bool flag = A_17 < Enumerable.Count<int>(Visual.bones);
			A_18 = flag;
			int num = (A_18 ? 1 : 0) * -2 + 97;
			A_0 = num;
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x00023DC8 File Offset: 0x00021FC8
		private static void FunctionPtrSafeProcessHandle(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			GameObject gameObject = new GameObject("Line");
			A_8 = gameObject;
			A_8.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			LineRenderer lineRenderer = A_8.AddComponent<LineRenderer>();
			A_9 = lineRenderer;
			A_9.SetPosition(0, A_5.transform.position + new Vector3(0f, 9999f, 0f));
			A_9.SetPosition(1, A_5.transform.position - new Vector3(0f, 9999f, 0f));
			A_9.startWidth = 0.015f;
			A_9.endWidth = 0.015f;
			A_9.material.shader = Shader.Find("GUI/Text Shader");
			float num = (float)Time.frameCount / 180f % 1f;
			A_10 = num;
			A_9.material.color = Main.outlineColor;
			Object.Destroy(A_8, Time.deltaTime);
			A_0 = 140;
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x00023F60 File Offset: 0x00022160
		private static void setSourceSwitchWrappers(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 265;
			A_0 = num;
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x00023FBC File Offset: 0x000221BC
		private static void ContinuationTaskCopyToAsync(ref int A_0, ref int A_1, ref int A_2)
		{
			Visual.infectionESP = false;
			A_1 = 0;
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x00023FE0 File Offset: 0x000221E0
		public static void nolowv2()
		{
			int num = 128;
			int num2 = 128;
			num2 = 128;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 128;
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x00024024 File Offset: 0x00022224
		private static void IIDIManifestInformationlpvardesc(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 204;
			A_0 = num;
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x0002406C File Offset: 0x0002226C
		private static void MuiResourceTypeIdStringEntryOid(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 182;
			A_0 = num;
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x000240B4 File Offset: 0x000222B4
		private static void ItemgetPrincipal(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_4.Dispose();
			A_1 = 3;
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x000240DC File Offset: 0x000222DC
		private static void ConvertTimeFromUtcStrongName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			GameObject gameObject = GameObject.CreatePrimitive(0);
			A_13 = gameObject;
			A_13.transform.position = A_5.rightHandTransform.position;
			A_13.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			A_13.GetComponent<Renderer>().material.color = Color.green;
			GameObject gameObject2 = GameObject.CreatePrimitive(0);
			A_14 = gameObject2;
			A_14.transform.position = A_5.leftHandTransform.position;
			A_14.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			A_14.GetComponent<Renderer>().material.color = Color.green;
			GameObject gameObject3 = GameObject.CreatePrimitive(0);
			A_15 = gameObject3;
			A_15.transform.position = A_5.headMesh.transform.position;
			A_15.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			A_15.GetComponent<Renderer>().material.color = Color.green;
			Object.Destroy(A_13, Time.deltaTime);
			Object.Destroy(A_14, Time.deltaTime);
			Object.Destroy(A_15, Time.deltaTime);
			A_13.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_14.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_15.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			Object.Destroy(A_13.GetComponent<MeshCollider>());
			Object.Destroy(A_13.GetComponent<Collider>());
			Object.Destroy(A_13.GetComponent<BoxCollider>());
			Object.Destroy(A_13.GetComponent<SphereCollider>());
			Object.Destroy(A_14.GetComponent<MeshCollider>());
			Object.Destroy(A_14.GetComponent<Collider>());
			Object.Destroy(A_14.GetComponent<BoxCollider>());
			Object.Destroy(A_14.GetComponent<SphereCollider>());
			Object.Destroy(A_15.GetComponent<MeshCollider>());
			Object.Destroy(A_15.GetComponent<Collider>());
			Object.Destroy(A_15.GetComponent<BoxCollider>());
			Object.Destroy(A_15.GetComponent<SphereCollider>());
			A_0 = 40;
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x00024428 File Offset: 0x00022628
		private static void ThrowExceptionForHRSetEnvironmentVariable(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_4.Dispose();
			A_1 = 5;
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x00024450 File Offset: 0x00022650
		public unsafe static void Capsule()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 185;
			int num4 = 185;
			num4 = 185;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 1)
					{
						num4 = 185;
						if ((int)array[0] != 0)
						{
							num5 = (int)array[3];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref HexPolicyLevel.StartupActivationListener + num5 + num2);
								num7 = *(ref HexPolicyLevel.StartupActivationListener + *(ref HexPolicyLevel.StartupActivationListener + (int)array[6] + num2) + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref HexPolicyLevel.StartupActivationListener + num7 + 40 + num2);
								if (num8 != -1)
								{
									num9 = *(ref HexPolicyLevel.StartupActivationListener + num8 + 80 + num2);
									array[6] = num8;
									array[7] = 0;
									num3 = *(ref HexPolicyLevel.StartupActivationListener + num8 + 80 + num2);
									goto IL_23;
								}
								num7 = *(ref HexPolicyLevel.StartupActivationListener + num7 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[2];
							num9 = *(ref HexPolicyLevel.StartupActivationListener + num5 + 80 + num2);
							ex3 = ex2;
							array = (object[])array[5];
							array2 = new object[8];
							array2[0] = 1;
							array2[5] = array;
							array2[2] = ex2;
							array2[6] = num5;
							array2[7] = 1;
							array = array2;
							num3 = *(ref HexPolicyLevel.StartupActivationListener + num5 + 80 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[4];
							array = (object[])array[5];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							GameObject gameObject;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,UnityEngine.GameObject&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref gameObject, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 185;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num16 * 72 + num2);
						num18 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num16 * 72 + 48 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num7 * 72 + 56 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num15 * 72 + num2);
						num6 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num15 * 72 + 48 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num7 * 72 + 56 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num16 * 80 + num2);
						num18 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num16 * 80 + 56 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num7 * 80 + 64 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A5B:
						if (array == null || (int)array[0] == 0)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref HexPolicyLevel.StartupActivationListener + num6 + num2);
								}
								else
								{
									num11 = *(ref HexPolicyLevel.StartupActivationListener + num19 + 40 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref HexPolicyLevel.StartupActivationListener + num19 + num2);
									goto IL_A5B;
								}
							}
							goto IL_BED;
						}
						int num20 = (int)array[6];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref HexPolicyLevel.StartupActivationListener + num19 + 24 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num16 * 80 + num2);
								num11 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num16 * 80 + 56 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num5 * 80 + 64 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref HexPolicyLevel.StartupActivationListener + num7 + num2);
								}
								else
								{
									num5 = *(ref HexPolicyLevel.StartupActivationListener + num19 + 40 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref HexPolicyLevel.StartupActivationListener + num19 + num2);
									goto IL_A5B;
								}
							}
							break;
						}
						if ((int)array[6] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[5];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref HexPolicyLevel.StartupActivationListener + num5 + 80 + num2);
					array2 = new object[8];
					array2[0] = 0;
					array2[5] = array;
					array2[4] = num12;
					array2[6] = num5;
					array2[7] = 0;
					array = array2;
					num3 = *(ref HexPolicyLevel.StartupActivationListener + num5 + 80 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_BED:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref HexPolicyLevel.StartupActivationListener + num11 + 80 + num2);
					array2 = new object[8];
					array2[0] = 0;
					array2[5] = array;
					array2[4] = num12;
					array2[6] = num11;
					array2[7] = 0;
					array = array2;
					num3 = *(ref HexPolicyLevel.StartupActivationListener + num11 + 80 + num2);
				}
				num4 = 185;
				return;
				IL_1D6:
				if (num15 != -1)
				{
					goto IL_1E1;
				}
				goto IL_402;
				IL_1E1:
				num6 = *(ref HexPolicyLevel.StartupActivationListener + num15 + 64 + num2);
				if (0 == num6)
				{
					goto IL_200;
				}
				if (3 == num6)
				{
					goto IL_389;
				}
				goto IL_402;
				IL_200:
				num11 = *(ref HexPolicyLevel.StartupActivationListener + num15 + 72 + num2);
				if (num11 == -1)
				{
					goto IL_24E;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_234;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_234:
				if (type.IsInstanceOfType(array2[2]))
				{
					goto IL_24E;
				}
				num15 = *(ref HexPolicyLevel.StartupActivationListener + num15 + 16 + num2);
				goto IL_1D6;
				IL_24E:
				num19 = num15;
				num14 = *(ref HexPolicyLevel.StartupActivationListener + *(ref HexPolicyLevel.StartupActivationListener + num19 + num2) + num2);
				num7 = (int)array2[1];
				IL_26C:
				if (num7 != num14)
				{
					goto IL_2EB;
				}
				num16 = *(ref HexPolicyLevel.StartupActivationListener + num19 + 80 + num2);
				ex3 = array2[2];
				array = (object[])array[5];
				object[] array5 = new object[8];
				array5[0] = 1;
				array5[5] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[6] = num19;
				array5[7] = 1;
				array = array5;
				num3 = *(ref HexPolicyLevel.StartupActivationListener + num19 + 80 + num2);
				goto IL_23;
				IL_2EB:
				num9 = *(ref HexPolicyLevel.StartupActivationListener + num7 + 40 + num2);
				if (num9 == -1)
				{
					goto IL_37A;
				}
				num16 = *(ref HexPolicyLevel.StartupActivationListener + num9 + 80 + num2);
				array = (object[])array[5];
				array5 = new object[8];
				array5[0] = 1;
				array5[5] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[6] = num9;
				array5[3] = num19;
				array5[7] = 0;
				array = array5;
				num3 = *(ref HexPolicyLevel.StartupActivationListener + num9 + 80 + num2);
				goto IL_23;
				IL_37A:
				num7 = *(ref HexPolicyLevel.StartupActivationListener + num7 + num2);
				goto IL_26C;
				IL_389:
				num16 = *(ref HexPolicyLevel.StartupActivationListener + num15 + 24 + num2);
				ex3 = array2[2];
				array = (object[])array[5];
				array5 = new object[8];
				array5[0] = 1;
				array5[5] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[6] = num15;
				array5[7] = 2;
				array = array5;
				num3 = *(ref HexPolicyLevel.StartupActivationListener + num15 + 24 + num2);
				goto IL_23;
				IL_402:
				array = (object[])array[5];
				ex = array2[2];
				int num23 = (int)array2[1];
				IL_421:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_42F:
				num8 = (num17 + num18) / 2;
				num5 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num8 * 72 + num2);
				num22 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num8 * 72 + 48 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_472;
				}
				if (num5 > num16)
				{
					goto IL_47A;
				}
				num14 = num8;
				num19 = *(ref HexPolicyLevel.StartupActivationListener + 144 + num14 * 72 + 56 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4A2;
				IL_472:
				num17 = num8 + 1;
				goto IL_42F;
				IL_47A:
				num18 = num8 - 1;
				goto IL_42F;
				IL_4A2:
				if (array != null)
				{
					goto IL_4AD;
				}
				goto IL_636;
				IL_4AD:
				if ((int)array[0] != 0)
				{
					goto IL_56A;
				}
				int num24 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_4D1;
				}
				int num25 = -1;
				goto IL_551;
				IL_4D1:
				int num26 = *(ref HexPolicyLevel.StartupActivationListener + num11 + 24 + num2);
				num22 = 0;
				num5 = 2;
				IL_4E4:
				num8 = (num22 + num5) / 2;
				num18 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num8 * 80 + num2);
				num17 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num8 * 80 + 56 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_527;
				}
				if (num18 > num26)
				{
					goto IL_52F;
				}
				num19 = num8;
				num14 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num19 * 80 + 64 + num2);
				num25 = num14;
				goto IL_551;
				IL_527:
				num22 = num8 + 1;
				goto IL_4E4;
				IL_52F:
				num5 = num8 - 1;
				goto IL_4E4;
				IL_551:
				if (num24 != num25)
				{
					goto IL_559;
				}
				goto IL_636;
				IL_559:
				array = (object[])array[5];
				goto IL_4A2;
				IL_56A:
				num9 = (int)array[7];
				if (num9 == 1 || num9 == 0)
				{
					goto IL_58B;
				}
				if (num9 != 2)
				{
					goto IL_58A;
				}
				array2 = array;
				num15 = *(ref HexPolicyLevel.StartupActivationListener + (int)array2[6] + 16 + num2);
				goto IL_1D6;
				IL_58A:
				IL_58B:
				int num27 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_5A0;
				}
				int num28 = -1;
				goto IL_620;
				IL_5A0:
				num16 = *(ref HexPolicyLevel.StartupActivationListener + num11 + 24 + num2);
				num17 = 0;
				num18 = 2;
				IL_5B3:
				num8 = (num17 + num18) / 2;
				num5 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num8 * 80 + num2);
				num22 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num8 * 80 + 56 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5F6;
				}
				if (num5 > num16)
				{
					goto IL_5FE;
				}
				num14 = num8;
				num19 = *(ref HexPolicyLevel.StartupActivationListener + 360 + num14 * 80 + 64 + num2);
				num28 = num19;
				goto IL_620;
				IL_5F6:
				num17 = num8 + 1;
				goto IL_5B3;
				IL_5FE:
				num18 = num8 - 1;
				goto IL_5B3;
				IL_620:
				if (num27 != num28)
				{
					goto IL_625;
				}
				goto IL_636;
				IL_625:
				array = (object[])array[5];
				goto IL_4A2;
				IL_636:
				if (-1 != num11)
				{
					goto IL_6D7;
				}
				num19 = num7;
				IL_643:
				if (num19 != -1)
				{
					goto IL_64F;
				}
				num10 = 1;
				throw ex;
				IL_64F:
				num14 = *(ref HexPolicyLevel.StartupActivationListener + num19 + 40 + num2);
				if (num14 == -1)
				{
					goto IL_6C8;
				}
				num26 = *(ref HexPolicyLevel.StartupActivationListener + num14 + 80 + num2);
				array2 = new object[8];
				array2[0] = 1;
				array2[5] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[6] = -1;
				array2[3] = -1;
				array2[7] = 1;
				array = array2;
				num3 = *(ref HexPolicyLevel.StartupActivationListener + num14 + 80 + num2);
				goto IL_23;
				IL_6C8:
				num19 = *(ref HexPolicyLevel.StartupActivationListener + num19 + num2);
				goto IL_643;
				IL_6D7:
				num6 = *(ref HexPolicyLevel.StartupActivationListener + num11 + 32 + num2);
				num16 = num6;
				IL_6E8:
				if (num16 != -1)
				{
					goto IL_6FC;
				}
				num11 = *(ref HexPolicyLevel.StartupActivationListener + num11 + num2);
				goto IL_4A2;
				IL_6FC:
				num18 = *(ref HexPolicyLevel.StartupActivationListener + num16 + 64 + num2);
				if (0 == num18)
				{
					goto IL_724;
				}
				if (3 == num18)
				{
					goto IL_889;
				}
				num11 = *(ref HexPolicyLevel.StartupActivationListener + num11 + num2);
				goto IL_4A2;
				IL_724:
				num17 = *(ref HexPolicyLevel.StartupActivationListener + num16 + 72 + num2);
				if (num17 == -1)
				{
					goto IL_773;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_758;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_758:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_773;
				}
				num16 = *(ref HexPolicyLevel.StartupActivationListener + num16 + 16 + num2);
				goto IL_6E8;
				IL_773:
				num26 = num16;
				num22 = *(ref HexPolicyLevel.StartupActivationListener + *(ref HexPolicyLevel.StartupActivationListener + num26 + num2) + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_796:
				if (num5 != num22)
				{
					goto IL_7FF;
				}
				int num29 = *(ref HexPolicyLevel.StartupActivationListener + num26 + 80 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[0] = 1;
				array2[5] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[6] = num26;
				array2[7] = 1;
				array = array2;
				num3 = *(ref HexPolicyLevel.StartupActivationListener + num26 + 80 + num2);
				goto IL_23;
				IL_7FF:
				num8 = *(ref HexPolicyLevel.StartupActivationListener + num5 + 40 + num2);
				if (num8 == -1)
				{
					goto IL_87A;
				}
				num29 = *(ref HexPolicyLevel.StartupActivationListener + num8 + 80 + num2);
				array2 = new object[8];
				array2[0] = 1;
				array2[5] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[6] = num8;
				array2[3] = num26;
				array2[7] = 0;
				array = array2;
				num3 = *(ref HexPolicyLevel.StartupActivationListener + num8 + 80 + num2);
				goto IL_23;
				IL_87A:
				num5 = *(ref HexPolicyLevel.StartupActivationListener + num5 + num2);
				goto IL_796;
				IL_889:
				num29 = *(ref HexPolicyLevel.StartupActivationListener + num16 + 24 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[0] = 1;
				array2[5] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[6] = num16;
				array2[7] = 2;
				array = array2;
				num3 = *(ref HexPolicyLevel.StartupActivationListener + num16 + 24 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_421;
				}
				throw ex4;
			}
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x00025100 File Offset: 0x00023300
		private static void ConvertTimeIContextProperty(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 35;
			A_0 = num;
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x0002515C File Offset: 0x0002335C
		private static void SecurityTransparentAttributeINVOKEPROPERTYPUT(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -19 + 102;
			A_0 = num;
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x000251A4 File Offset: 0x000233A4
		private static void getSelfAffectingThreadinggetStart(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 246;
			A_0 = num;
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x000251EC File Offset: 0x000233EC
		private static void PrefixPropertiesToSet(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 27;
			A_0 = num;
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x00025234 File Offset: 0x00023434
		private static void getAsRgetAssemblyFormat(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			A_0 = 245;
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0002524C File Offset: 0x0002344C
		private static void getAccessMaskgetAction(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 201;
			A_0 = num;
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x000252BC File Offset: 0x000234BC
		private static void SpacingCombiningMarkDidNotExist(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(A_5.head.rigTarget.gameObject);
			A_8 = orAddComponent;
			A_8.startWidth = 0.015f;
			A_8.endWidth = 0.015f;
			A_8.startColor = Main.outlineColor;
			A_8.endColor = Main.outlineColor;
			A_8.material.shader = Shader.Find("GUI/Text Shader");
			A_8.SetPosition(0, A_5.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
			A_8.SetPosition(1, A_5.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
			Object.Destroy(A_8, Time.deltaTime);
			int num = 0;
			A_9 = num;
			A_0 = 87;
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x00025438 File Offset: 0x00023638
		private static void TasksGregorianCalendarHelper(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			A_1 = 3;
			A_2 = 248;
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x0002545C File Offset: 0x0002365C
		private static void AdjustSessionIdDynamicSecurityMethodAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 78;
			A_0 = num;
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x000254A4 File Offset: 0x000236A4
		public unsafe static void Tracers()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 232;
			int num4 = 232;
			num4 = 232;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num23;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 232;
						if ((int)array[3] != 0)
						{
							num5 = (int)array[2];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref GuidArrayBrfalse.ManifestHashRC + num5 + 48 + num2);
								num7 = *(ref GuidArrayBrfalse.ManifestHashRC + *(ref GuidArrayBrfalse.ManifestHashRC + (int)array[0] + 48 + num2) + 24 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref GuidArrayBrfalse.ManifestHashRC + num7 + num2);
								if (num8 != -1)
								{
									num9 = *(ref GuidArrayBrfalse.ManifestHashRC + num8 + 16 + num2);
									array[0] = num8;
									array[1] = 1;
									num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num8 + 16 + num2);
									goto IL_23;
								}
								num7 = *(ref GuidArrayBrfalse.ManifestHashRC + num7 + 24 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[4];
							num9 = *(ref GuidArrayBrfalse.ManifestHashRC + num5 + 16 + num2);
							ex3 = ex2;
							array = (object[])array[7];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								1,
								default(object),
								default(object),
								default(object),
								array
							};
							array2[4] = ex2;
							array2[0] = num5;
							array2[1] = 0;
							array = array2;
							num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num5 + 16 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[6];
							array = (object[])array[7];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							GameObject gameObject;
							LineRenderer lineRenderer;
							float num14;
							bool flag3;
							GameObject gameObject2;
							LineRenderer lineRenderer2;
							GameObject gameObject3;
							LineRenderer lineRenderer3;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,System.Single&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,UnityEngine.GameObject&,UnityEngine.LineRenderer&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref gameObject, ref lineRenderer, ref num14, ref flag3, ref gameObject2, ref lineRenderer2, ref gameObject3, ref lineRenderer3, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 232;
						num8 = num13;
						num12 = num8;
					}
					num15 = num3;
					num6 = num15;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num17 * 40 + 16 + num2);
						num19 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num17 * 40 + 32 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num9 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num7 * 40 + num2);
					num20 = num9;
					num19 = num12;
					num18 = 0;
					num17 = 2;
					for (;;)
					{
						num16 = (num18 + num17) / 2;
						num11 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num16 * 40 + 16 + num2);
						num6 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num16 * 40 + 32 + num2);
						if (num19 < num11 + num6)
						{
							if (num11 <= num19)
							{
								break;
							}
							num17 = num16 - 1;
						}
						else
						{
							num18 = num16 + 1;
						}
					}
					num7 = num16;
					num8 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num7 * 40 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num17 * 40 + 16 + num2);
						num19 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num17 * 40 + 32 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num5 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num7 * 40 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A82:
						if (array == null || (int)array[3] == 0)
						{
							num6 = num9;
							while (num6 != num20)
							{
								if (num6 != -1)
								{
									num6 = *(ref GuidArrayBrfalse.ManifestHashRC + num6 + 24 + num2);
								}
								else
								{
									num11 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num20 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + 24 + num2);
									goto IL_A82;
								}
							}
							goto IL_C19;
						}
						int num21 = (int)array[0];
						int num22;
						if (num20 == -1)
						{
							num22 = -1;
						}
						else
						{
							num23 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + 8 + num2);
							num19 = 0;
							num18 = 2;
							for (;;)
							{
								num17 = (num19 + num18) / 2;
								num16 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num17 * 40 + 16 + num2);
								num11 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num17 * 40 + 32 + num2);
								if (num23 < num16 + num11)
								{
									if (num16 <= num23)
									{
										break;
									}
									num18 = num17 - 1;
								}
								else
								{
									num19 = num17 + 1;
								}
							}
							num5 = num17;
							num7 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num5 * 40 + num2);
							num22 = num7;
						}
						if (num21 == num22)
						{
							num7 = num9;
							while (num7 != num20)
							{
								if (num7 != -1)
								{
									num7 = *(ref GuidArrayBrfalse.ManifestHashRC + num7 + 24 + num2);
								}
								else
								{
									num5 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num20 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + 24 + num2);
									goto IL_A82;
								}
							}
							break;
						}
						if ((int)array[0] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[7];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref GuidArrayBrfalse.ManifestHashRC + num5 + 16 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						0,
						default(object),
						default(object),
						default(object),
						array
					};
					array2[6] = num12;
					array2[0] = num5;
					array2[1] = 1;
					array = array2;
					num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num5 + 16 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C19:
					num3 = num12;
					continue;
					Block_62:
					num16 = *(ref GuidArrayBrfalse.ManifestHashRC + num11 + 16 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						0,
						default(object),
						default(object),
						default(object),
						array
					};
					array2[6] = num12;
					array2[0] = num11;
					array2[1] = 1;
					array = array2;
					num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num11 + 16 + num2);
				}
				num4 = 232;
				return;
				IL_1EF:
				if (num16 != -1)
				{
					goto IL_1FA;
				}
				goto IL_420;
				IL_1FA:
				num6 = *(ref GuidArrayBrfalse.ManifestHashRC + num16 + 88 + num2);
				if (2 == num6)
				{
					goto IL_219;
				}
				if (4 == num6)
				{
					goto IL_3A7;
				}
				goto IL_420;
				IL_219:
				num11 = *(ref GuidArrayBrfalse.ManifestHashRC + num16 + 8 + num2);
				if (num11 == -1)
				{
					goto IL_266;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_24C;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_24C:
				if (type.IsInstanceOfType(array2[4]))
				{
					goto IL_266;
				}
				num16 = *(ref GuidArrayBrfalse.ManifestHashRC + num16 + 56 + num2);
				goto IL_1EF;
				IL_266:
				num20 = num16;
				num15 = *(ref GuidArrayBrfalse.ManifestHashRC + *(ref GuidArrayBrfalse.ManifestHashRC + num20 + 48 + num2) + 24 + num2);
				num7 = (int)array2[5];
				IL_28A:
				if (num7 != num15)
				{
					goto IL_309;
				}
				num17 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + 16 + num2);
				ex3 = array2[4];
				array = (object[])array[7];
				object[] array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array
				};
				array5[4] = array2[4];
				array5[5] = (int)array2[5];
				array5[0] = num20;
				array5[1] = 0;
				array = array5;
				num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + 16 + num2);
				goto IL_23;
				IL_309:
				num9 = *(ref GuidArrayBrfalse.ManifestHashRC + num7 + num2);
				if (num9 == -1)
				{
					goto IL_395;
				}
				num17 = *(ref GuidArrayBrfalse.ManifestHashRC + num9 + 16 + num2);
				array = (object[])array[7];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array
				};
				array5[4] = array2[4];
				array5[5] = (int)array2[5];
				array5[0] = num9;
				array5[2] = num20;
				array5[1] = 1;
				array = array5;
				num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num9 + 16 + num2);
				goto IL_23;
				IL_395:
				num7 = *(ref GuidArrayBrfalse.ManifestHashRC + num7 + 24 + num2);
				goto IL_28A;
				IL_3A7:
				num17 = *(ref GuidArrayBrfalse.ManifestHashRC + num16 + 32 + num2);
				ex3 = array2[4];
				array = (object[])array[7];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array
				};
				array5[4] = array2[4];
				array5[5] = (int)array2[5];
				array5[0] = num16;
				array5[1] = 2;
				array = array5;
				num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num16 + 32 + num2);
				goto IL_23;
				IL_420:
				array = (object[])array[7];
				ex = array2[4];
				int num24 = (int)array2[5];
				IL_43F:
				num16 = num3;
				num17 = num16;
				num18 = 0;
				num19 = 2;
				IL_44D:
				num8 = (num18 + num19) / 2;
				num5 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num8 * 40 + 16 + num2);
				num23 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num8 * 40 + 32 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_493;
				}
				if (num5 > num17)
				{
					goto IL_49B;
				}
				num15 = num8;
				num20 = *(ref GuidArrayBrfalse.ManifestHashRC + 168 + num15 * 40 + num2);
				num11 = num20;
				num7 = num11;
				goto IL_4C0;
				IL_493:
				num18 = num8 + 1;
				goto IL_44D;
				IL_49B:
				num19 = num8 - 1;
				goto IL_44D;
				IL_4C0:
				if (array != null)
				{
					goto IL_4CB;
				}
				goto IL_652;
				IL_4CB:
				if ((int)array[3] != 0)
				{
					goto IL_587;
				}
				int num25 = (int)array[0];
				if (num11 != -1)
				{
					goto IL_4EF;
				}
				int num26 = -1;
				goto IL_56E;
				IL_4EF:
				int num27 = *(ref GuidArrayBrfalse.ManifestHashRC + num11 + 8 + num2);
				num23 = 0;
				num5 = 2;
				IL_501:
				num8 = (num23 + num5) / 2;
				num19 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num8 * 40 + 16 + num2);
				num18 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num8 * 40 + 32 + num2);
				if (num27 >= num19 + num18)
				{
					goto IL_547;
				}
				if (num19 > num27)
				{
					goto IL_54F;
				}
				num20 = num8;
				num15 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num20 * 40 + num2);
				num26 = num15;
				goto IL_56E;
				IL_547:
				num23 = num8 + 1;
				goto IL_501;
				IL_54F:
				num5 = num8 - 1;
				goto IL_501;
				IL_56E:
				if (num25 != num26)
				{
					goto IL_576;
				}
				goto IL_652;
				IL_576:
				array = (object[])array[7];
				goto IL_4C0;
				IL_587:
				num9 = (int)array[1];
				if (num9 == 0 || num9 == 1)
				{
					goto IL_5A8;
				}
				if (num9 != 2)
				{
					goto IL_5A7;
				}
				array2 = array;
				num16 = *(ref GuidArrayBrfalse.ManifestHashRC + (int)array2[0] + 56 + num2);
				goto IL_1EF;
				IL_5A7:
				IL_5A8:
				int num28 = (int)array[0];
				if (num11 != -1)
				{
					goto IL_5BD;
				}
				int num29 = -1;
				goto IL_63C;
				IL_5BD:
				num17 = *(ref GuidArrayBrfalse.ManifestHashRC + num11 + 8 + num2);
				num18 = 0;
				num19 = 2;
				IL_5CF:
				num8 = (num18 + num19) / 2;
				num5 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num8 * 40 + 16 + num2);
				num23 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num8 * 40 + 32 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_615;
				}
				if (num5 > num17)
				{
					goto IL_61D;
				}
				num15 = num8;
				num20 = *(ref GuidArrayBrfalse.ManifestHashRC + 288 + num15 * 40 + num2);
				num29 = num20;
				goto IL_63C;
				IL_615:
				num18 = num8 + 1;
				goto IL_5CF;
				IL_61D:
				num19 = num8 - 1;
				goto IL_5CF;
				IL_63C:
				if (num28 != num29)
				{
					goto IL_641;
				}
				goto IL_652;
				IL_641:
				array = (object[])array[7];
				goto IL_4C0;
				IL_652:
				if (-1 != num11)
				{
					goto IL_6F3;
				}
				num20 = num7;
				IL_65F:
				if (num20 != -1)
				{
					goto IL_66B;
				}
				num10 = 1;
				throw ex;
				IL_66B:
				num15 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + num2);
				if (num15 == -1)
				{
					goto IL_6E1;
				}
				num27 = *(ref GuidArrayBrfalse.ManifestHashRC + num15 + 16 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array
				};
				array2[4] = ex;
				array2[5] = num7;
				array2[0] = -1;
				array2[2] = -1;
				array2[1] = 0;
				array = array2;
				num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num15 + 16 + num2);
				goto IL_23;
				IL_6E1:
				num20 = *(ref GuidArrayBrfalse.ManifestHashRC + num20 + 24 + num2);
				goto IL_65F;
				IL_6F3:
				num6 = *(ref GuidArrayBrfalse.ManifestHashRC + num11 + 56 + num2);
				num17 = num6;
				IL_704:
				if (num17 != -1)
				{
					goto IL_71B;
				}
				num11 = *(ref GuidArrayBrfalse.ManifestHashRC + num11 + 24 + num2);
				goto IL_4C0;
				IL_71B:
				num19 = *(ref GuidArrayBrfalse.ManifestHashRC + num17 + 88 + num2);
				if (2 == num19)
				{
					goto IL_746;
				}
				if (4 == num19)
				{
					goto IL_8B0;
				}
				num11 = *(ref GuidArrayBrfalse.ManifestHashRC + num11 + 24 + num2);
				goto IL_4C0;
				IL_746:
				num18 = *(ref GuidArrayBrfalse.ManifestHashRC + num17 + 8 + num2);
				if (num18 == -1)
				{
					goto IL_794;
				}
				Type type2;
				if ((type2 = array3[num18]) != null)
				{
					goto IL_779;
				}
				array3[num18] = Type.GetTypeFromHandle(array4[num18]);
				type2 = array3[num18];
				IL_779:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_794;
				}
				num17 = *(ref GuidArrayBrfalse.ManifestHashRC + num17 + 56 + num2);
				goto IL_704;
				IL_794:
				num27 = num17;
				num23 = *(ref GuidArrayBrfalse.ManifestHashRC + *(ref GuidArrayBrfalse.ManifestHashRC + num27 + 48 + num2) + 24 + num2);
				num5 = (num7 - num24) * ((num24 == -1) ? 1 : 0) + num24;
				IL_7BD:
				if (num5 != num23)
				{
					goto IL_826;
				}
				int num30 = *(ref GuidArrayBrfalse.ManifestHashRC + num27 + 16 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array
				};
				array2[4] = ex;
				array2[5] = num7;
				array2[0] = num27;
				array2[1] = 0;
				array = array2;
				num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num27 + 16 + num2);
				goto IL_23;
				IL_826:
				num8 = *(ref GuidArrayBrfalse.ManifestHashRC + num5 + num2);
				if (num8 == -1)
				{
					goto IL_89E;
				}
				num30 = *(ref GuidArrayBrfalse.ManifestHashRC + num8 + 16 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array
				};
				array2[4] = ex;
				array2[5] = num7;
				array2[0] = num8;
				array2[2] = num27;
				array2[1] = 1;
				array = array2;
				num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num8 + 16 + num2);
				goto IL_23;
				IL_89E:
				num5 = *(ref GuidArrayBrfalse.ManifestHashRC + num5 + 24 + num2);
				goto IL_7BD;
				IL_8B0:
				num30 = *(ref GuidArrayBrfalse.ManifestHashRC + num17 + 32 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					1,
					default(object),
					default(object),
					default(object),
					array
				};
				array2[4] = ex;
				array2[5] = num7;
				array2[0] = num17;
				array2[1] = 2;
				array = array2;
				num3 = *(ref GuidArrayBrfalse.ManifestHashRC + num17 + 32 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num24 = -1;
					goto IL_43F;
				}
				throw ex4;
			}
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x00026180 File Offset: 0x00024380
		private static void etwLogDecoderNLS(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 223;
			A_0 = num;
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x000261DC File Offset: 0x000243DC
		private static void GetAssemblyEvidencegetUseNetCoreTimer(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_1 = 0;
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x000261F4 File Offset: 0x000243F4
		private static void BuiltInDefineByValArray(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GameObject A_4, ref Rigidbody A_5, ref TrailRenderer A_6)
		{
			GameObject gameObject = GameObject.CreatePrimitive(0);
			A_4 = gameObject;
			A_4.transform.position = GTPlayer.Instance.rightControllerTransform.position;
			A_4.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
			A_4.transform.LookAt(Camera.main.transform.position);
			A_4.GetComponent<Renderer>().material.color = Color.magenta;
			Object.Destroy(A_4.GetComponent<MeshCollider>());
			Object.Destroy(A_4.GetComponent<Collider>());
			Object.Destroy(A_4.GetComponent<BoxCollider>());
			Object.Destroy(A_4.GetComponent<SphereCollider>());
			Object.Destroy(A_4, Time.deltaTime);
			Rigidbody rigidbody = A_4.AddComponent(typeof(Rigidbody)) as Rigidbody;
			A_5 = rigidbody;
			A_5.velocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
			TrailRenderer trailRenderer = A_4.AddComponent<TrailRenderer>();
			A_6 = trailRenderer;
			A_6.startColor = Color.magenta;
			A_6.endColor = Color.magenta;
			A_6.startWidth = 0.05f;
			A_6.endWidth = 0f;
			A_6.minVertexDistance = 0.05f;
			A_6.material.shader = Shader.Find("GUI/Text Shader");
			A_6.time = 2f;
			A_1 = 0;
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x00026428 File Offset: 0x00024628
		private static void StartOfUserTypesEnumSByteTypeInfo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_4.Dispose();
			A_1 = 1;
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x00026450 File Offset: 0x00024650
		private static void GetEnvoySinkIgnorePersistedDecision(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 20;
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x0002648C File Offset: 0x0002468C
		public static void LowHZ()
		{
			int num = 122;
			int num2 = 122;
			num2 = 122;
			while (num2 != 0)
			{
				int num3;
				VRRig[] array;
				int num4;
				VRRig vrrig;
				GameObject gameObject;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,VRRig[]&,System.Int32&,VRRig&,UnityEngine.GameObject&), ref num, ref num2, ref num3, ref array, ref num4, ref vrrig, ref gameObject, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 122;
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x000264CC File Offset: 0x000246CC
		private static void lpfuncdescDictionaryNode(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 24;
			A_0 = num;
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0002653C File Offset: 0x0002473C
		public static void nolow()
		{
			int num = 126;
			int num2 = 126;
			num2 = 126;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 126;
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x00026574 File Offset: 0x00024774
		private static void GetExecutingAssemblyAutoResetEvent(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 22;
			A_0 = num;
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x000265DC File Offset: 0x000247DC
		private static void getSetupInformationNested(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			A_0 = 26;
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x000265F4 File Offset: 0x000247F4
		private static void AddAccessRuleDelaySign(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 193;
			A_0 = num;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0002663C File Offset: 0x0002483C
		private static void RegisterInteropXmlElementNData(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 61;
			A_0 = num;
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x000266A4 File Offset: 0x000248A4
		private static void SecurityBindingRedirectsVTBLOB(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(GorillaTagger.Instance.offlineVRRig.head.rigTarget.gameObject);
			A_9 = orAddComponent;
			A_9.startWidth = 0.015f;
			A_9.endWidth = 0.015f;
			A_9.startColor = Color.green;
			A_9.endColor = Color.green;
			A_9.material.shader = Shader.Find("GUI/Text Shader");
			A_9.SetPosition(0, GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
			A_9.SetPosition(1, GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
			Object.Destroy(A_9, Time.deltaTime);
			int num = 0;
			A_10 = num;
			A_0 = 113;
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0002681C File Offset: 0x00024A1C
		private static void ArgumentOutOfRangeBiggerThanCollectiongetConcurrentScheduler(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x00026844 File Offset: 0x00024A44
		public unsafe static void LimbESP()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 30;
			int num4 = 30;
			num4 = 30;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num23;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 2)
					{
						num4 = 30;
						if ((int)array[0] != 0)
						{
							num5 = (int)array[2];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num5 + num2);
								num7 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + *(ref LocalSigremoveContractFailed.BufferGetStringArray + (int)array[7] + num2) + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num7 + 40 + num2);
								if (num8 != -1)
								{
									num9 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num8 + 32 + num2);
									array[7] = num8;
									array[4] = 0;
									num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num8 + 32 + num2);
									goto IL_1A;
								}
								num7 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num7 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[5];
							num9 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num5 + 32 + num2);
							ex3 = ex2;
							array = (object[])array[1];
							array2 = new object[]
							{
								1,
								array,
								default(object),
								default(object),
								default(object),
								ex2,
								default(object),
								num5
							};
							array2[4] = 2;
							array = array2;
							num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num5 + 32 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[3];
							array = (object[])array[1];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							float num14;
							GameObject gameObject;
							GameObject gameObject2;
							GameObject gameObject3;
							bool flag3;
							GameObject gameObject4;
							GameObject gameObject5;
							GameObject gameObject6;
							GameObject gameObject7;
							GameObject gameObject8;
							GameObject gameObject9;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Single&,UnityEngine.GameObject&,UnityEngine.GameObject&,UnityEngine.GameObject&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.GameObject&,UnityEngine.GameObject&,UnityEngine.GameObject&,UnityEngine.GameObject&,UnityEngine.GameObject&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref num14, ref gameObject, ref gameObject2, ref gameObject3, ref flag3, ref gameObject4, ref gameObject5, ref gameObject6, ref gameObject7, ref gameObject8, ref gameObject9, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 30;
						num8 = num13;
						num12 = num8;
					}
					num15 = num3;
					num6 = num15;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num17 * 80 + num2);
						num19 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num17 * 80 + 16 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num9 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num7 * 80 + 72 + num2);
					num20 = num9;
					num19 = num12;
					num18 = 0;
					num17 = 2;
					for (;;)
					{
						num16 = (num18 + num17) / 2;
						num11 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num16 * 80 + num2);
						num6 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num16 * 80 + 16 + num2);
						if (num19 < num11 + num6)
						{
							if (num11 <= num19)
							{
								break;
							}
							num17 = num16 - 1;
						}
						else
						{
							num18 = num16 + 1;
						}
					}
					num7 = num16;
					num8 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num7 * 80 + 72 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num17 * 64 + num2);
						num19 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num17 * 64 + 8 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num5 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num7 * 64 + 56 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A3E:
						if (array == null || (int)array[0] == 0)
						{
							num6 = num9;
							while (num6 != num20)
							{
								if (num6 != -1)
								{
									num6 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num6 + num2);
								}
								else
								{
									num11 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + 40 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num20 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + num2);
									goto IL_A3E;
								}
							}
							goto IL_BCF;
						}
						int num21 = (int)array[7];
						int num22;
						if (num20 == -1)
						{
							num22 = -1;
						}
						else
						{
							num23 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + 24 + num2);
							num19 = 0;
							num18 = 2;
							for (;;)
							{
								num17 = (num19 + num18) / 2;
								num16 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num17 * 64 + num2);
								num11 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num17 * 64 + 8 + num2);
								if (num23 < num16 + num11)
								{
									if (num16 <= num23)
									{
										break;
									}
									num18 = num17 - 1;
								}
								else
								{
									num19 = num17 + 1;
								}
							}
							num5 = num17;
							num7 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num5 * 64 + 56 + num2);
							num22 = num7;
						}
						if (num21 == num22)
						{
							num7 = num9;
							while (num7 != num20)
							{
								if (num7 != -1)
								{
									num7 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num7 + num2);
								}
								else
								{
									num5 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + 40 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num20 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + num2);
									goto IL_A3E;
								}
							}
							break;
						}
						if ((int)array[7] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[1];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num5 + 32 + num2);
					array2 = new object[]
					{
						0,
						array,
						default(object),
						num12,
						default(object),
						default(object),
						default(object),
						num5
					};
					array2[4] = 0;
					array = array2;
					num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num5 + 32 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_BCF:
					num3 = num12;
					continue;
					Block_62:
					num16 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num11 + 32 + num2);
					array2 = new object[]
					{
						0,
						array,
						default(object),
						num12,
						default(object),
						default(object),
						default(object),
						num11
					};
					array2[4] = 0;
					array = array2;
					num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num11 + 32 + num2);
				}
				num4 = 30;
				return;
				IL_1DA:
				if (num16 != -1)
				{
					goto IL_1E5;
				}
				goto IL_405;
				IL_1E5:
				num6 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num16 + 8 + num2);
				if (0 == num6)
				{
					goto IL_203;
				}
				if (1 == num6)
				{
					goto IL_38C;
				}
				goto IL_405;
				IL_203:
				num11 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num16 + 56 + num2);
				if (num11 == -1)
				{
					goto IL_251;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_237;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_237:
				if (type.IsInstanceOfType(array2[5]))
				{
					goto IL_251;
				}
				num16 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num16 + 48 + num2);
				goto IL_1DA;
				IL_251:
				num20 = num16;
				num15 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + num2) + num2);
				num7 = (int)array2[6];
				IL_26F:
				if (num7 != num15)
				{
					goto IL_2EE;
				}
				num17 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + 32 + num2);
				ex3 = array2[5];
				array = (object[])array[1];
				object[] array5 = new object[]
				{
					1,
					array,
					default(object),
					default(object),
					default(object),
					array2[5],
					(int)array2[6],
					num20
				};
				array5[4] = 2;
				array = array5;
				num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + 32 + num2);
				goto IL_1A;
				IL_2EE:
				num9 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num7 + 40 + num2);
				if (num9 == -1)
				{
					goto IL_37D;
				}
				num17 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num9 + 32 + num2);
				array = (object[])array[1];
				array5 = new object[]
				{
					1,
					array,
					default(object),
					default(object),
					default(object),
					array2[5],
					(int)array2[6],
					num9
				};
				array5[2] = num20;
				array5[4] = 0;
				array = array5;
				num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num9 + 32 + num2);
				goto IL_1A;
				IL_37D:
				num7 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num7 + num2);
				goto IL_26F;
				IL_38C:
				num17 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num16 + 40 + num2);
				ex3 = array2[5];
				array = (object[])array[1];
				array5 = new object[]
				{
					1,
					array,
					default(object),
					default(object),
					default(object),
					array2[5],
					(int)array2[6],
					num16
				};
				array5[4] = 1;
				array = array5;
				num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num16 + 40 + num2);
				goto IL_1A;
				IL_405:
				array = (object[])array[1];
				ex = array2[5];
				int num24 = (int)array2[6];
				IL_424:
				num16 = num3;
				num17 = num16;
				num18 = 0;
				num19 = 2;
				IL_432:
				num8 = (num18 + num19) / 2;
				num5 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num8 * 80 + num2);
				num23 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num8 * 80 + 16 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_46F;
				}
				if (num5 > num17)
				{
					goto IL_477;
				}
				num15 = num8;
				num20 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 112 + num15 * 80 + 72 + num2);
				num11 = num20;
				num7 = num11;
				goto IL_49C;
				IL_46F:
				num18 = num8 + 1;
				goto IL_432;
				IL_477:
				num19 = num8 - 1;
				goto IL_432;
				IL_49C:
				if (array != null)
				{
					goto IL_4A7;
				}
				goto IL_62E;
				IL_4A7:
				if ((int)array[0] != 0)
				{
					goto IL_563;
				}
				int num25 = (int)array[7];
				if (num11 != -1)
				{
					goto IL_4CB;
				}
				int num26 = -1;
				goto IL_54A;
				IL_4CB:
				int num27 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num11 + 24 + num2);
				num23 = 0;
				num5 = 2;
				IL_4DE:
				num8 = (num23 + num5) / 2;
				num19 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num8 * 64 + num2);
				num18 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num8 * 64 + 8 + num2);
				if (num27 >= num19 + num18)
				{
					goto IL_520;
				}
				if (num19 > num27)
				{
					goto IL_528;
				}
				num20 = num8;
				num15 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num20 * 64 + 56 + num2);
				num26 = num15;
				goto IL_54A;
				IL_520:
				num23 = num8 + 1;
				goto IL_4DE;
				IL_528:
				num5 = num8 - 1;
				goto IL_4DE;
				IL_54A:
				if (num25 != num26)
				{
					goto IL_552;
				}
				goto IL_62E;
				IL_552:
				array = (object[])array[1];
				goto IL_49C;
				IL_563:
				num9 = (int)array[4];
				if (num9 == 2 || num9 == 0)
				{
					goto IL_584;
				}
				if (num9 != 1)
				{
					goto IL_583;
				}
				array2 = array;
				num16 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + (int)array2[7] + 48 + num2);
				goto IL_1DA;
				IL_583:
				IL_584:
				int num28 = (int)array[7];
				if (num11 != -1)
				{
					goto IL_599;
				}
				int num29 = -1;
				goto IL_618;
				IL_599:
				num17 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num11 + 24 + num2);
				num18 = 0;
				num19 = 2;
				IL_5AC:
				num8 = (num18 + num19) / 2;
				num5 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num8 * 64 + num2);
				num23 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num8 * 64 + 8 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_5EE;
				}
				if (num5 > num17)
				{
					goto IL_5F6;
				}
				num15 = num8;
				num20 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + 352 + num15 * 64 + 56 + num2);
				num29 = num20;
				goto IL_618;
				IL_5EE:
				num18 = num8 + 1;
				goto IL_5AC;
				IL_5F6:
				num19 = num8 - 1;
				goto IL_5AC;
				IL_618:
				if (num28 != num29)
				{
					goto IL_61D;
				}
				goto IL_62E;
				IL_61D:
				array = (object[])array[1];
				goto IL_49C;
				IL_62E:
				if (-1 != num11)
				{
					goto IL_6CF;
				}
				num20 = num7;
				IL_63B:
				if (num20 != -1)
				{
					goto IL_647;
				}
				num10 = 1;
				throw ex;
				IL_647:
				num15 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + 40 + num2);
				if (num15 == -1)
				{
					goto IL_6C0;
				}
				num27 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num15 + 32 + num2);
				array2 = new object[]
				{
					1,
					array,
					default(object),
					default(object),
					default(object),
					ex,
					num7,
					-1
				};
				array2[2] = -1;
				array2[4] = 2;
				array = array2;
				num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num15 + 32 + num2);
				goto IL_1A;
				IL_6C0:
				num20 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num20 + num2);
				goto IL_63B;
				IL_6CF:
				num6 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num11 + 8 + num2);
				num17 = num6;
				IL_6DF:
				if (num17 != -1)
				{
					goto IL_6F3;
				}
				num11 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num11 + num2);
				goto IL_49C;
				IL_6F3:
				num19 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num17 + 8 + num2);
				if (0 == num19)
				{
					goto IL_71A;
				}
				if (1 == num19)
				{
					goto IL_87F;
				}
				num11 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num11 + num2);
				goto IL_49C;
				IL_71A:
				num18 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num17 + 56 + num2);
				if (num18 == -1)
				{
					goto IL_769;
				}
				Type type2;
				if ((type2 = array3[num18]) != null)
				{
					goto IL_74E;
				}
				array3[num18] = Type.GetTypeFromHandle(array4[num18]);
				type2 = array3[num18];
				IL_74E:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_769;
				}
				num17 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num17 + 48 + num2);
				goto IL_6DF;
				IL_769:
				num27 = num17;
				num23 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + *(ref LocalSigremoveContractFailed.BufferGetStringArray + num27 + num2) + num2);
				num5 = (num7 - num24) * ((num24 == -1) ? 1 : 0) + num24;
				IL_78C:
				if (num5 != num23)
				{
					goto IL_7F5;
				}
				int num30 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num27 + 32 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					1,
					array,
					default(object),
					default(object),
					default(object),
					ex,
					num7,
					num27
				};
				array2[4] = 2;
				array = array2;
				num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num27 + 32 + num2);
				goto IL_1A;
				IL_7F5:
				num8 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num5 + 40 + num2);
				if (num8 == -1)
				{
					goto IL_870;
				}
				num30 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num8 + 32 + num2);
				array2 = new object[]
				{
					1,
					array,
					default(object),
					default(object),
					default(object),
					ex,
					num7,
					num8
				};
				array2[2] = num27;
				array2[4] = 0;
				array = array2;
				num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num8 + 32 + num2);
				goto IL_1A;
				IL_870:
				num5 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num5 + num2);
				goto IL_78C;
				IL_87F:
				num30 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num17 + 40 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					1,
					array,
					default(object),
					default(object),
					default(object),
					ex,
					num7,
					num17
				};
				array2[4] = 1;
				array = array2;
				num3 = *(ref LocalSigremoveContractFailed.BufferGetStringArray + num17 + 40 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num24 = -1;
					goto IL_424;
				}
				throw ex4;
			}
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x000274D8 File Offset: 0x000256D8
		private static void CMSUSAGEPATTERNgetIsHomogenous(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref int A_4, ref Transform A_5, ref GameObject A_6, ref float A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x000274F0 File Offset: 0x000256F0
		private static void CurrentDirectoryStringToHString(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_5.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
			A_5.mainSkin.material.color = Color.red;
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 16;
			A_0 = num;
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x0002757C File Offset: 0x0002577C
		private static void getSourceLengthLayoutKind(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 143;
			A_0 = num;
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x000275C4 File Offset: 0x000257C4
		private static void StringTypeNoWindows(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			float num = (float)Time.frameCount / 180f % 1f;
			A_8 = num;
			GameObject gameObject = GameObject.CreatePrimitive(0);
			A_9 = gameObject;
			A_9.transform.position = A_5.rightHandTransform.position;
			A_9.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			A_9.GetComponent<Renderer>().material.color = Color.red;
			GameObject gameObject2 = GameObject.CreatePrimitive(0);
			A_10 = gameObject2;
			A_10.transform.position = A_5.leftHandTransform.position;
			A_10.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			A_10.GetComponent<Renderer>().material.color = Color.red;
			GameObject gameObject3 = GameObject.CreatePrimitive(0);
			A_11 = gameObject3;
			A_11.transform.position = A_5.headMesh.transform.position;
			A_11.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			A_11.GetComponent<Renderer>().material.color = Color.red;
			Object.Destroy(A_9, Time.deltaTime);
			Object.Destroy(A_10, Time.deltaTime);
			Object.Destroy(A_11, Time.deltaTime);
			A_9.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_10.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_11.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			Object.Destroy(A_9.GetComponent<MeshCollider>());
			Object.Destroy(A_9.GetComponent<Collider>());
			Object.Destroy(A_9.GetComponent<BoxCollider>());
			Object.Destroy(A_9.GetComponent<SphereCollider>());
			Object.Destroy(A_10.GetComponent<MeshCollider>());
			Object.Destroy(A_10.GetComponent<Collider>());
			Object.Destroy(A_10.GetComponent<BoxCollider>());
			Object.Destroy(A_10.GetComponent<SphereCollider>());
			Object.Destroy(A_11.GetComponent<MeshCollider>());
			Object.Destroy(A_11.GetComponent<Collider>());
			Object.Destroy(A_11.GetComponent<BoxCollider>());
			Object.Destroy(A_11.GetComponent<SphereCollider>());
			A_0 = 41;
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x00027934 File Offset: 0x00025B34
		private static void PortableEVENTACTIVITYCTRLCREATEID(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_7 = gameObject;
			A_7.transform.position = A_5.transform.position;
			Object.Destroy(A_7.GetComponent<BoxCollider>());
			A_7.transform.localScale = new Vector3(0.5f, 0.5f, 0.3f);
			A_7.transform.LookAt(Camera.main.transform.position);
			A_7.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_7.GetComponent<Renderer>().material.color = Main.outlineColor;
			Object.Destroy(A_7, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 182;
			A_0 = num;
		}

		// Token: 0x060004CE RID: 1230 RVA: 0x00027A78 File Offset: 0x00025C78
		private static void UnsafeQueueUserWorkItemPinnableBufferCacheEventSource(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			A_0 = 120;
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x00027A90 File Offset: 0x00025C90
		private static void getIsPublicFileNotFoundException(ref int A_0, ref int A_1, ref int A_2, ref Renderer[] A_3, ref int A_4, ref Renderer A_5)
		{
			A_1 = 0;
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x00027AA8 File Offset: 0x00025CA8
		private static void FormDDisallowUnassignedGetRandomizedEqualityComparer(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 257;
			A_0 = num;
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x00027AF0 File Offset: 0x00025CF0
		private static void getMaxCapacityWindowHeight(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 252;
			A_0 = num;
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x00027B58 File Offset: 0x00025D58
		private static void GuaranteesNestedPublic(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref int A_4, ref Transform A_5, ref GameObject A_6, ref float A_7, ref bool A_8)
		{
			GameObject gameObject = GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab");
			A_3 = gameObject;
			int num = 0;
			A_4 = num;
			A_0 = 277;
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x00027BA4 File Offset: 0x00025DA4
		private static void ShadowCopyDirectoriesValuegetLoaderOptimization(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_0 = 225;
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x00027BBC File Offset: 0x00025DBC
		private static void getCharCapacityWinCE(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 78;
			A_0 = num;
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x00027C04 File Offset: 0x00025E04
		private static void InvalidCastExceptionAttributeCount(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 246;
			A_0 = num;
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x00027C4C File Offset: 0x00025E4C
		private static void FullTrustAllINVOCATIONFLAGS(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			GameObject gameObject = new GameObject("Line");
			A_12 = gameObject;
			A_12.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			LineRenderer lineRenderer = A_12.AddComponent<LineRenderer>();
			A_13 = lineRenderer;
			A_13.SetPosition(0, A_5.transform.position + new Vector3(0f, 9999f, 0f));
			A_13.SetPosition(1, A_5.transform.position - new Vector3(0f, 9999f, 0f));
			A_13.startWidth = 0.015f;
			A_13.endWidth = 0.015f;
			A_13.material.shader = Shader.Find("GUI/Text Shader");
			A_13.material.color = Color.green;
			Object.Destroy(A_12, Time.deltaTime);
			A_0 = 139;
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x00027DBC File Offset: 0x00025FBC
		private static void DefineUnmanagedResourceResourceExposureAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 188;
			A_0 = num;
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x00027E24 File Offset: 0x00026024
		private static void AsyncTaskCachegetReturnXmlElementName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			GameObject gameObject = new GameObject();
			A_8 = gameObject;
			LineRenderer lineRenderer = A_8.AddComponent<LineRenderer>();
			A_9 = lineRenderer;
			Vector3 position = A_5.transform.position;
			A_10 = position;
			float num = (float)Time.frameCount / 180f % 1f;
			A_11 = num;
			Vector3[] array = new Vector3[5];
			A_12 = array;
			float num2 = 0.5f;
			A_13 = num2;
			float num3 = 0.5f;
			A_14 = num3;
			LineRenderer lineRenderer2 = new GameObject().AddComponent<LineRenderer>();
			A_15 = lineRenderer2;
			A_15.transform.parent = A_8.transform;
			Vector3[] array2 = new Vector3[5];
			A_16 = array2;
			A_16[0] = A_10 + A_5.transform.right * (-A_14 / 2f - 0.02f) + A_5.transform.up * (A_13 / 2f + 0.02f);
			A_16[1] = A_10 + A_5.transform.right * (A_14 / 2f + 0.02f) + A_5.transform.up * (A_13 / 2f + 0.02f);
			A_16[2] = A_10 + A_5.transform.right * (A_14 / 2f + 0.02f) + A_5.transform.up * (-A_13 / 2f - 0.02f);
			A_16[3] = A_10 + A_5.transform.right * (-A_14 / 2f - 0.02f) + A_5.transform.up * (-A_13 / 2f - 0.02f);
			A_16[4] = A_16[0];
			A_15.positionCount = A_16.Length;
			A_15.SetPositions(A_16);
			A_15.startWidth = 0.015f;
			A_15.endWidth = 0.015f;
			Shader shader = Shader.Find("GUI/Text Shader");
			A_17 = shader;
			bool flag = A_17 != null;
			A_18 = flag;
			int num4 = ((!A_18) ? 1 : 0) * 1 + 65;
			A_0 = num4;
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x00028244 File Offset: 0x00026444
		private static void GetConstructorManagedToNativeComInteropStubAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x0002826C File Offset: 0x0002646C
		private static void SupportUrlReflectionOnlyGetAssemblies(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 246;
			A_0 = num;
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x000282B4 File Offset: 0x000264B4
		private static void CreateObjRefBuiltinReplicatorSid(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 208;
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x000282F0 File Offset: 0x000264F0
		private static void TotalFreeSpaceValueAtReturn(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -19 + 102;
			A_0 = num;
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x00028338 File Offset: 0x00026538
		public unsafe static void DisableBreadCrumbs()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 163;
			int num4 = 163;
			num4 = 163;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 3)
					{
						num4 = 163;
						if ((int)array[4] != 1)
						{
							num5 = (int)array[2];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num5 + 48 + num2);
								num7 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + (int)array[6] + 48 + num2) + 32 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num7 + 56 + num2);
								if (num8 != -1)
								{
									num9 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num8 + 72 + num2);
									array[6] = num8;
									array[5] = 1;
									num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num8 + 72 + num2);
									goto IL_23;
								}
								num7 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num7 + 32 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[0];
							num9 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num5 + 72 + num2);
							ex3 = ex2;
							array = (object[])array[7];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								default(object),
								0,
								default(object),
								default(object),
								array
							};
							array2[0] = ex2;
							array2[6] = num5;
							array2[5] = 0;
							array = array2;
							num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num5 + 72 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[3];
							array = (object[])array[7];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 1)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 163;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num16 * 80 + 40 + num2);
						num18 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num16 * 80 + 72 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num7 * 80 + 64 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num15 * 80 + 40 + num2);
						num6 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num15 * 80 + 72 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num7 * 80 + 64 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num16 * 80 + 40 + num2);
						num18 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num16 * 80 + 72 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num7 * 80 + 64 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A86:
						if (array == null || (int)array[4] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num6 + 32 + num2);
								}
								else
								{
									num11 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 56 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 32 + num2);
									goto IL_A86;
								}
							}
							goto IL_C24;
						}
						int num20 = (int)array[6];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 48 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num16 * 80 + 40 + num2);
								num11 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num16 * 80 + 72 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num5 * 80 + 64 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num7 + 32 + num2);
								}
								else
								{
									num5 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 56 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 32 + num2);
									goto IL_A86;
								}
							}
							break;
						}
						if ((int)array[6] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[7];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num5 + 72 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						1,
						default(object),
						default(object),
						array
					};
					array2[3] = num12;
					array2[6] = num5;
					array2[5] = 1;
					array = array2;
					num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num5 + 72 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C24:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num11 + 72 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						1,
						default(object),
						default(object),
						array
					};
					array2[3] = num12;
					array2[6] = num11;
					array2[5] = 1;
					array = array2;
					num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num11 + 72 + num2);
				}
				num4 = 163;
				return;
				IL_1E0:
				if (num15 != -1)
				{
					goto IL_1EB;
				}
				goto IL_40F;
				IL_1EB:
				num6 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num15 + 88 + num2);
				if (2 == num6)
				{
					goto IL_20A;
				}
				if (4 == num6)
				{
					goto IL_39C;
				}
				goto IL_40F;
				IL_20A:
				num11 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num15 + 96 + num2);
				if (num11 == -1)
				{
					goto IL_258;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_23E;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_23E:
				if (type.IsInstanceOfType(array2[0]))
				{
					goto IL_258;
				}
				num15 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num15 + 16 + num2);
				goto IL_1E0;
				IL_258:
				num19 = num15;
				num14 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 48 + num2) + 32 + num2);
				num7 = (int)array2[1];
				IL_27C:
				if (num7 != num14)
				{
					goto IL_2FB;
				}
				num16 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 72 + num2);
				ex3 = array2[0];
				array = (object[])array[7];
				object[] array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array5[0] = array2[0];
				array5[1] = (int)array2[1];
				array5[6] = num19;
				array5[5] = 0;
				array = array5;
				num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 72 + num2);
				goto IL_23;
				IL_2FB:
				num9 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num7 + 56 + num2);
				if (num9 == -1)
				{
					goto IL_38A;
				}
				num16 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num9 + 72 + num2);
				array = (object[])array[7];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array5[0] = array2[0];
				array5[1] = (int)array2[1];
				array5[6] = num9;
				array5[2] = num19;
				array5[5] = 1;
				array = array5;
				num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num9 + 72 + num2);
				goto IL_23;
				IL_38A:
				num7 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num7 + 32 + num2);
				goto IL_27C;
				IL_39C:
				num16 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num15 + num2);
				ex3 = array2[0];
				array = (object[])array[7];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array5[0] = array2[0];
				array5[1] = (int)array2[1];
				array5[6] = num15;
				array5[5] = 2;
				array = array5;
				num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num15 + num2);
				goto IL_23;
				IL_40F:
				array = (object[])array[7];
				ex = array2[0];
				int num23 = (int)array2[1];
				IL_42E:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_43C:
				num8 = (num17 + num18) / 2;
				num5 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num8 * 80 + 40 + num2);
				num22 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num8 * 80 + 72 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_482;
				}
				if (num5 > num16)
				{
					goto IL_48A;
				}
				num14 = num8;
				num19 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 176 + num14 * 80 + 64 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4B2;
				IL_482:
				num17 = num8 + 1;
				goto IL_43C;
				IL_48A:
				num18 = num8 - 1;
				goto IL_43C;
				IL_4B2:
				if (array != null)
				{
					goto IL_4BD;
				}
				goto IL_64C;
				IL_4BD:
				if ((int)array[4] != 1)
				{
					goto IL_57D;
				}
				int num24 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_4E1;
				}
				int num25 = -1;
				goto IL_564;
				IL_4E1:
				int num26 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num11 + 48 + num2);
				num22 = 0;
				num5 = 2;
				IL_4F4:
				num8 = (num22 + num5) / 2;
				num18 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num8 * 80 + 40 + num2);
				num17 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num8 * 80 + 72 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_53A;
				}
				if (num18 > num26)
				{
					goto IL_542;
				}
				num19 = num8;
				num14 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num19 * 80 + 64 + num2);
				num25 = num14;
				goto IL_564;
				IL_53A:
				num22 = num8 + 1;
				goto IL_4F4;
				IL_542:
				num5 = num8 - 1;
				goto IL_4F4;
				IL_564:
				if (num24 != num25)
				{
					goto IL_56C;
				}
				goto IL_64C;
				IL_56C:
				array = (object[])array[7];
				goto IL_4B2;
				IL_57D:
				num9 = (int)array[5];
				if (num9 == 0 || num9 == 1)
				{
					goto IL_59E;
				}
				if (num9 != 2)
				{
					goto IL_59D;
				}
				array2 = array;
				num15 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + (int)array2[6] + 16 + num2);
				goto IL_1E0;
				IL_59D:
				IL_59E:
				int num27 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_5B3;
				}
				int num28 = -1;
				goto IL_636;
				IL_5B3:
				num16 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num11 + 48 + num2);
				num17 = 0;
				num18 = 2;
				IL_5C6:
				num8 = (num17 + num18) / 2;
				num5 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num8 * 80 + 40 + num2);
				num22 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num8 * 80 + 72 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_60C;
				}
				if (num5 > num16)
				{
					goto IL_614;
				}
				num14 = num8;
				num19 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + 416 + num14 * 80 + 64 + num2);
				num28 = num19;
				goto IL_636;
				IL_60C:
				num17 = num8 + 1;
				goto IL_5C6;
				IL_614:
				num18 = num8 - 1;
				goto IL_5C6;
				IL_636:
				if (num27 != num28)
				{
					goto IL_63B;
				}
				goto IL_64C;
				IL_63B:
				array = (object[])array[7];
				goto IL_4B2;
				IL_64C:
				if (-1 != num11)
				{
					goto IL_6F0;
				}
				num19 = num7;
				IL_659:
				if (num19 != -1)
				{
					goto IL_665;
				}
				num10 = 1;
				throw ex;
				IL_665:
				num14 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 56 + num2);
				if (num14 == -1)
				{
					goto IL_6DE;
				}
				num26 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num14 + 72 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[0] = ex;
				array2[1] = num7;
				array2[6] = -1;
				array2[2] = -1;
				array2[5] = 0;
				array = array2;
				num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num14 + 72 + num2);
				goto IL_23;
				IL_6DE:
				num19 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num19 + 32 + num2);
				goto IL_659;
				IL_6F0:
				num6 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num11 + 64 + num2);
				num16 = num6;
				IL_701:
				if (num16 != -1)
				{
					goto IL_718;
				}
				num11 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num11 + 32 + num2);
				goto IL_4B2;
				IL_718:
				num18 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num16 + 88 + num2);
				if (2 == num18)
				{
					goto IL_743;
				}
				if (4 == num18)
				{
					goto IL_8B1;
				}
				num11 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num11 + 32 + num2);
				goto IL_4B2;
				IL_743:
				num17 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num16 + 96 + num2);
				if (num17 == -1)
				{
					goto IL_792;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_777;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_777:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_792;
				}
				num16 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num16 + 16 + num2);
				goto IL_701;
				IL_792:
				num26 = num16;
				num22 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num26 + 48 + num2) + 32 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7BB:
				if (num5 != num22)
				{
					goto IL_824;
				}
				int num29 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num26 + 72 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[0] = ex;
				array2[1] = num7;
				array2[6] = num26;
				array2[5] = 0;
				array = array2;
				num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num26 + 72 + num2);
				goto IL_23;
				IL_824:
				num8 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num5 + 56 + num2);
				if (num8 == -1)
				{
					goto IL_89F;
				}
				num29 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num8 + 72 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[0] = ex;
				array2[1] = num7;
				array2[6] = num8;
				array2[2] = num26;
				array2[5] = 1;
				array = array2;
				num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num8 + 72 + num2);
				goto IL_23;
				IL_89F:
				num5 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num5 + 32 + num2);
				goto IL_7BB;
				IL_8B1:
				num29 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num16 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[0] = ex;
				array2[1] = num7;
				array2[6] = num16;
				array2[5] = 2;
				array = array2;
				num3 = *(ref HasFalseValueCHARINFO.ICspAsymmetricAlgorithmmowned + num16 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_42E;
				}
				throw ex4;
			}
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x00029024 File Offset: 0x00027224
		public unsafe static void Sphere3D()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 218;
			int num4 = 218;
			num4 = 218;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 3)
					{
						num4 = 218;
						if ((int)array[5] != 1)
						{
							num5 = (int)array[0];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num5 + 48 + num2);
								num7 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + (int)array[4] + 48 + num2) + 40 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num7 + 48 + num2);
								if (num8 != -1)
								{
									num9 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num8 + 72 + num2);
									array[4] = num8;
									array[7] = 1;
									num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num8 + 72 + num2);
									goto IL_23;
								}
								num7 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num7 + 40 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[2];
							num9 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num5 + 72 + num2);
							ex3 = ex2;
							array = (object[])array[3];
							array2 = new object[8];
							array2[5] = 0;
							array2[3] = array;
							array2[2] = ex2;
							array2[4] = num5;
							array2[7] = 2;
							array = array2;
							num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num5 + 72 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[6];
							array = (object[])array[3];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 5)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							GameObject gameObject;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,UnityEngine.GameObject&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref gameObject, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 218;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num16 * 64 + 40 + num2);
						num18 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num16 * 64 + 24 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num7 * 64 + 32 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num15 * 64 + 40 + num2);
						num6 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num15 * 64 + 24 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num7 * 64 + 32 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num16 * 80 + 48 + num2);
						num18 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num16 * 80 + 32 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num7 * 80 + 56 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A91:
						if (array == null || (int)array[5] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num6 + 40 + num2);
								}
								else
								{
									num11 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 48 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 40 + num2);
									goto IL_A91;
								}
							}
							goto IL_C2F;
						}
						int num20 = (int)array[4];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 64 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num16 * 80 + 48 + num2);
								num11 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num16 * 80 + 32 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num5 * 80 + 56 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num7 + 40 + num2);
								}
								else
								{
									num5 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 48 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 40 + num2);
									goto IL_A91;
								}
							}
							break;
						}
						if ((int)array[4] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[3];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num5 + 72 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[3] = array;
					array2[6] = num12;
					array2[4] = num5;
					array2[7] = 1;
					array = array2;
					num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num5 + 72 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C2F:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num11 + 72 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[3] = array;
					array2[6] = num12;
					array2[4] = num11;
					array2[7] = 1;
					array = array2;
					num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num11 + 72 + num2);
				}
				num4 = 218;
				return;
				IL_1E1:
				if (num15 != -1)
				{
					goto IL_1EC;
				}
				goto IL_415;
				IL_1EC:
				num6 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num15 + 32 + num2);
				if (3 == num6)
				{
					goto IL_20B;
				}
				if (1 == num6)
				{
					goto IL_39C;
				}
				goto IL_415;
				IL_20B:
				num11 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num15 + 56 + num2);
				if (num11 == -1)
				{
					goto IL_258;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_23F;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_23F:
				if (type.IsInstanceOfType(array2[2]))
				{
					goto IL_258;
				}
				num15 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num15 + 8 + num2);
				goto IL_1E1;
				IL_258:
				num19 = num15;
				num14 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 48 + num2) + 40 + num2);
				num7 = (int)array2[1];
				IL_27C:
				if (num7 != num14)
				{
					goto IL_2FB;
				}
				num16 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 72 + num2);
				ex3 = array2[2];
				array = (object[])array[3];
				object[] array5 = new object[8];
				array5[5] = 0;
				array5[3] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[4] = num19;
				array5[7] = 2;
				array = array5;
				num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 72 + num2);
				goto IL_23;
				IL_2FB:
				num9 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num7 + 48 + num2);
				if (num9 == -1)
				{
					goto IL_38A;
				}
				num16 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num9 + 72 + num2);
				array = (object[])array[3];
				array5 = new object[8];
				array5[5] = 0;
				array5[3] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[4] = num9;
				array5[0] = num19;
				array5[7] = 1;
				array = array5;
				num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num9 + 72 + num2);
				goto IL_23;
				IL_38A:
				num7 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num7 + 40 + num2);
				goto IL_27C;
				IL_39C:
				num16 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num15 + 24 + num2);
				ex3 = array2[2];
				array = (object[])array[3];
				array5 = new object[8];
				array5[5] = 0;
				array5[3] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[4] = num15;
				array5[7] = 0;
				array = array5;
				num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num15 + 24 + num2);
				goto IL_23;
				IL_415:
				array = (object[])array[3];
				ex = array2[2];
				int num23 = (int)array2[1];
				IL_434:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_442:
				num8 = (num17 + num18) / 2;
				num5 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num8 * 64 + 40 + num2);
				num22 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num8 * 64 + 24 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_488;
				}
				if (num5 > num16)
				{
					goto IL_490;
				}
				num14 = num8;
				num19 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 152 + num14 * 64 + 32 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4B8;
				IL_488:
				num17 = num8 + 1;
				goto IL_442;
				IL_490:
				num18 = num8 - 1;
				goto IL_442;
				IL_4B8:
				if (array != null)
				{
					goto IL_4C3;
				}
				goto IL_652;
				IL_4C3:
				if ((int)array[5] != 1)
				{
					goto IL_583;
				}
				int num24 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_4E7;
				}
				int num25 = -1;
				goto IL_56A;
				IL_4E7:
				int num26 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num11 + 64 + num2);
				num22 = 0;
				num5 = 2;
				IL_4FA:
				num8 = (num22 + num5) / 2;
				num18 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num8 * 80 + 48 + num2);
				num17 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num8 * 80 + 32 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_540;
				}
				if (num18 > num26)
				{
					goto IL_548;
				}
				num19 = num8;
				num14 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num19 * 80 + 56 + num2);
				num25 = num14;
				goto IL_56A;
				IL_540:
				num22 = num8 + 1;
				goto IL_4FA;
				IL_548:
				num5 = num8 - 1;
				goto IL_4FA;
				IL_56A:
				if (num24 != num25)
				{
					goto IL_572;
				}
				goto IL_652;
				IL_572:
				array = (object[])array[3];
				goto IL_4B8;
				IL_583:
				num9 = (int)array[7];
				if (num9 == 2 || num9 == 1)
				{
					goto IL_5A4;
				}
				if (num9 != 0)
				{
					goto IL_5A3;
				}
				array2 = array;
				num15 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + (int)array2[4] + 8 + num2);
				goto IL_1E1;
				IL_5A3:
				IL_5A4:
				int num27 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_5B9;
				}
				int num28 = -1;
				goto IL_63C;
				IL_5B9:
				num16 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num11 + 64 + num2);
				num17 = 0;
				num18 = 2;
				IL_5CC:
				num8 = (num17 + num18) / 2;
				num5 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num8 * 80 + 48 + num2);
				num22 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num8 * 80 + 32 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_612;
				}
				if (num5 > num16)
				{
					goto IL_61A;
				}
				num14 = num8;
				num19 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + 344 + num14 * 80 + 56 + num2);
				num28 = num19;
				goto IL_63C;
				IL_612:
				num17 = num8 + 1;
				goto IL_5CC;
				IL_61A:
				num18 = num8 - 1;
				goto IL_5CC;
				IL_63C:
				if (num27 != num28)
				{
					goto IL_641;
				}
				goto IL_652;
				IL_641:
				array = (object[])array[3];
				goto IL_4B8;
				IL_652:
				if (-1 != num11)
				{
					goto IL_6F6;
				}
				num19 = num7;
				IL_65F:
				if (num19 != -1)
				{
					goto IL_66B;
				}
				num10 = 1;
				throw ex;
				IL_66B:
				num14 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 48 + num2);
				if (num14 == -1)
				{
					goto IL_6E4;
				}
				num26 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num14 + 72 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[3] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[4] = -1;
				array2[0] = -1;
				array2[7] = 2;
				array = array2;
				num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num14 + 72 + num2);
				goto IL_23;
				IL_6E4:
				num19 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num19 + 40 + num2);
				goto IL_65F;
				IL_6F6:
				num6 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num11 + 24 + num2);
				num16 = num6;
				IL_707:
				if (num16 != -1)
				{
					goto IL_71E;
				}
				num11 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num11 + 40 + num2);
				goto IL_4B8;
				IL_71E:
				num18 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num16 + 32 + num2);
				if (3 == num18)
				{
					goto IL_749;
				}
				if (1 == num18)
				{
					goto IL_8B6;
				}
				num11 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num11 + 40 + num2);
				goto IL_4B8;
				IL_749:
				num17 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num16 + 56 + num2);
				if (num17 == -1)
				{
					goto IL_797;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_77D;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_77D:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_797;
				}
				num16 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num16 + 8 + num2);
				goto IL_707;
				IL_797:
				num26 = num16;
				num22 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num26 + 48 + num2) + 40 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7C0:
				if (num5 != num22)
				{
					goto IL_829;
				}
				int num29 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num26 + 72 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[3] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[4] = num26;
				array2[7] = 2;
				array = array2;
				num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num26 + 72 + num2);
				goto IL_23;
				IL_829:
				num8 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num5 + 48 + num2);
				if (num8 == -1)
				{
					goto IL_8A4;
				}
				num29 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num8 + 72 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[3] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[4] = num8;
				array2[0] = num26;
				array2[7] = 1;
				array = array2;
				num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num8 + 72 + num2);
				goto IL_23;
				IL_8A4:
				num5 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num5 + 40 + num2);
				goto IL_7C0;
				IL_8B6:
				num29 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num16 + 24 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[3] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[4] = num16;
				array2[7] = 0;
				array = array2;
				num3 = *(ref CriticalFinalizerObjectIDLFLAGFRETVAL.CrossAppDomainSinkGetDirectoryRoot + num16 + 24 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_434;
				}
				throw ex4;
			}
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x00029D18 File Offset: 0x00027F18
		private static void setParamTypesGetInt(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			bool flag = A_5 < Enumerable.Count<int>(Visual.bones);
			A_7 = flag;
			int num = (A_7 ? 1 : 0) * -2 + 109;
			A_0 = num;
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x00029D84 File Offset: 0x00027F84
		private static void PARAMFLAGFOUTIsEquivalentTo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x00029DAC File Offset: 0x00027FAC
		private static void ProvidedSecurityInfoStringValue(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 263;
			A_0 = num;
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x00029E14 File Offset: 0x00028014
		private static void getStringValueSerializationNullKey(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_0 = 192;
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x00029E2C File Offset: 0x0002802C
		private static void IsValidAttributeValueISODecoder(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			A_1 = 4;
			A_2 = 46;
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x00029E50 File Offset: 0x00028050
		private static void IsMulticastPm(ref int A_0, ref int A_1, ref int A_2)
		{
			Visual.infectionESP = false;
			Visual.trail = new TrailRenderer();
			Visual.bones = new int[]
			{
				4,
				3,
				5,
				4,
				19,
				18,
				20,
				19,
				3,
				18,
				21,
				20,
				22,
				21,
				25,
				21,
				29,
				21,
				31,
				29,
				27,
				25,
				24,
				22,
				6,
				5,
				7,
				6,
				10,
				6,
				14,
				6,
				16,
				14,
				12,
				10,
				9,
				7
			};
			A_1 = 0;
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x00029E98 File Offset: 0x00028098
		public static void DisableAllMaterials()
		{
			int num = 271;
			int num2 = 271;
			num2 = 271;
			while (num2 != 0)
			{
				int num3;
				Renderer[] array;
				int num4;
				Renderer renderer;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Renderer[]&,System.Int32&,UnityEngine.Renderer&), ref num, ref num2, ref num3, ref array, ref num4, ref renderer, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 271;
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x00029EE0 File Offset: 0x000280E0
		private static void MetadatasetPersist(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x00029F08 File Offset: 0x00028108
		private static void getExceptionTypeTokenUnboxAny(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_0 = 170;
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x00029F20 File Offset: 0x00028120
		private static void setWindowLeftIsModule(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			GameObject gameObject = GameObject.CreatePrimitive(0);
			A_7 = gameObject;
			A_7.transform.position = A_5.transform.position;
			Object.Destroy(A_7.GetComponent<CapsuleCollider>());
			A_7.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
			A_7.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_7.GetComponent<Renderer>().material.color = Main.outlineColor;
			Object.Destroy(A_7, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 226;
			A_0 = num;
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x0002A040 File Offset: 0x00028240
		private static void MessageDictionaryLaunchMail(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			bool flag = A_5 != GorillaTagger.Instance.offlineVRRig;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 16 + 84;
			A_0 = num;
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x0002A0CC File Offset: 0x000282CC
		private static void DefineResourceLPStr(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 55;
			A_0 = num;
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x0002A114 File Offset: 0x00028314
		private static void HasPropertiesgetHex(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 179;
			A_0 = num;
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x0002A184 File Offset: 0x00028384
		public unsafe static void ResetChams()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 47;
			int num4 = 47;
			num4 = 47;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 5)
					{
						num4 = 47;
						if ((int)array[1] != 0)
						{
							num5 = (int)array[3];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num5 + 8 + num2);
								num7 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + (int)array[5] + 8 + num2) + 8 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num7 + 32 + num2);
								if (num8 != -1)
								{
									num9 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num8 + num2);
									array[5] = num8;
									array[0] = 0;
									num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num8 + num2);
									goto IL_1A;
								}
								num7 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num7 + 8 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[6];
							num9 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num5 + num2);
							ex3 = ex2;
							array = (object[])array[2];
							array2 = new object[8];
							array2[1] = 1;
							array2[2] = array;
							array2[6] = ex2;
							array2[5] = num5;
							array2[0] = 2;
							array = array2;
							num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num5 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[4];
							array = (object[])array[2];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 1)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 47;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num16 * 64 + 8 + num2);
						num18 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num16 * 64 + 16 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num7 * 64 + 40 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num15 * 64 + 8 + num2);
						num6 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num15 * 64 + 16 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num7 * 64 + 40 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num16 * 40 + 8 + num2);
						num18 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num16 * 40 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num7 * 40 + 24 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A34:
						if (array == null || (int)array[1] == 0)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num6 + 8 + num2);
								}
								else
								{
									num11 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + 32 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + 8 + num2);
									goto IL_A34;
								}
							}
							goto IL_BC2;
						}
						int num20 = (int)array[5];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num16 * 40 + 8 + num2);
								num11 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num16 * 40 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num5 * 40 + 24 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num7 + 8 + num2);
								}
								else
								{
									num5 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + 32 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + 8 + num2);
									goto IL_A34;
								}
							}
							break;
						}
						if ((int)array[5] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[2];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num5 + num2);
					array2 = new object[8];
					array2[1] = 0;
					array2[2] = array;
					array2[4] = num12;
					array2[5] = num5;
					array2[0] = 0;
					array = array2;
					num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num5 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_BC2:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num11 + num2);
					array2 = new object[8];
					array2[1] = 0;
					array2[2] = array;
					array2[4] = num12;
					array2[5] = num11;
					array2[0] = 0;
					array = array2;
					num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num11 + num2);
				}
				num4 = 47;
				return;
				IL_1BE:
				if (num15 != -1)
				{
					goto IL_1C9;
				}
				goto IL_3E4;
				IL_1C9:
				num6 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num15 + 16 + num2);
				if (1 == num6)
				{
					goto IL_1E8;
				}
				if (0 == num6)
				{
					goto IL_36B;
				}
				goto IL_3E4;
				IL_1E8:
				num11 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num15 + 40 + num2);
				if (num11 == -1)
				{
					goto IL_236;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_21C;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_21C:
				if (type.IsInstanceOfType(array2[6]))
				{
					goto IL_236;
				}
				num15 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num15 + 64 + num2);
				goto IL_1BE;
				IL_236:
				num19 = num15;
				num14 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + 8 + num2) + 8 + num2);
				num7 = (int)array2[7];
				IL_258:
				if (num7 != num14)
				{
					goto IL_2D1;
				}
				num16 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + num2);
				ex3 = array2[6];
				array = (object[])array[2];
				object[] array5 = new object[]
				{
					default(object),
					1,
					array,
					default(object),
					default(object),
					default(object),
					array2[6],
					(int)array2[7]
				};
				array5[5] = num19;
				array5[0] = 2;
				array = array5;
				num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + num2);
				goto IL_1A;
				IL_2D1:
				num9 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num7 + 32 + num2);
				if (num9 == -1)
				{
					goto IL_35A;
				}
				num16 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num9 + num2);
				array = (object[])array[2];
				array5 = new object[]
				{
					default(object),
					1,
					array,
					default(object),
					default(object),
					default(object),
					array2[6],
					(int)array2[7]
				};
				array5[5] = num9;
				array5[3] = num19;
				array5[0] = 0;
				array = array5;
				num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num9 + num2);
				goto IL_1A;
				IL_35A:
				num7 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num7 + 8 + num2);
				goto IL_258;
				IL_36B:
				num16 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num15 + 56 + num2);
				ex3 = array2[6];
				array = (object[])array[2];
				array5 = new object[]
				{
					default(object),
					1,
					array,
					default(object),
					default(object),
					default(object),
					array2[6],
					(int)array2[7]
				};
				array5[5] = num15;
				array5[0] = 1;
				array = array5;
				num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num15 + 56 + num2);
				goto IL_1A;
				IL_3E4:
				array = (object[])array[2];
				ex = array2[6];
				int num23 = (int)array2[7];
				IL_403:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_411:
				num8 = (num17 + num18) / 2;
				num5 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num8 * 64 + 8 + num2);
				num22 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num8 * 64 + 16 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_456;
				}
				if (num5 > num16)
				{
					goto IL_45E;
				}
				num14 = num8;
				num19 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 128 + num14 * 64 + 40 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_486;
				IL_456:
				num17 = num8 + 1;
				goto IL_411;
				IL_45E:
				num18 = num8 - 1;
				goto IL_411;
				IL_486:
				if (array != null)
				{
					goto IL_491;
				}
				goto IL_612;
				IL_491:
				if ((int)array[1] != 0)
				{
					goto IL_54A;
				}
				int num24 = (int)array[5];
				if (num11 != -1)
				{
					goto IL_4B5;
				}
				int num25 = -1;
				goto IL_531;
				IL_4B5:
				int num26 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num11 + num2);
				num22 = 0;
				num5 = 2;
				IL_4C5:
				num8 = (num22 + num5) / 2;
				num18 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num8 * 40 + 8 + num2);
				num17 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num8 * 40 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_507;
				}
				if (num18 > num26)
				{
					goto IL_50F;
				}
				num19 = num8;
				num14 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num19 * 40 + 24 + num2);
				num25 = num14;
				goto IL_531;
				IL_507:
				num22 = num8 + 1;
				goto IL_4C5;
				IL_50F:
				num5 = num8 - 1;
				goto IL_4C5;
				IL_531:
				if (num24 != num25)
				{
					goto IL_539;
				}
				goto IL_612;
				IL_539:
				array = (object[])array[2];
				goto IL_486;
				IL_54A:
				num9 = (int)array[0];
				if (num9 == 2 || num9 == 0)
				{
					goto IL_56B;
				}
				if (num9 != 1)
				{
					goto IL_56A;
				}
				array2 = array;
				num15 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + (int)array2[5] + 64 + num2);
				goto IL_1BE;
				IL_56A:
				IL_56B:
				int num27 = (int)array[5];
				if (num11 != -1)
				{
					goto IL_580;
				}
				int num28 = -1;
				goto IL_5FC;
				IL_580:
				num16 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num11 + num2);
				num17 = 0;
				num18 = 2;
				IL_590:
				num8 = (num17 + num18) / 2;
				num5 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num8 * 40 + 8 + num2);
				num22 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num8 * 40 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5D2;
				}
				if (num5 > num16)
				{
					goto IL_5DA;
				}
				num14 = num8;
				num19 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + 320 + num14 * 40 + 24 + num2);
				num28 = num19;
				goto IL_5FC;
				IL_5D2:
				num17 = num8 + 1;
				goto IL_590;
				IL_5DA:
				num18 = num8 - 1;
				goto IL_590;
				IL_5FC:
				if (num27 != num28)
				{
					goto IL_601;
				}
				goto IL_612;
				IL_601:
				array = (object[])array[2];
				goto IL_486;
				IL_612:
				if (-1 != num11)
				{
					goto IL_6AF;
				}
				num19 = num7;
				IL_61F:
				if (num19 != -1)
				{
					goto IL_62B;
				}
				num10 = 1;
				throw ex;
				IL_62B:
				num14 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + 32 + num2);
				if (num14 == -1)
				{
					goto IL_69E;
				}
				num26 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num14 + num2);
				array2 = new object[]
				{
					default(object),
					1,
					array,
					default(object),
					default(object),
					default(object),
					ex,
					num7
				};
				array2[5] = -1;
				array2[3] = -1;
				array2[0] = 2;
				array = array2;
				num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num14 + num2);
				goto IL_1A;
				IL_69E:
				num19 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num19 + 8 + num2);
				goto IL_61F;
				IL_6AF:
				num6 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num11 + 16 + num2);
				num16 = num6;
				IL_6C0:
				if (num16 != -1)
				{
					goto IL_6D6;
				}
				num11 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num11 + 8 + num2);
				goto IL_486;
				IL_6D6:
				num18 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num16 + 16 + num2);
				if (1 == num18)
				{
					goto IL_700;
				}
				if (0 == num18)
				{
					goto IL_85F;
				}
				num11 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num11 + 8 + num2);
				goto IL_486;
				IL_700:
				num17 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num16 + 40 + num2);
				if (num17 == -1)
				{
					goto IL_74F;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_734;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_734:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_74F;
				}
				num16 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num16 + 64 + num2);
				goto IL_6C0;
				IL_74F:
				num26 = num16;
				num22 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num26 + 8 + num2) + 8 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_776:
				if (num5 != num22)
				{
					goto IL_7D9;
				}
				int num29 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num26 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					1,
					array,
					default(object),
					default(object),
					default(object),
					ex,
					num7
				};
				array2[5] = num26;
				array2[0] = 2;
				array = array2;
				num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num26 + num2);
				goto IL_1A;
				IL_7D9:
				num8 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num5 + 32 + num2);
				if (num8 == -1)
				{
					goto IL_84E;
				}
				num29 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num8 + num2);
				array2 = new object[]
				{
					default(object),
					1,
					array,
					default(object),
					default(object),
					default(object),
					ex,
					num7
				};
				array2[5] = num8;
				array2[3] = num26;
				array2[0] = 0;
				array = array2;
				num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num8 + num2);
				goto IL_1A;
				IL_84E:
				num5 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num5 + 8 + num2);
				goto IL_776;
				IL_85F:
				num29 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num16 + 56 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					1,
					array,
					default(object),
					default(object),
					default(object),
					ex,
					num7
				};
				array2[5] = num16;
				array2[0] = 1;
				array = array2;
				num3 = *(ref opModulusLinkDemand.OnSerializedAttributeThreadStaticAttribute + num16 + 56 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_403;
				}
				throw ex4;
			}
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x0002AE04 File Offset: 0x00029004
		public Visual()
		{
			int num = 279;
			int num2 = 279;
			num2 = 279;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,StupidTemplate.Mods.Visual), ref num, ref num2, ref num3, this, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 279;
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x0002AE48 File Offset: 0x00029048
		private static void getFieldNamesIEnumUnknown(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 168;
			A_0 = num;
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x0002AEB8 File Offset: 0x000290B8
		private static void CLRInstanceIDSecurity(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 215;
			A_0 = num;
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x0002AF00 File Offset: 0x00029100
		private static void DecimalInitialLeaseTime(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_27.material.renderQueue = 3000;
			A_27.startColor = Color.green;
			A_27.endColor = Color.green;
			A_21.transform.position = A_5.transform.position;
			A_21.transform.LookAt(GorillaTagger.Instance.headCollider.transform);
			Object.Destroy(A_21, Time.deltaTime);
			A_0 = 74;
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x0002AFB8 File Offset: 0x000291B8
		private static void TripleDESCryptoServiceProviderListSeparator(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 0;
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x0002AFD0 File Offset: 0x000291D0
		private static void DeploymentMetadataDeploymentFlagsEntryPointEntryFieldId(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			bool flag = A_14 < Enumerable.Count<int>(Visual.bones);
			A_15 = flag;
			int num = (A_15 ? 1 : 0) * -2 + 93;
			A_0 = num;
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x0002B03C File Offset: 0x0002923C
		private static void GetLowerBoundRC(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 22;
			A_2 = 18;
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x0002B060 File Offset: 0x00029260
		private static void GetTypeFromHandleNestedType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 78;
			A_0 = num;
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x0002B0A8 File Offset: 0x000292A8
		public unsafe static void Capsule3D()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 196;
			int num4 = 196;
			num4 = 196;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 196;
						if ((int)array[0] != 0)
						{
							num5 = (int)array[3];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num5 + num2);
								num7 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + (int)array[6] + num2) + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num7 + 40 + num2);
								if (num8 != -1)
								{
									num9 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num8 + 80 + num2);
									array[6] = num8;
									array[7] = 0;
									num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num8 + 80 + num2);
									goto IL_23;
								}
								num7 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num7 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[2];
							num9 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num5 + 80 + num2);
							ex3 = ex2;
							array = (object[])array[5];
							array2 = new object[8];
							array2[0] = 1;
							array2[5] = array;
							array2[2] = ex2;
							array2[6] = num5;
							array2[7] = 1;
							array = array2;
							num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num5 + 80 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[4];
							array = (object[])array[5];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							GameObject gameObject;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,UnityEngine.GameObject&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref gameObject, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 196;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num16 * 72 + num2);
						num18 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num16 * 72 + 48 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num7 * 72 + 56 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num15 * 72 + num2);
						num6 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num15 * 72 + 48 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num7 * 72 + 56 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num16 * 80 + num2);
						num18 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num16 * 80 + 56 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num7 * 80 + 64 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A5B:
						if (array == null || (int)array[0] == 0)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num6 + num2);
								}
								else
								{
									num11 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + 40 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + num2);
									goto IL_A5B;
								}
							}
							goto IL_BED;
						}
						int num20 = (int)array[6];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + 24 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num16 * 80 + num2);
								num11 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num16 * 80 + 56 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num5 * 80 + 64 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num7 + num2);
								}
								else
								{
									num5 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + 40 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + num2);
									goto IL_A5B;
								}
							}
							break;
						}
						if ((int)array[6] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[5];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num5 + 80 + num2);
					array2 = new object[8];
					array2[0] = 0;
					array2[5] = array;
					array2[4] = num12;
					array2[6] = num5;
					array2[7] = 0;
					array = array2;
					num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num5 + 80 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_BED:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num11 + 80 + num2);
					array2 = new object[8];
					array2[0] = 0;
					array2[5] = array;
					array2[4] = num12;
					array2[6] = num11;
					array2[7] = 0;
					array = array2;
					num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num11 + 80 + num2);
				}
				num4 = 196;
				return;
				IL_1D6:
				if (num15 != -1)
				{
					goto IL_1E1;
				}
				goto IL_402;
				IL_1E1:
				num6 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num15 + 64 + num2);
				if (0 == num6)
				{
					goto IL_200;
				}
				if (3 == num6)
				{
					goto IL_389;
				}
				goto IL_402;
				IL_200:
				num11 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num15 + 72 + num2);
				if (num11 == -1)
				{
					goto IL_24E;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_234;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_234:
				if (type.IsInstanceOfType(array2[2]))
				{
					goto IL_24E;
				}
				num15 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num15 + 16 + num2);
				goto IL_1D6;
				IL_24E:
				num19 = num15;
				num14 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + num2) + num2);
				num7 = (int)array2[1];
				IL_26C:
				if (num7 != num14)
				{
					goto IL_2EB;
				}
				num16 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + 80 + num2);
				ex3 = array2[2];
				array = (object[])array[5];
				object[] array5 = new object[8];
				array5[0] = 1;
				array5[5] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[6] = num19;
				array5[7] = 1;
				array = array5;
				num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + 80 + num2);
				goto IL_23;
				IL_2EB:
				num9 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num7 + 40 + num2);
				if (num9 == -1)
				{
					goto IL_37A;
				}
				num16 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num9 + 80 + num2);
				array = (object[])array[5];
				array5 = new object[8];
				array5[0] = 1;
				array5[5] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[6] = num9;
				array5[3] = num19;
				array5[7] = 0;
				array = array5;
				num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num9 + 80 + num2);
				goto IL_23;
				IL_37A:
				num7 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num7 + num2);
				goto IL_26C;
				IL_389:
				num16 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num15 + 24 + num2);
				ex3 = array2[2];
				array = (object[])array[5];
				array5 = new object[8];
				array5[0] = 1;
				array5[5] = array;
				array5[2] = array2[2];
				array5[1] = (int)array2[1];
				array5[6] = num15;
				array5[7] = 2;
				array = array5;
				num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num15 + 24 + num2);
				goto IL_23;
				IL_402:
				array = (object[])array[5];
				ex = array2[2];
				int num23 = (int)array2[1];
				IL_421:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_42F:
				num8 = (num17 + num18) / 2;
				num5 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num8 * 72 + num2);
				num22 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num8 * 72 + 48 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_472;
				}
				if (num5 > num16)
				{
					goto IL_47A;
				}
				num14 = num8;
				num19 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 144 + num14 * 72 + 56 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4A2;
				IL_472:
				num17 = num8 + 1;
				goto IL_42F;
				IL_47A:
				num18 = num8 - 1;
				goto IL_42F;
				IL_4A2:
				if (array != null)
				{
					goto IL_4AD;
				}
				goto IL_636;
				IL_4AD:
				if ((int)array[0] != 0)
				{
					goto IL_56A;
				}
				int num24 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_4D1;
				}
				int num25 = -1;
				goto IL_551;
				IL_4D1:
				int num26 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num11 + 24 + num2);
				num22 = 0;
				num5 = 2;
				IL_4E4:
				num8 = (num22 + num5) / 2;
				num18 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num8 * 80 + num2);
				num17 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num8 * 80 + 56 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_527;
				}
				if (num18 > num26)
				{
					goto IL_52F;
				}
				num19 = num8;
				num14 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num19 * 80 + 64 + num2);
				num25 = num14;
				goto IL_551;
				IL_527:
				num22 = num8 + 1;
				goto IL_4E4;
				IL_52F:
				num5 = num8 - 1;
				goto IL_4E4;
				IL_551:
				if (num24 != num25)
				{
					goto IL_559;
				}
				goto IL_636;
				IL_559:
				array = (object[])array[5];
				goto IL_4A2;
				IL_56A:
				num9 = (int)array[7];
				if (num9 == 1 || num9 == 0)
				{
					goto IL_58B;
				}
				if (num9 != 2)
				{
					goto IL_58A;
				}
				array2 = array;
				num15 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + (int)array2[6] + 16 + num2);
				goto IL_1D6;
				IL_58A:
				IL_58B:
				int num27 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_5A0;
				}
				int num28 = -1;
				goto IL_620;
				IL_5A0:
				num16 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num11 + 24 + num2);
				num17 = 0;
				num18 = 2;
				IL_5B3:
				num8 = (num17 + num18) / 2;
				num5 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num8 * 80 + num2);
				num22 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num8 * 80 + 56 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5F6;
				}
				if (num5 > num16)
				{
					goto IL_5FE;
				}
				num14 = num8;
				num19 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + 360 + num14 * 80 + 64 + num2);
				num28 = num19;
				goto IL_620;
				IL_5F6:
				num17 = num8 + 1;
				goto IL_5B3;
				IL_5FE:
				num18 = num8 - 1;
				goto IL_5B3;
				IL_620:
				if (num27 != num28)
				{
					goto IL_625;
				}
				goto IL_636;
				IL_625:
				array = (object[])array[5];
				goto IL_4A2;
				IL_636:
				if (-1 != num11)
				{
					goto IL_6D7;
				}
				num19 = num7;
				IL_643:
				if (num19 != -1)
				{
					goto IL_64F;
				}
				num10 = 1;
				throw ex;
				IL_64F:
				num14 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + 40 + num2);
				if (num14 == -1)
				{
					goto IL_6C8;
				}
				num26 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num14 + 80 + num2);
				array2 = new object[8];
				array2[0] = 1;
				array2[5] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[6] = -1;
				array2[3] = -1;
				array2[7] = 1;
				array = array2;
				num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num14 + 80 + num2);
				goto IL_23;
				IL_6C8:
				num19 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num19 + num2);
				goto IL_643;
				IL_6D7:
				num6 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num11 + 32 + num2);
				num16 = num6;
				IL_6E8:
				if (num16 != -1)
				{
					goto IL_6FC;
				}
				num11 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num11 + num2);
				goto IL_4A2;
				IL_6FC:
				num18 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num16 + 64 + num2);
				if (0 == num18)
				{
					goto IL_724;
				}
				if (3 == num18)
				{
					goto IL_889;
				}
				num11 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num11 + num2);
				goto IL_4A2;
				IL_724:
				num17 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num16 + 72 + num2);
				if (num17 == -1)
				{
					goto IL_773;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_758;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_758:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_773;
				}
				num16 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num16 + 16 + num2);
				goto IL_6E8;
				IL_773:
				num26 = num16;
				num22 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num26 + num2) + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_796:
				if (num5 != num22)
				{
					goto IL_7FF;
				}
				int num29 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num26 + 80 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[0] = 1;
				array2[5] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[6] = num26;
				array2[7] = 1;
				array = array2;
				num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num26 + 80 + num2);
				goto IL_23;
				IL_7FF:
				num8 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num5 + 40 + num2);
				if (num8 == -1)
				{
					goto IL_87A;
				}
				num29 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num8 + 80 + num2);
				array2 = new object[8];
				array2[0] = 1;
				array2[5] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[6] = num8;
				array2[3] = num26;
				array2[7] = 0;
				array = array2;
				num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num8 + 80 + num2);
				goto IL_23;
				IL_87A:
				num5 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num5 + num2);
				goto IL_796;
				IL_889:
				num29 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num16 + 24 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[0] = 1;
				array2[5] = array;
				array2[2] = ex;
				array2[1] = num7;
				array2[6] = num16;
				array2[7] = 2;
				array = array2;
				num3 = *(ref OnlyOnRanToCompletionScopeAction.IsNestedAssemblyAddOpcode + num16 + 24 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_421;
				}
				throw ex4;
			}
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x0002BD58 File Offset: 0x00029F58
		private static void CMSASSEMBLYDEPLOYMENTFLAGINSTALLmowned(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_0 = 54;
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x0002BD70 File Offset: 0x00029F70
		private static void SingleProducerSingleConsumerQueueDefaultEncoder(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 16;
			A_0 = num;
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x0002BDB8 File Offset: 0x00029FB8
		private static void removeModuleResolveEditAndContinueHelper(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 130;
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x0002BDF4 File Offset: 0x00029FF4
		private static void ConvOvfUTimeSpanParse(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_15.material = new Material(A_17);
			A_15.material.renderQueue = 3000;
			float num = 0f;
			A_19 = num;
			num = A_19 + Time.deltaTime;
			A_19 = num;
			A_15.startColor = Main.outlineColor;
			A_15.endColor = Main.outlineColor;
			A_8.transform.position = A_5.transform.position;
			A_8.transform.LookAt(Camera.main.transform.position);
			A_15.transform.LookAt(Camera.main.transform.position);
			Object.Destroy(A_8, Time.deltaTime);
			A_0 = 75;
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x0002BF30 File Offset: 0x0002A130
		private static void RegistryViewSetTraits(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			GameObject gameObject = new GameObject("Line");
			A_7 = gameObject;
			A_7.transform.localScale = new Vector3(0.001f, 0.001f, 0.001f);
			LineRenderer lineRenderer = A_7.AddComponent<LineRenderer>();
			A_8 = lineRenderer;
			A_8.SetPosition(0, GorillaTagger.Instance.offlineVRRig.bodyTransform.position - new Vector3(0f, 1f, 0f));
			A_8.SetPosition(1, A_5.transform.position);
			A_8.startWidth = 0.001f;
			A_8.endWidth = 0.001f;
			A_8.material.shader = Shader.Find("GUI/Text Shader");
			float num = 0f;
			A_9 = num;
			num = A_9 + Time.deltaTime;
			A_9 = num;
			A_8.material.color = Color.white;
			Object.Destroy(A_7, Time.deltaTime);
			int num2 = (A_4.MoveNext() ? 1 : 0) * -6 + 257;
			A_0 = num2;
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x0002C0EC File Offset: 0x0002A2EC
		private static void getCompletedSynchronouslygetActor(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			A_1 = 3;
			A_2 = 270;
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x0002C110 File Offset: 0x0002A310
		private static void ContextAttributeEntryMemberRef(ref int A_0, ref int A_1, ref int A_2, ref Renderer[] A_3, ref int A_4, ref Renderer A_5)
		{
			int num = ((A_4 < A_3.Length) ? 1 : 0) * -2 + 274;
			A_0 = num;
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x0002C14C File Offset: 0x0002A34C
		private static void getEndOfStreamgetCurrencyNegativePattern(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref int A_4, ref Transform A_5, ref GameObject A_6, ref float A_7, ref bool A_8)
		{
			Transform child = A_3.transform.GetChild(A_4);
			A_5 = child;
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_6 = gameObject;
			A_6.transform.position = A_5.position;
			A_6.transform.localScale = A_5.localScale;
			A_6.transform.rotation = A_5.rotation;
			float num = (float)Time.frameCount / 180f % 1f;
			A_7 = num;
			A_6.GetComponent<Renderer>().material.color = Color.red;
			A_6.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			Object.Destroy(A_6, Time.deltaTime);
			int num2 = A_4 + 1;
			A_4 = num2;
			bool flag = A_4 < A_3.transform.childCount;
			A_8 = flag;
			int num3 = (A_8 ? 1 : 0) * -2 + 278;
			A_0 = num3;
		}

		// Token: 0x060004FE RID: 1278 RVA: 0x0002C308 File Offset: 0x0002A508
		private static void BinaryContractReferenceAssemblyAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 186;
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x0002C344 File Offset: 0x0002A544
		private static void StartupCachePath(ref int A_0, ref int A_1, ref int A_2)
		{
			QualitySettings.SetQualityLevel(1);
			A_1 = 0;
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x0002C368 File Offset: 0x0002A568
		private static void CaptureOffsetgetUseNetCoreTimer(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("fected");
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 1 + 240;
			A_0 = num;
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x0002C3E8 File Offset: 0x0002A5E8
		private static void ToLongTimeStringDebugMessage(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			bool flag = A_13 < Enumerable.Count<int>(Visual.bones);
			A_14 = flag;
			int num = (A_14 ? 1 : 0) * -2 + 118;
			A_0 = num;
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x0002C454 File Offset: 0x0002A654
		private static void IsStringReturnValue(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 171;
			A_0 = num;
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x0002C49C File Offset: 0x0002A69C
		private static void RoundtripKindPercentNegativePattern(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			GameObject gameObject = new GameObject();
			A_21 = gameObject;
			LineRenderer lineRenderer = A_21.AddComponent<LineRenderer>();
			A_22 = lineRenderer;
			Vector3 position = A_5.transform.position;
			A_23 = position;
			Vector3[] array = new Vector3[5];
			A_24 = array;
			float num = 0.5f;
			A_25 = num;
			float num2 = 0.5f;
			A_26 = num2;
			LineRenderer lineRenderer2 = new GameObject().AddComponent<LineRenderer>();
			A_27 = lineRenderer2;
			A_27.transform.parent = A_21.transform;
			Vector3[] array2 = new Vector3[5];
			A_28 = array2;
			A_28[0] = A_23 + A_5.transform.right * (-A_26 / 2f - 0.02f) + A_5.transform.up * (A_25 / 2f + 0.02f);
			A_28[1] = A_23 + A_5.transform.right * (A_26 / 2f + 0.02f) + A_5.transform.up * (A_25 / 2f + 0.02f);
			A_28[2] = A_23 + A_5.transform.right * (A_26 / 2f + 0.02f) + A_5.transform.up * (-A_25 / 2f - 0.02f);
			A_28[3] = A_23 + A_5.transform.right * (-A_26 / 2f - 0.02f) + A_5.transform.up * (-A_25 / 2f - 0.02f);
			A_28[4] = A_28[0];
			A_27.positionCount = A_28.Length;
			A_27.SetPositions(A_28);
			A_27.startWidth = 0.015f;
			A_27.endWidth = 0.015f;
			Shader shader = Shader.Find("GUI/Text Shader");
			A_29 = shader;
			bool flag = A_29 != null;
			A_30 = flag;
			int num3 = ((!A_30) ? 1 : 0) * 1 + 69;
			A_0 = num3;
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x0002C89C File Offset: 0x0002AA9C
		private static void SingleCallQuickCacheEntryType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			Object.Destroy(A_5.GetComponent<TrailRenderer>());
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 171;
			A_0 = num;
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x0002C8F8 File Offset: 0x0002AAF8
		public unsafe static void Sphere()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 207;
			int num4 = 207;
			num4 = 207;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 3)
					{
						num4 = 207;
						if ((int)array[7] != 1)
						{
							num5 = (int)array[4];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num5 + 56 + num2);
								num7 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + (int)array[2] + 56 + num2) + 80 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num7 + 24 + num2);
								if (num8 != -1)
								{
									num9 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num8 + 8 + num2);
									array[2] = num8;
									array[1] = 2;
									num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num8 + 8 + num2);
									goto IL_23;
								}
								num7 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num7 + 80 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[3];
							num9 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num5 + 8 + num2);
							ex3 = ex2;
							array = (object[])array[0];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								0
							};
							array2[0] = array;
							array2[3] = ex2;
							array2[2] = num5;
							array2[1] = 1;
							array = array2;
							num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num5 + 8 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[6];
							array = (object[])array[0];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 5)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							GameObject gameObject;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,UnityEngine.GameObject&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref gameObject, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 207;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num16 * 48 + 40 + num2);
						num18 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num16 * 48 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num7 * 48 + 16 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num15 * 48 + 40 + num2);
						num6 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num15 * 48 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num7 * 48 + 16 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num16 * 40 + 32 + num2);
						num18 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num16 * 40 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num7 * 40 + 8 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A66:
						if (array == null || (int)array[7] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num6 + 80 + num2);
								}
								else
								{
									num11 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 24 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 80 + num2);
									goto IL_A66;
								}
							}
							goto IL_BFD;
						}
						int num20 = (int)array[2];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 8 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num16 * 40 + 32 + num2);
								num11 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num16 * 40 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num5 * 40 + 8 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num7 + 80 + num2);
								}
								else
								{
									num5 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 24 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 80 + num2);
									goto IL_A66;
								}
							}
							break;
						}
						if ((int)array[2] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[0];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num5 + 8 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						1
					};
					array2[0] = array;
					array2[6] = num12;
					array2[2] = num5;
					array2[1] = 2;
					array = array2;
					num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num5 + 8 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_BFD:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num11 + 8 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						1
					};
					array2[0] = array;
					array2[6] = num12;
					array2[2] = num11;
					array2[1] = 2;
					array = array2;
					num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num11 + 8 + num2);
				}
				num4 = 207;
				return;
				IL_1DE:
				if (num15 != -1)
				{
					goto IL_1E9;
				}
				goto IL_40C;
				IL_1E9:
				num6 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num15 + num2);
				if (4 == num6)
				{
					goto IL_205;
				}
				if (0 == num6)
				{
					goto IL_393;
				}
				goto IL_40C;
				IL_205:
				num11 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num15 + 16 + num2);
				if (num11 == -1)
				{
					goto IL_253;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_239;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_239:
				if (type.IsInstanceOfType(array2[3]))
				{
					goto IL_253;
				}
				num15 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num15 + 40 + num2);
				goto IL_1DE;
				IL_253:
				num19 = num15;
				num14 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 56 + num2) + 80 + num2);
				num7 = (int)array2[5];
				IL_277:
				if (num7 != num14)
				{
					goto IL_2F4;
				}
				num16 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 8 + num2);
				ex3 = array2[3];
				array = (object[])array[0];
				object[] array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[0] = array;
				array5[3] = array2[3];
				array5[5] = (int)array2[5];
				array5[2] = num19;
				array5[1] = 1;
				array = array5;
				num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 8 + num2);
				goto IL_23;
				IL_2F4:
				num9 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num7 + 24 + num2);
				if (num9 == -1)
				{
					goto IL_381;
				}
				num16 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num9 + 8 + num2);
				array = (object[])array[0];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[0] = array;
				array5[3] = array2[3];
				array5[5] = (int)array2[5];
				array5[2] = num9;
				array5[4] = num19;
				array5[1] = 2;
				array = array5;
				num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num9 + 8 + num2);
				goto IL_23;
				IL_381:
				num7 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num7 + 80 + num2);
				goto IL_277;
				IL_393:
				num16 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num15 + 24 + num2);
				ex3 = array2[3];
				array = (object[])array[0];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[0] = array;
				array5[3] = array2[3];
				array5[5] = (int)array2[5];
				array5[2] = num15;
				array5[1] = 0;
				array = array5;
				num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num15 + 24 + num2);
				goto IL_23;
				IL_40C:
				array = (object[])array[0];
				ex = array2[3];
				int num23 = (int)array2[5];
				IL_42B:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_439:
				num8 = (num17 + num18) / 2;
				num5 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num8 * 48 + 40 + num2);
				num22 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num8 * 48 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_47C;
				}
				if (num5 > num16)
				{
					goto IL_484;
				}
				num14 = num8;
				num19 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 152 + num14 * 48 + 16 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4AC;
				IL_47C:
				num17 = num8 + 1;
				goto IL_439;
				IL_484:
				num18 = num8 - 1;
				goto IL_439;
				IL_4AC:
				if (array != null)
				{
					goto IL_4B7;
				}
				goto IL_63C;
				IL_4B7:
				if ((int)array[7] != 1)
				{
					goto IL_572;
				}
				int num24 = (int)array[2];
				if (num11 != -1)
				{
					goto IL_4DB;
				}
				int num25 = -1;
				goto IL_559;
				IL_4DB:
				int num26 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num11 + 8 + num2);
				num22 = 0;
				num5 = 2;
				IL_4ED:
				num8 = (num22 + num5) / 2;
				num18 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num8 * 40 + 32 + num2);
				num17 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num8 * 40 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_530;
				}
				if (num18 > num26)
				{
					goto IL_538;
				}
				num19 = num8;
				num14 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num19 * 40 + 8 + num2);
				num25 = num14;
				goto IL_559;
				IL_530:
				num22 = num8 + 1;
				goto IL_4ED;
				IL_538:
				num5 = num8 - 1;
				goto IL_4ED;
				IL_559:
				if (num24 != num25)
				{
					goto IL_561;
				}
				goto IL_63C;
				IL_561:
				array = (object[])array[0];
				goto IL_4AC;
				IL_572:
				num9 = (int)array[1];
				if (num9 == 1 || num9 == 2)
				{
					goto IL_593;
				}
				if (num9 != 0)
				{
					goto IL_592;
				}
				array2 = array;
				num15 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + (int)array2[2] + 40 + num2);
				goto IL_1DE;
				IL_592:
				IL_593:
				int num27 = (int)array[2];
				if (num11 != -1)
				{
					goto IL_5A8;
				}
				int num28 = -1;
				goto IL_626;
				IL_5A8:
				num16 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num11 + 8 + num2);
				num17 = 0;
				num18 = 2;
				IL_5BA:
				num8 = (num17 + num18) / 2;
				num5 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num8 * 40 + 32 + num2);
				num22 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num8 * 40 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_5FD;
				}
				if (num5 > num16)
				{
					goto IL_605;
				}
				num14 = num8;
				num19 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + 296 + num14 * 40 + 8 + num2);
				num28 = num19;
				goto IL_626;
				IL_5FD:
				num17 = num8 + 1;
				goto IL_5BA;
				IL_605:
				num18 = num8 - 1;
				goto IL_5BA;
				IL_626:
				if (num27 != num28)
				{
					goto IL_62B;
				}
				goto IL_63C;
				IL_62B:
				array = (object[])array[0];
				goto IL_4AC;
				IL_63C:
				if (-1 != num11)
				{
					goto IL_6DE;
				}
				num19 = num7;
				IL_649:
				if (num19 != -1)
				{
					goto IL_655;
				}
				num10 = 1;
				throw ex;
				IL_655:
				num14 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 24 + num2);
				if (num14 == -1)
				{
					goto IL_6CC;
				}
				num26 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num14 + 8 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[0] = array;
				array2[3] = ex;
				array2[5] = num7;
				array2[2] = -1;
				array2[4] = -1;
				array2[1] = 1;
				array = array2;
				num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num14 + 8 + num2);
				goto IL_23;
				IL_6CC:
				num19 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num19 + 80 + num2);
				goto IL_649;
				IL_6DE:
				num6 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num11 + num2);
				num16 = num6;
				IL_6EC:
				if (num16 != -1)
				{
					goto IL_703;
				}
				num11 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num11 + 80 + num2);
				goto IL_4AC;
				IL_703:
				num18 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num16 + num2);
				if (4 == num18)
				{
					goto IL_72B;
				}
				if (0 == num18)
				{
					goto IL_895;
				}
				num11 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num11 + 80 + num2);
				goto IL_4AC;
				IL_72B:
				num17 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num16 + 16 + num2);
				if (num17 == -1)
				{
					goto IL_77A;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_75F;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_75F:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_77A;
				}
				num16 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num16 + 40 + num2);
				goto IL_6EC;
				IL_77A:
				num26 = num16;
				num22 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num26 + 56 + num2) + 80 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7A3:
				if (num5 != num22)
				{
					goto IL_80A;
				}
				int num29 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num26 + 8 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[0] = array;
				array2[3] = ex;
				array2[5] = num7;
				array2[2] = num26;
				array2[1] = 1;
				array = array2;
				num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num26 + 8 + num2);
				goto IL_23;
				IL_80A:
				num8 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num5 + 24 + num2);
				if (num8 == -1)
				{
					goto IL_883;
				}
				num29 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num8 + 8 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[0] = array;
				array2[3] = ex;
				array2[5] = num7;
				array2[2] = num8;
				array2[4] = num26;
				array2[1] = 2;
				array = array2;
				num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num8 + 8 + num2);
				goto IL_23;
				IL_883:
				num5 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num5 + 80 + num2);
				goto IL_7A3;
				IL_895:
				num29 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num16 + 24 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[0] = array;
				array2[3] = ex;
				array2[5] = num7;
				array2[2] = num16;
				array2[1] = 0;
				array = array2;
				num3 = *(ref UnicodeSymbolToken.EncoderExceptionFallbackgetIsGlobalTypeDefToken + num16 + 24 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_42B;
				}
				throw ex4;
			}
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x0002D5B8 File Offset: 0x0002B7B8
		private static void UTFsetCurrencyDecimalDigits(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 235;
			A_0 = num;
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x0002D620 File Offset: 0x0002B820
		private static void CMSUSAGEPATTERNSCOPEPROCESSIsLastFrameFromForeignExceptionStackTrace(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 171;
			A_0 = num;
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x0002D668 File Offset: 0x0002B868
		private static void getSkipVerificationTypeUnion(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_4.Dispose();
			A_1 = 3;
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x0002D690 File Offset: 0x0002B890
		private static void ArgumentOutOfRangeListInsertCrSel(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_37.material = new Material(A_39);
			A_37.material.renderQueue = 3000;
			A_37.startColor = Color.red;
			A_37.endColor = Color.red;
			A_31.transform.position = A_5.transform.position;
			A_31.transform.LookAt(GorillaTagger.Instance.headCollider.transform);
			Object.Destroy(A_31, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 78;
			A_0 = num;
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x0002D798 File Offset: 0x0002B998
		private static void SequentialSaturday(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 44;
			A_0 = num;
		}

		// Token: 0x0600050B RID: 1291 RVA: 0x0002D7E0 File Offset: 0x0002B9E0
		public unsafe static void BoxESP()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 58;
			int num4 = 58;
			num4 = 58;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num22;
				int num23;
				int num24;
				int num25;
				int num26;
				int num27;
				int num30;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 5)
					{
						num4 = 58;
						if ((int)array[4] != 1)
						{
							num5 = (int)array[1];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num5 + 56 + num2);
								num7 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + (int)array[5] + 56 + num2) + 40 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num7 + 48 + num2);
								if (num8 != -1)
								{
									num9 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num8 + 40 + num2);
									array[5] = num8;
									array[2] = 1;
									num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num8 + 40 + num2);
									goto IL_1A;
								}
								num7 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num7 + 40 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[6];
							num9 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num5 + 40 + num2);
							ex3 = ex2;
							array = (object[])array[7];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								default(object),
								0,
								default(object),
								default(object),
								array
							};
							array2[6] = ex2;
							array2[5] = num5;
							array2[2] = 0;
							array = array2;
							num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num5 + 40 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[0];
							array = (object[])array[7];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 2)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							GameObject gameObject;
							LineRenderer lineRenderer;
							Vector3 vector;
							float num14;
							Vector3[] array3;
							float num15;
							float num16;
							LineRenderer lineRenderer2;
							Vector3[] array4;
							Shader shader;
							bool flag3;
							float num17;
							bool flag4;
							GameObject gameObject2;
							LineRenderer lineRenderer3;
							Vector3 vector2;
							Vector3[] array5;
							float num18;
							float num19;
							LineRenderer lineRenderer4;
							Vector3[] array6;
							Shader shader2;
							bool flag5;
							GameObject gameObject3;
							LineRenderer lineRenderer5;
							Vector3 vector3;
							Vector3[] array7;
							float num20;
							float num21;
							LineRenderer lineRenderer6;
							Vector3[] array8;
							Shader shader3;
							bool flag6;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,UnityEngine.Vector3&,System.Single&,UnityEngine.Vector3[]&,System.Single&,System.Single&,UnityEngine.LineRenderer&,UnityEngine.Vector3[]&,UnityEngine.Shader&,System.Boolean&,System.Single&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,UnityEngine.Vector3&,UnityEngine.Vector3[]&,System.Single&,System.Single&,UnityEngine.LineRenderer&,UnityEngine.Vector3[]&,UnityEngine.Shader&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,UnityEngine.Vector3&,UnityEngine.Vector3[]&,System.Single&,System.Single&,UnityEngine.LineRenderer&,UnityEngine.Vector3[]&,UnityEngine.Shader&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref gameObject, ref lineRenderer, ref vector, ref num14, ref array3, ref num15, ref num16, ref lineRenderer2, ref array4, ref shader, ref flag3, ref num17, ref flag4, ref gameObject2, ref lineRenderer3, ref vector2, ref array5, ref num18, ref num19, ref lineRenderer4, ref array6, ref shader2, ref flag5, ref gameObject3, ref lineRenderer5, ref vector3, ref array7, ref num20, ref num21, ref lineRenderer6, ref array8, ref shader3, ref flag6, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 58;
						num8 = num13;
						num12 = num8;
					}
					num22 = num3;
					num6 = num22;
					num11 = 0;
					num23 = 2;
					for (;;)
					{
						num24 = (num11 + num23) / 2;
						num25 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num24 * 72 + 40 + num2);
						num26 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num24 * 72 + 64 + num2);
						if (num6 < num25 + num26)
						{
							if (num25 <= num6)
							{
								break;
							}
							num23 = num24 - 1;
						}
						else
						{
							num11 = num24 + 1;
						}
					}
					num7 = num24;
					num9 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num7 * 72 + 48 + num2);
					num27 = num9;
					num26 = num12;
					num25 = 0;
					num24 = 2;
					for (;;)
					{
						num23 = (num25 + num24) / 2;
						num11 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num23 * 72 + 40 + num2);
						num6 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num23 * 72 + 64 + num2);
						if (num26 < num11 + num6)
						{
							if (num11 <= num26)
							{
								break;
							}
							num24 = num23 - 1;
						}
						else
						{
							num25 = num23 + 1;
						}
					}
					num7 = num23;
					num8 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num7 * 72 + 48 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num23 = 2;
					for (;;)
					{
						num24 = (num11 + num23) / 2;
						num25 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num24 * 64 + 32 + num2);
						num26 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num24 * 64 + 56 + num2);
						if (num6 < num25 + num26)
						{
							if (num25 <= num6)
							{
								break;
							}
							num23 = num24 - 1;
						}
						else
						{
							num11 = num24 + 1;
						}
					}
					num7 = num24;
					num5 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num7 * 64 + 40 + num2);
					num8 = num5;
					for (;;)
					{
						IL_AC4:
						if (array == null || (int)array[4] == 1)
						{
							num6 = num9;
							while (num6 != num27)
							{
								if (num6 != -1)
								{
									num6 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num6 + 40 + num2);
								}
								else
								{
									num11 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 48 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num27 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 40 + num2);
									goto IL_AC4;
								}
							}
							goto IL_C62;
						}
						int num28 = (int)array[5];
						int num29;
						if (num27 == -1)
						{
							num29 = -1;
						}
						else
						{
							num30 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 24 + num2);
							num26 = 0;
							num25 = 2;
							for (;;)
							{
								num24 = (num26 + num25) / 2;
								num23 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num24 * 64 + 32 + num2);
								num11 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num24 * 64 + 56 + num2);
								if (num30 < num23 + num11)
								{
									if (num23 <= num30)
									{
										break;
									}
									num25 = num24 - 1;
								}
								else
								{
									num26 = num24 + 1;
								}
							}
							num5 = num24;
							num7 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num5 * 64 + 40 + num2);
							num29 = num7;
						}
						if (num28 == num29)
						{
							num7 = num9;
							while (num7 != num27)
							{
								if (num7 != -1)
								{
									num7 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num7 + 40 + num2);
								}
								else
								{
									num5 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 48 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num27 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 40 + num2);
									goto IL_AC4;
								}
							}
							break;
						}
						if ((int)array[5] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[7];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num5 + 40 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						1,
						default(object),
						default(object),
						array
					};
					array2[0] = num12;
					array2[5] = num5;
					array2[2] = 1;
					array = array2;
					num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num5 + 40 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C62:
					num3 = num12;
					continue;
					Block_62:
					num23 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num11 + 40 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						1,
						default(object),
						default(object),
						array
					};
					array2[0] = num12;
					array2[5] = num11;
					array2[2] = 1;
					array = array2;
					num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num11 + 40 + num2);
				}
				num4 = 58;
				return;
				IL_212:
				if (num23 != -1)
				{
					goto IL_21D;
				}
				goto IL_447;
				IL_21D:
				num6 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num23 + 88 + num2);
				if (2 == num6)
				{
					goto IL_23C;
				}
				if (4 == num6)
				{
					goto IL_3CE;
				}
				goto IL_447;
				IL_23C:
				num11 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num23 + 72 + num2);
				if (num11 == -1)
				{
					goto IL_28A;
				}
				Type[] array9;
				Type type;
				if ((type = array9[num11]) != null)
				{
					goto IL_270;
				}
				RuntimeTypeHandle[] array10;
				array9[num11] = Type.GetTypeFromHandle(array10[num11]);
				type = array9[num11];
				IL_270:
				if (type.IsInstanceOfType(array2[6]))
				{
					goto IL_28A;
				}
				num23 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num23 + 96 + num2);
				goto IL_212;
				IL_28A:
				num27 = num23;
				num22 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 56 + num2) + 40 + num2);
				num7 = (int)array2[3];
				IL_2AE:
				if (num7 != num22)
				{
					goto IL_32D;
				}
				num24 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 40 + num2);
				ex3 = array2[6];
				array = (object[])array[7];
				object[] array11 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array11[6] = array2[6];
				array11[3] = (int)array2[3];
				array11[5] = num27;
				array11[2] = 0;
				array = array11;
				num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 40 + num2);
				goto IL_1A;
				IL_32D:
				num9 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num7 + 48 + num2);
				if (num9 == -1)
				{
					goto IL_3BC;
				}
				num24 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num9 + 40 + num2);
				array = (object[])array[7];
				array11 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array11[6] = array2[6];
				array11[3] = (int)array2[3];
				array11[5] = num9;
				array11[1] = num27;
				array11[2] = 1;
				array = array11;
				num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num9 + 40 + num2);
				goto IL_1A;
				IL_3BC:
				num7 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num7 + 40 + num2);
				goto IL_2AE;
				IL_3CE:
				num24 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num23 + 80 + num2);
				ex3 = array2[6];
				array = (object[])array[7];
				array11 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array11[6] = array2[6];
				array11[3] = (int)array2[3];
				array11[5] = num23;
				array11[2] = 2;
				array = array11;
				num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num23 + 80 + num2);
				goto IL_1A;
				IL_447:
				array = (object[])array[7];
				ex = array2[6];
				int num31 = (int)array2[3];
				IL_466:
				num23 = num3;
				num24 = num23;
				num25 = 0;
				num26 = 2;
				IL_474:
				num8 = (num25 + num26) / 2;
				num5 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num8 * 72 + 40 + num2);
				num30 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num8 * 72 + 64 + num2);
				if (num24 >= num5 + num30)
				{
					goto IL_4BA;
				}
				if (num5 > num24)
				{
					goto IL_4C2;
				}
				num22 = num8;
				num27 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 176 + num22 * 72 + 48 + num2);
				num11 = num27;
				num7 = num11;
				goto IL_4EA;
				IL_4BA:
				num25 = num8 + 1;
				goto IL_474;
				IL_4C2:
				num26 = num8 - 1;
				goto IL_474;
				IL_4EA:
				if (array != null)
				{
					goto IL_4F5;
				}
				goto IL_684;
				IL_4F5:
				if ((int)array[4] != 1)
				{
					goto IL_5B5;
				}
				int num32 = (int)array[5];
				if (num11 != -1)
				{
					goto IL_519;
				}
				int num33 = -1;
				goto IL_59C;
				IL_519:
				int num34 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num11 + 24 + num2);
				num30 = 0;
				num5 = 2;
				IL_52C:
				num8 = (num30 + num5) / 2;
				num26 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num8 * 64 + 32 + num2);
				num25 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num8 * 64 + 56 + num2);
				if (num34 >= num26 + num25)
				{
					goto IL_572;
				}
				if (num26 > num34)
				{
					goto IL_57A;
				}
				num27 = num8;
				num22 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num27 * 64 + 40 + num2);
				num33 = num22;
				goto IL_59C;
				IL_572:
				num30 = num8 + 1;
				goto IL_52C;
				IL_57A:
				num5 = num8 - 1;
				goto IL_52C;
				IL_59C:
				if (num32 != num33)
				{
					goto IL_5A4;
				}
				goto IL_684;
				IL_5A4:
				array = (object[])array[7];
				goto IL_4EA;
				IL_5B5:
				num9 = (int)array[2];
				if (num9 == 0 || num9 == 1)
				{
					goto IL_5D6;
				}
				if (num9 != 2)
				{
					goto IL_5D5;
				}
				array2 = array;
				num23 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + (int)array2[5] + 96 + num2);
				goto IL_212;
				IL_5D5:
				IL_5D6:
				int num35 = (int)array[5];
				if (num11 != -1)
				{
					goto IL_5EB;
				}
				int num36 = -1;
				goto IL_66E;
				IL_5EB:
				num24 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num11 + 24 + num2);
				num25 = 0;
				num26 = 2;
				IL_5FE:
				num8 = (num25 + num26) / 2;
				num5 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num8 * 64 + 32 + num2);
				num30 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num8 * 64 + 56 + num2);
				if (num24 >= num5 + num30)
				{
					goto IL_644;
				}
				if (num5 > num24)
				{
					goto IL_64C;
				}
				num22 = num8;
				num27 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + 392 + num22 * 64 + 40 + num2);
				num36 = num27;
				goto IL_66E;
				IL_644:
				num25 = num8 + 1;
				goto IL_5FE;
				IL_64C:
				num26 = num8 - 1;
				goto IL_5FE;
				IL_66E:
				if (num35 != num36)
				{
					goto IL_673;
				}
				goto IL_684;
				IL_673:
				array = (object[])array[7];
				goto IL_4EA;
				IL_684:
				if (-1 != num11)
				{
					goto IL_728;
				}
				num27 = num7;
				IL_691:
				if (num27 != -1)
				{
					goto IL_69D;
				}
				num10 = 1;
				throw ex;
				IL_69D:
				num22 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 48 + num2);
				if (num22 == -1)
				{
					goto IL_716;
				}
				num34 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num22 + 40 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[6] = ex;
				array2[3] = num7;
				array2[5] = -1;
				array2[1] = -1;
				array2[2] = 0;
				array = array2;
				num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num22 + 40 + num2);
				goto IL_1A;
				IL_716:
				num27 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num27 + 40 + num2);
				goto IL_691;
				IL_728:
				num6 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num11 + 64 + num2);
				num24 = num6;
				IL_739:
				if (num24 != -1)
				{
					goto IL_750;
				}
				num11 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num11 + 40 + num2);
				goto IL_4EA;
				IL_750:
				num26 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num24 + 88 + num2);
				if (2 == num26)
				{
					goto IL_77B;
				}
				if (4 == num26)
				{
					goto IL_8E9;
				}
				num11 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num11 + 40 + num2);
				goto IL_4EA;
				IL_77B:
				num25 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num24 + 72 + num2);
				if (num25 == -1)
				{
					goto IL_7CA;
				}
				Type type2;
				if ((type2 = array9[num25]) != null)
				{
					goto IL_7AF;
				}
				array9[num25] = Type.GetTypeFromHandle(array10[num25]);
				type2 = array9[num25];
				IL_7AF:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_7CA;
				}
				num24 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num24 + 96 + num2);
				goto IL_739;
				IL_7CA:
				num34 = num24;
				num30 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num34 + 56 + num2) + 40 + num2);
				num5 = (num7 - num31) * ((num31 == -1) ? 1 : 0) + num31;
				IL_7F3:
				if (num5 != num30)
				{
					goto IL_85C;
				}
				int num37 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num34 + 40 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[6] = ex;
				array2[3] = num7;
				array2[5] = num34;
				array2[2] = 0;
				array = array2;
				num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num34 + 40 + num2);
				goto IL_1A;
				IL_85C:
				num8 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num5 + 48 + num2);
				if (num8 == -1)
				{
					goto IL_8D7;
				}
				num37 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num8 + 40 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[6] = ex;
				array2[3] = num7;
				array2[5] = num8;
				array2[1] = num34;
				array2[2] = 1;
				array = array2;
				num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num8 + 40 + num2);
				goto IL_1A;
				IL_8D7:
				num5 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num5 + 40 + num2);
				goto IL_7F3;
				IL_8E9:
				num37 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num24 + 80 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[6] = ex;
				array2[3] = num7;
				array2[5] = num24;
				array2[2] = 2;
				array = array2;
				num3 = *(ref MVIDArgumentOutOfRangeNeedNonNegNum.TupleElementNamesAttributeLogMessage + num24 + 80 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num31 = -1;
					goto IL_466;
				}
				throw ex4;
			}
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x0002E508 File Offset: 0x0002C708
		private static void CovariantPOLICYSETAUDITREQUIREMENTS(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_5]].gameObject);
			A_4 = orAddComponent;
			A_4.startWidth = 0.015f;
			A_4.endWidth = 0.015f;
			float num = 0f;
			A_6 = num;
			num = A_6 + Time.deltaTime;
			A_6 = num;
			A_4.startColor = Main.outlineColor;
			A_4.endColor = Main.outlineColor;
			A_4.material.shader = Shader.Find("GUI/Text Shader");
			A_4.SetPosition(0, GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_5]].position);
			A_4.SetPosition(1, GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_5 + 1]].position);
			Object.Destroy(A_4, Time.deltaTime);
			int num2 = A_5 + 2;
			A_5 = num2;
			bool flag = A_5 < Enumerable.Count<int>(Visual.bones);
			A_7 = flag;
			int num3 = (A_7 ? 1 : 0) * -2 + 109;
			A_0 = num3;
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x0002E718 File Offset: 0x0002C918
		private static void IConnectionPointContainerAppendFormat(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 33;
			A_0 = num;
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x0002E780 File Offset: 0x0002C980
		private static void TaskCompletedMapToDictionaryAdapter(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("fected");
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 1 + 38;
			A_0 = num;
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x0002E800 File Offset: 0x0002CA00
		private static void NativeCalendarNameNOTIFTYPECONVERTED(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 78;
			A_0 = num;
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x0002E848 File Offset: 0x0002CA48
		private static void DefineVersionInfoResourceGetFolderPath(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 4;
			A_2 = 184;
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x0002E86C File Offset: 0x0002CA6C
		private static void TokenUserClaimAttributesHasShutdownStarted(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 190;
			A_0 = num;
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x0002E8DC File Offset: 0x0002CADC
		private static void SetStubDataLaunchMail(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			A_0 = 99;
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x0002E8F4 File Offset: 0x0002CAF4
		private static void getItemsSecurityPermission(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 212;
			A_0 = num;
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x0002E950 File Offset: 0x0002CB50
		// Note: this type is marked as 'beforefieldinit'.
		static Visual()
		{
			Visual.fAnonymousTypesetWindowHeight();
			int num = 280;
			int num2 = 280;
			num2 = 280;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 280;
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x0002E998 File Offset: 0x0002CB98
		private static void getReturnParameterINVOCATIONFLAGSNONWPFXAPI(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_0 = 203;
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x0002E9B0 File Offset: 0x0002CBB0
		private static void AbbreviatedMonthNamesShadowCopyFilesValue(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 261;
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x0002E9EC File Offset: 0x0002CBEC
		private static void cParamsOptAsyncCausalityOperation(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 7;
			A_0 = num;
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x0002EA5C File Offset: 0x0002CC5C
		private static void SinkProviderDataRuntimeType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 257;
			A_0 = num;
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x0002EAA4 File Offset: 0x0002CCA4
		private static void StartingTaskFactory(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_1 = 0;
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x0002EABC File Offset: 0x0002CCBC
		private static void getLastAccessTimeIsNestedPublic(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_13]].gameObject);
			A_12 = orAddComponent;
			A_12.startWidth = 0.015f;
			A_12.endWidth = 0.015f;
			A_12.startColor = Color.red;
			A_12.endColor = Color.red;
			A_12.material.shader = Shader.Find("GUI/Text Shader");
			A_12.SetPosition(0, GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_13]].position);
			A_12.SetPosition(1, GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_13 + 1]].position);
			Object.Destroy(A_12, Time.deltaTime);
			int num = A_13 + 2;
			A_13 = num;
			bool flag = A_13 < Enumerable.Count<int>(Visual.bones);
			A_14 = flag;
			int num2 = (A_14 ? 1 : 0) * -2 + 118;
			A_0 = num2;
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x0002EC8C File Offset: 0x0002CE8C
		private static void TypeRepresentsComTypeUnmanagedMemoryStream(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 16;
			A_0 = num;
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x0002ECD4 File Offset: 0x0002CED4
		private static void getAllFilesEverything(ref int A_0, ref int A_1, ref int A_2)
		{
			Visual.infectionESP = true;
			A_1 = 1;
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x0002ECF8 File Offset: 0x0002CEF8
		private static void ISOCurrencySymbolCdsSyncEtwBCLProvider(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 7;
			A_0 = num;
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x0002ED54 File Offset: 0x0002CF54
		private static void getSourceInterfaceComputeHash(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			bool flag = !Visual.infectionESP;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 36;
			A_0 = num;
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x0002EDB8 File Offset: 0x0002CFB8
		private static void UnmanagedMemoryAccessorEnumerateSubKeys(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 134;
			A_0 = num;
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x0002EE14 File Offset: 0x0002D014
		private static void PacketmallSystemTimeZonesRead(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 190;
			A_0 = num;
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x0002EE70 File Offset: 0x0002D070
		private static void NoValuePropTryUpdate(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 16;
			A_0 = num;
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x0002EEB8 File Offset: 0x0002D0B8
		private static void EnumAssembliesGetDirectoryRoot(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 177;
			A_0 = num;
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x0002EF20 File Offset: 0x0002D120
		private static void FailedWriteAllBytes(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 210;
			A_0 = num;
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x0002EF88 File Offset: 0x0002D188
		private static void PointerExecutionContextSwitcher(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(A_5.head.rigTarget.gameObject);
			A_16 = orAddComponent;
			A_16.startWidth = 0.015f;
			A_16.endWidth = 0.015f;
			A_16.startColor = Color.red;
			A_16.endColor = Color.red;
			A_16.material.shader = Shader.Find("GUI/Text Shader");
			A_16.SetPosition(0, A_5.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
			A_16.SetPosition(1, A_5.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
			Object.Destroy(A_16, Time.deltaTime);
			int num = 0;
			A_17 = num;
			A_0 = 96;
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x0002F0FC File Offset: 0x0002D2FC
		private static void MaximumAllowedConvertAssemblyToTypeLib(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 265;
			A_0 = num;
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x0002F16C File Offset: 0x0002D36C
		private static void PrimitiveValueStopped(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 164;
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x0002F1A8 File Offset: 0x0002D3A8
		private static void DependentOSMetadataMinorVersiongetMilliseconds(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_4.Dispose();
			A_1 = 1;
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x0002F1D0 File Offset: 0x0002D3D0
		private static void CommonTemplatesDaylightTimeStruct(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 31;
		}

		// Token: 0x06000529 RID: 1321 RVA: 0x0002F20C File Offset: 0x0002D40C
		private static void IsRetvalRegistryWowKey(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_4.Dispose();
			A_1 = 19;
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x0002F234 File Offset: 0x0002D434
		public unsafe static void BoneESP()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 81;
			int num4 = 81;
			num4 = 81;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num18;
				int num19;
				int num20;
				int num21;
				int num22;
				int num23;
				int num26;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 81;
						if ((int)array[6] != 1)
						{
							num5 = (int)array[4];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num5 + 48 + num2);
								num7 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + (int)array[3] + 48 + num2) + 56 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num7 + 32 + num2);
								if (num8 != -1)
								{
									num9 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num8 + 8 + num2);
									array[3] = num8;
									array[1] = 2;
									num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num8 + 8 + num2);
									goto IL_1A;
								}
								num7 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num7 + 56 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[7];
							num9 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num5 + 8 + num2);
							ex3 = ex2;
							array = (object[])array[0];
							array2 = new object[8];
							array2[6] = 0;
							array2[0] = array;
							array2[7] = ex2;
							array2[3] = num5;
							array2[1] = 1;
							array = array2;
							num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num5 + 8 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[5];
							array = (object[])array[0];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							LineRenderer lineRenderer;
							int num14;
							float num15;
							bool flag3;
							bool flag4;
							LineRenderer lineRenderer2;
							int num16;
							bool flag5;
							LineRenderer lineRenderer3;
							int num17;
							bool flag6;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,UnityEngine.LineRenderer&,System.Int32&,System.Single&,System.Boolean&,System.Boolean&,UnityEngine.LineRenderer&,System.Int32&,System.Boolean&,UnityEngine.LineRenderer&,System.Int32&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref lineRenderer, ref num14, ref num15, ref flag3, ref flag4, ref lineRenderer2, ref num16, ref flag5, ref lineRenderer3, ref num17, ref flag6, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 81;
						num8 = num13;
						num12 = num8;
					}
					num18 = num3;
					num6 = num18;
					num11 = 0;
					num19 = 2;
					for (;;)
					{
						num20 = (num11 + num19) / 2;
						num21 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num20 * 56 + 40 + num2);
						num22 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num20 * 56 + num2);
						if (num6 < num21 + num22)
						{
							if (num21 <= num6)
							{
								break;
							}
							num19 = num20 - 1;
						}
						else
						{
							num11 = num20 + 1;
						}
					}
					num7 = num20;
					num9 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num7 * 56 + 24 + num2);
					num23 = num9;
					num22 = num12;
					num21 = 0;
					num20 = 2;
					for (;;)
					{
						num19 = (num21 + num20) / 2;
						num11 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num19 * 56 + 40 + num2);
						num6 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num19 * 56 + num2);
						if (num22 < num11 + num6)
						{
							if (num11 <= num22)
							{
								break;
							}
							num20 = num19 - 1;
						}
						else
						{
							num21 = num19 + 1;
						}
					}
					num7 = num19;
					num8 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num7 * 56 + 24 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num19 = 2;
					for (;;)
					{
						num20 = (num11 + num19) / 2;
						num21 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num20 * 48 + 32 + num2);
						num22 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num20 * 48 + num2);
						if (num6 < num21 + num22)
						{
							if (num21 <= num6)
							{
								break;
							}
							num19 = num20 - 1;
						}
						else
						{
							num11 = num20 + 1;
						}
					}
					num7 = num20;
					num5 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num7 * 48 + 16 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A6F:
						if (array == null || (int)array[6] == 1)
						{
							num6 = num9;
							while (num6 != num23)
							{
								if (num6 != -1)
								{
									num6 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num6 + 56 + num2);
								}
								else
								{
									num11 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 32 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num23 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 56 + num2);
									goto IL_A6F;
								}
							}
							goto IL_C08;
						}
						int num24 = (int)array[3];
						int num25;
						if (num23 == -1)
						{
							num25 = -1;
						}
						else
						{
							num26 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 16 + num2);
							num22 = 0;
							num21 = 2;
							for (;;)
							{
								num20 = (num22 + num21) / 2;
								num19 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num20 * 48 + 32 + num2);
								num11 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num20 * 48 + num2);
								if (num26 < num19 + num11)
								{
									if (num19 <= num26)
									{
										break;
									}
									num21 = num20 - 1;
								}
								else
								{
									num22 = num20 + 1;
								}
							}
							num5 = num20;
							num7 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num5 * 48 + 16 + num2);
							num25 = num7;
						}
						if (num24 == num25)
						{
							num7 = num9;
							while (num7 != num23)
							{
								if (num7 != -1)
								{
									num7 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num7 + 56 + num2);
								}
								else
								{
									num5 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 32 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num23 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 56 + num2);
									goto IL_A6F;
								}
							}
							break;
						}
						if ((int)array[3] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[0];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num5 + 8 + num2);
					array2 = new object[8];
					array2[6] = 1;
					array2[0] = array;
					array2[5] = num12;
					array2[3] = num5;
					array2[1] = 2;
					array = array2;
					num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num5 + 8 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C08:
					num3 = num12;
					continue;
					Block_62:
					num19 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num11 + 8 + num2);
					array2 = new object[8];
					array2[6] = 1;
					array2[0] = array;
					array2[5] = num12;
					array2[3] = num11;
					array2[1] = 2;
					array = array2;
					num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num11 + 8 + num2);
				}
				num4 = 81;
				return;
				IL_1E2:
				if (num19 != -1)
				{
					goto IL_1ED;
				}
				goto IL_410;
				IL_1ED:
				num6 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num19 + num2);
				if (3 == num6)
				{
					goto IL_209;
				}
				if (0 == num6)
				{
					goto IL_397;
				}
				goto IL_410;
				IL_209:
				num11 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num19 + 24 + num2);
				if (num11 == -1)
				{
					goto IL_257;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_23D;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_23D:
				if (type.IsInstanceOfType(array2[7]))
				{
					goto IL_257;
				}
				num19 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num19 + 16 + num2);
				goto IL_1E2;
				IL_257:
				num23 = num19;
				num18 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 48 + num2) + 56 + num2);
				num7 = (int)array2[2];
				IL_27B:
				if (num7 != num18)
				{
					goto IL_2F8;
				}
				num20 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 8 + num2);
				ex3 = array2[7];
				array = (object[])array[0];
				object[] array5 = new object[8];
				array5[6] = 0;
				array5[0] = array;
				array5[7] = array2[7];
				array5[2] = (int)array2[2];
				array5[3] = num23;
				array5[1] = 1;
				array = array5;
				num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 8 + num2);
				goto IL_1A;
				IL_2F8:
				num9 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num7 + 32 + num2);
				if (num9 == -1)
				{
					goto IL_385;
				}
				num20 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num9 + 8 + num2);
				array = (object[])array[0];
				array5 = new object[8];
				array5[6] = 0;
				array5[0] = array;
				array5[7] = array2[7];
				array5[2] = (int)array2[2];
				array5[3] = num9;
				array5[4] = num23;
				array5[1] = 2;
				array = array5;
				num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num9 + 8 + num2);
				goto IL_1A;
				IL_385:
				num7 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num7 + 56 + num2);
				goto IL_27B;
				IL_397:
				num20 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num19 + 56 + num2);
				ex3 = array2[7];
				array = (object[])array[0];
				array5 = new object[8];
				array5[6] = 0;
				array5[0] = array;
				array5[7] = array2[7];
				array5[2] = (int)array2[2];
				array5[3] = num19;
				array5[1] = 0;
				array = array5;
				num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num19 + 56 + num2);
				goto IL_1A;
				IL_410:
				array = (object[])array[0];
				ex = array2[7];
				int num27 = (int)array2[2];
				IL_42F:
				num19 = num3;
				num20 = num19;
				num21 = 0;
				num22 = 2;
				IL_43D:
				num8 = (num21 + num22) / 2;
				num5 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num8 * 56 + 40 + num2);
				num26 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num8 * 56 + num2);
				if (num20 >= num5 + num26)
				{
					goto IL_480;
				}
				if (num5 > num20)
				{
					goto IL_488;
				}
				num18 = num8;
				num23 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 144 + num18 * 56 + 24 + num2);
				num11 = num23;
				num7 = num11;
				goto IL_4B0;
				IL_480:
				num21 = num8 + 1;
				goto IL_43D;
				IL_488:
				num22 = num8 - 1;
				goto IL_43D;
				IL_4B0:
				if (array != null)
				{
					goto IL_4BB;
				}
				goto IL_644;
				IL_4BB:
				if ((int)array[6] != 1)
				{
					goto IL_578;
				}
				int num28 = (int)array[3];
				if (num11 != -1)
				{
					goto IL_4DF;
				}
				int num29 = -1;
				goto IL_55F;
				IL_4DF:
				int num30 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num11 + 16 + num2);
				num26 = 0;
				num5 = 2;
				IL_4F2:
				num8 = (num26 + num5) / 2;
				num22 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num8 * 48 + 32 + num2);
				num21 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num8 * 48 + num2);
				if (num30 >= num22 + num21)
				{
					goto IL_535;
				}
				if (num22 > num30)
				{
					goto IL_53D;
				}
				num23 = num8;
				num18 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num23 * 48 + 16 + num2);
				num29 = num18;
				goto IL_55F;
				IL_535:
				num26 = num8 + 1;
				goto IL_4F2;
				IL_53D:
				num5 = num8 - 1;
				goto IL_4F2;
				IL_55F:
				if (num28 != num29)
				{
					goto IL_567;
				}
				goto IL_644;
				IL_567:
				array = (object[])array[0];
				goto IL_4B0;
				IL_578:
				num9 = (int)array[1];
				if (num9 == 1 || num9 == 2)
				{
					goto IL_599;
				}
				if (num9 != 0)
				{
					goto IL_598;
				}
				array2 = array;
				num19 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + (int)array2[3] + 16 + num2);
				goto IL_1E2;
				IL_598:
				IL_599:
				int num31 = (int)array[3];
				if (num11 != -1)
				{
					goto IL_5AE;
				}
				int num32 = -1;
				goto IL_62E;
				IL_5AE:
				num20 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num11 + 16 + num2);
				num21 = 0;
				num22 = 2;
				IL_5C1:
				num8 = (num21 + num22) / 2;
				num5 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num8 * 48 + 32 + num2);
				num26 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num8 * 48 + num2);
				if (num20 >= num5 + num26)
				{
					goto IL_604;
				}
				if (num5 > num20)
				{
					goto IL_60C;
				}
				num18 = num8;
				num23 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + 312 + num18 * 48 + 16 + num2);
				num32 = num23;
				goto IL_62E;
				IL_604:
				num21 = num8 + 1;
				goto IL_5C1;
				IL_60C:
				num22 = num8 - 1;
				goto IL_5C1;
				IL_62E:
				if (num31 != num32)
				{
					goto IL_633;
				}
				goto IL_644;
				IL_633:
				array = (object[])array[0];
				goto IL_4B0;
				IL_644:
				if (-1 != num11)
				{
					goto IL_6E6;
				}
				num23 = num7;
				IL_651:
				if (num23 != -1)
				{
					goto IL_65D;
				}
				num10 = 1;
				throw ex;
				IL_65D:
				num18 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 32 + num2);
				if (num18 == -1)
				{
					goto IL_6D4;
				}
				num30 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num18 + 8 + num2);
				array2 = new object[8];
				array2[6] = 0;
				array2[0] = array;
				array2[7] = ex;
				array2[2] = num7;
				array2[3] = -1;
				array2[4] = -1;
				array2[1] = 1;
				array = array2;
				num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num18 + 8 + num2);
				goto IL_1A;
				IL_6D4:
				num23 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num23 + 56 + num2);
				goto IL_651;
				IL_6E6:
				num6 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num11 + num2);
				num20 = num6;
				IL_6F4:
				if (num20 != -1)
				{
					goto IL_70B;
				}
				num11 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num11 + 56 + num2);
				goto IL_4B0;
				IL_70B:
				num22 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num20 + num2);
				if (3 == num22)
				{
					goto IL_733;
				}
				if (0 == num22)
				{
					goto IL_89D;
				}
				num11 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num11 + 56 + num2);
				goto IL_4B0;
				IL_733:
				num21 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num20 + 24 + num2);
				if (num21 == -1)
				{
					goto IL_782;
				}
				Type type2;
				if ((type2 = array3[num21]) != null)
				{
					goto IL_767;
				}
				array3[num21] = Type.GetTypeFromHandle(array4[num21]);
				type2 = array3[num21];
				IL_767:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_782;
				}
				num20 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num20 + 16 + num2);
				goto IL_6F4;
				IL_782:
				num30 = num20;
				num26 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num30 + 48 + num2) + 56 + num2);
				num5 = (num7 - num27) * ((num27 == -1) ? 1 : 0) + num27;
				IL_7AB:
				if (num5 != num26)
				{
					goto IL_812;
				}
				int num33 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num30 + 8 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[6] = 0;
				array2[0] = array;
				array2[7] = ex;
				array2[2] = num7;
				array2[3] = num30;
				array2[1] = 1;
				array = array2;
				num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num30 + 8 + num2);
				goto IL_1A;
				IL_812:
				num8 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num5 + 32 + num2);
				if (num8 == -1)
				{
					goto IL_88B;
				}
				num33 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num8 + 8 + num2);
				array2 = new object[8];
				array2[6] = 0;
				array2[0] = array;
				array2[7] = ex;
				array2[2] = num7;
				array2[3] = num8;
				array2[4] = num30;
				array2[1] = 2;
				array = array2;
				num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num8 + 8 + num2);
				goto IL_1A;
				IL_88B:
				num5 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num5 + 56 + num2);
				goto IL_7AB;
				IL_89D:
				num33 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num20 + 56 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[6] = 0;
				array2[0] = array;
				array2[7] = ex;
				array2[2] = num7;
				array2[3] = num20;
				array2[1] = 0;
				array = array2;
				num3 = *(ref AssemblySuppliedGenericAll.getIsMethodDefLocalServiceSid + num20 + 56 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num27 = -1;
					goto IL_42F;
				}
				throw ex4;
			}
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x0002FF00 File Offset: 0x0002E100
		private static void WriteArrayPanic(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 226;
			A_0 = num;
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x0002FF48 File Offset: 0x0002E148
		private static void ParallelLoopBeginNoContext(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Visual.trail = ComponentUtils.AddComponent<TrailRenderer>(A_5);
			Visual.trail.startColor = Color.green;
			Visual.trail.endColor = Color.green;
			Visual.trail.startWidth = 0.05f;
			Visual.trail.endWidth = 0f;
			Visual.trail.minVertexDistance = 0.05f;
			Visual.trail.material.shader = Shader.Find("GUI/Text Shader");
			Visual.trail.time = 2f;
			A_0 = 156;
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x0002FFF0 File Offset: 0x0002E1F0
		private static void STAGetRegisteredActivatedClientTypes(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 3;
			A_2 = 206;
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x00030014 File Offset: 0x0002E214
		private static void ManifestPathUninstallOthers(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !Visual.infectionESP;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 8;
			A_0 = num;
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x00030078 File Offset: 0x0002E278
		private static void EnumerableToBindableIterableAdapterGetMethods(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 0;
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x00030090 File Offset: 0x0002E290
		private static void TraceSynchronousWorkCMSHASHTRANSFORM(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 5;
			A_0 = num;
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x000300F8 File Offset: 0x0002E2F8
		private static void getHostDllAssertion(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			bool flag = A_10 < Enumerable.Count<int>(Visual.bones);
			A_11 = flag;
			int num = (A_11 ? 1 : 0) * -2 + 114;
			A_0 = num;
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x00030164 File Offset: 0x0002E364
		private static void IsNotPublicVARFLAGFDISPLAYBIND(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 151;
			A_0 = num;
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x000301C0 File Offset: 0x0002E3C0
		public static void lowualy()
		{
			int num = 121;
			int num2 = 121;
			num2 = 121;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 121;
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x000301F8 File Offset: 0x0002E3F8
		private static void WindowObjectLoop(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			A_4.Dispose();
			A_1 = 3;
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x00030220 File Offset: 0x0002E420
		private static void SetOnCountdownMresNternal(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 182;
			A_0 = num;
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x00030268 File Offset: 0x0002E468
		private static void LibrarygetInnerException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref GameObject A_4, ref Rigidbody A_5, ref TrailRenderer A_6)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 1 + 230;
			A_0 = num;
		}

		// Token: 0x06000537 RID: 1335 RVA: 0x000302CC File Offset: 0x0002E4CC
		private static void SetActivityIdResourceExposureLevel(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			A_1 = 0;
		}

		// Token: 0x06000538 RID: 1336 RVA: 0x000302E8 File Offset: 0x0002E4E8
		private static void getUICCSTDCALL(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_15.material.renderQueue = 3000;
			float num = 0f;
			A_19 = num;
			num = A_19 + Time.deltaTime;
			A_19 = num;
			A_15.startColor = Main.outlineColor;
			A_15.endColor = Main.outlineColor;
			A_8.transform.position = A_5.transform.position;
			A_8.transform.LookAt(Camera.main.transform.position);
			A_15.transform.LookAt(Camera.main.transform.position);
			Object.Destroy(A_8, Time.deltaTime);
			A_0 = 75;
		}

		// Token: 0x06000539 RID: 1337 RVA: 0x00030404 File Offset: 0x0002E604
		private static void TimerHolderGetCheckSum(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 5;
			A_2 = 228;
		}

		// Token: 0x0600053A RID: 1338 RVA: 0x00030428 File Offset: 0x0002E628
		private static void ResourceManagerGetSatelliteAssemblyFailedSetAll(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 27;
			A_0 = num;
		}

		// Token: 0x0600053B RID: 1339 RVA: 0x00030470 File Offset: 0x0002E670
		private static void CCMAXIsPrefix(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			GameObject gameObject = new GameObject("Line");
			A_14 = gameObject;
			A_14.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			LineRenderer lineRenderer = A_14.AddComponent<LineRenderer>();
			A_15 = lineRenderer;
			A_15.SetPosition(0, GorillaTagger.Instance.offlineVRRig.rightHandTransform.position);
			A_15.SetPosition(1, A_5.transform.position);
			A_15.startWidth = 0.015f;
			A_15.endWidth = 0.015f;
			A_15.material.shader = Shader.Find("GUI/Text Shader");
			A_15.material.color = Color.red;
			Object.Destroy(A_14, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 246;
			A_0 = num;
		}

		// Token: 0x0600053C RID: 1340 RVA: 0x000305E0 File Offset: 0x0002E7E0
		private static void DeclareLocalFullTrustZoneInternet(ref int A_0, ref int A_1, ref int A_2, ref Renderer[] A_3, ref int A_4, ref Renderer A_5)
		{
			Renderer[] array = Object.FindObjectsOfType<Renderer>();
			A_3 = array;
			int num = 0;
			A_4 = num;
			A_0 = 273;
		}

		// Token: 0x0600053D RID: 1341 RVA: 0x00030628 File Offset: 0x0002E828
		private static void getLegalKeySizesPropertyAnalysis(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("fected");
			A_20 = flag;
			int num = ((!A_20) ? 1 : 0) * 3 + 68;
			A_0 = num;
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x000306A8 File Offset: 0x0002E8A8
		private static void IsHideBySigPrepareConstrainedRegionsNoOP(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			A_1 = 1;
			A_2 = 259;
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x000306CC File Offset: 0x0002E8CC
		private static void DivUnEndBuffered(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_27.material = new Material(A_29);
			A_27.material.renderQueue = 3000;
			A_27.startColor = Color.green;
			A_27.endColor = Color.green;
			A_21.transform.position = A_5.transform.position;
			A_21.transform.LookAt(GorillaTagger.Instance.headCollider.transform);
			Object.Destroy(A_21, Time.deltaTime);
			A_0 = 74;
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x000307A4 File Offset: 0x0002E9A4
		private static void UniversalTimeGetReferencedAssemblies(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 246;
			A_0 = num;
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x000307EC File Offset: 0x0002E9EC
		private static void UnknownIdentities(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			A_4.Dispose();
			A_1 = 4;
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x00030814 File Offset: 0x0002EA14
		private static void GetSByteTOKENSTATISTICS(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			int actorNumber = A_5.Creator.ActorNumber;
			A_7 = actorNumber;
			Player player = PhotonNetwork.CurrentRoom.GetPlayer(A_7, false);
			A_8 = player;
			GameObject gameObject = new GameObject();
			A_9 = gameObject;
			TextMeshPro textMeshPro = A_9.AddComponent<TextMeshPro>();
			A_10 = textMeshPro;
			A_10.text = A_8.NickName;
			A_10.fontSize = 2f;
			A_10.alignment = 514;
			A_10.color = A_5.mainSkin.material.color;
			A_10.font = GameObject.Find("motdtext").GetComponent<TextMeshPro>().font;
			Object.Destroy(A_9, Time.deltaTime);
			Transform transform = A_9.transform;
			A_11 = transform;
			A_11.transform.localScale = new Vector3(0.6f, 0.6f, 0.6f);
			A_11.position = A_5.transform.position + new Vector3(0f, 0.5f, 0f);
			A_11.LookAt(Camera.main.transform.position);
			A_11.Rotate(0f, 180f, 0f);
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 27;
			A_0 = num;
		}

		// Token: 0x06000543 RID: 1347 RVA: 0x00030A40 File Offset: 0x0002EC40
		private static void GenerateHashJulianCenturies(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			A_1 = 0;
		}

		// Token: 0x06000544 RID: 1348 RVA: 0x00030A58 File Offset: 0x0002EC58
		private static void setHashValueDisallowPublisherPolicyValue(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 52;
			A_0 = num;
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x00030AB4 File Offset: 0x0002ECB4
		private static void TraceFormatUnicodeCategory(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 0;
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x00030ACC File Offset: 0x0002ECCC
		private static void WriteKeyopLessThanOrEqual(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			A_0 = 142;
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x00030AE4 File Offset: 0x0002ECE4
		private static void IsDSProgramFilesX(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 35;
			A_0 = num;
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x00030B54 File Offset: 0x0002ED54
		private static void TransformMetadataSizesetApplicationUrl(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_5.mainSkin.material.shader = Shader.Find("GorillaTag/UberShader");
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 55;
			A_0 = num;
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x00030BC0 File Offset: 0x0002EDC0
		public unsafe static void Lines()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 249;
			int num4 = 249;
			num4 = 249;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num23;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 249;
						if ((int)array[6] != 1)
						{
							num5 = (int)array[0];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num5 + 72 + num2);
								num7 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + (int)array[1] + 72 + num2) + 64 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num7 + 16 + num2);
								if (num8 != -1)
								{
									num9 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num8 + 48 + num2);
									array[1] = num8;
									array[4] = 2;
									num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num8 + 48 + num2);
									goto IL_23;
								}
								num7 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num7 + 64 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[5];
							num9 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num5 + 48 + num2);
							ex3 = ex2;
							array = (object[])array[3];
							array2 = new object[8];
							array2[6] = 0;
							array2[3] = array;
							array2[5] = ex2;
							array2[1] = num5;
							array2[4] = 0;
							array = array2;
							num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num5 + 48 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[7];
							array = (object[])array[3];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 1)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							GameObject gameObject;
							LineRenderer lineRenderer;
							float num14;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,System.Single&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref gameObject, ref lineRenderer, ref num14, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 249;
						num8 = num13;
						num12 = num8;
					}
					num15 = num3;
					num6 = num15;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num17 * 48 + 32 + num2);
						num19 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num17 * 48 + 16 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num9 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num7 * 48 + 8 + num2);
					num20 = num9;
					num19 = num12;
					num18 = 0;
					num17 = 2;
					for (;;)
					{
						num16 = (num18 + num17) / 2;
						num11 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num16 * 48 + 32 + num2);
						num6 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num16 * 48 + 16 + num2);
						if (num19 < num11 + num6)
						{
							if (num11 <= num19)
							{
								break;
							}
							num17 = num16 - 1;
						}
						else
						{
							num18 = num16 + 1;
						}
					}
					num7 = num16;
					num8 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num7 * 48 + 8 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num17 * 64 + 48 + num2);
						num19 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num17 * 64 + 24 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num5 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num7 * 64 + 8 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A92:
						if (array == null || (int)array[6] == 1)
						{
							num6 = num9;
							while (num6 != num20)
							{
								if (num6 != -1)
								{
									num6 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num6 + 64 + num2);
								}
								else
								{
									num11 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 16 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num20 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 64 + num2);
									goto IL_A92;
								}
							}
							goto IL_C2F;
						}
						int num21 = (int)array[1];
						int num22;
						if (num20 == -1)
						{
							num22 = -1;
						}
						else
						{
							num23 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 32 + num2);
							num19 = 0;
							num18 = 2;
							for (;;)
							{
								num17 = (num19 + num18) / 2;
								num16 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num17 * 64 + 48 + num2);
								num11 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num17 * 64 + 24 + num2);
								if (num23 < num16 + num11)
								{
									if (num16 <= num23)
									{
										break;
									}
									num18 = num17 - 1;
								}
								else
								{
									num19 = num17 + 1;
								}
							}
							num5 = num17;
							num7 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num5 * 64 + 8 + num2);
							num22 = num7;
						}
						if (num21 == num22)
						{
							num7 = num9;
							while (num7 != num20)
							{
								if (num7 != -1)
								{
									num7 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num7 + 64 + num2);
								}
								else
								{
									num5 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 16 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num20 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 64 + num2);
									goto IL_A92;
								}
							}
							break;
						}
						if ((int)array[1] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[3];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num5 + 48 + num2);
					array2 = new object[8];
					array2[6] = 1;
					array2[3] = array;
					array2[7] = num12;
					array2[1] = num5;
					array2[4] = 2;
					array = array2;
					num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num5 + 48 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C2F:
					num3 = num12;
					continue;
					Block_62:
					num16 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num11 + 48 + num2);
					array2 = new object[8];
					array2[6] = 1;
					array2[3] = array;
					array2[7] = num12;
					array2[1] = num11;
					array2[4] = 2;
					array = array2;
					num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num11 + 48 + num2);
				}
				num4 = 249;
				return;
				IL_1E6:
				if (num16 != -1)
				{
					goto IL_1F1;
				}
				goto IL_41B;
				IL_1F1:
				num6 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num16 + 40 + num2);
				if (4 == num6)
				{
					goto IL_210;
				}
				if (2 == num6)
				{
					goto IL_3A2;
				}
				goto IL_41B;
				IL_210:
				num11 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num16 + 16 + num2);
				if (num11 == -1)
				{
					goto IL_25E;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_244;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_244:
				if (type.IsInstanceOfType(array2[5]))
				{
					goto IL_25E;
				}
				num16 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num16 + 24 + num2);
				goto IL_1E6;
				IL_25E:
				num20 = num16;
				num15 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 72 + num2) + 64 + num2);
				num7 = (int)array2[2];
				IL_282:
				if (num7 != num15)
				{
					goto IL_301;
				}
				num17 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 48 + num2);
				ex3 = array2[5];
				array = (object[])array[3];
				object[] array5 = new object[8];
				array5[6] = 0;
				array5[3] = array;
				array5[5] = array2[5];
				array5[2] = (int)array2[2];
				array5[1] = num20;
				array5[4] = 0;
				array = array5;
				num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 48 + num2);
				goto IL_23;
				IL_301:
				num9 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num7 + 16 + num2);
				if (num9 == -1)
				{
					goto IL_390;
				}
				num17 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num9 + 48 + num2);
				array = (object[])array[3];
				array5 = new object[8];
				array5[6] = 0;
				array5[3] = array;
				array5[5] = array2[5];
				array5[2] = (int)array2[2];
				array5[1] = num9;
				array5[0] = num20;
				array5[4] = 2;
				array = array5;
				num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num9 + 48 + num2);
				goto IL_23;
				IL_390:
				num7 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num7 + 64 + num2);
				goto IL_282;
				IL_3A2:
				num17 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num16 + 32 + num2);
				ex3 = array2[5];
				array = (object[])array[3];
				array5 = new object[8];
				array5[6] = 0;
				array5[3] = array;
				array5[5] = array2[5];
				array5[2] = (int)array2[2];
				array5[1] = num16;
				array5[4] = 1;
				array = array5;
				num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num16 + 32 + num2);
				goto IL_23;
				IL_41B:
				array = (object[])array[3];
				ex = array2[5];
				int num24 = (int)array2[2];
				IL_43A:
				num16 = num3;
				num17 = num16;
				num18 = 0;
				num19 = 2;
				IL_448:
				num8 = (num18 + num19) / 2;
				num5 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num8 * 48 + 32 + num2);
				num23 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num8 * 48 + 16 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_48E;
				}
				if (num5 > num17)
				{
					goto IL_496;
				}
				num15 = num8;
				num20 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 168 + num15 * 48 + 8 + num2);
				num11 = num20;
				num7 = num11;
				goto IL_4BD;
				IL_48E:
				num18 = num8 + 1;
				goto IL_448;
				IL_496:
				num19 = num8 - 1;
				goto IL_448;
				IL_4BD:
				if (array != null)
				{
					goto IL_4C8;
				}
				goto IL_655;
				IL_4C8:
				if ((int)array[6] != 1)
				{
					goto IL_587;
				}
				int num25 = (int)array[1];
				if (num11 != -1)
				{
					goto IL_4EC;
				}
				int num26 = -1;
				goto IL_56E;
				IL_4EC:
				int num27 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num11 + 32 + num2);
				num23 = 0;
				num5 = 2;
				IL_4FF:
				num8 = (num23 + num5) / 2;
				num19 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num8 * 64 + 48 + num2);
				num18 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num8 * 64 + 24 + num2);
				if (num27 >= num19 + num18)
				{
					goto IL_545;
				}
				if (num19 > num27)
				{
					goto IL_54D;
				}
				num20 = num8;
				num15 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num20 * 64 + 8 + num2);
				num26 = num15;
				goto IL_56E;
				IL_545:
				num23 = num8 + 1;
				goto IL_4FF;
				IL_54D:
				num5 = num8 - 1;
				goto IL_4FF;
				IL_56E:
				if (num25 != num26)
				{
					goto IL_576;
				}
				goto IL_655;
				IL_576:
				array = (object[])array[3];
				goto IL_4BD;
				IL_587:
				num9 = (int)array[4];
				if (num9 == 0 || num9 == 2)
				{
					goto IL_5A8;
				}
				if (num9 != 1)
				{
					goto IL_5A7;
				}
				array2 = array;
				num16 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + (int)array2[1] + 24 + num2);
				goto IL_1E6;
				IL_5A7:
				IL_5A8:
				int num28 = (int)array[1];
				if (num11 != -1)
				{
					goto IL_5BD;
				}
				int num29 = -1;
				goto IL_63F;
				IL_5BD:
				num17 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num11 + 32 + num2);
				num18 = 0;
				num19 = 2;
				IL_5D0:
				num8 = (num18 + num19) / 2;
				num5 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num8 * 64 + 48 + num2);
				num23 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num8 * 64 + 24 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_616;
				}
				if (num5 > num17)
				{
					goto IL_61E;
				}
				num15 = num8;
				num20 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + 312 + num15 * 64 + 8 + num2);
				num29 = num20;
				goto IL_63F;
				IL_616:
				num18 = num8 + 1;
				goto IL_5D0;
				IL_61E:
				num19 = num8 - 1;
				goto IL_5D0;
				IL_63F:
				if (num28 != num29)
				{
					goto IL_644;
				}
				goto IL_655;
				IL_644:
				array = (object[])array[3];
				goto IL_4BD;
				IL_655:
				if (-1 != num11)
				{
					goto IL_6F9;
				}
				num20 = num7;
				IL_662:
				if (num20 != -1)
				{
					goto IL_66E;
				}
				num10 = 1;
				throw ex;
				IL_66E:
				num15 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 16 + num2);
				if (num15 == -1)
				{
					goto IL_6E7;
				}
				num27 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num15 + 48 + num2);
				array2 = new object[8];
				array2[6] = 0;
				array2[3] = array;
				array2[5] = ex;
				array2[2] = num7;
				array2[1] = -1;
				array2[0] = -1;
				array2[4] = 0;
				array = array2;
				num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num15 + 48 + num2);
				goto IL_23;
				IL_6E7:
				num20 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num20 + 64 + num2);
				goto IL_662;
				IL_6F9:
				num6 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num11 + 40 + num2);
				num17 = num6;
				IL_70A:
				if (num17 != -1)
				{
					goto IL_721;
				}
				num11 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num11 + 64 + num2);
				goto IL_4BD;
				IL_721:
				num19 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num17 + 40 + num2);
				if (4 == num19)
				{
					goto IL_74C;
				}
				if (2 == num19)
				{
					goto IL_8BA;
				}
				num11 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num11 + 64 + num2);
				goto IL_4BD;
				IL_74C:
				num18 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num17 + 16 + num2);
				if (num18 == -1)
				{
					goto IL_79B;
				}
				Type type2;
				if ((type2 = array3[num18]) != null)
				{
					goto IL_780;
				}
				array3[num18] = Type.GetTypeFromHandle(array4[num18]);
				type2 = array3[num18];
				IL_780:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_79B;
				}
				num17 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num17 + 24 + num2);
				goto IL_70A;
				IL_79B:
				num27 = num17;
				num23 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num27 + 72 + num2) + 64 + num2);
				num5 = (num7 - num24) * ((num24 == -1) ? 1 : 0) + num24;
				IL_7C4:
				if (num5 != num23)
				{
					goto IL_82D;
				}
				int num30 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num27 + 48 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[6] = 0;
				array2[3] = array;
				array2[5] = ex;
				array2[2] = num7;
				array2[1] = num27;
				array2[4] = 0;
				array = array2;
				num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num27 + 48 + num2);
				goto IL_23;
				IL_82D:
				num8 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num5 + 16 + num2);
				if (num8 == -1)
				{
					goto IL_8A8;
				}
				num30 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num8 + 48 + num2);
				array2 = new object[8];
				array2[6] = 0;
				array2[3] = array;
				array2[5] = ex;
				array2[2] = num7;
				array2[1] = num8;
				array2[0] = num27;
				array2[4] = 2;
				array = array2;
				num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num8 + 48 + num2);
				goto IL_23;
				IL_8A8:
				num5 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num5 + 64 + num2);
				goto IL_7C4;
				IL_8BA:
				num30 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num17 + 32 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[6] = 0;
				array2[3] = array;
				array2[5] = ex;
				array2[2] = num7;
				array2[1] = num17;
				array2[4] = 1;
				array = array2;
				num3 = *(ref ContextBoundObjectgetAction.AnsiClassDescriptionData + num17 + 32 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num24 = -1;
					goto IL_43A;
				}
				throw ex4;
			}
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x000318B4 File Offset: 0x0002FAB4
		private static void paramdescGetChannelData(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 13 + 63;
			A_0 = num;
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x00031910 File Offset: 0x0002FB10
		private static void getSourceStrongNameSignatureVerification(ref int A_0, ref int A_1, ref int A_2, Visual A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x00031934 File Offset: 0x0002FB34
		private static void getAssemblyIsPrivateEtwSelfDescribingEventFormat(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_0 = 15;
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x0003194C File Offset: 0x0002FB4C
		private static void BltUnSsetMonthNames(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			bool flag = !Visual.infectionESP;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 4 + 106;
			A_0 = num;
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x000319B0 File Offset: 0x0002FBB0
		private static void StrongNameKeyGenExUserEntryPoint(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 268;
			A_0 = num;
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x000319F8 File Offset: 0x0002FBF8
		private static void getMutexRightsSetNativeFunction(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			GameObject gameObject = GameObject.CreatePrimitive(1);
			A_7 = gameObject;
			A_7.transform.position = A_5.transform.position;
			Object.Destroy(A_7.GetComponent<CapsuleCollider>());
			A_7.transform.localScale = new Vector3(0.5f, 0.5f, 0.3f);
			A_7.transform.LookAt(Camera.main.transform.position);
			A_7.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_7.GetComponent<Renderer>().material.color = Main.outlineColor;
			Object.Destroy(A_7, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 193;
			A_0 = num;
		}

		// Token: 0x06000550 RID: 1360 RVA: 0x00031B3C File Offset: 0x0002FD3C
		private static void TryDequeueMakeDataType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			A_1 = 4;
			A_2 = 145;
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x00031B60 File Offset: 0x0002FD60
		public unsafe static void FilledBox()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 174;
			int num4 = 174;
			num4 = 174;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 1)
					{
						num4 = 174;
						if ((int)array[7] != 1)
						{
							num5 = (int)array[6];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num5 + 72 + num2);
								num7 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + (int)array[0] + 72 + num2) + 72 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num7 + 8 + num2);
								if (num8 != -1)
								{
									num9 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num8 + 24 + num2);
									array[0] = num8;
									array[2] = 2;
									num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num8 + 24 + num2);
									goto IL_23;
								}
								num7 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num7 + 72 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[3];
							num9 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num5 + 24 + num2);
							ex3 = ex2;
							array = (object[])array[4];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								default(object),
								0
							};
							array2[4] = array;
							array2[3] = ex2;
							array2[0] = num5;
							array2[2] = 0;
							array = array2;
							num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num5 + 24 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[5];
							array = (object[])array[4];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							GameObject gameObject;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,UnityEngine.GameObject&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref gameObject, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 174;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num16 * 40 + 32 + num2);
						num18 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num16 * 40 + 16 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num7 * 40 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num15 * 40 + 32 + num2);
						num6 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num15 * 40 + 16 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num7 * 40 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num16 * 48 + 40 + num2);
						num18 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num16 * 48 + 16 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num7 * 48 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A7C:
						if (array == null || (int)array[7] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num6 + 72 + num2);
								}
								else
								{
									num11 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 8 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 72 + num2);
									goto IL_A7C;
								}
							}
							goto IL_C16;
						}
						int num20 = (int)array[0];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 24 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num16 * 48 + 40 + num2);
								num11 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num16 * 48 + 16 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num5 * 48 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num7 + 72 + num2);
								}
								else
								{
									num5 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 8 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 72 + num2);
									goto IL_A7C;
								}
							}
							break;
						}
						if ((int)array[0] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[4];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num5 + 24 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						1
					};
					array2[4] = array;
					array2[5] = num12;
					array2[0] = num5;
					array2[2] = 2;
					array = array2;
					num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num5 + 24 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C16:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num11 + 24 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						default(object),
						1
					};
					array2[4] = array;
					array2[5] = num12;
					array2[0] = num11;
					array2[2] = 2;
					array = array2;
					num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num11 + 24 + num2);
				}
				num4 = 174;
				return;
				IL_1E1:
				if (num15 != -1)
				{
					goto IL_1EC;
				}
				goto IL_414;
				IL_1EC:
				num6 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num15 + 40 + num2);
				if (4 == num6)
				{
					goto IL_20B;
				}
				if (2 == num6)
				{
					goto IL_39B;
				}
				goto IL_414;
				IL_20B:
				num11 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num15 + 8 + num2);
				if (num11 == -1)
				{
					goto IL_258;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_23E;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_23E:
				if (type.IsInstanceOfType(array2[3]))
				{
					goto IL_258;
				}
				num15 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num15 + 16 + num2);
				goto IL_1E1;
				IL_258:
				num19 = num15;
				num14 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 72 + num2) + 72 + num2);
				num7 = (int)array2[1];
				IL_27C:
				if (num7 != num14)
				{
					goto IL_2FB;
				}
				num16 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 24 + num2);
				ex3 = array2[3];
				array = (object[])array[4];
				object[] array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[4] = array;
				array5[3] = array2[3];
				array5[1] = (int)array2[1];
				array5[0] = num19;
				array5[2] = 0;
				array = array5;
				num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 24 + num2);
				goto IL_23;
				IL_2FB:
				num9 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num7 + 8 + num2);
				if (num9 == -1)
				{
					goto IL_389;
				}
				num16 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num9 + 24 + num2);
				array = (object[])array[4];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[4] = array;
				array5[3] = array2[3];
				array5[1] = (int)array2[1];
				array5[0] = num9;
				array5[6] = num19;
				array5[2] = 2;
				array = array5;
				num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num9 + 24 + num2);
				goto IL_23;
				IL_389:
				num7 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num7 + 72 + num2);
				goto IL_27C;
				IL_39B:
				num16 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num15 + 32 + num2);
				ex3 = array2[3];
				array = (object[])array[4];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array5[4] = array;
				array5[3] = array2[3];
				array5[1] = (int)array2[1];
				array5[0] = num15;
				array5[2] = 1;
				array = array5;
				num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num15 + 32 + num2);
				goto IL_23;
				IL_414:
				array = (object[])array[4];
				ex = array2[3];
				int num23 = (int)array2[1];
				IL_433:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_441:
				num8 = (num17 + num18) / 2;
				num5 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num8 * 40 + 32 + num2);
				num22 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num8 * 40 + 16 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_487;
				}
				if (num5 > num16)
				{
					goto IL_48F;
				}
				num14 = num8;
				num19 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 176 + num14 * 40 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4B4;
				IL_487:
				num17 = num8 + 1;
				goto IL_441;
				IL_48F:
				num18 = num8 - 1;
				goto IL_441;
				IL_4B4:
				if (array != null)
				{
					goto IL_4BF;
				}
				goto IL_648;
				IL_4BF:
				if ((int)array[7] != 1)
				{
					goto IL_57C;
				}
				int num24 = (int)array[0];
				if (num11 != -1)
				{
					goto IL_4E3;
				}
				int num25 = -1;
				goto IL_563;
				IL_4E3:
				int num26 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num11 + 24 + num2);
				num22 = 0;
				num5 = 2;
				IL_4F6:
				num8 = (num22 + num5) / 2;
				num18 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num8 * 48 + 40 + num2);
				num17 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num8 * 48 + 16 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_53C;
				}
				if (num18 > num26)
				{
					goto IL_544;
				}
				num19 = num8;
				num14 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num19 * 48 + num2);
				num25 = num14;
				goto IL_563;
				IL_53C:
				num22 = num8 + 1;
				goto IL_4F6;
				IL_544:
				num5 = num8 - 1;
				goto IL_4F6;
				IL_563:
				if (num24 != num25)
				{
					goto IL_56B;
				}
				goto IL_648;
				IL_56B:
				array = (object[])array[4];
				goto IL_4B4;
				IL_57C:
				num9 = (int)array[2];
				if (num9 == 0 || num9 == 2)
				{
					goto IL_59D;
				}
				if (num9 != 1)
				{
					goto IL_59C;
				}
				array2 = array;
				num15 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + (int)array2[0] + 16 + num2);
				goto IL_1E1;
				IL_59C:
				IL_59D:
				int num27 = (int)array[0];
				if (num11 != -1)
				{
					goto IL_5B2;
				}
				int num28 = -1;
				goto IL_632;
				IL_5B2:
				num16 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num11 + 24 + num2);
				num17 = 0;
				num18 = 2;
				IL_5C5:
				num8 = (num17 + num18) / 2;
				num5 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num8 * 48 + 40 + num2);
				num22 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num8 * 48 + 16 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_60B;
				}
				if (num5 > num16)
				{
					goto IL_613;
				}
				num14 = num8;
				num19 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + 296 + num14 * 48 + num2);
				num28 = num19;
				goto IL_632;
				IL_60B:
				num17 = num8 + 1;
				goto IL_5C5;
				IL_613:
				num18 = num8 - 1;
				goto IL_5C5;
				IL_632:
				if (num27 != num28)
				{
					goto IL_637;
				}
				goto IL_648;
				IL_637:
				array = (object[])array[4];
				goto IL_4B4;
				IL_648:
				if (-1 != num11)
				{
					goto IL_6EB;
				}
				num19 = num7;
				IL_655:
				if (num19 != -1)
				{
					goto IL_661;
				}
				num10 = 1;
				throw ex;
				IL_661:
				num14 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 8 + num2);
				if (num14 == -1)
				{
					goto IL_6D9;
				}
				num26 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num14 + 24 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[4] = array;
				array2[3] = ex;
				array2[1] = num7;
				array2[0] = -1;
				array2[6] = -1;
				array2[2] = 0;
				array = array2;
				num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num14 + 24 + num2);
				goto IL_23;
				IL_6D9:
				num19 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num19 + 72 + num2);
				goto IL_655;
				IL_6EB:
				num6 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num11 + 40 + num2);
				num16 = num6;
				IL_6FC:
				if (num16 != -1)
				{
					goto IL_713;
				}
				num11 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num11 + 72 + num2);
				goto IL_4B4;
				IL_713:
				num18 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num16 + 40 + num2);
				if (4 == num18)
				{
					goto IL_73E;
				}
				if (2 == num18)
				{
					goto IL_8AA;
				}
				num11 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num11 + 72 + num2);
				goto IL_4B4;
				IL_73E:
				num17 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num16 + 8 + num2);
				if (num17 == -1)
				{
					goto IL_78C;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_771;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_771:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_78C;
				}
				num16 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num16 + 16 + num2);
				goto IL_6FC;
				IL_78C:
				num26 = num16;
				num22 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num26 + 72 + num2) + 72 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7B5:
				if (num5 != num22)
				{
					goto IL_81E;
				}
				int num29 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num26 + 24 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[4] = array;
				array2[3] = ex;
				array2[1] = num7;
				array2[0] = num26;
				array2[2] = 0;
				array = array2;
				num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num26 + 24 + num2);
				goto IL_23;
				IL_81E:
				num8 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num5 + 8 + num2);
				if (num8 == -1)
				{
					goto IL_898;
				}
				num29 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num8 + 24 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[4] = array;
				array2[3] = ex;
				array2[1] = num7;
				array2[0] = num8;
				array2[6] = num26;
				array2[2] = 2;
				array = array2;
				num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num8 + 24 + num2);
				goto IL_23;
				IL_898:
				num5 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num5 + 72 + num2);
				goto IL_7B5;
				IL_8AA:
				num29 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num16 + 32 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					default(object),
					0
				};
				array2[4] = array;
				array2[3] = ex;
				array2[1] = num7;
				array2[0] = num16;
				array2[2] = 1;
				array = array2;
				num3 = *(ref IsInitOnlygetThreeLetterWindowsLanguageName.CriticalHandleSpacingCombiningMark + num16 + 32 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_433;
				}
				throw ex4;
			}
		}

		// Token: 0x06000552 RID: 1362 RVA: 0x0003283C File Offset: 0x00030A3C
		public unsafe static void PrismicLines()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 260;
			int num4 = 260;
			num4 = 260;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num23;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 260;
						if ((int)array[1] != 0)
						{
							num5 = (int)array[6];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num5 + 8 + num2);
								num7 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + (int)array[4] + 8 + num2) + 8 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num7 + 32 + num2);
								if (num8 != -1)
								{
									num9 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num8 + 64 + num2);
									array[4] = num8;
									array[7] = 0;
									num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num8 + 64 + num2);
									goto IL_23;
								}
								num7 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num7 + 8 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[5];
							num9 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num5 + 64 + num2);
							ex3 = ex2;
							array = (object[])array[2];
							array2 = new object[8];
							array2[1] = 1;
							array2[2] = array;
							array2[5] = ex2;
							array2[4] = num5;
							array2[7] = 2;
							array = array2;
							num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num5 + 64 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[0];
							array = (object[])array[2];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 3)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							GameObject gameObject;
							LineRenderer lineRenderer;
							float num14;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,System.Single&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref gameObject, ref lineRenderer, ref num14, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 260;
						num8 = num13;
						num12 = num8;
					}
					num15 = num3;
					num6 = num15;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num17 * 56 + 8 + num2);
						num19 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num17 * 56 + 16 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num9 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num7 * 56 + 32 + num2);
					num20 = num9;
					num19 = num12;
					num18 = 0;
					num17 = 2;
					for (;;)
					{
						num16 = (num18 + num17) / 2;
						num11 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num16 * 56 + 8 + num2);
						num6 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num16 * 56 + 16 + num2);
						if (num19 < num11 + num6)
						{
							if (num11 <= num19)
							{
								break;
							}
							num17 = num16 - 1;
						}
						else
						{
							num18 = num16 + 1;
						}
					}
					num7 = num16;
					num8 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num7 * 56 + 32 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num17 * 80 + 8 + num2);
						num19 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num17 * 80 + 24 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num5 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num7 * 80 + 40 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A85:
						if (array == null || (int)array[1] == 0)
						{
							num6 = num9;
							while (num6 != num20)
							{
								if (num6 != -1)
								{
									num6 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num6 + 8 + num2);
								}
								else
								{
									num11 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 32 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num20 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 8 + num2);
									goto IL_A85;
								}
							}
							goto IL_C1F;
						}
						int num21 = (int)array[4];
						int num22;
						if (num20 == -1)
						{
							num22 = -1;
						}
						else
						{
							num23 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 48 + num2);
							num19 = 0;
							num18 = 2;
							for (;;)
							{
								num17 = (num19 + num18) / 2;
								num16 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num17 * 80 + 8 + num2);
								num11 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num17 * 80 + 24 + num2);
								if (num23 < num16 + num11)
								{
									if (num16 <= num23)
									{
										break;
									}
									num18 = num17 - 1;
								}
								else
								{
									num19 = num17 + 1;
								}
							}
							num5 = num17;
							num7 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num5 * 80 + 40 + num2);
							num22 = num7;
						}
						if (num21 == num22)
						{
							num7 = num9;
							while (num7 != num20)
							{
								if (num7 != -1)
								{
									num7 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num7 + 8 + num2);
								}
								else
								{
									num5 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 32 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num20 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 8 + num2);
									goto IL_A85;
								}
							}
							break;
						}
						if ((int)array[4] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[2];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num5 + 64 + num2);
					array2 = new object[8];
					array2[1] = 0;
					array2[2] = array;
					array2[0] = num12;
					array2[4] = num5;
					array2[7] = 0;
					array = array2;
					num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num5 + 64 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C1F:
					num3 = num12;
					continue;
					Block_62:
					num16 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num11 + 64 + num2);
					array2 = new object[8];
					array2[1] = 0;
					array2[2] = array;
					array2[0] = num12;
					array2[4] = num11;
					array2[7] = 0;
					array = array2;
					num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num11 + 64 + num2);
				}
				num4 = 260;
				return;
				IL_1E2:
				if (num16 != -1)
				{
					goto IL_1ED;
				}
				goto IL_414;
				IL_1ED:
				num6 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num16 + 24 + num2);
				if (0 == num6)
				{
					goto IL_20C;
				}
				if (2 == num6)
				{
					goto IL_39B;
				}
				goto IL_414;
				IL_20C:
				num11 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num16 + 40 + num2);
				if (num11 == -1)
				{
					goto IL_25A;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_240;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_240:
				if (type.IsInstanceOfType(array2[5]))
				{
					goto IL_25A;
				}
				num16 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num16 + 16 + num2);
				goto IL_1E2;
				IL_25A:
				num20 = num16;
				num15 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 8 + num2) + 8 + num2);
				num7 = (int)array2[3];
				IL_27C:
				if (num7 != num15)
				{
					goto IL_2FB;
				}
				num17 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 64 + num2);
				ex3 = array2[5];
				array = (object[])array[2];
				object[] array5 = new object[8];
				array5[1] = 1;
				array5[2] = array;
				array5[5] = array2[5];
				array5[3] = (int)array2[3];
				array5[4] = num20;
				array5[7] = 2;
				array = array5;
				num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 64 + num2);
				goto IL_23;
				IL_2FB:
				num9 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num7 + 32 + num2);
				if (num9 == -1)
				{
					goto IL_38A;
				}
				num17 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num9 + 64 + num2);
				array = (object[])array[2];
				array5 = new object[8];
				array5[1] = 1;
				array5[2] = array;
				array5[5] = array2[5];
				array5[3] = (int)array2[3];
				array5[4] = num9;
				array5[6] = num20;
				array5[7] = 0;
				array = array5;
				num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num9 + 64 + num2);
				goto IL_23;
				IL_38A:
				num7 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num7 + 8 + num2);
				goto IL_27C;
				IL_39B:
				num17 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num16 + 48 + num2);
				ex3 = array2[5];
				array = (object[])array[2];
				array5 = new object[8];
				array5[1] = 1;
				array5[2] = array;
				array5[5] = array2[5];
				array5[3] = (int)array2[3];
				array5[4] = num16;
				array5[7] = 1;
				array = array5;
				num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num16 + 48 + num2);
				goto IL_23;
				IL_414:
				array = (object[])array[2];
				ex = array2[5];
				int num24 = (int)array2[3];
				IL_433:
				num16 = num3;
				num17 = num16;
				num18 = 0;
				num19 = 2;
				IL_441:
				num8 = (num18 + num19) / 2;
				num5 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num8 * 56 + 8 + num2);
				num23 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num8 * 56 + 16 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_486;
				}
				if (num5 > num17)
				{
					goto IL_48E;
				}
				num15 = num8;
				num20 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 128 + num15 * 56 + 32 + num2);
				num11 = num20;
				num7 = num11;
				goto IL_4B6;
				IL_486:
				num18 = num8 + 1;
				goto IL_441;
				IL_48E:
				num19 = num8 - 1;
				goto IL_441;
				IL_4B6:
				if (array != null)
				{
					goto IL_4C1;
				}
				goto IL_64E;
				IL_4C1:
				if ((int)array[1] != 0)
				{
					goto IL_580;
				}
				int num25 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_4E5;
				}
				int num26 = -1;
				goto IL_567;
				IL_4E5:
				int num27 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num11 + 48 + num2);
				num23 = 0;
				num5 = 2;
				IL_4F8:
				num8 = (num23 + num5) / 2;
				num19 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num8 * 80 + 8 + num2);
				num18 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num8 * 80 + 24 + num2);
				if (num27 >= num19 + num18)
				{
					goto IL_53D;
				}
				if (num19 > num27)
				{
					goto IL_545;
				}
				num20 = num8;
				num15 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num20 * 80 + 40 + num2);
				num26 = num15;
				goto IL_567;
				IL_53D:
				num23 = num8 + 1;
				goto IL_4F8;
				IL_545:
				num5 = num8 - 1;
				goto IL_4F8;
				IL_567:
				if (num25 != num26)
				{
					goto IL_56F;
				}
				goto IL_64E;
				IL_56F:
				array = (object[])array[2];
				goto IL_4B6;
				IL_580:
				num9 = (int)array[7];
				if (num9 == 2 || num9 == 0)
				{
					goto IL_5A1;
				}
				if (num9 != 1)
				{
					goto IL_5A0;
				}
				array2 = array;
				num16 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + (int)array2[4] + 16 + num2);
				goto IL_1E2;
				IL_5A0:
				IL_5A1:
				int num28 = (int)array[4];
				if (num11 != -1)
				{
					goto IL_5B6;
				}
				int num29 = -1;
				goto IL_638;
				IL_5B6:
				num17 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num11 + 48 + num2);
				num18 = 0;
				num19 = 2;
				IL_5C9:
				num8 = (num18 + num19) / 2;
				num5 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num8 * 80 + 8 + num2);
				num23 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num8 * 80 + 24 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_60E;
				}
				if (num5 > num17)
				{
					goto IL_616;
				}
				num15 = num8;
				num20 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + 296 + num15 * 80 + 40 + num2);
				num29 = num20;
				goto IL_638;
				IL_60E:
				num18 = num8 + 1;
				goto IL_5C9;
				IL_616:
				num19 = num8 - 1;
				goto IL_5C9;
				IL_638:
				if (num28 != num29)
				{
					goto IL_63D;
				}
				goto IL_64E;
				IL_63D:
				array = (object[])array[2];
				goto IL_4B6;
				IL_64E:
				if (-1 != num11)
				{
					goto IL_6F1;
				}
				num20 = num7;
				IL_65B:
				if (num20 != -1)
				{
					goto IL_667;
				}
				num10 = 1;
				throw ex;
				IL_667:
				num15 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 32 + num2);
				if (num15 == -1)
				{
					goto IL_6E0;
				}
				num27 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num15 + 64 + num2);
				array2 = new object[8];
				array2[1] = 1;
				array2[2] = array;
				array2[5] = ex;
				array2[3] = num7;
				array2[4] = -1;
				array2[6] = -1;
				array2[7] = 2;
				array = array2;
				num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num15 + 64 + num2);
				goto IL_23;
				IL_6E0:
				num20 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num20 + 8 + num2);
				goto IL_65B;
				IL_6F1:
				num6 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num11 + 16 + num2);
				num17 = num6;
				IL_702:
				if (num17 != -1)
				{
					goto IL_718;
				}
				num11 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num11 + 8 + num2);
				goto IL_4B6;
				IL_718:
				num19 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num17 + 24 + num2);
				if (0 == num19)
				{
					goto IL_742;
				}
				if (2 == num19)
				{
					goto IL_8AD;
				}
				num11 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num11 + 8 + num2);
				goto IL_4B6;
				IL_742:
				num18 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num17 + 40 + num2);
				if (num18 == -1)
				{
					goto IL_791;
				}
				Type type2;
				if ((type2 = array3[num18]) != null)
				{
					goto IL_776;
				}
				array3[num18] = Type.GetTypeFromHandle(array4[num18]);
				type2 = array3[num18];
				IL_776:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_791;
				}
				num17 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num17 + 16 + num2);
				goto IL_702;
				IL_791:
				num27 = num17;
				num23 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num27 + 8 + num2) + 8 + num2);
				num5 = (num7 - num24) * ((num24 == -1) ? 1 : 0) + num24;
				IL_7B8:
				if (num5 != num23)
				{
					goto IL_821;
				}
				int num30 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num27 + 64 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[1] = 1;
				array2[2] = array;
				array2[5] = ex;
				array2[3] = num7;
				array2[4] = num27;
				array2[7] = 2;
				array = array2;
				num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num27 + 64 + num2);
				goto IL_23;
				IL_821:
				num8 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num5 + 32 + num2);
				if (num8 == -1)
				{
					goto IL_89C;
				}
				num30 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num8 + 64 + num2);
				array2 = new object[8];
				array2[1] = 1;
				array2[2] = array;
				array2[5] = ex;
				array2[3] = num7;
				array2[4] = num8;
				array2[6] = num27;
				array2[7] = 0;
				array = array2;
				num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num8 + 64 + num2);
				goto IL_23;
				IL_89C:
				num5 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num5 + 8 + num2);
				goto IL_7B8;
				IL_8AD:
				num30 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num17 + 48 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[1] = 1;
				array2[2] = array;
				array2[5] = ex;
				array2[3] = num7;
				array2[4] = num17;
				array2[7] = 1;
				array = array2;
				num3 = *(ref IsGlobalTypeDefTokenEmptySet.TYPEFLAGFAGGREGATABLEDTDAttribute + num17 + 48 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num24 = -1;
					goto IL_433;
				}
				throw ex4;
			}
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x00033520 File Offset: 0x00031720
		private static void setActivityOptionsSerializedStreamHeader(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 132;
			A_0 = num;
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x00033588 File Offset: 0x00031788
		private static void DataCollectionStartgetOaepSHA(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x06000555 RID: 1365 RVA: 0x000335A0 File Offset: 0x000317A0
		private static void PublisherIdentityPermissionFileShare(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(GorillaTagger.Instance.offlineVRRig.head.rigTarget.gameObject);
			A_12 = orAddComponent;
			A_12.startWidth = 0.015f;
			A_12.endWidth = 0.015f;
			A_12.startColor = Color.red;
			A_12.endColor = Color.red;
			A_12.material.shader = Shader.Find("GUI/Text Shader");
			A_12.SetPosition(0, GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
			A_12.SetPosition(1, GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
			Object.Destroy(A_12, Time.deltaTime);
			int num = 0;
			A_13 = num;
			A_0 = 117;
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x00033718 File Offset: 0x00031918
		private static void SavePolicyIsolatedStorageScope(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			A_4.Dispose();
			A_1 = 3;
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x00033740 File Offset: 0x00031940
		private static void CMSHASHDIGESTMETHODMinusOne(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 166;
			A_0 = num;
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x000337A8 File Offset: 0x000319A8
		private static void StrongNameErrorInfoResourceManagerAddingCultureFromConfigFile(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(A_5.mainSkin.bones[Visual.bones[A_14]].gameObject);
			A_13 = orAddComponent;
			A_13.startWidth = 0.015f;
			A_13.endWidth = 0.015f;
			A_13.startColor = Color.green;
			A_13.endColor = Color.green;
			A_13.material.shader = Shader.Find("GUI/Text Shader");
			A_13.SetPosition(0, A_5.mainSkin.bones[Visual.bones[A_14]].position);
			A_13.SetPosition(1, A_5.mainSkin.bones[Visual.bones[A_14 + 1]].position);
			Object.Destroy(A_13, Time.deltaTime);
			int num = A_14 + 2;
			A_14 = num;
			bool flag = A_14 < Enumerable.Count<int>(Visual.bones);
			A_15 = flag;
			int num2 = (A_15 ? 1 : 0) * -2 + 93;
			A_0 = num2;
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x00033974 File Offset: 0x00031B74
		private static void ZeroFreeCoTaskMemAnsiCausalityRelation(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 215;
			A_0 = num;
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x000339BC File Offset: 0x00031BBC
		private static void ServerProcessingCheckAssertion(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 44;
			A_0 = num;
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x00033A04 File Offset: 0x00031C04
		private static void BuiltInMultiByte(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 199;
			A_0 = num;
		}

		// Token: 0x0600055C RID: 1372 RVA: 0x00033A6C File Offset: 0x00031C6C
		private static void NotOnCanceledBgeUn(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 59;
		}

		// Token: 0x0600055D RID: 1373 RVA: 0x00033AA8 File Offset: 0x00031CA8
		private static void UpgradeToWriterLocksetHandle(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			A_1 = 0;
		}

		// Token: 0x0600055E RID: 1374 RVA: 0x00033AC0 File Offset: 0x00031CC0
		private static void EventRegistrationTokenListWithCountIStoreBindingResultBoundVersion(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			A_1 = 0;
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x00033AD8 File Offset: 0x00031CD8
		private static void StartingCMSSECTIONIDCOMPATIBLEFRAMEWORKSSECTION(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			GameObject gameObject = new GameObject();
			A_31 = gameObject;
			LineRenderer lineRenderer = A_31.AddComponent<LineRenderer>();
			A_32 = lineRenderer;
			Vector3 position = A_5.transform.position;
			A_33 = position;
			Vector3[] array = new Vector3[5];
			A_34 = array;
			float num = 0.5f;
			A_35 = num;
			float num2 = 0.5f;
			A_36 = num2;
			LineRenderer lineRenderer2 = new GameObject().AddComponent<LineRenderer>();
			A_37 = lineRenderer2;
			A_37.transform.parent = A_31.transform;
			Vector3[] array2 = new Vector3[5];
			A_38 = array2;
			A_38[0] = A_33 + A_5.transform.right * (-A_36 / 2f - 0.02f) + A_5.transform.up * (A_35 / 2f + 0.02f);
			A_38[1] = A_33 + A_5.transform.right * (A_36 / 2f + 0.02f) + A_5.transform.up * (A_35 / 2f + 0.02f);
			A_38[2] = A_33 + A_5.transform.right * (A_36 / 2f + 0.02f) + A_5.transform.up * (-A_35 / 2f - 0.02f);
			A_38[3] = A_33 + A_5.transform.right * (-A_36 / 2f - 0.02f) + A_5.transform.up * (-A_35 / 2f - 0.02f);
			A_38[4] = A_38[0];
			A_37.positionCount = A_38.Length;
			A_37.SetPositions(A_38);
			A_37.startWidth = 0.015f;
			A_37.endWidth = 0.015f;
			Shader shader = Shader.Find("GUI/Text Shader");
			A_39 = shader;
			bool flag = A_39 != null;
			A_40 = flag;
			int num3 = ((!A_40) ? 1 : 0) * 1 + 72;
			A_0 = num3;
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x00033ED8 File Offset: 0x000320D8
		private static void GetHandleEncoderExceptionFallback(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 52;
			A_0 = num;
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x00033F48 File Offset: 0x00032148
		private static void UriAddrOfPinnedObject(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 48;
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x00033F84 File Offset: 0x00032184
		private static void DarkYellowGetOrderableDynamicPartitions(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 0;
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x00033F9C File Offset: 0x0003219C
		private static void getHasFlushedFinalBlockSTOREASSEMBLYSTATUSPAYLOADRESIDENT(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_10]].gameObject);
			A_9 = orAddComponent;
			A_9.startWidth = 0.015f;
			A_9.endWidth = 0.015f;
			A_9.startColor = Color.green;
			A_9.endColor = Color.green;
			A_9.material.shader = Shader.Find("GUI/Text Shader");
			A_9.SetPosition(0, GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_10]].position);
			A_9.SetPosition(1, GorillaTagger.Instance.offlineVRRig.mainSkin.bones[Visual.bones[A_10 + 1]].position);
			Object.Destroy(A_9, Time.deltaTime);
			int num = A_10 + 2;
			A_10 = num;
			bool flag = A_10 < Enumerable.Count<int>(Visual.bones);
			A_11 = flag;
			int num2 = (A_11 ? 1 : 0) * -2 + 114;
			A_0 = num2;
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x0003416C File Offset: 0x0003236C
		private static void UCOMIPersistFilePermitOnly(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_1 = 0;
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x00034184 File Offset: 0x00032384
		private static void getDaySingleUse(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			A_1 = 0;
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x0003419C File Offset: 0x0003239C
		private static void AccessRuleDYN(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 149;
			A_0 = num;
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x00034204 File Offset: 0x00032404
		private static void GetDecimalFUNCFLAGFRESTRICTED(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("fected");
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 1 + 137;
			A_0 = num;
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x00034284 File Offset: 0x00032484
		private static void asyncWaiterTokenDeviceClaimAttributes(ref int A_0, ref int A_1, ref int A_2)
		{
			QualitySettings.SetQualityLevel(0);
			A_1 = 0;
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x000342A8 File Offset: 0x000324A8
		public static void lowualyv2()
		{
			int num = 127;
			int num2 = 127;
			num2 = 127;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 127;
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x000342E0 File Offset: 0x000324E0
		private static void ToSerializedStringEnumByteTypeInfo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 179;
			A_0 = num;
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x0003433C File Offset: 0x0003253C
		public static void SeeNetworkTriggers()
		{
			int num = 275;
			int num2 = 275;
			num2 = 275;
			while (num2 != 0)
			{
				int num3;
				GameObject gameObject;
				int num4;
				Transform transform;
				GameObject gameObject2;
				float num5;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.GameObject&,System.Int32&,UnityEngine.Transform&,UnityEngine.GameObject&,System.Single&,System.Boolean&), ref num, ref num2, ref num3, ref gameObject, ref num4, ref transform, ref gameObject2, ref num5, ref flag, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 275;
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x0003438C File Offset: 0x0003258C
		private static void NestedTypeWriteInt(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 55;
			A_0 = num;
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x000343D4 File Offset: 0x000325D4
		private static void getInstanceCMSASSEMBLYREFERENCEFLAGOPTIONAL(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("fected");
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 4 + 90;
			A_0 = num;
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x00034454 File Offset: 0x00032654
		private static void CFBF(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 3;
			A_2 = 195;
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x00034478 File Offset: 0x00032678
		public static void Spammer()
		{
			int num = 229;
			int num2 = 229;
			num2 = 229;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				GameObject gameObject;
				Rigidbody rigidbody;
				TrailRenderer trailRenderer;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.Rigidbody&,UnityEngine.TrailRenderer&), ref num, ref num2, ref num3, ref flag, ref gameObject, ref rigidbody, ref trailRenderer, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 229;
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x000344C4 File Offset: 0x000326C4
		private static void IDispatchImplTypeComImportAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 143;
			A_0 = num;
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x0003450C File Offset: 0x0003270C
		private static void WindowsAccountNamegetUseUserOverride(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 219;
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x00034548 File Offset: 0x00032748
		private static void CLRInstanceIDgetPermissionSetName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_37.material.renderQueue = 3000;
			A_37.startColor = Color.red;
			A_37.endColor = Color.red;
			A_31.transform.position = A_5.transform.position;
			A_31.transform.LookAt(GorillaTagger.Instance.headCollider.transform);
			Object.Destroy(A_31, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -18 + 78;
			A_0 = num;
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x00034630 File Offset: 0x00032830
		private static void GetDeclaredMethodsdIIDIEnumSTORECATEGORYINSTANCE(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 143;
			A_0 = num;
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x00034678 File Offset: 0x00032878
		private static void KerbTicketLogonLPStruct(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 151;
			A_0 = num;
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x000346E8 File Offset: 0x000328E8
		public static void NoInfectionESP()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x0003471C File Offset: 0x0003291C
		private static void ArgumentOutOfRangeNeedNonNegNumAccessDenied(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			A_0 = 101;
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x00034734 File Offset: 0x00032934
		private static void GetOffsetgetStore(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(A_5.mainSkin.bones[Visual.bones[A_9]].gameObject);
			A_8 = orAddComponent;
			A_8.startWidth = 0.015f;
			A_8.endWidth = 0.015f;
			float num = 0f;
			A_10 = num;
			num = A_10 + Time.deltaTime;
			A_10 = num;
			A_8.startColor = Main.outlineColor;
			A_8.endColor = Main.outlineColor;
			A_8.material.shader = Shader.Find("GUI/Text Shader");
			A_8.SetPosition(0, A_5.mainSkin.bones[Visual.bones[A_9]].position);
			A_8.SetPosition(1, A_5.mainSkin.bones[Visual.bones[A_9 + 1]].position);
			Object.Destroy(A_8, Time.deltaTime);
			int num2 = A_9 + 2;
			A_9 = num2;
			bool flag = A_9 < Enumerable.Count<int>(Visual.bones);
			A_11 = flag;
			int num3 = (A_11 ? 1 : 0) * -2 + 88;
			A_0 = num3;
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x00034940 File Offset: 0x00032B40
		private static void IsServerGCAssemblyKeyNameAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 233;
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x0003497C File Offset: 0x00032B7C
		private static void LdcIDisableEvent(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 44;
			A_0 = num;
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x000349C4 File Offset: 0x00032BC4
		private static void TokenizerStreamNTAuthority(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_1 = 5;
			A_2 = 217;
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x000349E8 File Offset: 0x00032BE8
		private static void SuppressUnmanagedCodeSecurityAttributeToObject(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 197;
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x00034A24 File Offset: 0x00032C24
		private static void InstancesWaitingToRun(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			GameObject gameObject = GameObject.CreatePrimitive(0);
			A_7 = gameObject;
			A_7.transform.position = A_5.transform.position;
			Object.Destroy(A_7.GetComponent<BoxCollider>());
			A_7.transform.localScale = new Vector3(0.5f, 0.5f, 0.3f);
			A_7.transform.LookAt(Camera.main.transform.position);
			A_7.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_7.GetComponent<Renderer>().material.color = Main.outlineColor;
			Object.Destroy(A_7, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 215;
			A_0 = num;
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x00034B68 File Offset: 0x00032D68
		private static void ExchangegetFormat(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			GameObject gameObject = GameObject.CreatePrimitive(0);
			A_16 = gameObject;
			A_16.transform.position = A_5.rightHandTransform.position;
			A_16.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			A_16.GetComponent<Renderer>().material.color = Color.red;
			GameObject gameObject2 = GameObject.CreatePrimitive(0);
			A_17 = gameObject2;
			A_17.transform.position = A_5.leftHandTransform.position;
			A_17.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			A_17.GetComponent<Renderer>().material.color = Color.red;
			GameObject gameObject3 = GameObject.CreatePrimitive(0);
			A_18 = gameObject3;
			A_18.transform.position = A_5.headMesh.transform.position;
			A_18.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			A_18.GetComponent<Renderer>().material.color = Color.red;
			Object.Destroy(A_16, Time.deltaTime);
			Object.Destroy(A_17, Time.deltaTime);
			Object.Destroy(A_18, Time.deltaTime);
			A_16.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_17.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_18.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			Object.Destroy(A_16.GetComponent<MeshCollider>());
			Object.Destroy(A_16.GetComponent<Collider>());
			Object.Destroy(A_16.GetComponent<BoxCollider>());
			Object.Destroy(A_16.GetComponent<SphereCollider>());
			Object.Destroy(A_17.GetComponent<MeshCollider>());
			Object.Destroy(A_17.GetComponent<Collider>());
			Object.Destroy(A_17.GetComponent<BoxCollider>());
			Object.Destroy(A_17.GetComponent<SphereCollider>());
			Object.Destroy(A_18.GetComponent<MeshCollider>());
			Object.Destroy(A_18.GetComponent<Collider>());
			Object.Destroy(A_18.GetComponent<BoxCollider>());
			Object.Destroy(A_18.GetComponent<SphereCollider>());
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 44;
			A_0 = num;
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x00034EE4 File Offset: 0x000330E4
		private static void NetworkAsyncProcessMessage(ref int A_0, ref int A_1, ref int A_2, ref VRRig[] A_3, ref int A_4, ref VRRig A_5, ref GameObject A_6)
		{
			VRRig vrrig = A_3[A_4];
			A_5 = vrrig;
			GameObject gameObject = GameObject.CreatePrimitive(3);
			A_6 = gameObject;
			A_6.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_6.transform.position = A_5.transform.position;
			A_6.GetComponent<Collider>().enabled = false;
			Object.Destroy(A_6.GetComponent<Rigidbody>());
			Object.Destroy(A_6.GetComponent<Collider>());
			Object.Destroy(A_6, Time.deltaTime);
			A_6.transform.localScale = new Vector3(0.25f, 0.25f, 0.25f);
			A_6.GetComponent<Renderer>().material.color = Color.clear;
			int num = A_4 + 1;
			A_4 = num;
			int num2 = ((A_4 < A_3.Length) ? 1 : 0) * -2 + 125;
			A_0 = num2;
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x00035068 File Offset: 0x00033268
		private static void setCurrencySymbolgetCommand(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(GorillaTagger.Instance.offlineVRRig.head.rigTarget.gameObject);
			A_4 = orAddComponent;
			A_4.startWidth = 0.015f;
			A_4.endWidth = 0.015f;
			A_4.startColor = Main.outlineColor;
			A_4.endColor = Main.outlineColor;
			A_4.material.shader = Shader.Find("GUI/Text Shader");
			A_4.SetPosition(0, GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
			A_4.SetPosition(1, GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
			Object.Destroy(A_4, Time.deltaTime);
			int num = 0;
			A_5 = num;
			A_0 = 108;
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x000351E8 File Offset: 0x000333E8
		private static void PrepareConstrainedRegionsgetUseSalt(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 13 + 63;
			A_0 = num;
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x00035258 File Offset: 0x00033458
		private static void InvalidCastExceptionGetAccessors(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_0 = 214;
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x00035270 File Offset: 0x00033470
		private static void ScrollLockOnEnableDelegation(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 82;
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x000352AC File Offset: 0x000334AC
		private static void IsNotPublicLargestWindowHeight(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 250;
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x000352E8 File Offset: 0x000334E8
		private static void LocalActivatorOpenPunctuation(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			A_4.Dispose();
			A_1 = 5;
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x00035310 File Offset: 0x00033510
		private static void CreateLinkedTokenSourcegetLoaderOptimization(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			A_0 = 98;
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x00035328 File Offset: 0x00033528
		private static void ZeroIidParameterIndex(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 212;
			A_0 = num;
		}

		// Token: 0x06000587 RID: 1415 RVA: 0x00035398 File Offset: 0x00033598
		private static void getCookiegetPolicyStatement(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref LineRenderer A_4, ref int A_5, ref float A_6, ref bool A_7, ref bool A_8, ref LineRenderer A_9, ref int A_10, ref bool A_11, ref LineRenderer A_12, ref int A_13, ref bool A_14)
		{
			A_1 = 0;
		}

		// Token: 0x06000588 RID: 1416 RVA: 0x000353B0 File Offset: 0x000335B0
		private static void WindowsRuntimeResourceManagerBaseRequiredBit(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_0 = 159;
		}

		// Token: 0x06000589 RID: 1417 RVA: 0x000353C8 File Offset: 0x000335C8
		private static void NumberFormatInfogetParent(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			A_1 = 3;
			A_2 = 104;
		}

		// Token: 0x0600058A RID: 1418 RVA: 0x000353EC File Offset: 0x000335EC
		private static void ThreadTransferSendObjgetProviderName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			bool flag = !Visual.infectionESP;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 3 + 64;
			A_0 = num;
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x00035450 File Offset: 0x00033650
		public static void InfectionESP()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 0;
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x00035484 File Offset: 0x00033684
		private static void NoValuePropManifestError(ref int A_0, ref int A_1, ref int A_2, ref VRRig[] A_3, ref int A_4, ref VRRig A_5, ref GameObject A_6)
		{
			VRRig[] array = Object.FindObjectsOfType<VRRig>();
			A_3 = array;
			int num = 0;
			A_4 = num;
			A_0 = 124;
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x000354CC File Offset: 0x000336CC
		private static void NumberDecimalDigitsChineseEra(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(A_5.head.rigTarget.gameObject);
			A_13 = orAddComponent;
			A_13.startWidth = 0.015f;
			A_13.endWidth = 0.015f;
			A_13.startColor = Color.green;
			A_13.endColor = Color.green;
			A_13.material.shader = Shader.Find("GUI/Text Shader");
			A_13.SetPosition(0, A_5.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
			A_13.SetPosition(1, A_5.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
			Object.Destroy(A_13, Time.deltaTime);
			int num = 0;
			A_14 = num;
			A_0 = 92;
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x00035640 File Offset: 0x00033840
		private static void TimerCallbackgetChannelName(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 254;
			A_0 = num;
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x000356B0 File Offset: 0x000338B0
		private static void SetTypeSafeSerializationManager(ref int A_0, ref int A_1, ref int A_2)
		{
			QualitySettings.globalTextureMipmapLimit = 1;
			A_1 = 0;
		}

		// Token: 0x06000590 RID: 1424 RVA: 0x000356D4 File Offset: 0x000338D4
		public unsafe static void Breadcrumbs()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 146;
			int num4 = 146;
			num4 = 146;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 4)
					{
						num4 = 146;
						if ((int)array[4] != 1)
						{
							num5 = (int)array[2];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num5 + 48 + num2);
								num7 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + (int)array[6] + 48 + num2) + 32 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num7 + 56 + num2);
								if (num8 != -1)
								{
									num9 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num8 + 72 + num2);
									array[6] = num8;
									array[5] = 1;
									num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num8 + 72 + num2);
									goto IL_23;
								}
								num7 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num7 + 32 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[0];
							num9 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num5 + 72 + num2);
							ex3 = ex2;
							array = (object[])array[7];
							array2 = new object[]
							{
								default(object),
								default(object),
								default(object),
								default(object),
								0,
								default(object),
								default(object),
								array
							};
							array2[0] = ex2;
							array2[6] = num5;
							array2[5] = 0;
							array = array2;
							num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num5 + 72 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[3];
							array = (object[])array[7];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 2)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							bool flag3;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref flag3, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 146;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num16 * 80 + 40 + num2);
						num18 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num16 * 80 + 72 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num7 * 80 + 64 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num15 * 80 + 40 + num2);
						num6 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num15 * 80 + 72 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num7 * 80 + 64 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num16 * 80 + 40 + num2);
						num18 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num16 * 80 + 72 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num7 * 80 + 64 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A8A:
						if (array == null || (int)array[4] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num6 + 32 + num2);
								}
								else
								{
									num11 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 56 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 32 + num2);
									goto IL_A8A;
								}
							}
							goto IL_C28;
						}
						int num20 = (int)array[6];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 48 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num16 * 80 + 40 + num2);
								num11 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num16 * 80 + 72 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num5 * 80 + 64 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num7 + 32 + num2);
								}
								else
								{
									num5 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 56 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 32 + num2);
									goto IL_A8A;
								}
							}
							break;
						}
						if ((int)array[6] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[7];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num5 + 72 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						1,
						default(object),
						default(object),
						array
					};
					array2[3] = num12;
					array2[6] = num5;
					array2[5] = 1;
					array = array2;
					num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num5 + 72 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C28:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num11 + 72 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						default(object),
						default(object),
						1,
						default(object),
						default(object),
						array
					};
					array2[3] = num12;
					array2[6] = num11;
					array2[5] = 1;
					array = array2;
					num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num11 + 72 + num2);
				}
				num4 = 146;
				return;
				IL_1E4:
				if (num15 != -1)
				{
					goto IL_1EF;
				}
				goto IL_413;
				IL_1EF:
				num6 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num15 + 88 + num2);
				if (2 == num6)
				{
					goto IL_20E;
				}
				if (4 == num6)
				{
					goto IL_3A0;
				}
				goto IL_413;
				IL_20E:
				num11 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num15 + 96 + num2);
				if (num11 == -1)
				{
					goto IL_25C;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_242;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_242:
				if (type.IsInstanceOfType(array2[0]))
				{
					goto IL_25C;
				}
				num15 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num15 + 16 + num2);
				goto IL_1E4;
				IL_25C:
				num19 = num15;
				num14 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 48 + num2) + 32 + num2);
				num7 = (int)array2[1];
				IL_280:
				if (num7 != num14)
				{
					goto IL_2FF;
				}
				num16 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 72 + num2);
				ex3 = array2[0];
				array = (object[])array[7];
				object[] array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array5[0] = array2[0];
				array5[1] = (int)array2[1];
				array5[6] = num19;
				array5[5] = 0;
				array = array5;
				num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 72 + num2);
				goto IL_23;
				IL_2FF:
				num9 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num7 + 56 + num2);
				if (num9 == -1)
				{
					goto IL_38E;
				}
				num16 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num9 + 72 + num2);
				array = (object[])array[7];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array5[0] = array2[0];
				array5[1] = (int)array2[1];
				array5[6] = num9;
				array5[2] = num19;
				array5[5] = 1;
				array = array5;
				num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num9 + 72 + num2);
				goto IL_23;
				IL_38E:
				num7 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num7 + 32 + num2);
				goto IL_280;
				IL_3A0:
				num16 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num15 + num2);
				ex3 = array2[0];
				array = (object[])array[7];
				array5 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array5[0] = array2[0];
				array5[1] = (int)array2[1];
				array5[6] = num15;
				array5[5] = 2;
				array = array5;
				num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num15 + num2);
				goto IL_23;
				IL_413:
				array = (object[])array[7];
				ex = array2[0];
				int num23 = (int)array2[1];
				IL_432:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_440:
				num8 = (num17 + num18) / 2;
				num5 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num8 * 80 + 40 + num2);
				num22 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num8 * 80 + 72 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_486;
				}
				if (num5 > num16)
				{
					goto IL_48E;
				}
				num14 = num8;
				num19 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 176 + num14 * 80 + 64 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4B6;
				IL_486:
				num17 = num8 + 1;
				goto IL_440;
				IL_48E:
				num18 = num8 - 1;
				goto IL_440;
				IL_4B6:
				if (array != null)
				{
					goto IL_4C1;
				}
				goto IL_650;
				IL_4C1:
				if ((int)array[4] != 1)
				{
					goto IL_581;
				}
				int num24 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_4E5;
				}
				int num25 = -1;
				goto IL_568;
				IL_4E5:
				int num26 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num11 + 48 + num2);
				num22 = 0;
				num5 = 2;
				IL_4F8:
				num8 = (num22 + num5) / 2;
				num18 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num8 * 80 + 40 + num2);
				num17 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num8 * 80 + 72 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_53E;
				}
				if (num18 > num26)
				{
					goto IL_546;
				}
				num19 = num8;
				num14 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num19 * 80 + 64 + num2);
				num25 = num14;
				goto IL_568;
				IL_53E:
				num22 = num8 + 1;
				goto IL_4F8;
				IL_546:
				num5 = num8 - 1;
				goto IL_4F8;
				IL_568:
				if (num24 != num25)
				{
					goto IL_570;
				}
				goto IL_650;
				IL_570:
				array = (object[])array[7];
				goto IL_4B6;
				IL_581:
				num9 = (int)array[5];
				if (num9 == 0 || num9 == 1)
				{
					goto IL_5A2;
				}
				if (num9 != 2)
				{
					goto IL_5A1;
				}
				array2 = array;
				num15 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + (int)array2[6] + 16 + num2);
				goto IL_1E4;
				IL_5A1:
				IL_5A2:
				int num27 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_5B7;
				}
				int num28 = -1;
				goto IL_63A;
				IL_5B7:
				num16 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num11 + 48 + num2);
				num17 = 0;
				num18 = 2;
				IL_5CA:
				num8 = (num17 + num18) / 2;
				num5 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num8 * 80 + 40 + num2);
				num22 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num8 * 80 + 72 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_610;
				}
				if (num5 > num16)
				{
					goto IL_618;
				}
				num14 = num8;
				num19 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + 416 + num14 * 80 + 64 + num2);
				num28 = num19;
				goto IL_63A;
				IL_610:
				num17 = num8 + 1;
				goto IL_5CA;
				IL_618:
				num18 = num8 - 1;
				goto IL_5CA;
				IL_63A:
				if (num27 != num28)
				{
					goto IL_63F;
				}
				goto IL_650;
				IL_63F:
				array = (object[])array[7];
				goto IL_4B6;
				IL_650:
				if (-1 != num11)
				{
					goto IL_6F4;
				}
				num19 = num7;
				IL_65D:
				if (num19 != -1)
				{
					goto IL_669;
				}
				num10 = 1;
				throw ex;
				IL_669:
				num14 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 56 + num2);
				if (num14 == -1)
				{
					goto IL_6E2;
				}
				num26 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num14 + 72 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[0] = ex;
				array2[1] = num7;
				array2[6] = -1;
				array2[2] = -1;
				array2[5] = 0;
				array = array2;
				num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num14 + 72 + num2);
				goto IL_23;
				IL_6E2:
				num19 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num19 + 32 + num2);
				goto IL_65D;
				IL_6F4:
				num6 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num11 + 64 + num2);
				num16 = num6;
				IL_705:
				if (num16 != -1)
				{
					goto IL_71C;
				}
				num11 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num11 + 32 + num2);
				goto IL_4B6;
				IL_71C:
				num18 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num16 + 88 + num2);
				if (2 == num18)
				{
					goto IL_747;
				}
				if (4 == num18)
				{
					goto IL_8B5;
				}
				num11 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num11 + 32 + num2);
				goto IL_4B6;
				IL_747:
				num17 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num16 + 96 + num2);
				if (num17 == -1)
				{
					goto IL_796;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_77B;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_77B:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_796;
				}
				num16 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num16 + 16 + num2);
				goto IL_705;
				IL_796:
				num26 = num16;
				num22 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num26 + 48 + num2) + 32 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7BF:
				if (num5 != num22)
				{
					goto IL_828;
				}
				int num29 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num26 + 72 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[0] = ex;
				array2[1] = num7;
				array2[6] = num26;
				array2[5] = 0;
				array = array2;
				num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num26 + 72 + num2);
				goto IL_23;
				IL_828:
				num8 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num5 + 56 + num2);
				if (num8 == -1)
				{
					goto IL_8A3;
				}
				num29 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num8 + 72 + num2);
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[0] = ex;
				array2[1] = num7;
				array2[6] = num8;
				array2[2] = num26;
				array2[5] = 1;
				array = array2;
				num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num8 + 72 + num2);
				goto IL_23;
				IL_8A3:
				num5 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num5 + 32 + num2);
				goto IL_7BF;
				IL_8B5:
				num29 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num16 + num2);
				ex3 = ex;
				array2 = new object[]
				{
					default(object),
					default(object),
					default(object),
					default(object),
					0,
					default(object),
					default(object),
					array
				};
				array2[0] = ex;
				array2[1] = num7;
				array2[6] = num16;
				array2[5] = 2;
				array = array2;
				num3 = *(ref getHostDllHour.ICustomDebuggerNotificationgetRuleSet + num16 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_432;
				}
				throw ex4;
			}
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x000363C4 File Offset: 0x000345C4
		private static void FieldTypeGetSafeWaitHandle(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			A_0 = 267;
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x000363DC File Offset: 0x000345DC
		private static void ByValArrayCharUnicodeInfo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 16;
			A_0 = num;
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x00036424 File Offset: 0x00034624
		private static void EndNoGCRegionStatusDateTimeConstantAttribute(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			GameObject gameObject = new GameObject("Line");
			A_8 = gameObject;
			A_8.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			LineRenderer lineRenderer = A_8.AddComponent<LineRenderer>();
			A_9 = lineRenderer;
			A_9.SetPosition(0, GorillaTagger.Instance.offlineVRRig.rightHandTransform.position);
			A_9.SetPosition(1, A_5.transform.position);
			A_9.startWidth = 0.015f;
			A_9.endWidth = 0.015f;
			A_9.material.shader = Shader.Find("GUI/Text Shader");
			float num = 0f;
			A_10 = num;
			num = A_10 + Time.deltaTime;
			A_10 = num;
			A_9.material.color = Main.outlineColor;
			Object.Destroy(A_8, Time.deltaTime);
			A_0 = 243;
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0003659C File Offset: 0x0003479C
		private static void IsHomogenousSendCommand(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref int A_4, ref Transform A_5, ref GameObject A_6, ref float A_7, ref bool A_8)
		{
			bool flag = A_4 < A_3.transform.childCount;
			A_8 = flag;
			int num = (A_8 ? 1 : 0) * -2 + 278;
			A_0 = num;
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x00036610 File Offset: 0x00034810
		public static void BoneESPSelf()
		{
			int num = 105;
			int num2 = 105;
			num2 = 105;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				LineRenderer lineRenderer;
				int num4;
				float num5;
				bool flag2;
				bool flag3;
				LineRenderer lineRenderer2;
				int num6;
				bool flag4;
				LineRenderer lineRenderer3;
				int num7;
				bool flag5;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,UnityEngine.LineRenderer&,System.Int32&,System.Single&,System.Boolean&,System.Boolean&,UnityEngine.LineRenderer&,System.Int32&,System.Boolean&,UnityEngine.LineRenderer&,System.Int32&,System.Boolean&), ref num, ref num2, ref num3, ref flag, ref lineRenderer, ref num4, ref num5, ref flag2, ref flag3, ref lineRenderer2, ref num6, ref flag4, ref lineRenderer3, ref num7, ref flag5, Visual.ISOCurrencySymbolRemotingAssert[num]);
			}
			num2 = 105;
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x00036660 File Offset: 0x00034860
		private static void CustomErrorsEntryControlPrincipal(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			Visual.trail = ComponentUtils.AddComponent<TrailRenderer>(A_5);
			Visual.trail.startColor = Color.red;
			Visual.trail.endColor = Color.red;
			Visual.trail.startWidth = 0.05f;
			Visual.trail.endWidth = 0f;
			Visual.trail.minVertexDistance = 0.05f;
			Visual.trail.material.shader = Shader.Find("GUI/Text Shader");
			Visual.trail.time = 2f;
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 160;
			A_0 = num;
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x00036738 File Offset: 0x00034938
		private static void setSecurityZoneLocalVariableInfo(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -19 + 102;
			A_0 = num;
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x00036780 File Offset: 0x00034980
		private static void ValidKeySizeDXNN(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			bool flag = !Visual.infectionESP;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 238;
			A_0 = num;
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x000367E4 File Offset: 0x000349E4
		private static void IsPrefixExecuteAssembly(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_0 = 181;
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x000367FC File Offset: 0x000349FC
		private static void CallTypeIProgress(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			GameObject gameObject = GameObject.CreatePrimitive(1);
			A_7 = gameObject;
			A_7.transform.position = A_5.transform.position;
			Object.Destroy(A_7.GetComponent<CapsuleCollider>());
			A_7.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
			A_7.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			A_7.GetComponent<Renderer>().material.color = Main.outlineColor;
			Object.Destroy(A_7, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 204;
			A_0 = num;
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x0003691C File Offset: 0x00034B1C
		private static void GetRegistrableTypesInAssemblyInterfaceIsIDispatch(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			GameObject gameObject = new GameObject("Line");
			A_14 = gameObject;
			A_14.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
			LineRenderer lineRenderer = A_14.AddComponent<LineRenderer>();
			A_15 = lineRenderer;
			A_15.SetPosition(0, A_5.transform.position + new Vector3(0f, 9999f, 0f));
			A_15.SetPosition(1, A_5.transform.position - new Vector3(0f, 9999f, 0f));
			A_15.startWidth = 0.015f;
			A_15.endWidth = 0.015f;
			A_15.material.shader = Shader.Find("GUI/Text Shader");
			A_15.material.color = Color.red;
			Object.Destroy(A_14, Time.deltaTime);
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 143;
			A_0 = num;
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x00036ABC File Offset: 0x00034CBC
		private static void StoreListValidmhandle(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref LineRenderer A_8, ref int A_9, ref float A_10, ref bool A_11, ref bool A_12, ref LineRenderer A_13, ref int A_14, ref bool A_15, ref LineRenderer A_16, ref int A_17, ref bool A_18)
		{
			bool flag = !Visual.infectionESP;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 4 + 85;
			A_0 = num;
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x00036B20 File Offset: 0x00034D20
		private static void CharUnknownSerializationMonkey(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			List<VRRig>.Enumerator enumerator = GorillaParent.instance.vrrigs.GetEnumerator();
			A_4 = enumerator;
			A_0 = 147;
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x00036B5C File Offset: 0x00034D5C
		private static void ReadFromUnderlyingStreamAsyncdTYPEFLAGFOLEAUTOMATION(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !Visual.infectionESP;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 152;
			A_0 = num;
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x00036BC0 File Offset: 0x00034DC0
		private static void SetCompressedStackgetPercentPositivePattern(ref int A_0, ref int A_1, ref int A_2)
		{
			QualitySettings.globalTextureMipmapLimit = 999999999;
			A_1 = 0;
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x00036BE4 File Offset: 0x00034DE4
		private static void GetEnvironmentVariableSEPDateOrOffset(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			GameObject gameObject = new GameObject("Line");
			A_12 = gameObject;
			A_12.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			LineRenderer lineRenderer = A_12.AddComponent<LineRenderer>();
			A_13 = lineRenderer;
			A_13.SetPosition(0, GorillaTagger.Instance.offlineVRRig.rightHandTransform.position);
			A_13.SetPosition(1, A_5.transform.position);
			A_13.startWidth = 0.015f;
			A_13.endWidth = 0.015f;
			A_13.material.shader = Shader.Find("GUI/Text Shader");
			A_13.material.color = Color.green;
			Object.Destroy(A_12, Time.deltaTime);
			A_0 = 242;
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x00036D24 File Offset: 0x00034F24
		private static void BindableIterableToEnumerableAdapterIsNestedPublic(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref float A_8, ref GameObject A_9, ref GameObject A_10, ref GameObject A_11, ref bool A_12, ref GameObject A_13, ref GameObject A_14, ref GameObject A_15, ref GameObject A_16, ref GameObject A_17, ref GameObject A_18)
		{
			A_0 = 43;
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x00036D3C File Offset: 0x00034F3C
		private static void CompletionAsynchronous(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			A_1 = 0;
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x00036D54 File Offset: 0x00034F54
		private static void EncoderReplacementFallbackgetFirstDayOfWeek(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("fected");
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 10;
			A_0 = num;
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x00036DD4 File Offset: 0x00034FD4
		private static void EventHandleTaskCanceledException(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref Vector3 A_10, ref float A_11, ref Vector3[] A_12, ref float A_13, ref float A_14, ref LineRenderer A_15, ref Vector3[] A_16, ref Shader A_17, ref bool A_18, ref float A_19, ref bool A_20, ref GameObject A_21, ref LineRenderer A_22, ref Vector3 A_23, ref Vector3[] A_24, ref float A_25, ref float A_26, ref LineRenderer A_27, ref Vector3[] A_28, ref Shader A_29, ref bool A_30, ref GameObject A_31, ref LineRenderer A_32, ref Vector3 A_33, ref Vector3[] A_34, ref float A_35, ref float A_36, ref LineRenderer A_37, ref Vector3[] A_38, ref Shader A_39, ref bool A_40)
		{
			A_0 = 77;
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x00036DEC File Offset: 0x00034FEC
		private static void YearEndSkipVisibilityChecks(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 254;
			A_0 = num;
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x00036E48 File Offset: 0x00035048
		private static void TimeZoneGetOtherMethods(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 226;
			A_0 = num;
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x00036E90 File Offset: 0x00035090
		private static void IsCompletedEncodingProvider(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 168;
			A_0 = num;
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x00036EEC File Offset: 0x000350EC
		private static void PadLeftgetPercentGroupSeparator(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref GameObject A_8, ref LineRenderer A_9, ref float A_10, ref bool A_11, ref GameObject A_12, ref LineRenderer A_13, ref GameObject A_14, ref LineRenderer A_15)
		{
			bool flag = !A_5.isMyPlayer;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 7 + 134;
			A_0 = num;
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x00036F5C File Offset: 0x0003515C
		private static void CreateDefinitionVariantType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			A_5.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
			A_5.mainSkin.material.color = Main.outlineColor;
			A_0 = 13;
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x00036FBC File Offset: 0x000351BC
		private static void TokenTypeInfrastructure(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref int A_7, ref Player A_8, ref GameObject A_9, ref TextMeshPro A_10, ref Transform A_11)
		{
			A_1 = 4;
			A_2 = 29;
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x00036FE0 File Offset: 0x000351E0
		private static void ImageFileMachineSin(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			A_4.Dispose();
			A_1 = 3;
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00037008 File Offset: 0x00035208
		private static void getLengthArraySegmentEnumerator(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7, ref LineRenderer A_8, ref float A_9)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -6 + 268;
			A_0 = num;
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x00037050 File Offset: 0x00035250
		private static void RectactionsCopy(ref int A_0, ref int A_1, ref int A_2, ref VRRig[] A_3, ref int A_4, ref VRRig A_5, ref GameObject A_6)
		{
			int num = ((A_4 < A_3.Length) ? 1 : 0) * -2 + 125;
			A_0 = num;
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x0003708C File Offset: 0x0003528C
		private static void BgtUnSInternalActivationContextHelper(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_4.MoveNext() ? 1 : 0) * -12 + 160;
			A_0 = num;
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x000370D4 File Offset: 0x000352D4
		public unsafe static void Beacons()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 129;
			int num4 = 129;
			num4 = 129;
			try
			{
				IL_23:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num20;
				int num23;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 3)
					{
						num4 = 129;
						if ((int)array[2] != 0)
						{
							num5 = (int)array[5];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num5 + 24 + num2);
								num7 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + (int)array[1] + 24 + num2) + 16 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num7 + 8 + num2);
								if (num8 != -1)
								{
									num9 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num8 + 32 + num2);
									array[1] = num8;
									array[3] = 0;
									num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num8 + 32 + num2);
									goto IL_23;
								}
								num7 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num7 + 16 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[0];
							num9 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num5 + 32 + num2);
							ex3 = ex2;
							array = (object[])array[6];
							array2 = new object[8];
							array2[2] = 1;
							array2[6] = array;
							array2[0] = ex2;
							array2[1] = num5;
							array2[3] = 1;
							array = array2;
							num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num5 + 32 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[7];
							array = (object[])array[6];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							List<VRRig>.Enumerator enumerator;
							VRRig vrrig;
							bool flag;
							bool flag2;
							GameObject gameObject;
							LineRenderer lineRenderer;
							float num14;
							bool flag3;
							GameObject gameObject2;
							LineRenderer lineRenderer2;
							GameObject gameObject3;
							LineRenderer lineRenderer3;
							calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1/Enumerator<VRRig>&,VRRig&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,System.Single&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,UnityEngine.GameObject&,UnityEngine.LineRenderer&), ref num3, ref num4, ref num13, ex3, ref enumerator, ref vrrig, ref flag, ref flag2, ref gameObject, ref lineRenderer, ref num14, ref flag3, ref gameObject2, ref lineRenderer2, ref gameObject3, ref lineRenderer3, Visual.ISOCurrencySymbolRemotingAssert[num3]);
							continue;
						}
						num4 = 129;
						num8 = num13;
						num12 = num8;
					}
					num15 = num3;
					num6 = num15;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num17 * 48 + 8 + num2);
						num19 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num17 * 48 + 32 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num9 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num7 * 48 + 16 + num2);
					num20 = num9;
					num19 = num12;
					num18 = 0;
					num17 = 2;
					for (;;)
					{
						num16 = (num18 + num17) / 2;
						num11 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num16 * 48 + 8 + num2);
						num6 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num16 * 48 + 32 + num2);
						if (num19 < num11 + num6)
						{
							if (num11 <= num19)
							{
								break;
							}
							num17 = num16 - 1;
						}
						else
						{
							num18 = num16 + 1;
						}
					}
					num7 = num16;
					num8 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num7 * 48 + 16 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num16 = 2;
					for (;;)
					{
						num17 = (num11 + num16) / 2;
						num18 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num17 * 48 + 8 + num2);
						num19 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num17 * 48 + 32 + num2);
						if (num6 < num18 + num19)
						{
							if (num18 <= num6)
							{
								break;
							}
							num16 = num17 - 1;
						}
						else
						{
							num11 = num17 + 1;
						}
					}
					num7 = num17;
					num5 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num7 * 48 + 16 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A85:
						if (array == null || (int)array[2] == 0)
						{
							num6 = num9;
							while (num6 != num20)
							{
								if (num6 != -1)
								{
									num6 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num6 + 16 + num2);
								}
								else
								{
									num11 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 8 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num20 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 16 + num2);
									goto IL_A85;
								}
							}
							goto IL_C1E;
						}
						int num21 = (int)array[1];
						int num22;
						if (num20 == -1)
						{
							num22 = -1;
						}
						else
						{
							num23 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + num2);
							num19 = 0;
							num18 = 2;
							for (;;)
							{
								num17 = (num19 + num18) / 2;
								num16 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num17 * 48 + 8 + num2);
								num11 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num17 * 48 + 32 + num2);
								if (num23 < num16 + num11)
								{
									if (num16 <= num23)
									{
										break;
									}
									num18 = num17 - 1;
								}
								else
								{
									num19 = num17 + 1;
								}
							}
							num5 = num17;
							num7 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num5 * 48 + 16 + num2);
							num22 = num7;
						}
						if (num21 == num22)
						{
							num7 = num9;
							while (num7 != num20)
							{
								if (num7 != -1)
								{
									num7 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num7 + 16 + num2);
								}
								else
								{
									num5 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 8 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num20 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 16 + num2);
									goto IL_A85;
								}
							}
							break;
						}
						if ((int)array[1] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[6];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num5 + 32 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						0,
						default(object),
						default(object),
						default(object),
						array,
						num12
					};
					array2[1] = num5;
					array2[3] = 0;
					array = array2;
					num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num5 + 32 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C1E:
					num3 = num12;
					continue;
					Block_62:
					num16 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num11 + 32 + num2);
					array2 = new object[]
					{
						default(object),
						default(object),
						0,
						default(object),
						default(object),
						default(object),
						array,
						num12
					};
					array2[1] = num11;
					array2[3] = 0;
					array = array2;
					num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num11 + 32 + num2);
				}
				num4 = 129;
				return;
				IL_1F0:
				if (num16 != -1)
				{
					goto IL_1FB;
				}
				goto IL_41D;
				IL_1FB:
				num6 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num16 + 72 + num2);
				if (1 == num6)
				{
					goto IL_21A;
				}
				if (4 == num6)
				{
					goto IL_3AA;
				}
				goto IL_41D;
				IL_21A:
				num11 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num16 + 16 + num2);
				if (num11 == -1)
				{
					goto IL_267;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_24E;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_24E:
				if (type.IsInstanceOfType(array2[0]))
				{
					goto IL_267;
				}
				num16 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num16 + 8 + num2);
				goto IL_1F0;
				IL_267:
				num20 = num16;
				num15 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 24 + num2) + 16 + num2);
				num7 = (int)array2[4];
				IL_28B:
				if (num7 != num15)
				{
					goto IL_30A;
				}
				num17 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 32 + num2);
				ex3 = array2[0];
				array = (object[])array[6];
				object[] array5 = new object[8];
				array5[2] = 1;
				array5[6] = array;
				array5[0] = array2[0];
				array5[4] = (int)array2[4];
				array5[1] = num20;
				array5[3] = 1;
				array = array5;
				num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 32 + num2);
				goto IL_23;
				IL_30A:
				num9 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num7 + 8 + num2);
				if (num9 == -1)
				{
					goto IL_398;
				}
				num17 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num9 + 32 + num2);
				array = (object[])array[6];
				array5 = new object[8];
				array5[2] = 1;
				array5[6] = array;
				array5[0] = array2[0];
				array5[4] = (int)array2[4];
				array5[1] = num9;
				array5[5] = num20;
				array5[3] = 0;
				array = array5;
				num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num9 + 32 + num2);
				goto IL_23;
				IL_398:
				num7 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num7 + 16 + num2);
				goto IL_28B;
				IL_3AA:
				num17 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num16 + num2);
				ex3 = array2[0];
				array = (object[])array[6];
				array5 = new object[8];
				array5[2] = 1;
				array5[6] = array;
				array5[0] = array2[0];
				array5[4] = (int)array2[4];
				array5[1] = num16;
				array5[3] = 2;
				array = array5;
				num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num16 + num2);
				goto IL_23;
				IL_41D:
				array = (object[])array[6];
				ex = array2[0];
				int num24 = (int)array2[4];
				IL_43C:
				num16 = num3;
				num17 = num16;
				num18 = 0;
				num19 = 2;
				IL_44A:
				num8 = (num18 + num19) / 2;
				num5 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num8 * 48 + 8 + num2);
				num23 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num8 * 48 + 32 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_48F;
				}
				if (num5 > num17)
				{
					goto IL_497;
				}
				num15 = num8;
				num20 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 152 + num15 * 48 + 16 + num2);
				num11 = num20;
				num7 = num11;
				goto IL_4BF;
				IL_48F:
				num18 = num8 + 1;
				goto IL_44A;
				IL_497:
				num19 = num8 - 1;
				goto IL_44A;
				IL_4BF:
				if (array != null)
				{
					goto IL_4CA;
				}
				goto IL_651;
				IL_4CA:
				if ((int)array[2] != 0)
				{
					goto IL_586;
				}
				int num25 = (int)array[1];
				if (num11 != -1)
				{
					goto IL_4EE;
				}
				int num26 = -1;
				goto IL_56D;
				IL_4EE:
				int num27 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num11 + num2);
				num23 = 0;
				num5 = 2;
				IL_4FE:
				num8 = (num23 + num5) / 2;
				num19 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num8 * 48 + 8 + num2);
				num18 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num8 * 48 + 32 + num2);
				if (num27 >= num19 + num18)
				{
					goto IL_543;
				}
				if (num19 > num27)
				{
					goto IL_54B;
				}
				num20 = num8;
				num15 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num20 * 48 + 16 + num2);
				num26 = num15;
				goto IL_56D;
				IL_543:
				num23 = num8 + 1;
				goto IL_4FE;
				IL_54B:
				num5 = num8 - 1;
				goto IL_4FE;
				IL_56D:
				if (num25 != num26)
				{
					goto IL_575;
				}
				goto IL_651;
				IL_575:
				array = (object[])array[6];
				goto IL_4BF;
				IL_586:
				num9 = (int)array[3];
				if (num9 == 1 || num9 == 0)
				{
					goto IL_5A7;
				}
				if (num9 != 2)
				{
					goto IL_5A6;
				}
				array2 = array;
				num16 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + (int)array2[1] + 8 + num2);
				goto IL_1F0;
				IL_5A6:
				IL_5A7:
				int num28 = (int)array[1];
				if (num11 != -1)
				{
					goto IL_5BC;
				}
				int num29 = -1;
				goto IL_63B;
				IL_5BC:
				num17 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num11 + num2);
				num18 = 0;
				num19 = 2;
				IL_5CC:
				num8 = (num18 + num19) / 2;
				num5 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num8 * 48 + 8 + num2);
				num23 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num8 * 48 + 32 + num2);
				if (num17 >= num5 + num23)
				{
					goto IL_611;
				}
				if (num5 > num17)
				{
					goto IL_619;
				}
				num15 = num8;
				num20 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + 296 + num15 * 48 + 16 + num2);
				num29 = num20;
				goto IL_63B;
				IL_611:
				num18 = num8 + 1;
				goto IL_5CC;
				IL_619:
				num19 = num8 - 1;
				goto IL_5CC;
				IL_63B:
				if (num28 != num29)
				{
					goto IL_640;
				}
				goto IL_651;
				IL_640:
				array = (object[])array[6];
				goto IL_4BF;
				IL_651:
				if (-1 != num11)
				{
					goto IL_6F4;
				}
				num20 = num7;
				IL_65E:
				if (num20 != -1)
				{
					goto IL_66A;
				}
				num10 = 1;
				throw ex;
				IL_66A:
				num15 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 8 + num2);
				if (num15 == -1)
				{
					goto IL_6E2;
				}
				num27 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num15 + 32 + num2);
				array2 = new object[8];
				array2[2] = 1;
				array2[6] = array;
				array2[0] = ex;
				array2[4] = num7;
				array2[1] = -1;
				array2[5] = -1;
				array2[3] = 1;
				array = array2;
				num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num15 + 32 + num2);
				goto IL_23;
				IL_6E2:
				num20 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num20 + 16 + num2);
				goto IL_65E;
				IL_6F4:
				num6 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num11 + 40 + num2);
				num17 = num6;
				IL_705:
				if (num17 != -1)
				{
					goto IL_71C;
				}
				num11 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num11 + 16 + num2);
				goto IL_4BF;
				IL_71C:
				num19 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num17 + 72 + num2);
				if (1 == num19)
				{
					goto IL_747;
				}
				if (4 == num19)
				{
					goto IL_8B3;
				}
				num11 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num11 + 16 + num2);
				goto IL_4BF;
				IL_747:
				num18 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num17 + 16 + num2);
				if (num18 == -1)
				{
					goto IL_795;
				}
				Type type2;
				if ((type2 = array3[num18]) != null)
				{
					goto IL_77B;
				}
				array3[num18] = Type.GetTypeFromHandle(array4[num18]);
				type2 = array3[num18];
				IL_77B:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_795;
				}
				num17 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num17 + 8 + num2);
				goto IL_705;
				IL_795:
				num27 = num17;
				num23 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num27 + 24 + num2) + 16 + num2);
				num5 = (num7 - num24) * ((num24 == -1) ? 1 : 0) + num24;
				IL_7BE:
				if (num5 != num23)
				{
					goto IL_827;
				}
				int num30 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num27 + 32 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[2] = 1;
				array2[6] = array;
				array2[0] = ex;
				array2[4] = num7;
				array2[1] = num27;
				array2[3] = 1;
				array = array2;
				num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num27 + 32 + num2);
				goto IL_23;
				IL_827:
				num8 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num5 + 8 + num2);
				if (num8 == -1)
				{
					goto IL_8A1;
				}
				num30 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num8 + 32 + num2);
				array2 = new object[8];
				array2[2] = 1;
				array2[6] = array;
				array2[0] = ex;
				array2[4] = num7;
				array2[1] = num8;
				array2[5] = num27;
				array2[3] = 0;
				array = array2;
				num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num8 + 32 + num2);
				goto IL_23;
				IL_8A1:
				num5 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num5 + 16 + num2);
				goto IL_7BE;
				IL_8B3:
				num30 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num17 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[2] = 1;
				array2[6] = array;
				array2[0] = ex;
				array2[4] = num7;
				array2[1] = num17;
				array2[3] = 2;
				array = array2;
				num3 = *(ref GetFunctionPointergetIsInitOnly.getMonthDayPatternFalseString + num17 + num2);
				goto IL_23;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num24 = -1;
					goto IL_43C;
				}
				throw ex4;
			}
		}

		// Token: 0x060005B0 RID: 1456 RVA: 0x00037DB8 File Offset: 0x00035FB8
		private static void ModuleVersionIdComposedOfNoStaticMembers(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref GameObject A_7)
		{
			VRRig vrrig = A_4.Current;
			A_5 = vrrig;
			int num = (A_5.isOfflineVRRig ? 1 : 0) * 1 + 221;
			A_0 = num;
		}

		// Token: 0x060005B1 RID: 1457 RVA: 0x00037E20 File Offset: 0x00036020
		private static void SuccessfulAccessTotalHours(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<VRRig>.Enumerator A_4, ref VRRig A_5, ref bool A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = !A_5.mainSkin.material.name.Contains("fected");
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 1 + 154;
			A_0 = num;
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x00037EA0 File Offset: 0x000360A0
		private static void fAnonymousTypesetWindowHeight()
		{
			Visual.ISOCurrencySymbolRemotingAssert = new IntPtr[281];
			Visual.ISOCurrencySymbolRemotingAssert[0] = ldftn(getAllFilesEverything);
			Visual.ISOCurrencySymbolRemotingAssert[1] = ldftn(ContinuationTaskCopyToAsync);
			Visual.ISOCurrencySymbolRemotingAssert[2] = ldftn(IAsyncStateMachineAdd);
			Visual.ISOCurrencySymbolRemotingAssert[3] = ldftn(getAssemblyIsPrivateEtwSelfDescribingEventFormat);
			Visual.ISOCurrencySymbolRemotingAssert[4] = ldftn(TraceSynchronousWorkCMSHASHTRANSFORM);
			Visual.ISOCurrencySymbolRemotingAssert[5] = ldftn(cParamsOptAsyncCausalityOperation);
			Visual.ISOCurrencySymbolRemotingAssert[6] = ldftn(ISOCurrencySymbolCdsSyncEtwBCLProvider);
			Visual.ISOCurrencySymbolRemotingAssert[7] = ldftn(ManifestPathUninstallOthers);
			Visual.ISOCurrencySymbolRemotingAssert[8] = ldftn(CreateDefinitionVariantType);
			Visual.ISOCurrencySymbolRemotingAssert[9] = ldftn(EncoderReplacementFallbackgetFirstDayOfWeek);
			Visual.ISOCurrencySymbolRemotingAssert[10] = ldftn(GetXsdTypeIsFixedDateRule);
			Visual.ISOCurrencySymbolRemotingAssert[11] = ldftn(CurrentDirectoryStringToHString);
			Visual.ISOCurrencySymbolRemotingAssert[12] = ldftn(NoValuePropTryUpdate);
			Visual.ISOCurrencySymbolRemotingAssert[13] = ldftn(ByValArrayCharUnicodeInfo);
			Visual.ISOCurrencySymbolRemotingAssert[14] = ldftn(TypeRepresentsComTypeUnmanagedMemoryStream);
			Visual.ISOCurrencySymbolRemotingAssert[15] = ldftn(SingleProducerSingleConsumerQueueDefaultEncoder);
			Visual.ISOCurrencySymbolRemotingAssert[16] = ldftn(GetLowerBoundRC);
			Visual.ISOCurrencySymbolRemotingAssert[17] = ldftn(IsRetvalRegistryWowKey);
			Visual.ISOCurrencySymbolRemotingAssert[18] = ldftn(DarkYellowGetOrderableDynamicPartitions);
			Visual.ISOCurrencySymbolRemotingAssert[19] = ldftn(GetEnvoySinkIgnorePersistedDecision);
			Visual.ISOCurrencySymbolRemotingAssert[20] = ldftn(getSetupInformationNested);
			Visual.ISOCurrencySymbolRemotingAssert[21] = ldftn(GetExecutingAssemblyAutoResetEvent);
			Visual.ISOCurrencySymbolRemotingAssert[22] = ldftn(lpfuncdescDictionaryNode);
			Visual.ISOCurrencySymbolRemotingAssert[23] = ldftn(ITupleInternalVisibleToAllHosts);
			Visual.ISOCurrencySymbolRemotingAssert[24] = ldftn(GetSByteTOKENSTATISTICS);
			Visual.ISOCurrencySymbolRemotingAssert[25] = ldftn(ResourceManagerGetSatelliteAssemblyFailedSetAll);
			Visual.ISOCurrencySymbolRemotingAssert[26] = ldftn(PrefixPropertiesToSet);
			Visual.ISOCurrencySymbolRemotingAssert[27] = ldftn(TokenTypeInfrastructure);
			Visual.ISOCurrencySymbolRemotingAssert[28] = ldftn(SavePolicyIsolatedStorageScope);
			Visual.ISOCurrencySymbolRemotingAssert[29] = ldftn(StindRefDispatchReplyMessage);
			Visual.ISOCurrencySymbolRemotingAssert[30] = ldftn(CommonTemplatesDaylightTimeStruct);
			Visual.ISOCurrencySymbolRemotingAssert[31] = ldftn(BindableIterableToEnumerableAdapterIsNestedPublic);
			Visual.ISOCurrencySymbolRemotingAssert[32] = ldftn(IConnectionPointContainerAppendFormat);
			Visual.ISOCurrencySymbolRemotingAssert[33] = ldftn(IsDSProgramFilesX);
			Visual.ISOCurrencySymbolRemotingAssert[34] = ldftn(ConvertTimeIContextProperty);
			Visual.ISOCurrencySymbolRemotingAssert[35] = ldftn(getSourceInterfaceComputeHash);
			Visual.ISOCurrencySymbolRemotingAssert[36] = ldftn(StringTypeNoWindows);
			Visual.ISOCurrencySymbolRemotingAssert[37] = ldftn(TaskCompletedMapToDictionaryAdapter);
			Visual.ISOCurrencySymbolRemotingAssert[38] = ldftn(ConvertTimeFromUtcStrongName);
			Visual.ISOCurrencySymbolRemotingAssert[39] = ldftn(ExchangegetFormat);
			Visual.ISOCurrencySymbolRemotingAssert[40] = ldftn(SequentialSaturday);
			Visual.ISOCurrencySymbolRemotingAssert[41] = ldftn(LdcIDisableEvent);
			Visual.ISOCurrencySymbolRemotingAssert[42] = ldftn(setSerializationFormatterIntegerIdsSize);
			Visual.ISOCurrencySymbolRemotingAssert[43] = ldftn(ServerProcessingCheckAssertion);
			Visual.ISOCurrencySymbolRemotingAssert[44] = ldftn(IsValidAttributeValueISODecoder);
			Visual.ISOCurrencySymbolRemotingAssert[45] = ldftn(SecurityStateNotContentIndexed);
			Visual.ISOCurrencySymbolRemotingAssert[46] = ldftn(GetCallTypegetCurrencyGroupSizes);
			Visual.ISOCurrencySymbolRemotingAssert[47] = ldftn(UriAddrOfPinnedObject);
			Visual.ISOCurrencySymbolRemotingAssert[48] = ldftn(CMSASSEMBLYDEPLOYMENTFLAGINSTALLmowned);
			Visual.ISOCurrencySymbolRemotingAssert[49] = ldftn(setClipboardVARFLAGFHIDDEN);
			Visual.ISOCurrencySymbolRemotingAssert[50] = ldftn(GetHandleEncoderExceptionFallback);
			Visual.ISOCurrencySymbolRemotingAssert[51] = ldftn(setHashValueDisallowPublisherPolicyValue);
			Visual.ISOCurrencySymbolRemotingAssert[52] = ldftn(TransformMetadataSizesetApplicationUrl);
			Visual.ISOCurrencySymbolRemotingAssert[53] = ldftn(DefineResourceLPStr);
			Visual.ISOCurrencySymbolRemotingAssert[54] = ldftn(NestedTypeWriteInt);
			Visual.ISOCurrencySymbolRemotingAssert[55] = ldftn(FileIOPermissionAttributeFNonExtensible);
			Visual.ISOCurrencySymbolRemotingAssert[56] = ldftn(LocalActivatorOpenPunctuation);
			Visual.ISOCurrencySymbolRemotingAssert[57] = ldftn(UCOMIPersistFilePermitOnly);
			Visual.ISOCurrencySymbolRemotingAssert[58] = ldftn(NotOnCanceledBgeUn);
			Visual.ISOCurrencySymbolRemotingAssert[59] = ldftn(EventHandleTaskCanceledException);
			Visual.ISOCurrencySymbolRemotingAssert[60] = ldftn(RegisterInteropXmlElementNData);
			Visual.ISOCurrencySymbolRemotingAssert[61] = ldftn(PrepareConstrainedRegionsgetUseSalt);
			Visual.ISOCurrencySymbolRemotingAssert[62] = ldftn(paramdescGetChannelData);
			Visual.ISOCurrencySymbolRemotingAssert[63] = ldftn(ThreadTransferSendObjgetProviderName);
			Visual.ISOCurrencySymbolRemotingAssert[64] = ldftn(AsyncTaskCachegetReturnXmlElementName);
			Visual.ISOCurrencySymbolRemotingAssert[65] = ldftn(ConvOvfUTimeSpanParse);
			Visual.ISOCurrencySymbolRemotingAssert[66] = ldftn(getUICCSTDCALL);
			Visual.ISOCurrencySymbolRemotingAssert[67] = ldftn(getLegalKeySizesPropertyAnalysis);
			Visual.ISOCurrencySymbolRemotingAssert[68] = ldftn(RoundtripKindPercentNegativePattern);
			Visual.ISOCurrencySymbolRemotingAssert[69] = ldftn(DivUnEndBuffered);
			Visual.ISOCurrencySymbolRemotingAssert[70] = ldftn(DecimalInitialLeaseTime);
			Visual.ISOCurrencySymbolRemotingAssert[71] = ldftn(StartingCMSSECTIONIDCOMPATIBLEFRAMEWORKSSECTION);
			Visual.ISOCurrencySymbolRemotingAssert[72] = ldftn(ArgumentOutOfRangeListInsertCrSel);
			Visual.ISOCurrencySymbolRemotingAssert[73] = ldftn(CLRInstanceIDgetPermissionSetName);
			Visual.ISOCurrencySymbolRemotingAssert[74] = ldftn(getCharCapacityWinCE);
			Visual.ISOCurrencySymbolRemotingAssert[75] = ldftn(AdjustSessionIdDynamicSecurityMethodAttribute);
			Visual.ISOCurrencySymbolRemotingAssert[76] = ldftn(NativeCalendarNameNOTIFTYPECONVERTED);
			Visual.ISOCurrencySymbolRemotingAssert[77] = ldftn(GetTypeFromHandleNestedType);
			Visual.ISOCurrencySymbolRemotingAssert[78] = ldftn(FormatLiteralsSafeSubWindows);
			Visual.ISOCurrencySymbolRemotingAssert[79] = ldftn(ThrowExceptionForHRSetEnvironmentVariable);
			Visual.ISOCurrencySymbolRemotingAssert[80] = ldftn(GetAssemblyEvidencegetUseNetCoreTimer);
			Visual.ISOCurrencySymbolRemotingAssert[81] = ldftn(ScrollLockOnEnableDelegation);
			Visual.ISOCurrencySymbolRemotingAssert[82] = ldftn(ArgumentOutOfRangeNeedNonNegNumAccessDenied);
			Visual.ISOCurrencySymbolRemotingAssert[83] = ldftn(MessageDictionaryLaunchMail);
			Visual.ISOCurrencySymbolRemotingAssert[84] = ldftn(StoreListValidmhandle);
			Visual.ISOCurrencySymbolRemotingAssert[85] = ldftn(SpacingCombiningMarkDidNotExist);
			Visual.ISOCurrencySymbolRemotingAssert[86] = ldftn(GetOffsetgetStore);
			Visual.ISOCurrencySymbolRemotingAssert[87] = ldftn(CryptoKeyRightsDoubleArray);
			Visual.ISOCurrencySymbolRemotingAssert[88] = ldftn(SetStubDataLaunchMail);
			Visual.ISOCurrencySymbolRemotingAssert[89] = ldftn(getInstanceCMSASSEMBLYREFERENCEFLAGOPTIONAL);
			Visual.ISOCurrencySymbolRemotingAssert[90] = ldftn(NumberDecimalDigitsChineseEra);
			Visual.ISOCurrencySymbolRemotingAssert[91] = ldftn(StrongNameErrorInfoResourceManagerAddingCultureFromConfigFile);
			Visual.ISOCurrencySymbolRemotingAssert[92] = ldftn(DeploymentMetadataDeploymentFlagsEntryPointEntryFieldId);
			Visual.ISOCurrencySymbolRemotingAssert[93] = ldftn(CreateLinkedTokenSourcegetLoaderOptimization);
			Visual.ISOCurrencySymbolRemotingAssert[94] = ldftn(PointerExecutionContextSwitcher);
			Visual.ISOCurrencySymbolRemotingAssert[95] = ldftn(AllCriticalIsLittleEndian);
			Visual.ISOCurrencySymbolRemotingAssert[96] = ldftn(DefaultContextUnboxAny);
			Visual.ISOCurrencySymbolRemotingAssert[97] = ldftn(cNamedArgsGetEventToken);
			Visual.ISOCurrencySymbolRemotingAssert[98] = ldftn(TotalFreeSpaceValueAtReturn);
			Visual.ISOCurrencySymbolRemotingAssert[99] = ldftn(setSecurityZoneLocalVariableInfo);
			Visual.ISOCurrencySymbolRemotingAssert[100] = ldftn(setAssemblyEvidenceGenerateAppDomainEvidence);
			Visual.ISOCurrencySymbolRemotingAssert[101] = ldftn(SecurityTransparentAttributeINVOKEPROPERTYPUT);
			Visual.ISOCurrencySymbolRemotingAssert[102] = ldftn(NumberFormatInfogetParent);
			Visual.ISOCurrencySymbolRemotingAssert[103] = ldftn(GetConstructorManagedToNativeComInteropStubAttribute);
			Visual.ISOCurrencySymbolRemotingAssert[104] = ldftn(AppDomainManagerAssemblySilent);
			Visual.ISOCurrencySymbolRemotingAssert[105] = ldftn(BltUnSsetMonthNames);
			Visual.ISOCurrencySymbolRemotingAssert[106] = ldftn(setCurrencySymbolgetCommand);
			Visual.ISOCurrencySymbolRemotingAssert[107] = ldftn(CovariantPOLICYSETAUDITREQUIREMENTS);
			Visual.ISOCurrencySymbolRemotingAssert[108] = ldftn(setParamTypesGetInt);
			Visual.ISOCurrencySymbolRemotingAssert[109] = ldftn(UnsafeQueueUserWorkItemPinnableBufferCacheEventSource);
			Visual.ISOCurrencySymbolRemotingAssert[110] = ldftn(ReadBufferAsyncdAccountOperator);
			Visual.ISOCurrencySymbolRemotingAssert[111] = ldftn(SecurityBindingRedirectsVTBLOB);
			Visual.ISOCurrencySymbolRemotingAssert[112] = ldftn(getHasFlushedFinalBlockSTOREASSEMBLYSTATUSPAYLOADRESIDENT);
			Visual.ISOCurrencySymbolRemotingAssert[113] = ldftn(getHostDllAssertion);
			Visual.ISOCurrencySymbolRemotingAssert[114] = ldftn(getPropertyNamePARAMFLAGFLCID);
			Visual.ISOCurrencySymbolRemotingAssert[115] = ldftn(PublisherIdentityPermissionFileShare);
			Visual.ISOCurrencySymbolRemotingAssert[116] = ldftn(getLastAccessTimeIsNestedPublic);
			Visual.ISOCurrencySymbolRemotingAssert[117] = ldftn(ToLongTimeStringDebugMessage);
			Visual.ISOCurrencySymbolRemotingAssert[118] = ldftn(SetActivityIdResourceExposureLevel);
			Visual.ISOCurrencySymbolRemotingAssert[119] = ldftn(EventRegistrationTokenListWithCountIStoreBindingResultBoundVersion);
			Visual.ISOCurrencySymbolRemotingAssert[120] = ldftn(getCookiegetPolicyStatement);
			Visual.ISOCurrencySymbolRemotingAssert[121] = ldftn(SetCompressedStackgetPercentPositivePattern);
			Visual.ISOCurrencySymbolRemotingAssert[122] = ldftn(NoValuePropManifestError);
			Visual.ISOCurrencySymbolRemotingAssert[123] = ldftn(NetworkAsyncProcessMessage);
			Visual.ISOCurrencySymbolRemotingAssert[124] = ldftn(RectactionsCopy);
			Visual.ISOCurrencySymbolRemotingAssert[125] = ldftn(GetReferenceGuidScheme);
			Visual.ISOCurrencySymbolRemotingAssert[126] = ldftn(SetTypeSafeSerializationManager);
			Visual.ISOCurrencySymbolRemotingAssert[127] = ldftn(StartupCachePath);
			Visual.ISOCurrencySymbolRemotingAssert[128] = ldftn(asyncWaiterTokenDeviceClaimAttributes);
			Visual.ISOCurrencySymbolRemotingAssert[129] = ldftn(removeModuleResolveEditAndContinueHelper);
			Visual.ISOCurrencySymbolRemotingAssert[130] = ldftn(WriteKeyopLessThanOrEqual);
			Visual.ISOCurrencySymbolRemotingAssert[131] = ldftn(setActivityOptionsSerializedStreamHeader);
			Visual.ISOCurrencySymbolRemotingAssert[132] = ldftn(PadLeftgetPercentGroupSeparator);
			Visual.ISOCurrencySymbolRemotingAssert[133] = ldftn(UnmanagedMemoryAccessorEnumerateSubKeys);
			Visual.ISOCurrencySymbolRemotingAssert[134] = ldftn(getCalendarTypeApplicationTrust);
			Visual.ISOCurrencySymbolRemotingAssert[135] = ldftn(FunctionPtrSafeProcessHandle);
			Visual.ISOCurrencySymbolRemotingAssert[136] = ldftn(GetDecimalFUNCFLAGFRESTRICTED);
			Visual.ISOCurrencySymbolRemotingAssert[137] = ldftn(FullTrustAllINVOCATIONFLAGS);
			Visual.ISOCurrencySymbolRemotingAssert[138] = ldftn(GetRegistrableTypesInAssemblyInterfaceIsIDispatch);
			Visual.ISOCurrencySymbolRemotingAssert[139] = ldftn(IDispatchImplTypeComImportAttribute);
			Visual.ISOCurrencySymbolRemotingAssert[140] = ldftn(HandledRsaFull);
			Visual.ISOCurrencySymbolRemotingAssert[141] = ldftn(getSourceLengthLayoutKind);
			Visual.ISOCurrencySymbolRemotingAssert[142] = ldftn(GetDeclaredMethodsdIIDIEnumSTORECATEGORYINSTANCE);
			Visual.ISOCurrencySymbolRemotingAssert[143] = ldftn(TryDequeueMakeDataType);
			Visual.ISOCurrencySymbolRemotingAssert[144] = ldftn(WindowObjectLoop);
			Visual.ISOCurrencySymbolRemotingAssert[145] = ldftn(CompletionAsynchronous);
			Visual.ISOCurrencySymbolRemotingAssert[146] = ldftn(CharUnknownSerializationMonkey);
			Visual.ISOCurrencySymbolRemotingAssert[147] = ldftn(WindowsRuntimeResourceManagerBaseRequiredBit);
			Visual.ISOCurrencySymbolRemotingAssert[148] = ldftn(AccessRuleDYN);
			Visual.ISOCurrencySymbolRemotingAssert[149] = ldftn(KerbTicketLogonLPStruct);
			Visual.ISOCurrencySymbolRemotingAssert[150] = ldftn(IsNotPublicVARFLAGFDISPLAYBIND);
			Visual.ISOCurrencySymbolRemotingAssert[151] = ldftn(ReadFromUnderlyingStreamAsyncdTYPEFLAGFOLEAUTOMATION);
			Visual.ISOCurrencySymbolRemotingAssert[152] = ldftn(BuiltinReplicatorSidTokenUser);
			Visual.ISOCurrencySymbolRemotingAssert[153] = ldftn(SuccessfulAccessTotalHours);
			Visual.ISOCurrencySymbolRemotingAssert[154] = ldftn(ParallelLoopBeginNoContext);
			Visual.ISOCurrencySymbolRemotingAssert[155] = ldftn(CustomErrorsEntryControlPrincipal);
			Visual.ISOCurrencySymbolRemotingAssert[156] = ldftn(BgtUnSInternalActivationContextHelper);
			Visual.ISOCurrencySymbolRemotingAssert[157] = ldftn(RemotingExceptionCurrentUICulture);
			Visual.ISOCurrencySymbolRemotingAssert[158] = ldftn(NumEndBinaryCrossAppDomainAssembly);
			Visual.ISOCurrencySymbolRemotingAssert[159] = ldftn(getDataNever);
			Visual.ISOCurrencySymbolRemotingAssert[160] = ldftn(TaskExceptionHolderBge);
			Visual.ISOCurrencySymbolRemotingAssert[161] = ldftn(PARAMFLAGFOUTIsEquivalentTo);
			Visual.ISOCurrencySymbolRemotingAssert[162] = ldftn(DataCollectionStartgetOaepSHA);
			Visual.ISOCurrencySymbolRemotingAssert[163] = ldftn(PrimitiveValueStopped);
			Visual.ISOCurrencySymbolRemotingAssert[164] = ldftn(getExceptionTypeTokenUnboxAny);
			Visual.ISOCurrencySymbolRemotingAssert[165] = ldftn(CMSHASHDIGESTMETHODMinusOne);
			Visual.ISOCurrencySymbolRemotingAssert[166] = ldftn(getFieldNamesIEnumUnknown);
			Visual.ISOCurrencySymbolRemotingAssert[167] = ldftn(IsCompletedEncodingProvider);
			Visual.ISOCurrencySymbolRemotingAssert[168] = ldftn(SingleCallQuickCacheEntryType);
			Visual.ISOCurrencySymbolRemotingAssert[169] = ldftn(CMSUSAGEPATTERNSCOPEPROCESSIsLastFrameFromForeignExceptionStackTrace);
			Visual.ISOCurrencySymbolRemotingAssert[170] = ldftn(IsStringReturnValue);
			Visual.ISOCurrencySymbolRemotingAssert[171] = ldftn(SqmsetGroup);
			Visual.ISOCurrencySymbolRemotingAssert[172] = ldftn(ItemgetPrincipal);
			Visual.ISOCurrencySymbolRemotingAssert[173] = ldftn(StartingTaskFactory);
			Visual.ISOCurrencySymbolRemotingAssert[174] = ldftn(LocalMachineGetObjectValue);
			Visual.ISOCurrencySymbolRemotingAssert[175] = ldftn(IsPrefixExecuteAssembly);
			Visual.ISOCurrencySymbolRemotingAssert[176] = ldftn(EnumAssembliesGetDirectoryRoot);
			Visual.ISOCurrencySymbolRemotingAssert[177] = ldftn(HasPropertiesgetHex);
			Visual.ISOCurrencySymbolRemotingAssert[178] = ldftn(ToSerializedStringEnumByteTypeInfo);
			Visual.ISOCurrencySymbolRemotingAssert[179] = ldftn(PortableEVENTACTIVITYCTRLCREATEID);
			Visual.ISOCurrencySymbolRemotingAssert[180] = ldftn(SetOnCountdownMresNternal);
			Visual.ISOCurrencySymbolRemotingAssert[181] = ldftn(MuiResourceTypeIdStringEntryOid);
			Visual.ISOCurrencySymbolRemotingAssert[182] = ldftn(DefineVersionInfoResourceGetFolderPath);
			Visual.ISOCurrencySymbolRemotingAssert[183] = ldftn(DependentOSMetadataMinorVersiongetMilliseconds);
			Visual.ISOCurrencySymbolRemotingAssert[184] = ldftn(TraceFormatUnicodeCategory);
			Visual.ISOCurrencySymbolRemotingAssert[185] = ldftn(BinaryContractReferenceAssemblyAttribute);
			Visual.ISOCurrencySymbolRemotingAssert[186] = ldftn(getStringValueSerializationNullKey);
			Visual.ISOCurrencySymbolRemotingAssert[187] = ldftn(DefineUnmanagedResourceResourceExposureAttribute);
			Visual.ISOCurrencySymbolRemotingAssert[188] = ldftn(TokenUserClaimAttributesHasShutdownStarted);
			Visual.ISOCurrencySymbolRemotingAssert[189] = ldftn(PacketmallSystemTimeZonesRead);
			Visual.ISOCurrencySymbolRemotingAssert[190] = ldftn(getMutexRightsSetNativeFunction);
			Visual.ISOCurrencySymbolRemotingAssert[191] = ldftn(AddAccessRuleDelaySign);
			Visual.ISOCurrencySymbolRemotingAssert[192] = ldftn(getTypeTokenBuiltinAccountOperatorsSid);
			Visual.ISOCurrencySymbolRemotingAssert[193] = ldftn(CFBF);
			Visual.ISOCurrencySymbolRemotingAssert[194] = ldftn(StartOfUserTypesEnumSByteTypeInfo);
			Visual.ISOCurrencySymbolRemotingAssert[195] = ldftn(TripleDESCryptoServiceProviderListSeparator);
			Visual.ISOCurrencySymbolRemotingAssert[196] = ldftn(SuppressUnmanagedCodeSecurityAttributeToObject);
			Visual.ISOCurrencySymbolRemotingAssert[197] = ldftn(getReturnParameterINVOCATIONFLAGSNONWPFXAPI);
			Visual.ISOCurrencySymbolRemotingAssert[198] = ldftn(BuiltInMultiByte);
			Visual.ISOCurrencySymbolRemotingAssert[199] = ldftn(getAccessMaskgetAction);
			Visual.ISOCurrencySymbolRemotingAssert[200] = ldftn(TokenTypeXConstants);
			Visual.ISOCurrencySymbolRemotingAssert[201] = ldftn(CallTypeIProgress);
			Visual.ISOCurrencySymbolRemotingAssert[202] = ldftn(AsIntGetContextNameObject);
			Visual.ISOCurrencySymbolRemotingAssert[203] = ldftn(IIDIManifestInformationlpvardesc);
			Visual.ISOCurrencySymbolRemotingAssert[204] = ldftn(STAGetRegisteredActivatedClientTypes);
			Visual.ISOCurrencySymbolRemotingAssert[205] = ldftn(ArgumentOutOfRangeBiggerThanCollectiongetConcurrentScheduler);
			Visual.ISOCurrencySymbolRemotingAssert[206] = ldftn(EnumerableToBindableIterableAdapterGetMethods);
			Visual.ISOCurrencySymbolRemotingAssert[207] = ldftn(CreateObjRefBuiltinReplicatorSid);
			Visual.ISOCurrencySymbolRemotingAssert[208] = ldftn(InvalidCastExceptionGetAccessors);
			Visual.ISOCurrencySymbolRemotingAssert[209] = ldftn(FailedWriteAllBytes);
			Visual.ISOCurrencySymbolRemotingAssert[210] = ldftn(ZeroIidParameterIndex);
			Visual.ISOCurrencySymbolRemotingAssert[211] = ldftn(getItemsSecurityPermission);
			Visual.ISOCurrencySymbolRemotingAssert[212] = ldftn(InstancesWaitingToRun);
			Visual.ISOCurrencySymbolRemotingAssert[213] = ldftn(CLRInstanceIDSecurity);
			Visual.ISOCurrencySymbolRemotingAssert[214] = ldftn(ZeroFreeCoTaskMemAnsiCausalityRelation);
			Visual.ISOCurrencySymbolRemotingAssert[215] = ldftn(TokenizerStreamNTAuthority);
			Visual.ISOCurrencySymbolRemotingAssert[216] = ldftn(ImageFileMachineSin);
			Visual.ISOCurrencySymbolRemotingAssert[217] = ldftn(FailureReleaseAllResources);
			Visual.ISOCurrencySymbolRemotingAssert[218] = ldftn(WindowsAccountNamegetUseUserOverride);
			Visual.ISOCurrencySymbolRemotingAssert[219] = ldftn(ShadowCopyDirectoriesValuegetLoaderOptimization);
			Visual.ISOCurrencySymbolRemotingAssert[220] = ldftn(ModuleVersionIdComposedOfNoStaticMembers);
			Visual.ISOCurrencySymbolRemotingAssert[221] = ldftn(IsAttachedgetRenewalTime);
			Visual.ISOCurrencySymbolRemotingAssert[222] = ldftn(etwLogDecoderNLS);
			Visual.ISOCurrencySymbolRemotingAssert[223] = ldftn(setWindowLeftIsModule);
			Visual.ISOCurrencySymbolRemotingAssert[224] = ldftn(TimeZoneGetOtherMethods);
			Visual.ISOCurrencySymbolRemotingAssert[225] = ldftn(WriteArrayPanic);
			Visual.ISOCurrencySymbolRemotingAssert[226] = ldftn(TimerHolderGetCheckSum);
			Visual.ISOCurrencySymbolRemotingAssert[227] = ldftn(getSkipVerificationTypeUnion);
			Visual.ISOCurrencySymbolRemotingAssert[228] = ldftn(InvalidOperationEmptyStackMRMDictionary);
			Visual.ISOCurrencySymbolRemotingAssert[229] = ldftn(LibrarygetInnerException);
			Visual.ISOCurrencySymbolRemotingAssert[230] = ldftn(BuiltInDefineByValArray);
			Visual.ISOCurrencySymbolRemotingAssert[231] = ldftn(FromCanceledgetPublisher);
			Visual.ISOCurrencySymbolRemotingAssert[232] = ldftn(IsServerGCAssemblyKeyNameAttribute);
			Visual.ISOCurrencySymbolRemotingAssert[233] = ldftn(getAsRgetAssemblyFormat);
			Visual.ISOCurrencySymbolRemotingAssert[234] = ldftn(UTFsetCurrencyDecimalDigits);
			Visual.ISOCurrencySymbolRemotingAssert[235] = ldftn(ParameterTokenIsField);
			Visual.ISOCurrencySymbolRemotingAssert[236] = ldftn(SetErrorbuffer);
			Visual.ISOCurrencySymbolRemotingAssert[237] = ldftn(ValidKeySizeDXNN);
			Visual.ISOCurrencySymbolRemotingAssert[238] = ldftn(EndNoGCRegionStatusDateTimeConstantAttribute);
			Visual.ISOCurrencySymbolRemotingAssert[239] = ldftn(CaptureOffsetgetUseNetCoreTimer);
			Visual.ISOCurrencySymbolRemotingAssert[240] = ldftn(GetEnvironmentVariableSEPDateOrOffset);
			Visual.ISOCurrencySymbolRemotingAssert[241] = ldftn(CCMAXIsPrefix);
			Visual.ISOCurrencySymbolRemotingAssert[242] = ldftn(InvalidCastExceptionAttributeCount);
			Visual.ISOCurrencySymbolRemotingAssert[243] = ldftn(UniversalTimeGetReferencedAssemblies);
			Visual.ISOCurrencySymbolRemotingAssert[244] = ldftn(SupportUrlReflectionOnlyGetAssemblies);
			Visual.ISOCurrencySymbolRemotingAssert[245] = ldftn(getSelfAffectingThreadinggetStart);
			Visual.ISOCurrencySymbolRemotingAssert[246] = ldftn(TasksGregorianCalendarHelper);
			Visual.ISOCurrencySymbolRemotingAssert[247] = ldftn(MetadatasetPersist);
			Visual.ISOCurrencySymbolRemotingAssert[248] = ldftn(GenerateHashJulianCenturies);
			Visual.ISOCurrencySymbolRemotingAssert[249] = ldftn(IsNotPublicLargestWindowHeight);
			Visual.ISOCurrencySymbolRemotingAssert[250] = ldftn(AutoDualsetSoapAction);
			Visual.ISOCurrencySymbolRemotingAssert[251] = ldftn(getMaxCapacityWindowHeight);
			Visual.ISOCurrencySymbolRemotingAssert[252] = ldftn(TimerCallbackgetChannelName);
			Visual.ISOCurrencySymbolRemotingAssert[253] = ldftn(YearEndSkipVisibilityChecks);
			Visual.ISOCurrencySymbolRemotingAssert[254] = ldftn(RegistryViewSetTraits);
			Visual.ISOCurrencySymbolRemotingAssert[255] = ldftn(FormDDisallowUnassignedGetRandomizedEqualityComparer);
			Visual.ISOCurrencySymbolRemotingAssert[256] = ldftn(SinkProviderDataRuntimeType);
			Visual.ISOCurrencySymbolRemotingAssert[257] = ldftn(IsHideBySigPrepareConstrainedRegionsNoOP);
			Visual.ISOCurrencySymbolRemotingAssert[258] = ldftn(UnknownIdentities);
			Visual.ISOCurrencySymbolRemotingAssert[259] = ldftn(getDaySingleUse);
			Visual.ISOCurrencySymbolRemotingAssert[260] = ldftn(AbbreviatedMonthNamesShadowCopyFilesValue);
			Visual.ISOCurrencySymbolRemotingAssert[261] = ldftn(FieldTypeGetSafeWaitHandle);
			Visual.ISOCurrencySymbolRemotingAssert[262] = ldftn(ProvidedSecurityInfoStringValue);
			Visual.ISOCurrencySymbolRemotingAssert[263] = ldftn(MaximumAllowedConvertAssemblyToTypeLib);
			Visual.ISOCurrencySymbolRemotingAssert[264] = ldftn(setSourceSwitchWrappers);
			Visual.ISOCurrencySymbolRemotingAssert[265] = ldftn(EnumPropertiesGetDaysInMonth);
			Visual.ISOCurrencySymbolRemotingAssert[266] = ldftn(StrongNameKeyGenExUserEntryPoint);
			Visual.ISOCurrencySymbolRemotingAssert[267] = ldftn(getLengthArraySegmentEnumerator);
			Visual.ISOCurrencySymbolRemotingAssert[268] = ldftn(getCompletedSynchronouslygetActor);
			Visual.ISOCurrencySymbolRemotingAssert[269] = ldftn(AllowLeadingWhiteStaticIndexRangePartition);
			Visual.ISOCurrencySymbolRemotingAssert[270] = ldftn(UpgradeToWriterLocksetHandle);
			Visual.ISOCurrencySymbolRemotingAssert[271] = ldftn(DeclareLocalFullTrustZoneInternet);
			Visual.ISOCurrencySymbolRemotingAssert[272] = ldftn(ServiceCreatePermissionSet);
			Visual.ISOCurrencySymbolRemotingAssert[273] = ldftn(ContextAttributeEntryMemberRef);
			Visual.ISOCurrencySymbolRemotingAssert[274] = ldftn(getIsPublicFileNotFoundException);
			Visual.ISOCurrencySymbolRemotingAssert[275] = ldftn(GuaranteesNestedPublic);
			Visual.ISOCurrencySymbolRemotingAssert[276] = ldftn(getEndOfStreamgetCurrencyNegativePattern);
			Visual.ISOCurrencySymbolRemotingAssert[277] = ldftn(IsHomogenousSendCommand);
			Visual.ISOCurrencySymbolRemotingAssert[278] = ldftn(CMSUSAGEPATTERNgetIsHomogenous);
			Visual.ISOCurrencySymbolRemotingAssert[279] = ldftn(getSourceStrongNameSignatureVerification);
			Visual.ISOCurrencySymbolRemotingAssert[280] = ldftn(IsMulticastPm);
		}

		// Token: 0x040000BC RID: 188
		public static bool infectionESP;

		// Token: 0x040000BD RID: 189
		private static float splashtimeout;

		// Token: 0x040000BE RID: 190
		public static TrailRenderer trail;

		// Token: 0x040000BF RID: 191
		private const float LineWidth = 0.015f;

		// Token: 0x040000C0 RID: 192
		public static int[] bones;

		// Token: 0x040000C1 RID: 193
		private static IntPtr[] ISOCurrencySymbolRemotingAssert;
	}
}
