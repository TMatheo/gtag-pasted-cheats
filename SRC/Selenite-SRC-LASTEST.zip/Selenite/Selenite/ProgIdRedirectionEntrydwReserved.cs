﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000060 RID: 96
[StructLayout(2, Pack = 1, Size = 536)]
internal struct ProgIdRedirectionEntrydwReserved
{
	// Token: 0x04000188 RID: 392 RVA: 0x00065525 File Offset: 0x00063725
	internal static readonly ProgIdRedirectionEntrydwReserved AsAnyMarshalerBitArray;
}
