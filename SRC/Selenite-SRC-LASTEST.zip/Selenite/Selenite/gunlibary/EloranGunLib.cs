﻿using System;
using System.Collections;
using System.Collections.Generic;
using BepInEx;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Menu;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

namespace gunlibary
{
	// Token: 0x02000005 RID: 5
	public class EloranGunLib : MonoBehaviour
	{
		// Token: 0x0600001F RID: 31 RVA: 0x00003550 File Offset: 0x00001750
		private static IEnumerator AddAttributeRequireDashes(ref int A_0, ref int A_1, ref int A_2, LineRenderer A_3, Color32 A_4, Color32 A_5)
		{
			EloranGunLib.<AnimateLineGradient>d__26 <AnimateLineGradient>d__ = new EloranGunLib.<AnimateLineGradient>d__26(0);
			<AnimateLineGradient>d__.lineRenderer = A_3;
			<AnimateLineGradient>d__.startColor = A_4;
			<AnimateLineGradient>d__.endColor = A_5;
			A_1 = 0;
			return <AnimateLineGradient>d__;
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00003590 File Offset: 0x00001790
		private static bool MetadataSectionMvidValueSizegetLoadFrom(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			A_5.Dispose();
			A_1 = 3;
			bool result;
			return result;
		}

		// Token: 0x06000021 RID: 33 RVA: 0x000035BC File Offset: 0x000017BC
		private static void getPerMilleSymbolArgsIsArray(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever == null;
			A_8 = flag;
			int num = ((!A_8) ? 1 : 0) * 7 + 44;
			A_0 = num;
		}

		// Token: 0x06000022 RID: 34 RVA: 0x00003620 File Offset: 0x00001820
		private static bool getSubjectIsAppEarlierThanSilverlight(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			bool result = A_8;
			A_1 = 0;
			return result;
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00003640 File Offset: 0x00001840
		private static bool StlocSForm(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_5.MoveNext() ? 1 : 0) * -4 + 125;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x06000024 RID: 36 RVA: 0x0000368C File Offset: 0x0000188C
		private static void getActivityIdImageFileMachine(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			Ray ray = GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition);
			A_3 = ray;
			bool isPressed = Mouse.current.rightButton.isPressed;
			A_4 = isPressed;
			int num = ((!A_4) ? 1 : 0) * 32 + 70;
			A_0 = num;
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00003728 File Offset: 0x00001928
		private static void IResourceReaderDataCollector(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref ParticleSystem.MainModule A_4, ref ParticleSystem.EmissionModule A_5, ref ParticleSystem.ShapeModule A_6, ref ParticleSystemRenderer A_7, GameObject A_8)
		{
			A_0 = 37;
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00003740 File Offset: 0x00001940
		private static bool WindowsRuntimeMarshalgetDaylightTransitionEnd(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			XRDisplaySubsystem xrdisplaySubsystem = A_5.Current;
			A_6 = xrdisplaySubsystem;
			bool running = A_6.running;
			A_7 = running;
			int num = ((!A_7) ? 1 : 0) * 1 + 122;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x06000027 RID: 39 RVA: 0x000037C4 File Offset: 0x000019C4
		private static void GetTargetTypeRef(ref int A_0, ref int A_1, ref int A_2, EloranGunLib.AnimationMode A_3)
		{
			EloranGunLib.currentAnimationMode = A_3;
			A_1 = 0;
		}

		// Token: 0x06000028 RID: 40 RVA: 0x000037E4 File Offset: 0x000019E4
		private static void tdescPinned(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Action A_4, bool A_5)
		{
			A_1 = 0;
		}

		// Token: 0x06000029 RID: 41 RVA: 0x000037FC File Offset: 0x000019FC
		private static void getGUIDBinaryTypeEnum(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever != null;
			A_23 = flag;
			int num = ((!A_23) ? 1 : 0) * 1 + 100;
			A_0 = num;
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00003860 File Offset: 0x00001A60
		private static EloranGunLib.AnimationMode FromAsyncTrimPromiseReflectionExtensions(ref int A_0, ref int A_1, ref int A_2)
		{
			EloranGunLib.AnimationMode result = EloranGunLib.currentAnimationMode;
			A_1 = 1;
			return result;
		}

		// Token: 0x0600002B RID: 43 RVA: 0x0000387C File Offset: 0x00001A7C
		private static void GetMembersgetdefaultPermissionSetID(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref ParticleSystem.MainModule A_4, ref ParticleSystem.EmissionModule A_5, ref ParticleSystem.ShapeModule A_6, ref ParticleSystemRenderer A_7, GameObject A_8)
		{
			bool flag = !EloranGunLib.enableParticles;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 35;
			A_0 = num;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x000038E0 File Offset: 0x00001AE0
		private static void ReleaseMutexVARDESC(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6);
			A_9 = vector;
			A_9.x += (float)((A_5 % 2 == 0) ? 1 : -1) * A_4 * Mathf.Sin(EloranGunLib.waveTimeOffset);
			A_0 = 17;
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00003964 File Offset: 0x00001B64
		private static void putSubscriptionIdCheckLevel(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.spherepointer.GetComponent<Renderer>().material.color = EloranGunLib.TriggeredPointerColorStart;
			A_19 = A_25;
			int num = ((!A_19) ? 1 : 0) * 7 + 91;
			A_0 = num;
		}

		// Token: 0x0600002E RID: 46 RVA: 0x000039E0 File Offset: 0x00001BE0
		private static void FileSourceNamesetAbbreviatedMonthGenitiveNames(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			A_17.Invoke();
			A_0 = 60;
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00003A04 File Offset: 0x00001C04
		private static void PolicyLevelTypeConfig(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			A_1 = 0;
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00003A1C File Offset: 0x00001C1C
		private static void setDefaultThreadCurrentCultureRemotingServices(ref int A_0, ref int A_1, ref int A_2)
		{
			Object.Destroy(EloranGunLib.spherepointer);
			EloranGunLib.spherepointer = null;
			EloranGunLib.LockedRigOrPlayerOrwhatever = null;
			A_1 = 0;
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00003A4C File Offset: 0x00001C4C
		private static IEnumerator PulsePointer(GameObject pointer)
		{
			int num = 33;
			int num2 = 33;
			num2 = 33;
			IEnumerator result;
			while (num2 != 0)
			{
				int num3;
				result = calli(System.Collections.IEnumerator(System.Int32&,System.Int32&,System.Int32&,UnityEngine.GameObject), ref num, ref num2, ref num3, pointer, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 33;
			return result;
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00003A88 File Offset: 0x00001C88
		private static void getAttributeStringINormalizeForIsolatedStorage(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			Ray ray = GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition);
			A_3 = ray;
			bool isPressed = Mouse.current.rightButton.isPressed;
			A_4 = isPressed;
			int num = ((!A_4) ? 1 : 0) * 32 + 70;
			A_0 = num;
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00003B1C File Offset: 0x00001D1C
		private static void getmessageServerWellKnownEntry(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever != null;
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 1 + 57;
			A_0 = num;
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00003B84 File Offset: 0x00001D84
		private static void IServerResponseChannelSinkStackBuiltinSystemOperatorsSid(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			A_11.SetPosition(A_5, A_9);
			int num = A_5 + 1;
			A_5 = num;
			bool flag = A_5 < EloranGunLib.LineCurve;
			A_10 = flag;
			int num2 = (A_10 ? 1 : 0) * -14 + 19;
			A_0 = num2;
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00003C28 File Offset: 0x00001E28
		private static void ConsoleKeyIsFromThisAppDomain(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever != null;
			A_22 = flag;
			int num = ((!A_22) ? 1 : 0) * 1 + 96;
			A_0 = num;
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00003C8C File Offset: 0x00001E8C
		private static void getEventProviderEnvelope(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6);
			A_9 = vector;
			A_9.z += A_4 * (2f * (A_6 * A_3 - Mathf.Floor(A_6 * A_3 + 0.5f)));
			A_0 = 17;
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00003D1C File Offset: 0x00001F1C
		private static void getTypeNamegetIn(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			A_11.material = new Material(A_12);
			EloranGunLib eloranGunLib = A_10.AddComponent<EloranGunLib>();
			A_14 = eloranGunLib;
			A_14.StartCoroutine(EloranGunLib.StartCurvyLineRenderer(A_11, GorillaTagger.Instance.rightHandTransform.position, EloranGunLib.lr, EloranGunLib.spherepointer.transform.position, EloranGunLib.LineColorStart, EloranGunLib.LineColorEnd));
			A_14.StartCoroutine(EloranGunLib.AnimateLineGradient(A_11, EloranGunLib.LineColorStart, EloranGunLib.LineColorEnd));
			bool hasChanged = EloranGunLib.spherepointer.transform.hasChanged;
			A_15 = hasChanged;
			int num = ((!A_15) ? 1 : 0) * 5 + 82;
			A_0 = num;
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00003E30 File Offset: 0x00002030
		private static void DeploymentDataIConstantMembershipCondition(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			A_3 = rightGrab;
			int num = ((!A_3) ? 1 : 0) * 24 + 40;
			A_0 = num;
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00003E94 File Offset: 0x00002094
		private static void NotAPortableExecutableImageLongPathDirectory(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6);
			A_9 = vector;
			A_9.z += Mathf.Sin(A_6 * A_3 + EloranGunLib.waveTimeOffset) * A_4;
			A_0 = 17;
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00003F08 File Offset: 0x00002108
		private static void AccessRuleFactoryAccountEnterpriseAdminsSid(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Action A_4, bool A_5)
		{
			EloranGunLib.StartVrGun(A_4, A_5);
			A_0 = 118;
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00003F30 File Offset: 0x00002130
		private static void GetAssemblyManifestNativeSectionOffset(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = false;
			A_12 = flag;
			int num = ((!A_12) ? 1 : 0) * 1 + 57;
			A_0 = num;
		}

		// Token: 0x0600003C RID: 60 RVA: 0x00003F8C File Offset: 0x0000218C
		private static void getSetupInformationInternalApplicationIdentityHelper(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.spherepointer.transform.position = EloranGunLib.LockedRigOrPlayerOrwhatever.transform.position;
			EloranGunLib.HandleLineRendering();
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 7 + 54;
			A_0 = num;
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00004020 File Offset: 0x00002220
		private static void GetRuntimeDirectoryCreationTime(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = A_4.collider.GetComponentInParent<VRRig>() != null;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 3 + 47;
			A_0 = num;
		}

		// Token: 0x0600003E RID: 62 RVA: 0x00004090 File Offset: 0x00002290
		private static void ClassesRootCaster(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			A_13.material.renderQueue = 3000;
			A_13.startColor = Color.Lerp(Color.yellow, Color.magenta, Mathf.PingPong(Time.time, 1f));
			A_13.endColor = Color.Lerp(Color.yellow, Color.magenta, Mathf.PingPong(Time.time, 1f));
			A_5.transform.position = EloranGunLib.LockedRigOrPlayerOrwhatever.transform.position;
			A_5.transform.rotation = GorillaTagger.Instance.offlineVRRig.headMesh.transform.rotation;
			EloranGunLib eloranGunLib = A_5.AddComponent<EloranGunLib>();
			A_17 = eloranGunLib;
			A_17.StartCoroutine(EloranGunLib.AnimateBox(A_5, A_13));
			Object.Destroy(A_5, 0.05f);
			A_1 = 0;
		}

		// Token: 0x0600003F RID: 63 RVA: 0x000041C8 File Offset: 0x000023C8
		private static void SystemAlarmCallbackObjectYearDateSep(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = false;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 3 + 47;
			A_0 = num;
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00004224 File Offset: 0x00002424
		private static void TypesWhenNeededNoMangle(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			GameObject gameObject = new GameObject();
			A_5 = gameObject;
			LineRenderer lineRenderer = A_5.AddComponent<LineRenderer>();
			A_6 = lineRenderer;
			Vector3 position = EloranGunLib.LockedRigOrPlayerOrwhatever.transform.position;
			A_7 = position;
			Vector3[] array = new Vector3[5];
			A_8 = array;
			float num = 2f;
			A_9 = num;
			float num2 = 1f;
			A_10 = num2;
			A_8[0] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (-A_10 / 2f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (A_9 / 2f);
			A_8[1] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (A_10 / 2f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (A_9 / 2f);
			A_8[2] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (A_10 / 2f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (-A_9 / 2f);
			A_8[3] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (-A_10 / 2f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (-A_9 / 2f);
			A_8[4] = A_8[0];
			A_6.positionCount = A_8.Length;
			A_6.SetPositions(A_8);
			A_6.startWidth = 0.007f;
			A_6.endWidth = 0.007f;
			Shader shader = Shader.Find("Sprites/Default");
			A_11 = shader;
			bool flag = A_11 != null;
			A_12 = flag;
			int num3 = ((!A_12) ? 1 : 0) * 1 + 142;
			A_0 = num3;
		}

		// Token: 0x06000041 RID: 65 RVA: 0x00004578 File Offset: 0x00002778
		private static void ApplicationTrustManagerIsDiscretionaryAclCanonical(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = EloranGunLib.spherepointer != null;
			A_15 = flag;
			int num = ((!A_15) ? 1 : 0) * 1 + 65;
			A_0 = num;
		}

		// Token: 0x06000042 RID: 66 RVA: 0x000045DC File Offset: 0x000027DC
		private static void UIPermissionReadBlockAsyncInternald(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			int num = (GameObject.Find("Shoulder Camera").activeSelf ? 1 : 0) * 1 + 68;
			A_0 = num;
		}

		// Token: 0x06000043 RID: 67 RVA: 0x00004628 File Offset: 0x00002828
		private static void GetMembersLOADFROM(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			int num = (PhotonNetwork.InRoom ? 1 : 0) * 1 + 136;
			A_0 = num;
		}

		// Token: 0x06000044 RID: 68 RVA: 0x0000466C File Offset: 0x0000286C
		private static void MethodBuilderIEnumSTORECATEGORYSUBCATEGORY(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			bool inLobby = PhotonNetwork.InLobby;
			A_3 = inLobby;
			int num = ((!A_3) ? 1 : 0) * 9 + 138;
			A_0 = num;
		}

		// Token: 0x06000045 RID: 69 RVA: 0x000046CC File Offset: 0x000028CC
		private static IEnumerator StartCurvyLineRenderer(LineRenderer lineRenderer, Vector3 start, Vector3 mid, Vector3 end, Color32 startColor, Color32 endColor)
		{
			int num = 32;
			int num2 = 32;
			num2 = 32;
			IEnumerator result;
			while (num2 != 0)
			{
				int num3;
				result = calli(System.Collections.IEnumerator(System.Int32&,System.Int32&,System.Int32&,UnityEngine.LineRenderer,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Color32), ref num, ref num2, ref num3, lineRenderer, start, mid, end, startColor, endColor, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 32;
			return result;
		}

		// Token: 0x06000046 RID: 70 RVA: 0x0000470C File Offset: 0x0000290C
		private static void DelegationEra(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			Object.Destroy(EloranGunLib.spherepointer);
			EloranGunLib.spherepointer = null;
			EloranGunLib.LockedRigOrPlayerOrwhatever = null;
			A_1 = 0;
		}

		// Token: 0x06000047 RID: 71 RVA: 0x0000473C File Offset: 0x0000293C
		private static IEnumerator PersistKeySetAssemblyDelaySignAttribute(ref int A_0, ref int A_1, ref int A_2, GameObject A_3, LineRenderer A_4)
		{
			EloranGunLib.<AnimateBox>d__41 <AnimateBox>d__ = new EloranGunLib.<AnimateBox>d__41(0);
			<AnimateBox>d__.box = A_3;
			<AnimateBox>d__.outline = A_4;
			A_1 = 0;
			return <AnimateBox>d__;
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00004774 File Offset: 0x00002974
		private static void metwSessionIdTypesWhenNeeded(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			A_0 = 52;
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000049 RID: 73 RVA: 0x00004790 File Offset: 0x00002990
		// (set) Token: 0x0600006D RID: 109 RVA: 0x000067E4 File Offset: 0x000049E4
		public static EloranGunLib.AnimationMode CurrentAnimationMode
		{
			get
			{
				int num = 0;
				int num2 = 0;
				num2 = 0;
				EloranGunLib.AnimationMode result;
				while (num2 != 1)
				{
					int num3;
					result = calli(gunlibary.EloranGunLib/AnimationMode(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
				}
				num2 = 0;
				return result;
			}
			set
			{
				int num = 1;
				int num2 = 1;
				num2 = 1;
				while (num2 != 0)
				{
					int num3;
					calli(System.Void(System.Int32&,System.Int32&,System.Int32&,gunlibary.EloranGunLib/AnimationMode), ref num, ref num2, ref num3, value, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
				}
				num2 = 1;
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x000047C4 File Offset: 0x000029C4
		private static void UnsafeDeserializeGetRuntimeResourceString(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.spherepointer != null;
			A_24 = flag;
			int num = ((!A_24) ? 1 : 0) * 1 + 103;
			A_0 = num;
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00004828 File Offset: 0x00002A28
		private static IEnumerator IEnumSTOREASSEMBLYINSTALLATIONREFERENCEMessageDictionary(ref int A_0, ref int A_1, ref int A_2)
		{
			IEnumerator result = new EloranGunLib.<SmoothStopParticles>d__30(0);
			A_1 = 0;
			return result;
		}

		// Token: 0x0600004C RID: 76 RVA: 0x0000484C File Offset: 0x00002A4C
		private static void CountedMbcsStringTypeInitializer(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			A_0 = 89;
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00004864 File Offset: 0x00002A64
		private static Vector3 setIsSecuredBaseName(ref int A_0, ref int A_1, ref int A_2, ref Vector3 A_3, float A_4, Vector3 A_5, Vector3 A_6, Vector3 A_7)
		{
			Vector3 result = A_3;
			A_1 = 0;
			return result;
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00004884 File Offset: 0x00002A84
		private static void RaiseOnDeserializingEventOrderablePartitioner(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref EloranGunLib A_4)
		{
			EloranGunLib.enableParticles = !EloranGunLib.enableParticles;
			int num = (EloranGunLib.enableParticles ? 1 : 0) * 1 + 111;
			A_0 = num;
		}

		// Token: 0x0600004F RID: 79 RVA: 0x000048D8 File Offset: 0x00002AD8
		private static void MathTargetException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			bool flag = true;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 9 + 138;
			A_0 = num;
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00004934 File Offset: 0x00002B34
		private static void ERRORREFTOINVALIDASSEMBLYPermission(ref int A_0, ref int A_1, ref int A_2)
		{
			EloranGunLib.currentAnimationMode = (EloranGunLib.currentAnimationMode + 1) % (EloranGunLib.AnimationMode)Enum.GetValues(typeof(EloranGunLib.AnimationMode)).Length;
			Main.GetIndex("CGA").overlapText = "Change Gun Animation: " + EloranGunLib.currentAnimationMode.ToString();
			A_1 = 0;
		}

		// Token: 0x06000051 RID: 81 RVA: 0x0000499C File Offset: 0x00002B9C
		private static void ExtractNameSpaceTaskToApm(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.spherepointer.transform.position = A_4.point;
			EloranGunLib.spherepointer.GetComponent<Renderer>().material.color = EloranGunLib.PointerColorStart;
			int num = ((!A_16) ? 1 : 0) * 1 + 45;
			A_0 = num;
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00004A18 File Offset: 0x00002C18
		private static IEnumerator AnimateBox(GameObject box, LineRenderer outline)
		{
			int num = 134;
			int num2 = 134;
			num2 = 134;
			IEnumerator result;
			while (num2 != 0)
			{
				int num3;
				result = calli(System.Collections.IEnumerator(System.Int32&,System.Int32&,System.Int32&,UnityEngine.GameObject,UnityEngine.LineRenderer), ref num, ref num2, ref num3, box, outline, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 134;
			return result;
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00004A60 File Offset: 0x00002C60
		private static void RegisterWithHostAutoResetEvent(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref EloranGunLib A_4)
		{
			A_1 = 0;
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00004A78 File Offset: 0x00002C78
		private static void IsAutoLayoutGetSetMethod(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.spherepointer.GetComponent<Renderer>().material.color = EloranGunLib.TriggeredPointerColorStart;
			int num = ((!A_16) ? 1 : 0) * 1 + 55;
			A_0 = num;
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00004AD8 File Offset: 0x00002CD8
		private static void setApplicationNameTargetFrameworkName(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			Object.Destroy(A_11, Time.deltaTime);
			bool isPressed = Mouse.current.leftButton.isPressed;
			A_18 = isPressed;
			int num = ((!A_18) ? 1 : 0) * 9 + 90;
			A_0 = num;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00004B54 File Offset: 0x00002D54
		private static void ArchitectureAsyncTaskMethodBuilder(ref int A_0, ref int A_1, ref int A_2, ref Color32[] A_3, ref Color32 A_4, ref Color32 A_5, ref bool A_6, ref bool A_7, ref ParticleSystem.MainModule A_8)
		{
			Color32[] array = new Color32[]
			{
				new Color32(0, byte.MaxValue, 100, byte.MaxValue),
				new Color32(0, 200, byte.MaxValue, byte.MaxValue),
				new Color32(byte.MaxValue, 215, 0, byte.MaxValue),
				new Color32(byte.MaxValue, 165, 0, byte.MaxValue),
				new Color32(128, 0, 128, byte.MaxValue),
				new Color32(byte.MaxValue, 0, byte.MaxValue, byte.MaxValue),
				new Color32(0, 0, 128, byte.MaxValue),
				new Color32(byte.MaxValue, 69, 0, byte.MaxValue),
				new Color32(50, 205, 50, byte.MaxValue),
				new Color32(240, 128, 128, byte.MaxValue),
				new Color32(173, 216, 230, byte.MaxValue),
				new Color32(64, 224, 208, byte.MaxValue),
				new Color32(byte.MaxValue, 20, 147, byte.MaxValue),
				new Color32(123, 104, 238, byte.MaxValue),
				new Color32(byte.MaxValue, 99, 71, byte.MaxValue),
				new Color32(0, 191, byte.MaxValue, byte.MaxValue),
				new Color32(byte.MaxValue, 140, 0, byte.MaxValue),
				new Color32(75, 0, 130, byte.MaxValue),
				new Color32(60, 179, 113, byte.MaxValue),
				new Color32(244, 164, 96, byte.MaxValue),
				new Color32(138, 43, 226, byte.MaxValue),
				new Color32(byte.MaxValue, 105, 180, byte.MaxValue),
				new Color32(byte.MaxValue, 250, 205, byte.MaxValue),
				new Color32(139, 0, 0, byte.MaxValue)
			};
			A_3 = array;
			EloranGunLib.ColorIndex = (EloranGunLib.ColorIndex + 1) % A_3.Length;
			Color32 color = A_3[EloranGunLib.ColorIndex];
			A_4 = color;
			Color32 color2 = Color.Lerp(A_4, new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue), 0.5f);
			A_5 = color2;
			EloranGunLib.PointerColorStart = A_4;
			EloranGunLib.PointerColorEnd = A_5;
			EloranGunLib.LineColorStart = A_4;
			EloranGunLib.LineColorEnd = A_5;
			EloranGunLib.TriggeredPointerColorStart = A_4;
			EloranGunLib.TriggeredPointerColorEnd = A_5;
			bool flag = EloranGunLib.spherepointer != null;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 130;
			A_0 = num;
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00005014 File Offset: 0x00003214
		private static void GetConfigurationBytesCustomMarshaler(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.LockedRigOrPlayerOrwhatever = A_4.collider.GetComponentInParent<VRRig>();
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever == GorillaTagger.Instance.offlineVRRig;
			A_10 = flag;
			int num = ((!A_10) ? 1 : 0) * 1 + 48;
			A_0 = num;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00005094 File Offset: 0x00003294
		private static void IsAppEarlierThanWindowsPhoneMangoCOMServerImplementedClsid(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever == null;
			A_20 = flag;
			int num = ((!A_20) ? 1 : 0) * 3 + 92;
			A_0 = num;
		}

		// Token: 0x06000059 RID: 89 RVA: 0x000050F8 File Offset: 0x000032F8
		private static void getHasCurrentArrayList(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.spherepointer.transform.position = A_5.point;
			EloranGunLib.spherepointer.GetComponent<Renderer>().material.color = EloranGunLib.PointerColorStart;
			A_0 = 79;
		}

		// Token: 0x0600005A RID: 90 RVA: 0x0000514C File Offset: 0x0000334C
		private static void MetadataSectionDeploymentDataHasCreationContext(ref int A_0, ref int A_1, ref int A_2, ref Color32[] A_3, ref Color32 A_4, ref Color32 A_5, ref bool A_6, ref bool A_7, ref ParticleSystem.MainModule A_8)
		{
			EloranGunLib.spherepointer.GetComponent<Renderer>().material.color = A_4;
			bool flag = EloranGunLib.particleSystem != null;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 132;
			A_0 = num;
		}

		// Token: 0x0600005B RID: 91 RVA: 0x000051D4 File Offset: 0x000033D4
		public unsafe static bool IsXRDeviceActive()
		{
			int num = 1;
			int num2 = num * 4;
			int num3 = 119;
			int num4 = 119;
			num4 = 119;
			bool result;
			try
			{
				IL_1A:
				object[] array;
				int num5;
				int num6;
				int num7;
				int num8;
				int num9;
				int num10;
				Exception ex;
				Exception ex3;
				object[] array2;
				int num11;
				int num14;
				int num15;
				int num16;
				int num17;
				int num18;
				int num19;
				int num22;
				while (num4 != 0)
				{
					int num12;
					if (num4 == 3)
					{
						num4 = 119;
						if ((int)array[5] != 1)
						{
							num5 = (int)array[0];
							if (num5 == -1)
							{
								num6 = -1;
								num7 = -1;
							}
							else
							{
								num6 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num5 + 48 + num2);
								num7 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + (int)array[6] + 48 + num2) + 56 + num2);
							}
							while (num7 != num6)
							{
								num8 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num7 + 48 + num2);
								if (num8 != -1)
								{
									num9 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num8 + 24 + num2);
									array[6] = num8;
									array[2] = 2;
									num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num8 + 24 + num2);
									goto IL_1A;
								}
								num7 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num7 + 56 + num2);
							}
							if (num5 == -1)
							{
								num10 = 1;
								throw ex;
							}
							Exception ex2 = (Exception)array[4];
							num9 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num5 + 24 + num2);
							ex3 = ex2;
							array = (object[])array[1];
							array2 = new object[8];
							array2[5] = 0;
							array2[1] = array;
							array2[4] = ex2;
							array2[6] = num5;
							array2[2] = 1;
							array = array2;
							num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num5 + 24 + num2);
							continue;
						}
						else
						{
							num11 = (int)array[7];
							array = (object[])array[1];
							num12 = num11;
						}
					}
					else
					{
						int num13;
						if (num4 != 4)
						{
							List<XRDisplaySubsystem> list;
							List<XRDisplaySubsystem>.Enumerator enumerator;
							XRDisplaySubsystem xrdisplaySubsystem;
							bool flag;
							bool flag2;
							result = calli(System.Boolean(System.Int32&,System.Int32&,System.Int32&,System.Exception,System.Collections.Generic.List`1<UnityEngine.XR.XRDisplaySubsystem>&,System.Collections.Generic.List`1/Enumerator<UnityEngine.XR.XRDisplaySubsystem>&,UnityEngine.XR.XRDisplaySubsystem&,System.Boolean&,System.Boolean&), ref num3, ref num4, ref num13, ex3, ref list, ref enumerator, ref xrdisplaySubsystem, ref flag, ref flag2, EloranGunLib.DetachableResourceTypeIdStringSize[num3]);
							continue;
						}
						num4 = 119;
						num8 = num13;
						num12 = num8;
					}
					num14 = num3;
					num6 = num14;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num16 * 72 + 48 + num2);
						num18 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num16 * 72 + 8 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num9 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num7 * 72 + 40 + num2);
					num19 = num9;
					num18 = num12;
					num17 = 0;
					num16 = 2;
					for (;;)
					{
						num15 = (num17 + num16) / 2;
						num11 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num15 * 72 + 48 + num2);
						num6 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num15 * 72 + 8 + num2);
						if (num18 < num11 + num6)
						{
							if (num11 <= num18)
							{
								break;
							}
							num16 = num15 - 1;
						}
						else
						{
							num17 = num15 + 1;
						}
					}
					num7 = num15;
					num8 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num7 * 72 + 40 + num2);
					num9 = num8;
					num6 = num12;
					num11 = 0;
					num15 = 2;
					for (;;)
					{
						num16 = (num11 + num15) / 2;
						num17 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num16 * 56 + 40 + num2);
						num18 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num16 * 56 + 8 + num2);
						if (num6 < num17 + num18)
						{
							if (num17 <= num6)
							{
								break;
							}
							num15 = num16 - 1;
						}
						else
						{
							num11 = num16 + 1;
						}
					}
					num7 = num16;
					num5 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num7 * 56 + 32 + num2);
					num8 = num5;
					for (;;)
					{
						IL_A7E:
						if (array == null || (int)array[5] == 1)
						{
							num6 = num9;
							while (num6 != num19)
							{
								if (num6 != -1)
								{
									num6 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num6 + 56 + num2);
								}
								else
								{
									num11 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 48 + num2);
									if (num11 != -1)
									{
										goto Block_62;
									}
									num19 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 56 + num2);
									goto IL_A7E;
								}
							}
							goto IL_C1B;
						}
						int num20 = (int)array[6];
						int num21;
						if (num19 == -1)
						{
							num21 = -1;
						}
						else
						{
							num22 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 24 + num2);
							num18 = 0;
							num17 = 2;
							for (;;)
							{
								num16 = (num18 + num17) / 2;
								num15 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num16 * 56 + 40 + num2);
								num11 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num16 * 56 + 8 + num2);
								if (num22 < num15 + num11)
								{
									if (num15 <= num22)
									{
										break;
									}
									num17 = num16 - 1;
								}
								else
								{
									num18 = num16 + 1;
								}
							}
							num5 = num16;
							num7 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num5 * 56 + 32 + num2);
							num21 = num7;
						}
						if (num20 == num21)
						{
							num7 = num9;
							while (num7 != num19)
							{
								if (num7 != -1)
								{
									num7 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num7 + 56 + num2);
								}
								else
								{
									num5 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 48 + num2);
									if (num5 != -1)
									{
										goto Block_58;
									}
									num19 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 56 + num2);
									goto IL_A7E;
								}
							}
							break;
						}
						if ((int)array[6] == num8)
						{
							goto Block_59;
						}
						array = (object[])array[1];
					}
					num3 = num12;
					continue;
					Block_58:
					num6 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num5 + 24 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[1] = array;
					array2[7] = num12;
					array2[6] = num5;
					array2[2] = 2;
					array = array2;
					num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num5 + 24 + num2);
					continue;
					Block_59:
					num3 = num12;
					continue;
					IL_C1B:
					num3 = num12;
					continue;
					Block_62:
					num15 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num11 + 24 + num2);
					array2 = new object[8];
					array2[5] = 1;
					array2[1] = array;
					array2[7] = num12;
					array2[6] = num11;
					array2[2] = 2;
					array = array2;
					num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num11 + 24 + num2);
				}
				num4 = 119;
				return result;
				IL_1D4:
				if (num15 != -1)
				{
					goto IL_1DF;
				}
				goto IL_408;
				IL_1DF:
				num6 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num15 + 8 + num2);
				if (3 == num6)
				{
					goto IL_1FD;
				}
				if (0 == num6)
				{
					goto IL_38F;
				}
				goto IL_408;
				IL_1FD:
				num11 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num15 + 40 + num2);
				if (num11 == -1)
				{
					goto IL_24B;
				}
				Type[] array3;
				Type type;
				if ((type = array3[num11]) != null)
				{
					goto IL_231;
				}
				RuntimeTypeHandle[] array4;
				array3[num11] = Type.GetTypeFromHandle(array4[num11]);
				type = array3[num11];
				IL_231:
				if (type.IsInstanceOfType(array2[4]))
				{
					goto IL_24B;
				}
				num15 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num15 + 56 + num2);
				goto IL_1D4;
				IL_24B:
				num19 = num15;
				num14 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 48 + num2) + 56 + num2);
				num7 = (int)array2[3];
				IL_26F:
				if (num7 != num14)
				{
					goto IL_2EE;
				}
				num16 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 24 + num2);
				ex3 = array2[4];
				array = (object[])array[1];
				object[] array5 = new object[8];
				array5[5] = 0;
				array5[1] = array;
				array5[4] = array2[4];
				array5[3] = (int)array2[3];
				array5[6] = num19;
				array5[2] = 1;
				array = array5;
				num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 24 + num2);
				goto IL_1A;
				IL_2EE:
				num9 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num7 + 48 + num2);
				if (num9 == -1)
				{
					goto IL_37D;
				}
				num16 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num9 + 24 + num2);
				array = (object[])array[1];
				array5 = new object[8];
				array5[5] = 0;
				array5[1] = array;
				array5[4] = array2[4];
				array5[3] = (int)array2[3];
				array5[6] = num9;
				array5[0] = num19;
				array5[2] = 2;
				array = array5;
				num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num9 + 24 + num2);
				goto IL_1A;
				IL_37D:
				num7 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num7 + 56 + num2);
				goto IL_26F;
				IL_38F:
				num16 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num15 + 32 + num2);
				ex3 = array2[4];
				array = (object[])array[1];
				array5 = new object[8];
				array5[5] = 0;
				array5[1] = array;
				array5[4] = array2[4];
				array5[3] = (int)array2[3];
				array5[6] = num15;
				array5[2] = 0;
				array = array5;
				num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num15 + 32 + num2);
				goto IL_1A;
				IL_408:
				array = (object[])array[1];
				ex = array2[4];
				int num23 = (int)array2[3];
				IL_427:
				num15 = num3;
				num16 = num15;
				num17 = 0;
				num18 = 2;
				IL_435:
				num8 = (num17 + num18) / 2;
				num5 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num8 * 72 + 48 + num2);
				num22 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num8 * 72 + 8 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_47A;
				}
				if (num5 > num16)
				{
					goto IL_482;
				}
				num14 = num8;
				num19 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 152 + num14 * 72 + 40 + num2);
				num11 = num19;
				num7 = num11;
				goto IL_4AA;
				IL_47A:
				num17 = num8 + 1;
				goto IL_435;
				IL_482:
				num18 = num8 - 1;
				goto IL_435;
				IL_4AA:
				if (array != null)
				{
					goto IL_4B5;
				}
				goto IL_642;
				IL_4B5:
				if ((int)array[5] != 1)
				{
					goto IL_574;
				}
				int num24 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_4D9;
				}
				int num25 = -1;
				goto IL_55B;
				IL_4D9:
				int num26 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num11 + 24 + num2);
				num22 = 0;
				num5 = 2;
				IL_4EC:
				num8 = (num22 + num5) / 2;
				num18 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num8 * 56 + 40 + num2);
				num17 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num8 * 56 + 8 + num2);
				if (num26 >= num18 + num17)
				{
					goto IL_531;
				}
				if (num18 > num26)
				{
					goto IL_539;
				}
				num19 = num8;
				num14 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num19 * 56 + 32 + num2);
				num25 = num14;
				goto IL_55B;
				IL_531:
				num22 = num8 + 1;
				goto IL_4EC;
				IL_539:
				num5 = num8 - 1;
				goto IL_4EC;
				IL_55B:
				if (num24 != num25)
				{
					goto IL_563;
				}
				goto IL_642;
				IL_563:
				array = (object[])array[1];
				goto IL_4AA;
				IL_574:
				num9 = (int)array[2];
				if (num9 == 1 || num9 == 2)
				{
					goto IL_595;
				}
				if (num9 != 0)
				{
					goto IL_594;
				}
				array2 = array;
				num15 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + (int)array2[6] + 56 + num2);
				goto IL_1D4;
				IL_594:
				IL_595:
				int num27 = (int)array[6];
				if (num11 != -1)
				{
					goto IL_5AA;
				}
				int num28 = -1;
				goto IL_62C;
				IL_5AA:
				num16 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num11 + 24 + num2);
				num17 = 0;
				num18 = 2;
				IL_5BD:
				num8 = (num17 + num18) / 2;
				num5 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num8 * 56 + 40 + num2);
				num22 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num8 * 56 + 8 + num2);
				if (num16 >= num5 + num22)
				{
					goto IL_602;
				}
				if (num5 > num16)
				{
					goto IL_60A;
				}
				num14 = num8;
				num19 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + 368 + num14 * 56 + 32 + num2);
				num28 = num19;
				goto IL_62C;
				IL_602:
				num17 = num8 + 1;
				goto IL_5BD;
				IL_60A:
				num18 = num8 - 1;
				goto IL_5BD;
				IL_62C:
				if (num27 != num28)
				{
					goto IL_631;
				}
				goto IL_642;
				IL_631:
				array = (object[])array[1];
				goto IL_4AA;
				IL_642:
				if (-1 != num11)
				{
					goto IL_6E6;
				}
				num19 = num7;
				IL_64F:
				if (num19 != -1)
				{
					goto IL_65B;
				}
				num10 = 1;
				throw ex;
				IL_65B:
				num14 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 48 + num2);
				if (num14 == -1)
				{
					goto IL_6D4;
				}
				num26 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num14 + 24 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[1] = array;
				array2[4] = ex;
				array2[3] = num7;
				array2[6] = -1;
				array2[0] = -1;
				array2[2] = 1;
				array = array2;
				num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num14 + 24 + num2);
				goto IL_1A;
				IL_6D4:
				num19 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num19 + 56 + num2);
				goto IL_64F;
				IL_6E6:
				num6 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num11 + 16 + num2);
				num16 = num6;
				IL_6F7:
				if (num16 != -1)
				{
					goto IL_70E;
				}
				num11 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num11 + 56 + num2);
				goto IL_4AA;
				IL_70E:
				num18 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num16 + 8 + num2);
				if (3 == num18)
				{
					goto IL_738;
				}
				if (0 == num18)
				{
					goto IL_8A6;
				}
				num11 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num11 + 56 + num2);
				goto IL_4AA;
				IL_738:
				num17 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num16 + 40 + num2);
				if (num17 == -1)
				{
					goto IL_787;
				}
				Type type2;
				if ((type2 = array3[num17]) != null)
				{
					goto IL_76C;
				}
				array3[num17] = Type.GetTypeFromHandle(array4[num17]);
				type2 = array3[num17];
				IL_76C:
				if (type2.IsInstanceOfType(ex))
				{
					goto IL_787;
				}
				num16 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num16 + 56 + num2);
				goto IL_6F7;
				IL_787:
				num26 = num16;
				num22 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num26 + 48 + num2) + 56 + num2);
				num5 = (num7 - num23) * ((num23 == -1) ? 1 : 0) + num23;
				IL_7B0:
				if (num5 != num22)
				{
					goto IL_819;
				}
				int num29 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num26 + 24 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[1] = array;
				array2[4] = ex;
				array2[3] = num7;
				array2[6] = num26;
				array2[2] = 1;
				array = array2;
				num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num26 + 24 + num2);
				goto IL_1A;
				IL_819:
				num8 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num5 + 48 + num2);
				if (num8 == -1)
				{
					goto IL_894;
				}
				num29 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num8 + 24 + num2);
				array2 = new object[8];
				array2[5] = 0;
				array2[1] = array;
				array2[4] = ex;
				array2[3] = num7;
				array2[6] = num8;
				array2[0] = num26;
				array2[2] = 2;
				array = array2;
				num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num8 + 24 + num2);
				goto IL_1A;
				IL_894:
				num5 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num5 + 56 + num2);
				goto IL_7B0;
				IL_8A6:
				num29 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num16 + 32 + num2);
				ex3 = ex;
				array2 = new object[8];
				array2[5] = 0;
				array2[1] = array;
				array2[4] = ex;
				array2[3] = num7;
				array2[6] = num16;
				array2[2] = 0;
				array = array2;
				num3 = *(ref BuiltinPerformanceMonitoringUsersSidHeaderNamespace.FailIgnoreHashMembershipCondition + num16 + 32 + num2);
				goto IL_1A;
			}
			catch (Exception ex4)
			{
				int num10;
				if (num10 != 1)
				{
					Exception ex = ex4;
					int num23 = -1;
					goto IL_427;
				}
				throw ex4;
			}
			return result;
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00005EB8 File Offset: 0x000040B8
		// Note: this type is marked as 'beforefieldinit'.
		static EloranGunLib()
		{
			EloranGunLib.OpenStandardErrorgetDriveFormat();
			int num = 150;
			int num2 = 150;
			num2 = 150;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 150;
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00005F00 File Offset: 0x00004100
		private static IEnumerator AnimateLineGradient(LineRenderer lineRenderer, Color32 startColor, Color32 endColor)
		{
			int num = 31;
			int num2 = 31;
			num2 = 31;
			IEnumerator result;
			while (num2 != 0)
			{
				int num3;
				result = calli(System.Collections.IEnumerator(System.Int32&,System.Int32&,System.Int32&,UnityEngine.LineRenderer,UnityEngine.Color32,UnityEngine.Color32), ref num, ref num2, ref num3, lineRenderer, startColor, endColor, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 31;
			return result;
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00005F3C File Offset: 0x0000413C
		private static bool MarkUsedAsyncCausalityRelation(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			A_1 = 4;
			A_2 = 127;
			bool result;
			return result;
		}

		// Token: 0x0600005F RID: 95 RVA: 0x00005F64 File Offset: 0x00004164
		private static void TypeSpecgetException(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			A_0 = 104;
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00005F7C File Offset: 0x0000417C
		private static void StoreTransactionDataCMSFILEWRITABLETYPENOTWRITABLE(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever != GorillaTagger.Instance.offlineVRRig;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 5 + 141;
			A_0 = num;
		}

		// Token: 0x06000061 RID: 97 RVA: 0x00005FEC File Offset: 0x000041EC
		public static void ToggleParticles()
		{
			int num = 110;
			int num2 = 110;
			num2 = 110;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				EloranGunLib eloranGunLib;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,gunlibary.EloranGunLib&), ref num, ref num2, ref num3, ref flag, ref eloranGunLib, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 110;
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00006028 File Offset: 0x00004228
		private static void TokenPrivilegesgetIsAnsiClass(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			A_6.material = new Material(A_11);
			A_6.material.renderQueue = 3000;
			A_6.startColor = Color.Lerp(Color.green, Color.cyan, Mathf.PingPong(Time.time, 1f));
			A_6.endColor = Color.Lerp(Color.green, Color.cyan, Mathf.PingPong(Time.time, 1f));
			LineRenderer lineRenderer = new GameObject().AddComponent<LineRenderer>();
			A_13 = lineRenderer;
			A_13.transform.parent = A_5.transform;
			Vector3[] array = new Vector3[5];
			A_14 = array;
			A_14[0] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (-A_10 / 2f - 0.02f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (A_9 / 2f + 0.02f);
			A_14[1] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (A_10 / 2f + 0.02f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (A_9 / 2f + 0.02f);
			A_14[2] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (A_10 / 2f + 0.02f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (-A_9 / 2f - 0.02f);
			A_14[3] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (-A_10 / 2f - 0.02f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (-A_9 / 2f - 0.02f);
			A_14[4] = A_14[0];
			A_13.positionCount = A_14.Length;
			A_13.SetPositions(A_14);
			A_13.startWidth = 0.01f;
			A_13.endWidth = 0.01f;
			Shader shader = Shader.Find("Sprites/Default");
			A_15 = shader;
			bool flag = A_15 != null;
			A_16 = flag;
			int num = ((!A_16) ? 1 : 0) * 1 + 144;
			A_0 = num;
		}

		// Token: 0x06000063 RID: 99 RVA: 0x000063F8 File Offset: 0x000045F8
		private static void IncludeSectgetDeclaredFields(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever == null;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 77;
			A_0 = num;
		}

		// Token: 0x06000064 RID: 100 RVA: 0x0000645C File Offset: 0x0000465C
		private static void ArgumentOutOfRangeExceptionBaseFormattingOptions(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref ParticleSystem.MainModule A_4, ref ParticleSystem.EmissionModule A_5, ref ParticleSystem.ShapeModule A_6, ref ParticleSystemRenderer A_7, GameObject A_8)
		{
			A_1 = 0;
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00006474 File Offset: 0x00004674
		private static void GetKeyAlgorithmHaveYear(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			A_1 = 0;
		}

		// Token: 0x06000066 RID: 102 RVA: 0x0000648C File Offset: 0x0000468C
		private static void MatchExactVersionVTLPWSTR(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever == null;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 77;
			A_0 = num;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x000064F0 File Offset: 0x000046F0
		private static void getPayloadNamesFormatSerialization(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			int num = ((!Physics.Raycast(A_3.origin, A_3.direction, ref A_5, float.PositiveInfinity, -32777)) ? 1 : 0) * 1 + 71;
			A_0 = num;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00006554 File Offset: 0x00004754
		private static void CleanupPointer()
		{
			int num = 106;
			int num2 = 106;
			num2 = 106;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 106;
		}

		// Token: 0x06000069 RID: 105 RVA: 0x0000658C File Offset: 0x0000478C
		private static void ContainsNonCodeAccessPermissionsPopDirectionIsolate(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.CreatePointer();
			bool flag = A_5;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 10 + 43;
			A_0 = num;
		}

		// Token: 0x0600006A RID: 106 RVA: 0x000065F4 File Offset: 0x000047F4
		private static void GetILAsByteArrayAppId(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6 + Mathf.Sin(Time.time * A_3) * 0f);
			A_9 = vector;
			A_0 = 17;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00006650 File Offset: 0x00004850
		private static void FileAttributesAssemblyRequestEntry(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref LineRenderer A_4, ref Shader A_5, ref bool A_6, ref EloranGunLib A_7)
		{
			EloranGunLib.lr = Vector3.Lerp(EloranGunLib.lr, (GorillaTagger.Instance.rightHandTransform.position + EloranGunLib.spherepointer.transform.position) / 2f, Time.deltaTime * 6f);
			GameObject gameObject = new GameObject("Line");
			A_3 = gameObject;
			LineRenderer lineRenderer = A_3.AddComponent<LineRenderer>();
			A_4 = lineRenderer;
			A_4.startWidth = 0.015f;
			A_4.endWidth = 0.015f;
			Shader shader = Shader.Find("GUI/Text Shader");
			A_5 = shader;
			bool flag = A_5 != null;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 1 + 108;
			A_0 = num;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x0000677C File Offset: 0x0000497C
		private static void SetStateMachineCMSENTRYPOINTFLAGCUSTOMUX(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			bool flag = A_5 < EloranGunLib.LineCurve;
			A_10 = flag;
			int num = (A_10 ? 1 : 0) * -14 + 19;
			A_0 = num;
		}

		// Token: 0x0600006E RID: 110 RVA: 0x00006818 File Offset: 0x00004A18
		public static void ToggleAnimationMode()
		{
			int num = 148;
			int num2 = 148;
			num2 = 148;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 148;
		}

		// Token: 0x0600006F RID: 111 RVA: 0x0000685C File Offset: 0x00004A5C
		private static void CMSFILEHASHALGORITHMSHAFileEntry(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = !EloranGunLib.particleSystem.isPlaying;
			A_16 = flag;
			int num = ((!A_16) ? 1 : 0) * 1 + 85;
			A_0 = num;
		}

		// Token: 0x06000070 RID: 112 RVA: 0x000068C8 File Offset: 0x00004AC8
		public static void start2guns(Action action, bool lockOn)
		{
			int num = 115;
			int num2 = 115;
			num2 = 115;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Action,System.Boolean), ref num, ref num2, ref num3, ref flag, action, lockOn, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 115;
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00006904 File Offset: 0x00004B04
		public EloranGunLib()
		{
			int num = 149;
			int num2 = 149;
			num2 = 149;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,gunlibary.EloranGunLib), ref num, ref num2, ref num3, this, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 149;
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00006948 File Offset: 0x00004B48
		public static void StartPcGun(Action action, bool LockOn)
		{
			int num = 67;
			int num2 = 67;
			num2 = 67;
			while (num2 != 0)
			{
				int num3;
				Ray ray;
				bool flag;
				RaycastHit raycastHit;
				bool flag2;
				bool flag3;
				EloranGunLib eloranGunLib;
				bool flag4;
				GameObject gameObject;
				LineRenderer lineRenderer;
				Shader shader;
				bool flag5;
				EloranGunLib eloranGunLib2;
				bool flag6;
				bool flag7;
				bool flag8;
				bool flag9;
				bool flag10;
				bool flag11;
				bool flag12;
				bool flag13;
				bool flag14;
				bool flag15;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Ray&,System.Boolean&,UnityEngine.RaycastHit&,System.Boolean&,System.Boolean&,gunlibary.EloranGunLib&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,UnityEngine.Shader&,System.Boolean&,gunlibary.EloranGunLib&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean,System.Action), ref num, ref num2, ref num3, ref ray, ref flag, ref raycastHit, ref flag2, ref flag3, ref eloranGunLib, ref flag4, ref gameObject, ref lineRenderer, ref shader, ref flag5, ref eloranGunLib2, ref flag6, ref flag7, ref flag8, ref flag9, ref flag10, ref flag11, ref flag12, ref flag13, ref flag14, ref flag15, LockOn, action, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 67;
		}

		// Token: 0x06000073 RID: 115 RVA: 0x000069AC File Offset: 0x00004BAC
		private static void UseGenitiveMonthSponsorInfo(ref int A_0, ref int A_1, ref int A_2, ref EloranGunLib A_3)
		{
			EloranGunLib.spherepointer = GameObject.CreatePrimitive(0);
			EloranGunLib.spherepointer.AddComponent<Renderer>();
			EloranGunLib.spherepointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			EloranGunLib.spherepointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			Object.Destroy(EloranGunLib.spherepointer.GetComponent<BoxCollider>());
			Object.Destroy(EloranGunLib.spherepointer.GetComponent<Rigidbody>());
			Object.Destroy(EloranGunLib.spherepointer.GetComponent<Collider>());
			EloranGunLib.lr = GorillaTagger.Instance.offlineVRRig.rightHandTransform.position;
			EloranGunLib eloranGunLib = EloranGunLib.spherepointer.AddComponent<EloranGunLib>();
			A_3 = eloranGunLib;
			A_3.StartCoroutine(EloranGunLib.PulsePointer(EloranGunLib.spherepointer));
			EloranGunLib.AddPointerParticles(EloranGunLib.spherepointer);
			A_1 = 0;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00006AAC File Offset: 0x00004CAC
		private static void EqualsExactCompressedStackRunData(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref EloranGunLib A_4)
		{
			EloranGunLib eloranGunLib = EloranGunLib.spherepointer.AddComponent<EloranGunLib>();
			A_4 = eloranGunLib;
			A_4.StartCoroutine(EloranGunLib.SmoothStopParticles());
			A_1 = 0;
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00006AF4 File Offset: 0x00004CF4
		private static void RestrictedErrorObjectCMSSECTIONENTRYIDMETADATA(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.LockedRigOrPlayerOrwhatever = A_5.collider.GetComponentInParent<VRRig>();
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever == GorillaTagger.Instance.offlineVRRig;
			A_21 = flag;
			int num = ((!A_21) ? 1 : 0) * 1 + 93;
			A_0 = num;
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00006B74 File Offset: 0x00004D74
		private static bool PrimarySidType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			A_0 = 124;
			bool result;
			return result;
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00006B90 File Offset: 0x00004D90
		private static void ComparisonResultReadOnlyArrayAttribute(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.particleSystem.Play();
			A_0 = 89;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00006BB8 File Offset: 0x00004DB8
		private static bool UIPermissionAttributeNativeNational(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			int num = (A_5.MoveNext() ? 1 : 0) * -4 + 125;
			A_0 = num;
			bool result;
			return result;
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00006C04 File Offset: 0x00004E04
		private static void AtEntitiesInstall(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			A_0 = 104;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00006C1C File Offset: 0x00004E1C
		private static void IIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGSEventCommandEventArgs(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.LockedRigOrPlayerOrwhatever = null;
			A_0 = 66;
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00006C3C File Offset: 0x00004E3C
		private static void IsolatedStorageContainmentGetNextArgType(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			A_1 = 0;
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00006C54 File Offset: 0x00004E54
		private static Vector3 JaggedIsHideBySig(ref int A_0, ref int A_1, ref int A_2, ref Vector3 A_3, float A_4, Vector3 A_5, Vector3 A_6, Vector3 A_7)
		{
			Vector3 vector = Mathf.Pow(1f - A_4, 2f) * A_5 + 2f * (1f - A_4) * A_4 * A_6 + Mathf.Pow(A_4, 2f) * A_7;
			A_3 = vector;
			A_0 = 3;
			Vector3 result;
			return result;
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00006CE0 File Offset: 0x00004EE0
		private static void tailHighNestedType(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			float num = (float)A_5 / (float)(EloranGunLib.LineCurve - 1);
			A_6 = num;
			EloranGunLib.AnimationMode animationMode = EloranGunLib.currentAnimationMode;
			A_7 = animationMode;
			EloranGunLib.AnimationMode animationMode2 = A_7;
			A_8 = animationMode2;
			int num2 = A_8 - EloranGunLib.AnimationMode.Wave;
			num2 = num2 - (num2 - 10) * ((num2 > 9) ? 1 : 0) + 20;
			A_0 = num2;
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00006D88 File Offset: 0x00004F88
		private static void TypeAnalysisTextElementEnumerator(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Action A_4, bool A_5)
		{
			bool flag = EloranGunLib.IsXRDeviceActive();
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 116;
			A_0 = num;
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00006DE4 File Offset: 0x00004FE4
		private static void TraceSynchronousWorkEndCreate(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6 + Mathf.Sin(Time.time * A_3) * 0f);
			A_9 = vector;
			A_0 = 17;
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00006E40 File Offset: 0x00005040
		private static void CleanupCodeUpdateTimeOut(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, -GorillaTagger.Instance.rightHandTransform.up, ref A_4, float.MaxValue);
			A_5 = flag;
			bool flag2 = EloranGunLib.spherepointer == null;
			A_6 = flag2;
			int num = ((!A_6) ? 1 : 0) * 1 + 41;
			A_0 = num;
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00006EE4 File Offset: 0x000050E4
		private static void DTStringAlgorithmClass(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref EloranGunLib A_4)
		{
			bool flag = false;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 113;
			A_0 = num;
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00006F40 File Offset: 0x00005140
		private static void setVariantTypegetCanTimeout(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.LockedRigOrPlayerOrwhatever = null;
			A_0 = 66;
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00006F60 File Offset: 0x00005160
		private static void AndIContributeObjectSink(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			A_6.material.renderQueue = 3000;
			A_6.startColor = Color.Lerp(Color.green, Color.cyan, Mathf.PingPong(Time.time, 1f));
			A_6.endColor = Color.Lerp(Color.green, Color.cyan, Mathf.PingPong(Time.time, 1f));
			LineRenderer lineRenderer = new GameObject().AddComponent<LineRenderer>();
			A_13 = lineRenderer;
			A_13.transform.parent = A_5.transform;
			Vector3[] array = new Vector3[5];
			A_14 = array;
			A_14[0] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (-A_10 / 2f - 0.02f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (A_9 / 2f + 0.02f);
			A_14[1] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (A_10 / 2f + 0.02f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (A_9 / 2f + 0.02f);
			A_14[2] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (A_10 / 2f + 0.02f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (-A_9 / 2f - 0.02f);
			A_14[3] = A_7 + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.right * (-A_10 / 2f - 0.02f) + EloranGunLib.LockedRigOrPlayerOrwhatever.transform.up * (-A_9 / 2f - 0.02f);
			A_14[4] = A_14[0];
			A_13.positionCount = A_14.Length;
			A_13.SetPositions(A_14);
			A_13.startWidth = 0.01f;
			A_13.endWidth = 0.01f;
			Shader shader = Shader.Find("Sprites/Default");
			A_15 = shader;
			bool flag = A_15 != null;
			A_16 = flag;
			int num = ((!A_16) ? 1 : 0) * 1 + 144;
			A_0 = num;
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00007310 File Offset: 0x00005510
		private static void GetDataPolicyRights(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.HandleLineRendering();
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 7 + 54;
			A_0 = num;
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00007380 File Offset: 0x00005580
		private static void RfcPatterngetIsSingleByte(ref int A_0, ref int A_1, ref int A_2, EloranGunLib A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000086 RID: 134 RVA: 0x000073A4 File Offset: 0x000055A4
		private static void setFormatSetLastAccessTimeUtc(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.CleanupPointer();
			A_1 = 0;
		}

		// Token: 0x06000087 RID: 135 RVA: 0x000073C4 File Offset: 0x000055C4
		private static void AllocationExceededsetDecoderFallback(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib eloranGunLib = A_10.AddComponent<EloranGunLib>();
			A_14 = eloranGunLib;
			A_14.StartCoroutine(EloranGunLib.StartCurvyLineRenderer(A_11, GorillaTagger.Instance.rightHandTransform.position, EloranGunLib.lr, EloranGunLib.spherepointer.transform.position, EloranGunLib.LineColorStart, EloranGunLib.LineColorEnd));
			A_14.StartCoroutine(EloranGunLib.AnimateLineGradient(A_11, EloranGunLib.LineColorStart, EloranGunLib.LineColorEnd));
			bool hasChanged = EloranGunLib.spherepointer.transform.hasChanged;
			A_15 = hasChanged;
			int num = ((!A_15) ? 1 : 0) * 5 + 82;
			A_0 = num;
		}

		// Token: 0x06000088 RID: 136 RVA: 0x000074BC File Offset: 0x000056BC
		private static void setPrimaryIdentitySelectorASSEMBLYFLAGSTOKENMASK(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			A_1 = 0;
		}

		// Token: 0x06000089 RID: 137 RVA: 0x000074D4 File Offset: 0x000056D4
		private static void ResolvePolicygetHasProperties(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = false;
			A_16 = flag;
			int num = ((!A_16) ? 1 : 0) * 1 + 85;
			A_0 = num;
		}

		// Token: 0x0600008A RID: 138 RVA: 0x00007530 File Offset: 0x00005730
		private static void DispatchMessageEnumConnections(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.lr = Vector3.Lerp(EloranGunLib.lr, (GorillaTagger.Instance.rightHandTransform.position + EloranGunLib.spherepointer.transform.position) / 2f, Time.deltaTime * 6f);
			GameObject gameObject = new GameObject("Line");
			A_10 = gameObject;
			LineRenderer lineRenderer = A_10.AddComponent<LineRenderer>();
			A_11 = lineRenderer;
			A_11.startWidth = 0.015f;
			A_11.endWidth = 0.015f;
			Shader shader = Shader.Find("GUI/Text Shader");
			A_12 = shader;
			bool flag = A_12 != null;
			A_13 = flag;
			int num = ((!A_13) ? 1 : 0) * 1 + 80;
			A_0 = num;
		}

		// Token: 0x0600008B RID: 139 RVA: 0x0000765C File Offset: 0x0000585C
		private static void getAccessibleNumberStyles(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref ParticleSystem.MainModule A_4, ref ParticleSystem.EmissionModule A_5, ref ParticleSystem.ShapeModule A_6, ref ParticleSystemRenderer A_7, GameObject A_8)
		{
			EloranGunLib.particleSystem = A_8.AddComponent<ParticleSystem>();
			ParticleSystem.MainModule main = EloranGunLib.particleSystem.main;
			A_4 = main;
			A_4.startColor = new ParticleSystem.MinMaxGradient(EloranGunLib.PointerColorStart, EloranGunLib.PointerColorEnd);
			A_4.startSize = 0.1f;
			A_4.startSpeed = 1.5f;
			A_4.maxParticles = 100;
			A_4.duration = 1f;
			A_4.loop = true;
			A_4.simulationSpace = 1;
			ParticleSystem.EmissionModule emission = EloranGunLib.particleSystem.emission;
			A_5 = emission;
			A_5.rateOverTime = 20f;
			ParticleSystem.ShapeModule shape = EloranGunLib.particleSystem.shape;
			A_6 = shape;
			A_6.shapeType = 0;
			A_6.radius = 0.05f;
			ParticleSystemRenderer component = EloranGunLib.particleSystem.GetComponent<ParticleSystemRenderer>();
			A_7 = component;
			A_7.material = new Material(Shader.Find("Sprites/Default"));
			A_1 = 0;
		}

		// Token: 0x0600008C RID: 140 RVA: 0x000077C4 File Offset: 0x000059C4
		private static void NSgetMonthDayPattern(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.particleSystem.Stop();
			Object.Destroy(A_11, Time.deltaTime);
			bool isPressed = Mouse.current.leftButton.isPressed;
			A_18 = isPressed;
			int num = ((!A_18) ? 1 : 0) * 9 + 90;
			A_0 = num;
		}

		// Token: 0x0600008D RID: 141 RVA: 0x0000784C File Offset: 0x00005A4C
		private static void CalendarLocalizationResources(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.spherepointer.transform.position = EloranGunLib.LockedRigOrPlayerOrwhatever.transform.position;
			EloranGunLib.lr = Vector3.Lerp(EloranGunLib.lr, (GorillaTagger.Instance.rightHandTransform.position + EloranGunLib.spherepointer.transform.position) / 2f, Time.deltaTime * 6f);
			GameObject gameObject = new GameObject("Line");
			A_10 = gameObject;
			LineRenderer lineRenderer = A_10.AddComponent<LineRenderer>();
			A_11 = lineRenderer;
			A_11.startWidth = 0.015f;
			A_11.endWidth = 0.015f;
			Shader shader = Shader.Find("GUI/Text Shader");
			A_12 = shader;
			bool flag = A_12 != null;
			A_13 = flag;
			int num = ((!A_13) ? 1 : 0) * 1 + 80;
			A_0 = num;
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00007998 File Offset: 0x00005B98
		private static void HandleLineRendering()
		{
			int num = 107;
			int num2 = 107;
			num2 = 107;
			while (num2 != 0)
			{
				int num3;
				GameObject gameObject;
				LineRenderer lineRenderer;
				Shader shader;
				bool flag;
				EloranGunLib eloranGunLib;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,UnityEngine.Shader&,System.Boolean&,gunlibary.EloranGunLib&), ref num, ref num2, ref num3, ref gameObject, ref lineRenderer, ref shader, ref flag, ref eloranGunLib, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 107;
		}

		// Token: 0x0600008F RID: 143 RVA: 0x000079D8 File Offset: 0x00005BD8
		private static void PermissionSetEnumeratorTimeoutException(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			A_13.material = new Material(A_15);
			A_13.material.renderQueue = 3000;
			A_13.startColor = Color.Lerp(Color.yellow, Color.magenta, Mathf.PingPong(Time.time, 1f));
			A_13.endColor = Color.Lerp(Color.yellow, Color.magenta, Mathf.PingPong(Time.time, 1f));
			A_5.transform.position = EloranGunLib.LockedRigOrPlayerOrwhatever.transform.position;
			A_5.transform.rotation = GorillaTagger.Instance.offlineVRRig.headMesh.transform.rotation;
			EloranGunLib eloranGunLib = A_5.AddComponent<EloranGunLib>();
			A_17 = eloranGunLib;
			A_17.StartCoroutine(EloranGunLib.AnimateBox(A_5, A_13));
			Object.Destroy(A_5, 0.05f);
			A_1 = 0;
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00007B2C File Offset: 0x00005D2C
		private static void RemoveNamedPermissionSetgetTypeInformation(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			A_17.Invoke();
			A_0 = 63;
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00007B50 File Offset: 0x00005D50
		private static void OnlyGACDomainNeutralLinux(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.LockedRigOrPlayerOrwhatever = null;
			A_0 = 104;
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00007B70 File Offset: 0x00005D70
		private static IEnumerator IncreaseQuotaToControlFlags(ref int A_0, ref int A_1, ref int A_2, LineRenderer A_3, Vector3 A_4, Vector3 A_5, Vector3 A_6, Color32 A_7, Color32 A_8)
		{
			EloranGunLib.<StartCurvyLineRenderer>d__27 <StartCurvyLineRenderer>d__ = new EloranGunLib.<StartCurvyLineRenderer>d__27(0);
			<StartCurvyLineRenderer>d__.lineRenderer = A_3;
			<StartCurvyLineRenderer>d__.start = A_4;
			<StartCurvyLineRenderer>d__.mid = A_5;
			<StartCurvyLineRenderer>d__.end = A_6;
			<StartCurvyLineRenderer>d__.startColor = A_7;
			<StartCurvyLineRenderer>d__.endColor = A_8;
			A_1 = 0;
			return <StartCurvyLineRenderer>d__;
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00007BD0 File Offset: 0x00005DD0
		private static void ResourceLocationProviderType(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.spherepointer == null;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 3 + 73;
			A_0 = num;
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00007C38 File Offset: 0x00005E38
		private static bool FoundDatePatternIsLastFrameFromForeignExceptionStackTrace(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			List<XRDisplaySubsystem> list = new List<XRDisplaySubsystem>();
			A_4 = list;
			SubsystemManager.GetInstances<XRDisplaySubsystem>(A_4);
			List<XRDisplaySubsystem>.Enumerator enumerator = A_4.GetEnumerator();
			A_5 = enumerator;
			A_0 = 120;
			bool result;
			return result;
		}

		// Token: 0x06000095 RID: 149 RVA: 0x00007C9C File Offset: 0x00005E9C
		private static Vector3 CalculateBezierPoint(Vector3 start, Vector3 mid, Vector3 end, float t)
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			Vector3 result;
			while (num2 != 0)
			{
				int num3;
				Vector3 vector;
				result = calli(UnityEngine.Vector3(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Vector3&,System.Single,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3), ref num, ref num2, ref num3, ref vector, t, start, mid, end, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 2;
			return result;
		}

		// Token: 0x06000096 RID: 150 RVA: 0x00007CD8 File Offset: 0x00005ED8
		private static void ContractOptionAttributeAllowOnlyFipsAlgorithms(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			EloranGunLib.HandleLineRendering();
			bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
			A_11 = flag;
			int num = ((!A_11) ? 1 : 0) * 7 + 54;
			A_0 = num;
		}

		// Token: 0x06000097 RID: 151 RVA: 0x00007D48 File Offset: 0x00005F48
		private static void NullableMarshalerSpecialNameAttribute(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.spherepointer == null;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 74;
			A_0 = num;
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00007DAC File Offset: 0x00005FAC
		private static void ValueObjectAceType(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref LineRenderer A_4, ref Shader A_5, ref bool A_6, ref EloranGunLib A_7)
		{
			A_4.material = new Material(A_5);
			EloranGunLib eloranGunLib = A_3.AddComponent<EloranGunLib>();
			A_7 = eloranGunLib;
			A_7.StartCoroutine(EloranGunLib.StartCurvyLineRenderer(A_4, GorillaTagger.Instance.rightHandTransform.position, EloranGunLib.lr, EloranGunLib.spherepointer.transform.position, EloranGunLib.LineColorStart, EloranGunLib.LineColorEnd));
			A_7.StartCoroutine(EloranGunLib.AnimateLineGradient(A_4, EloranGunLib.LineColorStart, EloranGunLib.LineColorEnd));
			Object.Destroy(A_4, Time.deltaTime);
			A_1 = 0;
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00007E88 File Offset: 0x00006088
		private static void getResourceLocationOnDeserialization(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref EloranGunLib A_4)
		{
			bool flag = EloranGunLib.particleSystem != null;
			A_3 = flag;
			int num = ((!A_3) ? 1 : 0) * 1 + 113;
			A_0 = num;
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00007EF0 File Offset: 0x000060F0
		private static void CurveLineRenderer(LineRenderer lineRenderer, Vector3 start, Vector3 mid, Vector3 end)
		{
			int num = 4;
			int num2 = 4;
			num2 = 4;
			while (num2 != 0)
			{
				int num3;
				float num4;
				float num5;
				int num6;
				float num7;
				EloranGunLib.AnimationMode animationMode;
				EloranGunLib.AnimationMode animationMode2;
				Vector3 vector;
				bool flag;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Single&,System.Single&,System.Int32&,System.Single&,gunlibary.EloranGunLib/AnimationMode&,gunlibary.EloranGunLib/AnimationMode&,UnityEngine.Vector3&,System.Boolean&,UnityEngine.LineRenderer,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3), ref num, ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref animationMode, ref animationMode2, ref vector, ref flag, lineRenderer, start, end, mid, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 4;
		}

		// Token: 0x0600009B RID: 155 RVA: 0x00007F38 File Offset: 0x00006138
		private static void ApplicationBaseValuefVersioned(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			A_1 = 0;
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00007F50 File Offset: 0x00006150
		private static void getImpersonationLevelsetAbbreviatedMonthGenitiveNames(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6);
			A_9 = vector;
			A_9.x += Mathf.Sin(6.2831855f * A_3 * A_6 + EloranGunLib.waveTimeOffset) * A_4;
			A_9.z += Mathf.Cos(6.2831855f * A_3 * A_6 + EloranGunLib.waveTimeOffset) * A_4;
			A_0 = 17;
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00008004 File Offset: 0x00006204
		private static void CounterSectionGetEventToken(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever != null;
			A_14 = flag;
			int num = ((!A_14) ? 1 : 0) * 1 + 62;
			A_0 = num;
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00008068 File Offset: 0x00006268
		public static void ChangePointerColor()
		{
			int num = 129;
			int num2 = 129;
			num2 = 129;
			while (num2 != 0)
			{
				int num3;
				Color32[] array;
				Color32 color;
				Color32 color2;
				bool flag;
				bool flag2;
				ParticleSystem.MainModule mainModule;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.Color32[]&,UnityEngine.Color32&,UnityEngine.Color32&,System.Boolean&,System.Boolean&,UnityEngine.ParticleSystem/MainModule&), ref num, ref num2, ref num3, ref array, ref color, ref color2, ref flag, ref flag2, ref mainModule, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 129;
		}

		// Token: 0x0600009F RID: 159 RVA: 0x000080B8 File Offset: 0x000062B8
		private static IEnumerator SmoothStopParticles()
		{
			int num = 38;
			int num2 = 38;
			num2 = 38;
			IEnumerator result;
			while (num2 != 0)
			{
				int num3;
				result = calli(System.Collections.IEnumerator(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 38;
			return result;
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x000080F0 File Offset: 0x000062F0
		private static void MetadataSectionKeyInfoElementPropagationFlags(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6);
			A_9 = vector;
			A_9.y += A_4 * (2f * Mathf.Abs(2f * (A_6 * A_3 - Mathf.Floor(A_6 * A_3 + 0.5f))) - 1f);
			A_0 = 17;
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00008190 File Offset: 0x00006390
		private static void DebugActivityIdCreated(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6);
			A_9 = vector;
			A_9.x += Mathf.Sin(A_6 * A_3 + EloranGunLib.waveTimeOffset) * A_4;
			A_9.y += Mathf.Cos(A_6 * A_3 + EloranGunLib.waveTimeOffset) * A_4;
			A_0 = 17;
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00008238 File Offset: 0x00006438
		private static void GetBooleanStoreDeploymentMetadataEnumeration(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = EloranGunLib.CalculateBezierPoint(A_12, A_14, A_13, A_6);
			A_9 = vector;
			A_0 = 17;
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x0000827C File Offset: 0x0000647C
		private static void MatchServicingValues(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref LineRenderer A_4, ref Shader A_5, ref bool A_6, ref EloranGunLib A_7)
		{
			EloranGunLib eloranGunLib = A_3.AddComponent<EloranGunLib>();
			A_7 = eloranGunLib;
			A_7.StartCoroutine(EloranGunLib.StartCurvyLineRenderer(A_4, GorillaTagger.Instance.rightHandTransform.position, EloranGunLib.lr, EloranGunLib.spherepointer.transform.position, EloranGunLib.LineColorStart, EloranGunLib.LineColorEnd));
			A_7.StartCoroutine(EloranGunLib.AnimateLineGradient(A_4, EloranGunLib.LineColorStart, EloranGunLib.LineColorEnd));
			Object.Destroy(A_4, Time.deltaTime);
			A_1 = 0;
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00008338 File Offset: 0x00006538
		private static void EncodingInfoFloat(ref int A_0, ref int A_1, ref int A_2, ref Color32[] A_3, ref Color32 A_4, ref Color32 A_5, ref bool A_6, ref bool A_7, ref ParticleSystem.MainModule A_8)
		{
			ParticleSystem.MainModule main = EloranGunLib.particleSystem.main;
			A_8 = main;
			A_8.startColor = new ParticleSystem.MinMaxGradient(A_4, A_5);
			A_1 = 0;
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00008398 File Offset: 0x00006598
		private static void UnalignedWednesday(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			A_11.positionCount = EloranGunLib.LineCurve;
			EloranGunLib.waveTimeOffset += Time.deltaTime * 2f;
			float num = 5f;
			A_3 = num;
			float num2 = 0.05f;
			A_4 = num2;
			int num3 = 0;
			A_5 = num3;
			A_0 = 18;
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x00008418 File Offset: 0x00006618
		private static IEnumerator setNumberFormatNativeVariant(ref int A_0, ref int A_1, ref int A_2, GameObject A_3)
		{
			EloranGunLib.<PulsePointer>d__28 <PulsePointer>d__ = new EloranGunLib.<PulsePointer>d__28(0);
			<PulsePointer>d__.pointer = A_3;
			A_1 = 0;
			return <PulsePointer>d__;
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x00008444 File Offset: 0x00006644
		private static void BidiCategoryProgIdRedirectionSection(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			Vector3 vector = Vector3.Lerp(A_12, A_13, A_6);
			A_9 = vector;
			A_9.y += Mathf.Abs(Mathf.Sin(A_6 * A_3 + EloranGunLib.waveTimeOffset) * A_4);
			A_0 = 17;
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x000084BC File Offset: 0x000066BC
		private static void IntegerStringBuilderAnsi(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			int num = ((!(EloranGunLib.LockedRigOrPlayerOrwhatever != null)) ? 1 : 0) * 1 + 139;
			A_0 = num;
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x00008504 File Offset: 0x00006704
		private static void getMemberInfoGetEncoding(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = A_5;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 10 + 43;
			A_0 = num;
		}

		// Token: 0x060000AA RID: 170 RVA: 0x00008564 File Offset: 0x00006764
		private static void TimeZoneTokenLayoutMask(ref int A_0, ref int A_1, ref int A_2, ref float A_3, ref float A_4, ref int A_5, ref float A_6, ref EloranGunLib.AnimationMode A_7, ref EloranGunLib.AnimationMode A_8, ref Vector3 A_9, ref bool A_10, LineRenderer A_11, Vector3 A_12, Vector3 A_13, Vector3 A_14)
		{
			A_0 = 16;
		}

		// Token: 0x060000AB RID: 171 RVA: 0x0000857C File Offset: 0x0000677C
		private static void getAsyncWaitHandleVariantBool(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			int num = ((!EloranGunLib.enableParticles) ? 1 : 0) * 1 + 83;
			A_0 = num;
		}

		// Token: 0x060000AC RID: 172 RVA: 0x000085C0 File Offset: 0x000067C0
		private static bool NameDependentOSMetadataDescription(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = false;
			A_8 = flag;
			A_0 = 128;
			bool result;
			return result;
		}

		// Token: 0x060000AD RID: 173 RVA: 0x000085F4 File Offset: 0x000067F4
		private static void IsErrorRedirectedDTSubString(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.LockedRigOrPlayerOrwhatever = null;
			A_0 = 104;
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00008614 File Offset: 0x00006814
		public static void StartVrGun(Action action, bool LockOn)
		{
			int num = 39;
			int num2 = 39;
			num2 = 39;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				RaycastHit raycastHit;
				bool flag2;
				bool flag3;
				bool flag4;
				bool flag5;
				bool flag6;
				bool flag7;
				bool flag8;
				bool flag9;
				bool flag10;
				bool flag11;
				bool flag12;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,UnityEngine.RaycastHit&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean&,System.Boolean,System.Action), ref num, ref num2, ref num3, ref flag, ref raycastHit, ref flag2, ref flag3, ref flag4, ref flag5, ref flag6, ref flag7, ref flag8, ref flag9, ref flag10, ref flag11, ref flag12, LockOn, action, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 39;
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00008668 File Offset: 0x00006868
		private static void MathTrimFree(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref bool A_4, ref GameObject A_5, ref LineRenderer A_6, ref Vector3 A_7, ref Vector3[] A_8, ref float A_9, ref float A_10, ref Shader A_11, ref bool A_12, ref LineRenderer A_13, ref Vector3[] A_14, ref Shader A_15, ref bool A_16, ref EloranGunLib A_17)
		{
			bool flag = false;
			A_4 = flag;
			int num = ((!A_4) ? 1 : 0) * 5 + 141;
			A_0 = num;
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x000086C4 File Offset: 0x000068C4
		private static void TypedByRefNumDatesep(ref int A_0, ref int A_1, ref int A_2)
		{
			EloranGunLib.LineCurve = 50;
			EloranGunLib.PointerColorStart = new Color32(41, 41, 41, byte.MaxValue);
			EloranGunLib.PointerColorEnd = new Color32(41, 41, 41, byte.MaxValue);
			EloranGunLib.LineColorStart = new Color32(41, 41, 41, byte.MaxValue);
			EloranGunLib.LineColorEnd = new Color32(41, 41, 41, byte.MaxValue);
			EloranGunLib.TriggeredPointerColorStart = new Color32(41, 41, 41, byte.MaxValue);
			EloranGunLib.TriggeredPointerColorEnd = new Color32(41, 41, 41, byte.MaxValue);
			EloranGunLib.enableParticles = false;
			EloranGunLib.waveTimeOffset = 0f;
			EloranGunLib.currentAnimationMode = EloranGunLib.AnimationMode.Static;
			EloranGunLib.ColorIndex = 0;
			A_1 = 0;
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x000087C4 File Offset: 0x000069C4
		private static void IncreaseBasePriorityHashElementTransformMetadataSize(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.spherepointer = GameObject.CreatePrimitive(0);
			EloranGunLib.spherepointer.AddComponent<Renderer>();
			EloranGunLib.spherepointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			EloranGunLib.spherepointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			Object.Destroy(EloranGunLib.spherepointer.GetComponent<BoxCollider>());
			Object.Destroy(EloranGunLib.spherepointer.GetComponent<Rigidbody>());
			Object.Destroy(EloranGunLib.spherepointer.GetComponent<Collider>());
			EloranGunLib.lr = GorillaTagger.Instance.offlineVRRig.rightHandTransform.position;
			EloranGunLib eloranGunLib = EloranGunLib.spherepointer.AddComponent<EloranGunLib>();
			A_8 = eloranGunLib;
			A_8.StartCoroutine(EloranGunLib.PulsePointer(EloranGunLib.spherepointer));
			EloranGunLib.AddPointerParticles(EloranGunLib.spherepointer);
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever == null;
			A_9 = flag;
			int num = ((!A_9) ? 1 : 0) * 1 + 77;
			A_0 = num;
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00008910 File Offset: 0x00006B10
		private static void UnadviseCMSSECTIONIDEVENTSECTION(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			A_0 = 63;
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00008928 File Offset: 0x00006B28
		private static bool MaxDefinedMetadataTokenType(ref int A_0, ref int A_1, ref int A_2, Exception A_3, ref List<XRDisplaySubsystem> A_4, ref List<XRDisplaySubsystem>.Enumerator A_5, ref XRDisplaySubsystem A_6, ref bool A_7, ref bool A_8)
		{
			bool flag = true;
			A_8 = flag;
			A_1 = 4;
			A_2 = 128;
			bool result;
			return result;
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00008964 File Offset: 0x00006B64
		private static void AddPointerParticles(GameObject pointer)
		{
			int num = 34;
			int num2 = 34;
			num2 = 34;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				ParticleSystem.MainModule mainModule;
				ParticleSystem.EmissionModule emissionModule;
				ParticleSystem.ShapeModule shapeModule;
				ParticleSystemRenderer particleSystemRenderer;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,UnityEngine.ParticleSystem/MainModule&,UnityEngine.ParticleSystem/EmissionModule&,UnityEngine.ParticleSystem/ShapeModule&,UnityEngine.ParticleSystemRenderer&,UnityEngine.GameObject), ref num, ref num2, ref num3, ref flag, ref mainModule, ref emissionModule, ref shapeModule, ref particleSystemRenderer, pointer, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 34;
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x000089A8 File Offset: 0x00006BA8
		private static void StringBuffersetTargetTypeName(ref int A_0, ref int A_1, ref int A_2, ref Color32[] A_3, ref Color32 A_4, ref Color32 A_5, ref bool A_6, ref bool A_7, ref ParticleSystem.MainModule A_8)
		{
			A_1 = 0;
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x000089C0 File Offset: 0x00006BC0
		private static void ManifestErrorVariantWrapper(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			bool flag = !A_16;
			A_13 = flag;
			int num = ((!A_13) ? 1 : 0) * 1 + 59;
			A_0 = num;
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x00008A24 File Offset: 0x00006C24
		private static void ComposeWithgetIdentityObject(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, Action A_4, bool A_5)
		{
			EloranGunLib.StartPcGun(A_4, A_5);
			A_1 = 0;
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x00008A4C File Offset: 0x00006C4C
		private static void EncodedArgumentProcessorFallbackListValid(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.LockedRigOrPlayerOrwhatever != null;
			A_22 = flag;
			int num = ((!A_22) ? 1 : 0) * 1 + 96;
			A_0 = num;
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00008AB0 File Offset: 0x00006CB0
		private static void CancellationTokengetDay(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			A_0 = 52;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00008AC8 File Offset: 0x00006CC8
		private static void CreatePointer()
		{
			int num = 105;
			int num2 = 105;
			num2 = 105;
			while (num2 != 0)
			{
				int num3;
				EloranGunLib eloranGunLib;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,gunlibary.EloranGunLib&), ref num, ref num2, ref num3, ref eloranGunLib, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 105;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00008B00 File Offset: 0x00006D00
		private static void getWrapperThreadStart(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			EloranGunLib.spherepointer.transform.position = EloranGunLib.LockedRigOrPlayerOrwhatever.transform.position;
			A_26.Invoke();
			A_0 = 104;
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00008B44 File Offset: 0x00006D44
		private static void setPermissionStategetUnmappedIdentities(ref int A_0, ref int A_1, ref int A_2, ref bool A_3, ref RaycastHit A_4, ref bool A_5, ref bool A_6, ref bool A_7, ref bool A_8, ref bool A_9, ref bool A_10, ref bool A_11, ref bool A_12, ref bool A_13, ref bool A_14, ref bool A_15, bool A_16, Action A_17)
		{
			A_0 = 66;
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00008B5C File Offset: 0x00006D5C
		private static void GetResultAddProperty(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = false;
			A_6 = flag;
			int num = ((!A_6) ? 1 : 0) * 3 + 73;
			A_0 = num;
		}

		// Token: 0x060000BE RID: 190 RVA: 0x00008BB8 File Offset: 0x00006DB8
		private static void IDLDESCGCLatencyMode(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			bool flag = EloranGunLib.enableParticles;
			A_17 = flag;
			int num = ((!A_17) ? 1 : 0) * 1 + 88;
			A_0 = num;
		}

		// Token: 0x060000BF RID: 191 RVA: 0x00008C14 File Offset: 0x00006E14
		private static void getChannelDataInvalidOperationCannotRemoveFromStackOrQueue(ref int A_0, ref int A_1, ref int A_2, ref Color32[] A_3, ref Color32 A_4, ref Color32 A_5, ref bool A_6, ref bool A_7, ref ParticleSystem.MainModule A_8)
		{
			bool flag = EloranGunLib.particleSystem != null;
			A_7 = flag;
			int num = ((!A_7) ? 1 : 0) * 1 + 132;
			A_0 = num;
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00008C78 File Offset: 0x00006E78
		private static void EnvironmentPermissiongetProgID(ref int A_0, ref int A_1, ref int A_2, ref Ray A_3, ref bool A_4, ref RaycastHit A_5, ref bool A_6, ref bool A_7, ref EloranGunLib A_8, ref bool A_9, ref GameObject A_10, ref LineRenderer A_11, ref Shader A_12, ref bool A_13, ref EloranGunLib A_14, ref bool A_15, ref bool A_16, ref bool A_17, ref bool A_18, ref bool A_19, ref bool A_20, ref bool A_21, ref bool A_22, ref bool A_23, ref bool A_24, bool A_25, Action A_26)
		{
			A_26.Invoke();
			A_0 = 104;
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00008C9C File Offset: 0x00006E9C
		public static void BoxESP()
		{
			int num = 135;
			int num2 = 135;
			num2 = 135;
			while (num2 != 0)
			{
				int num3;
				bool flag;
				bool flag2;
				GameObject gameObject;
				LineRenderer lineRenderer;
				Vector3 vector;
				Vector3[] array;
				float num4;
				float num5;
				Shader shader;
				bool flag3;
				LineRenderer lineRenderer2;
				Vector3[] array2;
				Shader shader2;
				bool flag4;
				EloranGunLib eloranGunLib;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,System.Boolean&,System.Boolean&,UnityEngine.GameObject&,UnityEngine.LineRenderer&,UnityEngine.Vector3&,UnityEngine.Vector3[]&,System.Single&,System.Single&,UnityEngine.Shader&,System.Boolean&,UnityEngine.LineRenderer&,UnityEngine.Vector3[]&,UnityEngine.Shader&,System.Boolean&,gunlibary.EloranGunLib&), ref num, ref num2, ref num3, ref flag, ref flag2, ref gameObject, ref lineRenderer, ref vector, ref array, ref num4, ref num5, ref shader, ref flag3, ref lineRenderer2, ref array2, ref shader2, ref flag4, ref eloranGunLib, EloranGunLib.DetachableResourceTypeIdStringSize[num]);
			}
			num2 = 135;
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x00008CFC File Offset: 0x00006EFC
		private static void OpenStandardErrorgetDriveFormat()
		{
			EloranGunLib.DetachableResourceTypeIdStringSize = new IntPtr[151];
			EloranGunLib.DetachableResourceTypeIdStringSize[0] = ldftn(FromAsyncTrimPromiseReflectionExtensions);
			EloranGunLib.DetachableResourceTypeIdStringSize[1] = ldftn(GetTargetTypeRef);
			EloranGunLib.DetachableResourceTypeIdStringSize[2] = ldftn(JaggedIsHideBySig);
			EloranGunLib.DetachableResourceTypeIdStringSize[3] = ldftn(setIsSecuredBaseName);
			EloranGunLib.DetachableResourceTypeIdStringSize[4] = ldftn(UnalignedWednesday);
			EloranGunLib.DetachableResourceTypeIdStringSize[5] = ldftn(tailHighNestedType);
			EloranGunLib.DetachableResourceTypeIdStringSize[6] = ldftn(TimeZoneTokenLayoutMask);
			EloranGunLib.DetachableResourceTypeIdStringSize[7] = ldftn(TraceSynchronousWorkEndCreate);
			EloranGunLib.DetachableResourceTypeIdStringSize[8] = ldftn(GetILAsByteArrayAppId);
			EloranGunLib.DetachableResourceTypeIdStringSize[9] = ldftn(ReleaseMutexVARDESC);
			EloranGunLib.DetachableResourceTypeIdStringSize[10] = ldftn(BidiCategoryProgIdRedirectionSection);
			EloranGunLib.DetachableResourceTypeIdStringSize[11] = ldftn(DebugActivityIdCreated);
			EloranGunLib.DetachableResourceTypeIdStringSize[12] = ldftn(NotAPortableExecutableImageLongPathDirectory);
			EloranGunLib.DetachableResourceTypeIdStringSize[13] = ldftn(getImpersonationLevelsetAbbreviatedMonthGenitiveNames);
			EloranGunLib.DetachableResourceTypeIdStringSize[14] = ldftn(getEventProviderEnvelope);
			EloranGunLib.DetachableResourceTypeIdStringSize[15] = ldftn(MetadataSectionKeyInfoElementPropagationFlags);
			EloranGunLib.DetachableResourceTypeIdStringSize[16] = ldftn(GetBooleanStoreDeploymentMetadataEnumeration);
			EloranGunLib.DetachableResourceTypeIdStringSize[17] = ldftn(IServerResponseChannelSinkStackBuiltinSystemOperatorsSid);
			EloranGunLib.DetachableResourceTypeIdStringSize[18] = ldftn(SetStateMachineCMSENTRYPOINTFLAGCUSTOMUX);
			EloranGunLib.DetachableResourceTypeIdStringSize[19] = ldftn(ApplicationBaseValuefVersioned);
			EloranGunLib.DetachableResourceTypeIdStringSize[20] = ldftn(TraceSynchronousWorkEndCreate);
			EloranGunLib.DetachableResourceTypeIdStringSize[21] = ldftn(GetILAsByteArrayAppId);
			EloranGunLib.DetachableResourceTypeIdStringSize[22] = ldftn(ReleaseMutexVARDESC);
			EloranGunLib.DetachableResourceTypeIdStringSize[23] = ldftn(BidiCategoryProgIdRedirectionSection);
			EloranGunLib.DetachableResourceTypeIdStringSize[24] = ldftn(DebugActivityIdCreated);
			EloranGunLib.DetachableResourceTypeIdStringSize[25] = ldftn(NotAPortableExecutableImageLongPathDirectory);
			EloranGunLib.DetachableResourceTypeIdStringSize[26] = ldftn(getImpersonationLevelsetAbbreviatedMonthGenitiveNames);
			EloranGunLib.DetachableResourceTypeIdStringSize[27] = ldftn(getEventProviderEnvelope);
			EloranGunLib.DetachableResourceTypeIdStringSize[28] = ldftn(MetadataSectionKeyInfoElementPropagationFlags);
			EloranGunLib.DetachableResourceTypeIdStringSize[29] = ldftn(GetBooleanStoreDeploymentMetadataEnumeration);
			EloranGunLib.DetachableResourceTypeIdStringSize[30] = ldftn(TimeZoneTokenLayoutMask);
			EloranGunLib.DetachableResourceTypeIdStringSize[31] = ldftn(AddAttributeRequireDashes);
			EloranGunLib.DetachableResourceTypeIdStringSize[32] = ldftn(IncreaseQuotaToControlFlags);
			EloranGunLib.DetachableResourceTypeIdStringSize[33] = ldftn(setNumberFormatNativeVariant);
			EloranGunLib.DetachableResourceTypeIdStringSize[34] = ldftn(GetMembersgetdefaultPermissionSetID);
			EloranGunLib.DetachableResourceTypeIdStringSize[35] = ldftn(IResourceReaderDataCollector);
			EloranGunLib.DetachableResourceTypeIdStringSize[36] = ldftn(getAccessibleNumberStyles);
			EloranGunLib.DetachableResourceTypeIdStringSize[37] = ldftn(ArgumentOutOfRangeExceptionBaseFormattingOptions);
			EloranGunLib.DetachableResourceTypeIdStringSize[38] = ldftn(IEnumSTOREASSEMBLYINSTALLATIONREFERENCEMessageDictionary);
			EloranGunLib.DetachableResourceTypeIdStringSize[39] = ldftn(DeploymentDataIConstantMembershipCondition);
			EloranGunLib.DetachableResourceTypeIdStringSize[40] = ldftn(CleanupCodeUpdateTimeOut);
			EloranGunLib.DetachableResourceTypeIdStringSize[41] = ldftn(ContainsNonCodeAccessPermissionsPopDirectionIsolate);
			EloranGunLib.DetachableResourceTypeIdStringSize[42] = ldftn(getMemberInfoGetEncoding);
			EloranGunLib.DetachableResourceTypeIdStringSize[43] = ldftn(getPerMilleSymbolArgsIsArray);
			EloranGunLib.DetachableResourceTypeIdStringSize[44] = ldftn(ExtractNameSpaceTaskToApm);
			EloranGunLib.DetachableResourceTypeIdStringSize[45] = ldftn(GetRuntimeDirectoryCreationTime);
			EloranGunLib.DetachableResourceTypeIdStringSize[46] = ldftn(SystemAlarmCallbackObjectYearDateSep);
			EloranGunLib.DetachableResourceTypeIdStringSize[47] = ldftn(GetConfigurationBytesCustomMarshaler);
			EloranGunLib.DetachableResourceTypeIdStringSize[48] = ldftn(IIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGSEventCommandEventArgs);
			EloranGunLib.DetachableResourceTypeIdStringSize[49] = ldftn(metwSessionIdTypesWhenNeeded);
			EloranGunLib.DetachableResourceTypeIdStringSize[50] = ldftn(CancellationTokengetDay);
			EloranGunLib.DetachableResourceTypeIdStringSize[51] = ldftn(getSetupInformationInternalApplicationIdentityHelper);
			EloranGunLib.DetachableResourceTypeIdStringSize[52] = ldftn(GetDataPolicyRights);
			EloranGunLib.DetachableResourceTypeIdStringSize[53] = ldftn(ContractOptionAttributeAllowOnlyFipsAlgorithms);
			EloranGunLib.DetachableResourceTypeIdStringSize[54] = ldftn(IsAutoLayoutGetSetMethod);
			EloranGunLib.DetachableResourceTypeIdStringSize[55] = ldftn(getmessageServerWellKnownEntry);
			EloranGunLib.DetachableResourceTypeIdStringSize[56] = ldftn(GetAssemblyManifestNativeSectionOffset);
			EloranGunLib.DetachableResourceTypeIdStringSize[57] = ldftn(FileSourceNamesetAbbreviatedMonthGenitiveNames);
			EloranGunLib.DetachableResourceTypeIdStringSize[58] = ldftn(ManifestErrorVariantWrapper);
			EloranGunLib.DetachableResourceTypeIdStringSize[59] = ldftn(RemoveNamedPermissionSetgetTypeInformation);
			EloranGunLib.DetachableResourceTypeIdStringSize[60] = ldftn(UnadviseCMSSECTIONIDEVENTSECTION);
			EloranGunLib.DetachableResourceTypeIdStringSize[61] = ldftn(CounterSectionGetEventToken);
			EloranGunLib.DetachableResourceTypeIdStringSize[62] = ldftn(setVariantTypegetCanTimeout);
			EloranGunLib.DetachableResourceTypeIdStringSize[63] = ldftn(setPermissionStategetUnmappedIdentities);
			EloranGunLib.DetachableResourceTypeIdStringSize[64] = ldftn(ApplicationTrustManagerIsDiscretionaryAclCanonical);
			EloranGunLib.DetachableResourceTypeIdStringSize[65] = ldftn(setFormatSetLastAccessTimeUtc);
			EloranGunLib.DetachableResourceTypeIdStringSize[66] = ldftn(setPrimaryIdentitySelectorASSEMBLYFLAGSTOKENMASK);
			EloranGunLib.DetachableResourceTypeIdStringSize[67] = ldftn(UIPermissionReadBlockAsyncInternald);
			EloranGunLib.DetachableResourceTypeIdStringSize[68] = ldftn(getActivityIdImageFileMachine);
			EloranGunLib.DetachableResourceTypeIdStringSize[69] = ldftn(getAttributeStringINormalizeForIsolatedStorage);
			EloranGunLib.DetachableResourceTypeIdStringSize[70] = ldftn(getPayloadNamesFormatSerialization);
			EloranGunLib.DetachableResourceTypeIdStringSize[71] = ldftn(ResourceLocationProviderType);
			EloranGunLib.DetachableResourceTypeIdStringSize[72] = ldftn(GetResultAddProperty);
			EloranGunLib.DetachableResourceTypeIdStringSize[73] = ldftn(NullableMarshalerSpecialNameAttribute);
			EloranGunLib.DetachableResourceTypeIdStringSize[74] = ldftn(IncreaseBasePriorityHashElementTransformMetadataSize);
			EloranGunLib.DetachableResourceTypeIdStringSize[75] = ldftn(MatchExactVersionVTLPWSTR);
			EloranGunLib.DetachableResourceTypeIdStringSize[76] = ldftn(IncludeSectgetDeclaredFields);
			EloranGunLib.DetachableResourceTypeIdStringSize[77] = ldftn(getHasCurrentArrayList);
			EloranGunLib.DetachableResourceTypeIdStringSize[78] = ldftn(CalendarLocalizationResources);
			EloranGunLib.DetachableResourceTypeIdStringSize[79] = ldftn(DispatchMessageEnumConnections);
			EloranGunLib.DetachableResourceTypeIdStringSize[80] = ldftn(getTypeNamegetIn);
			EloranGunLib.DetachableResourceTypeIdStringSize[81] = ldftn(AllocationExceededsetDecoderFallback);
			EloranGunLib.DetachableResourceTypeIdStringSize[82] = ldftn(getAsyncWaitHandleVariantBool);
			EloranGunLib.DetachableResourceTypeIdStringSize[83] = ldftn(CMSFILEHASHALGORITHMSHAFileEntry);
			EloranGunLib.DetachableResourceTypeIdStringSize[84] = ldftn(ResolvePolicygetHasProperties);
			EloranGunLib.DetachableResourceTypeIdStringSize[85] = ldftn(ComparisonResultReadOnlyArrayAttribute);
			EloranGunLib.DetachableResourceTypeIdStringSize[86] = ldftn(CountedMbcsStringTypeInitializer);
			EloranGunLib.DetachableResourceTypeIdStringSize[87] = ldftn(IDLDESCGCLatencyMode);
			EloranGunLib.DetachableResourceTypeIdStringSize[88] = ldftn(NSgetMonthDayPattern);
			EloranGunLib.DetachableResourceTypeIdStringSize[89] = ldftn(setApplicationNameTargetFrameworkName);
			EloranGunLib.DetachableResourceTypeIdStringSize[90] = ldftn(putSubscriptionIdCheckLevel);
			EloranGunLib.DetachableResourceTypeIdStringSize[91] = ldftn(IsAppEarlierThanWindowsPhoneMangoCOMServerImplementedClsid);
			EloranGunLib.DetachableResourceTypeIdStringSize[92] = ldftn(RestrictedErrorObjectCMSSECTIONENTRYIDMETADATA);
			EloranGunLib.DetachableResourceTypeIdStringSize[93] = ldftn(IsErrorRedirectedDTSubString);
			EloranGunLib.DetachableResourceTypeIdStringSize[94] = ldftn(ConsoleKeyIsFromThisAppDomain);
			EloranGunLib.DetachableResourceTypeIdStringSize[95] = ldftn(EncodedArgumentProcessorFallbackListValid);
			EloranGunLib.DetachableResourceTypeIdStringSize[96] = ldftn(getWrapperThreadStart);
			EloranGunLib.DetachableResourceTypeIdStringSize[97] = ldftn(AtEntitiesInstall);
			EloranGunLib.DetachableResourceTypeIdStringSize[98] = ldftn(EnvironmentPermissiongetProgID);
			EloranGunLib.DetachableResourceTypeIdStringSize[99] = ldftn(getGUIDBinaryTypeEnum);
			EloranGunLib.DetachableResourceTypeIdStringSize[100] = ldftn(OnlyGACDomainNeutralLinux);
			EloranGunLib.DetachableResourceTypeIdStringSize[101] = ldftn(TypeSpecgetException);
			EloranGunLib.DetachableResourceTypeIdStringSize[102] = ldftn(UnsafeDeserializeGetRuntimeResourceString);
			EloranGunLib.DetachableResourceTypeIdStringSize[103] = ldftn(DelegationEra);
			EloranGunLib.DetachableResourceTypeIdStringSize[104] = ldftn(GetKeyAlgorithmHaveYear);
			EloranGunLib.DetachableResourceTypeIdStringSize[105] = ldftn(UseGenitiveMonthSponsorInfo);
			EloranGunLib.DetachableResourceTypeIdStringSize[106] = ldftn(setDefaultThreadCurrentCultureRemotingServices);
			EloranGunLib.DetachableResourceTypeIdStringSize[107] = ldftn(FileAttributesAssemblyRequestEntry);
			EloranGunLib.DetachableResourceTypeIdStringSize[108] = ldftn(ValueObjectAceType);
			EloranGunLib.DetachableResourceTypeIdStringSize[109] = ldftn(MatchServicingValues);
			EloranGunLib.DetachableResourceTypeIdStringSize[110] = ldftn(RaiseOnDeserializingEventOrderablePartitioner);
			EloranGunLib.DetachableResourceTypeIdStringSize[111] = ldftn(getResourceLocationOnDeserialization);
			EloranGunLib.DetachableResourceTypeIdStringSize[112] = ldftn(DTStringAlgorithmClass);
			EloranGunLib.DetachableResourceTypeIdStringSize[113] = ldftn(EqualsExactCompressedStackRunData);
			EloranGunLib.DetachableResourceTypeIdStringSize[114] = ldftn(RegisterWithHostAutoResetEvent);
			EloranGunLib.DetachableResourceTypeIdStringSize[115] = ldftn(TypeAnalysisTextElementEnumerator);
			EloranGunLib.DetachableResourceTypeIdStringSize[116] = ldftn(AccessRuleFactoryAccountEnterpriseAdminsSid);
			EloranGunLib.DetachableResourceTypeIdStringSize[117] = ldftn(ComposeWithgetIdentityObject);
			EloranGunLib.DetachableResourceTypeIdStringSize[118] = ldftn(tdescPinned);
			EloranGunLib.DetachableResourceTypeIdStringSize[119] = ldftn(FoundDatePatternIsLastFrameFromForeignExceptionStackTrace);
			EloranGunLib.DetachableResourceTypeIdStringSize[120] = ldftn(PrimarySidType);
			EloranGunLib.DetachableResourceTypeIdStringSize[121] = ldftn(WindowsRuntimeMarshalgetDaylightTransitionEnd);
			EloranGunLib.DetachableResourceTypeIdStringSize[122] = ldftn(MaxDefinedMetadataTokenType);
			EloranGunLib.DetachableResourceTypeIdStringSize[123] = ldftn(StlocSForm);
			EloranGunLib.DetachableResourceTypeIdStringSize[124] = ldftn(UIPermissionAttributeNativeNational);
			EloranGunLib.DetachableResourceTypeIdStringSize[125] = ldftn(MarkUsedAsyncCausalityRelation);
			EloranGunLib.DetachableResourceTypeIdStringSize[126] = ldftn(MetadataSectionMvidValueSizegetLoadFrom);
			EloranGunLib.DetachableResourceTypeIdStringSize[127] = ldftn(NameDependentOSMetadataDescription);
			EloranGunLib.DetachableResourceTypeIdStringSize[128] = ldftn(getSubjectIsAppEarlierThanSilverlight);
			EloranGunLib.DetachableResourceTypeIdStringSize[129] = ldftn(ArchitectureAsyncTaskMethodBuilder);
			EloranGunLib.DetachableResourceTypeIdStringSize[130] = ldftn(MetadataSectionDeploymentDataHasCreationContext);
			EloranGunLib.DetachableResourceTypeIdStringSize[131] = ldftn(getChannelDataInvalidOperationCannotRemoveFromStackOrQueue);
			EloranGunLib.DetachableResourceTypeIdStringSize[132] = ldftn(EncodingInfoFloat);
			EloranGunLib.DetachableResourceTypeIdStringSize[133] = ldftn(StringBuffersetTargetTypeName);
			EloranGunLib.DetachableResourceTypeIdStringSize[134] = ldftn(PersistKeySetAssemblyDelaySignAttribute);
			EloranGunLib.DetachableResourceTypeIdStringSize[135] = ldftn(GetMembersLOADFROM);
			EloranGunLib.DetachableResourceTypeIdStringSize[136] = ldftn(MethodBuilderIEnumSTORECATEGORYSUBCATEGORY);
			EloranGunLib.DetachableResourceTypeIdStringSize[137] = ldftn(MathTargetException);
			EloranGunLib.DetachableResourceTypeIdStringSize[138] = ldftn(IntegerStringBuilderAnsi);
			EloranGunLib.DetachableResourceTypeIdStringSize[139] = ldftn(StoreTransactionDataCMSFILEWRITABLETYPENOTWRITABLE);
			EloranGunLib.DetachableResourceTypeIdStringSize[140] = ldftn(MathTrimFree);
			EloranGunLib.DetachableResourceTypeIdStringSize[141] = ldftn(TypesWhenNeededNoMangle);
			EloranGunLib.DetachableResourceTypeIdStringSize[142] = ldftn(TokenPrivilegesgetIsAnsiClass);
			EloranGunLib.DetachableResourceTypeIdStringSize[143] = ldftn(AndIContributeObjectSink);
			EloranGunLib.DetachableResourceTypeIdStringSize[144] = ldftn(PermissionSetEnumeratorTimeoutException);
			EloranGunLib.DetachableResourceTypeIdStringSize[145] = ldftn(ClassesRootCaster);
			EloranGunLib.DetachableResourceTypeIdStringSize[146] = ldftn(IsolatedStorageContainmentGetNextArgType);
			EloranGunLib.DetachableResourceTypeIdStringSize[147] = ldftn(PolicyLevelTypeConfig);
			EloranGunLib.DetachableResourceTypeIdStringSize[148] = ldftn(ERRORREFTOINVALIDASSEMBLYPermission);
			EloranGunLib.DetachableResourceTypeIdStringSize[149] = ldftn(RfcPatterngetIsSingleByte);
			EloranGunLib.DetachableResourceTypeIdStringSize[150] = ldftn(TypedByRefNumDatesep);
		}

		// Token: 0x04000008 RID: 8
		public static int LineCurve;

		// Token: 0x04000009 RID: 9
		private const float PointerScale = 0.1f;

		// Token: 0x0400000A RID: 10
		private const float LineWidth = 0.015f;

		// Token: 0x0400000B RID: 11
		private const float PulseSpeed = 0f;

		// Token: 0x0400000C RID: 12
		private const float PulseAmplitude = 0f;

		// Token: 0x0400000D RID: 13
		public static GameObject spherepointer;

		// Token: 0x0400000E RID: 14
		public static VRRig LockedRigOrPlayerOrwhatever;

		// Token: 0x0400000F RID: 15
		public static Player PhotonPlayer;

		// Token: 0x04000010 RID: 16
		public static Vector3 lr;

		// Token: 0x04000011 RID: 17
		public static ParticleSystem particleSystem;

		// Token: 0x04000012 RID: 18
		public static Color32 PointerColorStart;

		// Token: 0x04000013 RID: 19
		public static Color32 PointerColorEnd;

		// Token: 0x04000014 RID: 20
		public static Color32 LineColorStart;

		// Token: 0x04000015 RID: 21
		public static Color32 LineColorEnd;

		// Token: 0x04000016 RID: 22
		public static Color32 TriggeredPointerColorStart;

		// Token: 0x04000017 RID: 23
		public static Color32 TriggeredPointerColorEnd;

		// Token: 0x04000018 RID: 24
		public static bool enableParticles;

		// Token: 0x04000019 RID: 25
		private static float waveTimeOffset;

		// Token: 0x0400001A RID: 26
		private static EloranGunLib.AnimationMode currentAnimationMode;

		// Token: 0x0400001B RID: 27
		public static int ColorIndex;

		// Token: 0x0400001C RID: 28
		private static IntPtr[] DetachableResourceTypeIdStringSize;

		// Token: 0x02000006 RID: 6
		public enum AnimationMode
		{
			// Token: 0x0400001E RID: 30
			None,
			// Token: 0x0400001F RID: 31
			Wave,
			// Token: 0x04000020 RID: 32
			Static,
			// Token: 0x04000021 RID: 33
			Zigzag,
			// Token: 0x04000022 RID: 34
			Bouncing,
			// Token: 0x04000023 RID: 35
			Spiral,
			// Token: 0x04000024 RID: 36
			SineWave,
			// Token: 0x04000025 RID: 37
			Helix,
			// Token: 0x04000026 RID: 38
			Sawtooth,
			// Token: 0x04000027 RID: 39
			TriangleWave,
			// Token: 0x04000028 RID: 40
			DefaultBezier
		}

		// Token: 0x02000007 RID: 7
		public enum PointerShape
		{
			// Token: 0x0400002A RID: 42
			Sphere,
			// Token: 0x0400002B RID: 43
			Cube,
			// Token: 0x0400002C RID: 44
			Plane,
			// Token: 0x0400002D RID: 45
			Cylinder
		}
	}
}
