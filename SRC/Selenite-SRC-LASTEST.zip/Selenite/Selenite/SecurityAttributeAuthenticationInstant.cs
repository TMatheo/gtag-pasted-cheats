﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000044 RID: 68
[StructLayout(2, Pack = 1, Size = 14527)]
internal struct SecurityAttributeAuthenticationInstant
{
	// Token: 0x0400016C RID: 364 RVA: 0x0005E256 File Offset: 0x0005C456
	internal static readonly SecurityAttributeAuthenticationInstant NestedPrivateCursorSize;
}
