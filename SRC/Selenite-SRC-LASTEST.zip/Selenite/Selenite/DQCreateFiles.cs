﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000043 RID: 67
[StructLayout(2, Pack = 1, Size = 129)]
internal struct DQCreateFiles
{
	// Token: 0x0400016B RID: 363 RVA: 0x0005E1D5 File Offset: 0x0005C3D5
	internal static readonly DQCreateFiles setCreationTimeBadImageFormatException;
}
