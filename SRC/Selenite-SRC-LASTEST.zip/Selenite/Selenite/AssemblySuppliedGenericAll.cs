﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000050 RID: 80
[StructLayout(2, Pack = 1, Size = 456)]
internal struct AssemblySuppliedGenericAll
{
	// Token: 0x04000178 RID: 376 RVA: 0x0006329D File Offset: 0x0006149D
	internal static readonly AssemblySuppliedGenericAll getIsMethodDefLocalServiceSid;
}
