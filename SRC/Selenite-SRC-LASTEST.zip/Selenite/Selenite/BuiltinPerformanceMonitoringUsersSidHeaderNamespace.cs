﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000045 RID: 69
[StructLayout(2, Pack = 1, Size = 536)]
internal struct BuiltinPerformanceMonitoringUsersSidHeaderNamespace
{
	// Token: 0x0400016D RID: 365 RVA: 0x00061B15 File Offset: 0x0005FD15
	internal static readonly BuiltinPerformanceMonitoringUsersSidHeaderNamespace FailIgnoreHashMembershipCondition;
}
