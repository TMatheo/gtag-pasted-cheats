﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200005D RID: 93
[StructLayout(2, Pack = 1, Size = 816)]
internal struct getResourceExposureLevelRegistryOptions
{
	// Token: 0x04000185 RID: 389 RVA: 0x00064D3D File Offset: 0x00062F3D
	internal static readonly getResourceExposureLevelRegistryOptions HResultExceptionMarshalerRSACspObject;
}
