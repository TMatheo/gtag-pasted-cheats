﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000065 RID: 101
[StructLayout(2, Pack = 1, Size = 504)]
internal struct ITypeLibExporterNotifySinkgetKey
{
	// Token: 0x0400018D RID: 397 RVA: 0x00066795 File Offset: 0x00064995
	internal static readonly ITypeLibExporterNotifySinkgetKey EphemeralKeySetgetCalendarWeekRule;
}
