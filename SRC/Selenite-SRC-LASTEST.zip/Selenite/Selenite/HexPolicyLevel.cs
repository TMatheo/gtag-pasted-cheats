﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000055 RID: 85
[StructLayout(2, Pack = 1, Size = 600)]
internal struct HexPolicyLevel
{
	// Token: 0x0400017D RID: 381 RVA: 0x00063CF5 File Offset: 0x00061EF5
	internal static readonly HexPolicyLevel StartupActivationListener;
}
