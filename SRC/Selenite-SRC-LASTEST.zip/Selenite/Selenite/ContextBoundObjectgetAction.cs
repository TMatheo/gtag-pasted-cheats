﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200005A RID: 90
[StructLayout(2, Pack = 1, Size = 504)]
internal struct ContextBoundObjectgetAction
{
	// Token: 0x04000182 RID: 386 RVA: 0x00064725 File Offset: 0x00062925
	internal static readonly ContextBoundObjectgetAction AnsiClassDescriptionData;
}
