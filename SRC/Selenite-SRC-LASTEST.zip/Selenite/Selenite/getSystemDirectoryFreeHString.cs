﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000047 RID: 71
[StructLayout(2, Pack = 1, Size = 880)]
internal struct getSystemDirectoryFreeHString
{
	// Token: 0x0400016F RID: 367 RVA: 0x00061F65 File Offset: 0x00060165
	internal static readonly getSystemDirectoryFreeHString PercentNegativePatternGetSymAttribute;
}
