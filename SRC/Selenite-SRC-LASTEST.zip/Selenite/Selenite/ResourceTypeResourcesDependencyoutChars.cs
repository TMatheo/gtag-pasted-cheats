﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000042 RID: 66
[StructLayout(2, Pack = 1, Size = 129)]
internal struct ResourceTypeResourcesDependencyoutChars
{
	// Token: 0x0400016A RID: 362 RVA: 0x0005E154 File Offset: 0x0005C354
	internal static readonly ResourceTypeResourcesDependencyoutChars DatagetContextProperties;
}
