﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200004B RID: 75
[StructLayout(2, Pack = 1, Size = 560)]
internal struct CreateActContextParametersSourceClose
{
	// Token: 0x04000173 RID: 371 RVA: 0x00062865 File Offset: 0x00060A65
	internal static readonly CreateActContextParametersSourceClose GetGenericParameterConstraintsSafeHandle;
}
