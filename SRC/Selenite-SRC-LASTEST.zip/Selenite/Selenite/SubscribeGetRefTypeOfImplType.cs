﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200004C RID: 76
[StructLayout(2, Pack = 1, Size = 488)]
internal struct SubscribeGetRefTypeOfImplType
{
	// Token: 0x04000174 RID: 372 RVA: 0x00062A95 File Offset: 0x00060C95
	internal static readonly SubscribeGetRefTypeOfImplType getUserClaimsdSuppressFinalize;
}
