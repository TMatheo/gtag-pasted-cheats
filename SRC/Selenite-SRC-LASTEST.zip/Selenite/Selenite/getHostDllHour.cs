﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000052 RID: 82
[StructLayout(2, Pack = 1, Size = 656)]
internal struct getHostDllHour
{
	// Token: 0x0400017A RID: 378 RVA: 0x0006361D File Offset: 0x0006181D
	internal static readonly getHostDllHour ICustomDebuggerNotificationgetRuleSet;
}
