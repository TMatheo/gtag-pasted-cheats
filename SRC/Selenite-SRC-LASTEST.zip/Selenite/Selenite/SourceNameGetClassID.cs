﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000064 RID: 100
[StructLayout(2, Pack = 1, Size = 1240)]
internal struct SourceNameGetClassID
{
	// Token: 0x0400018C RID: 396 RVA: 0x000662BD File Offset: 0x000644BD
	internal static readonly SourceNameGetClassID getNewLinegetApplicationId;
}
