﻿using System;
using BepInEx;
using UnityEngine;

namespace EloranProjs
{
	// Token: 0x02000003 RID: 3
	[BepInPlugin("org.gorillatag.paranoiaprojs.projectileslib", "ProjectileLibV2", "2.0.0")]
	public class ProjectileLib : BaseUnityPlugin
	{
		// Token: 0x06000011 RID: 17 RVA: 0x00003210 File Offset: 0x00001410
		public static void LaunchProjectile(Vector3 pos, Vector3 velocity, int hash, Color color, NetPlayer sender)
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				GameObject gameObject;
				float num4;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,UnityEngine.GameObject&,System.Single&,System.Int32,UnityEngine.Vector3,UnityEngine.Vector3,NetPlayer,UnityEngine.Color), ref num, ref num2, ref num3, ref gameObject, ref num4, hash, pos, velocity, sender, color, ProjectileLib.MayLeakOnAbortgetByteCapacity[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000012 RID: 18 RVA: 0x0000324C File Offset: 0x0000144C
		private static void GetResourceDataPOLICYGETPRIVATEINFORMATION(ref int A_0, ref int A_1, ref int A_2, ProjectileLib A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00003270 File Offset: 0x00001470
		private static void AceQualifierTypeResolveHandler(ref int A_0, ref int A_1, ref int A_2, ref GameObject A_3, ref float A_4, int A_5, Vector3 A_6, Vector3 A_7, NetPlayer A_8, Color A_9)
		{
			GameObject gameObject = ObjectPools.instance.Instantiate(A_5);
			A_3 = gameObject;
			float num = Mathf.Abs(A_3.transform.lossyScale.x);
			A_4 = num;
			A_3.transform.localScale = Vector3.one * A_4;
			A_3.GetComponent<SlingshotProjectile>().Launch(A_6, A_7, A_8, false, false, -1, 1f, true, A_9);
			A_1 = 1;
		}

		// Token: 0x06000014 RID: 20 RVA: 0x0000333C File Offset: 0x0000153C
		public ProjectileLib()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,EloranProjs.ProjectileLib), ref num, ref num2, ref num3, this, ProjectileLib.MayLeakOnAbortgetByteCapacity[num]);
			}
			num2 = 1;
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00003370 File Offset: 0x00001570
		// Note: this type is marked as 'beforefieldinit'.
		static ProjectileLib()
		{
			ProjectileLib.addProcessExitAddHostEvidence();
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00003384 File Offset: 0x00001584
		private static void addProcessExitAddHostEvidence()
		{
			ProjectileLib.MayLeakOnAbortgetByteCapacity = new IntPtr[2];
			ProjectileLib.MayLeakOnAbortgetByteCapacity[0] = ldftn(AceQualifierTypeResolveHandler);
			ProjectileLib.MayLeakOnAbortgetByteCapacity[1] = ldftn(GetResourceDataPOLICYGETPRIVATEINFORMATION);
		}

		// Token: 0x04000005 RID: 5
		private static IntPtr[] MayLeakOnAbortgetByteCapacity;
	}
}
