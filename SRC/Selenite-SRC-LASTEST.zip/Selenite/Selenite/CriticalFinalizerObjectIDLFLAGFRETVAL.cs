﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000058 RID: 88
[StructLayout(2, Pack = 1, Size = 584)]
internal struct CriticalFinalizerObjectIDLFLAGFRETVAL
{
	// Token: 0x04000180 RID: 384 RVA: 0x00064345 File Offset: 0x00062545
	internal static readonly CriticalFinalizerObjectIDLFLAGFRETVAL CrossAppDomainSinkGetDirectoryRoot;
}
