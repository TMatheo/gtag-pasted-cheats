﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000048 RID: 72
[StructLayout(2, Pack = 1, Size = 592)]
internal struct IOCompletionCallbackGetRuntimeProperty
{
	// Token: 0x04000170 RID: 368 RVA: 0x000622D5 File Offset: 0x000604D5
	internal static readonly IOCompletionCallbackGetRuntimeProperty DoubleArrayCOMServerImplementedClsid;
}
