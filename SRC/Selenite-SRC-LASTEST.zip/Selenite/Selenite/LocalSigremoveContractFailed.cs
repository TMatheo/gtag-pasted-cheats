﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200004D RID: 77
[StructLayout(2, Pack = 1, Size = 544)]
internal struct LocalSigremoveContractFailed
{
	// Token: 0x04000175 RID: 373 RVA: 0x00062C7D File Offset: 0x00060E7D
	internal static readonly LocalSigremoveContractFailed BufferGetStringArray;
}
