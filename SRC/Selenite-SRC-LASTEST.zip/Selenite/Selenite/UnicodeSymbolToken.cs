﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000057 RID: 87
[StructLayout(2, Pack = 1, Size = 416)]
internal struct UnicodeSymbolToken
{
	// Token: 0x0400017F RID: 383 RVA: 0x000641A5 File Offset: 0x000623A5
	internal static readonly UnicodeSymbolToken EncoderExceptionFallbackgetIsGlobalTypeDefToken;
}
