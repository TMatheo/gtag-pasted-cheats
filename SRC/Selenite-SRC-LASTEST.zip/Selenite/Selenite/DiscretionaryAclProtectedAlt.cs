﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000062 RID: 98
[StructLayout(2, Pack = 1, Size = 1552)]
internal struct DiscretionaryAclProtectedAlt
{
	// Token: 0x0400018A RID: 394 RVA: 0x00065AE5 File Offset: 0x00063CE5
	internal static readonly DiscretionaryAclProtectedAlt ImpersonateSystemAcl;
}
