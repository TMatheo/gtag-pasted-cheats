﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000049 RID: 73
[StructLayout(2, Pack = 1, Size = 416)]
internal struct getDoNotAddrOfCspParentWindowHandleBraceFormat
{
	// Token: 0x04000171 RID: 369 RVA: 0x00062525 File Offset: 0x00060725
	internal static readonly getDoNotAddrOfCspParentWindowHandleBraceFormat NoAccessRegisterWaitForSingleObject;
}
