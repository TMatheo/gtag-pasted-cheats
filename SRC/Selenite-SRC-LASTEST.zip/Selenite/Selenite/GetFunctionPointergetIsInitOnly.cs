﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000051 RID: 81
[StructLayout(2, Pack = 1, Size = 440)]
internal struct GetFunctionPointergetIsInitOnly
{
	// Token: 0x04000179 RID: 377 RVA: 0x00063465 File Offset: 0x00061665
	internal static readonly GetFunctionPointergetIsInitOnly getMonthDayPatternFalseString;
}
