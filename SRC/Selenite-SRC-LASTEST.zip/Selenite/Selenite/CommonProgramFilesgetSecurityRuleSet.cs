﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000046 RID: 70
[StructLayout(2, Pack = 1, Size = 568)]
internal struct CommonProgramFilesgetSecurityRuleSet
{
	// Token: 0x0400016E RID: 366 RVA: 0x00061D2D File Offset: 0x0005FF2D
	internal static readonly CommonProgramFilesgetSecurityRuleSet ManifestPathWellKnownObjectMode;
}
