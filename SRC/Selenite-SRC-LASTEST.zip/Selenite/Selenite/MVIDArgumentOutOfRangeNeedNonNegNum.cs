﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200004F RID: 79
[StructLayout(2, Pack = 1, Size = 584)]
internal struct MVIDArgumentOutOfRangeNeedNonNegNum
{
	// Token: 0x04000177 RID: 375 RVA: 0x00063055 File Offset: 0x00061255
	internal static readonly MVIDArgumentOutOfRangeNeedNonNegNum TupleElementNamesAttributeLogMessage;
}
