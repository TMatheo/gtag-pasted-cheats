﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000063 RID: 99
[StructLayout(2, Pack = 1, Size = 456)]
internal struct getSuiteNameSetPermission
{
	// Token: 0x0400018B RID: 395 RVA: 0x000660F5 File Offset: 0x000642F5
	internal static readonly getSuiteNameSetPermission DiscardBufferedDataCMSHASHTRANSFORMIDENTITY;
}
