﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200004E RID: 78
[StructLayout(2, Pack = 1, Size = 440)]
internal struct opModulusLinkDemand
{
	// Token: 0x04000176 RID: 374 RVA: 0x00062E9D File Offset: 0x0006109D
	internal static readonly opModulusLinkDemand OnSerializedAttributeThreadStaticAttribute;
}
