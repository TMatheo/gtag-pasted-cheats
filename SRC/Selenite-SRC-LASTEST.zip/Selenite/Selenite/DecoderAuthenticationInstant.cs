﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200004A RID: 74
[StructLayout(2, Pack = 1, Size = 416)]
internal struct DecoderAuthenticationInstant
{
	// Token: 0x04000172 RID: 370 RVA: 0x000626C5 File Offset: 0x000608C5
	internal static readonly DecoderAuthenticationInstant AppendFormatSetOpaque;
}
