﻿using System;

// Token: 0x02000066 RID: 102
internal class PermissionSetEnumeratorInternalLeftCtrlPressed
{
	// Token: 0x0400018E RID: 398
	static bool giGXUx28rIA3qfJqLUrA3JOAPGg;
}
