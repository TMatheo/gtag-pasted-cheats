﻿using System;
using BepInEx;

// Token: 0x02000002 RID: 2
public class MyPlugin : BaseUnityPlugin
{
	// Token: 0x0600000B RID: 11 RVA: 0x00003118 File Offset: 0x00001318
	private void Start()
	{
		int num = 0;
		int num2 = 0;
		num2 = 0;
		while (num2 != 1)
		{
			int num3;
			calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, MyPlugin.StrongNameSignatureVerificationExCommandLineFile[num]);
		}
		num2 = 0;
	}

	// Token: 0x0600000C RID: 12 RVA: 0x0000314C File Offset: 0x0000134C
	private static void AccessControlSectionsGetItem(ref int A_0, ref int A_1, ref int A_2, MyPlugin A_3)
	{
		A_3..ctor();
		A_1 = 0;
	}

	// Token: 0x0600000D RID: 13 RVA: 0x00003170 File Offset: 0x00001370
	public MyPlugin()
	{
		int num = 1;
		int num2 = 1;
		num2 = 1;
		while (num2 != 0)
		{
			int num3;
			calli(System.Void(System.Int32&,System.Int32&,System.Int32&,MyPlugin), ref num, ref num2, ref num3, this, MyPlugin.StrongNameSignatureVerificationExCommandLineFile[num]);
		}
		num2 = 1;
	}

	// Token: 0x0600000E RID: 14 RVA: 0x000031A4 File Offset: 0x000013A4
	private static void CMSSECTIONIDPERMISSIONSETSECTIONSecuritySerialization(ref int A_0, ref int A_1, ref int A_2)
	{
		A_1 = 1;
	}

	// Token: 0x0600000F RID: 15 RVA: 0x000031BC File Offset: 0x000013BC
	// Note: this type is marked as 'beforefieldinit'.
	static MyPlugin()
	{
		MyPlugin.getSaltpUnk();
	}

	// Token: 0x06000010 RID: 16 RVA: 0x000031D0 File Offset: 0x000013D0
	private static void getSaltpUnk()
	{
		MyPlugin.StrongNameSignatureVerificationExCommandLineFile = new IntPtr[2];
		MyPlugin.StrongNameSignatureVerificationExCommandLineFile[0] = ldftn(CMSSECTIONIDPERMISSIONSETSECTIONSecuritySerialization);
		MyPlugin.StrongNameSignatureVerificationExCommandLineFile[1] = ldftn(AccessControlSectionsGetItem);
	}

	// Token: 0x04000004 RID: 4
	private static IntPtr[] StrongNameSignatureVerificationExCommandLineFile;
}
