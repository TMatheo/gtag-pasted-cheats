﻿using System;
using StupidTemplate.Patches;
using UnityEngine;

namespace Loading
{
	// Token: 0x02000004 RID: 4
	public class Loader
	{
		// Token: 0x06000017 RID: 23 RVA: 0x000033C4 File Offset: 0x000015C4
		public static void Load()
		{
			int num = 0;
			int num2 = 0;
			num2 = 0;
			while (num2 != 1)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Loader.FileIOAccesspInt[num]);
			}
			num2 = 0;
		}

		// Token: 0x06000018 RID: 24 RVA: 0x000033F8 File Offset: 0x000015F8
		private static void GregorianCalendarTypesMethodSpec(ref int A_0, ref int A_1, ref int A_2, Loader A_3)
		{
			A_3..ctor();
			A_1 = 0;
		}

		// Token: 0x06000019 RID: 25 RVA: 0x0000341C File Offset: 0x0000161C
		private static void VolatileWriteVectorToCollectionAdapter(ref int A_0, ref int A_1, ref int A_2)
		{
			Object.Destroy(Loader.gameObject);
			A_1 = 0;
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00003440 File Offset: 0x00001640
		private static void GetFolderPathgetAuthenticationType(ref int A_0, ref int A_1, ref int A_2)
		{
			Loader.gameObject = new GameObject();
			Loader.gameObject.AddComponent<Menu>();
			Object.DontDestroyOnLoad(Loader.gameObject);
			Debug.Log("Loaded");
			A_1 = 1;
		}

		// Token: 0x0600001B RID: 27 RVA: 0x00003484 File Offset: 0x00001684
		public Loader()
		{
			int num = 2;
			int num2 = 2;
			num2 = 2;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&,Loading.Loader), ref num, ref num2, ref num3, this, Loader.FileIOAccesspInt[num]);
			}
			num2 = 2;
		}

		// Token: 0x0600001C RID: 28 RVA: 0x000034B8 File Offset: 0x000016B8
		public static void Unload()
		{
			int num = 1;
			int num2 = 1;
			num2 = 1;
			while (num2 != 0)
			{
				int num3;
				calli(System.Void(System.Int32&,System.Int32&,System.Int32&), ref num, ref num2, ref num3, Loader.FileIOAccesspInt[num]);
			}
			num2 = 1;
		}

		// Token: 0x0600001D RID: 29 RVA: 0x000034EC File Offset: 0x000016EC
		// Note: this type is marked as 'beforefieldinit'.
		static Loader()
		{
			Loader.SetAddOnMethodReadCache();
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00003500 File Offset: 0x00001700
		private static void SetAddOnMethodReadCache()
		{
			Loader.FileIOAccesspInt = new IntPtr[3];
			Loader.FileIOAccesspInt[0] = ldftn(GetFolderPathgetAuthenticationType);
			Loader.FileIOAccesspInt[1] = ldftn(VolatileWriteVectorToCollectionAdapter);
			Loader.FileIOAccesspInt[2] = ldftn(GregorianCalendarTypesMethodSpec);
		}

		// Token: 0x04000006 RID: 6
		private static GameObject gameObject;

		// Token: 0x04000007 RID: 7
		private static IntPtr[] FileIOAccesspInt;
	}
}
