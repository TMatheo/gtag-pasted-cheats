﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000054 RID: 84
[StructLayout(2, Pack = 1, Size = 440)]
internal struct IsInitOnlygetThreeLetterWindowsLanguageName
{
	// Token: 0x0400017C RID: 380 RVA: 0x00063B3D File Offset: 0x00061D3D
	internal static readonly IsInitOnlygetThreeLetterWindowsLanguageName CriticalHandleSpacingCombiningMark;
}
