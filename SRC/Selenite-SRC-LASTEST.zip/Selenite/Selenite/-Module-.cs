﻿using System;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	unsafe static <Module>()
	{
		<Module>.VTCFThreadingModel();
		int num = 1;
		int num2 = num;
		int num3 = num2 * 4;
		int num4 = num2 * 8;
		byte[] array = new byte[5];
		object[] array2 = new object[5];
		int[] array3 = new int[5];
		sbyte[] array5;
		fixed (sbyte[] array4 = array5 = new sbyte[1])
		{
			long[] array7;
			fixed (long[] array6 = array7 = new long[5])
			{
				object[] array8 = new object[6];
				array8[2] = <Module>.TargetedPatchBandSpecialPermissionSetFlag;
				byte* ptr = (byte*)(&SecurityAttributeAuthenticationInstant.NestedPrivateCursorSize);
				int num5;
				while (num5 != 1)
				{
					byte b = (byte)(*(sbyte*)ptr);
					ptr++;
					int num6;
					if (b >= 1 && b <= 32)
					{
						if (16 >= b)
						{
							if (16 <= b)
							{
								((object[])array2[num6 - 3])[*(int*)(&array7[num6 - 2])] = array2[num6 - 1];
								num6 -= 3;
								continue;
							}
							if (8 >= b)
							{
								if (8 <= b)
								{
									array[num6] = 13;
									*(int*)(&array7[num6]) = *(int*)(ptr + num3);
									array3[num6 - 0] = *(int*)(ptr + 8 + num3);
									num6++;
									ptr += 16;
									continue;
								}
								if (4 >= b)
								{
									if (4 <= b)
									{
										array5[*(int*)(ptr + num3)] = (sbyte)(*(int*)(&array7[num6 - 1]));
										ptr += 8;
										num6--;
										continue;
									}
									if (2 >= b)
									{
										if (2 <= b)
										{
											array2[num6 - 1] = new object[*(int*)(&array7[num6 - 1])];
											array[num6 - 1] = 5;
											continue;
										}
										if (1 >= b)
										{
											if (1 <= b)
											{
											}
										}
									}
									else if (3 >= b)
									{
										if (3 <= b)
										{
											array8[*(int*)(ptr + num3)] = array2[num6 - 1];
											ptr += 8;
											num6--;
											continue;
										}
									}
								}
								else if (6 >= b)
								{
									if (6 <= b)
									{
										array[num6] = 4;
										array2[num6] = calli(System.DateTime(), <Module>.RunContinuationsAsynchronouslyPackingSize[*(int*)(ptr + num3)]);
										num6++;
										ptr += 8;
										continue;
									}
									if (5 >= b)
									{
										if (5 <= b)
										{
											*(&array7[num6]) = *(long*)(ptr + num4);
											array[num6] = 1;
											num6++;
											ptr += 16;
											continue;
										}
									}
								}
								else if (7 >= b)
								{
									if (7 <= b)
									{
										array8[*(int*)(ptr + num3)] = (DateTime)array2[num6 - 1];
										ptr += 8;
										num6--;
										continue;
									}
								}
							}
							else if (12 >= b)
							{
								if (12 <= b)
								{
									array[num6] = array[num6 - 1];
									array3[num6 - 0] = array3[num6 - 1];
									*(&array7[num6]) = *(&array7[num6 - 1]);
									array2[num6] = array2[num6 - 1];
									num6++;
									continue;
								}
								if (10 >= b)
								{
									if (10 <= b)
									{
										ptr = ((*(&array7[num6 - 2]) > *(&array7[num6 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ref SecurityAttributeAuthenticationInstant.NestedPrivateCursorSize;
										num6 -= 2;
										continue;
									}
									if (9 >= b)
									{
										if (9 <= b)
										{
											array[num6 - 1] = 1;
											*(&array7[num6 - 1]) = calli(System.Int64(System.DateTime&), calli(System.DateTime&(System.Object,System.IntPtr,System.Object[],System.SByte[]), array2[num6 - 1], *(int*)(&array7[num6 - 1]), array8, array5, <Module>.RunContinuationsAsynchronouslyPackingSize[array3[num6 - 1]]), <Module>.RunContinuationsAsynchronouslyPackingSize[*(int*)(ptr + num3)]);
											ptr += 8;
											continue;
										}
									}
								}
								else if (11 >= b)
								{
									if (11 <= b)
									{
										array2[num6 - 1] = new char[*(int*)(&array7[num6 - 1])];
										array[num6 - 1] = 5;
										continue;
									}
								}
							}
							else if (14 >= b)
							{
								if (14 <= b)
								{
									array[num6] = 5;
									array2[num6] = array8[*(int*)(ptr + num3)];
									num6++;
									ptr += 8;
									continue;
								}
								if (13 >= b)
								{
									if (13 <= b)
									{
										array8[*(int*)(ptr + num3)] = array2[num6 - 1];
										ptr += 8;
										num6--;
										continue;
									}
								}
							}
							else if (15 >= b)
							{
								if (15 <= b)
								{
									array[num6] = 5;
									array2[num6] = array8[*(int*)(ptr + num3)];
									num6++;
									ptr += 8;
									continue;
								}
							}
						}
						else if (24 >= b)
						{
							if (24 <= b)
							{
								array2[num6 - 3][*(int*)(&array7[num6 - 2])] = *(int*)(&array7[num6 - 1]);
								num6 -= 3;
								continue;
							}
							if (20 >= b)
							{
								if (20 <= b)
								{
									*(IntPtr*)(&array7[num6 - 2]) = *(IntPtr*)(&array7[num6 - 2]) + (IntPtr)(*(int*)(&array7[num6 - 1]));
									array[num6 - 2] = 2;
									num6--;
									continue;
								}
								if (18 >= b)
								{
									if (18 <= b)
									{
										array[num6] = 15;
										array3[num6] = *(int*)(ptr + num3);
										ptr += 8;
										num6++;
										continue;
									}
									if (17 >= b)
									{
										if (17 <= b)
										{
											array2[num6 - 2] = ((object[])array2[num6 - 2])[*(int*)(&array7[num6 - 1])];
											array[num6 - 2] = 5;
											num6--;
											continue;
										}
									}
								}
								else if (19 >= b)
								{
									if (19 <= b)
									{
										*(IntPtr*)(&array7[num6 - 1]) = calli(ResourceTypeResourcesDependencyoutChars&(System.Object,System.IntPtr,System.Object[],System.SByte[]), array2[num6 - 1], *(int*)(&array7[num6 - 1]), array8, array5, <Module>.RunContinuationsAsynchronouslyPackingSize[array3[num6 - 1]]);
										array[num6 - 1] = 2;
										continue;
									}
								}
							}
							else if (22 >= b)
							{
								if (22 <= b)
								{
									*(int*)(&array7[num6 - 1]) = *(int*)(&array7[num6 - 1]);
									array[num6 - 1] = 0;
									continue;
								}
								if (21 >= b)
								{
									if (21 <= b)
									{
										*(int*)(&array7[num6 - 1]) = (int)(*(*(IntPtr*)(&array7[num6 - 1])));
										array[num6 - 1] = 0;
										continue;
									}
								}
							}
							else if (23 >= b)
							{
								if (23 <= b)
								{
									*(int*)(&array7[num6 - 2]) = (*(int*)(&array7[num6 - 2]) ^ *(int*)(&array7[num6 - 1]));
									array[num6 - 2] = 0;
									num6--;
									continue;
								}
							}
						}
						else if (28 >= b)
						{
							if (28 <= b)
							{
								*(IntPtr*)(&array7[num6 - 1]) = calli(DQCreateFiles&(System.Object,System.IntPtr,System.Object[],System.SByte[]), array2[num6 - 1], *(int*)(&array7[num6 - 1]), array8, array5, <Module>.RunContinuationsAsynchronouslyPackingSize[array3[num6 - 1]]);
								array[num6 - 1] = 2;
								continue;
							}
							if (26 >= b)
							{
								if (26 <= b)
								{
									calli(System.Void(System.String), (string)array2[num6 - 1], <Module>.RunContinuationsAsynchronouslyPackingSize[*(int*)(ptr + num3)]);
									num6--;
									ptr += 8;
									continue;
								}
								if (25 >= b)
								{
									if (25 <= b)
									{
										array[num6 - 1] = 5;
										array2[num6 - 1] = calli(System.String(System.Char[]), (char[])array2[num6 - 1], <Module>.RunContinuationsAsynchronouslyPackingSize[*(int*)(ptr + num3)]);
										ptr += 8;
										continue;
									}
								}
							}
							else if (27 >= b)
							{
								if (27 <= b)
								{
									array[num6] = 15;
									array3[num6] = *(int*)(ptr + num3);
									ptr += 8;
									num6++;
									continue;
								}
							}
						}
						else if (30 >= b)
						{
							if (30 <= b)
							{
								throw (Exception)array2[num6 - 1];
							}
							if (29 >= b)
							{
								if (29 <= b)
								{
									array[num6 - 1] = 5;
									array2[num6 - 1] = calli(System.Exception(System.String), (string)array2[num6 - 1], <Module>.RunContinuationsAsynchronouslyPackingSize[*(int*)(ptr + num3)]);
									ptr += 8;
									continue;
								}
							}
						}
						else if (31 >= b)
						{
							if (31 <= b)
							{
								continue;
							}
						}
						else if (32 >= b)
						{
							if (32 <= b)
							{
								num5 = 1;
								continue;
							}
						}
					}
					IL_5D2:
					*(int*)(&array7[num6]) = *(int*)(ptr + num3);
					array[num6] = 0;
					num6++;
					ptr += 8;
					continue;
					goto IL_5D2;
				}
			}
		}
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00003020 File Offset: 0x00001220
	private static DateTime SecurityCriticalScopeIServerChannelSinkProvider()
	{
		return DateTime.UtcNow;
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00003027 File Offset: 0x00001227
	private static ref DateTime SystemAclAutoInheritedImportAsX(object A_0, IntPtr A_1, object[] A_2, sbyte[] A_3)
	{
		return ref (DateTime)A_2[(int)A_1];
	}

	// Token: 0x06000004 RID: 4 RVA: 0x00003037 File Offset: 0x00001237
	private static long GCHandleCookieTableWindowsRuntime(ref DateTime A_0)
	{
		return A_0.Ticks;
	}

	// Token: 0x06000005 RID: 5 RVA: 0x00003042 File Offset: 0x00001242
	private static ref ResourceTypeResourcesDependencyoutChars ChildGetSystemVersion(object A_0, IntPtr A_1, object[] A_2, sbyte[] A_3)
	{
		return ref ResourceTypeResourcesDependencyoutChars.DatagetContextProperties;
	}

	// Token: 0x06000006 RID: 6 RVA: 0x00003049 File Offset: 0x00001249
	private static string LdelemsetCustomErrorsMode(char[] A_0)
	{
		return new string(A_0);
	}

	// Token: 0x06000007 RID: 7 RVA: 0x00003054 File Offset: 0x00001254
	private static void IsSystemMonikerFileAssociationProgID(string A_0)
	{
		Environment.FailFast(A_0);
	}

	// Token: 0x06000008 RID: 8 RVA: 0x0000305F File Offset: 0x0000125F
	private static ref DQCreateFiles OffsetLowMatchExactVersion(object A_0, IntPtr A_1, object[] A_2, sbyte[] A_3)
	{
		return ref DQCreateFiles.setCreationTimeBadImageFormatException;
	}

	// Token: 0x06000009 RID: 9 RVA: 0x00003066 File Offset: 0x00001266
	private static Exception ListToVectorAdapterSetType(string A_0)
	{
		return new Exception(A_0);
	}

	// Token: 0x0600000A RID: 10 RVA: 0x00003074 File Offset: 0x00001274
	private static void VTCFThreadingModel()
	{
		<Module>.RunContinuationsAsynchronouslyPackingSize = new IntPtr[8];
		<Module>.RunContinuationsAsynchronouslyPackingSize[0] = ldftn(SecurityCriticalScopeIServerChannelSinkProvider);
		<Module>.RunContinuationsAsynchronouslyPackingSize[1] = ldftn(SystemAclAutoInheritedImportAsX);
		<Module>.RunContinuationsAsynchronouslyPackingSize[2] = ldftn(GCHandleCookieTableWindowsRuntime);
		<Module>.RunContinuationsAsynchronouslyPackingSize[3] = ldftn(ChildGetSystemVersion);
		<Module>.RunContinuationsAsynchronouslyPackingSize[4] = ldftn(LdelemsetCustomErrorsMode);
		<Module>.RunContinuationsAsynchronouslyPackingSize[5] = ldftn(IsSystemMonikerFileAssociationProgID);
		<Module>.RunContinuationsAsynchronouslyPackingSize[6] = ldftn(OffsetLowMatchExactVersion);
		<Module>.RunContinuationsAsynchronouslyPackingSize[7] = ldftn(ListToVectorAdapterSetType);
	}

	// Token: 0x04000001 RID: 1
	public static byte IsolatedStorageFilePermissionAttributeHString;

	// Token: 0x04000002 RID: 2
	private static DateTime TargetedPatchBandSpecialPermissionSetFlag;

	// Token: 0x04000003 RID: 3
	private static IntPtr[] RunContinuationsAsynchronouslyPackingSize;
}
