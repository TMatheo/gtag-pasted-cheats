﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200005C RID: 92
[StructLayout(2, Pack = 1, Size = 520)]
internal struct OemPlussetCreate
{
	// Token: 0x04000184 RID: 388 RVA: 0x00064B35 File Offset: 0x00062D35
	internal static readonly OemPlussetCreate SetGenericParameterAttributessetCurrencyPositivePattern;
}
