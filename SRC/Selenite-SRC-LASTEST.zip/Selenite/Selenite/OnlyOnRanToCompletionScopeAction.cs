﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000056 RID: 86
[StructLayout(2, Pack = 1, Size = 600)]
internal struct OnlyOnRanToCompletionScopeAction
{
	// Token: 0x0400017E RID: 382 RVA: 0x00063F4D File Offset: 0x0006214D
	internal static readonly OnlyOnRanToCompletionScopeAction IsNestedAssemblyAddOpcode;
}
