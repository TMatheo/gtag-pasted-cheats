﻿using System;
using GorillaLocomotion;
using HarmonyLib;

namespace NXO.Patches
{
	// Token: 0x02000017 RID: 23
	[HarmonyPatch(typeof(GTPlayer), "AntiTeleportTechnology", 0)]
	public class TeleportPatch
	{
		// Token: 0x0600009B RID: 155 RVA: 0x00007A78 File Offset: 0x00005C78
		private static bool Prefix()
		{
			return false;
		}
	}
}
