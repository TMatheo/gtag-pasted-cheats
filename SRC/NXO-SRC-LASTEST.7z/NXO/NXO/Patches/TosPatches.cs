﻿using System;
using System.Runtime.CompilerServices;
using HarmonyLib;

namespace NXO.Patches
{
	// Token: 0x02000018 RID: 24
	public class TosPatches
	{
		// Token: 0x04000140 RID: 320
		public static bool IsEnabled;

		// Token: 0x02000053 RID: 83
		[HarmonyPatch(typeof(LegalAgreements), "PostUpdate")]
		public class ToSPatch
		{
			// Token: 0x06000201 RID: 513 RVA: 0x0001A1E8 File Offset: 0x000183E8
			[NullableContext(1)]
			private static bool Prefix(LegalAgreements __instance)
			{
				bool flag = !TosPatches.IsEnabled;
				bool result;
				if (flag)
				{
					result = true;
				}
				else
				{
					__instance.TurnPage(999);
					Traverse.Create(__instance).Field("controllerBehaviour").Field("buttonDown").SetValue(true);
					result = false;
				}
				return result;
			}
		}

		// Token: 0x02000054 RID: 84
		[HarmonyPatch(typeof(ModIOTermsOfUse), "PostUpdate")]
		public class ToSPatch2
		{
			// Token: 0x06000203 RID: 515 RVA: 0x0001A248 File Offset: 0x00018448
			[NullableContext(1)]
			private static bool Prefix(ModIOTermsOfUse __instance)
			{
				bool flag = !TosPatches.IsEnabled;
				bool result;
				if (flag)
				{
					result = true;
				}
				else
				{
					__instance.TurnPage(999);
					Traverse.Create(__instance).Field("controllerBehaviour").Field("buttonDown").SetValue(true);
					result = false;
				}
				return result;
			}
		}
	}
}
