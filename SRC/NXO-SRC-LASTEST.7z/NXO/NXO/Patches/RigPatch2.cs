﻿using System;
using System.Runtime.CompilerServices;
using HarmonyLib;

namespace NXO.Patches
{
	// Token: 0x02000014 RID: 20
	[HarmonyPatch(typeof(VRRigJobManager), "DeregisterVRRig")]
	public static class RigPatch2
	{
		// Token: 0x06000096 RID: 150 RVA: 0x000079C4 File Offset: 0x00005BC4
		[NullableContext(1)]
		public static bool Prefix(VRRigJobManager __instance, VRRig rig)
		{
			return !rig.isOfflineVRRig;
		}
	}
}
