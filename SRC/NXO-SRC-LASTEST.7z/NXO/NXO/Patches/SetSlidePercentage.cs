﻿using System;
using GorillaLocomotion;
using HarmonyLib;
using NXO.Mods.Categories;

namespace NXO.Patches
{
	// Token: 0x02000016 RID: 22
	[HarmonyPatch(typeof(GTPlayer), "GetSlidePercentage")]
	public class SetSlidePercentage
	{
		// Token: 0x06000099 RID: 153 RVA: 0x00007A3C File Offset: 0x00005C3C
		public static void Postfix(ref float __result)
		{
			bool grippySurfaces = Movement.GrippySurfaces;
			if (grippySurfaces)
			{
				__result = 0f;
			}
			bool slipperySurfaces = Movement.SlipperySurfaces;
			if (slipperySurfaces)
			{
				__result = 1f;
			}
		}
	}
}
