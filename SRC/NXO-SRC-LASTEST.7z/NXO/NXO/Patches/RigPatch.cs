﻿using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using NXO.Utilities;

namespace NXO.Patches
{
	// Token: 0x02000013 RID: 19
	[HarmonyPatch(typeof(VRRig), "OnDisable", 0)]
	public static class RigPatch
	{
		// Token: 0x06000095 RID: 149 RVA: 0x0000799C File Offset: 0x00005B9C
		[NullableContext(1)]
		public static bool Prefix(VRRig __instance)
		{
			return !(__instance == Variables.taggerInstance.offlineVRRig);
		}
	}
}
