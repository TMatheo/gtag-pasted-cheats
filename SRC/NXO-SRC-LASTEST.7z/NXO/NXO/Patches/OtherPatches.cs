﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Fusion;
using GorillaLocomotion;
using HarmonyLib;
using NXO.Utilities;
using Photon.Pun;
using PlayFab;
using PlayFab.ClientModels;
using PlayFab.Internal;
using UnityEngine;

namespace NXO.Patches
{
	// Token: 0x02000012 RID: 18
	public class OtherPatches
	{
		// Token: 0x0200003F RID: 63
		[HarmonyPatch(typeof(NetworkSystemFusion), "UpdateNetPlayerList")]
		public class noupdate
		{
			// Token: 0x060001DA RID: 474 RVA: 0x00019F58 File Offset: 0x00018158
			[NullableContext(1)]
			public static bool Prefix(NetworkSystemFusion __instance)
			{
				Debug.Log(__instance);
				string text = "runner: ";
				NetworkRunner runner = __instance.runner;
				Debug.Log(text + ((runner != null) ? runner.ToString() : null) != null);
				return false;
			}
		}

		// Token: 0x02000040 RID: 64
		[HarmonyPatch(typeof(DebugHudStats), "Update", 0)]
		public class noupdate2
		{
			// Token: 0x060001DC RID: 476 RVA: 0x00019FA8 File Offset: 0x000181A8
			public static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000041 RID: 65
		[HarmonyPatch(typeof(GTPlayer), "AntiTeleportTechnology", 0)]
		public class NoAntiTP
		{
			// Token: 0x060001DE RID: 478 RVA: 0x00019FC4 File Offset: 0x000181C4
			private static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000042 RID: 66
		[HarmonyPatch(typeof(PlayFabClientAPI), "AttributeInstall")]
		internal class NoAttributeInstall
		{
			// Token: 0x060001E0 RID: 480 RVA: 0x00019FE0 File Offset: 0x000181E0
			private static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000043 RID: 67
		[HarmonyPatch(typeof(PlayFabHttp), "InitializeScreenTimeTracker")]
		internal class NoInitializeScreenTimeTracker
		{
			// Token: 0x060001E2 RID: 482 RVA: 0x00019FFC File Offset: 0x000181FC
			private static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000044 RID: 68
		[HarmonyPatch(typeof(PlayFabDeviceUtil), "GetAdvertIdFromUnity")]
		internal class NoGetAdvertIdFromUnity
		{
			// Token: 0x060001E4 RID: 484 RVA: 0x0001A018 File Offset: 0x00018218
			private static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000045 RID: 69
		[HarmonyPatch(typeof(PlayFabDeviceUtil), "DoAttributeInstall")]
		internal class NoDoAttributeInstall
		{
			// Token: 0x060001E6 RID: 486 RVA: 0x0001A034 File Offset: 0x00018234
			private static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000046 RID: 70
		[HarmonyPatch(typeof(PlayFabClientInstanceAPI), "ReportDeviceInfo")]
		internal class NoDeviceInfo2
		{
			// Token: 0x060001E8 RID: 488 RVA: 0x0001A050 File Offset: 0x00018250
			private static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000047 RID: 71
		[HarmonyPatch(typeof(PlayFabClientAPI), "ReportDeviceInfo")]
		internal class NoDeviceInfo1
		{
			// Token: 0x060001EA RID: 490 RVA: 0x0001A06C File Offset: 0x0001826C
			private static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000048 RID: 72
		[HarmonyPatch(typeof(PlayFabDeviceUtil), "SendDeviceInfoToPlayFab")]
		internal class NoDeviceInfo
		{
			// Token: 0x060001EC RID: 492 RVA: 0x0001A088 File Offset: 0x00018288
			private static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000049 RID: 73
		[HarmonyPatch(typeof(PlayFabClientInstanceAPI), "ReportPlayer", 0)]
		public class NoReportPlayer
		{
			// Token: 0x060001EE RID: 494 RVA: 0x0001A0A4 File Offset: 0x000182A4
			[NullableContext(1)]
			private static bool Prefix(ReportPlayerClientRequest request, Action<ReportPlayerClientResult> resultCallback, Action<PlayFabError> errorCallback, object customData = null, Dictionary<string, string> extraHeaders = null)
			{
				return false;
			}
		}

		// Token: 0x0200004A RID: 74
		[HarmonyPatch(typeof(PlayFabClientAPI), "ReportPlayer", 0)]
		public class PlayFabReportPatch2
		{
			// Token: 0x060001F0 RID: 496 RVA: 0x0001A0C0 File Offset: 0x000182C0
			[NullableContext(1)]
			private static bool Prefix(ReportPlayerClientRequest request, Action<ReportPlayerClientResult> resultCallback, Action<PlayFabError> errorCallback, object customData = null, Dictionary<string, string> extraHeaders = null)
			{
				return false;
			}
		}

		// Token: 0x0200004B RID: 75
		[HarmonyPatch(typeof(GorillaNot), "SendReport")]
		public static class NoSendReport
		{
			// Token: 0x060001F2 RID: 498 RVA: 0x0001A0DC File Offset: 0x000182DC
			[NullableContext(1)]
			private static bool Prefix(string susReason, string susId, string susNick)
			{
				bool antiCheatNotifications = OtherPatches.NoSendReport.AntiCheatNotifications;
				if (antiCheatNotifications)
				{
					bool flag = susId == PhotonNetwork.LocalPlayer.UserId;
					if (flag)
					{
						NotificationLib.SendNotification("<color=blue>Anti-Cheat</color> : Reason: " + susReason);
					}
				}
				return false;
			}

			// Token: 0x0400025B RID: 603
			public static bool AntiCheatNotifications;
		}

		// Token: 0x0200004C RID: 76
		[HarmonyPatch(typeof(GorillaNot), "CheckReports", 5)]
		public class ReportCheck : MonoBehaviourPunCallbacks
		{
			// Token: 0x060001F3 RID: 499 RVA: 0x0001A124 File Offset: 0x00018324
			public static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x0200004D RID: 77
		[HarmonyPatch(typeof(GorillaNot), "LogErrorCount")]
		public class LogErrorCount : MonoBehaviourPunCallbacks
		{
			// Token: 0x060001F5 RID: 501 RVA: 0x0001A140 File Offset: 0x00018340
			public static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x0200004E RID: 78
		[HarmonyPatch(typeof(GorillaNot), "DispatchReport")]
		public class Dispatch : MonoBehaviourPunCallbacks
		{
			// Token: 0x060001F7 RID: 503 RVA: 0x0001A15C File Offset: 0x0001835C
			public static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x0200004F RID: 79
		[HarmonyPatch(typeof(GorillaNetworkPublicTestsJoin))]
		[HarmonyPatch("GracePeriod", 5)]
		public class NoGracePeriod
		{
			// Token: 0x060001F9 RID: 505 RVA: 0x0001A178 File Offset: 0x00018378
			public static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000050 RID: 80
		[HarmonyPatch(typeof(GorillaNetworkPublicTestsJoin))]
		[HarmonyPatch("LateUpdate", 0)]
		public class NoGracePeriod4
		{
			// Token: 0x060001FB RID: 507 RVA: 0x0001A194 File Offset: 0x00018394
			public static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000051 RID: 81
		[HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2))]
		[HarmonyPatch("GracePeriod", 5)]
		public class NoGracePeriod3
		{
			// Token: 0x060001FD RID: 509 RVA: 0x0001A1B0 File Offset: 0x000183B0
			public static bool Prefix()
			{
				return false;
			}
		}

		// Token: 0x02000052 RID: 82
		[HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2))]
		[HarmonyPatch("LateUpdate", 0)]
		public class NoGracePeriod2
		{
			// Token: 0x060001FF RID: 511 RVA: 0x0001A1CC File Offset: 0x000183CC
			public static bool Prefix()
			{
				return false;
			}
		}
	}
}
