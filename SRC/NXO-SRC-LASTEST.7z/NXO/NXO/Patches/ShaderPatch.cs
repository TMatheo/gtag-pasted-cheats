﻿using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

namespace NXO.Patches
{
	// Token: 0x02000015 RID: 21
	[HarmonyPatch(typeof(GameObject), "CreatePrimitive", 0)]
	public class ShaderPatch
	{
		// Token: 0x06000097 RID: 151 RVA: 0x000079E0 File Offset: 0x00005BE0
		[NullableContext(1)]
		public static void Postfix(GameObject __result)
		{
			bool flag = __result.GetComponent<Renderer>() != null;
			if (flag)
			{
				__result.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
				__result.GetComponent<Renderer>().material.color = Color.black;
			}
		}
	}
}
