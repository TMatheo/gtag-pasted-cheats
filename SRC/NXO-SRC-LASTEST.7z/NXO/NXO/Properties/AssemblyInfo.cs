﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyCompany("NXO")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+6280a7f02a1f30ea65b01dd620d4b63ac4f4c38a")]
[assembly: AssemblyProduct("NXO")]
[assembly: AssemblyTitle("NXO")]
[assembly: SecurityPermission(8, SkipVerification = true)]
