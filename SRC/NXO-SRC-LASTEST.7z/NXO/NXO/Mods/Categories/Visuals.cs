﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using NXO.Utilities;
using Photon.Pun;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000029 RID: 41
	[NullableContext(1)]
	[Nullable(0)]
	public class Visuals : MonoBehaviourPunCallbacks
	{
		// Token: 0x06000157 RID: 343 RVA: 0x00014008 File Offset: 0x00012208
		private static Color32 GetTeamColor(bool isInfected, bool teamChecked, VRRig rig)
		{
			Color32 result;
			if (teamChecked)
			{
				result = (isInfected ? new Color32(byte.MaxValue, 0, 0, 175) : new Color32(0, byte.MaxValue, 0, 175));
			}
			else
			{
				result = (isInfected ? new Color32(byte.MaxValue, 0, 0, 175) : new Color32((byte)(rig.mainSkin.material.color.r * 255f), (byte)(rig.mainSkin.material.color.g * 255f), (byte)(rig.mainSkin.material.color.b * 255f), 175));
			}
			return result;
		}

		// Token: 0x06000158 RID: 344 RVA: 0x000140C0 File Offset: 0x000122C0
		private static Material EnsureMaterial(ref Material material, Shader shader)
		{
			bool flag = material == null || material.shader != shader;
			if (flag)
			{
				bool flag2 = material != null;
				if (flag2)
				{
					Object.Destroy(material);
				}
				material = new Material(shader);
			}
			return material;
		}

		// Token: 0x06000159 RID: 345 RVA: 0x00014110 File Offset: 0x00012310
		private static Vector3[] CalculateCorners(Vector3 center, Vector3 halfSize, Quaternion rotation)
		{
			Vector3[] array = new Vector3[]
			{
				new Vector3(-halfSize.x, -halfSize.y, -halfSize.z),
				new Vector3(halfSize.x, -halfSize.y, -halfSize.z),
				new Vector3(halfSize.x, -halfSize.y, halfSize.z),
				new Vector3(-halfSize.x, -halfSize.y, halfSize.z),
				new Vector3(-halfSize.x, halfSize.y, -halfSize.z),
				new Vector3(halfSize.x, halfSize.y, -halfSize.z),
				new Vector3(halfSize.x, halfSize.y, halfSize.z),
				new Vector3(-halfSize.x, halfSize.y, halfSize.z)
			};
			Vector3[] array2 = new Vector3[8];
			for (int i = 0; i < 8; i++)
			{
				array2[i] = center + rotation * array[i];
			}
			return array2;
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0001425C File Offset: 0x0001245C
		private static void DestroyDictionary<[Nullable(2)] T>(Dictionary<T, GameObject> dictionary)
		{
			foreach (GameObject gameObject in dictionary.Values)
			{
				bool flag = gameObject != null;
				if (flag)
				{
					Object.Destroy(gameObject);
				}
			}
			dictionary.Clear();
			dictionary = null;
		}

		// Token: 0x0600015B RID: 347 RVA: 0x000142CC File Offset: 0x000124CC
		private static void DestroyNestedList(Dictionary<VRRig, List<GameObject>> dictionary)
		{
			foreach (List<GameObject> list in dictionary.Values)
			{
				foreach (GameObject gameObject in list)
				{
					bool flag = gameObject != null;
					if (flag)
					{
						Object.Destroy(gameObject);
					}
				}
			}
			dictionary.Clear();
			dictionary = null;
		}

		// Token: 0x0600015C RID: 348 RVA: 0x00014378 File Offset: 0x00012578
		private static void DestroyMaterial(ref Material material)
		{
			bool flag = material != null;
			if (flag)
			{
				Object.Destroy(material);
				material = null;
			}
		}

		// Token: 0x0600015D RID: 349 RVA: 0x000143A0 File Offset: 0x000125A0
		private void OnDestroy()
		{
			Visuals.DestroyDictionary<VRRig>(Visuals.tracerLines);
			Visuals.DestroyMaterial(ref Visuals.tracerLineMaterial);
			Visuals.DestroyNestedList(Visuals.wireframeLines);
			Visuals.DestroyMaterial(ref Visuals.wireframeLineMaterial);
			Visuals.DestroyNestedList(Visuals.twoDBoxLines);
			Visuals.DestroyMaterial(ref Visuals.twoDBoxMaterial);
			Visuals.DestroyNestedList(Visuals.boneLines);
			Visuals.DestroyMaterial(ref Visuals.boneLineMaterial);
			Visuals.DestroyDictionary<VRRig>(Visuals.beaconLines);
			Visuals.DestroyMaterial(ref Visuals.beaconLineMaterial);
			bool flag = Visuals.originalSettings != null;
			if (flag)
			{
				foreach (VRRig vrrig in Visuals.originalSettings.Keys)
				{
					bool flag2 = vrrig.mainSkin != null;
					if (flag2)
					{
						vrrig.mainSkin.material.shader = Visuals.originalSettings[vrrig].Item1;
						vrrig.mainSkin.material.color = Visuals.originalSettings[vrrig].Item2;
					}
				}
				Visuals.originalSettings.Clear();
				Visuals.originalSettings = null;
			}
			bool flag3 = Visuals.originalLightmaps != null;
			if (flag3)
			{
				LightmapSettings.lightmaps = Visuals.originalLightmaps;
				Visuals.originalLightmaps = null;
			}
			Visuals.brightModeLightmaps = null;
			Visuals.cachedLeaves.Clear();
			Visuals.cachedLeaves = null;
		}

		// Token: 0x0600015E RID: 350 RVA: 0x00014514 File Offset: 0x00012714
		public static void TracersESP(bool tracersOn)
		{
			Visuals.tracerLineMaterial = Visuals.EnsureMaterial(ref Visuals.tracerLineMaterial, ColorLib.guiShader);
			if (tracersOn)
			{
				List<VRRig> vrrigs = GorillaParent.instance.vrrigs;
				List<VRRig> list = new List<VRRig>();
				foreach (VRRig vrrig in Visuals.tracerLines.Keys)
				{
					bool flag = vrrig == null || !vrrigs.Contains(vrrig) || vrrig.isOfflineVRRig;
					if (flag)
					{
						list.Add(vrrig);
					}
				}
				foreach (VRRig vrrig2 in list)
				{
					GameObject gameObject;
					bool flag2 = Visuals.tracerLines.TryGetValue(vrrig2, ref gameObject);
					if (flag2)
					{
						bool flag3 = gameObject != null;
						if (flag3)
						{
							Object.Destroy(gameObject);
						}
						Visuals.tracerLines.Remove(vrrig2);
					}
				}
				foreach (VRRig vrrig3 in vrrigs)
				{
					bool flag4 = vrrig3.isMyPlayer || vrrig3.isOfflineVRRig;
					if (!flag4)
					{
						GameObject gameObject2;
						bool flag5 = !Visuals.tracerLines.TryGetValue(vrrig3, ref gameObject2) || gameObject2 == null;
						if (flag5)
						{
							gameObject2 = new GameObject("Tracer Line");
							LineRenderer lineRenderer = gameObject2.AddComponent<LineRenderer>();
							lineRenderer.positionCount = 2;
							lineRenderer.startWidth = 0.02f;
							lineRenderer.endWidth = 0.02f;
							lineRenderer.useWorldSpace = true;
							lineRenderer.material = Visuals.tracerLineMaterial;
							Visuals.tracerLines[vrrig3] = gameObject2;
						}
						LineRenderer component = gameObject2.GetComponent<LineRenderer>();
						bool isInfected = Variables.RigIsInfected(vrrig3);
						Color32 teamColor = Visuals.GetTeamColor(isInfected, Variables.teamCheckedESP, vrrig3);
						component.startColor = teamColor;
						component.endColor = teamColor;
						switch (Settings.tracerPositionIndex)
						{
						case 0:
							component.SetPosition(0, Variables.taggerInstance.rightHandTransform.position);
							break;
						case 1:
							component.SetPosition(0, Variables.taggerInstance.leftHandTransform.position);
							break;
						case 2:
							component.SetPosition(0, Variables.taggerInstance.headCollider.transform.position + new Vector3(0f, 0.4f, 0f));
							break;
						case 3:
							component.SetPosition(0, Variables.taggerInstance.bodyCollider.transform.position + new Vector3(0f, -0.3f, 0f));
							break;
						default:
							component.SetPosition(0, Variables.taggerInstance.rightHandTransform.position);
							break;
						}
						component.SetPosition(1, vrrig3.transform.position);
					}
				}
			}
			else
			{
				Visuals.DestroyDictionary<VRRig>(Visuals.tracerLines);
			}
		}

		// Token: 0x0600015F RID: 351 RVA: 0x00014894 File Offset: 0x00012A94
		public static void ESP3D(bool wireframeOn)
		{
			Visuals.wireframeLineMaterial = Visuals.EnsureMaterial(ref Visuals.wireframeLineMaterial, ColorLib.guiShader);
			if (wireframeOn)
			{
				List<VRRig> vrrigs = GorillaParent.instance.vrrigs;
				List<VRRig> list = new List<VRRig>();
				foreach (VRRig vrrig in Visuals.wireframeLines.Keys)
				{
					bool flag = vrrig == null || !vrrigs.Contains(vrrig) || vrrig.isOfflineVRRig;
					if (flag)
					{
						list.Add(vrrig);
					}
				}
				foreach (VRRig vrrig2 in list)
				{
					List<GameObject> list2;
					bool flag2 = Visuals.wireframeLines.TryGetValue(vrrig2, ref list2);
					if (flag2)
					{
						foreach (GameObject gameObject in list2)
						{
							bool flag3 = gameObject != null;
							if (flag3)
							{
								Object.Destroy(gameObject);
							}
						}
						Visuals.wireframeLines.Remove(vrrig2);
					}
				}
				foreach (VRRig vrrig3 in vrrigs)
				{
					bool isOfflineVRRig = vrrig3.isOfflineVRRig;
					if (!isOfflineVRRig)
					{
						bool flag4 = !Visuals.wireframeLines.ContainsKey(vrrig3);
						if (flag4)
						{
							List<GameObject> list3 = new List<GameObject>();
							foreach (int[] array2 in Visuals.edgeIndices)
							{
								GameObject gameObject2 = new GameObject("Wireframe Line");
								LineRenderer lineRenderer = gameObject2.AddComponent<LineRenderer>();
								lineRenderer.positionCount = 2;
								lineRenderer.startWidth = 0.06f;
								lineRenderer.endWidth = 0.06f;
								lineRenderer.useWorldSpace = true;
								lineRenderer.material = Visuals.wireframeLineMaterial;
								list3.Add(gameObject2);
							}
							Visuals.wireframeLines[vrrig3] = list3;
						}
						Vector3 halfSize;
						halfSize..ctor(vrrig3.transform.localScale.x * 0.375f, vrrig3.transform.localScale.y * 0.525f, vrrig3.transform.localScale.z * 0.375f);
						Vector3 center = vrrig3.transform.position - new Vector3(0f, 0.075f, 0f);
						Quaternion rotation = vrrig3.transform.rotation;
						Vector3[] array3 = Visuals.CalculateCorners(center, halfSize, rotation);
						bool isInfected = Variables.RigIsInfected(vrrig3);
						Color32 teamColor = Visuals.GetTeamColor(isInfected, Variables.teamCheckedESP, vrrig3);
						List<GameObject> list4;
						bool flag5 = Visuals.wireframeLines.TryGetValue(vrrig3, ref list4);
						if (flag5)
						{
							for (int j = 0; j < list4.Count; j++)
							{
								LineRenderer component = list4[j].GetComponent<LineRenderer>();
								bool flag6 = component == null;
								if (!flag6)
								{
									component.startColor = teamColor;
									component.endColor = teamColor;
									component.SetPositions(new Vector3[]
									{
										array3[Visuals.edgeIndices[j][0]],
										array3[Visuals.edgeIndices[j][1]]
									});
								}
							}
						}
					}
				}
			}
			else
			{
				Visuals.DestroyNestedList(Visuals.wireframeLines);
			}
		}

		// Token: 0x06000160 RID: 352 RVA: 0x00014C9C File Offset: 0x00012E9C
		public static void ESP2D(bool boxESPOn)
		{
			Visuals.twoDBoxMaterial = Visuals.EnsureMaterial(ref Visuals.twoDBoxMaterial, ColorLib.guiShader);
			if (boxESPOn)
			{
				List<VRRig> vrrigs = GorillaParent.instance.vrrigs;
				List<VRRig> list = new List<VRRig>();
				foreach (VRRig vrrig in Visuals.twoDBoxLines.Keys)
				{
					bool flag = vrrig == null || !vrrigs.Contains(vrrig) || vrrig.isOfflineVRRig;
					if (flag)
					{
						list.Add(vrrig);
					}
				}
				foreach (VRRig vrrig2 in list)
				{
					List<GameObject> list2;
					bool flag2 = Visuals.twoDBoxLines.TryGetValue(vrrig2, ref list2);
					if (flag2)
					{
						foreach (GameObject gameObject in list2)
						{
							bool flag3 = gameObject != null;
							if (flag3)
							{
								Object.Destroy(gameObject);
							}
						}
						Visuals.twoDBoxLines.Remove(vrrig2);
					}
				}
				foreach (VRRig vrrig3 in vrrigs)
				{
					bool isOfflineVRRig = vrrig3.isOfflineVRRig;
					if (!isOfflineVRRig)
					{
						List<GameObject> list3;
						bool flag4 = !Visuals.twoDBoxLines.TryGetValue(vrrig3, ref list3) || list3 == null;
						if (flag4)
						{
							list3 = new List<GameObject>();
							for (int i = 0; i < 4; i++)
							{
								GameObject gameObject2 = new GameObject("2D Box Line");
								LineRenderer lineRenderer = gameObject2.AddComponent<LineRenderer>();
								lineRenderer.positionCount = 2;
								lineRenderer.startWidth = 0.07f;
								lineRenderer.endWidth = 0.07f;
								lineRenderer.material = Visuals.twoDBoxMaterial;
								lineRenderer.useWorldSpace = true;
								list3.Add(gameObject2);
							}
							Visuals.twoDBoxLines[vrrig3] = list3;
						}
						bool isInfected = Variables.RigIsInfected(vrrig3);
						Color32 teamColor = Visuals.GetTeamColor(isInfected, Variables.teamCheckedESP, vrrig3);
						Vector3 position = vrrig3.transform.position;
						Vector3 position2 = Camera.main.transform.position;
						Quaternion quaternion = Quaternion.LookRotation(position - position2);
						float num = 0.03f;
						Vector3[] array = new Vector3[]
						{
							position + quaternion * new Vector3(-0.5f - num, 0.5f + num, 0f),
							position + quaternion * new Vector3(0.5f + num, 0.5f + num, 0f),
							position + quaternion * new Vector3(0.5f + num, -0.5f - num, 0f),
							position + quaternion * new Vector3(-0.5f - num, -0.5f - num, 0f)
						};
						for (int j = 0; j < list3.Count; j++)
						{
							LineRenderer component = list3[j].GetComponent<LineRenderer>();
							bool flag5 = component == null;
							if (!flag5)
							{
								component.startColor = teamColor;
								component.endColor = teamColor;
								component.SetPositions(new Vector3[]
								{
									array[j] - (array[(j + 1) % array.Length] - array[j]).normalized * num,
									array[(j + 1) % array.Length] + (array[(j + 1) % array.Length] - array[j]).normalized * num
								});
							}
						}
					}
				}
			}
			else
			{
				Visuals.DestroyNestedList(Visuals.twoDBoxLines);
			}
		}

		// Token: 0x06000161 RID: 353 RVA: 0x00015154 File Offset: 0x00013354
		public static void SkeletonESP(bool skeletonESPOn)
		{
			Visuals.boneLineMaterial = Visuals.EnsureMaterial(ref Visuals.boneLineMaterial, ColorLib.guiShader);
			if (skeletonESPOn)
			{
				List<VRRig> vrrigs = GorillaParent.instance.vrrigs;
				List<VRRig> list = new List<VRRig>();
				foreach (VRRig vrrig in Visuals.boneLines.Keys)
				{
					bool flag = vrrig == null || !vrrigs.Contains(vrrig) || vrrig.isOfflineVRRig;
					if (flag)
					{
						list.Add(vrrig);
					}
				}
				foreach (VRRig vrrig2 in list)
				{
					List<GameObject> list2;
					bool flag2 = Visuals.boneLines.TryGetValue(vrrig2, ref list2);
					if (flag2)
					{
						foreach (GameObject gameObject in list2)
						{
							bool flag3 = gameObject != null;
							if (flag3)
							{
								Object.Destroy(gameObject);
							}
						}
						Visuals.boneLines.Remove(vrrig2);
					}
				}
				foreach (VRRig vrrig3 in vrrigs)
				{
					bool isOfflineVRRig = vrrig3.isOfflineVRRig;
					if (!isOfflineVRRig)
					{
						List<GameObject> list3;
						bool flag4 = !Visuals.boneLines.TryGetValue(vrrig3, ref list3) || list3 == null;
						if (flag4)
						{
							list3 = new List<GameObject>();
							GameObject gameObject2 = new GameObject("Head Line");
							LineRenderer lineRenderer = gameObject2.AddComponent<LineRenderer>();
							lineRenderer.positionCount = 2;
							lineRenderer.startWidth = 0.04f;
							lineRenderer.endWidth = 0.04f;
							lineRenderer.material = Visuals.boneLineMaterial;
							list3.Add(gameObject2);
							for (int i = 0; i < Visuals.bones.Length; i += 2)
							{
								GameObject gameObject3 = new GameObject("Bone Line");
								LineRenderer lineRenderer2 = gameObject3.AddComponent<LineRenderer>();
								lineRenderer2.positionCount = 2;
								lineRenderer2.startWidth = 0.04f;
								lineRenderer2.endWidth = 0.04f;
								lineRenderer2.material = Visuals.boneLineMaterial;
								list3.Add(gameObject3);
							}
							Visuals.boneLines[vrrig3] = list3;
						}
						bool isInfected = Variables.RigIsInfected(vrrig3);
						Color32 teamColor = Visuals.GetTeamColor(isInfected, Variables.teamCheckedESP, vrrig3);
						LineRenderer component = Visuals.boneLines[vrrig3][0].GetComponent<LineRenderer>();
						component.startColor = teamColor;
						component.endColor = teamColor;
						component.SetPositions(new Vector3[]
						{
							vrrig3.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f),
							vrrig3.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f)
						});
						for (int j = 0; j < Visuals.bones.Length; j += 2)
						{
							LineRenderer component2 = Visuals.boneLines[vrrig3][1 + j / 2].GetComponent<LineRenderer>();
							component2.startColor = teamColor;
							component2.endColor = teamColor;
							component2.SetPositions(new Vector3[]
							{
								vrrig3.mainSkin.bones[Visuals.bones[j]].position,
								vrrig3.mainSkin.bones[Visuals.bones[j + 1]].position
							});
						}
					}
				}
			}
			else
			{
				Visuals.DestroyNestedList(Visuals.boneLines);
			}
		}

		// Token: 0x06000162 RID: 354 RVA: 0x000155C0 File Offset: 0x000137C0
		public static void BeaconsESP(bool beaconsOn)
		{
			Visuals.beaconLineMaterial = Visuals.EnsureMaterial(ref Visuals.beaconLineMaterial, ColorLib.guiShader);
			if (beaconsOn)
			{
				List<VRRig> vrrigs = GorillaParent.instance.vrrigs;
				List<VRRig> list = new List<VRRig>();
				foreach (VRRig vrrig in Visuals.beaconLines.Keys)
				{
					bool flag = vrrig == null || !vrrigs.Contains(vrrig) || vrrig.isOfflineVRRig;
					if (flag)
					{
						list.Add(vrrig);
					}
				}
				foreach (VRRig vrrig2 in list)
				{
					GameObject gameObject;
					bool flag2 = Visuals.beaconLines.TryGetValue(vrrig2, ref gameObject);
					if (flag2)
					{
						bool flag3 = gameObject != null;
						if (flag3)
						{
							Object.Destroy(gameObject);
						}
						Visuals.beaconLines.Remove(vrrig2);
					}
				}
				foreach (VRRig vrrig3 in vrrigs)
				{
					bool flag4 = vrrig3.isOfflineVRRig || vrrig3.isMyPlayer;
					if (!flag4)
					{
						GameObject gameObject2;
						bool flag5 = !Visuals.beaconLines.TryGetValue(vrrig3, ref gameObject2) || gameObject2 == null;
						if (flag5)
						{
							gameObject2 = new GameObject("Beacon Line");
							LineRenderer lineRenderer = gameObject2.AddComponent<LineRenderer>();
							lineRenderer.positionCount = 2;
							lineRenderer.startWidth = 0.15f;
							lineRenderer.endWidth = 0.15f;
							lineRenderer.useWorldSpace = true;
							lineRenderer.material = Visuals.beaconLineMaterial;
							Visuals.beaconLines[vrrig3] = gameObject2;
						}
						LineRenderer component = Visuals.beaconLines[vrrig3].GetComponent<LineRenderer>();
						bool flag6 = component == null;
						if (!flag6)
						{
							Vector3 position = vrrig3.transform.position;
							Vector3 vector = position + Vector3.up * 50f;
							Vector3 vector2 = position + Vector3.down * 50f;
							Color32 teamColor = Visuals.GetTeamColor(Variables.RigIsInfected(vrrig3), Variables.teamCheckedESP, vrrig3);
							component.startColor = teamColor;
							component.endColor = teamColor;
							component.SetPositions(new Vector3[]
							{
								vector2,
								vector
							});
						}
					}
				}
			}
			else
			{
				Visuals.DestroyDictionary<VRRig>(Visuals.beaconLines);
			}
		}

		// Token: 0x06000163 RID: 355 RVA: 0x000158B8 File Offset: 0x00013AB8
		public static void ChamsESP(bool enable)
		{
			if (enable)
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					bool flag = Variables.IsOtherPlayer(vrrig);
					if (flag)
					{
						SkinnedMeshRenderer mainSkin = vrrig.mainSkin;
						bool flag2 = ((mainSkin != null) ? mainSkin.material : null) != null;
						if (flag2)
						{
							Color color = vrrig.mainSkin.material.color;
							vrrig.mainSkin.material.shader = ColorLib.guiShader;
							bool flag3 = Variables.RigIsInfected(vrrig);
							if (flag3)
							{
								vrrig.mainSkin.material.color = new Color32(byte.MaxValue, 0, 0, 175);
							}
							else
							{
								vrrig.mainSkin.material.color = new Color32(0, byte.MaxValue, 0, 175);
							}
						}
					}
				}
			}
			else
			{
				foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
				{
					bool flag4;
					if (vrrig2 != GorillaTagger.Instance.offlineVRRig)
					{
						SkinnedMeshRenderer mainSkin2 = vrrig2.mainSkin;
						Object @object;
						if (mainSkin2 == null)
						{
							@object = null;
						}
						else
						{
							Material material = mainSkin2.material;
							@object = ((material != null) ? material.shader : null);
						}
						flag4 = (@object == ColorLib.guiShader);
					}
					else
					{
						flag4 = false;
					}
					bool flag5 = flag4;
					if (flag5)
					{
						vrrig2.mainSkin.material.shader = ColorLib.uberShader;
					}
				}
			}
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00015A88 File Offset: 0x00013C88
		public static void FPSBoost(bool enableBadGraphics)
		{
			bool flag = enableBadGraphics == Visuals.isBadGraphicsActive;
			if (!flag)
			{
				if (enableBadGraphics)
				{
					bool flag2 = !Visuals.settingsBackedUp;
					if (flag2)
					{
						Visuals.originalglobalTextureMipmapLimit = QualitySettings.globalTextureMipmapLimit;
						Visuals.originalPixelLightCount = QualitySettings.pixelLightCount;
						Visuals.originalShadowQuality = QualitySettings.shadows;
						Visuals.originalShadowResolution = QualitySettings.shadowResolution;
						Visuals.originalShadowDistance = QualitySettings.shadowDistance;
						Visuals.originalShadowCascades = QualitySettings.shadowCascades;
						Visuals.originalRealtimeReflectionProbes = QualitySettings.realtimeReflectionProbes;
						Visuals.originalSoftParticles = QualitySettings.softParticles;
						Visuals.originalLodBias = QualitySettings.lodBias;
						Visuals.originalAntiAliasing = QualitySettings.antiAliasing;
						Visuals.originalVSyncCount = QualitySettings.vSyncCount;
						Visuals.originalQualityLevel = QualitySettings.GetQualityLevel();
						Visuals.originalSkinWeights = QualitySettings.skinWeights;
						Visuals.originalAnisotropicFiltering = QualitySettings.anisotropicFiltering;
						Visuals.originalParticleRaycastBudget = QualitySettings.particleRaycastBudget;
						Visuals.originalMaxQueuedFrames = QualitySettings.maxQueuedFrames;
						Visuals.settingsBackedUp = true;
					}
					QualitySettings.globalTextureMipmapLimit = 99999;
					QualitySettings.pixelLightCount = 0;
					QualitySettings.shadows = 0;
					QualitySettings.shadowResolution = 0;
					QualitySettings.shadowDistance = 0f;
					QualitySettings.shadowCascades = 0;
					QualitySettings.realtimeReflectionProbes = false;
					QualitySettings.softParticles = false;
					QualitySettings.lodBias = 0.2f;
					QualitySettings.antiAliasing = 0;
					QualitySettings.vSyncCount = 0;
					QualitySettings.SetQualityLevel(0, true);
					QualitySettings.skinWeights = 1;
					QualitySettings.anisotropicFiltering = 0;
					QualitySettings.particleRaycastBudget = 64;
					QualitySettings.maxQueuedFrames = 1;
					QualitySettings.asyncUploadTimeSlice = 2;
					QualitySettings.asyncUploadBufferSize = 1;
					QualitySettings.asyncUploadPersistentBuffer = false;
				}
				else
				{
					QualitySettings.globalTextureMipmapLimit = Visuals.originalglobalTextureMipmapLimit;
					QualitySettings.pixelLightCount = Visuals.originalPixelLightCount;
					QualitySettings.shadows = Visuals.originalShadowQuality;
					QualitySettings.shadowResolution = Visuals.originalShadowResolution;
					QualitySettings.shadowDistance = Visuals.originalShadowDistance;
					QualitySettings.shadowCascades = Visuals.originalShadowCascades;
					QualitySettings.realtimeReflectionProbes = Visuals.originalRealtimeReflectionProbes;
					QualitySettings.softParticles = Visuals.originalSoftParticles;
					QualitySettings.lodBias = Visuals.originalLodBias;
					QualitySettings.antiAliasing = Visuals.originalAntiAliasing;
					QualitySettings.vSyncCount = Visuals.originalVSyncCount;
					QualitySettings.SetQualityLevel(Visuals.originalQualityLevel, true);
					QualitySettings.skinWeights = Visuals.originalSkinWeights;
					QualitySettings.anisotropicFiltering = Visuals.originalAnisotropicFiltering;
					QualitySettings.particleRaycastBudget = Visuals.originalParticleRaycastBudget;
					QualitySettings.maxQueuedFrames = Visuals.originalMaxQueuedFrames;
					QualitySettings.asyncUploadTimeSlice = 4;
					QualitySettings.asyncUploadBufferSize = 4;
					QualitySettings.asyncUploadPersistentBuffer = true;
				}
				Visuals.isBadGraphicsActive = enableBadGraphics;
			}
		}

		// Token: 0x06000165 RID: 357 RVA: 0x00015CD0 File Offset: 0x00013ED0
		public static void FuckLights(bool fuckLights)
		{
			if (fuckLights)
			{
				BetterDayNightManager.instance.AnimateLightFlash(2, 0f, 0f, 2f);
			}
			else
			{
				BetterDayNightManager.instance.AnimateLightFlash(2, 2f, 2f, 2f);
			}
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00015D24 File Offset: 0x00013F24
		public static void FPC(bool enableFPC)
		{
			bool flag = Variables.shoulderCamera == null;
			if (flag)
			{
				Variables.shoulderCamera = GameObject.Find("Shoulder Camera");
			}
			bool flag2 = Variables.thirdPersonCamera == null;
			if (flag2)
			{
				Variables.thirdPersonCamera = GameObject.Find("Third Person Camera");
			}
			if (enableFPC)
			{
				bool flag3 = !Variables.didThirdPerson;
				if (flag3)
				{
					Variables.didThirdPerson = true;
					Variables.TransformCam = GameObject.Find("CM vcam1");
				}
				bool flag4 = Variables.TransformCam != null;
				if (flag4)
				{
					Variables.TransformCam.SetActive(false);
				}
				bool flag5 = Variables.shoulderCamera != null;
				if (flag5)
				{
					Variables.shoulderCamera.transform.SetParent(Camera.main.transform);
					Variables.shoulderCamera.transform.localPosition = Vector3.zero;
					Variables.shoulderCamera.transform.localRotation = Quaternion.identity;
					Variables.shoulderCamera.GetComponent<Camera>().fieldOfView = Settings.FOV;
				}
			}
			else
			{
				bool flag6 = Variables.TransformCam != null;
				if (flag6)
				{
					Variables.TransformCam.SetActive(true);
				}
				bool flag7 = Variables.shoulderCamera != null && Variables.thirdPersonCamera != null;
				if (flag7)
				{
					Variables.shoulderCamera.transform.SetParent(Variables.thirdPersonCamera.transform);
					Variables.shoulderCamera.transform.localPosition = Vector3.zero;
					Variables.shoulderCamera.transform.localRotation = Quaternion.identity;
				}
			}
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00015EB8 File Offset: 0x000140B8
		public static void ChangeTime()
		{
			Visuals.TimeType = (Visuals.TimeType + 1) % 7;
			switch (Visuals.TimeType)
			{
			case 0:
				BetterDayNightManager.instance.SetTimeOfDay(0);
				break;
			case 1:
				BetterDayNightManager.instance.SetTimeOfDay(1);
				break;
			case 2:
				BetterDayNightManager.instance.SetTimeOfDay(2);
				break;
			case 3:
				BetterDayNightManager.instance.SetTimeOfDay(3);
				break;
			case 4:
				BetterDayNightManager.instance.SetTimeOfDay(4);
				break;
			case 5:
				BetterDayNightManager.instance.SetTimeOfDay(5);
				break;
			case 6:
				BetterDayNightManager.instance.SetTimeOfDay(6);
				break;
			default:
				BetterDayNightManager.instance.SetTimeOfDay(0);
				Visuals.TimeType = 0;
				break;
			}
		}

		// Token: 0x06000168 RID: 360 RVA: 0x00015F88 File Offset: 0x00014188
		public static void RainyWeather(bool setActive)
		{
			if (setActive)
			{
				for (int i = 1; i < BetterDayNightManager.instance.weatherCycle.Length; i++)
				{
					BetterDayNightManager.instance.weatherCycle[i] = 1;
				}
			}
			else
			{
				for (int j = 1; j < BetterDayNightManager.instance.weatherCycle.Length; j++)
				{
					BetterDayNightManager.instance.weatherCycle[j] = 0;
				}
			}
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00016000 File Offset: 0x00014200
		public static void DarkMode(bool isEnabled)
		{
			if (isEnabled)
			{
				bool flag = Visuals.originalLightmaps == null;
				if (flag)
				{
					Visuals.originalLightmaps = LightmapSettings.lightmaps;
				}
				LightmapSettings.lightmaps = null;
			}
			else
			{
				bool flag2 = Visuals.originalLightmaps != null;
				if (flag2)
				{
					LightmapSettings.lightmaps = Visuals.originalLightmaps;
					Visuals.originalLightmaps = null;
				}
			}
		}

		// Token: 0x0600016A RID: 362 RVA: 0x00016058 File Offset: 0x00014258
		public static void BrightMode(bool isEnabled)
		{
			if (isEnabled)
			{
				bool flag = Visuals.originalLightmaps == null;
				if (flag)
				{
					Visuals.originalLightmaps = LightmapSettings.lightmaps;
				}
				bool flag2 = Visuals.BlindingModeLightmaps == null && Visuals.originalLightmaps != null;
				if (flag2)
				{
					Visuals.BlindingModeLightmaps = new LightmapData[Visuals.originalLightmaps.Length];
					for (int i = 0; i < Visuals.originalLightmaps.Length; i++)
					{
						LightmapData lightmapData = new LightmapData();
						lightmapData.lightmapColor = Texture2D.whiteTexture;
						Visuals.BlindingModeLightmaps[i] = lightmapData;
					}
				}
				LightmapSettings.lightmaps = Visuals.BlindingModeLightmaps;
			}
			else
			{
				bool flag3 = Visuals.originalLightmaps != null;
				if (flag3)
				{
					LightmapSettings.lightmaps = Visuals.originalLightmaps;
					Visuals.originalLightmaps = null;
				}
				bool flag4 = Visuals.BlindingModeLightmaps != null;
				if (flag4)
				{
					Visuals.BlindingModeLightmaps = null;
				}
			}
		}

		// Token: 0x0600016B RID: 363 RVA: 0x00016130 File Offset: 0x00014330
		public static void DisableLeaves(bool setActive)
		{
			bool flag = setActive && !Visuals.areLeavesDisabled;
			if (flag)
			{
				Visuals.cachedLeaves.Clear();
				foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
				{
					bool flag2 = gameObject.activeSelf && (gameObject.name.Contains("leaves_green") || gameObject.name.Contains("fallleaves"));
					if (flag2)
					{
						gameObject.SetActive(false);
						Visuals.cachedLeaves.Add(gameObject);
					}
				}
				Visuals.areLeavesDisabled = true;
			}
			else
			{
				bool flag3 = !setActive && Visuals.areLeavesDisabled;
				if (flag3)
				{
					foreach (GameObject gameObject2 in Visuals.cachedLeaves)
					{
						bool flag4 = gameObject2 != null;
						if (flag4)
						{
							gameObject2.SetActive(true);
						}
					}
					Visuals.cachedLeaves.Clear();
					Visuals.areLeavesDisabled = false;
				}
			}
		}

		// Token: 0x0600016C RID: 364 RVA: 0x00016250 File Offset: 0x00014450
		public static void ReverseBodyAndCamera(bool setActive)
		{
			if (setActive)
			{
				Variables.playerInstance.transform.rotation = Quaternion.Euler(180f, Variables.playerInstance.transform.rotation.eulerAngles.y, 0f);
			}
			else
			{
				Variables.playerInstance.transform.rotation = Quaternion.Euler(0f, Variables.playerInstance.transform.rotation.eulerAngles.y, 0f);
			}
		}

		// Token: 0x0600016D RID: 365 RVA: 0x000162E0 File Offset: 0x000144E0
		public static void Nametags(bool enableNametags)
		{
			if (enableNametags)
			{
				List<VRRig> vrrigs = GorillaParent.instance.vrrigs;
				List<VRRig> list = new List<VRRig>();
				foreach (VRRig vrrig in Visuals.nametags.Keys)
				{
					bool flag = vrrig == null || !vrrigs.Contains(vrrig) || vrrig.isOfflineVRRig;
					if (flag)
					{
						list.Add(vrrig);
					}
				}
				foreach (VRRig vrrig2 in list)
				{
					GameObject gameObject;
					bool flag2 = Visuals.nametags.TryGetValue(vrrig2, ref gameObject);
					if (flag2)
					{
						Object.Destroy(gameObject);
						Visuals.nametags.Remove(vrrig2);
					}
				}
				foreach (VRRig vrrig3 in vrrigs)
				{
					bool flag3 = vrrig3.isMyPlayer || vrrig3.isOfflineVRRig;
					if (!flag3)
					{
						bool flag4 = !Visuals.nametags.ContainsKey(vrrig3);
						if (flag4)
						{
							GameObject gameObject2 = new GameObject("Nametag");
							gameObject2.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
							TextMesh textMesh = gameObject2.AddComponent<TextMesh>();
							textMesh.text = string.Concat(new string[]
							{
								vrrig3.Creator.NickName.ToUpper(),
								" (",
								(vrrig3.mainSkin.material.color.r * 9f).ToString(),
								", ",
								(vrrig3.mainSkin.material.color.g * 9f).ToString(),
								", ",
								(vrrig3.mainSkin.material.color.b * 9f).ToString(),
								") \n",
								vrrig3.Creator.UserId.ToUpper()
							});
							textMesh.fontSize = 300;
							textMesh.fontStyle = 1;
							textMesh.color = vrrig3.playerColor;
							textMesh.anchor = 4;
							textMesh.alignment = 1;
							Visuals.nametags[vrrig3] = gameObject2;
						}
						GameObject gameObject3 = Visuals.nametags[vrrig3];
						bool flag5 = gameObject3 != null;
						if (flag5)
						{
							gameObject3.transform.position = vrrig3.headMesh.transform.position + vrrig3.headMesh.transform.up * 0.7f;
							gameObject3.transform.LookAt(Camera.main.transform);
							gameObject3.transform.Rotate(0f, 180f, 0f);
						}
					}
				}
			}
			else
			{
				foreach (GameObject gameObject4 in Visuals.nametags.Values)
				{
					bool flag6 = gameObject4 != null;
					if (flag6)
					{
						Object.Destroy(gameObject4);
					}
				}
				Visuals.nametags.Clear();
			}
		}

		// Token: 0x0600016F RID: 367 RVA: 0x000166EC File Offset: 0x000148EC
		// Note: this type is marked as 'beforefieldinit'.
		static Visuals()
		{
			int[][] array = new int[12][];
			array[0] = new int[]
			{
				default(int),
				1
			};
			array[1] = new int[]
			{
				1,
				2
			};
			array[2] = new int[]
			{
				2,
				3
			};
			int num = 3;
			int[] array2 = new int[2];
			array2[0] = 3;
			array[num] = array2;
			array[4] = new int[]
			{
				4,
				5
			};
			array[5] = new int[]
			{
				5,
				6
			};
			array[6] = new int[]
			{
				6,
				7
			};
			array[7] = new int[]
			{
				7,
				4
			};
			array[8] = new int[]
			{
				default(int),
				4
			};
			array[9] = new int[]
			{
				1,
				5
			};
			array[10] = new int[]
			{
				2,
				6
			};
			array[11] = new int[]
			{
				3,
				7
			};
			Visuals.edgeIndices = array;
			Visuals.bones = new int[]
			{
				4,
				3,
				5,
				4,
				19,
				18,
				20,
				19,
				3,
				18,
				21,
				20,
				22,
				21,
				25,
				21,
				29,
				21,
				31,
				29,
				27,
				25,
				24,
				22,
				6,
				5,
				7,
				6,
				10,
				6,
				14,
				6,
				16,
				14,
				12,
				10,
				9,
				7
			};
			Visuals.originalSettings = new Dictionary<VRRig, ValueTuple<Shader, Color>>();
			Visuals.TimeType = 0;
			Visuals.originalLightmaps = null;
			Visuals.brightModeLightmaps = null;
			Visuals.BlindingModeLightmaps = null;
			Visuals.settingsBackedUp = false;
			Visuals.isBadGraphicsActive = false;
			Visuals.cachedLeaves = new List<GameObject>();
			Visuals.areLeavesDisabled = false;
			Visuals.nametags = new Dictionary<VRRig, GameObject>();
		}

		// Token: 0x040001F4 RID: 500
		private static Dictionary<VRRig, GameObject> tracerLines = new Dictionary<VRRig, GameObject>();

		// Token: 0x040001F5 RID: 501
		private static Material tracerLineMaterial = null;

		// Token: 0x040001F6 RID: 502
		private static Dictionary<VRRig, GameObject> beaconLines = new Dictionary<VRRig, GameObject>();

		// Token: 0x040001F7 RID: 503
		private static Material beaconLineMaterial = null;

		// Token: 0x040001F8 RID: 504
		private static Dictionary<VRRig, List<GameObject>> wireframeLines = new Dictionary<VRRig, List<GameObject>>();

		// Token: 0x040001F9 RID: 505
		private static Material wireframeLineMaterial = null;

		// Token: 0x040001FA RID: 506
		private static Dictionary<VRRig, List<GameObject>> twoDBoxLines = new Dictionary<VRRig, List<GameObject>>();

		// Token: 0x040001FB RID: 507
		private static Material twoDBoxMaterial = null;

		// Token: 0x040001FC RID: 508
		private static Dictionary<VRRig, List<GameObject>> boneLines = new Dictionary<VRRig, List<GameObject>>();

		// Token: 0x040001FD RID: 509
		private static Material boneLineMaterial = null;

		// Token: 0x040001FE RID: 510
		private static readonly int[][] edgeIndices;

		// Token: 0x040001FF RID: 511
		public static readonly int[] bones;

		// Token: 0x04000200 RID: 512
		[TupleElementNames(new string[]
		{
			"originalShader",
			"originalColor"
		})]
		[Nullable(new byte[]
		{
			1,
			1,
			0,
			1
		})]
		private static Dictionary<VRRig, ValueTuple<Shader, Color>> originalSettings;

		// Token: 0x04000201 RID: 513
		public static int TimeType;

		// Token: 0x04000202 RID: 514
		private static LightmapData[] originalLightmaps;

		// Token: 0x04000203 RID: 515
		private static LightmapData[] brightModeLightmaps;

		// Token: 0x04000204 RID: 516
		private static LightmapData[] BlindingModeLightmaps;

		// Token: 0x04000205 RID: 517
		private static bool settingsBackedUp;

		// Token: 0x04000206 RID: 518
		private static int originalglobalTextureMipmapLimit;

		// Token: 0x04000207 RID: 519
		private static int originalPixelLightCount;

		// Token: 0x04000208 RID: 520
		private static ShadowQuality originalShadowQuality;

		// Token: 0x04000209 RID: 521
		private static ShadowResolution originalShadowResolution;

		// Token: 0x0400020A RID: 522
		private static float originalShadowDistance;

		// Token: 0x0400020B RID: 523
		private static int originalShadowCascades;

		// Token: 0x0400020C RID: 524
		private static bool originalRealtimeReflectionProbes;

		// Token: 0x0400020D RID: 525
		private static bool originalSoftParticles;

		// Token: 0x0400020E RID: 526
		private static float originalLodBias;

		// Token: 0x0400020F RID: 527
		private static int originalAntiAliasing;

		// Token: 0x04000210 RID: 528
		private static int originalVSyncCount;

		// Token: 0x04000211 RID: 529
		private static int originalQualityLevel;

		// Token: 0x04000212 RID: 530
		private static SkinWeights originalSkinWeights;

		// Token: 0x04000213 RID: 531
		private static AnisotropicFiltering originalAnisotropicFiltering;

		// Token: 0x04000214 RID: 532
		private static int originalParticleRaycastBudget;

		// Token: 0x04000215 RID: 533
		private static int originalMaxQueuedFrames;

		// Token: 0x04000216 RID: 534
		private static bool isBadGraphicsActive;

		// Token: 0x04000217 RID: 535
		private static List<GameObject> cachedLeaves;

		// Token: 0x04000218 RID: 536
		private static bool areLeavesDisabled;

		// Token: 0x04000219 RID: 537
		private static Dictionary<VRRig, GameObject> nametags;
	}
}
