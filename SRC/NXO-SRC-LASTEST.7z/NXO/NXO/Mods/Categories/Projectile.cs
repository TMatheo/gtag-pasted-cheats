﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using NXO.Menu;
using NXO.Utilities;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000021 RID: 33
	[NullableContext(1)]
	[Nullable(0)]
	public class Projectile
	{
		// Token: 0x060000F1 RID: 241 RVA: 0x0000F257 File Offset: 0x0000D457
		public static int GetProjectile()
		{
			return Projectile.allProjectiles[Projectile.currentProjectile];
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x0000F268 File Offset: 0x0000D468
		public static void ProjectileSpammer(Vector3 position, Vector3 velocity, Color? customColor = null)
		{
			bool rightGrab = Variables.pollerInstance.rightGrab;
			if (rightGrab)
			{
				bool flag = Projectile.velocityEstimator == null;
				if (flag)
				{
					GameObject gameObject = new GameObject("VelocityHolder");
					Projectile.velocityEstimator = gameObject.AddComponent<GorillaVelocityEstimator>();
				}
				Projectile.velocityEstimator.enabled = false;
				foreach (SnowballThrowable snowballThrowable in Projectile.snowballMaker.snowballs)
				{
					bool flag2 = snowballThrowable.matDataIndexes.Contains(Projectile.GetProjectile());
					if (flag2)
					{
						bool flag3 = !snowballThrowable.gameObject.activeSelf;
						if (flag3)
						{
							Projectile.snowballThrowable = snowballThrowable;
							snowballThrowable.SetSnowballActiveLocal(true);
							snowballThrowable.velocityEstimator = Projectile.velocityEstimator;
							snowballThrowable.transform.position = Variables.taggerInstance.leftHandTransform.position;
							snowballThrowable.transform.rotation = Variables.taggerInstance.leftHandTransform.rotation;
						}
					}
				}
				bool flag4 = Time.time > Projectile.projectileCooldown;
				if (flag4)
				{
					try
					{
						Color color = customColor ?? (Projectile.isRandomColorMode ? ColorLib.GetRainbowColor(Projectile.rainbowHue) : Projectile.currentProjectileColor);
						Projectile.snowballThrowable.randomizeColor = true;
						bool flag5 = Projectile.isRandomColorMode;
						if (flag5)
						{
							Projectile.rainbowHue += 0.02f;
						}
						Variables.taggerInstance.offlineVRRig.SetThrowableProjectileColor(true, color);
						Rigidbody component = Variables.taggerInstance.GetComponent<Rigidbody>();
						Vector3 velocity2 = component.velocity;
						component.velocity = velocity;
						Projectile.snowballThrowable.transform.position = position;
						MethodInfo method = typeof(SnowballThrowable).GetMethod("PerformSnowballThrowAuthority", 36);
						method.Invoke(Projectile.snowballThrowable, new object[0]);
						component.velocity = velocity2;
						Projectile.projectileCooldown = Time.time + 0.15f;
						Projectile.snowballThrowable.randomizeColor = false;
					}
					catch (Exception ex)
					{
						Debug.LogError("<color=red>Error Spawning Projectile</color>: " + ex.Message);
					}
				}
			}
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x0000F4A4 File Offset: 0x0000D6A4
		public static void LaunchProjectile(Vector3 position, Vector3 velocity, Color32? customColor = null)
		{
			bool flag = Projectile.velocityEstimator == null;
			if (flag)
			{
				GameObject gameObject = new GameObject("VelocityHolder");
				Projectile.velocityEstimator = gameObject.AddComponent<GorillaVelocityEstimator>();
			}
			Projectile.velocityEstimator.enabled = false;
			foreach (SnowballThrowable snowballThrowable in Projectile.snowballMaker.snowballs)
			{
				bool flag2 = snowballThrowable.matDataIndexes.Contains(Projectile.GetProjectile());
				if (flag2)
				{
					bool flag3 = !snowballThrowable.gameObject.activeSelf;
					if (flag3)
					{
						Projectile.snowballThrowable = snowballThrowable;
						snowballThrowable.SetSnowballActiveLocal(true);
						snowballThrowable.velocityEstimator = Projectile.velocityEstimator;
						snowballThrowable.transform.position = Variables.taggerInstance.leftHandTransform.position;
						snowballThrowable.transform.rotation = Variables.taggerInstance.leftHandTransform.rotation;
					}
				}
			}
			bool flag4 = Time.time > Projectile.projectileCooldown;
			if (flag4)
			{
				try
				{
					object[] array = new object[]
					{
						position,
						velocity,
						1,
						0,
						true,
						(customColor != null) ? new byte?(customColor.GetValueOrDefault().r) : default(byte?),
						(customColor != null) ? new byte?(customColor.GetValueOrDefault().g) : default(byte?),
						(customColor != null) ? new byte?(customColor.GetValueOrDefault().b) : default(byte?),
						(customColor != null) ? new byte?(customColor.GetValueOrDefault().a) : default(byte?)
					};
					NetworkSystemRaiseEvent.RaiseEvent(3, new object[]
					{
						NetworkSystem.Instance.ServerTimestamp,
						0,
						array
					}, Projectile.all, false);
					Projectile.projectileCooldown = Time.time + 0.16129032f;
				}
				catch (Exception ex)
				{
					Debug.LogError("<color=red>Error Spawning Projectile</color>: " + ex.Message);
				}
			}
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x0000F728 File Offset: 0x0000D928
		public static void CycleProjectileType()
		{
			Projectile.currentProjectile = (Projectile.currentProjectile + 1) % Projectile.allProjectiles.Count;
			bool flag = Projectile.cycleProjectileButton != null;
			if (flag)
			{
				Projectile.cycleProjectileButton.buttonText = "Projectile Type : " + Projectile.projectileNames[Projectile.currentProjectile];
			}
			Debug.Log("Projectile changed to: " + Projectile.projectileNames[Projectile.currentProjectile]);
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x0000F7A0 File Offset: 0x0000D9A0
		public static void CycleProjectileColor()
		{
			Projectile.currentColorIndex = (Projectile.currentColorIndex + 1) % Projectile.colorNames.Count;
			bool flag = Projectile.colorNames[Projectile.currentColorIndex] == "Rainbow";
			if (flag)
			{
				Projectile.isRandomColorMode = true;
			}
			else
			{
				Projectile.isRandomColorMode = false;
				Projectile.currentProjectileColor = Projectile.projectileColors[Projectile.currentColorIndex];
			}
			bool flag2 = Projectile.cycleProjectileColorButton != null;
			if (flag2)
			{
				Projectile.cycleProjectileColorButton.buttonText = "Projectile Color : " + Projectile.colorNames[Projectile.currentColorIndex];
			}
			Debug.Log(string.Format("Projectile color changed to: {0} (Rainbow Mode: {1})", Projectile.colorNames[Projectile.currentColorIndex], Projectile.isRandomColorMode));
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x0000F864 File Offset: 0x0000DA64
		public static void ProjectileGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					ControllerInputPoller.instance.rightGrab = true;
					Projectile.LaunchProjectile(GunLib.raycastHit.point, GunLib.raycastHit.transform.up * 0f, new Color32?(ColorLib.RainbowMat.color));
				}
			}
			else
			{
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x0000F8E4 File Offset: 0x0000DAE4
		public static void GiveProjectileSpamGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						ControllerInputPoller.instance.rightGrab = true;
						Projectile.ProjectileSpammer(GunLib.lockedTargetRig.rightHandTransform.position, GunLib.lockedTargetRig.rightHandTransform.forward * 0f, default(Color?));
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x0000F9AC File Offset: 0x0000DBAC
		public static void GiveShootProjectilesGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						ControllerInputPoller.instance.rightGrab = true;
						Projectile.ProjectileSpammer(GunLib.lockedTargetRig.rightHandTransform.position, GunLib.lockedTargetRig.rightHandTransform.forward * Settings.ProjectileSpeed, default(Color?));
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x0000FA74 File Offset: 0x0000DC74
		public static void GiveUrineGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						ControllerInputPoller.instance.rightGrab = true;
						Projectile.ProjectileSpammer(GunLib.lockedTargetRig.rightHandTransform.position, GunLib.lockedTargetRig.rightHandTransform.forward * 0f, default(Color?));
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000FA RID: 250 RVA: 0x0000FB3C File Offset: 0x0000DD3C
		public static void GiveSemenGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						ControllerInputPoller.instance.rightGrab = true;
						Projectile.ProjectileSpammer(GunLib.lockedTargetRig.bodyTransform.position - Vector3.up * 0.22f, GunLib.lockedTargetRig.bodyTransform.forward * 3f, new Color?(new Color32(240, 240, 200, byte.MaxValue)));
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000FB RID: 251 RVA: 0x0000FC34 File Offset: 0x0000DE34
		public static void GiveFecesGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						ControllerInputPoller.instance.rightGrab = true;
						Projectile.ProjectileSpammer(GunLib.lockedTargetRig.bodyTransform.position - Vector3.up * 0.22f, Vector3.up * -0.1f, new Color?(ColorLib.Brown));
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000FC RID: 252 RVA: 0x0000FD0C File Offset: 0x0000DF0C
		public static void GiveVomitGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						ControllerInputPoller.instance.rightGrab = true;
						Projectile.ProjectileSpammer(GunLib.lockedTargetRig.head.headTransform.position - GunLib.lockedTargetRig.head.headTransform.up * 0.2f, GunLib.lockedTargetRig.head.headTransform.forward * 6f, new Color?(ColorLib.DarkGreen));
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000FD RID: 253 RVA: 0x0000FE08 File Offset: 0x0000E008
		public static void GiveSpitGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						ControllerInputPoller.instance.rightGrab = true;
						Projectile.ProjectileSpammer(GunLib.lockedTargetRig.head.headTransform.position - GunLib.lockedTargetRig.head.headTransform.up * 0.2f, GunLib.lockedTargetRig.head.headTransform.forward * 6f, new Color?(new Color32(190, 190, 190, byte.MaxValue)));
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000FF RID: 255 RVA: 0x0000FF24 File Offset: 0x0000E124
		// Note: this type is marked as 'beforefieldinit'.
		static Projectile()
		{
			List<int> list = new List<int>();
			list.Add(32);
			list.Add(204);
			list.Add(240);
			list.Add(249);
			list.Add(252);
			list.Add(287);
			list.Add(286);
			list.Add(288);
			Projectile.allProjectiles = list;
			Projectile.currentProjectile = 0;
			Projectile.rainbowHue = 0f;
			Projectile.isRandomColorMode = false;
			Projectile.currentColorIndex = 0;
			Projectile.currentProjectileColor = Color.white;
			List<string> list2 = new List<string>();
			list2.Add("Snowballs");
			list2.Add("Water Balloons");
			list2.Add("Presents");
			list2.Add("Mentos");
			list2.Add("Fish Food");
			list2.Add("Voting Rock");
			list2.Add("Candy");
			list2.Add("Apples");
			Projectile.projectileNames = list2;
			List<Color> list3 = new List<Color>();
			list3.Add(ColorLib.White);
			list3.Add(ColorLib.Red);
			list3.Add(ColorLib.Orange);
			list3.Add(ColorLib.Yellow);
			list3.Add(ColorLib.Green);
			list3.Add(ColorLib.Cyan);
			list3.Add(ColorLib.Blue);
			list3.Add(ColorLib.Magenta);
			list3.Add(ColorLib.Purple);
			list3.Add(ColorLib.Pink);
			list3.Add(ColorLib.Grey);
			list3.Add(ColorLib.Black);
			Projectile.projectileColors = list3;
			List<string> list4 = new List<string>();
			list4.Add("White");
			list4.Add("Red");
			list4.Add("Orange");
			list4.Add("Yellow");
			list4.Add("Green");
			list4.Add("Cyan");
			list4.Add("Blue");
			list4.Add("Magenta");
			list4.Add("Purple");
			list4.Add("Pink");
			list4.Add("Gray");
			list4.Add("Black");
			list4.Add("Rainbow");
			Projectile.colorNames = list4;
			Projectile.all = new NetEventOptions
			{
				Reciever = 1
			};
		}

		// Token: 0x04000197 RID: 407
		public static GorillaVelocityEstimator velocityEstimator = null;

		// Token: 0x04000198 RID: 408
		public static SnowballMaker snowballMaker = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/LeftHand Controller/SnowballMakerLeftHand").GetComponent<SnowballMaker>();

		// Token: 0x04000199 RID: 409
		public static SnowballThrowable snowballThrowable = null;

		// Token: 0x0400019A RID: 410
		public static float projectileCooldown = 0f;

		// Token: 0x0400019B RID: 411
		public static List<int> allProjectiles;

		// Token: 0x0400019C RID: 412
		public static int currentProjectile;

		// Token: 0x0400019D RID: 413
		public static ButtonHandler.Button cycleProjectileButton;

		// Token: 0x0400019E RID: 414
		public static float rainbowHue;

		// Token: 0x0400019F RID: 415
		public static bool isRandomColorMode;

		// Token: 0x040001A0 RID: 416
		public static int currentColorIndex;

		// Token: 0x040001A1 RID: 417
		public static Color currentProjectileColor;

		// Token: 0x040001A2 RID: 418
		public static ButtonHandler.Button cycleProjectileColorButton;

		// Token: 0x040001A3 RID: 419
		public static List<string> projectileNames;

		// Token: 0x040001A4 RID: 420
		public static List<Color> projectileColors;

		// Token: 0x040001A5 RID: 421
		public static List<string> colorNames;

		// Token: 0x040001A6 RID: 422
		public static readonly NetEventOptions all;
	}
}
