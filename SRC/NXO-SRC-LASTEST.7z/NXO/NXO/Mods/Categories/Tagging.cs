﻿using System;
using ExitGames.Client.Photon;
using NXO.Utilities;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.InputSystem;

namespace NXO.Mods.Categories
{
	// Token: 0x02000028 RID: 40
	public class Tagging
	{
		// Token: 0x0600014E RID: 334 RVA: 0x000138F8 File Offset: 0x00011AF8
		public static void TagAll()
		{
			bool flag = Variables.IAmInfected && Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
			if (flag)
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					bool flag2 = !Variables.RigIsInfected(vrrig);
					if (flag2)
					{
						Variables.taggerInstance.offlineVRRig.enabled = false;
						Variables.taggerInstance.offlineVRRig.transform.position = vrrig.transform.position;
						Variables.playerInstance.leftControllerTransform.position = vrrig.transform.position;
						Variables.taggerInstance.offlineVRRig.enabled = true;
						break;
					}
				}
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x0600014F RID: 335 RVA: 0x000139F4 File Offset: 0x00011BF4
		public static void TagGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						bool iamInfected = Variables.IAmInfected;
						if (iamInfected)
						{
							bool flag2 = !Variables.RigIsInfected(GunLib.lockedTargetRig);
							if (flag2)
							{
								Variables.taggerInstance.offlineVRRig.enabled = false;
								Variables.taggerInstance.offlineVRRig.transform.position = GunLib.lockedTargetRig.transform.position;
								Variables.playerInstance.leftControllerTransform.position = GunLib.lockedTargetRig.transform.position;
							}
							else
							{
								Variables.taggerInstance.offlineVRRig.enabled = true;
							}
						}
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x06000150 RID: 336 RVA: 0x00013B08 File Offset: 0x00011D08
		public static void TagAura()
		{
			bool flag = Variables.IAmInfected && Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
			if (flag)
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					bool flag2 = Variables.IsOtherPlayer(Variables.vrrig) && !Variables.RigIsInfected(Variables.vrrig);
					if (flag2)
					{
						bool flag3 = Vector3.Distance(Variables.taggerInstance.offlineVRRig.transform.position, Variables.vrrig.transform.position) < 5f;
						if (flag3)
						{
							Variables.playerInstance.rightControllerTransform.position = Variables.vrrig.transform.position;
						}
					}
				}
			}
		}

		// Token: 0x06000151 RID: 337 RVA: 0x00013C04 File Offset: 0x00011E04
		public static void TagSelf()
		{
			bool flag = !Variables.IAmInfected && Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
			if (flag)
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					bool flag2 = Variables.RigIsInfected(vrrig);
					if (flag2)
					{
						Variables.taggerInstance.offlineVRRig.enabled = false;
						Variables.taggerInstance.offlineVRRig.transform.position = vrrig.rightHandTransform.position;
						Variables.taggerInstance.myVRRig.transform.position = vrrig.transform.position;
						Vector3 position = vrrig.transform.position;
						Vector3 position2 = Variables.taggerInstance.offlineVRRig.head.rigTarget.position;
						float num = Vector3.Distance(position, position2);
						bool flag3 = !Variables.RigIsInfected(vrrig) && num < 1.667f;
						if (flag3)
						{
							Variables.playerInstance.leftControllerTransform.position = position;
						}
					}
				}
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x06000152 RID: 338 RVA: 0x00013D5C File Offset: 0x00011F5C
		public static void FlickTag()
		{
			Ray ray = (Mouse.current.rightButton.isPressed || Mouse.current.leftButton.isPressed) ? Variables.thirdPersonCamera.GetComponent<Camera>().ScreenPointToRay(Mouse.current.position.ReadValue()) : new Ray(Variables.playerInstance.rightControllerTransform.position, Variables.playerInstance.rightControllerTransform.forward);
			Physics.Raycast(ray, ref GunLib.raycastHit, 100f);
			bool flag = GunLib.lockedTargetRig != null;
			if (flag)
			{
				GunLib.SetupGunObjectPositions(GunLib.lockedTargetRig.transform.position);
			}
			else
			{
				GunLib.SetupGunObjectPositions(GunLib.raycastHit.point);
			}
			bool gunTriggers = GunLib.GunTriggers;
			if (gunTriggers)
			{
				Variables.taggerInstance.rightHandTransform.position = GunLib.gunPointer.transform.position;
			}
		}

		// Token: 0x06000153 RID: 339 RVA: 0x00013E4C File Offset: 0x0001204C
		public static void AntiTag()
		{
			bool flag = !Variables.IAmInfected;
			if (flag)
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					bool flag2 = Variables.IsOtherPlayer(vrrig) && Variables.RigIsInfected(vrrig);
					if (flag2)
					{
						bool flag3 = Vector3.Distance(Variables.taggerInstance.offlineVRRig.transform.position, vrrig.transform.position) < 3f;
						if (flag3)
						{
							Variables.taggerInstance.offlineVRRig.enabled = false;
							Variables.taggerInstance.offlineVRRig.transform.position = new Vector3(999f, 999f, 999f);
						}
						else
						{
							Variables.taggerInstance.offlineVRRig.enabled = true;
						}
					}
				}
			}
		}

		// Token: 0x06000154 RID: 340 RVA: 0x00013F58 File Offset: 0x00012158
		public static void UntagSelf()
		{
			bool flag = PhotonNetwork.InRoom && Variables.IAmInfected;
			if (flag)
			{
				Room.Reconnect();
				Tagging.NoTagOnJoin(true);
			}
			else
			{
				NotificationLib.SendNotification("<color=red>Photon Error</color> : Not In A Room.");
			}
		}

		// Token: 0x06000155 RID: 341 RVA: 0x00013F98 File Offset: 0x00012198
		public static void NoTagOnJoin(bool setActive)
		{
			string text = setActive ? "nope" : "done";
			bool flag = !setActive;
			PlayerPrefs.SetString("tutorial", text);
			PlayerPrefs.SetString("didTutorial", text);
			Player localPlayer = PhotonNetwork.LocalPlayer;
			if (localPlayer != null)
			{
				Hashtable hashtable = new Hashtable();
				hashtable.Add("didTutorial", flag);
				localPlayer.SetCustomProperties(hashtable, null, null);
			}
		}
	}
}
