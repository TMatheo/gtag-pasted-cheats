﻿using System;
using System.Runtime.CompilerServices;
using NXO.Utilities;
using Photon.Pun;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000025 RID: 37
	public class Sound
	{
		// Token: 0x06000129 RID: 297 RVA: 0x00011544 File Offset: 0x0000F744
		[NullableContext(1)]
		public static string GetSoundName(int index)
		{
			string result;
			switch (index)
			{
			case 0:
				result = "Default";
				break;
			case 1:
				result = "Rock Wall";
				break;
			case 2:
				result = "Canyon";
				break;
			case 3:
				result = "Pillow White";
				break;
			case 4:
				result = "Pillow Blue";
				break;
			case 5:
				result = "Pillow Yellow";
				break;
			case 6:
				result = "Pillow Pink";
				break;
			case 7:
				result = "Pit Ground";
				break;
			case 8:
				result = "Bark";
				break;
			case 9:
				result = "Log Low Resolution";
				break;
			case 10:
				result = "Table";
				break;
			case 11:
				result = "Dark Brown Panel";
				break;
			case 12:
				result = "Log Support";
				break;
			case 13:
				result = "Wooden Support";
				break;
			case 14:
				result = "Mine Wall";
				break;
			case 15:
				result = "Picnic Table";
				break;
			case 16:
				result = "Crate";
				break;
			case 17:
				result = "Cart Texture";
				break;
			case 18:
				result = "Metal Bare";
				break;
			case 19:
				result = "Metal Pattern";
				break;
			case 20:
				result = "Crystal Light Pink";
				break;
			case 21:
				result = "Crystal Light Purple";
				break;
			case 22:
				result = "Crystal Light Teal";
				break;
			case 23:
				result = "Crystal Light Yellow";
				break;
			case 24:
				result = "Bronze";
				break;
			case 25:
				result = "Red Panel";
				break;
			case 26:
				result = "Rusty";
				break;
			case 27:
				result = "Cactus";
				break;
			case 28:
				result = "Light";
				break;
			case 29:
				result = "Window";
				break;
			case 30:
				result = "Mirror Center";
				break;
			case 31:
				result = "Pit Ground Fall";
				break;
			case 32:
				result = "Pit Ground Winter";
				break;
			case 33:
				result = "Holiday White";
				break;
			case 34:
				result = "Holiday White Off";
				break;
			case 35:
				result = "Holiday Red";
				break;
			case 36:
				result = "Holiday Green";
				break;
			case 37:
				result = "Holiday Yellow";
				break;
			case 38:
				result = "Holiday Blue";
				break;
			case 39:
				result = "Christmas Tree";
				break;
			case 40:
				result = "Crystal Red Root 2 Down";
				break;
			case 41:
				result = "Crystal Orange Second 2 Down";
				break;
			case 42:
				result = "Crystal Yellow Third 2 Down";
				break;
			case 43:
				result = "Crystal Teal Fifth 2 Down";
				break;
			case 44:
				result = "Crystal Dark Blue Sixth 2 Down";
				break;
			case 45:
				result = "Crystal Red Root 1 Down";
				break;
			case 46:
				result = "Crystal Orange Second 1 Down";
				break;
			case 47:
				result = "Crystal Yellow Third 1 Down";
				break;
			case 48:
				result = "Crystal Teal Fifth 1 Down";
				break;
			case 49:
				result = "Crystal Dark Blue Sixth 1 Down";
				break;
			case 50:
				result = "Crystal Red Root";
				break;
			case 51:
				result = "Crystal Orange Second";
				break;
			case 52:
				result = "Crystal Yellow Third";
				break;
			case 53:
				result = "Crystal Teal Fifth";
				break;
			case 54:
				result = "Crystal Dark Blue Sixth";
				break;
			case 55:
				result = "Shiny Hat";
				break;
			case 56:
				result = "Whee";
				break;
			case 57:
				result = "Bronze Slide";
				break;
			case 58:
				result = "Metal Slide";
				break;
			case 59:
				result = "Ice Ground";
				break;
			case 60:
				result = "Purple Plastic Inside";
				break;
			case 61:
				result = "Mountain Ice";
				break;
			case 62:
				result = "Cosmetics Room Atlas Slippery";
				break;
			case 63:
				result = "Rock Wall 3";
				break;
			case 64:
				result = "Umbrella Open";
				break;
			case 65:
				result = "Umbrella Close";
				break;
			case 66:
				result = "Keyboard Key";
				break;
			case 67:
				result = "Button Press";
				break;
			case 68:
				result = "Giant Drum";
				break;
			case 69:
				result = "Large Drum";
				break;
			case 70:
				result = "Medium Drum";
				break;
			case 71:
				result = "Small Drum";
				break;
			case 72:
				result = "Cymbal";
				break;
			case 73:
				result = "Big Bongo";
				break;
			case 74:
				result = "Small Bongo";
				break;
			case 75:
				result = "Squeak Squeeze";
				break;
			case 76:
				result = "Squeak Release";
				break;
			case 77:
				result = "Rattling Bone";
				break;
			case 78:
				result = "Tombstone Hit";
				break;
			case 79:
				result = "Inner Cauldron";
				break;
			case 80:
				result = "Outer Cauldron";
				break;
			case 81:
				result = "Pumpkin Hit";
				break;
			case 82:
				result = "Web Touch";
				break;
			case 83:
				result = "Turkey Squeeze";
				break;
			case 84:
				result = "Food Pop";
				break;
			case 85:
				result = "Bite 1";
				break;
			case 86:
				result = "Bite 2";
				break;
			case 87:
				result = "Bite 3";
				break;
			case 88:
				result = "Hay Bale";
				break;
			case 89:
				result = "Rope Creak";
				break;
			case 90:
				result = "Plant Crunch";
				break;
			case 91:
				result = "Frog Squeeze";
				break;
			case 92:
				result = "Vine";
				break;
			case 93:
				result = "Cloud Floor";
				break;
			case 94:
				result = "Platform";
				break;
			case 95:
				result = "Car Tire";
				break;
			case 96:
				result = "Storefront Fruit";
				break;
			case 97:
				result = "Branches";
				break;
			case 98:
				result = "Clothes Dryer";
				break;
			case 99:
				result = "Leaf";
				break;
			case 100:
				result = "Gear Platform";
				break;
			case 101:
				result = "Pivot Platform";
				break;
			case 102:
				result = "Wall Jump";
				break;
			case 103:
				result = "Gear Platform";
				break;
			case 104:
				result = "Wall Jump";
				break;
			case 105:
				result = "Hut";
				break;
			case 106:
				result = "Firefly Jar";
				break;
			case 107:
				result = "Bean Bag Chair";
				break;
			case 108:
				result = "Round Pillow";
				break;
			case 109:
				result = "Square Pillow";
				break;
			case 110:
				result = "Small Storefront";
				break;
			case 111:
				result = "Large Storefront";
				break;
			case 112:
				result = "Small Storefront";
				break;
			case 113:
				result = "Large Storefront";
				break;
			case 114:
				result = "Wooden Shelf";
				break;
			case 115:
				result = "Hut";
				break;
			case 116:
				result = "Crane";
				break;
			case 117:
				result = "Crane";
				break;
			case 118:
				result = "Square Rug";
				break;
			case 119:
				result = "Round Rug";
				break;
			case 120:
				result = "Window";
				break;
			case 121:
				result = "Giant Ornament Long";
				break;
			case 122:
				result = "Christmas Tree";
				break;
			case 123:
				result = "Giant Ornament Round";
				break;
			case 124:
				result = "Giant Ornament Star";
				break;
			case 125:
				result = "Giant Ornament Snowflake";
				break;
			case 126:
				result = "Stocking Empty";
				break;
			case 127:
				result = "Stocking Full";
				break;
			case 128:
				result = "Shiny Atlas";
				break;
			case 129:
				result = "Neon Blue";
				break;
			case 130:
				result = "Neon Red";
				break;
			case 131:
				result = "Neon Green";
				break;
			case 132:
				result = "Neon Purple";
				break;
			case 133:
				result = "Neon Yellow";
				break;
			case 134:
				result = "Rectangle Gift Box";
				break;
			case 135:
				result = "Rectangle Gift Box Full";
				break;
			case 136:
				result = "Square Gift Box";
				break;
			case 137:
				result = "Square Gift Box Full";
				break;
			case 138:
				result = "Neon Yellow";
				break;
			case 139:
				result = "Hat Atlas";
				break;
			case 140:
				result = "Toy Gorilla Squeeze";
				break;
			case 141:
				result = "Toy Gorilla Release";
				break;
			case 142:
				result = "Gear Platform";
				break;
			case 143:
				result = "Material";
				break;
			case 144:
				result = "Stool";
				break;
			case 145:
				result = "Table";
				break;
			case 146:
				result = "TV";
				break;
			case 147:
				result = "Snowman";
				break;
			case 148:
				result = "Giant Candy Cane";
				break;
			case 149:
				result = "Toy Train";
				break;
			case 150:
				result = "Giant Snowman";
				break;
			case 151:
				result = "Hut Container";
				break;
			case 152:
				result = "Tree Topper";
				break;
			case 153:
				result = "Shiny Hat Atlas";
				break;
			case 154:
				result = "Penguin Squeeze";
				break;
			case 155:
				result = "Penguin Release";
				break;
			case 156:
				result = "Wolf Squeeze";
				break;
			case 157:
				result = "Wolf Release";
				break;
			case 158:
				result = "Basement Couch";
				break;
			case 159:
				result = "Shag Carpet";
				break;
			case 160:
				result = "Small Basement Box";
				break;
			case 161:
				result = "Medium Basement Box";
				break;
			case 162:
				result = "Large Basement Box";
				break;
			case 163:
				result = "Basement Couch Pillow";
				break;
			case 164:
				result = "Basement Rug";
				break;
			case 165:
				result = "Large Basement Rug";
				break;
			case 166:
				result = "Basement Shelf";
				break;
			case 167:
				result = "Small Basement Shelf";
				break;
			case 168:
				result = "Basement Stool";
				break;
			case 169:
				result = "Basement Table";
				break;
			case 170:
				result = "Basement Heater";
				break;
			case 171:
				result = "Basement Lava Lamp";
				break;
			case 172:
				result = "Lumber";
				break;
			case 173:
				result = "Wall Panel";
				break;
			case 174:
				result = "Basement Comic Box";
				break;
			case 175:
				result = "Basement Comic Books";
				break;
			case 176:
				result = "Basement Lamp";
				break;
			case 177:
				result = "Basement Lamp";
				break;
			case 178:
				result = "Basement Book";
				break;
			case 179:
				result = "Basement Book";
				break;
			case 180:
				result = "Basement Book";
				break;
			case 181:
				result = "Basement Book";
				break;
			case 182:
				result = "Basement Book Stack";
				break;
			case 183:
				result = "Basement Book Stack";
				break;
			case 184:
				result = "Basement Light";
				break;
			case 185:
				result = "Basement Light";
				break;
			case 186:
				result = "Basement Pipes";
				break;
			case 187:
				result = "Monkey Squeeze";
				break;
			case 188:
				result = "Dragon Squeeze";
				break;
			case 189:
				result = "Basement Concrete";
				break;
			case 190:
				result = "Basement Concrete Floor";
				break;
			case 191:
				result = "Bee Toy Squeeze";
				break;
			case 192:
				result = "Bee Toy Release";
				break;
			case 193:
				result = "Sponge Squeeze";
				break;
			case 194:
				result = "Sponge Release";
				break;
			case 195:
				result = "Coyote Toy Squeeze";
				break;
			case 196:
				result = "Diving Board Bounce";
				break;
			case 197:
				result = "Beach Sand";
				break;
			case 198:
				result = "Palm Tree Bark";
				break;
			case 199:
				result = "Palm Tree Leaf";
				break;
			case 200:
				result = "Shark Squeeze";
				break;
			case 201:
				result = "Shark Release";
				break;
			case 202:
				result = "Beach Tent";
				break;
			case 203:
				result = "Firework Mortars Bucket Pile";
				break;
			case 204:
				result = "Water Balloon Bucket Pile";
				break;
			case 205:
				result = "Summer Slip Slide";
				break;
			case 206:
				result = "Dolphin Squeeze";
				break;
			case 207:
				result = "Dolphin Release";
				break;
			case 208:
				result = "Bug Spray Squeeze";
				break;
			case 209:
				result = "Bug Spray Release";
				break;
			case 210:
				result = "Trampoline Bounce";
				break;
			case 211:
				result = "Button Split Down";
				break;
			case 212:
				result = "Button Split Up";
				break;
			case 213:
				result = "Huge Crystal";
				break;
			case 214:
				result = "Purple Crystal Seventh";
				break;
			case 215:
				result = "Purple Crystal Seventh 1 Up";
				break;
			case 216:
				result = "Purple Crystal Seventh 1 Down";
				break;
			case 217:
				result = "Purple Crystal Seventh 2 Down";
				break;
			case 218:
				result = "Green Crystal Fourth";
				break;
			case 219:
				result = "Green Crystal Fourth 1 Down";
				break;
			case 220:
				result = "Green Crystal Fourth 1 Up";
				break;
			case 221:
				result = "Green Crystal Fourth 2 Down";
				break;
			case 222:
				result = "Eel Squeeze";
				break;
			case 223:
				result = "Eel Release";
				break;
			case 224:
				result = "Red Crystal Root 1 Up";
				break;
			case 225:
				result = "Orange Crystal Second 1 Up";
				break;
			case 226:
				result = "Yellow Crystal Third 1 Up";
				break;
			case 227:
				result = "Teal Crystal Fifth 1 Up";
				break;
			case 228:
				result = "Dark Blue Crystal Sixth 1 Up";
				break;
			default:
				result = "Unknown Sound";
				break;
			}
			return result;
		}

		// Token: 0x0600012A RID: 298 RVA: 0x000122A8 File Offset: 0x000104A8
		public static void SpecificSoundSpam(int SoundIndex)
		{
			bool flag = Time.time < Variables.rpcCooldown;
			if (!flag)
			{
				Variables.rpcCooldown = Time.time + Sound.soundCooldown;
				Safety.RPCShield();
				bool flag2 = (double)Variables.pollerInstance.rightControllerIndexFloat > 0.1;
				if (flag2)
				{
					bool inRoom = PhotonNetwork.InRoom;
					if (inRoom)
					{
						Variables.taggerInstance.myVRRig.GetView.RPC("RPC_PlayHandTap", 0, new object[]
						{
							SoundIndex,
							Variables.rightHandedMenu,
							99999
						});
					}
					else
					{
						Variables.taggerInstance.offlineVRRig.PlayHandTapLocal(SoundIndex, Variables.rightHandedMenu, 1f);
					}
				}
			}
		}

		// Token: 0x0600012B RID: 299 RVA: 0x0001236C File Offset: 0x0001056C
		public static void OnTouchPlayer(int SoundIndex)
		{
			bool flag = Time.time < Variables.rpcCooldown;
			if (!flag)
			{
				Variables.rpcCooldown = Time.time + Sound.soundCooldown;
				Safety.RPCShield();
				bool flag2 = false;
				bool flag3 = false;
				float num = 0.325f;
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					bool flag4 = !Variables.IsOtherPlayer(vrrig);
					if (!flag4)
					{
						bool flag5 = !flag2;
						if (flag5)
						{
							flag2 = (Vector3.Distance(GorillaTagger.Instance.leftHandTransform.position, vrrig.headMesh.transform.position) < num);
						}
						bool flag6 = !flag3;
						if (flag6)
						{
							flag3 = (Vector3.Distance(GorillaTagger.Instance.rightHandTransform.position, vrrig.headMesh.transform.position) < num);
						}
						bool flag7 = flag2 && flag3;
						if (flag7)
						{
							break;
						}
					}
				}
				bool flag8 = flag2 && !Sound.lastLeftTouch;
				if (flag8)
				{
					Variables.taggerInstance.myVRRig.GetView.RPC("RPC_PlayHandTap", 0, new object[]
					{
						SoundIndex,
						true,
						99999
					});
				}
				bool flag9 = flag3 && !Sound.lastRightTouch;
				if (flag9)
				{
					Variables.taggerInstance.myVRRig.GetView.RPC("RPC_PlayHandTap", 0, new object[]
					{
						SoundIndex,
						false,
						1
					});
				}
				Sound.lastLeftTouch = flag2;
				Sound.lastRightTouch = flag3;
			}
		}

		// Token: 0x0600012C RID: 300 RVA: 0x0001253C File Offset: 0x0001073C
		public static void CustomSoundSpam()
		{
			bool flag = Time.time < Variables.rpcCooldown;
			if (!flag)
			{
				Variables.rpcCooldown = Time.time + Sound.soundCooldown;
				Safety.RPCShield();
				bool flag2 = Variables.pollerInstance.rightControllerIndexFloat > 0f;
				if (flag2)
				{
					bool inRoom = PhotonNetwork.InRoom;
					if (inRoom)
					{
						Variables.taggerInstance.myVRRig.GetView.RPC("RPC_PlayHandTap", 0, new object[]
						{
							Sound.sound,
							Variables.rightHandedMenu,
							99999f
						});
					}
					else
					{
						Variables.taggerInstance.offlineVRRig.PlayHandTapLocal(Sound.sound, Variables.rightHandedMenu, 99999f);
					}
				}
				bool flag3 = Variables.pollerInstance.rightControllerPrimaryButton && !Sound.haschangedint;
				if (flag3)
				{
					Sound.sound++;
					string soundName = Sound.GetSoundName(Sound.sound);
					NotificationLib.ClearAllNotifications();
					NotificationLib.SendNotification(string.Concat(new string[]
					{
						"<color=blue>Sound</color> : Set Index To: ",
						soundName,
						" [",
						Sound.sound.ToString(),
						"]"
					}));
					Sound.haschangedint = true;
				}
				bool flag4 = !Variables.pollerInstance.rightControllerPrimaryButton;
				if (flag4)
				{
					Sound.haschangedint = false;
				}
				bool flag5 = Variables.pollerInstance.rightControllerSecondaryButton && !Sound.haschangedint2;
				if (flag5)
				{
					Sound.sound--;
					string soundName2 = Sound.GetSoundName(Sound.sound);
					NotificationLib.ClearAllNotifications();
					NotificationLib.SendNotification(string.Concat(new string[]
					{
						"<color=blue>Sound</color> : Set Index To: ",
						soundName2,
						" [",
						Sound.sound.ToString(),
						"]"
					}));
					Sound.haschangedint2 = true;
				}
				bool flag6 = !Variables.pollerInstance.rightControllerSecondaryButton;
				if (flag6)
				{
					Sound.haschangedint2 = false;
				}
			}
		}

		// Token: 0x040001D2 RID: 466
		public static bool haschangedint = false;

		// Token: 0x040001D3 RID: 467
		public static bool haschangedint2 = false;

		// Token: 0x040001D4 RID: 468
		public static int sound = 0;

		// Token: 0x040001D5 RID: 469
		private static bool lastLeftTouch = false;

		// Token: 0x040001D6 RID: 470
		private static bool lastRightTouch = false;

		// Token: 0x040001D7 RID: 471
		private static float soundCooldown = 0.175f;
	}
}
