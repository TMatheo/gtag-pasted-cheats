﻿using System;
using System.Runtime.CompilerServices;
using ExitGames.Client.Photon;
using GorillaLocomotion.Gameplay;
using NXO.Utilities;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000027 RID: 39
	[NullableContext(1)]
	[Nullable(0)]
	public class Special
	{
		// Token: 0x0600013F RID: 319 RVA: 0x00012C2C File Offset: 0x00010E2C
		public static VRRig GetRandomRig()
		{
			VRRig[] array = GorillaParent.instance.vrrigs.ToArray();
			bool flag = array.Length == 0;
			VRRig result;
			if (flag)
			{
				Debug.Log("No VRRigs found.");
				result = null;
			}
			else
			{
				int num = Random.Range(0, array.Length);
				VRRig vrrig = null;
				for (int i = 0; i < array.Length; i++)
				{
					bool flag2 = i == num;
					if (flag2)
					{
						vrrig = array[i];
						break;
					}
				}
				result = vrrig;
			}
			return result;
		}

		// Token: 0x06000140 RID: 320 RVA: 0x00012CA8 File Offset: 0x00010EA8
		public static void SendEvent(byte code, object evData, RaiseEventOptions reo, SendOptions so, bool sendToSpecific = false, Player specificPlayer = null)
		{
			float time = Time.time;
			bool flag = time - Special.lastSendTime < Special.fixedCooldown;
			if (!flag)
			{
				object[] array = new object[]
				{
					PhotonNetwork.ServerTimestamp,
					code,
					evData
				};
				bool flag2 = sendToSpecific && specificPlayer != null;
				if (flag2)
				{
					reo.TargetActors = new int[]
					{
						specificPlayer.ActorNumber
					};
				}
				PhotonNetwork.RaiseEvent(3, array, reo, so);
				Special.lastSendTime = time;
			}
		}

		// Token: 0x06000141 RID: 321 RVA: 0x00012D2C File Offset: 0x00010F2C
		public static void SpazImpact()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						object[] array = new object[]
						{
							GunLib.lockedTargetRig.transform.position + new Vector3(0f, 0.1f, 0f) + GunLib.lockedTargetRig.transform.forward * 0.2f,
							Random.Range(0f, 1f),
							Random.Range(0f, 1f),
							Random.Range(0f, 1f),
							1f,
							0
						};
						byte code = 1;
						object evData = array;
						Special.SendEvent(code, evData, Special.reoAll, Special.soUnreliable, false, null);
					}
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x06000142 RID: 322 RVA: 0x00012E94 File Offset: 0x00011094
		public static GrowingSnowballThrowable throwballsnowable()
		{
			GrowingSnowballThrowable[] array = Object.FindObjectsOfType<GrowingSnowballThrowable>();
			foreach (GrowingSnowballThrowable growingSnowballThrowable in array)
			{
				bool activeSelf = growingSnowballThrowable.gameObject.activeSelf;
				if (activeSelf)
				{
					GameObject gameObject = growingSnowballThrowable.gameObject;
					string text = "/" + gameObject.name;
					while (gameObject.transform.parent != null)
					{
						gameObject = gameObject.transform.parent.gameObject;
						text = "/" + gameObject.name + text;
					}
					bool flag = text.Contains("Gorilla Player Networked(Clone)");
					if (flag)
					{
						return growingSnowballThrowable;
					}
				}
				else
				{
					Debug.Log("None");
					GameObject gameObject2 = growingSnowballThrowable.gameObject;
					string text2 = "/" + gameObject2.name;
					while (gameObject2.transform.parent != null)
					{
						gameObject2 = gameObject2.transform.parent.gameObject;
						text2 = "/" + gameObject2.name + text2;
					}
					bool flag2 = text2.Contains("Player Objects");
					if (flag2)
					{
						growingSnowballThrowable.SetSnowballActiveLocal(true);
						return growingSnowballThrowable;
					}
				}
			}
			return null;
		}

		// Token: 0x06000143 RID: 323 RVA: 0x00012FF0 File Offset: 0x000111F0
		private static bool IsInPath(GameObject obj, string target)
		{
			string text = "/" + obj.name;
			while (obj.transform.parent != null)
			{
				obj = obj.transform.parent.gameObject;
				text = "/" + obj.name + text;
			}
			return text.Contains(target);
		}

		// Token: 0x06000144 RID: 324 RVA: 0x00013058 File Offset: 0x00011258
		public static GorillaRopeSwing[] Ropes()
		{
			bool flag = Time.time >= Special.nextUpdateTime || Special.cachedRopes == null;
			if (flag)
			{
				Special.cachedRopes = Object.FindObjectsOfType<GorillaRopeSwing>();
				Special.nextUpdateTime = Time.time + Special.cacheExpirationTime;
			}
			return Special.cachedRopes;
		}

		// Token: 0x06000145 RID: 325 RVA: 0x000130A8 File Offset: 0x000112A8
		public static void FreezeAllRopes()
		{
			bool flag = Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
			if (flag)
			{
				bool flag2 = Time.time < Variables.rpcCooldown;
				if (!flag2)
				{
					Variables.rpcCooldown = Time.time + Special.rpcrpcCooldown;
					foreach (GorillaRopeSwing gorillaRopeSwing in Special.Ropes())
					{
						RopeSwingManager instance = RopeSwingManager.instance;
						bool flag3 = ((instance != null) ? instance.photonView : null) != null;
						if (flag3)
						{
							PhotonView photonView = RopeSwingManager.instance.photonView;
							string text = "SetVelocity";
							RpcTarget rpcTarget = 0;
							object[] array2 = new object[5];
							array2[0] = gorillaRopeSwing.ropeId;
							array2[1] = 1;
							array2[2] = Vector3.zero;
							array2[3] = true;
							photonView.RPC(text, rpcTarget, array2);
						}
					}
					Safety.RPCShield();
				}
			}
		}

		// Token: 0x06000146 RID: 326 RVA: 0x00013180 File Offset: 0x00011380
		public static void FreezeRopeGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = Time.time < Variables.rpcCooldown;
					if (!flag)
					{
						Variables.rpcCooldown = Time.time + Special.rpcrpcCooldown;
						Collider collider = GunLib.raycastHit.collider;
						GorillaRopeSwing gorillaRopeSwing = (collider != null) ? collider.GetComponentInParent<GorillaRopeSwing>() : null;
						bool flag2;
						if (gorillaRopeSwing)
						{
							RopeSwingManager instance = RopeSwingManager.instance;
							flag2 = (((instance != null) ? instance.photonView : null) != null);
						}
						else
						{
							flag2 = false;
						}
						bool flag3 = flag2;
						if (flag3)
						{
							PhotonView photonView = RopeSwingManager.instance.photonView;
							string text = "SetVelocity";
							RpcTarget rpcTarget = 0;
							object[] array = new object[5];
							array[0] = gorillaRopeSwing.ropeId;
							array[1] = 1;
							array[2] = Vector3.zero;
							array[3] = true;
							photonView.RPC(text, rpcTarget, array);
						}
						Safety.RPCShield();
					}
				}
			}
			else
			{
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x06000147 RID: 327 RVA: 0x00013270 File Offset: 0x00011470
		public static void SpazAllRopes()
		{
			bool flag = Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
			if (flag)
			{
				bool flag2 = Time.time < Variables.rpcCooldown;
				if (!flag2)
				{
					Variables.rpcCooldown = Time.time + Special.rpcrpcCooldown;
					foreach (GorillaRopeSwing gorillaRopeSwing in Special.Ropes())
					{
						RopeSwingManager instance = RopeSwingManager.instance;
						bool flag3 = ((instance != null) ? instance.photonView : null) != null;
						if (flag3)
						{
							PhotonView photonView = RopeSwingManager.instance.photonView;
							string text = "SetVelocity";
							RpcTarget rpcTarget = 0;
							object[] array2 = new object[5];
							array2[0] = gorillaRopeSwing.ropeId;
							array2[1] = 1;
							array2[2] = new Vector3(Random.Range(-25f, 25f), Random.Range(-25f, 25f), Random.Range(-25f, 25f));
							array2[3] = true;
							photonView.RPC(text, rpcTarget, array2);
						}
					}
					Safety.RPCShield();
				}
			}
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0001337C File Offset: 0x0001157C
		public static void SpazRopeGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = Time.time < Variables.rpcCooldown;
					if (!flag)
					{
						Variables.rpcCooldown = Time.time + Special.rpcrpcCooldown;
						Collider collider = GunLib.raycastHit.collider;
						GorillaRopeSwing gorillaRopeSwing = (collider != null) ? collider.GetComponentInParent<GorillaRopeSwing>() : null;
						bool flag2;
						if (gorillaRopeSwing)
						{
							RopeSwingManager instance = RopeSwingManager.instance;
							flag2 = (((instance != null) ? instance.photonView : null) != null);
						}
						else
						{
							flag2 = false;
						}
						bool flag3 = flag2;
						if (flag3)
						{
							PhotonView photonView = RopeSwingManager.instance.photonView;
							string text = "SetVelocity";
							RpcTarget rpcTarget = 0;
							object[] array = new object[5];
							array[0] = gorillaRopeSwing.ropeId;
							array[1] = 1;
							array[2] = new Vector3(Random.Range(-25f, 25f), Random.Range(-25f, 25f), Random.Range(-25f, 25f));
							array[3] = true;
							photonView.RPC(text, rpcTarget, array);
						}
						Safety.RPCShield();
					}
				}
			}
			else
			{
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0001349C File Offset: 0x0001169C
		public static void AllRopesToMe()
		{
			bool flag = Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
			if (flag)
			{
				bool flag2 = Time.time < Variables.rpcCooldown;
				if (!flag2)
				{
					Variables.rpcCooldown = Time.time + Special.rpcrpcCooldown;
					foreach (GorillaRopeSwing gorillaRopeSwing in Special.Ropes())
					{
						RopeSwingManager instance = RopeSwingManager.instance;
						bool flag3 = ((instance != null) ? instance.photonView : null) != null;
						if (flag3)
						{
							PhotonView photonView = RopeSwingManager.instance.photonView;
							string text = "SetVelocity";
							RpcTarget rpcTarget = 0;
							object[] array2 = new object[5];
							array2[0] = gorillaRopeSwing.ropeId;
							array2[1] = 1;
							array2[2] = (Variables.taggerInstance.transform.position - gorillaRopeSwing.transform.position).normalized * 50f;
							array2[3] = true;
							photonView.RPC(text, rpcTarget, array2);
						}
					}
					Safety.RPCShield();
				}
			}
		}

		// Token: 0x0600014A RID: 330 RVA: 0x000135A8 File Offset: 0x000117A8
		public static void AllRopesToGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = Time.time < Variables.rpcCooldown;
					if (!flag)
					{
						Variables.rpcCooldown = Time.time + Special.rpcrpcCooldown;
						foreach (GorillaRopeSwing gorillaRopeSwing in Special.Ropes())
						{
							RopeSwingManager instance = RopeSwingManager.instance;
							bool flag2 = ((instance != null) ? instance.photonView : null) != null;
							if (flag2)
							{
								PhotonView photonView = RopeSwingManager.instance.photonView;
								string text = "SetVelocity";
								RpcTarget rpcTarget = 0;
								object[] array2 = new object[5];
								array2[0] = gorillaRopeSwing.ropeId;
								array2[1] = 1;
								array2[2] = (GunLib.raycastHit.point - gorillaRopeSwing.transform.position).normalized * 50f;
								array2[3] = true;
								photonView.RPC(text, rpcTarget, array2);
							}
						}
						Safety.RPCShield();
					}
				}
			}
			else
			{
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x0600014B RID: 331 RVA: 0x000136C8 File Offset: 0x000118C8
		public static void AllRopesToPlayerGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						bool flag2 = Time.time < Variables.rpcCooldown;
						if (!flag2)
						{
							Variables.rpcCooldown = Time.time + Special.rpcrpcCooldown;
							foreach (GorillaRopeSwing gorillaRopeSwing in Special.Ropes())
							{
								RopeSwingManager instance = RopeSwingManager.instance;
								bool flag3 = ((instance != null) ? instance.photonView : null) != null;
								if (flag3)
								{
									PhotonView photonView = RopeSwingManager.instance.photonView;
									string text = "SetVelocity";
									RpcTarget rpcTarget = 0;
									object[] array2 = new object[5];
									array2[0] = gorillaRopeSwing.ropeId;
									array2[1] = 1;
									array2[2] = (GunLib.lockedTargetRig.transform.position - gorillaRopeSwing.transform.position).normalized * 50f;
									array2[3] = true;
									photonView.RPC(text, rpcTarget, array2);
								}
							}
							Safety.RPCShield();
						}
					}
				}
				else
				{
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x040001E4 RID: 484
		private static float cacheExpirationTime = 5f;

		// Token: 0x040001E5 RID: 485
		private static float nextUpdateTime = 0f;

		// Token: 0x040001E6 RID: 486
		private static GorillaRopeSwing[] cachedRopes = null;

		// Token: 0x040001E7 RID: 487
		public static float lastRpcTime = 0f;

		// Token: 0x040001E8 RID: 488
		private static int rpcCount = 0;

		// Token: 0x040001E9 RID: 489
		public static bool islagging = false;

		// Token: 0x040001EA RID: 490
		public static float rpcrpcCooldown = 0.002f;

		// Token: 0x040001EB RID: 491
		private static int rpcCountThisSecond = 0;

		// Token: 0x040001EC RID: 492
		private static float lastSendTime = -1f;

		// Token: 0x040001ED RID: 493
		private static readonly float fixedRate = 6.2f;

		// Token: 0x040001EE RID: 494
		private static readonly float fixedCooldown = 0.16129032f;

		// Token: 0x040001EF RID: 495
		private static readonly SendOptions soUnreliable = SendOptions.SendUnreliable;

		// Token: 0x040001F0 RID: 496
		private static readonly RaiseEventOptions reoAll = new RaiseEventOptions
		{
			Receivers = 1
		};

		// Token: 0x040001F1 RID: 497
		private static SnowballMaker snowballMaker = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/LeftHand Controller/SnowballMakerLeftHand").GetComponent<SnowballMaker>();

		// Token: 0x040001F2 RID: 498
		public static float cooldown = 0f;

		// Token: 0x040001F3 RID: 499
		public static float setcooldown = 0.16129032f;

		// Token: 0x02000069 RID: 105
		[NullableContext(0)]
		public enum StatusEffects
		{
			// Token: 0x040002B2 RID: 690
			TaggedTime,
			// Token: 0x040002B3 RID: 691
			JoinedTaggedTime,
			// Token: 0x040002B4 RID: 692
			SetSlowedTime,
			// Token: 0x040002B5 RID: 693
			UnTagged,
			// Token: 0x040002B6 RID: 694
			FrozenTime
		}
	}
}
