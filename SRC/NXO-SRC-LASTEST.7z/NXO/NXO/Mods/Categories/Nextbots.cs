﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using NXO.Utilities;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x0200001F RID: 31
	[NullableContext(1)]
	[Nullable(0)]
	public class Nextbots
	{
		// Token: 0x060000D4 RID: 212 RVA: 0x0000CCBC File Offset: 0x0000AEBC
		public static void EggmanNextbot(bool setActive)
		{
			if (setActive)
			{
				bool flag = !Nextbots.pressgrip && ControllerInputPoller.instance.rightGrab;
				if (flag)
				{
					Nextbots.pressgrip = true;
					GameObject taper = GameObject.CreatePrimitive(4);
					taper.transform.position = Variables.playerInstance.rightControllerTransform.position;
					taper.AddComponent<BoxCollider>();
					Rigidbody rigidbody = taper.AddComponent<Rigidbody>();
					rigidbody.collisionDetectionMode = 1;
					taper.layer = 8;
					MonoBehaviourHelper.Instance.StartCoroutine(ColorLib.LoadTextureFromUrl("https://raw.githubusercontent.com/NuggetGT/NXO-Resources/main/Eggman.png", delegate(Texture2D texture)
					{
						bool flag7 = texture != null;
						if (flag7)
						{
							Material material = new Material(ColorLib.uiShader);
							material.mainTexture = texture;
							taper.GetComponent<Renderer>().material = material;
							Nextbots.textures.Add(texture);
						}
					}));
					taper.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					MonoBehaviourHelper.Instance.StartCoroutine(Nextbots.NextbotDownloadAndPlaySoundFromUrl("https://github.com/iiDk-the-actual/ModInfo/raw/main/prowler.mp3", taper));
				}
				bool flag2 = Nextbots.pressgrip && !ControllerInputPoller.instance.rightGrab;
				if (flag2)
				{
					Nextbots.pressgrip = false;
				}
				foreach (GameObject gameObject in Nextbots.tapers)
				{
					bool flag3 = gameObject != null;
					if (flag3)
					{
						Debug.Log(gameObject.name);
						gameObject.transform.position = Vector3.Lerp(gameObject.transform.position, Variables.taggerInstance.offlineVRRig.transform.position, 1.5f * Time.deltaTime);
						gameObject.transform.LookAt(Variables.taggerInstance.offlineVRRig.transform.position);
						gameObject.transform.Rotate(90f, 180f, 180f);
					}
				}
			}
			else
			{
				foreach (GameObject gameObject2 in Nextbots.tapers)
				{
					bool flag4 = gameObject2 != null;
					if (flag4)
					{
						Object.Destroy(gameObject2);
					}
				}
				Nextbots.tapers.Clear();
				foreach (AudioSource audioSource in Nextbots.audioSources)
				{
					bool flag5 = audioSource != null;
					if (flag5)
					{
						Object.Destroy(audioSource.gameObject);
					}
				}
				Nextbots.audioSources.Clear();
				foreach (Texture2D texture2D in Nextbots.textures)
				{
					bool flag6 = texture2D != null;
					if (flag6)
					{
						Resources.UnloadAsset(texture2D);
					}
				}
				Nextbots.textures.Clear();
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x0000CFFC File Offset: 0x0000B1FC
		private static IEnumerator NextbotDownloadAndPlaySoundFromUrl(string url, GameObject obj)
		{
			Nextbots.<NextbotDownloadAndPlaySoundFromUrl>d__5 <NextbotDownloadAndPlaySoundFromUrl>d__ = new Nextbots.<NextbotDownloadAndPlaySoundFromUrl>d__5(0);
			<NextbotDownloadAndPlaySoundFromUrl>d__.url = url;
			<NextbotDownloadAndPlaySoundFromUrl>d__.obj = obj;
			return <NextbotDownloadAndPlaySoundFromUrl>d__;
		}

		// Token: 0x04000188 RID: 392
		public static bool pressgrip;

		// Token: 0x04000189 RID: 393
		public static List<GameObject> tapers = new List<GameObject>();

		// Token: 0x0400018A RID: 394
		public static List<AudioSource> audioSources = new List<AudioSource>();

		// Token: 0x0400018B RID: 395
		public static List<Texture2D> textures = new List<Texture2D>();
	}
}
