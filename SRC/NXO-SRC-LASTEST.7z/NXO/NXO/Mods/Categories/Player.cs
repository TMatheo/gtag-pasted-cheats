﻿using System;
using GorillaLocomotion;
using HarmonyLib;
using NXO.Utilities;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000020 RID: 32
	public class Player
	{
		// Token: 0x060000D8 RID: 216 RVA: 0x0000D03C File Offset: 0x0000B23C
		public static void GhostMonke()
		{
			bool rightControllerPrimaryButton = Variables.pollerInstance.rightControllerPrimaryButton;
			bool flag = !Player.wasButtonPressed && rightControllerPrimaryButton;
			if (flag)
			{
				Player.isOn = !Player.isOn;
			}
			Player.wasButtonPressed = rightControllerPrimaryButton;
			bool flag2 = Player.isOn;
			if (flag2)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x0000D0AC File Offset: 0x0000B2AC
		public static void InvisibleMonke()
		{
			bool rightControllerPrimaryButton = Variables.pollerInstance.rightControllerPrimaryButton;
			bool flag = !Player.wasButtonPressed && rightControllerPrimaryButton;
			if (flag)
			{
				Player.isOn = !Player.isOn;
			}
			Player.wasButtonPressed = rightControllerPrimaryButton;
			bool flag2 = Player.isOn;
			if (flag2)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.transform.position = new Vector3(999f, 999f, 999f);
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000DA RID: 218 RVA: 0x0000D144 File Offset: 0x0000B344
		public static void GhostInvisibleMonke()
		{
			bool rightControllerPrimaryButton = Variables.pollerInstance.rightControllerPrimaryButton;
			bool flag = !Player.wasButtonPressed && rightControllerPrimaryButton;
			if (flag)
			{
				Player.isOn = !Player.isOn;
			}
			Player.wasButtonPressed = rightControllerPrimaryButton;
			bool rightControllerSecondaryButton = Variables.pollerInstance.rightControllerSecondaryButton;
			bool flag2 = !Player.wasButtonPressed2 && rightControllerSecondaryButton;
			if (flag2)
			{
				Player.isOn2 = !Player.isOn2;
			}
			Player.wasButtonPressed2 = rightControllerSecondaryButton;
			bool flag3 = Player.isOn;
			if (flag3)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
			bool flag4 = Player.isOn2;
			if (flag4)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.transform.position = new Vector3(999f, 999f, 999f);
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000DB RID: 219 RVA: 0x0000D240 File Offset: 0x0000B440
		public static void FreezeRig()
		{
			bool rightControllerPrimaryButton = Variables.pollerInstance.rightControllerPrimaryButton;
			bool flag = !Player.wasButtonPressed && rightControllerPrimaryButton;
			if (flag)
			{
				Player.isOn = !Player.isOn;
			}
			Player.wasButtonPressed = rightControllerPrimaryButton;
			bool flag2 = Player.isOn;
			if (flag2)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.transform.position = Variables.taggerInstance.headCollider.transform.position;
				Variables.taggerInstance.offlineVRRig.transform.rotation = Variables.taggerInstance.headCollider.transform.rotation;
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000DC RID: 220 RVA: 0x0000D300 File Offset: 0x0000B500
		public static void GrabRig()
		{
			bool rightGrab = Variables.pollerInstance.rightGrab;
			if (rightGrab)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.transform.position = Variables.taggerInstance.rightHandTransform.position;
				Variables.taggerInstance.offlineVRRig.transform.rotation = Variables.taggerInstance.rightHandTransform.rotation;
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
			bool leftGrab = Variables.pollerInstance.leftGrab;
			if (leftGrab)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.transform.position = Variables.taggerInstance.leftHandTransform.position;
				Variables.taggerInstance.offlineVRRig.transform.rotation = Variables.taggerInstance.leftHandTransform.rotation;
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000DD RID: 221 RVA: 0x0000D40C File Offset: 0x0000B60C
		public static void LongArms(bool setActive)
		{
			if (setActive)
			{
				Variables.playerInstance.transform.localScale = Settings.ArmLength;
			}
			else
			{
				Variables.playerInstance.transform.localScale = Vector3.one;
			}
		}

		// Token: 0x060000DE RID: 222 RVA: 0x0000D450 File Offset: 0x0000B650
		public static void GriddyMonke()
		{
			bool flag = (double)Variables.pollerInstance.rightControllerIndexFloat > 0.1;
			if (flag)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.head.rigTarget.transform.rotation = Variables.taggerInstance.offlineVRRig.transform.rotation;
				Vector3 vector = Variables.taggerInstance.offlineVRRig.transform.right * -0.25f + Variables.taggerInstance.offlineVRRig.transform.forward * 0.5f * Mathf.Cos((float)Time.frameCount / 10f) + Variables.taggerInstance.offlineVRRig.transform.up * -0.3f * Mathf.Abs(Mathf.Sin((float)Time.frameCount / 7f));
				Vector3 vector2 = Variables.taggerInstance.offlineVRRig.transform.right * 0.25f + Variables.taggerInstance.offlineVRRig.transform.forward * 0.5f * Mathf.Cos((float)Time.frameCount / 10f) + Variables.taggerInstance.offlineVRRig.transform.up * -0.3f * Mathf.Abs(Mathf.Sin((float)Time.frameCount / 7f));
				Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + vector;
				Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + vector2;
				Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.rotation = Variables.taggerInstance.offlineVRRig.transform.rotation;
				Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.rotation = Variables.taggerInstance.offlineVRRig.transform.rotation;
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000DF RID: 223 RVA: 0x0000D6DC File Offset: 0x0000B8DC
		public static void SizeChanger()
		{
			bool leftControllerSecondaryButton = Variables.pollerInstance.leftControllerSecondaryButton;
			if (leftControllerSecondaryButton)
			{
				Player.sizeScale = 1f;
			}
			bool flag = Variables.pollerInstance.leftControllerIndexFloat > 0.1f;
			if (flag)
			{
				Player.sizeScale -= 0.05f;
			}
			bool flag2 = Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
			if (flag2)
			{
				Player.sizeScale += 0.05f;
			}
			bool flag3 = Player.sizeScale <= 0f;
			if (flag3)
			{
				Player.sizeScale = 0.05f;
			}
			Traverse.Create(GTPlayer.Instance).Field("scaleMultiplier").SetValue(Player.sizeScale);
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x0000D798 File Offset: 0x0000B998
		public static void HelicopterMonke()
		{
			bool flag = (double)Variables.pollerInstance.rightControllerIndexFloat > 0.1;
			if (flag)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.transform.position += new Vector3(0f, 0.075f, 0f);
				Variables.taggerInstance.offlineVRRig.transform.rotation = Quaternion.Euler(Variables.taggerInstance.offlineVRRig.transform.rotation.eulerAngles + new Vector3(0f, 10f, 0f));
				Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * -1f;
				Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * 1f;
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x0000D91C File Offset: 0x0000BB1C
		public static void AscendingMonke()
		{
			bool flag = (double)Variables.pollerInstance.rightControllerIndexFloat > 0.1;
			if (flag)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.transform.position += new Vector3(0f, 0.01f, 0f);
				Variables.taggerInstance.offlineVRRig.head.rigTarget.transform.rotation = Variables.taggerInstance.offlineVRRig.transform.rotation;
				Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * -1f;
				Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * 1f;
				Player.SetHeadRotation(new Vector3?(new Vector3(180f, 0f, 0f)), default(float?));
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x0000DAAC File Offset: 0x0000BCAC
		public static void SpazMonke()
		{
			Variables.taggerInstance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
			Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
			Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
			Variables.taggerInstance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 180), (float)Random.Range(0, 180));
			Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 180), (float)Random.Range(0, 180));
			Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 180), (float)Random.Range(0, 180));
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x0000DC4C File Offset: 0x0000BE4C
		public static void SpazArms()
		{
			bool flag = (double)Variables.pollerInstance.rightControllerIndexFloat > 0.1;
			if (flag)
			{
				float num = 360f;
				Variables.playerInstance.leftControllerTransform.rotation = Quaternion.Euler(new Vector3(Random.Range(0f, num), Random.Range(0f, num), 4f));
				Variables.playerInstance.leftControllerTransform.position = Variables.taggerInstance.leftHandTransform.position + Variables.playerInstance.leftControllerTransform.forward * 3f;
				Variables.playerInstance.rightControllerTransform.rotation = Quaternion.Euler(new Vector3(Random.Range(0f, num), Random.Range(0f, num), 4f));
				Variables.playerInstance.rightControllerTransform.position = Variables.taggerInstance.rightHandTransform.position + Variables.playerInstance.rightControllerTransform.forward * 3f;
			}
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x0000DD64 File Offset: 0x0000BF64
		public static void TPose()
		{
			bool flag = (double)Variables.pollerInstance.rightControllerIndexFloat > 0.1;
			if (flag)
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
				Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * -1.5f;
				Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * 1.5f;
				Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
				Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
			}
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x0000DEB4 File Offset: 0x0000C0B4
		public static void SetRigStatus(bool rigStatus)
		{
			if (rigStatus)
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 0f, 0f)), default(float?));
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = false;
			}
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x0000DF18 File Offset: 0x0000C118
		public static void SetHeadRotation(Vector3? headRotation = null, float? spinAmount = null)
		{
			Vector3 trackingRotationOffset = Variables.taggerInstance.offlineVRRig.head.trackingRotationOffset;
			bool flag = spinAmount != null;
			if (flag)
			{
				trackingRotationOffset.y += spinAmount.Value;
			}
			bool flag2 = headRotation != null;
			if (flag2)
			{
				trackingRotationOffset = headRotation.Value;
			}
			Variables.taggerInstance.offlineVRRig.head.trackingRotationOffset = trackingRotationOffset;
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x0000DF84 File Offset: 0x0000C184
		public static void RigGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					Variables.taggerInstance.offlineVRRig.enabled = false;
					Variables.taggerInstance.offlineVRRig.transform.position = GunLib.raycastHit.point + new Vector3(0f, 1f, 0f);
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
				}
			}
			else
			{
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x0000E018 File Offset: 0x0000C218
		public static void TeleportGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = !Player.hasTeleported && GunLib.raycastHit.collider != null;
					if (flag)
					{
						Variables.playerInstance.transform.position = GunLib.raycastHit.point;
						Player.hasTeleported = true;
					}
				}
				else
				{
					Player.hasTeleported = false;
				}
			}
			else
			{
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x0000E098 File Offset: 0x0000C298
		public static void ChasePlayerGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						Variables.taggerInstance.offlineVRRig.enabled = false;
						Variables.taggerInstance.offlineVRRig.transform.position = Vector3.MoveTowards(Variables.taggerInstance.offlineVRRig.transform.position, GunLib.lockedTargetRig.transform.position, Time.deltaTime * 10f);
						Variables.taggerInstance.offlineVRRig.transform.LookAt(GunLib.lockedTargetRig.transform);
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * -1.5f;
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * 1.5f;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						Variables.taggerInstance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 180), (float)Random.Range(0, 180));
						Variables.taggerInstance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
						Variables.taggerInstance.GetComponent<Rigidbody>().velocity = Vector3.zero;
					}
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000EA RID: 234 RVA: 0x0000E358 File Offset: 0x0000C558
		public static void JumpscarePlayerGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						Variables.taggerInstance.offlineVRRig.enabled = false;
						Variables.taggerInstance.offlineVRRig.transform.position = GunLib.lockedTargetRig.head.rigTarget.transform.position + GunLib.lockedTargetRig.head.rigTarget.transform.forward * 0.6f;
						Variables.taggerInstance.offlineVRRig.transform.LookAt(GunLib.lockedTargetRig.transform);
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * -1.5f;
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * 1.5f;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						Variables.taggerInstance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 180), (float)Random.Range(0, 180));
						Variables.taggerInstance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)Random.Range(0, 360), (float)Random.Range(0, 360), (float)Random.Range(0, 360));
						Variables.taggerInstance.GetComponent<Rigidbody>().velocity = Vector3.zero;
					}
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000EB RID: 235 RVA: 0x0000E624 File Offset: 0x0000C824
		public static void OrbitPlayerGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						Variables.taggerInstance.offlineVRRig.enabled = false;
						Variables.taggerInstance.offlineVRRig.transform.LookAt(GunLib.lockedTargetRig.transform.position);
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * -1.5f;
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * 1.5f;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						Variables.taggerInstance.offlineVRRig.transform.RotateAround(GunLib.lockedTargetRig.transform.position, Vector3.up, Player.orbitSpeed * Time.deltaTime);
						Vector3 position = (Variables.taggerInstance.offlineVRRig.transform.position - GunLib.lockedTargetRig.transform.position).normalized * Player.orbitDistance + GunLib.lockedTargetRig.transform.position;
						Variables.taggerInstance.offlineVRRig.transform.position = position;
					}
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000EC RID: 236 RVA: 0x0000E8A0 File Offset: 0x0000CAA0
		public static void CopyPlayerGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						Variables.taggerInstance.offlineVRRig.enabled = false;
						Variables.taggerInstance.offlineVRRig.transform.position = GunLib.lockedTargetRig.transform.position;
						Variables.taggerInstance.offlineVRRig.transform.rotation = GunLib.lockedTargetRig.transform.rotation;
						Variables.taggerInstance.offlineVRRig.head.rigTarget.position = GunLib.lockedTargetRig.head.rigTarget.position;
						Variables.taggerInstance.offlineVRRig.head.rigTarget.rotation = GunLib.lockedTargetRig.head.rigTarget.rotation;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.position = GunLib.lockedTargetRig.leftHand.rigTarget.position;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.rotation = GunLib.lockedTargetRig.leftHand.rigTarget.rotation;
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.position = GunLib.lockedTargetRig.rightHand.rigTarget.position;
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.rotation = GunLib.lockedTargetRig.rightHand.rigTarget.rotation;
						bool flag2 = GunLib.lockedTargetRig.leftIndex != null;
						if (flag2)
						{
							Variables.taggerInstance.offlineVRRig.leftIndex.calcT = GunLib.lockedTargetRig.leftIndex.calcT;
							Variables.taggerInstance.offlineVRRig.leftIndex.LerpFinger(1f, false);
						}
						bool flag3 = GunLib.lockedTargetRig.leftMiddle != null;
						if (flag3)
						{
							Variables.taggerInstance.offlineVRRig.leftMiddle.calcT = GunLib.lockedTargetRig.leftMiddle.calcT;
							Variables.taggerInstance.offlineVRRig.leftMiddle.LerpFinger(1f, false);
						}
						bool flag4 = GunLib.lockedTargetRig.leftThumb != null;
						if (flag4)
						{
							Variables.taggerInstance.offlineVRRig.leftThumb.calcT = GunLib.lockedTargetRig.leftThumb.calcT;
							Variables.taggerInstance.offlineVRRig.leftThumb.LerpFinger(1f, false);
						}
						bool flag5 = GunLib.lockedTargetRig.rightIndex != null;
						if (flag5)
						{
							Variables.taggerInstance.offlineVRRig.rightIndex.calcT = GunLib.lockedTargetRig.rightIndex.calcT;
							Variables.taggerInstance.offlineVRRig.rightIndex.LerpFinger(1f, false);
						}
						bool flag6 = GunLib.lockedTargetRig.rightMiddle != null;
						if (flag6)
						{
							Variables.taggerInstance.offlineVRRig.rightMiddle.calcT = GunLib.lockedTargetRig.rightMiddle.calcT;
							Variables.taggerInstance.offlineVRRig.rightMiddle.LerpFinger(1f, false);
						}
						bool flag7 = GunLib.lockedTargetRig.rightThumb != null;
						if (flag7)
						{
							Variables.taggerInstance.offlineVRRig.rightThumb.calcT = GunLib.lockedTargetRig.rightThumb.calcT;
							Variables.taggerInstance.offlineVRRig.rightThumb.LerpFinger(1f, false);
						}
					}
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000ED RID: 237 RVA: 0x0000EC98 File Offset: 0x0000CE98
		public static void FuckPlayerGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						Variables.taggerInstance.offlineVRRig.enabled = false;
						Vector3 vector = GunLib.lockedTargetRig.transform.position - GunLib.lockedTargetRig.transform.forward * 0.5f;
						Vector3 vector2 = GunLib.lockedTargetRig.transform.position - GunLib.lockedTargetRig.transform.forward * 1.5f;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * -1.5f;
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * 1.5f;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						bool flag2 = Player.movingCloser;
						if (flag2)
						{
							Variables.taggerInstance.offlineVRRig.transform.position = Vector3.MoveTowards(Variables.taggerInstance.offlineVRRig.transform.position, vector, Player.fuckSpeed * Time.deltaTime);
							bool flag3 = Vector3.Distance(Variables.taggerInstance.offlineVRRig.transform.position, vector) < 0.1f;
							if (flag3)
							{
								Player.movingCloser = false;
							}
						}
						else
						{
							Variables.taggerInstance.offlineVRRig.transform.position = Vector3.MoveTowards(Variables.taggerInstance.offlineVRRig.transform.position, vector2, Player.fuckSpeed * Time.deltaTime);
							bool flag4 = Vector3.Distance(Variables.taggerInstance.offlineVRRig.transform.position, vector2) < 0.1f;
							if (flag4)
							{
								Player.movingCloser = true;
							}
						}
						Variables.taggerInstance.offlineVRRig.transform.LookAt(GunLib.lockedTargetRig.transform);
					}
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000EE RID: 238 RVA: 0x0000EFB8 File Offset: 0x0000D1B8
		public static void PiggybackPlayerGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				Collider collider = GunLib.raycastHit.collider;
				GunLib.potentialTargetRig = ((collider != null) ? collider.GetComponentInParent<VRRig>() : null);
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					bool flag = GunLib.lockedTargetRig == null;
					if (flag)
					{
						GunLib.lockedTargetRig = GunLib.potentialTargetRig;
					}
					else
					{
						Variables.taggerInstance.offlineVRRig.enabled = false;
						Variables.taggerInstance.offlineVRRig.transform.position = GunLib.lockedTargetRig.transform.position - GunLib.lockedTargetRig.transform.forward * 0.5f + Vector3.up * 0.3f;
						Variables.taggerInstance.offlineVRRig.transform.rotation = GunLib.lockedTargetRig.transform.rotation;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * -1.5f;
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.position = Variables.taggerInstance.offlineVRRig.transform.position + Variables.taggerInstance.offlineVRRig.transform.right * 1.5f;
						Variables.taggerInstance.offlineVRRig.leftHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
						Variables.taggerInstance.offlineVRRig.rightHand.rigTarget.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
					}
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
					GunLib.lockedTargetRig = null;
				}
			}
			else
			{
				GunLib.lockedTargetRig = null;
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x0400018C RID: 396
		private static bool isOn = false;

		// Token: 0x0400018D RID: 397
		private static bool wasButtonPressed = false;

		// Token: 0x0400018E RID: 398
		public static bool isOn2 = false;

		// Token: 0x0400018F RID: 399
		private static bool wasButtonPressed2 = false;

		// Token: 0x04000190 RID: 400
		private static bool isplayerlevitating = false;

		// Token: 0x04000191 RID: 401
		private static float orbitSpeed = 100f;

		// Token: 0x04000192 RID: 402
		private static float orbitDistance = 2f;

		// Token: 0x04000193 RID: 403
		private static bool hasTeleported = false;

		// Token: 0x04000194 RID: 404
		private static float fuckSpeed = 5f;

		// Token: 0x04000195 RID: 405
		private static bool movingCloser = true;

		// Token: 0x04000196 RID: 406
		private static float sizeScale = 1f;
	}
}
