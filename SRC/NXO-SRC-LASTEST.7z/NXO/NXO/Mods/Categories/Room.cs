﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using GorillaNetworking;
using NXO.Patches;
using NXO.Utilities;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000022 RID: 34
	[NullableContext(1)]
	[Nullable(0)]
	public class Room : MonoBehaviourPunCallbacks
	{
		// Token: 0x06000100 RID: 256 RVA: 0x000101E0 File Offset: 0x0000E3E0
		public static void SetNetworkTriggersActive(bool isActive)
		{
			GameObject gameObject = GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab");
			bool flag = gameObject != null;
			if (flag)
			{
				gameObject.SetActive(isActive);
			}
		}

		// Token: 0x06000101 RID: 257 RVA: 0x00010210 File Offset: 0x0000E410
		public static void SetQuitBoxActive(bool isActive)
		{
			GameObject gameObject = GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox");
			bool flag = gameObject != null;
			if (flag)
			{
				gameObject.SetActive(isActive);
			}
		}

		// Token: 0x06000102 RID: 258 RVA: 0x00010240 File Offset: 0x0000E440
		public static void AcceptTOS(bool tosActive)
		{
			GameObject gameObject = GameObject.Find("Miscellaneous Scripts/PopUpMessage");
			bool flag = gameObject != null;
			if (flag)
			{
				gameObject.SetActive(tosActive);
				TosPatches.IsEnabled = tosActive;
			}
		}

		// Token: 0x06000103 RID: 259 RVA: 0x00010274 File Offset: 0x0000E474
		public static void GrabAllIDs()
		{
			bool flag = PhotonNetwork.CurrentRoom == null || PhotonNetwork.PlayerList == null || PhotonNetwork.PlayerList.Length == 0;
			if (flag)
			{
				Debug.LogError("Failed to grab IDs: No room or players found.");
			}
			else
			{
				string text = "IDS GRABBED FROM NXO \nIDS GRABBED FROM ROOM: " + PhotonNetwork.CurrentRoom.Name + "\n\n";
				StringBuilder stringBuilder = new StringBuilder(text);
				foreach (Player player in PhotonNetwork.PlayerList)
				{
					stringBuilder.AppendLine("NAME: " + player.NickName + " ID: " + player.UserId);
				}
				string text2 = Path.Combine(Room.folderName, "Grabbed_IDs_By_NXO.txt");
				File.WriteAllText(text2, stringBuilder.ToString());
				Process.Start(new ProcessStartInfo(text2)
				{
					UseShellExecute = true
				});
			}
		}

		// Token: 0x06000104 RID: 260 RVA: 0x0001034C File Offset: 0x0000E54C
		public static void GrabSelfID()
		{
			string text = "SELF ID GRABBED FROM NXO";
			StringBuilder stringBuilder = new StringBuilder(text);
			stringBuilder.AppendLine("NAME: " + PhotonNetwork.LocalPlayer.NickName + " ID: " + PhotonNetwork.LocalPlayer.UserId);
			string text2 = Path.Combine(Room.folderName, "Self_ID_By_NXO.txt");
			File.WriteAllText(text2, stringBuilder.ToString());
			Process.Start(new ProcessStartInfo(text2)
			{
				UseShellExecute = true
			});
		}

		// Token: 0x06000105 RID: 261 RVA: 0x000103C4 File Offset: 0x0000E5C4
		public static void DumpAllRPCs()
		{
			bool flag = PhotonNetwork.PhotonServerSettings == null || PhotonNetwork.PhotonServerSettings.RpcList == null;
			if (flag)
			{
				Debug.LogError("Failed to dump RPCs: PhotonServerSettings or RpcList is null.");
			}
			else
			{
				string text = "RPCS DUMPED BY NXO\n\n";
				StringBuilder stringBuilder = new StringBuilder(text);
				foreach (string text2 in PhotonNetwork.PhotonServerSettings.RpcList)
				{
					stringBuilder.AppendLine("RPC: " + text2);
				}
				string text3 = Path.Combine(Room.folderName, "Dumped_RPCs_By_NXO.txt");
				File.WriteAllText(text3, stringBuilder.ToString());
				Process.Start(new ProcessStartInfo(text3)
				{
					UseShellExecute = true
				});
			}
		}

		// Token: 0x06000106 RID: 262 RVA: 0x000104A0 File Offset: 0x0000E6A0
		public static void Reconnect()
		{
			Room.roomCode = PhotonNetwork.CurrentRoom.Name;
			bool inRoom = PhotonNetwork.InRoom;
			if (inRoom)
			{
				PhotonNetwork.Disconnect();
			}
			Task.Delay(3).ContinueWith(delegate(Task _)
			{
				PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(Room.roomCode, 0);
			});
		}

		// Token: 0x06000107 RID: 263 RVA: 0x000104FC File Offset: 0x0000E6FC
		public static void JoinRandomPublic()
		{
			bool inRoom = PhotonNetwork.InRoom;
			if (inRoom)
			{
				Debug.LogWarning("<color=blue>Photon</color> : Already connected to a room.");
				NotificationLib.SendNotification("<color=blue>Photon</color> : Already connected to a room.");
			}
			else
			{
				string gamemode = PhotonNetworkController.Instance.currentJoinTrigger.networkZone;
				bool flag = gamemode == null;
				if (flag)
				{
					Debug.LogWarning("<color=blue>Photon</color> : Unable To Find Join Trigger.");
					NotificationLib.SendNotification("<color=Red>Photon</color> : Unable To Find Join Trigger.");
				}
				else
				{
					Task.Delay(3).ContinueWith(delegate(Task _)
					{
						PhotonNetworkController.Instance.AttemptToJoinPublicRoom(GorillaComputer.instance.GetJoinTriggerForZone(gamemode), 0);
					});
				}
			}
		}

		// Token: 0x06000108 RID: 264 RVA: 0x00010588 File Offset: 0x0000E788
		public override void OnJoinRoomFailed(short returnCode, string message)
		{
			bool flag = returnCode == 32765;
			if (flag)
			{
				Debug.LogWarning("OnJoinRoomFailed : Failed to join room '" + Room.roomCode + "'. Reason: Is Full.");
				NotificationLib.SendNotification("<color=red>Error</color> : Failed to join room '" + Room.roomCode + "'. Reason: Is Full.");
			}
			else
			{
				Debug.LogWarning(string.Concat(new string[]
				{
					"OnJoinRoomFailed: Failed to join room '",
					Room.roomCode,
					"'. Reason: ",
					message,
					"."
				}));
				NotificationLib.SendNotification(string.Concat(new string[]
				{
					"<color=red>Error</color>: Failed to join room '",
					Room.roomCode,
					"'. Reason: ",
					message,
					"."
				}));
			}
		}

		// Token: 0x040001A7 RID: 423
		public static string roomCode;

		// Token: 0x040001A8 RID: 424
		public static string folderName;
	}
}
