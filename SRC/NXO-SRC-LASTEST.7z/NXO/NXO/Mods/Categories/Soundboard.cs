﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using NXO.Menu;
using NXO.Utilities;
using Photon.Pun;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000026 RID: 38
	[NullableContext(1)]
	[Nullable(0)]
	public static class Soundboard
	{
		// Token: 0x0600012F RID: 303 RVA: 0x00012765 File Offset: 0x00010965
		public static void EnableLoop()
		{
			Soundboard.loop = true;
		}

		// Token: 0x06000130 RID: 304 RVA: 0x0001276D File Offset: 0x0001096D
		public static void DisableLoop()
		{
			Soundboard.loop = false;
		}

		// Token: 0x06000131 RID: 305 RVA: 0x00012778 File Offset: 0x00010978
		public static void PlaySound(string url)
		{
			bool flag = InputHandler.RSecondary();
			if (flag)
			{
				bool flag2 = !Soundboard.isPlaying;
				if (flag2)
				{
					Soundboard.isPlaying = true;
					bool flag3 = !PhotonNetwork.InRoom;
					if (flag3)
					{
						NotificationLib.SendNotification("<color=red>ERROR</color> : Join A Lobby To Play Soundboard");
					}
					else
					{
						bool flag4 = Soundboard.currentlyPlayingSound != null && Soundboard.currentlyPlayingSound != url;
						if (flag4)
						{
							Soundboard.StopSound(Soundboard.currentlyPlayingSound);
						}
						Soundboard.currentlyPlayingSound = url;
						Soundboard.SoundboardSoundsActive[url] = true;
						bool flag5 = Soundboard.loadedSounds.ContainsKey(url);
						if (flag5)
						{
							Soundboard.sounded = Soundboard.loadedSounds[url];
							Soundboard.PlayAudioSource(Soundboard.sounded, url);
						}
						else
						{
							MonoBehaviourHelper.Instance.StartCoroutine(Soundboard.SoundboardDownloadAndPlaySoundFromUrl(url));
						}
					}
				}
			}
			else
			{
				Soundboard.isPlaying = false;
			}
		}

		// Token: 0x06000132 RID: 306 RVA: 0x00012850 File Offset: 0x00010A50
		public static void InitializeSounds()
		{
			bool flag = !Soundboard.SoundsInitialized;
			if (flag)
			{
				Soundboard.SoundsInitialized = true;
				Debug.Log("Sounds Initialized");
				MonoBehaviourHelper.Instance.StartCoroutine(Soundboard.GetSoundsToButtons());
				MonoBehaviourHelper.Instance.StartCoroutine(Variables.AddTimerOnMethod(new Action(Optimizations.RefreshMenu), 1.5f));
			}
		}

		// Token: 0x06000133 RID: 307 RVA: 0x000128AE File Offset: 0x00010AAE
		public static IEnumerator GetSoundsToButtons()
		{
			return new Soundboard.<GetSoundsToButtons>d__16(0);
		}

		// Token: 0x06000134 RID: 308 RVA: 0x000128B6 File Offset: 0x00010AB6
		public static IEnumerator SoundboardDownloadAndPlaySoundFromUrl(string url)
		{
			Soundboard.<SoundboardDownloadAndPlaySoundFromUrl>d__17 <SoundboardDownloadAndPlaySoundFromUrl>d__ = new Soundboard.<SoundboardDownloadAndPlaySoundFromUrl>d__17(0);
			<SoundboardDownloadAndPlaySoundFromUrl>d__.url = url;
			return <SoundboardDownloadAndPlaySoundFromUrl>d__;
		}

		// Token: 0x06000135 RID: 309 RVA: 0x000128C5 File Offset: 0x00010AC5
		public static IEnumerator LoadAllSoundsCoroutine()
		{
			return new Soundboard.<LoadAllSoundsCoroutine>d__18(0);
		}

		// Token: 0x06000136 RID: 310 RVA: 0x000128D0 File Offset: 0x00010AD0
		[DebuggerStepThrough]
		public static Task LoadAllSoundboardSounds()
		{
			Soundboard.<LoadAllSoundboardSounds>d__19 <LoadAllSoundboardSounds>d__ = new Soundboard.<LoadAllSoundboardSounds>d__19();
			<LoadAllSoundboardSounds>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<LoadAllSoundboardSounds>d__.<>1__state = -1;
			<LoadAllSoundboardSounds>d__.<>t__builder.Start<Soundboard.<LoadAllSoundboardSounds>d__19>(ref <LoadAllSoundboardSounds>d__);
			return <LoadAllSoundboardSounds>d__.<>t__builder.Task;
		}

		// Token: 0x06000137 RID: 311 RVA: 0x00012910 File Offset: 0x00010B10
		[DebuggerStepThrough]
		public static Task LoadSoundboardSounds(string url, string category)
		{
			Soundboard.<LoadSoundboardSounds>d__20 <LoadSoundboardSounds>d__ = new Soundboard.<LoadSoundboardSounds>d__20();
			<LoadSoundboardSounds>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<LoadSoundboardSounds>d__.url = url;
			<LoadSoundboardSounds>d__.category = category;
			<LoadSoundboardSounds>d__.<>1__state = -1;
			<LoadSoundboardSounds>d__.<>t__builder.Start<Soundboard.<LoadSoundboardSounds>d__20>(ref <LoadSoundboardSounds>d__);
			return <LoadSoundboardSounds>d__.<>t__builder.Task;
		}

		// Token: 0x06000138 RID: 312 RVA: 0x0001295C File Offset: 0x00010B5C
		[DebuggerStepThrough]
		public static Task<string> GetRawFrom(string url)
		{
			Soundboard.<GetRawFrom>d__21 <GetRawFrom>d__ = new Soundboard.<GetRawFrom>d__21();
			<GetRawFrom>d__.<>t__builder = AsyncTaskMethodBuilder<string>.Create();
			<GetRawFrom>d__.url = url;
			<GetRawFrom>d__.<>1__state = -1;
			<GetRawFrom>d__.<>t__builder.Start<Soundboard.<GetRawFrom>d__21>(ref <GetRawFrom>d__);
			return <GetRawFrom>d__.<>t__builder.Task;
		}

		// Token: 0x06000139 RID: 313 RVA: 0x000129A0 File Offset: 0x00010BA0
		private static void PlayAudioSource(AudioSource source, string url)
		{
			bool flag = source == null;
			if (flag)
			{
				Debug.LogError("AudioSource is null.");
			}
			else
			{
				source.Play();
				source.transform.parent = Variables.playerInstance.transform;
				Soundboard.SetupRecorder(source);
				bool flag2 = Soundboard.loop;
				if (flag2)
				{
					Coroutine coroutine = MonoBehaviourHelper.Instance.StartCoroutine(Soundboard.PlaySoundCoroutine(source, url));
					Soundboard.activeCoroutines[url] = coroutine;
				}
			}
		}

		// Token: 0x0600013A RID: 314 RVA: 0x00012A15 File Offset: 0x00010C15
		private static IEnumerator PlaySoundCoroutine(AudioSource source, string url)
		{
			Soundboard.<PlaySoundCoroutine>d__23 <PlaySoundCoroutine>d__ = new Soundboard.<PlaySoundCoroutine>d__23(0);
			<PlaySoundCoroutine>d__.source = source;
			<PlaySoundCoroutine>d__.url = url;
			return <PlaySoundCoroutine>d__;
		}

		// Token: 0x0600013B RID: 315 RVA: 0x00012A2C File Offset: 0x00010C2C
		public static void StopSound(string url)
		{
			bool flag = !Soundboard.SoundboardSoundsActive.ContainsKey(url) || !Soundboard.SoundboardSoundsActive[url];
			if (!flag)
			{
				Soundboard.SoundboardSoundsActive[url] = false;
				Coroutine coroutine;
				bool flag2 = Soundboard.activeCoroutines.TryGetValue(url, ref coroutine);
				if (flag2)
				{
					MonoBehaviourHelper.Instance.StopCoroutine(coroutine);
					Soundboard.activeCoroutines.Remove(url);
				}
				bool flag3 = Soundboard.sounded != null;
				if (flag3)
				{
					Soundboard.sounded.Stop();
					Soundboard.sounded = null;
				}
				Soundboard.FixRecorder();
				Debug.Log("Sound stopped: " + url);
			}
		}

		// Token: 0x0600013C RID: 316 RVA: 0x00012AD0 File Offset: 0x00010CD0
		private static void SetupRecorder(AudioSource source)
		{
			GorillaTagger.Instance.myRecorder.SourceType = 1;
			GorillaTagger.Instance.myRecorder.AudioClip = source.clip;
			GorillaTagger.Instance.myRecorder.RestartRecording(true);
			GorillaTagger.Instance.myRecorder.LoopAudioClip = Soundboard.loop;
		}

		// Token: 0x0600013D RID: 317 RVA: 0x00012B2C File Offset: 0x00010D2C
		public static void FixRecorder()
		{
			GorillaTagger.Instance.myRecorder.SourceType = 0;
			GorillaTagger.Instance.myRecorder.AudioClip = null;
			GorillaTagger.Instance.myRecorder.RestartRecording(true);
			GorillaTagger.Instance.myRecorder.LoopAudioClip = false;
			Soundboard.currentlyPlayingSound = null;
			Soundboard.isPlaying = false;
		}

		// Token: 0x0600013E RID: 318 RVA: 0x00012B8C File Offset: 0x00010D8C
		// Note: this type is marked as 'beforefieldinit'.
		static Soundboard()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("SFX", "https://github.com/NuggetGT/NXO-Resources/raw/refs/heads/main/Sounds/SoundEffects/SoundEffectsDownloadPath.txt");
			dictionary.Add("Trolling", "https://github.com/NuggetGT/NXO-Resources/raw/refs/heads/main/Sounds/Trolling/TrollingDownloadPath.txt");
			dictionary.Add("Songs", "https://github.com/NuggetGT/NXO-Resources/raw/refs/heads/main/Sounds/Songs/SongsDownloadPath.txt");
			Soundboard.soundboardUrls = dictionary;
		}

		// Token: 0x040001D8 RID: 472
		public static Dictionary<string, bool> SoundboardSoundsActive = new Dictionary<string, bool>();

		// Token: 0x040001D9 RID: 473
		private static bool loop = false;

		// Token: 0x040001DA RID: 474
		private static Dictionary<string, Coroutine> activeCoroutines = new Dictionary<string, Coroutine>();

		// Token: 0x040001DB RID: 475
		private static Dictionary<string, AudioSource> loadedSounds = new Dictionary<string, AudioSource>();

		// Token: 0x040001DC RID: 476
		private static AudioSource sounded;

		// Token: 0x040001DD RID: 477
		private static string currentlyPlayingSound = null;

		// Token: 0x040001DE RID: 478
		private static bool isPlaying = false;

		// Token: 0x040001DF RID: 479
		public static bool SoundsInitialized = false;

		// Token: 0x040001E0 RID: 480
		public static Dictionary<string, string> SFX = new Dictionary<string, string>();

		// Token: 0x040001E1 RID: 481
		public static Dictionary<string, string> Trolling = new Dictionary<string, string>();

		// Token: 0x040001E2 RID: 482
		public static Dictionary<string, string> Songs = new Dictionary<string, string>();

		// Token: 0x040001E3 RID: 483
		private static readonly Dictionary<string, string> soundboardUrls;
	}
}
