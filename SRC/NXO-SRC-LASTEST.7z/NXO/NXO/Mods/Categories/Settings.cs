﻿using System;
using System.Runtime.CompilerServices;
using NXO.Menu;
using NXO.Utilities;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000024 RID: 36
	[NullableContext(1)]
	[Nullable(0)]
	public class Settings
	{
		// Token: 0x06000113 RID: 275 RVA: 0x00010BAB File Offset: 0x0000EDAB
		public static void SwitchHands(bool setActive)
		{
			Variables.rightHandedMenu = setActive;
		}

		// Token: 0x06000114 RID: 276 RVA: 0x00010BB4 File Offset: 0x0000EDB4
		public static void ClearNotifications()
		{
			NotificationLib.ClearAllNotifications();
		}

		// Token: 0x06000115 RID: 277 RVA: 0x00010BBD File Offset: 0x0000EDBD
		public static void ToggleNotifications(bool setActive)
		{
			Variables.toggleNotifications = setActive;
		}

		// Token: 0x06000116 RID: 278 RVA: 0x00010BC6 File Offset: 0x0000EDC6
		public static void ToggleDisconnectButton(bool setActive)
		{
			Variables.toggledisconnectButton = setActive;
		}

		// Token: 0x06000117 RID: 279 RVA: 0x00010BCF File Offset: 0x0000EDCF
		public static void ToggleWideMenu(bool setActive)
		{
			Variables.wideMenu = setActive;
		}

		// Token: 0x06000118 RID: 280 RVA: 0x00010BD8 File Offset: 0x0000EDD8
		public static void GripSpeedBoost(bool setActive)
		{
			Settings.useGripForSpeedBoost = setActive;
		}

		// Token: 0x06000119 RID: 281 RVA: 0x00010BE1 File Offset: 0x0000EDE1
		public static void TriggerPlatforms(bool setActive)
		{
			PlatformLib.isTriggerPlatforms = setActive;
		}

		// Token: 0x0600011A RID: 282 RVA: 0x00010BEA File Offset: 0x0000EDEA
		public static void IsTeamChecked(bool setActive)
		{
			Variables.teamCheckedESP = setActive;
		}

		// Token: 0x0600011B RID: 283 RVA: 0x00010BF3 File Offset: 0x0000EDF3
		public static void isNoclipFly(bool setActive)
		{
			Settings.noclipFly = setActive;
		}

		// Token: 0x0600011C RID: 284 RVA: 0x00010BFC File Offset: 0x0000EDFC
		public static void AdvancedTitle(bool setActive)
		{
			Variables.advancedTitle = setActive;
		}

		// Token: 0x0600011D RID: 285 RVA: 0x00010C05 File Offset: 0x0000EE05
		public static void AnimatedGuns(bool setActive)
		{
			GunLib.isWiggling = setActive;
		}

		// Token: 0x0600011E RID: 286 RVA: 0x00010C10 File Offset: 0x0000EE10
		public static void CycleTheme()
		{
			ColorLib.CurrentTheme = (ColorLib.CurrentTheme + 1) % Settings.ThemeDescriptions.Length;
			Settings.ThemeDescription = Settings.ThemeDescriptions[ColorLib.CurrentTheme];
			bool flag = Settings.themeChangerButton != null;
			if (flag)
			{
				Settings.themeChangerButton.buttonText = "Menu Theme : " + Settings.ThemeDescription;
			}
			NXOUI nxoui = Object.FindObjectOfType<NXOUI>();
			if (nxoui != null)
			{
				nxoui.GUITextures();
			}
			Optimizations.RefreshMenu();
		}

		// Token: 0x0600011F RID: 287 RVA: 0x00010C84 File Offset: 0x0000EE84
		public static void AdjustTracerPosition()
		{
			Settings.tracerPositionIndex = (Settings.tracerPositionIndex + 1) % 4;
			int num = Settings.tracerPositionIndex;
			if (!true)
			{
			}
			string tracerPosition;
			switch (num)
			{
			case 0:
				tracerPosition = "Right Hand";
				break;
			case 1:
				tracerPosition = "Left Hand";
				break;
			case 2:
				tracerPosition = "Head";
				break;
			case 3:
				tracerPosition = "Button";
				break;
			default:
				tracerPosition = "Unknown";
				break;
			}
			if (!true)
			{
			}
			Settings.TracerPosition = tracerPosition;
			bool flag = Settings.tracerPositionButton != null;
			if (flag)
			{
				Settings.tracerPositionButton.buttonText = "Tracer Position : " + Settings.TracerPosition;
			}
		}

		// Token: 0x06000120 RID: 288 RVA: 0x00010D1C File Offset: 0x0000EF1C
		public static void AdjustSpeedBoost()
		{
			Settings.currentSpeedIndex = (Settings.currentSpeedIndex + 1) % 6;
			int num = Settings.currentSpeedIndex;
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple;
			switch (num)
			{
			case 0:
				valueTuple = new ValueTuple<float, string>(10f, "Medium");
				break;
			case 1:
				valueTuple = new ValueTuple<float, string>(14f, "Fast");
				break;
			case 2:
				valueTuple = new ValueTuple<float, string>(18f, "Very Fast");
				break;
			case 3:
				valueTuple = new ValueTuple<float, string>(7.5f, "Mosa");
				break;
			case 4:
				valueTuple = new ValueTuple<float, string>(7f, "Comp");
				break;
			case 5:
				valueTuple = new ValueTuple<float, string>(6f, "Slow");
				break;
			default:
				valueTuple = new ValueTuple<float, string>(10f, "Unknown");
				break;
			}
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple2 = valueTuple;
			float item = valueTuple2.Item1;
			string item2 = valueTuple2.Item2;
			Settings.SpeedboostSpeed = item;
			Settings.SpeedboostMultiplier = Settings.SpeedboostSpeed / 5f;
			Settings.SpeedDescription = item2;
			bool flag = Settings.adjustSpeedBoostButton != null;
			if (flag)
			{
				Settings.adjustSpeedBoostButton.buttonText = "Speed Boost : " + Settings.SpeedDescription;
			}
		}

		// Token: 0x06000121 RID: 289 RVA: 0x00010E40 File Offset: 0x0000F040
		public static void AdjustFlySpeed()
		{
			Settings.flySpeedIndex = (Settings.flySpeedIndex + 1) % 5;
			int num = Settings.flySpeedIndex;
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple;
			switch (num)
			{
			case 0:
				valueTuple = new ValueTuple<float, string>(12f, "Medium");
				break;
			case 1:
				valueTuple = new ValueTuple<float, string>(16f, "Fast");
				break;
			case 2:
				valueTuple = new ValueTuple<float, string>(20f, "Very Fast");
				break;
			case 3:
				valueTuple = new ValueTuple<float, string>(4f, "Very Slow");
				break;
			case 4:
				valueTuple = new ValueTuple<float, string>(8f, "Slow");
				break;
			default:
				valueTuple = new ValueTuple<float, string>(10f, "Unknown");
				break;
			}
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple2 = valueTuple;
			float item = valueTuple2.Item1;
			string item2 = valueTuple2.Item2;
			Settings.FlySpeed = item;
			Settings.FlySpeedDescription = item2;
			bool flag = Settings.adjustFlySpeedButton != null;
			if (flag)
			{
				Settings.adjustFlySpeedButton.buttonText = "Flight Speed : " + Settings.FlySpeedDescription;
			}
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00010F3C File Offset: 0x0000F13C
		public static void AdjustFOV()
		{
			Settings.FOVIndex = (Settings.FOVIndex + 1) % 5;
			int fovindex = Settings.FOVIndex;
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple;
			switch (fovindex)
			{
			case 0:
				valueTuple = new ValueTuple<float, string>(100f, "100");
				break;
			case 1:
				valueTuple = new ValueTuple<float, string>(110f, "110");
				break;
			case 2:
				valueTuple = new ValueTuple<float, string>(120f, "120");
				break;
			case 3:
				valueTuple = new ValueTuple<float, string>(80f, "80");
				break;
			case 4:
				valueTuple = new ValueTuple<float, string>(90f, "90");
				break;
			default:
				valueTuple = new ValueTuple<float, string>(10f, "Unknown");
				break;
			}
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple2 = valueTuple;
			float item = valueTuple2.Item1;
			string item2 = valueTuple2.Item2;
			Settings.FOV = item;
			Settings.FOVDescription = item2;
			bool flag = Settings.adjustFOVButton != null;
			if (flag)
			{
				Settings.adjustFOVButton.buttonText = "FPC FOV : " + Settings.FOVDescription;
			}
		}

		// Token: 0x06000123 RID: 291 RVA: 0x00011038 File Offset: 0x0000F238
		public static void AdjustWallWalkStrength()
		{
			Settings.WallWalkStrengthIndex = (Settings.WallWalkStrengthIndex + 1) % 3;
			int wallWalkStrengthIndex = Settings.WallWalkStrengthIndex;
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple;
			switch (wallWalkStrengthIndex)
			{
			case 0:
				valueTuple = new ValueTuple<float, string>(-7.5f, "Medium");
				break;
			case 1:
				valueTuple = new ValueTuple<float, string>(-12.5f, "Strong");
				break;
			case 2:
				valueTuple = new ValueTuple<float, string>(-3f, "Weak");
				break;
			default:
				valueTuple = new ValueTuple<float, string>(10f, "Unknown");
				break;
			}
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple2 = valueTuple;
			float item = valueTuple2.Item1;
			string item2 = valueTuple2.Item2;
			Settings.WallWalkStrength = item;
			Settings.WalkWalkStrengthDescription = item2;
			bool flag = Settings.adjustWalkWalkStrengthButton != null;
			if (flag)
			{
				Settings.adjustWalkWalkStrengthButton.buttonText = "Wall Walk Strength : " + Settings.WalkWalkStrengthDescription;
			}
		}

		// Token: 0x06000124 RID: 292 RVA: 0x00011108 File Offset: 0x0000F308
		public static void AdjustArmLength()
		{
			Settings.ArmLengthIndex = (Settings.ArmLengthIndex + 1) % 3;
			int armLengthIndex = Settings.ArmLengthIndex;
			if (!true)
			{
			}
			ValueTuple<Vector3, string> valueTuple;
			switch (armLengthIndex)
			{
			case 0:
				valueTuple = new ValueTuple<Vector3, string>(new Vector3(1.2f, 1.2f, 1.2f), "Slightly Long");
				break;
			case 1:
				valueTuple = new ValueTuple<Vector3, string>(new Vector3(1.3f, 1.3f, 1.3f), "Long");
				break;
			case 2:
				valueTuple = new ValueTuple<Vector3, string>(new Vector3(1.5f, 1.5f, 1.5f), "Very Long");
				break;
			default:
				valueTuple = new ValueTuple<Vector3, string>(new Vector3(1f, 1f, 1f), "Unknown");
				break;
			}
			if (!true)
			{
			}
			ValueTuple<Vector3, string> valueTuple2 = valueTuple;
			Vector3 item = valueTuple2.Item1;
			string item2 = valueTuple2.Item2;
			Settings.ArmLength = item;
			Settings.ArmLengthDescription = item2;
			bool flag = Settings.adjustArmLengthButton != null;
			if (flag)
			{
				Settings.adjustArmLengthButton.buttonText = "Long Arms Length : " + Settings.ArmLengthDescription;
			}
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00011214 File Offset: 0x0000F414
		public static void CyclePlatformType()
		{
			string[] array = new string[]
			{
				"Normal",
				"Sticky",
				"Invisible",
				"Frozone"
			};
			Settings.PlatformTypeIndex = (Settings.PlatformTypeIndex + 1) % array.Length;
			Settings.PlatformType = array[Settings.PlatformTypeIndex];
			bool flag = Settings.cyclePlatformTypeButton != null;
			if (flag)
			{
				Settings.cyclePlatformTypeButton.buttonText = "Platform Type : " + Settings.PlatformType;
			}
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00011290 File Offset: 0x0000F490
		public static void AdjustProjectileSpeed()
		{
			Settings.ProjectileSpeedIndex = (Settings.ProjectileSpeedIndex + 1) % 6;
			int projectileSpeedIndex = Settings.ProjectileSpeedIndex;
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple;
			switch (projectileSpeedIndex)
			{
			case 0:
				valueTuple = new ValueTuple<float, string>(20f, "Faster");
				break;
			case 1:
				valueTuple = new ValueTuple<float, string>(25f, "Extreme");
				break;
			case 2:
				valueTuple = new ValueTuple<float, string>(0f, "None");
				break;
			case 3:
				valueTuple = new ValueTuple<float, string>(5f, "Slow");
				break;
			case 4:
				valueTuple = new ValueTuple<float, string>(10f, "Medium");
				break;
			case 5:
				valueTuple = new ValueTuple<float, string>(15f, "Fast");
				break;
			default:
				valueTuple = new ValueTuple<float, string>(10f, "Unknown");
				break;
			}
			if (!true)
			{
			}
			ValueTuple<float, string> valueTuple2 = valueTuple;
			float item = valueTuple2.Item1;
			string item2 = valueTuple2.Item2;
			Settings.ProjectileSpeed = item;
			Settings.ProjectileSpeedDescription = item2;
			bool flag = Settings.adjustProjectileSpeedButton != null;
			if (flag)
			{
				Settings.adjustProjectileSpeedButton.buttonText = "Projectile Speed : " + Settings.ProjectileSpeedDescription;
			}
		}

		// Token: 0x040001AE RID: 430
		public static bool useGripForSpeedBoost = false;

		// Token: 0x040001AF RID: 431
		public static bool noclipFly = false;

		// Token: 0x040001B0 RID: 432
		public static ButtonHandler.Button themeChangerButton;

		// Token: 0x040001B1 RID: 433
		public static string[] ThemeDescriptions = new string[]
		{
			"Purple Lerp",
			"Rainbow",
			"Blue",
			"Gray",
			"Purple",
			"Green",
			"Red",
			"Orange",
			"Yellow",
			"Magenta",
			"Purple",
			"Red Lerp",
			"Blue Lerp",
			"Green Lerp",
			"Orange Lerp",
			"Yellow Lerp",
			"Magenta Lerp"
		};

		// Token: 0x040001B2 RID: 434
		public static string ThemeDescription = Settings.ThemeDescriptions[0];

		// Token: 0x040001B3 RID: 435
		public static int tracerPositionIndex = 0;

		// Token: 0x040001B4 RID: 436
		public static string TracerPosition = "Right Hand";

		// Token: 0x040001B5 RID: 437
		public static ButtonHandler.Button tracerPositionButton;

		// Token: 0x040001B6 RID: 438
		public static float SpeedboostSpeed = 10f;

		// Token: 0x040001B7 RID: 439
		public static float SpeedboostMultiplier = 2f;

		// Token: 0x040001B8 RID: 440
		public static string SpeedDescription = "Medium";

		// Token: 0x040001B9 RID: 441
		private static int currentSpeedIndex = 0;

		// Token: 0x040001BA RID: 442
		public static ButtonHandler.Button adjustSpeedBoostButton;

		// Token: 0x040001BB RID: 443
		public static float FlySpeed = 10f;

		// Token: 0x040001BC RID: 444
		public static string FlySpeedDescription = "Medium";

		// Token: 0x040001BD RID: 445
		private static int flySpeedIndex = 0;

		// Token: 0x040001BE RID: 446
		public static ButtonHandler.Button adjustFlySpeedButton;

		// Token: 0x040001BF RID: 447
		public static float FOV = 100f;

		// Token: 0x040001C0 RID: 448
		public static string FOVDescription = "100";

		// Token: 0x040001C1 RID: 449
		private static int FOVIndex = 0;

		// Token: 0x040001C2 RID: 450
		public static ButtonHandler.Button adjustFOVButton;

		// Token: 0x040001C3 RID: 451
		public static float WallWalkStrength = -7.5f;

		// Token: 0x040001C4 RID: 452
		public static string WalkWalkStrengthDescription = "Medium";

		// Token: 0x040001C5 RID: 453
		private static int WallWalkStrengthIndex = 0;

		// Token: 0x040001C6 RID: 454
		public static ButtonHandler.Button adjustWalkWalkStrengthButton;

		// Token: 0x040001C7 RID: 455
		public static Vector3 ArmLength = new Vector3(1.2f, 1.2f, 1.2f);

		// Token: 0x040001C8 RID: 456
		public static string ArmLengthDescription = "Off";

		// Token: 0x040001C9 RID: 457
		private static int ArmLengthIndex = 0;

		// Token: 0x040001CA RID: 458
		public static ButtonHandler.Button adjustArmLengthButton;

		// Token: 0x040001CB RID: 459
		public static int PlatformTypeIndex = 0;

		// Token: 0x040001CC RID: 460
		public static string PlatformType = "Normal";

		// Token: 0x040001CD RID: 461
		public static ButtonHandler.Button cyclePlatformTypeButton;

		// Token: 0x040001CE RID: 462
		public static float ProjectileSpeed = 20f;

		// Token: 0x040001CF RID: 463
		public static string ProjectileSpeedDescription = "Fast";

		// Token: 0x040001D0 RID: 464
		private static int ProjectileSpeedIndex = 0;

		// Token: 0x040001D1 RID: 465
		public static ButtonHandler.Button adjustProjectileSpeedButton;
	}
}
