﻿using System;
using System.Runtime.CompilerServices;
using NXO.Utilities;
using Photon.Pun;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x02000023 RID: 35
	public class Safety : MonoBehaviourPunCallbacks
	{
		// Token: 0x0600010A RID: 266 RVA: 0x00010650 File Offset: 0x0000E850
		public static void AntiReport(bool autoQueue, bool reconnect)
		{
			foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
			{
				bool flag = gorillaPlayerScoreboardLine.linePlayer != NetworkSystem.Instance.LocalPlayer || gorillaPlayerScoreboardLine.reportButton == null;
				if (!flag)
				{
					Transform transform = gorillaPlayerScoreboardLine.reportButton.gameObject.transform;
					float num = 0.55f;
					foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
					{
						bool flag2 = vrrig == null || vrrig == Variables.taggerInstance.offlineVRRig;
						if (!flag2)
						{
							bool flag3 = Vector3.Distance(vrrig.rightHandTransform.position, transform.position) < num || Vector3.Distance(vrrig.leftHandTransform.position, transform.position) < num;
							if (flag3)
							{
								PhotonNetwork.Disconnect();
								NotificationLib.SendNotification("<color=blue>Anti-Report</color> : " + vrrig.Creator.NickName + " Attempted to Report You!");
								if (autoQueue)
								{
									Room.JoinRandomPublic();
								}
								if (reconnect)
								{
									Room.Reconnect();
								}
								return;
							}
						}
					}
				}
			}
		}

		// Token: 0x0600010B RID: 267 RVA: 0x000107FC File Offset: 0x0000E9FC
		public static void RPCShield()
		{
			bool flag = Time.time - Safety.rpcTime < 0.25f;
			if (!flag)
			{
				Safety.rpcTime = Time.time;
				bool flag2 = !PhotonNetwork.InRoom;
				if (!flag2)
				{
					GorillaNot.instance.rpcErrorMax = int.MaxValue;
					GorillaNot.instance.rpcCallLimit = int.MaxValue;
					GorillaNot.instance.logErrorMax = int.MaxValue;
					PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
					PhotonNetwork.QuickResends = int.MaxValue;
					PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
					PhotonNetwork.SendAllOutgoingCommands();
					GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
				}
			}
		}

		// Token: 0x0600010C RID: 268 RVA: 0x000108B4 File Offset: 0x0000EAB4
		public static void AntiModerator()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = !vrrig.isOfflineVRRig && vrrig.concatStringOfCosmeticsAllowed.Contains("LBAAK");
				if (flag)
				{
					PhotonNetwork.Disconnect();
					NotificationLib.SendNotification("<color=blue>Anti Moderator</color> : Disconnected Due To Detected Moderator: " + vrrig.Creator.NickName);
					Room.JoinRandomPublic();
					break;
				}
			}
		}

		// Token: 0x0600010D RID: 269 RVA: 0x00010954 File Offset: 0x0000EB54
		public static void FakeQuestMenu()
		{
			bool rightControllerPrimaryButton = Variables.pollerInstance.rightControllerPrimaryButton;
			bool flag = !Safety.wasButtonPressed && rightControllerPrimaryButton;
			if (flag)
			{
				Safety.isOn = !Safety.isOn;
			}
			Safety.wasButtonPressed = rightControllerPrimaryButton;
			bool flag2 = Safety.isOn;
			if (flag2)
			{
				Variables.playerInstance.inOverlay = true;
			}
			else
			{
				Variables.playerInstance.inOverlay = false;
			}
		}

		// Token: 0x0600010E RID: 270 RVA: 0x000109B8 File Offset: 0x0000EBB8
		public static void FakeLag()
		{
			bool rightControllerPrimaryButton = Variables.pollerInstance.rightControllerPrimaryButton;
			bool flag = !Safety.wasButtonPressed && rightControllerPrimaryButton;
			if (flag)
			{
				Safety.isOn = !Safety.isOn;
				bool flag2 = Safety.isOn;
				if (flag2)
				{
					Safety.lagcooldownduration = Random.Range(0.1f, 0.4f);
				}
			}
			Safety.wasButtonPressed = rightControllerPrimaryButton;
			bool flag3 = Safety.isOn;
			if (flag3)
			{
				bool flag4 = Time.time > Safety.lagcooldown;
				if (flag4)
				{
					Safety.lagcooldown = Time.time + Safety.lagcooldownduration;
					Variables.taggerInstance.offlineVRRig.enabled = !Variables.taggerInstance.offlineVRRig.enabled;
				}
			}
			else
			{
				Variables.taggerInstance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x0600010F RID: 271 RVA: 0x00010A79 File Offset: 0x0000EC79
		public static void NoFingerMovement()
		{
			Variables.pollerInstance.leftControllerGripFloat = 0f;
			Variables.pollerInstance.leftControllerIndexFloat = 0f;
			Variables.pollerInstance.rightControllerGripFloat = 0f;
			Variables.pollerInstance.rightControllerIndexFloat = 0f;
		}

		// Token: 0x06000110 RID: 272 RVA: 0x00010AB8 File Offset: 0x0000ECB8
		[NullableContext(1)]
		public override void OnJoinRoomFailed(short returnCode, string message)
		{
			bool flag = returnCode == 32765;
			if (flag)
			{
				Debug.LogWarning("OnJoinRoomFailed : Failed to join room '" + Room.roomCode + "'. Reason: Is Full.");
				NotificationLib.SendNotification("<color=red>Error</color> : Failed to join room '" + Room.roomCode + "'. Reason: Is Full.");
			}
			else
			{
				Debug.LogWarning(string.Concat(new string[]
				{
					"OnJoinRoomFailed: Failed to join room '",
					Room.roomCode,
					"'. Reason: ",
					message,
					"."
				}));
				NotificationLib.SendNotification(string.Concat(new string[]
				{
					"<color=red>Error</color>: Failed to join room '",
					Room.roomCode,
					"'. Reason: ",
					message,
					"."
				}));
			}
		}

		// Token: 0x040001A9 RID: 425
		private static bool isOn = false;

		// Token: 0x040001AA RID: 426
		private static bool wasButtonPressed = false;

		// Token: 0x040001AB RID: 427
		private static float lagcooldown = 0f;

		// Token: 0x040001AC RID: 428
		private static float lagcooldownduration = 0.5f;

		// Token: 0x040001AD RID: 429
		private static float rpcTime = 0f;
	}
}
