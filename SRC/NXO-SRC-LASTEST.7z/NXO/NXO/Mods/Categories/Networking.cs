﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using ExitGames.Client.Photon;
using NXO.Menu;
using NXO.Utilities;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x0200001E RID: 30
	public class Networking
	{
		// Token: 0x02000056 RID: 86
		[NullableContext(1)]
		[Nullable(0)]
		public static class NetworkedBlocks
		{
			// Token: 0x06000360 RID: 864 RVA: 0x0001B518 File Offset: 0x00019718
			public static void NetworkedBlocksTest(bool setActive, Vector3 blockSize)
			{
				if (setActive)
				{
					bool rightGrab = Variables.pollerInstance.rightGrab;
					if (rightGrab)
					{
						bool flag = !Networking.NetworkedBlocks.hasSpawnedBlock;
						if (flag)
						{
							Networking.NetworkedBlocks.hasSpawnedBlock = true;
							Networking.NetworkedBlocks.currentBlock = GameObject.CreatePrimitive(Networking.NetworkedBlocks.blockShapes[Networking.NetworkedBlocks.currentBlockShape]);
							Networking.NetworkedBlocks.currentBlock.name = "Wall";
							Networking.NetworkedBlocks.currentBlock.transform.localScale = blockSize;
							Renderer component = Networking.NetworkedBlocks.currentBlock.GetComponent<Renderer>();
							bool flag2 = component != null;
							if (flag2)
							{
								component.material = ColorLib.ThemeArraya[ColorLib.CurrentTheme];
							}
							Collider component2 = Networking.NetworkedBlocks.currentBlock.GetComponent<Collider>();
							bool flag3 = component2 != null;
							if (flag3)
							{
								component2.enabled = false;
							}
							Networking.NetworkedBlocks.NetworkTestblocks.Add(Networking.NetworkedBlocks.currentBlock);
							object[] array = new object[]
							{
								blockSize,
								Variables.playerInstance.rightControllerTransform.position,
								Variables.playerInstance.rightControllerTransform.rotation,
								PhotonNetwork.LocalPlayer.ActorNumber
							};
							bool inRoom = PhotonNetwork.InRoom;
							if (inRoom)
							{
								PhotonNetwork.RaiseEvent(33, array, new RaiseEventOptions
								{
									Receivers = 1
								}, SendOptions.SendReliable);
							}
						}
						bool flag4 = Networking.NetworkedBlocks.currentBlock != null;
						if (flag4)
						{
							Networking.NetworkedBlocks.currentBlock.transform.position = Variables.playerInstance.rightControllerTransform.position;
							Networking.NetworkedBlocks.currentBlock.transform.rotation = Variables.playerInstance.rightControllerTransform.rotation;
						}
					}
					else
					{
						bool flag5 = Networking.NetworkedBlocks.currentBlock != null;
						if (flag5)
						{
							GameObject wallToFinalize = Networking.NetworkedBlocks.currentBlock;
							Task.Delay(3000).ContinueWith(delegate(Task _)
							{
								bool flag7 = wallToFinalize != null;
								if (flag7)
								{
									Collider component3 = wallToFinalize.GetComponent<Collider>();
									bool flag8 = component3 != null;
									if (flag8)
									{
										component3.enabled = true;
									}
								}
							});
							Networking.NetworkedBlocks.currentBlock = null;
						}
						Networking.NetworkedBlocks.hasSpawnedBlock = false;
					}
				}
				else
				{
					foreach (GameObject gameObject in Networking.NetworkedBlocks.NetworkTestblocks)
					{
						bool flag6 = gameObject != null;
						if (flag6)
						{
							Object.Destroy(gameObject);
						}
					}
					Networking.NetworkedBlocks.NetworkTestblocks.Clear();
					Networking.NetworkedBlocks.currentBlock = null;
					Networking.NetworkedBlocks.hasSpawnedBlock = false;
				}
			}

			// Token: 0x06000361 RID: 865 RVA: 0x0001B78C File Offset: 0x0001998C
			public static void OnPhotonEventReceived(EventData eventData)
			{
				bool flag = eventData.Code == 33;
				if (flag)
				{
					object[] array = (object[])eventData.CustomData;
					Vector3 localScale = (Vector3)array[0];
					Vector3 position = (Vector3)array[1];
					Quaternion rotation = (Quaternion)array[2];
					int num = (int)array[3];
					bool flag2 = num == PhotonNetwork.LocalPlayer.ActorNumber && Networking.NetworkedBlocks.currentBlock != null;
					if (flag2)
					{
						Networking.NetworkedBlocks.currentBlock.transform.position = position;
						Networking.NetworkedBlocks.currentBlock.transform.rotation = rotation;
					}
					else
					{
						GameObject newWall = GameObject.CreatePrimitive(Networking.NetworkedBlocks.blockShapes[Networking.NetworkedBlocks.currentBlockShape]);
						newWall.name = "NetworkedBlocks";
						newWall.transform.localScale = localScale;
						newWall.transform.position = position;
						newWall.transform.rotation = rotation;
						Renderer component = newWall.GetComponent<Renderer>();
						bool flag3 = component != null;
						if (flag3)
						{
							component.material.color = ColorLib.MaterialToColorConverter(ColorLib.ThemeArraya[ColorLib.CurrentTheme]);
						}
						Collider component2 = newWall.GetComponent<Collider>();
						bool flag4 = component2 != null;
						if (flag4)
						{
							component2.enabled = false;
							Task.Delay(3000).ContinueWith(delegate(Task _)
							{
								bool flag5 = newWall != null;
								if (flag5)
								{
									Collider component3 = newWall.GetComponent<Collider>();
									bool flag6 = component3 != null;
									if (flag6)
									{
										component3.enabled = true;
									}
								}
							});
						}
						Networking.NetworkedBlocks.NetworkTestblocks.Add(newWall);
					}
				}
			}

			// Token: 0x06000362 RID: 866 RVA: 0x0001B924 File Offset: 0x00019B24
			public static void CycleNetworkedBlocksShape()
			{
				Networking.NetworkedBlocks.currentBlockShape = (Networking.NetworkedBlocks.currentBlockShape + 1) % Networking.NetworkedBlocks.blockShapes.Count;
				bool flag = Networking.NetworkedBlocks.cycleNetworkedBlocksShapeButton != null;
				if (flag)
				{
					Networking.NetworkedBlocks.cycleNetworkedBlocksShapeButton.buttonText = "Block Shape : " + Networking.NetworkedBlocks.blockshapeNames[Networking.NetworkedBlocks.currentBlockShape];
				}
				Debug.Log("Projectile changed to: " + Networking.NetworkedBlocks.blockshapeNames[Networking.NetworkedBlocks.currentBlockShape]);
			}

			// Token: 0x06000363 RID: 867 RVA: 0x0001B99C File Offset: 0x00019B9C
			// Note: this type is marked as 'beforefieldinit'.
			static NetworkedBlocks()
			{
				List<PrimitiveType> list = new List<PrimitiveType>();
				list.Add(3);
				list.Add(0);
				list.Add(2);
				list.Add(1);
				list.Add(4);
				Networking.NetworkedBlocks.blockShapes = list;
				Networking.NetworkedBlocks.currentBlockShape = 0;
				List<string> list2 = new List<string>();
				list2.Add("Cube");
				list2.Add("Sphere");
				list2.Add("Cylinder");
				list2.Add("Capsule");
				list2.Add("Plane");
				Networking.NetworkedBlocks.blockshapeNames = list2;
			}

			// Token: 0x0400025D RID: 605
			public const byte MetworkedBlockTestEventCode = 33;

			// Token: 0x0400025E RID: 606
			private static GameObject currentBlock;

			// Token: 0x0400025F RID: 607
			private static bool hasSpawnedBlock;

			// Token: 0x04000260 RID: 608
			private static List<GameObject> NetworkTestblocks = new List<GameObject>();

			// Token: 0x04000261 RID: 609
			public static List<PrimitiveType> blockShapes;

			// Token: 0x04000262 RID: 610
			public static int currentBlockShape;

			// Token: 0x04000263 RID: 611
			public static ButtonHandler.Button cycleNetworkedBlocksShapeButton;

			// Token: 0x04000264 RID: 612
			public static List<string> blockshapeNames;
		}

		// Token: 0x02000057 RID: 87
		public static class NetworkedGun
		{
		}

		// Token: 0x02000058 RID: 88
		[NullableContext(1)]
		[Nullable(0)]
		public static class NetworkedPenis
		{
			// Token: 0x06000364 RID: 868 RVA: 0x0001BA34 File Offset: 0x00019C34
			public static void DickMod(bool setActive)
			{
				if (setActive)
				{
					bool flag = Networking.NetworkedPenis.full == null;
					if (flag)
					{
						Networking.NetworkedPenis.full = GameObject.CreatePrimitive(3);
						Networking.NetworkedPenis.full.transform.localScale = new Vector3(1f, 1f, 1f);
						Object.Destroy(Networking.NetworkedPenis.full.GetComponent<Rigidbody>());
						Object.Destroy(Networking.NetworkedPenis.full.GetComponent<BoxCollider>());
						Object.Destroy(Networking.NetworkedPenis.full.GetComponent<Renderer>());
						Networking.NetworkedPenis.full.name = "Dick";
						Material material = Variables.taggerInstance.offlineVRRig.mainSkin.material;
						Networking.NetworkedPenis.ball1 = GameObject.CreatePrimitive(0);
						Networking.NetworkedPenis.ball1.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
						Networking.NetworkedPenis.ball1.transform.parent = Networking.NetworkedPenis.full.transform;
						Networking.NetworkedPenis.ball1.transform.localPosition = new Vector3(0.06f, -0.2909f, 0.1309f);
						Object.Destroy(Networking.NetworkedPenis.ball1.GetComponent<Collider>());
						Networking.NetworkedPenis.ball1.GetComponent<Renderer>().material = material;
						Networking.NetworkedPenis.ball2 = GameObject.CreatePrimitive(0);
						Networking.NetworkedPenis.ball2.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
						Networking.NetworkedPenis.ball2.transform.parent = Networking.NetworkedPenis.full.transform;
						Networking.NetworkedPenis.ball2.transform.localPosition = new Vector3(-0.0725f, -0.2764f, 0.1309f);
						Object.Destroy(Networking.NetworkedPenis.ball2.GetComponent<Collider>());
						Networking.NetworkedPenis.ball2.GetComponent<Renderer>().material = material;
						Networking.NetworkedPenis.shaft = GameObject.CreatePrimitive(1);
						Networking.NetworkedPenis.shaft.transform.localScale = new Vector3(0.2f, 0.5f, 0.2f);
						Networking.NetworkedPenis.shaft.transform.parent = Networking.NetworkedPenis.full.transform;
						Networking.NetworkedPenis.shaft.transform.localPosition = new Vector3(0f, -0.2782f, 0.4109f);
						Networking.NetworkedPenis.shaft.transform.rotation = Quaternion.Euler(new Vector3(90f, 0f, 0f));
						Object.Destroy(Networking.NetworkedPenis.shaft.GetComponent<CapsuleCollider>());
						Networking.NetworkedPenis.shaft.GetComponent<Renderer>().material = material;
					}
					Networking.NetworkedPenis.full.transform.position = Variables.taggerInstance.offlineVRRig.transform.position;
					Networking.NetworkedPenis.full.transform.rotation = Variables.taggerInstance.offlineVRRig.transform.rotation;
					object[] array = new object[]
					{
						Networking.NetworkedPenis.full.transform.position,
						Networking.NetworkedPenis.full.transform.rotation,
						PhotonNetwork.LocalPlayer.ActorNumber
					};
					bool inRoom = PhotonNetwork.InRoom;
					if (inRoom)
					{
						PhotonNetwork.RaiseEvent(11, array, new RaiseEventOptions
						{
							Receivers = 1
						}, SendOptions.SendReliable);
					}
				}
				else
				{
					Object.Destroy(Networking.NetworkedPenis.ball1);
					Object.Destroy(Networking.NetworkedPenis.ball2);
					Object.Destroy(Networking.NetworkedPenis.shaft);
					Object.Destroy(Networking.NetworkedPenis.full);
				}
			}

			// Token: 0x06000365 RID: 869 RVA: 0x0001BDA0 File Offset: 0x00019FA0
			private static void LogToFile(string logMessage)
			{
				string text = Directory.GetCurrentDirectory() + "/PhotonEventLog.txt";
				using (StreamWriter streamWriter = new StreamWriter(text, true))
				{
					streamWriter.WriteLine(logMessage);
				}
			}

			// Token: 0x06000366 RID: 870 RVA: 0x0001BDF0 File Offset: 0x00019FF0
			public static void OnPhotonEventReceived(EventData eventData)
			{
				bool flag = eventData.Code == 11;
				if (flag)
				{
					object[] array = (object[])eventData.CustomData;
					Vector3 position = (Vector3)array[0];
					Quaternion rotation = (Quaternion)array[1];
					int num = (int)array[2];
					bool flag2 = num == PhotonNetwork.LocalPlayer.ActorNumber;
					if (flag2)
					{
						return;
					}
					GameObject gameObject;
					bool flag3 = Networking.NetworkedPenis.networkedPenisesBySender.TryGetValue(num, ref gameObject);
					if (flag3)
					{
						gameObject.transform.position = position;
						gameObject.transform.rotation = rotation;
						return;
					}
					GameObject gameObject2 = new GameObject(string.Format("NetworkedDick_{0}", num));
					GameObject gameObject3 = GameObject.CreatePrimitive(0);
					gameObject3.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
					gameObject3.transform.parent = gameObject2.transform;
					gameObject3.transform.localPosition = new Vector3(0.06f, -0.2909f, 0.1309f);
					Object.Destroy(gameObject3.GetComponent<Collider>());
					GameObject gameObject4 = GameObject.CreatePrimitive(0);
					gameObject4.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
					gameObject4.transform.parent = gameObject2.transform;
					gameObject4.transform.localPosition = new Vector3(-0.0725f, -0.2764f, 0.1309f);
					Object.Destroy(gameObject4.GetComponent<Collider>());
					GameObject gameObject5 = GameObject.CreatePrimitive(1);
					gameObject5.transform.localScale = new Vector3(0.2f, 0.5f, 0.2f);
					gameObject5.transform.parent = gameObject2.transform;
					gameObject5.transform.localPosition = new Vector3(0f, -0.2782f, 0.4109f);
					gameObject5.transform.rotation = Quaternion.Euler(new Vector3(90f, 0f, 0f));
					Object.Destroy(gameObject5.GetComponent<CapsuleCollider>());
					gameObject2.transform.position = position;
					gameObject2.transform.rotation = rotation;
					Networking.NetworkedPenis.networkedPenisesBySender[num] = gameObject2;
				}
				bool flag4 = eventData.Code != 200;
				if (flag4)
				{
					string text = string.Format("Received Photon Event - Code: {0}", eventData.Code);
					bool flag5 = eventData.CustomData != null;
					if (flag5)
					{
						object[] array2 = (object[])eventData.CustomData;
						text += "\nParameters:";
						for (int i = 0; i < array2.Length; i++)
						{
							GameObject gameObject6 = array2[i] as GameObject;
							bool flag6 = gameObject6 != null;
							if (flag6)
							{
								text += string.Format("\n\tParam {0}: GameObject - Name: {1}, Position: {2}", i, gameObject6.name, gameObject6.transform.position);
							}
							else
							{
								Transform transform = array2[i] as Transform;
								bool flag7 = transform != null;
								if (flag7)
								{
									text += string.Format("\n\tParam {0}: Transform - Name: {1}, Position: {2}", i, transform.name, transform.position);
								}
								else
								{
									object obj = array2[i];
									Vector3 vector;
									bool flag8;
									if (obj is Vector3)
									{
										vector = (Vector3)obj;
										flag8 = true;
									}
									else
									{
										flag8 = false;
									}
									bool flag9 = flag8;
									if (flag9)
									{
										text += string.Format("\n\tParam {0}: Vector3 - {1}, {2}, {3}", new object[]
										{
											i,
											vector.x,
											vector.y,
											vector.z
										});
									}
									else
									{
										string text2 = array2[i] as string;
										bool flag10 = text2 != null;
										if (flag10)
										{
											text += string.Format("\n\tParam {0}: String - {1}", i, text2);
										}
										else
										{
											obj = array2[i];
											int num2;
											bool flag11;
											if (obj is int)
											{
												num2 = (int)obj;
												flag11 = true;
											}
											else
											{
												flag11 = false;
											}
											bool flag12 = flag11;
											if (flag12)
											{
												text += string.Format("\n\tParam {0}: Int - {1}", i, num2);
											}
											else
											{
												text += string.Format("\n\tParam {0}: Unknown Type - {1}", i, array2[i]);
											}
										}
									}
								}
							}
						}
					}
					else
					{
						text += "\nNo custom data in this event.";
					}
					Networking.NetworkedPenis.LogToFile(text);
				}
			}

			// Token: 0x04000265 RID: 613
			public const byte NetworkedPenisEventCode = 11;

			// Token: 0x04000266 RID: 614
			private static List<GameObject> networkedPenises = new List<GameObject>();

			// Token: 0x04000267 RID: 615
			private static Dictionary<int, GameObject> networkedPenisesBySender = new Dictionary<int, GameObject>();

			// Token: 0x04000268 RID: 616
			public static GameObject ball1;

			// Token: 0x04000269 RID: 617
			public static GameObject ball2;

			// Token: 0x0400026A RID: 618
			public static GameObject shaft;

			// Token: 0x0400026B RID: 619
			public static GameObject full;
		}
	}
}
