﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion.Swimming;
using GorillaNetworking;
using NXO.Menu;
using NXO.Utilities;
using Photon.Pun;
using UnityEngine;

namespace NXO.Mods.Categories
{
	// Token: 0x0200001C RID: 28
	[NullableContext(1)]
	[Nullable(0)]
	public class Miscellaneous
	{
		// Token: 0x060000A8 RID: 168 RVA: 0x0000A8D8 File Offset: 0x00008AD8
		public static void OnDestroy()
		{
			Optimizations.DestroyAndNullify<GameObject>(ref Miscellaneous.rightPointer, 0f);
			Optimizations.DestroyAndNullify<GameObject>(ref Miscellaneous.leftPointer, 0f);
			Miscellaneous.DestroyAllDrawings();
			Optimizations.DestroyAndNullify<GameObject>(ref Miscellaneous.bomb, 0f);
			Optimizations.DestroyAndNullify<GameObject>(ref Networking.NetworkedPenis.ball1, 0f);
			Optimizations.DestroyAndNullify<GameObject>(ref Networking.NetworkedPenis.ball2, 0f);
			Optimizations.DestroyAndNullify<GameObject>(ref Networking.NetworkedPenis.shaft, 0f);
			Optimizations.DestroyAndNullify<GameObject>(ref Networking.NetworkedPenis.full, 0f);
			Miscellaneous.CleanupWebshooters();
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x0000A964 File Offset: 0x00008B64
		private static void DestroyAllDrawings()
		{
			foreach (GameObject gameObject in Miscellaneous.drawings)
			{
				bool flag = gameObject != null;
				if (flag)
				{
					Object.Destroy(gameObject);
				}
			}
			Miscellaneous.drawings.Clear();
		}

		// Token: 0x060000AA RID: 170 RVA: 0x0000A9D4 File Offset: 0x00008BD4
		private static void CleanupWebshooters()
		{
			Optimizations.DestroyAndNullify<GameObject>(ref Miscellaneous.rightaimer, 0f);
			Optimizations.DestroyAndNullify<GameObject>(ref Miscellaneous.leftaimer, 0f);
			Optimizations.DestroyAndNullify<LineRenderer>(ref Miscellaneous.lr, 0f);
			Optimizations.DestroyAndNullify<LineRenderer>(ref Miscellaneous.leftlr, 0f);
			Optimizations.DestroyAndNullify<SpringJoint>(ref Miscellaneous.joint, 0f);
			Optimizations.DestroyAndNullify<SpringJoint>(ref Miscellaneous.leftjoint, 0f);
			Miscellaneous.wackstart = false;
			Miscellaneous.cangrapple = true;
			Miscellaneous.canleftgrapple = true;
		}

		// Token: 0x060000AB RID: 171 RVA: 0x0000AA54 File Offset: 0x00008C54
		public static void SetName(string name)
		{
			GorillaComputer.instance.currentName = name;
			PhotonNetwork.LocalPlayer.NickName = name;
			GorillaComputer.instance.offlineVRRigNametagText.text = name;
			GorillaComputer.instance.savedName = name;
			PlayerPrefs.SetString("playerName", name);
			PlayerPrefs.Save();
		}

		// Token: 0x060000AC RID: 172 RVA: 0x0000AAB0 File Offset: 0x00008CB0
		public static void AttachCosmetic(bool setActive, string name)
		{
			GameObject gameObject = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/" + name);
			bool flag = gameObject != null;
			if (flag)
			{
				gameObject.SetActive(setActive);
			}
		}

		// Token: 0x060000AD RID: 173 RVA: 0x0000AAE4 File Offset: 0x00008CE4
		public static void PunchMod()
		{
			int num = 0;
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig == Variables.taggerInstance.offlineVRRig;
				if (!flag)
				{
					Vector3 position = Variables.taggerInstance.offlineVRRig.transform.position;
					Rigidbody component = Variables.playerInstance.GetComponent<Rigidbody>();
					Vector3 position2 = vrrig.rightHandTransform.position;
					Vector3 vector = position2 - Miscellaneous.lastRight[num];
					bool flag2 = Vector3.Distance(position2, position) < 0.25f;
					if (flag2)
					{
						Vector3 vector2 = Vector3.Normalize(vector) * 9f;
						vector2 += Vector3.up * 2f;
						component.AddForce(vector2, 2);
					}
					Miscellaneous.lastRight[num] = position2;
					Vector3 position3 = vrrig.leftHandTransform.position;
					Vector3 vector3 = position3 - Miscellaneous.lastLeft[num];
					bool flag3 = Vector3.Distance(position3, position) < 0.25f;
					if (flag3)
					{
						Vector3 vector4 = Vector3.Normalize(vector3) * 9f;
						vector4 += Vector3.up * 2f;
						component.AddForce(vector4, 2);
					}
					Miscellaneous.lastLeft[num] = position3;
					num++;
				}
			}
		}

		// Token: 0x060000AE RID: 174 RVA: 0x0000AC88 File Offset: 0x00008E88
		public static void DrawMod(bool setActive)
		{
			if (setActive)
			{
				bool flag = Miscellaneous.rightPointer == null;
				if (flag)
				{
					Miscellaneous.rightPointer = GameObject.CreatePrimitive(0);
					Miscellaneous.rightPointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
					Object.Destroy(Miscellaneous.rightPointer.GetComponent<Rigidbody>());
					Object.Destroy(Miscellaneous.rightPointer.GetComponent<SphereCollider>());
				}
				bool flag2 = Miscellaneous.leftPointer == null;
				if (flag2)
				{
					Miscellaneous.leftPointer = GameObject.CreatePrimitive(0);
					Miscellaneous.leftPointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
					Object.Destroy(Miscellaneous.leftPointer.GetComponent<Rigidbody>());
					Object.Destroy(Miscellaneous.leftPointer.GetComponent<SphereCollider>());
				}
				Miscellaneous.rightPointer.transform.position = Variables.playerInstance.rightControllerTransform.position;
				Miscellaneous.leftPointer.transform.position = Variables.playerInstance.leftControllerTransform.position;
				Renderer component = Miscellaneous.rightPointer.GetComponent<Renderer>();
				Renderer component2 = Miscellaneous.leftPointer.GetComponent<Renderer>();
				bool flag3 = component != null;
				if (flag3)
				{
					component.material.color = Miscellaneous.drawColor;
				}
				bool flag4 = component2 != null;
				if (flag4)
				{
					component2.material.color = Miscellaneous.drawColor;
				}
				bool rightGrab = Variables.pollerInstance.rightGrab;
				if (rightGrab)
				{
					GameObject gameObject = GameObject.CreatePrimitive(0);
					gameObject.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
					gameObject.transform.position = Variables.playerInstance.rightControllerTransform.position;
					Renderer component3 = gameObject.GetComponent<Renderer>();
					bool flag5 = component3 != null;
					if (flag5)
					{
						component3.material.color = Miscellaneous.drawColor;
					}
					Object.Destroy(gameObject.GetComponent<Rigidbody>());
					Object.Destroy(gameObject.GetComponent<SphereCollider>());
					Miscellaneous.drawings.Add(gameObject);
				}
				bool leftGrab = Variables.pollerInstance.leftGrab;
				if (leftGrab)
				{
					GameObject gameObject2 = GameObject.CreatePrimitive(0);
					gameObject2.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
					gameObject2.transform.position = Variables.playerInstance.leftControllerTransform.position;
					Renderer component4 = gameObject2.GetComponent<Renderer>();
					bool flag6 = component4 != null;
					if (flag6)
					{
						component4.material.color = Miscellaneous.drawColor;
					}
					Object.Destroy(gameObject2.GetComponent<Rigidbody>());
					Object.Destroy(gameObject2.GetComponent<SphereCollider>());
					Miscellaneous.drawings.Add(gameObject2);
				}
				bool flag7 = Variables.pollerInstance.rightControllerPrimaryButton && !Miscellaneous.colorChangerCooldown;
				if (flag7)
				{
					Miscellaneous.currentColor = (Miscellaneous.currentColor + 1) % 13;
					int num = Miscellaneous.currentColor;
					if (!true)
					{
					}
					Color color;
					switch (num)
					{
					case 0:
						color = Color.white;
						break;
					case 1:
						color = Color.blue;
						break;
					case 2:
						color = Color.red;
						break;
					case 3:
						color = Color.green;
						break;
					case 4:
						color = new Color32(76, 0, 164, byte.MaxValue);
						break;
					case 5:
						color = Color.black;
						break;
					case 6:
						color = Color.cyan;
						break;
					case 7:
						color = new Color32(80, 80, 80, byte.MaxValue);
						break;
					case 8:
						color = Color.yellow;
						break;
					case 9:
						color = new Color32(byte.MaxValue, 0, byte.MaxValue, byte.MaxValue);
						break;
					case 10:
						color = new Color32(0, byte.MaxValue, byte.MaxValue, byte.MaxValue);
						break;
					case 11:
						color = new Color32(150, 75, 0, byte.MaxValue);
						break;
					case 12:
						color = new Color32(byte.MaxValue, 165, 0, byte.MaxValue);
						break;
					default:
						color = Color.white;
						break;
					}
					if (!true)
					{
					}
					Miscellaneous.drawColor = color;
					Miscellaneous.colorChangerCooldown = true;
				}
				else
				{
					bool flag8 = !Variables.pollerInstance.rightControllerPrimaryButton;
					if (flag8)
					{
						Miscellaneous.colorChangerCooldown = false;
					}
				}
			}
			else
			{
				Object.Destroy(Miscellaneous.rightPointer);
				Object.Destroy(Miscellaneous.leftPointer);
				Miscellaneous.DestroyAllDrawings();
			}
		}

		// Token: 0x060000AF RID: 175 RVA: 0x0000B11C File Offset: 0x0000931C
		public static void PlaceBomb(bool setActive)
		{
			if (setActive)
			{
				bool rightGrab = Variables.pollerInstance.rightGrab;
				if (rightGrab)
				{
					bool flag = Miscellaneous.bomb == null;
					if (flag)
					{
						Miscellaneous.bomb = GameObject.CreatePrimitive(3);
						Miscellaneous.bomb.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
						Renderer component = Miscellaneous.bomb.GetComponent<Renderer>();
						bool flag2 = component != null;
						if (flag2)
						{
							component.material.color = Color.red;
						}
						Object.Destroy(Miscellaneous.bomb.GetComponent<SphereCollider>());
					}
					Miscellaneous.bomb.transform.position = Variables.playerInstance.rightControllerTransform.position;
				}
				else
				{
					bool flag3 = Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
					if (flag3)
					{
						bool flag4 = Miscellaneous.bomb != null;
						if (flag4)
						{
							Variables.playerInstance.bodyCollider.attachedRigidbody.AddExplosionForce(50000f, Miscellaneous.bomb.transform.position, 5f);
							Object.Destroy(Miscellaneous.bomb);
						}
					}
				}
			}
			else
			{
				Object.Destroy(Miscellaneous.bomb);
			}
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x0000B258 File Offset: 0x00009458
		public static void Webshooters(bool setActive)
		{
			if (setActive)
			{
				bool flag = !Miscellaneous.wackstart;
				if (flag)
				{
					bool flag2 = Miscellaneous.lr == null;
					if (flag2)
					{
						GameObject gameObject = new GameObject("RightWebShooterLine");
						Miscellaneous.lr = gameObject.AddComponent<LineRenderer>();
						Miscellaneous.lr.material = new Material(Shader.Find("Sprites/Default"));
						Miscellaneous.lr.startColor = Color.white;
						Miscellaneous.lr.endColor = Color.white;
						Miscellaneous.lr.startWidth = 0.02f;
						Miscellaneous.lr.endWidth = 0.02f;
						Miscellaneous.lr.positionCount = 0;
						gameObject.transform.SetParent(Variables.playerInstance.transform);
					}
					bool flag3 = Miscellaneous.leftlr == null;
					if (flag3)
					{
						GameObject gameObject2 = new GameObject("LeftWebShooterLine");
						Miscellaneous.leftlr = gameObject2.AddComponent<LineRenderer>();
						Miscellaneous.leftlr.material = new Material(Shader.Find("Sprites/Default"));
						Miscellaneous.leftlr.startColor = Color.white;
						Miscellaneous.leftlr.endColor = Color.white;
						Miscellaneous.leftlr.startWidth = 0.02f;
						Miscellaneous.leftlr.endWidth = 0.02f;
						Miscellaneous.leftlr.positionCount = 0;
						gameObject2.transform.SetParent(Variables.playerInstance.transform);
					}
					Miscellaneous.wackstart = true;
				}
				Miscellaneous.HandleWebshooter(ref Miscellaneous.joint, ref Miscellaneous.lr, ref Miscellaneous.rightaimer, ref Miscellaneous.cangrapple, Variables.playerInstance.rightControllerTransform, Variables.pollerInstance.rightControllerIndexFloat, 2);
				Miscellaneous.HandleWebshooter(ref Miscellaneous.leftjoint, ref Miscellaneous.leftlr, ref Miscellaneous.leftaimer, ref Miscellaneous.canleftgrapple, Variables.playerInstance.leftControllerTransform, Variables.pollerInstance.leftControllerIndexFloat, 1);
			}
			else
			{
				Miscellaneous.CleanupWebshooters();
			}
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x0000B440 File Offset: 0x00009640
		private static void HandleWebshooter(ref SpringJoint joint, ref LineRenderer lineRenderer, ref GameObject aimer, ref bool canGrapple, Transform handTransform, float controllerIndexFloat, OVRInput.Controller controller)
		{
			RaycastHit raycastHit;
			bool flag = Physics.Raycast(handTransform.position, handTransform.forward, ref raycastHit, 100f);
			if (flag)
			{
				bool flag2 = aimer == null;
				if (flag2)
				{
					aimer = GameObject.CreatePrimitive(0);
					Object.Destroy(aimer.GetComponent<Rigidbody>());
					Object.Destroy(aimer.GetComponent<SphereCollider>());
					aimer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
					aimer.GetComponent<Renderer>().material.color = Color.green;
				}
				aimer.SetActive(true);
				aimer.transform.position = raycastHit.point;
			}
			else
			{
				bool flag3 = aimer != null;
				if (flag3)
				{
					aimer.SetActive(false);
				}
			}
			bool flag4 = controllerIndexFloat == 0f;
			if (flag4)
			{
				aimer.GetComponent<MeshRenderer>().enabled = true;
			}
			else
			{
				aimer.GetComponent<MeshRenderer>().enabled = false;
			}
			bool flag5 = controllerIndexFloat > 0.1f;
			if (flag5)
			{
				bool flag6 = canGrapple && Physics.Raycast(handTransform.position, handTransform.forward, ref raycastHit, 100f);
				if (flag6)
				{
					joint = Variables.playerInstance.gameObject.AddComponent<SpringJoint>();
					joint.autoConfigureConnectedAnchor = false;
					joint.connectedAnchor = raycastHit.point;
					float num = Vector3.Distance(Variables.playerInstance.transform.position, raycastHit.point);
					joint.maxDistance = num * 0.8f;
					joint.minDistance = num * 0.25f;
					joint.spring = 5000f;
					joint.damper = 4000f;
					joint.massScale = 6f;
					lineRenderer.positionCount = 2;
					lineRenderer.SetPosition(1, raycastHit.point);
					Variables.taggerInstance.offlineVRRig.PlayHandTapLocal(82, false, 1f);
					canGrapple = false;
				}
				bool flag7 = joint != null;
				if (flag7)
				{
					lineRenderer.positionCount = 2;
					lineRenderer.SetPosition(0, handTransform.position);
					lineRenderer.SetPosition(1, joint.connectedAnchor);
					bool flag8 = OVRInput.GetLocalControllerVelocity(controller).magnitude >= 2.5f;
					if (flag8)
					{
						Vector3 vector = (joint.connectedAnchor - Variables.playerInstance.transform.position).normalized * 3f;
						Variables.playerInstance.GetComponent<Rigidbody>().AddForce(vector, 2);
					}
				}
			}
			else
			{
				bool flag9 = joint != null;
				if (flag9)
				{
					Object.Destroy(joint);
					joint = null;
				}
				lineRenderer.positionCount = 0;
				canGrapple = true;
			}
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x0000B710 File Offset: 0x00009910
		public static void WaterBender()
		{
			bool flag = Time.time < Variables.rpcCooldown;
			if (!flag)
			{
				Variables.rpcCooldown = Time.time + Miscellaneous.splashrpcCooldown;
				Safety.RPCShield();
				bool flag2 = Variables.pollerInstance.rightGrab && Variables.pollerInstance.leftGrab;
				if (flag2)
				{
					Vector3 position = Variables.playerInstance.rightControllerTransform.position;
					Vector3 position2 = Variables.playerInstance.leftControllerTransform.position;
					Vector3 position3 = (position + position2) / 2f;
					float num = Vector3.Distance(position, position2);
					float size = Mathf.Clamp(num * 100f, 75f, 500f);
					Quaternion rotation = Quaternion.Lerp(Variables.playerInstance.rightControllerTransform.rotation, Variables.playerInstance.leftControllerTransform.rotation, 0.5f);
					Miscellaneous.PlaySplashEffect(position3, rotation, size);
				}
				else
				{
					bool rightGrab = Variables.pollerInstance.rightGrab;
					if (rightGrab)
					{
						Vector3 position4 = Variables.playerInstance.rightControllerTransform.position;
						Miscellaneous.PlaySplashEffect(position4, Variables.taggerInstance.offlineVRRig.transform.rotation, 125f);
					}
					bool leftGrab = Variables.pollerInstance.leftGrab;
					if (leftGrab)
					{
						Vector3 position5 = Variables.playerInstance.leftControllerTransform.position;
						Miscellaneous.PlaySplashEffect(position5, Variables.taggerInstance.offlineVRRig.transform.rotation, 125f);
					}
				}
				bool rightControllerPrimaryButton = Variables.pollerInstance.rightControllerPrimaryButton;
				if (rightControllerPrimaryButton)
				{
					Vector3 position6 = Variables.taggerInstance.offlineVRRig.headMesh.transform.position + new Vector3(0f, 0.5f, 0f);
					Quaternion rotation2 = Quaternion.Euler(90f, 0f, 0f);
					Miscellaneous.PlaySplashEffect(position6, rotation2, 125f);
				}
			}
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x0000B8F0 File Offset: 0x00009AF0
		public static void SplashSelf()
		{
			bool flag = Time.time < Variables.rpcCooldown;
			if (!flag)
			{
				Variables.rpcCooldown = Time.time + Miscellaneous.splashrpcCooldown;
				Safety.RPCShield();
				Vector3 position = Variables.taggerInstance.offlineVRRig.transform.position;
				Quaternion rotation = Variables.taggerInstance.offlineVRRig.transform.rotation;
				Miscellaneous.PlaySplashEffect(position, rotation, 125f);
			}
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x0000B960 File Offset: 0x00009B60
		public static void SplashGun()
		{
			bool gunGrips = GunLib.GunGrips;
			if (gunGrips)
			{
				GunLib.SetupRaycast();
				bool gunTriggers = GunLib.GunTriggers;
				if (gunTriggers)
				{
					Variables.taggerInstance.offlineVRRig.enabled = false;
					Variables.taggerInstance.offlineVRRig.transform.position = GunLib.raycastHit.point + new Vector3(0f, 1f, 0f);
					bool flag = Time.time < Variables.rpcCooldown;
					if (!flag)
					{
						Variables.rpcCooldown = Time.time + Miscellaneous.splashrpcCooldown;
						Safety.RPCShield();
						Vector3 point = GunLib.raycastHit.point;
						Quaternion rotation = GunLib.raycastHit.transform.rotation;
						Miscellaneous.PlaySplashEffect(point, rotation, 125f);
					}
				}
				else
				{
					Variables.taggerInstance.offlineVRRig.enabled = true;
				}
			}
			else
			{
				GunLib.SetGunVisibility(false);
			}
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x0000BA4C File Offset: 0x00009C4C
		public static void SplashAura()
		{
			bool flag = Time.time < Variables.rpcCooldown;
			if (!flag)
			{
				Variables.rpcCooldown = Time.time + Miscellaneous.splashrpcCooldown;
				Safety.RPCShield();
				bool flag2 = Variables.pollerInstance.rightControllerIndexFloat > 0f;
				if (flag2)
				{
					foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
					{
						Vector3 position = vrrig.transform.position;
						Quaternion rotation = vrrig.transform.rotation;
						Miscellaneous.PlaySplashEffect(position, rotation, 125f);
					}
				}
			}
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x0000BB10 File Offset: 0x00009D10
		public static void WaterBarrage()
		{
			bool flag = Time.time < Variables.rpcCooldown;
			if (!flag)
			{
				Variables.rpcCooldown = Time.time + Miscellaneous.splashrpcCooldown;
				Safety.RPCShield();
				bool flag2 = Variables.pollerInstance.rightControllerIndexFloat > 0f;
				if (flag2)
				{
					float num = 1.5f;
					float num2 = 1.6f;
					Vector3 vector = Random.insideUnitSphere.normalized * Random.Range(num, num2);
					Vector3 vector2 = Variables.taggerInstance.offlineVRRig.transform.position + vector;
					Vector3 vector3 = Variables.taggerInstance.offlineVRRig.transform.position - vector2;
					Quaternion rotation = Quaternion.LookRotation(vector3);
					Miscellaneous.PlaySplashEffect(vector2, rotation, 125f);
				}
			}
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x0000BBDC File Offset: 0x00009DDC
		public static void PlaySplashEffect(Vector3 position, Quaternion rotation, float size)
		{
			Variables.taggerInstance.myVRRig.GetView.RPC("RPC_PlaySplashEffect", 0, new object[]
			{
				position,
				rotation,
				size,
				size,
				true,
				true
			});
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x0000BC44 File Offset: 0x00009E44
		public static void FastSwim()
		{
			bool inWater = Variables.playerInstance.InWater;
			if (inWater)
			{
				Variables.playerInstance.gameObject.GetComponent<Rigidbody>().velocity *= 1.03f;
			}
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x0000BC88 File Offset: 0x00009E88
		public static void ModifyWater(bool makeSolid, bool makeTransparent)
		{
			string text;
			if (makeSolid)
			{
				text = "Default";
			}
			else if (makeTransparent)
			{
				text = "TransparentFX";
			}
			else
			{
				text = "Water";
			}
			int num = LayerMask.NameToLayer(text);
			bool flag = num == -1;
			if (flag)
			{
				Debug.LogError("Layer '" + text + "' does not exist!");
			}
			else
			{
				foreach (WaterVolume waterVolume in Object.FindObjectsOfType<WaterVolume>())
				{
					waterVolume.gameObject.layer = num;
				}
			}
		}

		// Token: 0x060000BA RID: 186 RVA: 0x0000BD18 File Offset: 0x00009F18
		public static void AirSwim(bool isActive)
		{
			GameObject gameObject = GameObject.Find("Environment Objects/LocalObjects_Prefab/ForestToBeach/ForestToBeach_Prefab_V4/CaveWaterVolume");
			bool flag = gameObject == null;
			if (flag)
			{
				Debug.LogError("Source water object not found!");
			}
			else if (isActive)
			{
				GameObject gameObject2 = GameObject.Find("WaterObj");
				bool flag2 = gameObject2 == null;
				if (flag2)
				{
					gameObject2 = Object.Instantiate<GameObject>(gameObject);
					gameObject2.name = "WaterObj";
					gameObject2.transform.localScale = new Vector3(10f, 10f, 10f);
				}
				gameObject2.transform.position = Variables.taggerInstance.headCollider.transform.position + new Vector3(0f, 3f, 0f);
				Variables.playerInstance.audioManager.UnsetMixerSnapshot(0.1f);
				gameObject2.SetActive(true);
			}
			else
			{
				GameObject gameObject3 = GameObject.Find("WaterObj");
				bool flag3 = gameObject3 != null;
				if (flag3)
				{
					Object.Destroy(gameObject3);
				}
			}
		}

		// Token: 0x04000165 RID: 357
		private static readonly Vector3[] lastRight = new Vector3[10];

		// Token: 0x04000166 RID: 358
		private static readonly Vector3[] lastLeft = new Vector3[10];

		// Token: 0x04000167 RID: 359
		private static GameObject rightPointer;

		// Token: 0x04000168 RID: 360
		private static GameObject leftPointer;

		// Token: 0x04000169 RID: 361
		private static readonly HashSet<GameObject> drawings = new HashSet<GameObject>();

		// Token: 0x0400016A RID: 362
		private static bool colorChangerCooldown = false;

		// Token: 0x0400016B RID: 363
		private static int currentColor = 0;

		// Token: 0x0400016C RID: 364
		private static Color drawColor = Color.white;

		// Token: 0x0400016D RID: 365
		private static GameObject bomb;

		// Token: 0x0400016E RID: 366
		private static GameObject rightaimer;

		// Token: 0x0400016F RID: 367
		private static GameObject leftaimer;

		// Token: 0x04000170 RID: 368
		private static LineRenderer lr;

		// Token: 0x04000171 RID: 369
		private static LineRenderer leftlr;

		// Token: 0x04000172 RID: 370
		private static SpringJoint joint;

		// Token: 0x04000173 RID: 371
		private static SpringJoint leftjoint;

		// Token: 0x04000174 RID: 372
		private static bool cangrapple = true;

		// Token: 0x04000175 RID: 373
		private static bool canleftgrapple = true;

		// Token: 0x04000176 RID: 374
		private static bool wackstart = false;

		// Token: 0x04000177 RID: 375
		private const float maxDistance = 100f;

		// Token: 0x04000178 RID: 376
		private const float Spring = 5000f;

		// Token: 0x04000179 RID: 377
		private const float Damper = 4000f;

		// Token: 0x0400017A RID: 378
		private const float MassScale = 6f;

		// Token: 0x0400017B RID: 379
		private const float pullspeed = 3f;

		// Token: 0x0400017C RID: 380
		private const float speedtopull = 2.5f;

		// Token: 0x0400017D RID: 381
		private static float splashrpcCooldown = 0.25f;
	}
}
