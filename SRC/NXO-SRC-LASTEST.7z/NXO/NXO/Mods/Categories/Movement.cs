﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using BepInEx;
using GorillaLocomotion;
using NXO.Utilities;
using UnityEngine;
using UnityEngine.InputSystem;
using Valve.VR;

namespace NXO.Mods.Categories
{
	// Token: 0x0200001D RID: 29
	[NullableContext(1)]
	[Nullable(0)]
	public class Movement
	{
		// Token: 0x060000BD RID: 189 RVA: 0x0000BE90 File Offset: 0x0000A090
		public static void TogglePlatforms()
		{
			string text = Settings.PlatformType.ToLower();
			string text2 = text;
			if (!(text2 == "normal"))
			{
				if (!(text2 == "sticky"))
				{
					if (!(text2 == "invisible"))
					{
						Debug.LogError("Unknown platform type: " + Settings.PlatformType);
					}
					else
					{
						PlatformLib.CreateOrDestroyPlatform(ref PlatformLib.leftPlatform, PlatformLib.PlatformInput(false), Variables.playerInstance.leftControllerTransform, true);
						PlatformLib.CreateOrDestroyPlatform(ref PlatformLib.rightPlatform, PlatformLib.PlatformInput(true), Variables.playerInstance.rightControllerTransform, true);
					}
				}
				else
				{
					PlatformLib.CreateOrDestroySides(ref PlatformLib.leftSideObjects, PlatformLib.PlatformInput(false), Variables.playerInstance.leftControllerTransform, false);
					PlatformLib.CreateOrDestroySides(ref PlatformLib.rightSideObjects, PlatformLib.PlatformInput(true), Variables.playerInstance.rightControllerTransform, false);
				}
			}
			else
			{
				PlatformLib.CreateOrDestroyPlatform(ref PlatformLib.leftPlatform, PlatformLib.PlatformInput(false), Variables.playerInstance.leftControllerTransform, false);
				PlatformLib.CreateOrDestroyPlatform(ref PlatformLib.rightPlatform, PlatformLib.PlatformInput(true), Variables.playerInstance.rightControllerTransform, false);
			}
		}

		// Token: 0x060000BE RID: 190 RVA: 0x0000BF9F File Offset: 0x0000A19F
		public static void Frozone()
		{
			PlatformLib.CreateOrDestroyFrozonePlatform(ref PlatformLib.leftIce, PlatformLib.PlatformInput(false), Variables.playerInstance.leftControllerTransform);
			PlatformLib.CreateOrDestroyFrozonePlatform(ref PlatformLib.RightIce, PlatformLib.PlatformInput(true), Variables.playerInstance.rightControllerTransform);
		}

		// Token: 0x060000BF RID: 191 RVA: 0x0000BFD8 File Offset: 0x0000A1D8
		public static void Noclip()
		{
			bool enabled = Variables.pollerInstance.rightControllerIndexFloat <= 0.1f;
			foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
			{
				meshCollider.enabled = enabled;
			}
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x0000C020 File Offset: 0x0000A220
		public static void FlyMonke(bool useVelocity, float velocityMultiplier = 3f)
		{
			Rigidbody component = Variables.playerInstance.GetComponent<Rigidbody>();
			bool rightControllerPrimaryButton = Variables.pollerInstance.rightControllerPrimaryButton;
			if (rightControllerPrimaryButton)
			{
				bool noclipFly = Settings.noclipFly;
				if (noclipFly)
				{
					foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
					{
						meshCollider.enabled = false;
					}
				}
				if (useVelocity)
				{
					component.velocity += Variables.playerInstance.headCollider.transform.forward * Time.deltaTime * Settings.FlySpeed * velocityMultiplier;
				}
				else
				{
					Variables.playerInstance.transform.position += Variables.playerInstance.headCollider.transform.forward * Time.deltaTime * Settings.FlySpeed;
					component.velocity = Vector3.zero;
				}
			}
			else
			{
				bool noclipFly2 = Settings.noclipFly;
				if (noclipFly2)
				{
					foreach (MeshCollider meshCollider2 in Resources.FindObjectsOfTypeAll<MeshCollider>())
					{
						meshCollider2.enabled = true;
					}
				}
			}
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x0000C15C File Offset: 0x0000A35C
		public static void WASDMovement()
		{
			Transform transform = Variables.taggerInstance.headCollider.transform;
			float num = UnityInput.Current.GetKey(304) ? (Settings.FlySpeed + 3f) : Settings.FlySpeed;
			Variables.playerInstance.GetComponent<Rigidbody>().velocity = new Vector3(0f, 0.065f, 0f);
			Vector3 vector = Vector3.zero;
			bool key = UnityInput.Current.GetKey(119);
			if (key)
			{
				vector += transform.forward;
			}
			bool key2 = UnityInput.Current.GetKey(115);
			if (key2)
			{
				vector -= transform.forward;
			}
			bool key3 = UnityInput.Current.GetKey(97);
			if (key3)
			{
				vector -= transform.right;
			}
			bool key4 = UnityInput.Current.GetKey(100);
			if (key4)
			{
				vector += transform.right;
			}
			bool key5 = UnityInput.Current.GetKey(32);
			if (key5)
			{
				vector += transform.up;
			}
			bool key6 = UnityInput.Current.GetKey(306);
			if (key6)
			{
				vector -= transform.up;
			}
			Variables.taggerInstance.headCollider.transform.position += vector.normalized * num * Time.deltaTime;
			bool mouseButton = UnityInput.Current.GetMouseButton(1);
			if (mouseButton)
			{
				Vector3 vector2 = UnityInput.Current.mousePosition - Movement.OldMousePosition;
				float num2 = 0.1f;
				Variables.taggerInstance.mainCamera.transform.localEulerAngles += new Vector3(-vector2.y * num2, vector2.x * num2, 0f);
			}
			Movement.OldMousePosition = UnityInput.Current.mousePosition;
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x0000C338 File Offset: 0x0000A538
		public static void JoystickFly()
		{
			Rigidbody component = Variables.playerInstance.GetComponent<Rigidbody>();
			Transform transform = Variables.playerInstance.headCollider.transform;
			Vector2 axis = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.axis;
			bool flag = axis.magnitude > 0.1f;
			if (flag)
			{
				Vector3 vector = transform.forward * axis.y + transform.right * axis.x;
				Variables.playerInstance.transform.position += vector * Time.deltaTime * Settings.FlySpeed;
				component.velocity = Vector3.zero;
			}
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x0000C3E8 File Offset: 0x0000A5E8
		public static void IronMonke(int flySpeed)
		{
			bool leftGrab = Variables.pollerInstance.leftGrab;
			if (leftGrab)
			{
				Variables.playerInstance.bodyCollider.attachedRigidbody.AddForce((float)flySpeed * -Variables.taggerInstance.leftHandTransform.right, 5);
			}
			bool rightGrab = Variables.pollerInstance.rightGrab;
			if (rightGrab)
			{
				Variables.playerInstance.bodyCollider.attachedRigidbody.AddForce((float)flySpeed * Variables.taggerInstance.rightHandTransform.right, 5);
			}
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x0000C474 File Offset: 0x0000A674
		public static void CarMonke()
		{
			float rightControllerIndexFloat = Variables.pollerInstance.rightControllerIndexFloat;
			bool flag = rightControllerIndexFloat > 0.1f;
			if (flag)
			{
				Movement.CurrentCarSpeed = Mathf.Clamp(Movement.CurrentCarSpeed + 0.1f, 0f, 15f);
			}
			else
			{
				Movement.CurrentCarSpeed = Mathf.Max(Movement.CurrentCarSpeed - 0.5f, 0f);
			}
			Variables.playerInstance.transform.position += Variables.playerInstance.bodyCollider.transform.forward * Time.deltaTime * Movement.CurrentCarSpeed;
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x0000C51C File Offset: 0x0000A71C
		public static void SpeedBoost()
		{
			bool useGripForSpeedBoost = Settings.useGripForSpeedBoost;
			if (useGripForSpeedBoost)
			{
				bool rightGrab = Variables.pollerInstance.rightGrab;
				if (rightGrab)
				{
					Variables.playerInstance.maxJumpSpeed = Settings.SpeedboostSpeed;
					GorillaGameManager.instance.fastJumpLimit = Settings.SpeedboostSpeed;
					Variables.playerInstance.jumpMultiplier = Settings.SpeedboostMultiplier;
					GorillaGameManager.instance.fastJumpMultiplier = Settings.SpeedboostMultiplier;
				}
			}
			else
			{
				Variables.playerInstance.maxJumpSpeed = Settings.SpeedboostSpeed;
				Variables.playerInstance.jumpMultiplier = Settings.SpeedboostMultiplier;
			}
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x0000C5A8 File Offset: 0x0000A7A8
		public static void FunnyRun()
		{
			float num = (float)Time.frameCount;
			Vector3 position = Variables.taggerInstance.headCollider.transform.position;
			bool flag = Variables.pollerInstance.rightGrab || Variables.pollerInstance.leftGrab || Mouse.current.rightButton.isPressed || Mouse.current.leftButton.isPressed;
			if (flag)
			{
				bool rightGrab = Variables.pollerInstance.rightGrab;
				float num2 = rightGrab ? 0f : 3.1415927f;
				float num3 = rightGrab ? -0.05f : 0.05f;
				Vector3 vector = Variables.taggerInstance.headCollider.transform.forward * (MathF.Cos(num + num2) / 10f);
				Vector3 vector2;
				vector2..ctor(0f, -0.5f - MathF.Sin(num + num2) / 7f, 0f);
				Vector3 vector3 = Variables.taggerInstance.headCollider.transform.right * num3;
				bool flag2 = rightGrab;
				if (flag2)
				{
					Variables.taggerInstance.rightHandTransform.position = position + vector + vector2 + vector3;
				}
				else
				{
					Variables.taggerInstance.leftHandTransform.position = position + vector + vector2 + vector3;
				}
			}
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x0000C70C File Offset: 0x0000A90C
		public static void DashAndAirJump(bool isDashEnabled, bool isAirJumpEnabled)
		{
			bool flag = Variables.pollerInstance.rightControllerPrimaryButton && !Movement.pressedPrimary;
			if (flag)
			{
				Movement.pressedPrimary = true;
				if (isDashEnabled)
				{
					Variables.playerInstance.GetComponent<Rigidbody>().velocity = Variables.playerInstance.headCollider.transform.forward * 9f;
				}
				if (isAirJumpEnabled)
				{
					Variables.playerInstance.GetComponent<Rigidbody>().velocity += Vector3.up * 7f;
				}
			}
			bool flag2 = !Variables.pollerInstance.rightControllerPrimaryButton;
			if (flag2)
			{
				Movement.pressedPrimary = false;
			}
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x0000C7BC File Offset: 0x0000A9BC
		public static void HandleGravity(string GravityType)
		{
			string text = GravityType.ToLower();
			string text2 = text;
			if (!(text2 == "anti gravity"))
			{
				if (!(text2 == "low gravity"))
				{
					if (!(text2 == "high gravity"))
					{
						Debug.LogError("Unknown Gravity Type: " + GravityType);
					}
					else
					{
						Movement.SetGravity(6.5f, Vector3.down, false);
					}
				}
				else
				{
					Movement.SetGravity(6.5f, Vector3.up, false);
				}
			}
			else
			{
				Movement.SetGravity(0f, Vector3.zero, true);
			}
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x0000C848 File Offset: 0x0000AA48
		public static void SetGravity(float gravityLevel, Vector3 gravityDirection, bool noGravity = false)
		{
			Rigidbody component = Variables.playerInstance.GetComponent<Rigidbody>();
			if (noGravity)
			{
				component.AddForce(-Physics.gravity, 5);
			}
			else
			{
				component.AddForce(gravityDirection * (Time.deltaTime * (gravityLevel / Time.deltaTime)), 5);
			}
		}

		// Token: 0x060000CA RID: 202 RVA: 0x0000C89C File Offset: 0x0000AA9C
		public static void WallWalk()
		{
			bool flag = Variables.playerInstance.wasLeftHandColliding || Variables.playerInstance.wasRightHandColliding;
			if (flag)
			{
				FieldInfo field = typeof(GTPlayer).GetField("lastHitInfoHand", 36);
				bool flag2 = field != null;
				if (flag2)
				{
					object value = field.GetValue(Variables.playerInstance);
					RaycastHit raycastHit;
					bool flag3;
					if (value is RaycastHit)
					{
						raycastHit = (RaycastHit)value;
						flag3 = true;
					}
					else
					{
						flag3 = false;
					}
					bool flag4 = flag3;
					if (flag4)
					{
						Movement.wallContactPoint = raycastHit.point;
						Movement.wallContactNormal = raycastHit.normal;
					}
				}
			}
			bool flag5 = Movement.wallContactPoint != Vector3.zero && (Variables.pollerInstance.rightGrab || Variables.pollerInstance.leftGrab);
			if (flag5)
			{
				Variables.playerInstance.bodyCollider.attachedRigidbody.AddForce(Movement.wallContactNormal * Settings.WallWalkStrength, 5);
			}
		}

		// Token: 0x060000CB RID: 203 RVA: 0x0000C988 File Offset: 0x0000AB88
		public static void SpiderWalk()
		{
			bool flag = Variables.playerInstance.wasLeftHandColliding || Variables.playerInstance.wasRightHandColliding;
			if (flag)
			{
				FieldInfo field = typeof(GTPlayer).GetField("lastHitInfoHand", 36);
				bool flag2 = field != null;
				if (flag2)
				{
					object value = field.GetValue(Variables.playerInstance);
					RaycastHit raycastHit;
					bool flag3;
					if (value is RaycastHit)
					{
						raycastHit = (RaycastHit)value;
						flag3 = true;
					}
					else
					{
						flag3 = false;
					}
					bool flag4 = flag3;
					if (flag4)
					{
						Movement.wallContactPoint = raycastHit.point;
						Movement.wallContactNormal = raycastHit.normal;
					}
				}
			}
			bool flag5 = Movement.wallContactPoint != Vector3.zero && (Variables.pollerInstance.rightGrab || Variables.pollerInstance.leftGrab);
			if (flag5)
			{
				Variables.playerInstance.bodyCollider.attachedRigidbody.AddForce(Movement.wallContactNormal * -35f, 5);
				Movement.HandleGravity("No Gravity");
			}
		}

		// Token: 0x060000CC RID: 204 RVA: 0x0000CA7E File Offset: 0x0000AC7E
		public static void GrippyHands(bool setActive)
		{
			Movement.GrippySurfaces = setActive;
		}

		// Token: 0x060000CD RID: 205 RVA: 0x0000CA87 File Offset: 0x0000AC87
		public static void SlippyHands(bool setActive)
		{
			Movement.SlipperySurfaces = setActive;
		}

		// Token: 0x060000CE RID: 206 RVA: 0x0000CA90 File Offset: 0x0000AC90
		public static void SlideControl(bool setActive)
		{
			if (setActive)
			{
				Variables.playerInstance.slideControl = 0.04f;
			}
			else
			{
				Variables.playerInstance.slideControl = 0.00425f;
			}
		}

		// Token: 0x060000CF RID: 207 RVA: 0x0000CAC8 File Offset: 0x0000ACC8
		public static void PlaceCheckPoint(bool setActive)
		{
			if (setActive)
			{
				bool rightGrab = Variables.pollerInstance.rightGrab;
				if (rightGrab)
				{
					bool flag = Movement.checkpoint == null;
					if (flag)
					{
						Movement.checkpoint = GameObject.CreatePrimitive(0);
						Movement.checkpoint.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
						Renderer component = Movement.checkpoint.GetComponent<Renderer>();
						bool flag2 = component != null;
						if (flag2)
						{
							component.material.shader = Shader.Find("GUI/Text Shader");
							component.material.color = Color.red;
						}
						Movement.checkpoint.GetComponent<Collider>().enabled = false;
					}
					Movement.checkpoint.transform.position = Variables.playerInstance.rightControllerTransform.position;
				}
				else
				{
					bool flag3 = Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
					if (flag3)
					{
						bool flag4 = Movement.checkpoint != null;
						if (flag4)
						{
							Renderer component2 = Movement.checkpoint.GetComponent<Renderer>();
							bool flag5 = component2 != null;
							if (flag5)
							{
								component2.material.color = Color.green;
							}
							Vector3 position = Movement.checkpoint.transform.position;
							Variables.playerInstance.transform.position = position;
						}
					}
					else
					{
						GameObject gameObject = Movement.checkpoint;
						Renderer renderer = (gameObject != null) ? gameObject.GetComponent<Renderer>() : null;
						bool flag6 = renderer != null;
						if (flag6)
						{
							renderer.material.color = Color.red;
						}
					}
				}
			}
			else
			{
				Object.Destroy(Movement.checkpoint);
			}
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x0000CC6D File Offset: 0x0000AE6D
		public static void NoTagFreeze()
		{
			Variables.playerInstance.disableMovement = false;
		}

		// Token: 0x0400017E RID: 382
		public static bool pressedPrimary = false;

		// Token: 0x0400017F RID: 383
		public static bool GrippySurfaces = false;

		// Token: 0x04000180 RID: 384
		public static float CurrentCarSpeed = 0f;

		// Token: 0x04000181 RID: 385
		private static Vector3 wallContactPoint;

		// Token: 0x04000182 RID: 386
		private static Vector3 wallContactNormal;

		// Token: 0x04000183 RID: 387
		public static bool SlipperySurfaces = false;

		// Token: 0x04000184 RID: 388
		public static Vector3 OldMousePosition;

		// Token: 0x04000185 RID: 389
		public static float Sensitivity = 0.3f;

		// Token: 0x04000186 RID: 390
		public static bool didPress = false;

		// Token: 0x04000187 RID: 391
		private static GameObject checkpoint;
	}
}
