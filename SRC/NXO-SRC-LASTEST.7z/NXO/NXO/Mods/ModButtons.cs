﻿using System;
using System.Linq;
using System.Runtime.CompilerServices;
using NXO.Menu;
using NXO.Mods.Categories;
using NXO.Utilities;
using Photon.Pun;
using UnityEngine;

namespace NXO.Mods
{
	// Token: 0x0200001A RID: 26
	public class ModButtons
	{
		// Token: 0x04000161 RID: 353
		[Nullable(1)]
		public static ButtonHandler.Button[] buttons = new ButtonHandler.Button[]
		{
			new ButtonHandler.Button("Enabled Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Enabled);
			}, null, false),
			new ButtonHandler.Button("Favorite Mods : <color=yellow>LG While Enabling Mod</color>", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Favorited);
			}, null, false),
			new ButtonHandler.Button("Safety Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Safety);
			}, null, false),
			new ButtonHandler.Button("Room Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Room);
			}, null, false),
			new ButtonHandler.Button("Player Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Player);
			}, null, false),
			new ButtonHandler.Button("Movement Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Movement);
			}, null, false),
			new ButtonHandler.Button("Tag Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Tagging);
			}, null, false),
			new ButtonHandler.Button("Visual Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Visuals);
			}, null, false),
			new ButtonHandler.Button("Soundboard (Being Reworked)", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Soundboard);
			}, null, false),
			new ButtonHandler.Button("Projectile Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Projectile);
			}, null, false),
			new ButtonHandler.Button("Sound Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Sound);
			}, null, false),
			new ButtonHandler.Button("Nextbots", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Nextbots);
			}, null, false),
			new ButtonHandler.Button("Miscellaneous Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Miscellaneous);
			}, null, false),
			new ButtonHandler.Button("Cosmetics (CS)", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Cosmetics);
			}, null, false),
			new ButtonHandler.Button("Networked Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Networked);
			}, null, false),
			new ButtonHandler.Button("Special Mods", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Special);
			}, null, false),
			new ButtonHandler.Button("Admins Only", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Admin);
			}, null, false),
			new ButtonHandler.Button("Save Preferences", Category.Settings, false, false, delegate
			{
				ButtonHandler.SavePreferences();
			}, null, false),
			new ButtonHandler.Button("Load Preferences", Category.Settings, false, false, delegate
			{
				ButtonHandler.LoadPreferences();
			}, null, false),
			new ButtonHandler.Button("Menu Settings", Category.Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Menu_Settings);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Menu_Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Settings);
			}, null, false),
			new ButtonHandler.Button("Switch Hands", Category.Menu_Settings, true, false, delegate
			{
				Settings.SwitchHands(true);
			}, delegate
			{
				Settings.SwitchHands(false);
			}, false),
			Settings.themeChangerButton = new ButtonHandler.Button("Menu Theme : " + Settings.ThemeDescription, Category.Menu_Settings, false, false, delegate
			{
				Settings.CycleTheme();
			}, null, false),
			Optimizations.ResourceLoader.CycleMenuFontButton = new ButtonHandler.Button("Menu Font : " + Optimizations.ResourceLoader.CurrentFontDescription, Category.Menu_Settings, false, false, delegate
			{
				Optimizations.ResourceLoader.CycleFont();
			}, null, false),
			ButtonSoundHandler.changeclicksoundButton = new ButtonHandler.Button("Click Sound : " + ButtonSoundHandler.ClickSoundDescription, Category.Menu_Settings, false, false, delegate
			{
				ButtonSoundHandler.ChangeClickSound();
			}, null, false),
			new ButtonHandler.Button("Disconnect Button", Category.Menu_Settings, true, true, delegate
			{
				Settings.ToggleDisconnectButton(true);
			}, delegate
			{
				Settings.ToggleDisconnectButton(false);
			}, false),
			new ButtonHandler.Button("Wide Menu", Category.Menu_Settings, true, false, delegate
			{
				Settings.ToggleWideMenu(true);
			}, delegate
			{
				Settings.ToggleWideMenu(false);
			}, false),
			new ButtonHandler.Button("Advanced Title", Category.Menu_Settings, true, true, delegate
			{
				Settings.AdvancedTitle(true);
			}, delegate
			{
				Settings.AdvancedTitle(false);
			}, false),
			new ButtonHandler.Button("Toggle Notifications", Category.Menu_Settings, true, true, delegate
			{
				Settings.ToggleNotifications(true);
			}, delegate
			{
				Settings.ToggleNotifications(false);
			}, false),
			new ButtonHandler.Button("Clear Notifications", Category.Menu_Settings, false, false, delegate
			{
				Settings.ClearNotifications();
			}, null, false),
			new ButtonHandler.Button("Disable All Mods", Category.Menu_Settings, false, false, delegate
			{
				ButtonHandler.DisableAllMods();
			}, null, false),
			new ButtonHandler.Button("Player Settings", Category.Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Player_Settings);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Player_Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Settings);
			}, null, false),
			Settings.adjustArmLengthButton = new ButtonHandler.Button("Long Arms Length : " + Settings.ArmLengthDescription, Category.Player_Settings, false, false, delegate
			{
				Settings.AdjustArmLength();
			}, null, false),
			new ButtonHandler.Button("Movement Settings", Category.Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Movement_Settings);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Movement_Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Settings);
			}, null, false),
			Settings.cyclePlatformTypeButton = new ButtonHandler.Button("Platform Type : " + Settings.PlatformType, Category.Movement_Settings, false, false, delegate
			{
				Settings.CyclePlatformType();
			}, null, false),
			Settings.adjustFlySpeedButton = new ButtonHandler.Button("Flight Speed : " + Settings.FlySpeedDescription, Category.Movement_Settings, false, false, delegate
			{
				Settings.AdjustFlySpeed();
			}, null, false),
			Settings.adjustSpeedBoostButton = new ButtonHandler.Button("Speed Boost : " + Settings.SpeedDescription, Category.Movement_Settings, false, false, delegate
			{
				Settings.AdjustSpeedBoost();
			}, null, false),
			Settings.adjustWalkWalkStrengthButton = new ButtonHandler.Button("Wall Walk Strength : " + Settings.WalkWalkStrengthDescription, Category.Movement_Settings, false, false, delegate
			{
				Settings.AdjustWallWalkStrength();
			}, null, false),
			new ButtonHandler.Button("Grip To Speedboost", Category.Movement_Settings, true, false, delegate
			{
				Settings.GripSpeedBoost(true);
			}, delegate
			{
				Settings.GripSpeedBoost(false);
			}, false),
			new ButtonHandler.Button("Noclip Fly", Category.Movement_Settings, true, false, delegate
			{
				Settings.isNoclipFly(true);
			}, delegate
			{
				Settings.isNoclipFly(false);
			}, false),
			new ButtonHandler.Button("Trigger Platforms", Category.Movement_Settings, true, false, delegate
			{
				Settings.TriggerPlatforms(true);
			}, delegate
			{
				Settings.TriggerPlatforms(false);
			}, false),
			new ButtonHandler.Button("Visual Settings", Category.Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Visual_Settings);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Visual_Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Settings);
			}, null, false),
			Settings.tracerPositionButton = new ButtonHandler.Button("Tracer Positon : " + Settings.TracerPosition, Category.Visual_Settings, false, false, delegate
			{
				Settings.AdjustTracerPosition();
			}, null, false),
			Settings.adjustFOVButton = new ButtonHandler.Button("FPC FOV : " + Settings.FOVDescription, Category.Visual_Settings, false, false, delegate
			{
				Settings.AdjustFOV();
			}, null, false),
			new ButtonHandler.Button("Team Checked ESP", Category.Visual_Settings, true, false, delegate
			{
				Settings.IsTeamChecked(true);
			}, delegate
			{
				Settings.IsTeamChecked(false);
			}, false),
			new ButtonHandler.Button("Animated Guns", Category.Visual_Settings, true, true, delegate
			{
				Settings.AnimatedGuns(true);
			}, delegate
			{
				Settings.AnimatedGuns(false);
			}, false),
			new ButtonHandler.Button("Projectile Settings", Category.Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Projectile_Settings);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Projectile_Settings, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Settings);
			}, null, false),
			Settings.adjustProjectileSpeedButton = new ButtonHandler.Button("Projectile Speed : " + Settings.ProjectileSpeedDescription, Category.Projectile_Settings, false, false, delegate
			{
				Settings.AdjustProjectileSpeed();
			}, null, false),
			Projectile.cycleProjectileButton = new ButtonHandler.Button("Projectile Type : " + Projectile.projectileNames[Projectile.currentProjectile], Category.Projectile_Settings, false, false, delegate
			{
				Projectile.CycleProjectileType();
			}, null, false),
			Projectile.cycleProjectileColorButton = new ButtonHandler.Button("Projectile Color : " + Projectile.colorNames[Projectile.currentColorIndex], Category.Projectile_Settings, false, false, delegate
			{
				Projectile.CycleProjectileColor();
			}, null, false),
			new ButtonHandler.Button("Anti Report", Category.Safety, true, false, delegate
			{
				Safety.AntiReport(false, false);
			}, null, false),
			new ButtonHandler.Button("Queue Anti Report", Category.Safety, true, true, delegate
			{
				Safety.AntiReport(true, false);
			}, null, false),
			new ButtonHandler.Button("Reconnect Anti Report", Category.Safety, true, false, delegate
			{
				Safety.AntiReport(false, true);
			}, null, false),
			new ButtonHandler.Button("Anti Moderator", Category.Safety, true, false, delegate
			{
				Safety.AntiModerator();
			}, null, false),
			new ButtonHandler.Button("Fake Quest Menu (A)", Category.Safety, true, false, delegate
			{
				Safety.FakeQuestMenu();
			}, null, false),
			new ButtonHandler.Button("Fake Lag (A)", Category.Safety, true, false, delegate
			{
				Safety.FakeLag();
			}, delegate
			{
				Player.SetRigStatus(true);
			}, false),
			new ButtonHandler.Button("No Finger Movement", Category.Safety, true, false, delegate
			{
				Safety.NoFingerMovement();
			}, null, false),
			new ButtonHandler.Button("Disable Quit Box", Category.Safety, true, false, delegate
			{
				Room.SetQuitBoxActive(false);
			}, delegate
			{
				Room.SetQuitBoxActive(true);
			}, false),
			new ButtonHandler.Button("Quit Game", Category.Room, false, false, new Action(Application.Quit), null, false),
			new ButtonHandler.Button("Disconnect", Category.Room, false, false, new Action(PhotonNetwork.Disconnect), null, false),
			new ButtonHandler.Button("Reconnect", Category.Room, false, false, delegate
			{
				Room.Reconnect();
			}, null, false),
			new ButtonHandler.Button("Join Random", Category.Room, false, false, delegate
			{
				Room.JoinRandomPublic();
			}, null, false),
			new ButtonHandler.Button("Disable Network Triggers", Category.Room, true, false, delegate
			{
				Room.SetNetworkTriggersActive(false);
			}, delegate
			{
				Room.SetNetworkTriggersActive(true);
			}, false),
			new ButtonHandler.Button("Accept TOS", Category.Room, true, false, delegate
			{
				Room.AcceptTOS(true);
			}, delegate
			{
				Room.AcceptTOS(false);
			}, false),
			new ButtonHandler.Button("Grab All IDs", Category.Room, false, false, delegate
			{
				Room.GrabAllIDs();
			}, null, false),
			new ButtonHandler.Button("Grab Self ID", Category.Room, false, false, delegate
			{
				Room.GrabSelfID();
			}, null, false),
			new ButtonHandler.Button("Dump All RPCs", Category.Room, false, false, delegate
			{
				Room.DumpAllRPCs();
			}, null, false),
			new ButtonHandler.Button("Ghost Monke (A)", Category.Player, true, false, delegate
			{
				Player.GhostMonke();
			}, null, false),
			new ButtonHandler.Button("Invisible Monke (A)", Category.Player, true, false, delegate
			{
				Player.InvisibleMonke();
			}, null, false),
			new ButtonHandler.Button("Ghost & Invisibility (A/B)", Category.Player, true, false, delegate
			{
				Player.GhostInvisibleMonke();
			}, null, false),
			new ButtonHandler.Button("Freeze Rig (A)", Category.Player, true, false, delegate
			{
				Player.FreezeRig();
			}, null, false),
			new ButtonHandler.Button("Grab Rig (RG/LG)", Category.Player, true, false, delegate
			{
				Player.GrabRig();
			}, null, false),
			new ButtonHandler.Button("Long Arms", Category.Player, true, false, delegate
			{
				Player.LongArms(true);
			}, delegate
			{
				Player.LongArms(false);
			}, false),
			new ButtonHandler.Button("Griddy (RT)", Category.Player, true, false, delegate
			{
				Player.GriddyMonke();
			}, null, false),
			new ButtonHandler.Button("Size Changer (RT/LT)", Category.Player, true, false, delegate
			{
				Player.SizeChanger();
			}, null, false),
			new ButtonHandler.Button("Helicopter Monke (RT)", Category.Player, true, false, delegate
			{
				Player.HelicopterMonke();
			}, delegate
			{
				Player.SetRigStatus(true);
			}, false),
			new ButtonHandler.Button("Ascend Monke (RT)", Category.Player, true, false, delegate
			{
				Player.AscendingMonke();
			}, delegate
			{
				Player.SetRigStatus(true);
			}, false),
			new ButtonHandler.Button("Spaz Monke (RT)", Category.Player, true, false, delegate
			{
				Player.SpazMonke();
			}, delegate
			{
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 0f, 0f)), default(float?));
			}, false),
			new ButtonHandler.Button("Spaz Arms (RT)", Category.Player, true, false, delegate
			{
				Player.SpazArms();
			}, null, false),
			new ButtonHandler.Button("T-Pose (RT)", Category.Player, true, false, delegate
			{
				Player.TPose();
			}, null, false),
			new ButtonHandler.Button("Spin Head (RT)", Category.Player, true, false, delegate
			{
				float? spinAmount = new float?(10f);
				Player.SetHeadRotation(default(Vector3?), spinAmount);
			}, delegate
			{
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 0f, 0f)), default(float?));
			}, false),
			new ButtonHandler.Button("Flip Head (RT)", Category.Player, true, false, delegate
			{
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 0f, 180f)), default(float?));
			}, delegate
			{
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 0f, 0f)), default(float?));
			}, false),
			new ButtonHandler.Button("Backwards Head (RT)", Category.Player, true, false, delegate
			{
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 180f, 0f)), default(float?));
			}, delegate
			{
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 0f, 0f)), default(float?));
			}, false),
			new ButtonHandler.Button("Snap Neck", Category.Player, true, false, delegate
			{
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 0f, 90f)), default(float?));
			}, delegate
			{
				Player.SetHeadRotation(new Vector3?(new Vector3(0f, 0f, 0f)), default(float?));
			}, false),
			new ButtonHandler.Button("Rig Gun", Category.Player, true, false, delegate
			{
				Player.RigGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Teleport Gun", Category.Player, true, false, delegate
			{
				Player.TeleportGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Chase Gun", Category.Player, true, false, delegate
			{
				Player.ChasePlayerGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Orbit Gun", Category.Player, true, false, delegate
			{
				Player.OrbitPlayerGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Jumpscare Gun", Category.Player, true, false, delegate
			{
				Player.JumpscarePlayerGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Copy Player Gun", Category.Player, true, false, delegate
			{
				Player.CopyPlayerGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Fuck Player Gun", Category.Player, true, false, delegate
			{
				Player.FuckPlayerGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Piggyback Player Gun", Category.Player, true, false, delegate
			{
				Player.PiggybackPlayerGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Flight (A)", Category.Movement, true, false, delegate
			{
				Movement.FlyMonke(false, 3f);
			}, null, false),
			new ButtonHandler.Button("Platforms (RG/LG)", Category.Movement, true, false, delegate
			{
				Movement.TogglePlatforms();
			}, null, false),
			new ButtonHandler.Button("Frozone (RG/LG)", Category.Movement, true, false, delegate
			{
				Movement.Frozone();
			}, null, false),
			new ButtonHandler.Button("Speed Boost", Category.Movement, true, false, delegate
			{
				Movement.SpeedBoost();
			}, null, false),
			new ButtonHandler.Button("Noclip (RT)", Category.Movement, true, false, delegate
			{
				Movement.Noclip();
			}, null, false),
			new ButtonHandler.Button("Anti Gravity", Category.Movement, true, false, delegate
			{
				Movement.HandleGravity("anti gravity");
			}, null, false),
			new ButtonHandler.Button("Low Gravity", Category.Movement, true, false, delegate
			{
				Movement.HandleGravity("low gravity");
			}, null, false),
			new ButtonHandler.Button("High Gravity", Category.Movement, true, false, delegate
			{
				Movement.HandleGravity("high gravity");
			}, null, false),
			new ButtonHandler.Button("Wall Walk (RG/LG)", Category.Movement, true, false, delegate
			{
				Movement.WallWalk();
			}, null, false),
			new ButtonHandler.Button("Spider Walk (RG/LG)", Category.Movement, true, false, delegate
			{
				Movement.SpiderWalk();
			}, null, false),
			new ButtonHandler.Button("Accel Flight (A)", Category.Movement, true, false, delegate
			{
				Movement.FlyMonke(true, 3f);
			}, null, false),
			new ButtonHandler.Button("WASD Movement", Category.Movement, true, false, delegate
			{
				Movement.WASDMovement();
			}, null, false),
			new ButtonHandler.Button("Freecam (LJ)", Category.Movement, true, false, delegate
			{
				Movement.JoystickFly();
			}, null, false),
			new ButtonHandler.Button("Funny Run (RG/LG)", Category.Movement, true, false, delegate
			{
				Movement.FunnyRun();
			}, null, false),
			new ButtonHandler.Button("Swim Speed Boost", Category.Movement, true, false, delegate
			{
				Miscellaneous.FastSwim();
			}, null, false),
			new ButtonHandler.Button("Dash Monke (A)", Category.Movement, true, false, delegate
			{
				Movement.DashAndAirJump(true, false);
			}, null, false),
			new ButtonHandler.Button("Checkpoint (RG/RT)", Category.Movement, true, false, delegate
			{
				Movement.PlaceCheckPoint(true);
			}, delegate
			{
				Movement.PlaceCheckPoint(false);
			}, false),
			new ButtonHandler.Button("Slide Control", Category.Movement, true, false, delegate
			{
				Movement.SlideControl(true);
			}, delegate
			{
				Movement.SlideControl(false);
			}, false),
			new ButtonHandler.Button("Anti Slip", Category.Movement, true, false, delegate
			{
				Movement.GrippyHands(true);
			}, delegate
			{
				Movement.GrippyHands(false);
			}, false),
			new ButtonHandler.Button("Slippy Hands", Category.Movement, true, false, delegate
			{
				Movement.SlippyHands(true);
			}, delegate
			{
				Movement.SlippyHands(false);
			}, false),
			new ButtonHandler.Button("No Tag Freeze", Category.Movement, true, false, delegate
			{
				Movement.NoTagFreeze();
			}, null, false),
			new ButtonHandler.Button("Tag All (RT)", Category.Tagging, true, false, delegate
			{
				Tagging.TagAll();
			}, delegate
			{
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Tag Gun", Category.Tagging, true, false, delegate
			{
				Tagging.TagGun();
			}, delegate
			{
				Player.SetRigStatus(false);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Flick Tag (RT)", Category.Tagging, true, false, delegate
			{
				Tagging.FlickTag();
			}, delegate
			{
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Tag Aura (RT)", Category.Tagging, true, false, delegate
			{
				Tagging.TagAura();
			}, null, false),
			new ButtonHandler.Button("Tag Self (RT)", Category.Tagging, true, false, delegate
			{
				Tagging.TagSelf();
			}, null, false),
			new ButtonHandler.Button("Un-Tag Self (RT)", Category.Tagging, false, false, delegate
			{
				Tagging.UntagSelf();
			}, null, false),
			new ButtonHandler.Button("Anti Tag", Category.Tagging, true, false, delegate
			{
				Tagging.AntiTag();
			}, null, false),
			new ButtonHandler.Button("No Tag On Join", Category.Tagging, true, false, delegate
			{
				Tagging.NoTagOnJoin(true);
			}, delegate
			{
				Tagging.NoTagOnJoin(false);
			}, false),
			new ButtonHandler.Button("3D Box ESP", Category.Visuals, true, false, delegate
			{
				Visuals.ESP3D(true);
			}, delegate
			{
				Visuals.ESP3D(false);
			}, false),
			new ButtonHandler.Button("2D Box ESP", Category.Visuals, true, false, delegate
			{
				Visuals.ESP2D(true);
			}, delegate
			{
				Visuals.ESP2D(false);
			}, false),
			new ButtonHandler.Button("Tracers", Category.Visuals, true, false, delegate
			{
				Visuals.TracersESP(true);
			}, delegate
			{
				Visuals.TracersESP(false);
			}, false),
			new ButtonHandler.Button("Skeleton ESP", Category.Visuals, true, false, delegate
			{
				Visuals.SkeletonESP(true);
			}, delegate
			{
				Visuals.SkeletonESP(false);
			}, false),
			new ButtonHandler.Button("Chams", Category.Visuals, true, false, delegate
			{
				Visuals.ChamsESP(true);
			}, delegate
			{
				Visuals.ChamsESP(false);
			}, false),
			new ButtonHandler.Button("Beacons ESP", Category.Visuals, true, false, delegate
			{
				Visuals.BeaconsESP(true);
			}, delegate
			{
				Visuals.BeaconsESP(false);
			}, false),
			new ButtonHandler.Button("Name Tags", Category.Visuals, true, false, delegate
			{
				Visuals.Nametags(true);
			}, delegate
			{
				Visuals.Nametags(false);
			}, false),
			new ButtonHandler.Button("First Person", Category.Visuals, true, false, delegate
			{
				Visuals.FPC(true);
			}, delegate
			{
				Visuals.FPC(false);
			}, false),
			new ButtonHandler.Button("Change Time", Category.Visuals, false, false, delegate
			{
				Visuals.ChangeTime();
			}, null, false),
			new ButtonHandler.Button("FPS Boost", Category.Visuals, true, false, delegate
			{
				Visuals.FPSBoost(true);
			}, delegate
			{
				Visuals.FPSBoost(false);
			}, false),
			new ButtonHandler.Button("Fuck Colors", Category.Visuals, true, false, delegate
			{
				Visuals.FuckLights(true);
			}, delegate
			{
				Visuals.FuckLights(false);
			}, false),
			new ButtonHandler.Button("Bright Mode", Category.Visuals, true, false, delegate
			{
				Visuals.BrightMode(true);
			}, delegate
			{
				Visuals.BrightMode(false);
			}, false),
			new ButtonHandler.Button("Dark Mode", Category.Visuals, true, false, delegate
			{
				Visuals.DarkMode(true);
			}, delegate
			{
				Visuals.DarkMode(false);
			}, false),
			new ButtonHandler.Button("Disable Rain", Category.Visuals, true, false, delegate
			{
				Visuals.RainyWeather(false);
			}, delegate
			{
				Visuals.RainyWeather(true);
			}, false),
			new ButtonHandler.Button("Rain Mode", Category.Visuals, true, false, delegate
			{
				Visuals.RainyWeather(true);
			}, delegate
			{
				Visuals.RainyWeather(false);
			}, false),
			new ButtonHandler.Button("Load Soundboard", Category.Soundboard, false, false, delegate
			{
				Soundboard.InitializeSounds();
			}, null, false),
			new ButtonHandler.Button("Disable All Sounds", Category.Soundboard, false, false, delegate
			{
				Enumerable.ToList<string>(Soundboard.SoundboardSoundsActive.Keys).ForEach(new Action<string>(Soundboard.StopSound));
			}, null, false),
			new ButtonHandler.Button("Loop Sounds", Category.Soundboard, true, false, delegate
			{
				Soundboard.EnableLoop();
			}, delegate
			{
				Soundboard.DisableLoop();
			}, false),
			InputHandler.cycleControllerBindButton = new ButtonHandler.Button("Sound Input : " + InputHandler.inputName, Category.Soundboard, false, false, delegate
			{
				InputHandler.CycleControllerBind();
			}, null, false),
			new ButtonHandler.Button("Return", Category.SFX, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Soundboard);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Trolling, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Soundboard);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Songs, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Soundboard);
			}, null, false),
			new ButtonHandler.Button("Projectile Spam (RG)", Category.Projectile, true, false, delegate
			{
				Projectile.LaunchProjectile(Variables.playerInstance.rightControllerTransform.position, Variables.playerInstance.rightControllerTransform.forward * 0f, new Color32?(ColorLib.RainbowMat.color));
			}, null, false),
			new ButtonHandler.Button("Shoot Projectiles (RG)", Category.Projectile, true, false, delegate
			{
				Projectile.LaunchProjectile(Variables.playerInstance.rightControllerTransform.position, Variables.playerInstance.rightControllerTransform.forward * Settings.ProjectileSpeed, new Color32?(ColorLib.RainbowMat.color));
			}, null, false),
			new ButtonHandler.Button("Projectile Gun", Category.Projectile, true, false, delegate
			{
				Projectile.ProjectileGun();
			}, delegate
			{
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Urine (RG)", Category.Projectile, true, false, delegate
			{
				Projectile.LaunchProjectile(Variables.playerInstance.bodyCollider.transform.position + Vector3.up * 0.22f, Variables.playerInstance.bodyCollider.transform.forward * 3f, new Color32?(ColorLib.Yellow));
			}, null, false),
			new ButtonHandler.Button("Semen (RG)", Category.Projectile, true, false, delegate
			{
				Projectile.LaunchProjectile(Variables.playerInstance.bodyCollider.transform.position - Vector3.up * 0.22f, Variables.playerInstance.bodyCollider.transform.forward * 3f, new Color32?(new Color32(240, 240, 200, byte.MaxValue)));
			}, null, false),
			new ButtonHandler.Button("Feces (RG)", Category.Projectile, true, false, delegate
			{
				Projectile.LaunchProjectile(Variables.playerInstance.bodyCollider.transform.position - Vector3.up * 0.22f, Vector3.up * -0.1f, new Color32?(ColorLib.Brown));
			}, null, false),
			new ButtonHandler.Button("Vomit (RG)", Category.Projectile, true, false, delegate
			{
				Projectile.LaunchProjectile(Variables.playerInstance.headCollider.transform.position - Variables.playerInstance.headCollider.transform.up * 0.2f, Variables.playerInstance.headCollider.transform.forward * 6f, new Color32?(ColorLib.DarkGreen));
			}, null, false),
			new ButtonHandler.Button("Spit (RG)", Category.Projectile, true, false, delegate
			{
				Projectile.LaunchProjectile(Variables.playerInstance.headCollider.transform.position - Variables.playerInstance.headCollider.transform.up * 0.2f, Variables.playerInstance.headCollider.transform.forward * 6f, new Color32?(new Color32(190, 190, 190, byte.MaxValue)));
			}, null, false),
			new ButtonHandler.Button("Random Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(Random.Range(0, 228));
			}, null, false),
			new ButtonHandler.Button("Annoying Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(248);
			}, null, false),
			new ButtonHandler.Button("Boop Player", Category.Sound, true, false, delegate
			{
				Sound.OnTouchPlayer(84);
			}, null, false),
			new ButtonHandler.Button("Slap Player", Category.Sound, true, false, delegate
			{
				Sound.OnTouchPlayer(248);
			}, null, false),
			new ButtonHandler.Button("Glass Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(28);
			}, null, false),
			new ButtonHandler.Button("Metal Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(18);
			}, null, false),
			new ButtonHandler.Button("Pop Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(84);
			}, null, false),
			new ButtonHandler.Button("Squeaky Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(75);
			}, null, false),
			new ButtonHandler.Button("Crystal Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(213);
			}, null, false),
			new ButtonHandler.Button("Turkey Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(83);
			}, null, false),
			new ButtonHandler.Button("Frog Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(91);
			}, null, false),
			new ButtonHandler.Button("AK-47 Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(203);
			}, null, false),
			new ButtonHandler.Button("Wolf Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(195);
			}, null, false),
			new ButtonHandler.Button("Cat Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(236);
			}, null, false),
			new ButtonHandler.Button("Bee Sound Spam (RT)", Category.Sound, true, false, delegate
			{
				Sound.SpecificSoundSpam(191);
			}, null, false),
			new ButtonHandler.Button("Eggman Nextbot", Category.Nextbots, true, false, delegate
			{
				Nextbots.EggmanNextbot(true);
			}, delegate
			{
				Nextbots.EggmanNextbot(false);
			}, false),
			new ButtonHandler.Button("Web Shooters (RG/LG)", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.Webshooters(true);
			}, delegate
			{
				Miscellaneous.Webshooters(false);
			}, false),
			new ButtonHandler.Button("Draw Mod (RG/LG)", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.DrawMod(true);
			}, delegate
			{
				Miscellaneous.DrawMod(false);
			}, false),
			new ButtonHandler.Button("Place Bomb (RG/RT)", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.PlaceBomb(true);
			}, delegate
			{
				Miscellaneous.PlaceBomb(false);
			}, false),
			new ButtonHandler.Button("Punch Mod", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.PunchMod();
			}, null, false),
			new ButtonHandler.Button("No Name", Category.Miscellaneous, false, false, delegate
			{
				Miscellaneous.SetName("_____");
			}, null, false),
			new ButtonHandler.Button("Solid Water", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.ModifyWater(true, false);
			}, delegate
			{
				Miscellaneous.ModifyWater(false, false);
			}, false),
			new ButtonHandler.Button("Disable Water", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.ModifyWater(false, true);
			}, delegate
			{
				Miscellaneous.ModifyWater(false, false);
			}, false),
			new ButtonHandler.Button("Air Swim", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.AirSwim(true);
			}, delegate
			{
				Miscellaneous.AirSwim(false);
			}, false),
			new ButtonHandler.Button("Water Bender (RG/LG)", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.WaterBender();
			}, null, false),
			new ButtonHandler.Button("Splash Gun", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.SplashGun();
			}, delegate
			{
				Player.SetRigStatus(true);
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Water Barrage (RG/LG)", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.WaterBarrage();
			}, null, false),
			new ButtonHandler.Button("Splash Aura (RT)", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.SplashAura();
			}, null, false),
			new ButtonHandler.Button("Splash Self (RT)", Category.Miscellaneous, true, false, delegate
			{
				Miscellaneous.SplashSelf();
			}, null, false),
			new ButtonHandler.Button("Disable Leaves", Category.Miscellaneous, true, false, delegate
			{
				Visuals.DisableLeaves(true);
			}, delegate
			{
				Visuals.DisableLeaves(false);
			}, false),
			new ButtonHandler.Button("Body", Category.Cosmetics, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Body_Cosmetics);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Body_Cosmetics, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Cosmetics);
			}, null, false),
			new ButtonHandler.Button("Unreleased Sweater", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACP.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACP.");
			}, false),
			new ButtonHandler.Button("Drumset", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBABN.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBABN.");
			}, false),
			new ButtonHandler.Button("Box Body", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBABS.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBABS.");
			}, false),
			new ButtonHandler.Button("Penguin Suit", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACU.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACU.");
			}, false),
			new ButtonHandler.Button("Muscular Body (1)", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBABT.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBABT.");
			}, false),
			new ButtonHandler.Button("Muscular Body (2)", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBADK.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBADK.");
			}, false),
			new ButtonHandler.Button("Flamingo Floaty", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBABP.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBABP.");
			}, false),
			new ButtonHandler.Button("Duck Floaty", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBADI.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBADI.");
			}, false),
			new ButtonHandler.Button("Mermaid", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBADG.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBADG.");
			}, false),
			new ButtonHandler.Button("Santa Body", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACH.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACH.");
			}, false),
			new ButtonHandler.Button("Snowman", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACI.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACI.");
			}, false),
			new ButtonHandler.Button("Cozy Sweater", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACJ.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACJ.");
			}, false),
			new ButtonHandler.Button("Gorilla Tag Shirt", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACA.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACA.");
			}, false),
			new ButtonHandler.Button("I <3 GT Shirt", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACD.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACD.");
			}, false),
			new ButtonHandler.Button("Black Tuxedo", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACE.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACE.");
			}, false),
			new ButtonHandler.Button("White Tuxedo", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACB.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACB.");
			}, false),
			new ButtonHandler.Button("Knight Suit", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACY.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACY.");
			}, false),
			new ButtonHandler.Button("Orange Jacket", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBACL.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBACL.");
			}, false),
			new ButtonHandler.Button("Music Shirt", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBAJH.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBAJH.");
			}, false),
			new ButtonHandler.Button("DJ Set", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBAJI.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBAJI.");
			}, false),
			new ButtonHandler.Button("Xylophone", Category.Body_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBADU.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBADU.");
			}, false),
			new ButtonHandler.Button("Hands", Category.Cosmetics, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Hand_Cosmetics);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Hand_Cosmetics, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Cosmetics);
			}, null, false),
			new ButtonHandler.Button("Gloves (1)", Category.Hand_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LMACK.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LMACK.");
			}, false),
			new ButtonHandler.Button("Gloves (2)", Category.Hand_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LMACO.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LMACO.");
			}, false),
			new ButtonHandler.Button("Gloves (3)", Category.Hand_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LMACN.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LMACN.");
			}, false),
			new ButtonHandler.Button("Gloves (4)", Category.Hand_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LMACM.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LMACM.");
			}, false),
			new ButtonHandler.Button("Wolf Claws", Category.Hand_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LMADI.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LMADI.");
			}, false),
			new ButtonHandler.Button("Goblin Hands", Category.Hand_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LMADP.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LMADP.");
			}, false),
			new ButtonHandler.Button("Knight Gloves", Category.Hand_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LMADO.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LMADO.");
			}, false),
			new ButtonHandler.Button("Rubber Gloves", Category.Hand_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LMAEJ.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LMAEJ.");
			}, false),
			new ButtonHandler.Button("Badges", Category.Cosmetics, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Badge_Cosmetics);
			}, null, false),
			new ButtonHandler.Button("Return", Category.Badge_Cosmetics, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Cosmetics);
			}, null, false),
			new ButtonHandler.Button("Admin Badge", Category.Badge_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBAAD.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBAAD.");
			}, false),
			new ButtonHandler.Button("Illustrator Badge", Category.Badge_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBAGS.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBAGS.");
			}, false),
			new ButtonHandler.Button("Finger Painter Bage", Category.Badge_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBADE.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBADE.");
			}, false),
			new ButtonHandler.Button("Early Access Badge", Category.Badge_Cosmetics, true, false, delegate
			{
				Miscellaneous.AttachCosmetic(true, "LBAAE.");
			}, delegate
			{
				Miscellaneous.AttachCosmetic(false, "LBAAE.");
			}, false),
			new ButtonHandler.Button("Dick Mod", Category.Networked, true, false, delegate
			{
				Networking.NetworkedPenis.DickMod(true);
			}, delegate
			{
				Networking.NetworkedPenis.DickMod(false);
			}, false),
			Networking.NetworkedBlocks.cycleNetworkedBlocksShapeButton = new ButtonHandler.Button("Block Shape : " + Networking.NetworkedBlocks.blockshapeNames[Networking.NetworkedBlocks.currentBlockShape], Category.Networked, false, false, delegate
			{
				Networking.NetworkedBlocks.CycleNetworkedBlocksShape();
			}, null, false),
			new ButtonHandler.Button("Networked Blocks (RG/Big)", Category.Networked, true, false, delegate
			{
				Networking.NetworkedBlocks.NetworkedBlocksTest(true, new Vector3(0.5f, 0.5f, 0.5f));
			}, delegate
			{
				Networking.NetworkedBlocks.NetworkedBlocksTest(false, Vector3.zero);
			}, false),
			new ButtonHandler.Button("Networked Blocks (RG/Medium)", Category.Networked, true, false, delegate
			{
				Networking.NetworkedBlocks.NetworkedBlocksTest(true, new Vector3(0.25f, 0.25f, 0.25f));
			}, delegate
			{
				Networking.NetworkedBlocks.NetworkedBlocksTest(false, Vector3.zero);
			}, false),
			new ButtonHandler.Button("Networked Blocks (RG/Small)", Category.Networked, true, false, delegate
			{
				Networking.NetworkedBlocks.NetworkedBlocksTest(true, new Vector3(0.1f, 0.1f, 0.1f));
			}, delegate
			{
				Networking.NetworkedBlocks.NetworkedBlocksTest(false, Vector3.zero);
			}, false),
			new ButtonHandler.Button("Annoy Gun", Category.Special, true, false, delegate
			{
				Special.SpazImpact();
			}, null, false),
			new ButtonHandler.Button("Spaz All Ropes (RT)", Category.Special, true, false, delegate
			{
				Special.SpazAllRopes();
			}, null, false),
			new ButtonHandler.Button("Spaz Rope Gun", Category.Special, true, false, delegate
			{
				Special.SpazRopeGun();
			}, delegate
			{
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Freeze All Ropes (RT)", Category.Special, true, false, delegate
			{
				Special.FreezeAllRopes();
			}, null, false),
			new ButtonHandler.Button("Freeze Rope Gun", Category.Special, true, false, delegate
			{
				Special.FreezeRopeGun();
			}, delegate
			{
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("All Ropes To Self (RT)", Category.Special, true, false, delegate
			{
				Special.AllRopesToMe();
			}, null, false),
			new ButtonHandler.Button("All Ropes To Gun", Category.Special, true, false, delegate
			{
				Special.AllRopesToGun();
			}, delegate
			{
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("All Ropes To Player Gun", Category.Special, true, false, delegate
			{
				Special.AllRopesToPlayerGun();
			}, delegate
			{
				GunLib.SetGunVisibility(false);
			}, false),
			new ButtonHandler.Button("Fling NXO Users (RT)", Category.Admin, true, false, delegate
			{
				Admin.SendAllToSpace();
			}, delegate
			{
				Admin.ResetName();
			}, false),
			new ButtonHandler.Button("Crash All NXO Users (RT)", Category.Admin, true, false, delegate
			{
				Admin.CrashAll();
			}, delegate
			{
				Admin.ResetName();
			}, false),
			new ButtonHandler.Button("Freeze All NXO Users (RT)", Category.Admin, true, false, delegate
			{
				Admin.FreezeAll();
			}, delegate
			{
				Admin.ResetName();
			}, false)
		};
	}
}
