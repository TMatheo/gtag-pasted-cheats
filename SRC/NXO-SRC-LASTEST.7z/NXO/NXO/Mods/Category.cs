﻿using System;

namespace NXO.Mods
{
	// Token: 0x02000019 RID: 25
	public enum Category
	{
		// Token: 0x04000142 RID: 322
		Home,
		// Token: 0x04000143 RID: 323
		Settings,
		// Token: 0x04000144 RID: 324
		Enabled,
		// Token: 0x04000145 RID: 325
		Favorited,
		// Token: 0x04000146 RID: 326
		Safety,
		// Token: 0x04000147 RID: 327
		Room,
		// Token: 0x04000148 RID: 328
		Player,
		// Token: 0x04000149 RID: 329
		Movement,
		// Token: 0x0400014A RID: 330
		Tagging,
		// Token: 0x0400014B RID: 331
		Visuals,
		// Token: 0x0400014C RID: 332
		Soundboard,
		// Token: 0x0400014D RID: 333
		Projectile,
		// Token: 0x0400014E RID: 334
		Sound,
		// Token: 0x0400014F RID: 335
		Nextbots,
		// Token: 0x04000150 RID: 336
		Miscellaneous,
		// Token: 0x04000151 RID: 337
		Cosmetics,
		// Token: 0x04000152 RID: 338
		Networked,
		// Token: 0x04000153 RID: 339
		Special,
		// Token: 0x04000154 RID: 340
		Admin,
		// Token: 0x04000155 RID: 341
		Menu_Settings,
		// Token: 0x04000156 RID: 342
		Player_Settings,
		// Token: 0x04000157 RID: 343
		Movement_Settings,
		// Token: 0x04000158 RID: 344
		Visual_Settings,
		// Token: 0x04000159 RID: 345
		Projectile_Settings,
		// Token: 0x0400015A RID: 346
		Body_Cosmetics,
		// Token: 0x0400015B RID: 347
		Hand_Cosmetics,
		// Token: 0x0400015C RID: 348
		Badge_Cosmetics,
		// Token: 0x0400015D RID: 349
		SFX,
		// Token: 0x0400015E RID: 350
		Trolling,
		// Token: 0x0400015F RID: 351
		Songs,
		// Token: 0x04000160 RID: 352
		SearchedMods
	}
}
