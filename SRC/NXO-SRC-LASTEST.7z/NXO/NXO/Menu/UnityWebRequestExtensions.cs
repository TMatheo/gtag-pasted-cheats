﻿using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace NXO.Menu
{
	// Token: 0x0200002C RID: 44
	public static class UnityWebRequestExtensions
	{
		// Token: 0x0600019A RID: 410 RVA: 0x0001905C File Offset: 0x0001725C
		[NullableContext(1)]
		public static Task<UnityWebRequest> SendWebRequest(this UnityWebRequest request)
		{
			TaskCompletionSource<UnityWebRequest> tcs = new TaskCompletionSource<UnityWebRequest>();
			UnityWebRequestAsyncOperation unityWebRequestAsyncOperation = request.SendWebRequest();
			unityWebRequestAsyncOperation.completed += delegate(AsyncOperation _)
			{
				tcs.SetResult(request);
			};
			return tcs.Task;
		}
	}
}
