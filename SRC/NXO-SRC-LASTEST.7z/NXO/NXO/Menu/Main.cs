﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using BepInEx;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using HarmonyLib;
using NXO.Mods;
using NXO.Mods.Categories;
using NXO.Utilities;
using Photon.Pun;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace NXO.Menu
{
	// Token: 0x0200002B RID: 43
	[NullableContext(1)]
	[Nullable(0)]
	[HarmonyPatch(typeof(GTPlayer), "LateUpdate")]
	public class Main : MonoBehaviour
	{
		// Token: 0x06000183 RID: 387 RVA: 0x00017168 File Offset: 0x00015368
		private static void CheckMenuActive()
		{
			UnityWebRequest request = UnityWebRequest.Get("https://pastebin.com/raw/1xmmwKSV");
			request.SendWebRequest().completed += delegate(AsyncOperation asyncOperation)
			{
				bool flag = request.isDone && request.result == 1;
				if (flag)
				{
					string text = request.downloadHandler.text.Trim();
					Debug.Log("Menu status: " + text);
					bool flag2 = text == "false" && !Main.isShuttingDown;
					if (flag2)
					{
						Main.isShuttingDown = true;
						Main.shutdownTime = 10f;
					}
				}
				else
				{
					Debug.LogError("Failed to check menu status: " + request.error);
				}
			};
		}

		// Token: 0x06000184 RID: 388 RVA: 0x000171AC File Offset: 0x000153AC
		[HarmonyPrefix]
		public static void Prefix()
		{
			try
			{
				try
				{
					bool flag = Time.time >= Main.nextCheckTime;
					if (flag)
					{
						Main.CheckMenuActive();
						Main.nextCheckTime = Time.time + 20f;
					}
					bool flag2 = Main.isShuttingDown;
					if (flag2)
					{
						Main.shutdownTime -= Time.deltaTime;
						GameObject gameObject = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/Main Camera/DebugCanvas");
						bool flag3 = gameObject != null;
						if (flag3)
						{
							gameObject.SetActive(true);
							TextMeshPro component = gameObject.transform.Find("Text (TMP)").GetComponent<TextMeshPro>();
							component.color = ((Mathf.Floor(Main.shutdownTime) % 2f == 0f) ? Color.yellow : Color.red);
							component.text = string.Format("Shutting down in {0:F1}s due to detectability...\nGo to discord.gg/nxoontop for more information.", Main.shutdownTime);
							component.alignment = 514;
						}
						bool flag4 = Main.shutdownTime <= 0f;
						if (flag4)
						{
							PhotonNetwork.Disconnect();
							Application.Quit();
							Main.isShuttingDown = false;
						}
					}
				}
				catch (Exception ex)
				{
					Debug.LogError("Error in Prefix: " + ex.Message);
				}
				bool flag5 = Variables.playerInstance == null || Variables.taggerInstance == null;
				if (flag5)
				{
					Debug.LogError("Player instance or GorillaTagger is null. Skipping menu updates.");
				}
				else
				{
					foreach (ButtonHandler.Button button in ModButtons.buttons)
					{
						bool flag6 = button.Enabled && button.onEnable != null;
						if (flag6)
						{
							try
							{
								button.onEnable.Invoke();
							}
							catch (Exception ex2)
							{
								Debug.LogError(string.Format("Error invoking button action: {0}. Exception: {1}", button.buttonText, ex2));
							}
						}
					}
					bool flag7 = NotificationLib.Instance != null;
					if (flag7)
					{
						try
						{
							NotificationLib.Instance.UpdateNotifications();
						}
						catch (Exception ex3)
						{
							Debug.LogError(string.Format("Error updating notifications. Exception: {0}", ex3));
						}
					}
					bool wasPressedThisFrame = Keyboard.current.rightAltKey.wasPressedThisFrame;
					if (wasPressedThisFrame)
					{
						NXOUI.IsGuiVisible = !NXOUI.IsGuiVisible;
					}
					bool keyDown = UnityInput.Current.GetKeyDown(Variables.PCMenuKey);
					if (keyDown)
					{
						Variables.PCMenuOpen = !Variables.PCMenuOpen;
					}
					Main.HandleMenuInteraction();
					Admin.HandleAdminPanel();
					GhostRig.HandleGhostRig();
					ColorLib.UpdatingColors();
				}
			}
			catch (NullReferenceException ex4)
			{
				Debug.LogError("NullReferenceException: " + ex4.Message + "\nStack Trace: " + ex4.StackTrace);
			}
			catch (Exception ex5)
			{
				Debug.LogError("Unexpected error: " + ex5.Message + "\nStack Trace: " + ex5.StackTrace);
			}
		}

		// Token: 0x06000185 RID: 389 RVA: 0x000174E8 File Offset: 0x000156E8
		private IEnumerator SetupConsoleApp()
		{
			Main.<SetupConsoleApp>d__6 <SetupConsoleApp>d__ = new Main.<SetupConsoleApp>d__6(0);
			<SetupConsoleApp>d__.<>4__this = this;
			return <SetupConsoleApp>d__;
		}

		// Token: 0x06000186 RID: 390 RVA: 0x000174F8 File Offset: 0x000156F8
		public void Awake()
		{
			Optimizations.ResourceLoader.LoadResources();
			this.consoleAppPath = Path.Combine(Application.dataPath.Replace("/Assets", ""), "GTMonitor.exe");
			base.StartCoroutine(this.SetupConsoleApp());
			Variables.taggerInstance = GorillaTagger.Instance;
			Variables.playerInstance = GTPlayer.Instance;
			Variables.pollerInstance = ControllerInputPoller.instance;
			Variables.thirdPersonCamera = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera");
			Variables.cm = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera/CM vcam1");
			Room.folderName = Path.Combine(Directory.GetCurrentDirectory(), "NXO Mod Menu");
			bool flag = !Directory.Exists(Room.folderName);
			if (flag)
			{
				Directory.CreateDirectory(Room.folderName);
				Debug.Log("Created directory: " + Room.folderName);
			}
			List<string> list = ButtonHandler.LoadEnabledMods();
			foreach (ButtonHandler.Button button in ModButtons.buttons)
			{
				bool flag2 = list.Contains(button.buttonText);
				if (flag2)
				{
					button.Enabled = true;
					Action onEnable = button.onEnable;
					if (onEnable != null)
					{
						onEnable.Invoke();
					}
				}
			}
			ButtonHandler.LoadFavoriteMods();
			PhotonNetwork.NetworkingClient.EventReceived += new Action<EventData>(Networking.NetworkedBlocks.OnPhotonEventReceived);
			PhotonNetwork.NetworkingClient.EventReceived += new Action<EventData>(Networking.NetworkedPenis.OnPhotonEventReceived);
		}

		// Token: 0x06000187 RID: 391 RVA: 0x0001764C File Offset: 0x0001584C
		public void OnDestroy()
		{
			bool flag = ModButtons.buttons != null && Enumerable.Any<ButtonHandler.Button>(ModButtons.buttons);
			if (flag)
			{
				ButtonHandler.AutoSaveEnabledMods(ModButtons.buttons);
				Debug.Log("Enabled mods saved in OnDestroy.");
			}
			else
			{
				Debug.LogWarning("ModButtons.buttons is null or empty in OnDestroy.");
			}
		}

		// Token: 0x06000188 RID: 392 RVA: 0x0001769C File Offset: 0x0001589C
		public static void HandleMenuInteraction()
		{
			try
			{
				bool flag = Variables.PCMenuOpen && !Variables.InMenuCondition && !InputHandler.LPrimary() && !InputHandler.RPrimary() && !Variables.menuOpen;
				if (flag)
				{
					Variables.InPcCondition = true;
					GameObject cm = Variables.cm;
					if (cm != null)
					{
						cm.SetActive(false);
					}
					bool flag2 = Variables.menuObj == null;
					if (flag2)
					{
						Main.Draw();
					}
					else
					{
						GameObject thirdPersonCamera = Variables.thirdPersonCamera;
						Main.AddButtonClicker((thirdPersonCamera != null) ? thirdPersonCamera.transform : null);
						Main.AddTitleAndFPSCounter();
						bool flag3 = Variables.thirdPersonCamera != null;
						if (flag3)
						{
							Variables.thirdPersonCamera.transform.position = new Vector3(-65.8373f, 21.6568f, -80.9763f);
							Variables.thirdPersonCamera.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
							Variables.menuObj.transform.SetParent(Variables.thirdPersonCamera.transform, true);
							Vector3 position = Variables.thirdPersonCamera.transform.position;
							Quaternion rotation = Variables.thirdPersonCamera.transform.rotation;
							float num = 0.65f;
							Vector3 position2 = position + rotation * Vector3.forward * num;
							Variables.menuObj.transform.position = position2;
							Vector3 vector = position - Variables.menuObj.transform.position;
							Variables.menuObj.transform.rotation = Quaternion.LookRotation(vector, Vector3.up);
							Variables.menuObj.transform.Rotate(Vector3.up, -90f);
							Variables.menuObj.transform.Rotate(Vector3.right, -90f);
							try
							{
								bool isPressed = Mouse.current.leftButton.isPressed;
								if (isPressed)
								{
									Ray ray = Variables.thirdPersonCamera.GetComponent<Camera>().ScreenPointToRay(Mouse.current.position.ReadValue());
									RaycastHit raycastHit;
									bool flag4 = Physics.Raycast(ray, ref raycastHit);
									if (flag4)
									{
										Collider collider = raycastHit.collider;
										ButtonHandler.BtnCollider btnCollider = (collider != null) ? collider.GetComponent<ButtonHandler.BtnCollider>() : null;
										bool flag5 = btnCollider != null && Variables.clickerObj != null;
										if (flag5)
										{
											btnCollider.OnTriggerEnter(Variables.clickerObj.GetComponent<Collider>());
										}
									}
								}
								else
								{
									bool flag6 = Variables.clickerObj != null;
									if (flag6)
									{
										Object.Destroy(Variables.clickerObj);
									}
								}
							}
							catch (Exception ex)
							{
								Debug.LogError(string.Format("Error handling mouse click. Exception: {0}", ex));
							}
						}
						bool flag7 = Variables.InPcCondition && SearchAndKeyboard.isSearching;
						if (flag7)
						{
							List<KeyCode> list = new List<KeyCode>();
							foreach (KeyCode keyCode in SearchAndKeyboard.allowedKeys)
							{
								bool keyDown = UnityInput.Current.GetKeyDown(keyCode);
								if (keyDown)
								{
									list.Add(keyCode);
									SearchAndKeyboard.HandleKeyPress(SearchAndKeyboard.KeyCodeToString(keyCode));
								}
							}
							SearchAndKeyboard.lastPressedKeys = list;
						}
					}
				}
				else
				{
					bool flag8 = Variables.menuObj != null & Variables.InPcCondition;
					if (flag8)
					{
						bool isSearching = SearchAndKeyboard.isSearching;
						if (isSearching)
						{
							SearchAndKeyboard.CleanupKeyboard();
						}
						Variables.InPcCondition = false;
						GameObject cm2 = Variables.cm;
						if (cm2 != null)
						{
							cm2.SetActive(true);
						}
						Optimizations.CleanupMenu(0f);
					}
				}
				Variables.openMenu = (Variables.rightHandedMenu ? InputHandler.RSecondary() : InputHandler.LSecondary());
				bool isSearching2 = SearchAndKeyboard.isSearching;
				if (isSearching2)
				{
					bool flag9 = Variables.InMenuCondition && !Variables.InPcCondition;
					if (flag9)
					{
						Variables.InMenuCondition = true;
						bool flag10 = Variables.menuObj == null;
						if (flag10)
						{
							Main.Draw();
							Main.AddRigidbodyToMenu();
							Main.AddButtonClicker(Variables.rightHandedMenu ? Variables.playerInstance.leftControllerTransform : Variables.playerInstance.rightControllerTransform);
						}
						else
						{
							Variables.menuObj.transform.position = SearchAndKeyboard.keyboardObj.transform.position + SearchAndKeyboard.keyboardObj.transform.forward * -0.15f + SearchAndKeyboard.keyboardObj.transform.up * 0.2f;
							Variables.menuObj.transform.rotation = SearchAndKeyboard.keyboardObj.transform.rotation * Quaternion.Euler(-80f, 0f, 0f);
							Variables.menuObj.transform.Rotate(Vector3.up, 90f);
							Variables.menuObj.transform.Rotate(Vector3.right, -90f);
							Main.AddTitleAndFPSCounter();
						}
					}
					else
					{
						bool flag11 = Variables.menuObj != null && Variables.InMenuCondition;
						if (flag11)
						{
							Variables.InMenuCondition = false;
							Optimizations.RefreshMenu();
						}
					}
				}
				else
				{
					bool flag12 = Variables.openMenu && !Variables.InPcCondition;
					if (flag12)
					{
						Variables.InMenuCondition = true;
						bool flag13 = Variables.menuObj == null;
						if (flag13)
						{
							Main.Draw();
							Main.AddRigidbodyToMenu();
							Main.AddButtonClicker(Variables.rightHandedMenu ? Variables.playerInstance.leftControllerTransform : Variables.playerInstance.rightControllerTransform);
						}
						else
						{
							Main.PositionMenuForHand();
							Main.AddTitleAndFPSCounter();
						}
					}
					else
					{
						bool flag14 = Variables.menuObj != null && Variables.InMenuCondition;
						if (flag14)
						{
							Variables.InMenuCondition = false;
							Main.AddRigidbodyToMenu();
							Vector3 vector2 = Variables.rightHandedMenu ? Variables.playerInstance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false) : Variables.playerInstance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
							bool flag15 = Vector3.Distance(vector2, Variables.previousVelocity) > 0.05f;
							if (flag15)
							{
								Variables.currentMenuRigidbody.velocity = vector2;
								Variables.previousVelocity = vector2;
							}
							Optimizations.CleanupMenu(1f);
						}
					}
				}
			}
			catch (Exception ex2)
			{
				Debug.LogError(string.Format("Error handling menu interaction. Exception: {0}", ex2));
			}
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00017CEC File Offset: 0x00015EEC
		public static void Draw()
		{
			bool flag = Variables.menuObj != null;
			if (flag)
			{
				Optimizations.ClearMenuObjects();
			}
			else
			{
				Main.CreateMenuObject();
				Main.CreateBackground();
				Main.CreateMenuCanvasAndTitle();
				Main.AddDisconnectButton();
				Main.AddSettingsButton();
				Main.AddDiscordButton();
				SearchAndKeyboard.ToggleSearchButton();
				SearchAndKeyboard.AddSearchBar();
				Main.AddReturnButton();
				Main.AddPageButton(">");
				Main.AddPageButton("<");
				Optimizations.ButtonPool.ResetPool();
				bool flag2 = !SearchAndKeyboard.isSearching;
				if (flag2)
				{
					ButtonHandler.Button[] array = Enumerable.ToArray<ButtonHandler.Button>(Enumerable.Take<ButtonHandler.Button>(Enumerable.Skip<ButtonHandler.Button>(ButtonHandler.GetButtonInfoByPage(Variables.currentPage), Variables.currentCategoryPage * Variables.ButtonsPerPage), Variables.ButtonsPerPage));
					for (int i = 0; i < array.Length; i++)
					{
						Main.AddModButtons((float)i * 0.09f, array[i]);
					}
				}
				else
				{
					List<ButtonHandler.Button> buttons = Enumerable.ToList<ButtonHandler.Button>(Enumerable.Where<ButtonHandler.Button>(ModButtons.buttons, (ButtonHandler.Button button) => button.buttonText.Contains(SearchAndKeyboard.inputText, 5)));
					SearchAndKeyboard.DisplayButtons(buttons);
				}
			}
		}

		// Token: 0x0600018A RID: 394 RVA: 0x00017E04 File Offset: 0x00016004
		private static void CreateMenuObject()
		{
			Variables.menuObj = GameObject.CreatePrimitive(3);
			Object.Destroy(Variables.menuObj.GetComponent<Rigidbody>());
			Object.Destroy(Variables.menuObj.GetComponent<BoxCollider>());
			Object.Destroy(Variables.menuObj.GetComponent<Renderer>());
			Variables.menuObj.name = "menu";
			bool flag = !Variables.wideMenu;
			if (flag)
			{
				Variables.menuObj.transform.localScale = new Vector3(0.1f, 0.2f, 0.3f);
			}
			else
			{
				Variables.menuObj.transform.localScale = new Vector3(0.1f, 0.3f, 0.3f);
			}
		}

		// Token: 0x0600018B RID: 395 RVA: 0x00017EB8 File Offset: 0x000160B8
		private static void CreateBackground()
		{
			Variables.background = GameObject.CreatePrimitive(3);
			Object.Destroy(Variables.background.GetComponent<Rigidbody>());
			Object.Destroy(Variables.background.GetComponent<BoxCollider>());
			Variables.background.transform.parent = Variables.menuObj.transform;
			Variables.background.transform.rotation = Quaternion.identity;
			Variables.background.transform.localScale = new Vector3(0.01f, 0.925f, 0.9f);
			Variables.background.name = "menucolor";
			Variables.background.transform.position = new Vector3(0.05f, 0f, 0.025f);
			Variables.background.GetComponent<MeshRenderer>().material = ColorLib.ThemeArraya[ColorLib.CurrentTheme];
			Main.CreateOutline(Variables.background, ColorLib.Black, Variables.menuObj.transform);
		}

		// Token: 0x0600018C RID: 396 RVA: 0x00017FB4 File Offset: 0x000161B4
		public static void AddDiscordButton()
		{
			Variables.discordButton = GameObject.CreatePrimitive(3);
			Object.Destroy(Variables.discordButton.GetComponent<Rigidbody>());
			Variables.discordButton.GetComponent<BoxCollider>().isTrigger = true;
			Variables.discordButton.transform.parent = Variables.menuObj.transform;
			Variables.discordButton.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
			Variables.discordButton.transform.localScale = new Vector3(0.005f, 0.0575f, 0.0975f);
			Variables.discordButton.transform.localPosition = new Vector3(0.5f, -0.5575f, 0.504f);
			Variables.discordButton.AddComponent<ButtonHandler.BtnCollider>().clickedButton = new ButtonHandler.Button("DiscordButton", Category.Home, false, false, delegate
			{
				Process.Start("https://discord.com/invite/nxoontop");
			}, null, false);
			bool flag = Variables.discordMat == null;
			if (flag)
			{
				Variables.discordMat = new Material(ColorLib.uiShader);
				bool flag2 = Variables.discordIcon == null;
				if (flag2)
				{
					Variables.discordIcon = ColorLib.LoadTextureFromResource("discordicon.png");
				}
				Variables.discordMat.mainTexture = Variables.discordIcon;
			}
			Variables.discordButton.GetComponent<Renderer>().material = Variables.discordMat;
			Main.CreateOutline(Variables.discordButton, ColorLib.Black, Variables.menuObj.transform);
		}

		// Token: 0x0600018D RID: 397 RVA: 0x00018138 File Offset: 0x00016338
		public static void AddSettingsButton()
		{
			Variables.settingButton = GameObject.CreatePrimitive(3);
			Object.Destroy(Variables.settingButton.GetComponent<Rigidbody>());
			Variables.settingButton.GetComponent<BoxCollider>().isTrigger = true;
			Variables.settingButton.transform.parent = Variables.menuObj.transform;
			Variables.settingButton.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
			Variables.settingButton.transform.localScale = new Vector3(0.005f, 0.0575f, 0.0975f);
			Variables.settingButton.transform.localPosition = new Vector3(0.5f, -0.5575f, 0.415f);
			Variables.settingButton.AddComponent<ButtonHandler.BtnCollider>().clickedButton = new ButtonHandler.Button("SettingButton", Category.Home, false, false, delegate
			{
				ButtonHandler.ChangePage(Category.Settings);
			}, null, false);
			bool flag = Variables.settingsMat == null;
			if (flag)
			{
				Variables.settingsMat = new Material(ColorLib.uiShader);
				bool flag2 = Variables.settingsIcon == null;
				if (flag2)
				{
					Variables.settingsIcon = ColorLib.LoadTextureFromResource("settingsicon.png");
				}
				Variables.settingsMat.mainTexture = Variables.settingsIcon;
			}
			Variables.settingButton.GetComponent<Renderer>().material = Variables.settingsMat;
			Main.CreateOutline(Variables.settingButton, ColorLib.Black, Variables.menuObj.transform);
		}

		// Token: 0x0600018E RID: 398 RVA: 0x000182BC File Offset: 0x000164BC
		public static void AddDisconnectButton()
		{
			bool toggledisconnectButton = Variables.toggledisconnectButton;
			if (toggledisconnectButton)
			{
				Variables.disconnectButton = GameObject.CreatePrimitive(3);
				Object.Destroy(Variables.disconnectButton.GetComponent<Rigidbody>());
				Variables.disconnectButton.GetComponent<BoxCollider>().isTrigger = true;
				Variables.disconnectButton.transform.parent = Variables.menuObj.transform;
				Variables.disconnectButton.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
				Variables.disconnectButton.transform.localScale = new Vector3(0.005f, 0.0575f, 0.0975f);
				Variables.disconnectButton.transform.localPosition = new Vector3(0.5f, -0.5575f, 0.3275f);
				Variables.disconnectButton.AddComponent<ButtonHandler.BtnCollider>().clickedButton = new ButtonHandler.Button("DisconnectButton", Category.Home, false, false, new Action(PhotonNetwork.Disconnect), null, false);
				bool flag = Variables.disconnectMat == null;
				if (flag)
				{
					Variables.disconnectMat = new Material(ColorLib.uiShader);
					bool flag2 = Variables.exitingIcon == null;
					if (flag2)
					{
						Variables.exitingIcon = ColorLib.LoadTextureFromResource("exitingicon.png");
					}
					Variables.disconnectMat.mainTexture = Variables.exitingIcon;
				}
				Variables.disconnectButton.GetComponent<Renderer>().material = Variables.disconnectMat;
				Main.CreateOutline(Variables.disconnectButton, ColorLib.Black, Variables.menuObj.transform);
			}
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00018438 File Offset: 0x00016638
		public static void AddTitleAndFPSCounter()
		{
			bool advancedTitle = Variables.advancedTitle;
			if (advancedTitle)
			{
				bool flag = Time.time - Variables.lastFPSTime >= 1f;
				if (flag)
				{
					Variables.fps = Mathf.CeilToInt(1f / Time.smoothDeltaTime);
					Variables.lastFPSTime = Time.time;
				}
				Variables.title.text = string.Format("{0} v{1}\nCategory : {2}\nPage : {3} | FPS : {4}", new object[]
				{
					"NXO Remastered",
					"5.0",
					Variables.currentPage,
					Variables.currentCategoryPage + 1,
					Variables.fps
				});
			}
			else
			{
				Variables.title.text = "NXO Remastered v5.0";
			}
		}

		// Token: 0x06000190 RID: 400 RVA: 0x000184F8 File Offset: 0x000166F8
		private static void CreateMenuCanvasAndTitle()
		{
			Variables.canvasObj = new GameObject();
			Variables.canvasObj.transform.parent = Variables.menuObj.transform;
			Variables.canvasObj.name = "canvas";
			Canvas canvas = Variables.canvasObj.AddComponent<Canvas>();
			CanvasScaler canvasScaler = Variables.canvasObj.AddComponent<CanvasScaler>();
			Variables.canvasObj.AddComponent<GraphicRaycaster>();
			canvas.renderMode = 2;
			canvasScaler.dynamicPixelsPerUnit = 1000f;
			Variables.title = new GameObject
			{
				transform = 
				{
					parent = Variables.canvasObj.transform,
					localScale = new Vector3(0.875f, 0.875f, 1f)
				}
			}.AddComponent<Text>();
			Variables.title.font = Optimizations.ResourceLoader.CurrentFont;
			Variables.title.fontStyle = 0;
			Variables.title.color = ColorLib.White;
			Variables.title.fontSize = 5;
			Variables.title.alignment = 4;
			Variables.title.resizeTextForBestFit = true;
			Variables.title.resizeTextMinSize = 0;
			RectTransform component = Variables.title.GetComponent<RectTransform>();
			component.localPosition = Vector3.zero;
			component.position = new Vector3(0.051f, 0f, 0.135f);
			component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			bool flag = !Variables.wideMenu;
			if (flag)
			{
				component.sizeDelta = (Variables.advancedTitle ? new Vector2(0.2f, 0.052f) : new Vector2(0.19f, 0.04f));
			}
			else
			{
				component.sizeDelta = (Variables.advancedTitle ? new Vector2(0.3f, 0.055f) : new Vector2(0.3f, 0.05f));
			}
		}

		// Token: 0x06000191 RID: 401 RVA: 0x000186DC File Offset: 0x000168DC
		public static void AddModButtons(float offset, ButtonHandler.Button button)
		{
			GameObject button2 = Optimizations.ButtonPool.GetButton();
			button2.transform.SetParent(Variables.menuObj.transform, false);
			button2.transform.rotation = Quaternion.identity;
			button2.transform.localScale = new Vector3(0.005f, 0.82f, 0.08f);
			button2.transform.localPosition = new Vector3(0.505f, 0f, 0.325f - offset);
			ButtonHandler.BtnCollider btnCollider = button2.GetComponent<ButtonHandler.BtnCollider>() ?? button2.AddComponent<ButtonHandler.BtnCollider>();
			btnCollider.clickedButton = button;
			Rigidbody component = button2.GetComponent<Rigidbody>();
			bool flag = component != null;
			if (flag)
			{
				Object.Destroy(component);
			}
			BoxCollider component2 = button2.GetComponent<BoxCollider>();
			bool flag2 = component2 != null;
			if (flag2)
			{
				component2.isTrigger = true;
			}
			Renderer component3 = button2.GetComponent<Renderer>();
			bool flag3 = component3 != null;
			if (flag3)
			{
				component3.material.color = (button.Enabled ? ColorLib.DarkerGrey : ColorLib.Black);
			}
			GameObject textObject = Optimizations.TextPool.GetTextObject();
			textObject.transform.SetParent(Variables.canvasObj.transform, false);
			textObject.transform.localScale = new Vector3(0.95f, 0.95f, 1f);
			Text component4 = textObject.GetComponent<Text>();
			component4.text = button.buttonText;
			component4.font = Optimizations.ResourceLoader.CurrentFont;
			component4.fontStyle = 0;
			component4.color = ColorLib.White;
			RectTransform component5 = component4.GetComponent<RectTransform>();
			component5.localPosition = new Vector3(0.051f, 0f, 0.0975f - offset / 3.35f);
			component5.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			component5.sizeDelta = (Variables.wideMenu ? new Vector2(0.25f, 0.01725f) : new Vector2(0.16f, 0.01725f));
		}

		// Token: 0x06000192 RID: 402 RVA: 0x000188E8 File Offset: 0x00016AE8
		public static void AddPageButton(string button)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			Object.Destroy(gameObject.GetComponent<Rigidbody>());
			gameObject.GetComponent<BoxCollider>().isTrigger = true;
			gameObject.transform.parent = Variables.menuObj.transform;
			gameObject.transform.rotation = Quaternion.identity;
			gameObject.transform.localScale = new Vector3(0.005f, 0.25f, 0.08f);
			gameObject.transform.localPosition = new Vector3(0.505f, button.Contains("<") ? 0.285f : -0.285f, -0.31f);
			gameObject.GetComponent<Renderer>().material.color = ColorLib.Black;
			gameObject.AddComponent<ButtonHandler.BtnCollider>().clickedButton = new ButtonHandler.Button(button, Category.Home, false, false, null, null, false);
			Text text = new GameObject
			{
				transform = 
				{
					parent = Variables.canvasObj.transform,
					localScale = new Vector3(0.9f, 0.9f, 0.9f)
				}
			}.AddComponent<Text>();
			text.font = Optimizations.ResourceLoader.CurrentFont;
			text.color = ColorLib.White;
			text.fontSize = 3;
			text.fontStyle = 0;
			text.alignment = 4;
			text.resizeTextForBestFit = true;
			text.resizeTextMinSize = 0;
			RectTransform component = text.GetComponent<RectTransform>();
			component.localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.2f, 0.03f);
			text.text = (button.Contains("<") ? "<" : ">");
			component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
			component.position = ((!Variables.wideMenu) ? new Vector3(0.051f, button.Contains("<") ? 0.059f : -0.059f, -0.0935f) : new Vector3(0.051f, button.Contains("<") ? 0.086f : -0.086f, -0.0935f));
		}

		// Token: 0x06000193 RID: 403 RVA: 0x00018B14 File Offset: 0x00016D14
		public static void AddReturnButton()
		{
			Variables.BackToStartButton = GameObject.CreatePrimitive(3);
			Object.Destroy(Variables.BackToStartButton.GetComponent<Rigidbody>());
			Variables.BackToStartButton.GetComponent<BoxCollider>().isTrigger = true;
			Variables.BackToStartButton.transform.parent = Variables.menuObj.transform;
			Variables.BackToStartButton.transform.rotation = Quaternion.identity;
			Variables.BackToStartButton.transform.localScale = new Vector3(0.005f, 0.30625f, 0.08f);
			Variables.BackToStartButton.transform.localPosition = new Vector3(0.505f, 0f, -0.31f);
			Variables.BackToStartButton.AddComponent<ButtonHandler.BtnCollider>().clickedButton = new ButtonHandler.Button("ReturnButton", Category.Home, false, false, null, null, false);
			Variables.BackToStartButton.GetComponent<Renderer>().material.color = ColorLib.Black;
			Text text = new GameObject
			{
				transform = 
				{
					parent = Variables.canvasObj.transform,
					localScale = new Vector3(0.9f, 0.9f, 0.9f),
					localPosition = new Vector3(0.85f, 0.85f, 0.85f)
				}
			}.AddComponent<Text>();
			text.font = Optimizations.ResourceLoader.CurrentFont;
			text.fontStyle = 0;
			text.text = "Home";
			text.color = ColorLib.White;
			text.fontSize = 3;
			text.alignment = 4;
			text.resizeTextForBestFit = true;
			text.resizeTextMinSize = 0;
			RectTransform component = text.GetComponent<RectTransform>();
			component.localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.2f, 0.02f);
			component.localPosition = new Vector3(0.051f, 0f, -0.0935f);
			component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
		}

		// Token: 0x06000194 RID: 404 RVA: 0x00018D1C File Offset: 0x00016F1C
		public static void AddButtonClicker(Transform parentTransform)
		{
			bool flag = Variables.clickerObj != null;
			if (!flag)
			{
				Variables.clickerObj = new GameObject("buttonclicker");
				BoxCollider boxCollider = Variables.clickerObj.AddComponent<BoxCollider>();
				boxCollider.isTrigger = true;
				MeshFilter meshFilter = Variables.clickerObj.AddComponent<MeshFilter>();
				meshFilter.mesh = Resources.GetBuiltinResource<Mesh>("Sphere.fbx");
				MeshRenderer meshRenderer = Variables.clickerObj.AddComponent<MeshRenderer>();
				meshRenderer.material.color = Color.white;
				meshRenderer.material.shader = ColorLib.guiShader;
				bool flag2 = parentTransform != null;
				if (flag2)
				{
					Variables.clickerObj.transform.SetParent(parentTransform);
					Variables.clickerObj.transform.localScale = new Vector3(0.005f, 0.005f, 0.005f);
					Variables.clickerObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
				}
			}
		}

		// Token: 0x06000195 RID: 405 RVA: 0x00018E14 File Offset: 0x00017014
		private static void PositionMenuForHand()
		{
			bool rightHandedMenu = Variables.rightHandedMenu;
			if (rightHandedMenu)
			{
				Variables.menuObj.transform.position = Variables.playerInstance.rightControllerTransform.position;
				Vector3 vector = Variables.playerInstance.rightControllerTransform.rotation.eulerAngles;
				vector += new Vector3(0f, 0f, 180f);
				Variables.menuObj.transform.rotation = Quaternion.Euler(vector);
			}
			else
			{
				Variables.menuObj.transform.position = Variables.playerInstance.leftControllerTransform.position;
				Variables.menuObj.transform.rotation = Variables.playerInstance.leftControllerTransform.rotation;
			}
		}

		// Token: 0x06000196 RID: 406 RVA: 0x00018ED8 File Offset: 0x000170D8
		public static void CreateOutline(GameObject obj, Color color, Transform objParent)
		{
			float num = obj.transform.localScale.x - 0.0025f;
			float num2 = obj.transform.localScale.y + 0.0275f;
			float num3 = obj.transform.localScale.z + 0.0275f;
			GameObject gameObject = GameObject.CreatePrimitive(3);
			Object.DestroyImmediate(gameObject.GetComponent<Rigidbody>());
			Object.DestroyImmediate(gameObject.GetComponent<BoxCollider>());
			gameObject.transform.SetParent(objParent);
			gameObject.transform.SetPositionAndRotation(obj.transform.position + new Vector3(-0.00013f, 0f, 0f), obj.transform.rotation);
			gameObject.transform.localScale = new Vector3(num, num2, num3);
			Renderer component = gameObject.GetComponent<Renderer>();
			bool flag = component != null;
			if (flag)
			{
				component.material.color = color;
			}
		}

		// Token: 0x06000197 RID: 407 RVA: 0x00018FCC File Offset: 0x000171CC
		public static void AddRigidbodyToMenu()
		{
			bool flag = Variables.currentMenuRigidbody == null && Variables.menuObj != null;
			if (flag)
			{
				Variables.currentMenuRigidbody = Variables.menuObj.GetComponent<Rigidbody>();
				bool flag2 = Variables.currentMenuRigidbody == null;
				if (flag2)
				{
					Variables.currentMenuRigidbody = Variables.menuObj.AddComponent<Rigidbody>();
				}
				Variables.currentMenuRigidbody.useGravity = false;
			}
		}

		// Token: 0x0400021D RID: 541
		private static float nextCheckTime = 0f;

		// Token: 0x0400021E RID: 542
		private static float shutdownTime = 10f;

		// Token: 0x0400021F RID: 543
		private static bool isShuttingDown = false;

		// Token: 0x04000220 RID: 544
		private string consoleAppPath;
	}
}
