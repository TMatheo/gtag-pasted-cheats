﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using NXO.Utilities;
using UnityEngine;
using UnityEngine.UI;

namespace NXO.Menu
{
	// Token: 0x0200002D RID: 45
	[NullableContext(1)]
	[Nullable(0)]
	public class Optimizations
	{
		// Token: 0x0600019B RID: 411 RVA: 0x000190B0 File Offset: 0x000172B0
		public static void DestroyAndNullify<[Nullable(0)] T>(ref T obj, float delay = 0f) where T : Object
		{
			bool flag = obj != null;
			if (flag)
			{
				Component component = obj as Component;
				bool flag2 = component != null;
				if (flag2)
				{
					Object.Destroy(component.gameObject, delay);
				}
				else
				{
					Object.Destroy(obj, delay);
				}
				obj = default(T);
			}
		}

		// Token: 0x0600019C RID: 412 RVA: 0x0001911A File Offset: 0x0001731A
		public static void CleanupMenu(float delay = 0f)
		{
			Object.Destroy(Variables.menuObj, delay);
			Object.Destroy(Variables.clickerObj);
			Variables.currentMenuRigidbody = null;
		}

		// Token: 0x0600019D RID: 413 RVA: 0x0001913C File Offset: 0x0001733C
		public static void ClearMenuObjects()
		{
			GameObject[] array = new GameObject[]
			{
				Variables.menuObj,
				Variables.background,
				Variables.canvasObj,
				Variables.disconnectButton,
				Variables.settingButton,
				SearchAndKeyboard.searchBar,
				Variables.searchButton,
				Variables.discordButton
			};
			foreach (GameObject gameObject in array)
			{
				bool flag = gameObject != null;
				if (flag)
				{
					Object.Destroy(gameObject);
				}
			}
			Variables.currentMenuRigidbody = null;
		}

		// Token: 0x0600019E RID: 414 RVA: 0x000191C4 File Offset: 0x000173C4
		public static void RefreshMenu()
		{
			Optimizations.ClearMenuObjects();
			Main.Draw();
		}

		// Token: 0x02000073 RID: 115
		[Nullable(0)]
		public static class ButtonPool
		{
			// Token: 0x060003D5 RID: 981 RVA: 0x0001DB2C File Offset: 0x0001BD2C
			public static GameObject GetButton()
			{
				bool flag = Optimizations.ButtonPool.currentIndex < Optimizations.ButtonPool.buttonPool.Count;
				GameObject result;
				if (flag)
				{
					GameObject gameObject = Optimizations.ButtonPool.buttonPool[Optimizations.ButtonPool.currentIndex];
					bool flag2 = gameObject == null;
					if (flag2)
					{
						gameObject = Optimizations.ButtonPool.CreateNewButton();
						Optimizations.ButtonPool.buttonPool[Optimizations.ButtonPool.currentIndex] = gameObject;
					}
					gameObject.SetActive(true);
					Optimizations.ButtonPool.currentIndex++;
					result = gameObject;
				}
				else
				{
					GameObject gameObject2 = Optimizations.ButtonPool.CreateNewButton();
					Optimizations.ButtonPool.buttonPool.Add(gameObject2);
					Optimizations.ButtonPool.currentIndex++;
					result = gameObject2;
				}
				return result;
			}

			// Token: 0x060003D6 RID: 982 RVA: 0x0001DBC4 File Offset: 0x0001BDC4
			public static void ResetPool()
			{
				Optimizations.ButtonPool.currentIndex = 0;
				foreach (GameObject gameObject in Optimizations.ButtonPool.buttonPool)
				{
					bool flag = gameObject != null;
					if (flag)
					{
						gameObject.SetActive(false);
						gameObject.transform.parent = null;
					}
				}
			}

			// Token: 0x060003D7 RID: 983 RVA: 0x0001DC3C File Offset: 0x0001BE3C
			private static GameObject CreateNewButton()
			{
				GameObject gameObject = GameObject.CreatePrimitive(3);
				gameObject.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				return gameObject;
			}

			// Token: 0x040002D4 RID: 724
			private static List<GameObject> buttonPool = new List<GameObject>();

			// Token: 0x040002D5 RID: 725
			private static int currentIndex = 0;
		}

		// Token: 0x02000074 RID: 116
		[Nullable(0)]
		public static class TextPool
		{
			// Token: 0x060003D9 RID: 985 RVA: 0x0001DC88 File Offset: 0x0001BE88
			public static GameObject GetTextObject()
			{
				bool flag = Optimizations.TextPool.currentIndex < Optimizations.TextPool.textPool.Count;
				GameObject result;
				if (flag)
				{
					GameObject gameObject = Optimizations.TextPool.textPool[Optimizations.TextPool.currentIndex];
					bool flag2 = gameObject == null;
					if (flag2)
					{
						gameObject = Optimizations.TextPool.CreateNewTextObject();
						Optimizations.TextPool.textPool[Optimizations.TextPool.currentIndex] = gameObject;
					}
					gameObject.SetActive(true);
					Optimizations.TextPool.currentIndex++;
					result = gameObject;
				}
				else
				{
					GameObject gameObject2 = Optimizations.TextPool.CreateNewTextObject();
					Optimizations.TextPool.textPool.Add(gameObject2);
					Optimizations.TextPool.currentIndex++;
					result = gameObject2;
				}
				return result;
			}

			// Token: 0x060003DA RID: 986 RVA: 0x0001DD20 File Offset: 0x0001BF20
			public static void ResetPool()
			{
				Optimizations.TextPool.currentIndex = 0;
				foreach (GameObject gameObject in Optimizations.TextPool.textPool)
				{
					bool flag = gameObject != null;
					if (flag)
					{
						gameObject.SetActive(false);
					}
				}
			}

			// Token: 0x060003DB RID: 987 RVA: 0x0001DD8C File Offset: 0x0001BF8C
			private static GameObject CreateNewTextObject()
			{
				GameObject gameObject = new GameObject();
				Text text = gameObject.AddComponent<Text>();
				text.fontStyle = 0;
				text.color = ColorLib.White;
				text.alignment = 4;
				text.resizeTextForBestFit = true;
				text.resizeTextMinSize = 0;
				return gameObject;
			}

			// Token: 0x040002D6 RID: 726
			private static List<GameObject> textPool = new List<GameObject>();

			// Token: 0x040002D7 RID: 727
			private static int currentIndex = 0;
		}

		// Token: 0x02000075 RID: 117
		[Nullable(0)]
		public static class ResourceLoader
		{
			// Token: 0x1700002D RID: 45
			// (get) Token: 0x060003DD RID: 989 RVA: 0x0001DDEF File Offset: 0x0001BFEF
			// (set) Token: 0x060003DE RID: 990 RVA: 0x0001DDF6 File Offset: 0x0001BFF6
			public static Font ArialFont { get; private set; }

			// Token: 0x1700002E RID: 46
			// (get) Token: 0x060003DF RID: 991 RVA: 0x0001DDFE File Offset: 0x0001BFFE
			// (set) Token: 0x060003E0 RID: 992 RVA: 0x0001DE05 File Offset: 0x0001C005
			public static Font AgencyFont { get; private set; }

			// Token: 0x1700002F RID: 47
			// (get) Token: 0x060003E1 RID: 993 RVA: 0x0001DE0D File Offset: 0x0001C00D
			// (set) Token: 0x060003E2 RID: 994 RVA: 0x0001DE14 File Offset: 0x0001C014
			public static Font SansFont { get; private set; }

			// Token: 0x17000030 RID: 48
			// (get) Token: 0x060003E3 RID: 995 RVA: 0x0001DE1C File Offset: 0x0001C01C
			// (set) Token: 0x060003E4 RID: 996 RVA: 0x0001DE23 File Offset: 0x0001C023
			public static Font ImpactFont { get; private set; }

			// Token: 0x17000031 RID: 49
			// (get) Token: 0x060003E5 RID: 997 RVA: 0x0001DE2B File Offset: 0x0001C02B
			// (set) Token: 0x060003E6 RID: 998 RVA: 0x0001DE32 File Offset: 0x0001C032
			public static Font BubblyFont { get; private set; }

			// Token: 0x17000032 RID: 50
			// (get) Token: 0x060003E7 RID: 999 RVA: 0x0001DE3A File Offset: 0x0001C03A
			// (set) Token: 0x060003E8 RID: 1000 RVA: 0x0001DE41 File Offset: 0x0001C041
			public static Font MinecraftFont { get; private set; }

			// Token: 0x17000033 RID: 51
			// (get) Token: 0x060003E9 RID: 1001 RVA: 0x0001DE49 File Offset: 0x0001C049
			// (set) Token: 0x060003EA RID: 1002 RVA: 0x0001DE50 File Offset: 0x0001C050
			public static int CurrentFontIndex { get; private set; } = 0;

			// Token: 0x17000034 RID: 52
			// (get) Token: 0x060003EB RID: 1003 RVA: 0x0001DE58 File Offset: 0x0001C058
			public static string CurrentFontDescription
			{
				get
				{
					return Optimizations.ResourceLoader.FontDescriptions[Optimizations.ResourceLoader.CurrentFontIndex];
				}
			}

			// Token: 0x17000035 RID: 53
			// (get) Token: 0x060003EC RID: 1004 RVA: 0x0001DE65 File Offset: 0x0001C065
			public static Font CurrentFont
			{
				get
				{
					return Optimizations.ResourceLoader.Fonts[Optimizations.ResourceLoader.CurrentFontIndex];
				}
			}

			// Token: 0x060003ED RID: 1005 RVA: 0x0001DE74 File Offset: 0x0001C074
			public static void LoadResources()
			{
				Optimizations.ResourceLoader.ArialFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
				Optimizations.ResourceLoader.SansFont = Font.CreateDynamicFontFromOSFont("Comic Sans MS", 20);
				Optimizations.ResourceLoader.ImpactFont = Font.CreateDynamicFontFromOSFont("Impact", 20);
				Optimizations.ResourceLoader.bubblyFontBundle = AssetHandler.LoadFromResources("NXO.Resources.bubblyfont");
				bool flag = Optimizations.ResourceLoader.bubblyFontBundle != null;
				if (flag)
				{
					Optimizations.ResourceLoader.BubblyFont = AssetHandler.LoadFont(Optimizations.ResourceLoader.bubblyFontBundle, "Super Morning");
					bool flag2 = Optimizations.ResourceLoader.BubblyFont == null;
					if (flag2)
					{
						Debug.LogError("Failed to load Bubbly Font from the asset bundle.");
					}
				}
				else
				{
					Debug.LogError("Failed to load Bubbly Font bundle.");
				}
				Optimizations.ResourceLoader.minecraftFontBundle = AssetHandler.LoadFromResources("NXO.Resources.minecraftfont");
				bool flag3 = Optimizations.ResourceLoader.minecraftFontBundle != null;
				if (flag3)
				{
					Optimizations.ResourceLoader.MinecraftFont = AssetHandler.LoadFont(Optimizations.ResourceLoader.minecraftFontBundle, "Minecraftia-Regular");
					bool flag4 = Optimizations.ResourceLoader.MinecraftFont == null;
					if (flag4)
					{
						Debug.LogError("Failed to load Minecraft Font from the asset bundle.");
					}
				}
				else
				{
					Debug.LogError("Failed to load Minecraft Font bundle.");
				}
				Optimizations.ResourceLoader.Fonts[0] = Optimizations.ResourceLoader.MinecraftFont;
				Optimizations.ResourceLoader.Fonts[1] = Optimizations.ResourceLoader.BubblyFont;
				Optimizations.ResourceLoader.Fonts[2] = Optimizations.ResourceLoader.ArialFont;
				Optimizations.ResourceLoader.Fonts[3] = Optimizations.ResourceLoader.SansFont;
				Optimizations.ResourceLoader.Fonts[4] = Optimizations.ResourceLoader.ImpactFont;
			}

			// Token: 0x060003EE RID: 1006 RVA: 0x0001DFB4 File Offset: 0x0001C1B4
			public static void CycleFont()
			{
				Optimizations.ResourceLoader.CurrentFontIndex = (Optimizations.ResourceLoader.CurrentFontIndex + 1) % Optimizations.ResourceLoader.Fonts.Length;
				bool flag = Optimizations.ResourceLoader.CycleMenuFontButton != null;
				if (flag)
				{
					Optimizations.ResourceLoader.CycleMenuFontButton.buttonText = "Menu Font: " + Optimizations.ResourceLoader.CurrentFontDescription;
				}
			}

			// Token: 0x060003EF RID: 1007 RVA: 0x0001E000 File Offset: 0x0001C200
			public static void UnloadResources()
			{
				bool flag = Optimizations.ResourceLoader.bubblyFontBundle != null;
				if (flag)
				{
					AssetHandler.UnloadBundle(Optimizations.ResourceLoader.bubblyFontBundle, false);
					Optimizations.ResourceLoader.bubblyFontBundle = null;
					Optimizations.ResourceLoader.BubblyFont = null;
				}
				bool flag2 = Optimizations.ResourceLoader.minecraftFontBundle != null;
				if (flag2)
				{
					AssetHandler.UnloadBundle(Optimizations.ResourceLoader.minecraftFontBundle, false);
					Optimizations.ResourceLoader.minecraftFontBundle = null;
					Optimizations.ResourceLoader.MinecraftFont = null;
				}
			}

			// Token: 0x040002DF RID: 735
			private static AssetBundle bubblyFontBundle;

			// Token: 0x040002E0 RID: 736
			private static AssetBundle minecraftFontBundle;

			// Token: 0x040002E1 RID: 737
			private static readonly string[] FontDescriptions = new string[]
			{
				"Minecraft",
				"Bubbly",
				"Arial",
				"Sans",
				"Impact"
			};

			// Token: 0x040002E2 RID: 738
			private static readonly Font[] Fonts = new Font[5];

			// Token: 0x040002E3 RID: 739
			public static ButtonHandler.Button CycleMenuFontButton;
		}
	}
}
