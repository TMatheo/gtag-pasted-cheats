﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using NXO.Mods;
using NXO.Mods.Categories;
using NXO.Utilities;
using UnityEngine;

namespace NXO.Menu
{
	// Token: 0x0200002A RID: 42
	[NullableContext(1)]
	[Nullable(0)]
	public class ButtonHandler
	{
		// Token: 0x06000170 RID: 368 RVA: 0x00016878 File Offset: 0x00014A78
		public static void Toggle(ButtonHandler.Button button)
		{
			string buttonText = button.buttonText;
			string text = buttonText;
			if (!(text == "<"))
			{
				if (!(text == ">"))
				{
					if (!(text == "ReturnButton"))
					{
						if (!(text == "Toggle Search Button"))
						{
							ButtonHandler.ToggleButton(button);
						}
						else
						{
							SearchAndKeyboard.ToggleKeyboard();
						}
					}
					else
					{
						ButtonHandler.ReturnToMainPage();
					}
				}
				else
				{
					ButtonHandler.NavigatePage(true);
				}
			}
			else
			{
				ButtonHandler.NavigatePage(false);
			}
		}

		// Token: 0x06000171 RID: 369 RVA: 0x000168F0 File Offset: 0x00014AF0
		private static void NavigatePage(bool forward)
		{
			int totalPages = ButtonHandler.GetTotalPages(Variables.currentPage);
			int num = totalPages - 1;
			Variables.currentCategoryPage += (forward ? 1 : -1);
			bool flag = Variables.currentCategoryPage < 0;
			if (flag)
			{
				Variables.currentCategoryPage = num;
			}
			else
			{
				bool flag2 = Variables.currentCategoryPage > num;
				if (flag2)
				{
					Variables.currentCategoryPage = 0;
				}
			}
			Optimizations.RefreshMenu();
		}

		// Token: 0x06000172 RID: 370 RVA: 0x0001694F File Offset: 0x00014B4F
		private static void ReturnToMainPage()
		{
			Variables.currentPage = Category.Home;
			Variables.currentCategoryPage = 0;
			Optimizations.RefreshMenu();
		}

		// Token: 0x06000173 RID: 371 RVA: 0x00016964 File Offset: 0x00014B64
		private static int GetTotalPages(Category page)
		{
			return (ButtonHandler.GetButtonInfoByPage(page).Count + Variables.ButtonsPerPage - 1) / Variables.ButtonsPerPage;
		}

		// Token: 0x06000174 RID: 372 RVA: 0x00016990 File Offset: 0x00014B90
		public static void ChangePage(Category page)
		{
			Variables.currentCategoryPage = 0;
			Variables.currentPage = page;
			bool flag = page == Category.Enabled;
			if (flag)
			{
				int num = Enumerable.Count<ButtonHandler.Button>(ModButtons.buttons, (ButtonHandler.Button button) => button.Enabled);
				NotificationLib.SendNotification(string.Format("<color=green>{0} Enabled Mods</color>", num));
			}
			Optimizations.RefreshMenu();
		}

		// Token: 0x06000175 RID: 373 RVA: 0x000169FC File Offset: 0x00014BFC
		public static void ToggleButton(ButtonHandler.Button button)
		{
			try
			{
				bool flag = !button.isToggle;
				if (flag)
				{
					Action onEnable = button.onEnable;
					if (onEnable != null)
					{
						onEnable.Invoke();
					}
					bool flag2 = button.Page == Variables.currentPage;
					if (flag2)
					{
						NotificationLib.SendNotification("<color=green>Enabled</color> : " + button.buttonText);
					}
					else
					{
						NotificationLib.SendNotification("<color=green>Entered Category</color> : " + button.buttonText);
					}
				}
				else
				{
					button.Enabled = !button.Enabled;
					bool enabled = button.Enabled;
					if (enabled)
					{
						Action onEnable2 = button.onEnable;
						if (onEnable2 != null)
						{
							onEnable2.Invoke();
						}
						NotificationLib.SendNotification("<color=green>Enabled</color> : " + button.buttonText);
						NXOUI.AddMod(button.buttonText);
					}
					else
					{
						Action onDisable = button.onDisable;
						if (onDisable != null)
						{
							onDisable.Invoke();
						}
						NotificationLib.SendNotification("<color=red>Disabled</color> : " + button.buttonText);
						NXOUI.RemoveMod(button.buttonText);
					}
				}
				Optimizations.RefreshMenu();
			}
			catch (Exception ex)
			{
				Debug.LogError(string.Concat(new string[]
				{
					"Error while toggling button '",
					button.buttonText,
					"': ",
					ex.Message,
					"\nStack Trace: ",
					ex.StackTrace
				}));
			}
		}

		// Token: 0x06000176 RID: 374 RVA: 0x00016B60 File Offset: 0x00014D60
		public static List<ButtonHandler.Button> GetButtonInfoByPage(Category page)
		{
			bool flag = page == Category.Enabled;
			List<ButtonHandler.Button> result;
			if (flag)
			{
				result = Enumerable.ToList<ButtonHandler.Button>(Enumerable.Where<ButtonHandler.Button>(ModButtons.buttons, (ButtonHandler.Button button) => button.Enabled));
			}
			else
			{
				bool flag2 = page == Category.Favorited;
				if (flag2)
				{
					result = ButtonHandler.FavoriteMods;
				}
				else
				{
					result = Enumerable.ToList<ButtonHandler.Button>(Enumerable.Where<ButtonHandler.Button>(ModButtons.buttons, (ButtonHandler.Button button) => button.Page == page));
				}
			}
			return result;
		}

		// Token: 0x06000177 RID: 375 RVA: 0x00016BF0 File Offset: 0x00014DF0
		public static void DisableAllMods()
		{
			foreach (ButtonHandler.Button button in ModButtons.buttons)
			{
				bool enabled = button.Enabled;
				if (enabled)
				{
					button.Enabled = false;
					Action onDisable = button.onDisable;
					if (onDisable != null)
					{
						onDisable.Invoke();
					}
				}
			}
			Optimizations.RefreshMenu();
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000178 RID: 376 RVA: 0x00016C45 File Offset: 0x00014E45
		private static string SavedPreferencesFilePath
		{
			get
			{
				return Path.Combine(Room.folderName, "SavedPreferences.txt");
			}
		}

		// Token: 0x06000179 RID: 377 RVA: 0x00016C58 File Offset: 0x00014E58
		public static void SavePreferences()
		{
			bool flag = !Directory.Exists(Room.folderName);
			if (flag)
			{
				Directory.CreateDirectory(Room.folderName);
				Debug.Log("Created Directory: " + Room.folderName);
			}
			ButtonHandler.enabledMods.Clear();
			foreach (ButtonHandler.Button button in ModButtons.buttons)
			{
				bool enabled = button.Enabled;
				if (enabled)
				{
					ButtonHandler.enabledMods.Add(button.buttonText);
				}
			}
			File.WriteAllLines(ButtonHandler.SavedPreferencesFilePath, ButtonHandler.enabledMods);
			Debug.Log("Preferences Saved To: " + ButtonHandler.SavedPreferencesFilePath);
			NotificationLib.SendNotification("<color=blue>System</color> : Preferences Saved.");
		}

		// Token: 0x0600017A RID: 378 RVA: 0x00016D10 File Offset: 0x00014F10
		public static void LoadPreferences()
		{
			bool flag = !Directory.Exists(Room.folderName);
			if (flag)
			{
				Directory.CreateDirectory(Room.folderName);
				Debug.Log("Created Directory: " + Room.folderName);
			}
			bool flag2 = File.Exists(ButtonHandler.SavedPreferencesFilePath);
			if (flag2)
			{
				List<string> list = Enumerable.ToList<string>(File.ReadAllLines(ButtonHandler.SavedPreferencesFilePath));
				foreach (ButtonHandler.Button button in ModButtons.buttons)
				{
					bool flag3 = button.Enabled && !list.Contains(button.buttonText);
					if (flag3)
					{
						button.Enabled = false;
						Action onDisable = button.onDisable;
						if (onDisable != null)
						{
							onDisable.Invoke();
						}
						NXOUI.RemoveMod(button.buttonText);
					}
				}
				foreach (string text in list)
				{
					foreach (ButtonHandler.Button button2 in ModButtons.buttons)
					{
						bool flag4 = button2.buttonText == text && !button2.Enabled;
						if (flag4)
						{
							button2.Enabled = true;
							Action onEnable = button2.onEnable;
							if (onEnable != null)
							{
								onEnable.Invoke();
							}
							NXOUI.AddMod(button2.buttonText);
						}
					}
				}
				Debug.Log("Preferences Loaded From: " + ButtonHandler.SavedPreferencesFilePath);
			}
			else
			{
				Debug.LogWarning("No Saved Preferences Found At: " + ButtonHandler.SavedPreferencesFilePath);
			}
			Optimizations.RefreshMenu();
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600017B RID: 379 RVA: 0x00016ECC File Offset: 0x000150CC
		private static string AutoSaveFilePatch
		{
			get
			{
				return Path.Combine(Room.folderName, "AutoSavedMods.txt");
			}
		}

		// Token: 0x0600017C RID: 380 RVA: 0x00016EE0 File Offset: 0x000150E0
		public static void AutoSaveEnabledMods(ButtonHandler.Button[] buttons)
		{
			List<string> list = Enumerable.ToList<string>(Enumerable.Select<ButtonHandler.Button, string>(Enumerable.Where<ButtonHandler.Button>(buttons, (ButtonHandler.Button button) => button.Enabled), (ButtonHandler.Button button) => button.buttonText));
			File.WriteAllLines(ButtonHandler.AutoSaveFilePatch, list);
			Debug.Log("Auto Enabled Mods Saved To: " + ButtonHandler.AutoSaveFilePatch);
		}

		// Token: 0x0600017D RID: 381 RVA: 0x00016F60 File Offset: 0x00015160
		public static List<string> LoadEnabledMods()
		{
			bool flag = File.Exists(ButtonHandler.AutoSaveFilePatch);
			List<string> result;
			if (flag)
			{
				List<string> list = Enumerable.ToList<string>(File.ReadAllLines(ButtonHandler.AutoSaveFilePatch));
				Debug.Log("Auto Enabled Mods Loaded From: " + ButtonHandler.AutoSaveFilePatch);
				result = list;
			}
			else
			{
				Debug.LogWarning("No Auto Enabled Mods Found At: " + ButtonHandler.AutoSaveFilePatch);
				result = new List<string>();
			}
			return result;
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x0600017E RID: 382 RVA: 0x00016FC4 File Offset: 0x000151C4
		private static string FavoriteModsFilePath
		{
			get
			{
				return Path.Combine(Room.folderName, "FavoriteMods.txt");
			}
		}

		// Token: 0x0600017F RID: 383 RVA: 0x00016FD8 File Offset: 0x000151D8
		public static void SaveFavoriteMods()
		{
			bool flag = !Directory.Exists(Room.folderName);
			if (flag)
			{
				Directory.CreateDirectory(Room.folderName);
				Debug.Log("Created Directory: " + Room.folderName);
			}
			File.WriteAllLines(ButtonHandler.FavoriteModsFilePath, ButtonHandler.favoriteMods);
			Debug.Log("Favorite Mods Saved To: " + ButtonHandler.FavoriteModsFilePath);
			NotificationLib.SendNotification("<color=yellow>Favorites Saved</color>");
		}

		// Token: 0x06000180 RID: 384 RVA: 0x0001704C File Offset: 0x0001524C
		public static void LoadFavoriteMods()
		{
			bool flag = File.Exists(ButtonHandler.FavoriteModsFilePath);
			if (flag)
			{
				ButtonHandler.favoriteMods = Enumerable.ToList<string>(File.ReadAllLines(ButtonHandler.FavoriteModsFilePath));
				using (List<string>.Enumerator enumerator = ButtonHandler.favoriteMods.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string modName = enumerator.Current;
						ButtonHandler.Button button = Enumerable.FirstOrDefault<ButtonHandler.Button>(ModButtons.buttons, (ButtonHandler.Button b) => b.buttonText == modName);
						bool flag2 = button != null && !ButtonHandler.FavoriteMods.Contains(button);
						if (flag2)
						{
							ButtonHandler.FavoriteMods.Add(button);
						}
					}
				}
				Debug.Log("Favorite Mods Loaded From: " + ButtonHandler.FavoriteModsFilePath);
			}
			else
			{
				Debug.LogWarning("No Favorite Mods Found At: " + ButtonHandler.FavoriteModsFilePath);
			}
		}

		// Token: 0x0400021A RID: 538
		public static List<string> enabledMods = new List<string>();

		// Token: 0x0400021B RID: 539
		public static List<string> favoriteMods = new List<string>();

		// Token: 0x0400021C RID: 540
		public static List<ButtonHandler.Button> FavoriteMods = new List<ButtonHandler.Button>();

		// Token: 0x0200006A RID: 106
		[Nullable(0)]
		public class Button
		{
			// Token: 0x17000024 RID: 36
			// (get) Token: 0x060003A8 RID: 936 RVA: 0x0001D508 File Offset: 0x0001B708
			// (set) Token: 0x060003A9 RID: 937 RVA: 0x0001D510 File Offset: 0x0001B710
			public string buttonText { get; set; }

			// Token: 0x17000025 RID: 37
			// (get) Token: 0x060003AA RID: 938 RVA: 0x0001D519 File Offset: 0x0001B719
			// (set) Token: 0x060003AB RID: 939 RVA: 0x0001D521 File Offset: 0x0001B721
			public bool isToggle { get; set; }

			// Token: 0x17000026 RID: 38
			// (get) Token: 0x060003AC RID: 940 RVA: 0x0001D52A File Offset: 0x0001B72A
			// (set) Token: 0x060003AD RID: 941 RVA: 0x0001D532 File Offset: 0x0001B732
			public bool NeedsMaster { get; set; }

			// Token: 0x17000027 RID: 39
			// (get) Token: 0x060003AE RID: 942 RVA: 0x0001D53B File Offset: 0x0001B73B
			// (set) Token: 0x060003AF RID: 943 RVA: 0x0001D543 File Offset: 0x0001B743
			public bool Enabled { get; set; }

			// Token: 0x17000028 RID: 40
			// (get) Token: 0x060003B0 RID: 944 RVA: 0x0001D54C File Offset: 0x0001B74C
			// (set) Token: 0x060003B1 RID: 945 RVA: 0x0001D554 File Offset: 0x0001B754
			public Action onEnable { get; set; }

			// Token: 0x17000029 RID: 41
			// (get) Token: 0x060003B2 RID: 946 RVA: 0x0001D55D File Offset: 0x0001B75D
			// (set) Token: 0x060003B3 RID: 947 RVA: 0x0001D565 File Offset: 0x0001B765
			public Action onDisable { get; set; }

			// Token: 0x1700002A RID: 42
			// (get) Token: 0x060003B4 RID: 948 RVA: 0x0001D56E File Offset: 0x0001B76E
			// (set) Token: 0x060003B5 RID: 949 RVA: 0x0001D576 File Offset: 0x0001B776
			public Category Page { get; set; }

			// Token: 0x060003B6 RID: 950 RVA: 0x0001D580 File Offset: 0x0001B780
			public Button(string label, Category page, bool isToggle, bool isActive, Action onClick, Action onDisable = null, bool doesNeedMaster = false)
			{
				this.buttonText = label;
				this.isToggle = isToggle;
				this.Enabled = isActive;
				this.onEnable = onClick;
				this.Page = page;
				this.onDisable = onDisable;
				this.NeedsMaster = doesNeedMaster;
			}

			// Token: 0x060003B7 RID: 951 RVA: 0x0001D5D1 File Offset: 0x0001B7D1
			public void SetText(string newText)
			{
				this.buttonText = newText;
			}
		}

		// Token: 0x0200006B RID: 107
		[Nullable(0)]
		public class BtnCollider : MonoBehaviour
		{
			// Token: 0x060003B8 RID: 952 RVA: 0x0001D5DC File Offset: 0x0001B7DC
			public void OnTriggerEnter(Collider collider)
			{
				bool flag = Time.frameCount >= ButtonHandler.BtnCollider.clickCooldown + 25 && collider.gameObject.name == "buttonclicker";
				if (flag)
				{
					base.transform.localScale = new Vector3(base.transform.localScale.x / 3f, base.transform.localScale.y, base.transform.localScale.z);
					ButtonHandler.BtnCollider.clickCooldown = Time.frameCount;
					Variables.taggerInstance.StartVibration(Variables.rightHandedMenu, Variables.taggerInstance.tagHapticStrength / 2f, Variables.taggerInstance.tagHapticDuration / 2f);
					ButtonSoundHandler.PlayClickSound();
					base.GetComponent<BoxCollider>().enabled = true;
					bool flag2 = InputHandler.LGrip();
					if (flag2)
					{
						this.TryAddModToFavorites(this.clickedButton);
					}
					ButtonHandler.Toggle(this.clickedButton);
				}
			}

			// Token: 0x060003B9 RID: 953 RVA: 0x0001D6D4 File Offset: 0x0001B8D4
			private void TryAddModToFavorites(ButtonHandler.Button button)
			{
				bool flag = !ButtonHandler.FavoriteMods.Contains(button);
				if (flag)
				{
					ButtonHandler.FavoriteMods.Add(button);
					ButtonHandler.favoriteMods.Add(button.buttonText);
					NotificationLib.SendNotification("<color=blue>Favorited</color> : " + button.buttonText);
					Debug.Log("Added " + button.buttonText + " to favorites.");
					ButtonHandler.SaveFavoriteMods();
				}
			}

			// Token: 0x040002BE RID: 702
			public ButtonHandler.Button clickedButton;

			// Token: 0x040002BF RID: 703
			public static int clickCooldown;
		}
	}
}
