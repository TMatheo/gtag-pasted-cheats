﻿using System;
using System.Runtime.CompilerServices;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;

namespace NXO.Initialization
{
	// Token: 0x0200002E RID: 46
	[BepInPlugin("com.nxo.nxoremastered.org", "NXO Remastered", "5.0")]
	public class BepInExInitializer : BaseUnityPlugin
	{
		// Token: 0x060001A0 RID: 416 RVA: 0x000191DC File Offset: 0x000173DC
		private void Awake()
		{
			BepInExInitializer.LoggerInstance = base.Logger;
			try
			{
				Harmony harmony = new Harmony("com.nxo.nxoremastered.org");
				harmony.PatchAll();
				base.Logger.LogInfo("NXO Remastered 5.0 initialized successfully.");
			}
			catch (Exception ex)
			{
				base.Logger.LogError("Failed to initialize NXO Remastered: " + ex.Message + "\n" + ex.StackTrace);
			}
		}

		// Token: 0x04000221 RID: 545
		[Nullable(1)]
		public static ManualLogSource LoggerInstance;
	}
}
