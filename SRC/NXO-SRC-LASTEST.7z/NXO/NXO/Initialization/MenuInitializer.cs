﻿using System;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using HarmonyLib;
using NXO.Menu;
using NXO.Utilities;
using UnityEngine;

namespace NXO.Initialization
{
	// Token: 0x0200002F RID: 47
	[HarmonyPatch(typeof(GTPlayer), "LateUpdate")]
	internal class MenuInitializer
	{
		// Token: 0x060001A2 RID: 418 RVA: 0x00019264 File Offset: 0x00017464
		public static void Postfix()
		{
			bool flag = MenuInitializer.menuObject != null && GameObject.Find("NXO Remastered") != null;
			if (!flag)
			{
				bool flag2 = MenuInitializer.menuObject != null;
				if (flag2)
				{
					Debug.LogWarning("NXO Remastered was unexpectedly destroyed. Reinitializing...");
				}
				try
				{
					MenuInitializer.menuObject = new GameObject("NXO Remastered");
					Debug.Log("Initializing NXO Remastered...");
					MenuInitializer.menuObject.AddComponent<Main>();
					MenuInitializer.menuObject.AddComponent<NotificationLib>();
					MenuInitializer.menuObject.AddComponent<CustomBoards>();
					MenuInitializer.menuObject.AddComponent<NXOUI>();
					Object.DontDestroyOnLoad(MenuInitializer.menuObject);
					Debug.Log("NXO Remastered successfully initialized.");
				}
				catch (Exception ex)
				{
					Debug.LogError("Failed to initialize NXO Remastered: " + ex.Message + "\n" + ex.StackTrace);
				}
			}
		}

		// Token: 0x04000222 RID: 546
		[Nullable(1)]
		public static GameObject menuObject;
	}
}
