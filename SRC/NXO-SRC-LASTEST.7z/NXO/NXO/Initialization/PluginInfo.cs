﻿using System;
using System.Runtime.CompilerServices;

namespace NXO.Initialization
{
	// Token: 0x02000030 RID: 48
	[NullableContext(1)]
	[Nullable(0)]
	public static class PluginInfo
	{
		// Token: 0x04000223 RID: 547
		public const string menuGUID = "com.nxo.nxoremastered.org";

		// Token: 0x04000224 RID: 548
		public const string menuName = "NXO Remastered";

		// Token: 0x04000225 RID: 549
		public const string menuVersion = "5.0";
	}
}
