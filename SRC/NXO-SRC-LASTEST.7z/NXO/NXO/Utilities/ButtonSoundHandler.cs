﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using NXO.Menu;
using UnityEngine;

namespace NXO.Utilities
{
	// Token: 0x02000006 RID: 6
	[NullableContext(1)]
	[Nullable(0)]
	public class ButtonSoundHandler
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000011 RID: 17 RVA: 0x00002495 File Offset: 0x00000695
		// (set) Token: 0x06000012 RID: 18 RVA: 0x0000249C File Offset: 0x0000069C
		public static string ClickSoundDescription { get; private set; }

		// Token: 0x06000013 RID: 19 RVA: 0x000024A4 File Offset: 0x000006A4
		static ButtonSoundHandler()
		{
			List<ButtonSoundHandler.SoundEntry> list = new List<ButtonSoundHandler.SoundEntry>();
			list.Add(new ButtonSoundHandler.SoundEntry(ButtonSoundHandler.SoundType.AssetBundle, "NXO.Resources.click1", "click", "Pop"));
			list.Add(new ButtonSoundHandler.SoundEntry(ButtonSoundHandler.SoundType.AssetBundle, "NXO.Resources.minecraftclick", "minecraftclick", "Minecraft"));
			list.Add(new ButtonSoundHandler.SoundEntry(ButtonSoundHandler.SoundType.AssetBundle, "NXO.Resources.click2", "click", "Switch"));
			list.Add(new ButtonSoundHandler.SoundEntry(ButtonSoundHandler.SoundType.HandTap, 67, "Button"));
			list.Add(new ButtonSoundHandler.SoundEntry(ButtonSoundHandler.SoundType.HandTap, 66, "Keyboard"));
			list.Add(new ButtonSoundHandler.SoundEntry(ButtonSoundHandler.SoundType.HandTap, 93, "Cloud"));
			list.Add(new ButtonSoundHandler.SoundEntry(ButtonSoundHandler.SoundType.HandTap, 8, "Floor"));
			ButtonSoundHandler.SoundSequence = list;
			ButtonSoundHandler.SoundEntry soundEntry = ButtonSoundHandler.SoundSequence[ButtonSoundHandler.CurrentSoundIndex];
			ButtonSoundHandler.ClickSoundDescription = soundEntry.Description;
			bool flag = soundEntry.Type == ButtonSoundHandler.SoundType.AssetBundle;
			if (flag)
			{
				ButtonSoundHandler.LoadClickSound();
			}
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002598 File Offset: 0x00000798
		public static void LoadClickSound()
		{
			ButtonSoundHandler.SoundEntry soundEntry = ButtonSoundHandler.SoundSequence[ButtonSoundHandler.CurrentSoundIndex];
			bool flag = soundEntry.Type == ButtonSoundHandler.SoundType.AssetBundle;
			if (flag)
			{
				bool flag2 = ButtonSoundHandler.clickBundle != null;
				if (flag2)
				{
					AssetHandler.UnloadBundle(ButtonSoundHandler.clickBundle, false);
					ButtonSoundHandler.clickBundle = null;
					ButtonSoundHandler.clickClip = null;
				}
				ButtonSoundHandler.clickBundle = AssetHandler.LoadFromResources(soundEntry.AssetPath);
				bool flag3 = ButtonSoundHandler.clickBundle != null;
				if (flag3)
				{
					ButtonSoundHandler.clickClip = AssetHandler.LoadAudioClip(ButtonSoundHandler.clickBundle, soundEntry.ClipName);
				}
			}
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002624 File Offset: 0x00000824
		public static void PlayClickSound()
		{
			ButtonSoundHandler.SoundEntry soundEntry = ButtonSoundHandler.SoundSequence[ButtonSoundHandler.CurrentSoundIndex];
			bool flag = soundEntry.Type == ButtonSoundHandler.SoundType.AssetBundle;
			if (flag)
			{
				ButtonSoundHandler.PlayAssetBundleSound();
			}
			else
			{
				bool flag2 = soundEntry.Type == ButtonSoundHandler.SoundType.HandTap;
				if (flag2)
				{
					ButtonSoundHandler.PlayHandTapSound(soundEntry.HandTapIndex);
				}
			}
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00002674 File Offset: 0x00000874
		private static void PlayAssetBundleSound()
		{
			bool flag = ButtonSoundHandler.clickClip == null;
			if (!flag)
			{
				AudioSource audioSource = Variables.rightHandedMenu ? Variables.taggerInstance.offlineVRRig.rightHandPlayer : Variables.taggerInstance.offlineVRRig.leftHandPlayer;
				bool flag2 = audioSource != null;
				if (flag2)
				{
					AssetHandler.AttachAndPlaySound(audioSource.gameObject, ButtonSoundHandler.clickClip, 1f);
				}
			}
		}

		// Token: 0x06000017 RID: 23 RVA: 0x000026DE File Offset: 0x000008DE
		private static void PlayHandTapSound(int handTapIndex)
		{
			GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(handTapIndex, Variables.rightHandedMenu, 1f);
		}

		// Token: 0x06000018 RID: 24 RVA: 0x000026FC File Offset: 0x000008FC
		public static void ChangeClickSound()
		{
			ButtonSoundHandler.CurrentSoundIndex = (ButtonSoundHandler.CurrentSoundIndex + 1) % ButtonSoundHandler.SoundSequence.Count;
			ButtonSoundHandler.SoundEntry soundEntry = ButtonSoundHandler.SoundSequence[ButtonSoundHandler.CurrentSoundIndex];
			ButtonSoundHandler.ClickSoundDescription = soundEntry.Description;
			bool flag = soundEntry.Type == ButtonSoundHandler.SoundType.AssetBundle;
			if (flag)
			{
				ButtonSoundHandler.LoadClickSound();
			}
			bool flag2 = ButtonSoundHandler.changeclicksoundButton != null;
			if (flag2)
			{
				ButtonSoundHandler.changeclicksoundButton.buttonText = "Click Sound: " + ButtonSoundHandler.ClickSoundDescription;
			}
		}

		// Token: 0x04000006 RID: 6
		private static int CurrentSoundIndex = 0;

		// Token: 0x04000007 RID: 7
		private static AssetBundle clickBundle;

		// Token: 0x04000008 RID: 8
		private static AudioClip clickClip;

		// Token: 0x04000009 RID: 9
		private static readonly List<ButtonSoundHandler.SoundEntry> SoundSequence;

		// Token: 0x0400000A RID: 10
		public static ButtonHandler.Button changeclicksoundButton;

		// Token: 0x02000033 RID: 51
		[NullableContext(0)]
		public enum SoundType
		{
			// Token: 0x04000231 RID: 561
			AssetBundle,
			// Token: 0x04000232 RID: 562
			HandTap
		}

		// Token: 0x02000034 RID: 52
		[Nullable(0)]
		public class SoundEntry
		{
			// Token: 0x1700000F RID: 15
			// (get) Token: 0x060001AC RID: 428 RVA: 0x0001965C File Offset: 0x0001785C
			public ButtonSoundHandler.SoundType Type { get; }

			// Token: 0x17000010 RID: 16
			// (get) Token: 0x060001AD RID: 429 RVA: 0x00019664 File Offset: 0x00017864
			public string AssetPath { get; }

			// Token: 0x17000011 RID: 17
			// (get) Token: 0x060001AE RID: 430 RVA: 0x0001966C File Offset: 0x0001786C
			public int HandTapIndex { get; }

			// Token: 0x17000012 RID: 18
			// (get) Token: 0x060001AF RID: 431 RVA: 0x00019674 File Offset: 0x00017874
			public string ClipName { get; }

			// Token: 0x17000013 RID: 19
			// (get) Token: 0x060001B0 RID: 432 RVA: 0x0001967C File Offset: 0x0001787C
			public string Description { get; }

			// Token: 0x060001B1 RID: 433 RVA: 0x00019684 File Offset: 0x00017884
			public SoundEntry(ButtonSoundHandler.SoundType type, string assetPath, string clipName, string description)
			{
				this.Type = type;
				this.AssetPath = assetPath;
				this.ClipName = clipName;
				this.Description = description;
			}

			// Token: 0x060001B2 RID: 434 RVA: 0x000196AB File Offset: 0x000178AB
			public SoundEntry(ButtonSoundHandler.SoundType type, int handTapIndex, string description)
			{
				this.Type = type;
				this.HandTapIndex = handTapIndex;
				this.Description = description;
			}
		}
	}
}
