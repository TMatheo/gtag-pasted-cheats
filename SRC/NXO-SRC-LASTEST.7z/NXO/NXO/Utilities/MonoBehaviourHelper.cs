﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace NXO.Utilities
{
	// Token: 0x0200000C RID: 12
	[NullableContext(1)]
	[Nullable(0)]
	public class MonoBehaviourHelper : MonoBehaviour
	{
		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00004874 File Offset: 0x00002A74
		public static MonoBehaviourHelper Instance
		{
			get
			{
				bool flag = MonoBehaviourHelper._instance == null;
				if (flag)
				{
					GameObject gameObject = new GameObject("MonoBehaviourHelper");
					MonoBehaviourHelper._instance = gameObject.AddComponent<MonoBehaviourHelper>();
					Object.DontDestroyOnLoad(gameObject);
				}
				return MonoBehaviourHelper._instance;
			}
		}

		// Token: 0x040000CE RID: 206
		public static MonoBehaviourHelper _instance;
	}
}
