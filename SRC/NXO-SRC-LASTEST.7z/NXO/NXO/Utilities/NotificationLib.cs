﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using NXO.Menu;
using UnityEngine;
using UnityEngine.UI;

namespace NXO.Utilities
{
	// Token: 0x0200000D RID: 13
	[NullableContext(1)]
	[Nullable(0)]
	internal class NotificationLib : MonoBehaviour
	{
		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000045 RID: 69 RVA: 0x000048C2 File Offset: 0x00002AC2
		// (set) Token: 0x06000046 RID: 70 RVA: 0x000048C9 File Offset: 0x00002AC9
		public static string PreviousNotification { get; private set; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000047 RID: 71 RVA: 0x000048D1 File Offset: 0x00002AD1
		// (set) Token: 0x06000048 RID: 72 RVA: 0x000048D8 File Offset: 0x00002AD8
		public static bool IsEnabled { get; set; } = true;

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000049 RID: 73 RVA: 0x000048E0 File Offset: 0x00002AE0
		public static NotificationLib Instance
		{
			get
			{
				bool flag = NotificationLib.instance == null;
				if (flag)
				{
					NotificationLib.instance = (Object.FindObjectOfType<NotificationLib>() ?? new GameObject("NotificationLib").AddComponent<NotificationLib>());
				}
				return NotificationLib.instance;
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00004928 File Offset: 0x00002B28
		public void Init()
		{
			bool flag = this.hasInitialized;
			if (!flag)
			{
				this.MainCamera = GameObject.Find("Main Camera");
				bool flag2 = this.MainCamera == null;
				if (!flag2)
				{
					this.HUDObj2 = this.CreateAndTrackHUDObject("HUD_Notification_Parent", null);
					this.HUDObj2.transform.position = this.MainCamera.transform.position + new Vector3(-1.5f, 0f, -4.5f);
					this.HUDObj = this.CreateAndTrackHUDObject("HUD_Notification", this.HUDObj2.transform);
					Canvas canvas = this.HUDObj.AddComponent<Canvas>();
					canvas.renderMode = 2;
					canvas.worldCamera = this.MainCamera.GetComponent<Camera>();
					CanvasScaler canvasScaler = this.HUDObj.AddComponent<CanvasScaler>();
					canvasScaler.dynamicPixelsPerUnit = 10f;
					this.HUDObj.AddComponent<GraphicRaycaster>();
					RectTransform component = this.HUDObj.GetComponent<RectTransform>();
					component.sizeDelta = new Vector2(5f, 5f);
					component.localScale = Vector3.one;
					component.localPosition = new Vector3(0f, 0f, 1.6f);
					component.rotation = Quaternion.Euler(0f, -270f, 0f);
					this.notificationText = this.CreateTextElement("NotificationText", this.HUDObj, new Vector3(-1.2f, -0.9f, -0.22f), new Vector2(260f, 70f), 7);
					this.notificationText.font = Optimizations.ResourceLoader.ArialFont;
					this.notificationText.fontStyle = 3;
					this.notificationMaterial = new Material(Shader.Find("GUI/Text Shader"));
					this.notificationText.material = this.notificationMaterial;
					this.hasInitialized = true;
				}
			}
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00004B0C File Offset: 0x00002D0C
		private GameObject CreateAndTrackHUDObject(string name, Transform parent = null)
		{
			GameObject gameObject = new GameObject(name);
			bool flag = parent != null;
			if (flag)
			{
				gameObject.transform.parent = parent;
			}
			this.trackedObjects.Add(gameObject);
			return gameObject;
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00004B50 File Offset: 0x00002D50
		private Text CreateTextElement(string name, GameObject parent, Vector3 position, Vector2 size, int fontSize)
		{
			GameObject gameObject = new GameObject(name);
			gameObject.transform.parent = parent.transform;
			Text text = gameObject.AddComponent<Text>();
			text.fontSize = fontSize;
			text.alignment = 4;
			text.rectTransform.sizeDelta = size;
			text.rectTransform.localScale = new Vector3(0.01f, 0.01f, 1f);
			text.rectTransform.localPosition = position;
			this.trackedObjects.Add(gameObject);
			return text;
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00004BDC File Offset: 0x00002DDC
		public void UpdateNotifications()
		{
			bool flag = !this.hasInitialized;
			if (flag)
			{
				this.Init();
			}
			bool flag2 = this.HUDObj2 != null && this.MainCamera != null;
			if (flag2)
			{
				this.HUDObj2.transform.SetPositionAndRotation(this.MainCamera.transform.position, this.MainCamera.transform.rotation);
			}
			this.ProcessExpiredNotifications();
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00004C5C File Offset: 0x00002E5C
		private void ProcessExpiredNotifications()
		{
			float now = Time.time;
			IEnumerable<string> keys = NotificationLib.notificationTimestamps.Keys;
			Func<string, bool> <>9__0;
			Func<string, bool> func;
			if ((func = <>9__0) == null)
			{
				func = (<>9__0 = ((string notification) => now - NotificationLib.notificationTimestamps[notification] > 1f));
			}
			foreach (string text in Enumerable.ToList<string>(Enumerable.Where<string>(keys, func)))
			{
				NotificationLib.notificationTimestamps.Remove(text);
				this.UpdateNotificationText();
			}
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00004D00 File Offset: 0x00002F00
		private void UpdateNotificationText()
		{
			bool flag = this.notificationText != null;
			if (flag)
			{
				this.notificationText.text = string.Join(Environment.NewLine, NotificationLib.notificationTimestamps.Keys);
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00004D40 File Offset: 0x00002F40
		public static void SendNotification(string content)
		{
			bool flag = !Variables.toggleNotifications;
			if (!flag)
			{
				bool flag2 = !NotificationLib.IsEnabled || string.IsNullOrEmpty(content) || NotificationLib.Instance.notificationText == null || content == NotificationLib.PreviousNotification;
				if (!flag2)
				{
					NotificationLib.notificationTimestamps[content] = Time.time;
					NotificationLib.PreviousNotification = content;
					NotificationLib.Instance.UpdateNotificationText();
				}
			}
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00004DB5 File Offset: 0x00002FB5
		public static void ClearAllNotifications()
		{
			NotificationLib.notificationTimestamps.Clear();
			NotificationLib.Instance.UpdateNotificationText();
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00004DD0 File Offset: 0x00002FD0
		private void OnDestroy()
		{
			foreach (GameObject gameObject in this.trackedObjects)
			{
				bool flag = gameObject != null;
				if (flag)
				{
					Object.Destroy(gameObject);
				}
			}
			this.trackedObjects.Clear();
			bool flag2 = this.notificationMaterial != null;
			if (flag2)
			{
				Object.Destroy(this.notificationMaterial);
				this.notificationMaterial = null;
			}
			bool flag3 = NotificationLib.instance == this;
			if (flag3)
			{
				NotificationLib.instance = null;
			}
		}

		// Token: 0x040000CF RID: 207
		private GameObject HUDObj;

		// Token: 0x040000D0 RID: 208
		private GameObject HUDObj2;

		// Token: 0x040000D1 RID: 209
		private GameObject MainCamera;

		// Token: 0x040000D2 RID: 210
		private Text notificationText;

		// Token: 0x040000D3 RID: 211
		private static readonly Dictionary<string, float> notificationTimestamps = new Dictionary<string, float>();

		// Token: 0x040000D4 RID: 212
		private static NotificationLib instance;

		// Token: 0x040000D5 RID: 213
		private const float NotificationDelay = 1f;

		// Token: 0x040000D6 RID: 214
		private bool hasInitialized;

		// Token: 0x040000D7 RID: 215
		private readonly List<GameObject> trackedObjects = new List<GameObject>();

		// Token: 0x040000D8 RID: 216
		private Material notificationMaterial;
	}
}
