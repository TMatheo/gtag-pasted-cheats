﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using NXO.Menu;
using NXO.Mods;
using UnityEngine;
using UnityEngine.UI;

namespace NXO.Utilities
{
	// Token: 0x02000010 RID: 16
	[NullableContext(1)]
	[Nullable(0)]
	public class SearchAndKeyboard : MonoBehaviour
	{
		// Token: 0x06000073 RID: 115 RVA: 0x00006858 File Offset: 0x00004A58
		public static string KeyCodeToString(KeyCode keyCode)
		{
			if (!true)
			{
			}
			string result;
			if (keyCode != 8)
			{
				if (keyCode != 32)
				{
					result = keyCode.ToString();
				}
				else
				{
					result = " ";
				}
			}
			else
			{
				result = "<<<";
			}
			if (!true)
			{
			}
			return result;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x000068A0 File Offset: 0x00004AA0
		public static void CleanupKeyboard()
		{
			SearchAndKeyboard.isSearching = false;
			Object.Destroy(SearchAndKeyboard.keyboardObj);
			Object.Destroy(Variables.keyclickerObj1);
			Object.Destroy(Variables.keyclickerObj2);
			SearchAndKeyboard.inputText = "";
			foreach (GameObject gameObject in SearchAndKeyboard.keyTextObjects)
			{
				Object.Destroy(gameObject);
			}
			SearchAndKeyboard.keyTextObjects.Clear();
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00006934 File Offset: 0x00004B34
		private void OnDestroy()
		{
			Object.Destroy(SearchAndKeyboard.keyboardObj);
			foreach (GameObject gameObject in SearchAndKeyboard.keyTextObjects)
			{
				Object.Destroy(gameObject);
			}
			SearchAndKeyboard.keyTextObjects.Clear();
		}

		// Token: 0x06000076 RID: 118 RVA: 0x000069A4 File Offset: 0x00004BA4
		public static void AddSearchBar()
		{
			SearchAndKeyboard.searchBar = GameObject.CreatePrimitive(3);
			Object.Destroy(SearchAndKeyboard.searchBar.GetComponent<Rigidbody>());
			SearchAndKeyboard.searchBar.GetComponent<BoxCollider>().isTrigger = true;
			SearchAndKeyboard.searchBar.transform.parent = Variables.menuObj.transform;
			SearchAndKeyboard.searchBar.transform.rotation = Quaternion.identity;
			SearchAndKeyboard.searchBar.transform.localScale = new Vector3(0.005f, 0.8975f, 0.0575f);
			SearchAndKeyboard.searchBar.transform.localPosition = new Vector3(0.5f, 0f, 0.6f);
			SearchAndKeyboard.searchBar.GetComponent<Renderer>().material = ColorLib.ThemeArraya[ColorLib.CurrentTheme];
			Main.CreateOutline(SearchAndKeyboard.searchBar, ColorLib.Black, Variables.menuObj.transform);
			SearchAndKeyboard.searchText = new GameObject
			{
				transform = 
				{
					parent = Variables.canvasObj.transform
				}
			}.AddComponent<Text>();
			SearchAndKeyboard.searchText.text = ((!string.IsNullOrEmpty(SearchAndKeyboard.inputText) && SearchAndKeyboard.isSearching) ? SearchAndKeyboard.inputText : "Search...");
			SearchAndKeyboard.searchText.font = Optimizations.ResourceLoader.CurrentFont;
			SearchAndKeyboard.searchText.fontStyle = 0;
			SearchAndKeyboard.searchText.fontSize = 3;
			SearchAndKeyboard.searchText.color = ColorLib.White;
			SearchAndKeyboard.searchText.alignment = 3;
			SearchAndKeyboard.searchText.resizeTextForBestFit = true;
			SearchAndKeyboard.searchText.resizeTextMinSize = 0;
			RectTransform component = SearchAndKeyboard.searchText.GetComponent<RectTransform>();
			component.sizeDelta = new Vector2(0.2f, 0.02f);
			component.localPosition = new Vector3(0.051f, -0.005f, 0.18f);
			component.localScale = new Vector3(0.9f, 0.9f, 0.9f);
			component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00006BB8 File Offset: 0x00004DB8
		public static void ToggleSearchButton()
		{
			SearchAndKeyboard.searchButton = GameObject.CreatePrimitive(3);
			Object.Destroy(SearchAndKeyboard.searchButton.GetComponent<Rigidbody>());
			SearchAndKeyboard.searchButton.GetComponent<BoxCollider>().isTrigger = true;
			SearchAndKeyboard.searchButton.transform.parent = Variables.menuObj.transform;
			SearchAndKeyboard.searchButton.transform.localRotation = Quaternion.Euler(180f, 0f, 0f);
			SearchAndKeyboard.searchButton.transform.localScale = new Vector3(0.005f, 0.0975f, 0.0575f);
			SearchAndKeyboard.searchButton.transform.localPosition = new Vector3(0.5f, -0.5575f, 0.2375f);
			ButtonHandler.BtnCollider btnCollider = SearchAndKeyboard.searchButton.GetComponent<ButtonHandler.BtnCollider>() ?? SearchAndKeyboard.searchButton.AddComponent<ButtonHandler.BtnCollider>();
			btnCollider.clickedButton = new ButtonHandler.Button("Toggle Search Button", Category.Home, true, false, null, null, false);
			bool flag = Variables.searchMat == null;
			if (flag)
			{
				Variables.searchMat = new Material(ColorLib.uiShader);
				if (Variables.searchIcon == null)
				{
					Variables.searchIcon = ColorLib.LoadTextureFromResource("searchicon.png");
				}
				Variables.searchMat.mainTexture = Variables.searchIcon;
			}
			SearchAndKeyboard.searchButton.GetComponent<Renderer>().material = Variables.searchMat;
			Main.CreateOutline(SearchAndKeyboard.searchButton, ColorLib.Black, Variables.menuObj.transform);
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00006D24 File Offset: 0x00004F24
		public static void ToggleKeyboard()
		{
			SearchAndKeyboard.isSearching = !SearchAndKeyboard.isSearching;
			bool flag = SearchAndKeyboard.isSearching;
			if (flag)
			{
				SearchAndKeyboard.DrawKeyboard();
				bool flag2 = !Variables.InPcCondition;
				if (flag2)
				{
					SearchAndKeyboard.KeyClicker1(Variables.playerInstance.rightControllerTransform);
					SearchAndKeyboard.KeyClicker2(Variables.playerInstance.leftControllerTransform);
				}
				Optimizations.RefreshMenu();
			}
			else
			{
				Optimizations.RefreshMenu();
				SearchAndKeyboard.CleanupKeyboard();
			}
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00006D94 File Offset: 0x00004F94
		public static void DrawKeyboard()
		{
			SearchAndKeyboard.keyboardObj = new GameObject("Keyboard");
			bool flag = Variables.InPcCondition && !Variables.InMenuCondition;
			if (flag)
			{
				SearchAndKeyboard.keyboardObj.transform.position = Variables.menuObj.transform.position + new Vector3(0f, -0.175f, -0.175f);
				SearchAndKeyboard.keyboardObj.transform.rotation = Quaternion.Euler(80f, 0f, 0f);
			}
			else
			{
				bool inMenuCondition = Variables.InMenuCondition;
				if (inMenuCondition)
				{
					SearchAndKeyboard.keyboardObj.transform.position = Variables.taggerInstance.bodyCollider.transform.position + Variables.taggerInstance.bodyCollider.transform.forward * 0.25f;
					SearchAndKeyboard.keyboardObj.transform.rotation = Variables.taggerInstance.bodyCollider.transform.rotation;
					SearchAndKeyboard.keyboardObj.transform.Rotate(Vector3.right, 80f);
				}
			}
			GameObject gameObject = GameObject.CreatePrimitive(3);
			Object.Destroy(gameObject.GetComponent<Rigidbody>());
			Object.Destroy(gameObject.GetComponent<BoxCollider>());
			gameObject.transform.parent = SearchAndKeyboard.keyboardObj.transform;
			gameObject.transform.localScale = new Vector3(0.5f, 0.2f, 0.005f);
			gameObject.transform.localPosition = new Vector3(0f, 0.002f, 0.005f);
			gameObject.transform.localRotation = Quaternion.identity;
			gameObject.GetComponent<Renderer>().material = ColorLib.ThemeArraya[ColorLib.CurrentTheme];
			float num = gameObject.transform.localScale.x + 0.015f;
			float num2 = gameObject.transform.localScale.y + 0.015f;
			float num3 = gameObject.transform.localScale.z - 0.0025f;
			GameObject gameObject2 = GameObject.CreatePrimitive(3);
			Object.Destroy(gameObject2.GetComponent<Rigidbody>());
			Object.Destroy(gameObject2.GetComponent<BoxCollider>());
			gameObject2.transform.parent = SearchAndKeyboard.keyboardObj.transform;
			gameObject2.transform.rotation = gameObject.transform.rotation;
			gameObject2.transform.position = gameObject.transform.position + new Vector3(-0.00013f, 0f, 0f);
			gameObject2.transform.localScale = new Vector3(num, num2, num3);
			Renderer component = gameObject2.GetComponent<Renderer>();
			component.material.color = ColorLib.Black;
			string[] array = new string[]
			{
				"QWERTYUIOP",
				"ASDFGHJKL",
				"ZXCVBNM"
			};
			float keySize = 0.04f;
			float spacing = 0.005f;
			float num4 = 0.07f;
			float num5 = Enumerable.Max<string>(array, (string row) => (float)row.Length * keySize + (float)(row.Length - 1) * spacing);
			foreach (string text in array)
			{
				float num6 = 0.2425f - num5;
				string text2 = text;
				for (int j = 0; j < text2.Length; j++)
				{
					SearchAndKeyboard.CreateKey(text2.get_Chars(j).ToString(), new Vector3(num6, num4, 0f), keySize, 0.04f);
					num6 += keySize + spacing;
				}
				num4 -= keySize + spacing;
			}
			SearchAndKeyboard.CreateKey("-", new Vector3(0f, num4, 0f), keySize * 11.1f, 0.04f);
			SearchAndKeyboard.CreateKey("<<<", new Vector3(0.136f, num4 + (keySize + spacing), 0f), keySize * 2.1f, 0.04f);
		}

		// Token: 0x0600007A RID: 122 RVA: 0x000071C0 File Offset: 0x000053C0
		private static void CreateKey(string key, Vector3 position, float width, float height = 0.04f)
		{
			GameObject gameObject = GameObject.CreatePrimitive(3);
			Object.Destroy(gameObject.GetComponent<Rigidbody>());
			BoxCollider component = gameObject.GetComponent<BoxCollider>();
			component.isTrigger = true;
			gameObject.transform.parent = SearchAndKeyboard.keyboardObj.transform;
			gameObject.transform.localScale = new Vector3(width, height, 0.01f);
			gameObject.transform.localPosition = position;
			gameObject.transform.localRotation = Quaternion.identity;
			gameObject.GetComponent<Renderer>().material.color = Color.black;
			GameObject gameObject2 = new GameObject("KeyText");
			gameObject2.transform.parent = gameObject.transform;
			gameObject2.transform.localPosition = Vector3.zero;
			gameObject2.transform.localRotation = Quaternion.identity;
			gameObject2.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
			TextMesh textMesh = gameObject2.AddComponent<TextMesh>();
			textMesh.text = key;
			textMesh.font = Optimizations.ResourceLoader.CurrentFont;
			textMesh.fontSize = 1000;
			textMesh.color = ColorLib.White;
			textMesh.anchor = 4;
			textMesh.alignment = 1;
			textMesh.GetComponent<MeshRenderer>().material = Optimizations.ResourceLoader.CurrentFont.material;
			textMesh.transform.position = gameObject.transform.position;
			textMesh.transform.rotation = gameObject.transform.rotation;
			SearchAndKeyboard.keyTextObjects.Add(gameObject2);
			SearchAndKeyboard.KeyCollider keyCollider = gameObject.AddComponent<SearchAndKeyboard.KeyCollider>();
			keyCollider.key = key;
		}

		// Token: 0x0600007B RID: 123 RVA: 0x0000735C File Offset: 0x0000555C
		public static void HandleKeyPress(string key)
		{
			bool flag = SearchAndKeyboard.searchText == null;
			if (!flag)
			{
				if (!true)
				{
				}
				string text;
				if (!(key == "-"))
				{
					if (!(key == "<<<"))
					{
						text = SearchAndKeyboard.inputText + key;
					}
					else
					{
						text = ((SearchAndKeyboard.inputText.Length > 0) ? SearchAndKeyboard.inputText.Substring(0, SearchAndKeyboard.inputText.Length - 1) : SearchAndKeyboard.inputText);
					}
				}
				else
				{
					text = SearchAndKeyboard.inputText + " ";
				}
				if (!true)
				{
				}
				SearchAndKeyboard.inputText = text;
				Variables.taggerInstance.offlineVRRig.PlayHandTapLocal(66, true, 1f);
				Variables.taggerInstance.offlineVRRig.PlayHandTapLocal(66, false, 1f);
				SearchAndKeyboard.searchText.text = SearchAndKeyboard.inputText;
				Variables.currentCategoryPage = 0;
				Optimizations.RefreshMenu();
			}
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00007444 File Offset: 0x00005644
		public static void DisplayButtons(List<ButtonHandler.Button> buttons)
		{
			bool flag = buttons != null && Enumerable.Any<ButtonHandler.Button>(buttons);
			if (flag)
			{
				List<ButtonHandler.Button> list = Enumerable.ToList<ButtonHandler.Button>(Enumerable.Take<ButtonHandler.Button>(Enumerable.Skip<ButtonHandler.Button>(buttons, Variables.currentCategoryPage * Variables.ButtonsPerPage), Variables.ButtonsPerPage));
				for (int i = 0; i < list.Count; i++)
				{
					Main.AddModButtons((float)i * 0.09f, list[i]);
				}
			}
		}

		// Token: 0x0600007D RID: 125 RVA: 0x000074B4 File Offset: 0x000056B4
		private static void CreateKeyClicker(ref GameObject keyclickerObj, Transform parentTransform)
		{
			bool flag = keyclickerObj != null;
			if (!flag)
			{
				keyclickerObj = new GameObject("keyclicker");
				BoxCollider boxCollider = keyclickerObj.AddComponent<BoxCollider>();
				boxCollider.isTrigger = true;
				MeshFilter meshFilter = keyclickerObj.AddComponent<MeshFilter>();
				meshFilter.mesh = Resources.GetBuiltinResource<Mesh>("Sphere.fbx");
				MeshRenderer meshRenderer = keyclickerObj.AddComponent<MeshRenderer>();
				meshRenderer.material.color = Color.white;
				meshRenderer.material.shader = ColorLib.guiShader;
				bool flag2 = parentTransform != null;
				if (flag2)
				{
					keyclickerObj.transform.SetParent(parentTransform);
					keyclickerObj.transform.localScale = new Vector3(0.005f, 0.005f, 0.005f);
					keyclickerObj.transform.localPosition = new Vector3(0f, -0.1f, 0f);
				}
			}
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00007591 File Offset: 0x00005791
		public static void KeyClicker1(Transform parentTransform)
		{
			SearchAndKeyboard.CreateKeyClicker(ref Variables.keyclickerObj1, parentTransform);
		}

		// Token: 0x0600007F RID: 127 RVA: 0x0000759F File Offset: 0x0000579F
		public static void KeyClicker2(Transform parentTransform)
		{
			SearchAndKeyboard.CreateKeyClicker(ref Variables.keyclickerObj2, parentTransform);
		}

		// Token: 0x06000081 RID: 129 RVA: 0x000075B8 File Offset: 0x000057B8
		// Note: this type is marked as 'beforefieldinit'.
		static SearchAndKeyboard()
		{
			KeyCode[] array = new KeyCode[28];
			RuntimeHelpers.InitializeArray(array, fieldof(<PrivateImplementationDetails>.26E5A5BED18D4F279F60AF77F0CCE9161F28BD2CAA6CA49E7AE7E3A7F18DBA40).FieldHandle);
			SearchAndKeyboard.allowedKeys = array;
		}

		// Token: 0x040000FD RID: 253
		public static GameObject searchBar = null;

		// Token: 0x040000FE RID: 254
		public static Text searchText = null;

		// Token: 0x040000FF RID: 255
		public static string inputText = "";

		// Token: 0x04000100 RID: 256
		private static GameObject searchButton = null;

		// Token: 0x04000101 RID: 257
		public static GameObject keyboardObj = null;

		// Token: 0x04000102 RID: 258
		public static bool isSearching = false;

		// Token: 0x04000103 RID: 259
		public static bool menuInFront = false;

		// Token: 0x04000104 RID: 260
		private static readonly List<GameObject> keyTextObjects = new List<GameObject>();

		// Token: 0x04000105 RID: 261
		public static List<KeyCode> lastPressedKeys = new List<KeyCode>();

		// Token: 0x04000106 RID: 262
		public static KeyCode[] allowedKeys;

		// Token: 0x0200003C RID: 60
		[Nullable(0)]
		public class KeyCollider : MonoBehaviour
		{
			// Token: 0x060001D0 RID: 464 RVA: 0x00019DE0 File Offset: 0x00017FE0
			private void OnTriggerEnter(Collider collider)
			{
				bool flag = Time.frameCount >= SearchAndKeyboard.KeyCollider.kcpsCooldown + 10 && collider.gameObject.name == "keyclicker";
				if (flag)
				{
					SearchAndKeyboard.KeyCollider.kcpsCooldown = Time.frameCount;
					base.GetComponent<BoxCollider>().enabled = true;
					SearchAndKeyboard.HandleKeyPress(this.key);
				}
			}

			// Token: 0x04000252 RID: 594
			public string key;

			// Token: 0x04000253 RID: 595
			private static int kcpsCooldown;
		}
	}
}
