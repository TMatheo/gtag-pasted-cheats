﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using HarmonyLib;
using NXO.Mods;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.UI;

namespace NXO.Utilities
{
	// Token: 0x02000011 RID: 17
	[NullableContext(1)]
	[Nullable(0)]
	public class Variables
	{
		// Token: 0x06000082 RID: 130 RVA: 0x0000761E File Offset: 0x0000581E
		public static IEnumerator AddTimerOnMethod(Action method, float timer)
		{
			Variables.<AddTimerOnMethod>d__52 <AddTimerOnMethod>d__ = new Variables.<AddTimerOnMethod>d__52(0);
			<AddTimerOnMethod>d__.method = method;
			<AddTimerOnMethod>d__.timer = timer;
			return <AddTimerOnMethod>d__;
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00007634 File Offset: 0x00005834
		public static Player GetPhotonPlayerFromVRRig(VRRig vrrig)
		{
			return vrrig.Creator.GetPlayerRef();
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00007641 File Offset: 0x00005841
		public static Player GetPhotonPlayerFromNetPlayer(NetPlayer netPlayer)
		{
			return netPlayer.GetPlayerRef();
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00007649 File Offset: 0x00005849
		public static NetPlayer GetNetPlayerCreatorFromVRRig(VRRig vrrig)
		{
			return vrrig.Creator;
		}

		// Token: 0x06000086 RID: 134 RVA: 0x00007651 File Offset: 0x00005851
		public static VRRig GetVRRigFromNetPlayer(NetPlayer netPlayer)
		{
			return GorillaGameManager.instance.FindPlayerVRRig(netPlayer);
		}

		// Token: 0x06000087 RID: 135 RVA: 0x0000765E File Offset: 0x0000585E
		public static PhotonView GetPhotonViewFromVRRigDirect(VRRig vrrig)
		{
			return (PhotonView)Traverse.Create(vrrig).Field("photonView").GetValue();
		}

		// Token: 0x06000088 RID: 136 RVA: 0x0000767A File Offset: 0x0000587A
		public static PhotonView GetPhotonViewUsingNetPlayer(NetPlayer netPlayer)
		{
			return Variables.GetPhotonViewFromVRRigDirect(GorillaGameManager.instance.FindPlayerVRRig(netPlayer));
		}

		// Token: 0x06000089 RID: 137 RVA: 0x0000768C File Offset: 0x0000588C
		public static bool GetGamemode(string gamemodeName)
		{
			return GorillaGameManager.instance.GameModeName().ToLower().Contains(gamemodeName.ToLower());
		}

		// Token: 0x0600008A RID: 138 RVA: 0x000076A8 File Offset: 0x000058A8
		public static bool InLobby()
		{
			return PhotonNetwork.InLobby;
		}

		// Token: 0x0600008B RID: 139 RVA: 0x000076AF File Offset: 0x000058AF
		public static bool IsMaster()
		{
			return PhotonNetwork.IsMasterClient;
		}

		// Token: 0x0600008C RID: 140 RVA: 0x000076B6 File Offset: 0x000058B6
		public static bool IsOtherPlayer(VRRig rig)
		{
			return rig != null && rig != Variables.taggerInstance.offlineVRRig && !rig.isOfflineVRRig && !rig.isMyPlayer;
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600008D RID: 141 RVA: 0x000076E7 File Offset: 0x000058E7
		public static bool IAmInfected
		{
			get
			{
				return Variables.taggerInstance.offlineVRRig != null && Variables.RigIsInfected(Variables.taggerInstance.offlineVRRig);
			}
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00007710 File Offset: 0x00005910
		public static void IsModded()
		{
			bool flag = !PhotonNetwork.IsConnected;
			if (flag)
			{
				NotificationLib.SendNotification("<color=blue>Room</color> : You are not connected to a room.");
			}
			else
			{
				string content = Variables.GetHTMode().Contains("MODDED") ? "<color=blue>Room</color> : You are in a modded lobby." : "<color=blue>Room</color> : You are not in a modded lobby.";
				NotificationLib.SendNotification(content);
			}
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00007760 File Offset: 0x00005960
		public static string GetHTMode()
		{
			bool flag = PhotonNetwork.CurrentRoom == null || !PhotonNetwork.CurrentRoom.CustomProperties.ContainsKey("gameMode");
			string result;
			if (flag)
			{
				result = "ERROR";
			}
			else
			{
				result = PhotonNetwork.CurrentRoom.CustomProperties["gameMode"].ToString();
			}
			return result;
		}

		// Token: 0x06000090 RID: 144 RVA: 0x000077BC File Offset: 0x000059BC
		public static bool RigIsInfected(VRRig vrrig)
		{
			string name = vrrig.mainSkin.material.name;
			return name.Contains("fected") || name.Contains("It");
		}

		// Token: 0x06000091 RID: 145 RVA: 0x000077FC File Offset: 0x000059FC
		public static void IsMasterCheck()
		{
			bool flag = !PhotonNetwork.IsConnected;
			if (flag)
			{
				NotificationLib.SendNotification("<color=blue>Room</color> : You are not connected to a room.");
			}
			else
			{
				NotificationLib.SendNotification(PhotonNetwork.IsMasterClient ? "<color=blue>Room</color> : You are master." : "<color=blue>Room</color> : You are not master.");
			}
		}

		// Token: 0x04000107 RID: 263
		public static GameObject menuObj = null;

		// Token: 0x04000108 RID: 264
		public static GameObject background = null;

		// Token: 0x04000109 RID: 265
		public static GameObject canvasObj = null;

		// Token: 0x0400010A RID: 266
		public static GameObject clickerObj = null;

		// Token: 0x0400010B RID: 267
		public static GameObject BackToStartButton = null;

		// Token: 0x0400010C RID: 268
		public static GameObject keyclickerObj1 = null;

		// Token: 0x0400010D RID: 269
		public static GameObject keyclickerObj2 = null;

		// Token: 0x0400010E RID: 270
		public static GameObject disconnectButton = null;

		// Token: 0x0400010F RID: 271
		public static GameObject settingButton = null;

		// Token: 0x04000110 RID: 272
		public static GameObject discordButton = null;

		// Token: 0x04000111 RID: 273
		public static GameObject searchButton = null;

		// Token: 0x04000112 RID: 274
		public static Texture2D discordIcon = null;

		// Token: 0x04000113 RID: 275
		public static Texture2D settingsIcon = null;

		// Token: 0x04000114 RID: 276
		public static Texture2D exitingIcon = null;

		// Token: 0x04000115 RID: 277
		public static Texture2D searchIcon = null;

		// Token: 0x04000116 RID: 278
		public static Material disconnectMat = null;

		// Token: 0x04000117 RID: 279
		public static Material searchMat = null;

		// Token: 0x04000118 RID: 280
		public static Material settingsMat = null;

		// Token: 0x04000119 RID: 281
		public static Material discordMat = null;

		// Token: 0x0400011A RID: 282
		public static Text title = null;

		// Token: 0x0400011B RID: 283
		public static Category currentPage = Category.Home;

		// Token: 0x0400011C RID: 284
		public static int currentCategoryPage = 0;

		// Token: 0x0400011D RID: 285
		public static int ButtonsPerPage = 7;

		// Token: 0x0400011E RID: 286
		public static bool toggledisconnectButton = false;

		// Token: 0x0400011F RID: 287
		public static bool rightHandedMenu = false;

		// Token: 0x04000120 RID: 288
		public static bool toggleNotifications = true;

		// Token: 0x04000121 RID: 289
		public static bool advancedTitle = false;

		// Token: 0x04000122 RID: 290
		public static bool wideMenu = false;

		// Token: 0x04000123 RID: 291
		public static bool notificationSent = false;

		// Token: 0x04000124 RID: 292
		public static bool teamCheckedESP = false;

		// Token: 0x04000125 RID: 293
		public static bool SearchEnabled = false;

		// Token: 0x04000126 RID: 294
		public static bool PCMenuOpen = false;

		// Token: 0x04000127 RID: 295
		public static KeyCode PCMenuKey = 308;

		// Token: 0x04000128 RID: 296
		public static bool openMenu;

		// Token: 0x04000129 RID: 297
		public static bool menuOpen = false;

		// Token: 0x0400012A RID: 298
		public static bool InMenuCondition;

		// Token: 0x0400012B RID: 299
		public static bool InPcCondition;

		// Token: 0x0400012C RID: 300
		public static GTPlayer playerInstance;

		// Token: 0x0400012D RID: 301
		public static GorillaTagger taggerInstance;

		// Token: 0x0400012E RID: 302
		public static ControllerInputPoller pollerInstance;

		// Token: 0x0400012F RID: 303
		public static VRRig vrrig = null;

		// Token: 0x04000130 RID: 304
		public static Material vrrigMaterial = null;

		// Token: 0x04000131 RID: 305
		public static GameObject thirdPersonCamera = null;

		// Token: 0x04000132 RID: 306
		public static GameObject shoulderCamera = null;

		// Token: 0x04000133 RID: 307
		public static GameObject TransformCam = null;

		// Token: 0x04000134 RID: 308
		public static bool didThirdPerson = false;

		// Token: 0x04000135 RID: 309
		public static GameObject cm = null;

		// Token: 0x04000136 RID: 310
		public static Rigidbody currentMenuRigidbody = null;

		// Token: 0x04000137 RID: 311
		public static Vector3 previousVelocity = Vector3.zero;

		// Token: 0x04000138 RID: 312
		public const float velocityThreshold = 0.05f;

		// Token: 0x04000139 RID: 313
		public static float rpcCooldown = 0f;

		// Token: 0x0400013A RID: 314
		public static float lastClearTime = 0f;

		// Token: 0x0400013B RID: 315
		public static int fps;

		// Token: 0x0400013C RID: 316
		public static float lastFPSTime = 0f;

		// Token: 0x0400013D RID: 317
		public static string AllKeycards = "";

		// Token: 0x0400013E RID: 318
		public static bool ownersInRoom = false;

		// Token: 0x0400013F RID: 319
		public static bool didIds = false;
	}
}
