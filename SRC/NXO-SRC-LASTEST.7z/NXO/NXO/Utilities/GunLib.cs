﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.InputSystem;

namespace NXO.Utilities
{
	// Token: 0x0200000A RID: 10
	[NullableContext(1)]
	[Nullable(0)]
	public class GunLib
	{
		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600002F RID: 47 RVA: 0x00004249 File Offset: 0x00002449
		public static bool GunGrips
		{
			get
			{
				return Mouse.current.rightButton.isPressed || InputHandler.RGrip();
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000030 RID: 48 RVA: 0x00004264 File Offset: 0x00002464
		public static bool GunTriggers
		{
			get
			{
				return Mouse.current.leftButton.isPressed || InputHandler.RTrigger();
			}
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00004280 File Offset: 0x00002480
		public static void SetupGunObjectPositions(Vector3 pos)
		{
			bool flag = GunLib.gunPointer == null;
			if (flag)
			{
				GunLib.gunPointer = GameObject.CreatePrimitive(0);
				Renderer component = GunLib.gunPointer.GetComponent<Renderer>();
				component.material.shader = ColorLib.guiShader;
				Object.Destroy(GunLib.gunPointer.GetComponent<Rigidbody>());
				Object.Destroy(GunLib.gunPointer.GetComponent<SphereCollider>());
				GunLib.gunPointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			}
			bool flag2 = GunLib.lineMaterial == null;
			if (flag2)
			{
				GunLib.lineMaterial = new Material(ColorLib.guiShader);
			}
			bool flag3 = GunLib.lineFollow == null;
			if (flag3)
			{
				GunLib.lineFollow = new GameObject("Line");
				GunLib.lineRenderer = GunLib.lineFollow.AddComponent<LineRenderer>();
				GunLib.lineRenderer.positionCount = 50;
				GunLib.lineRenderer.startWidth = 0.02f;
				GunLib.lineRenderer.endWidth = 0.02f;
				GunLib.lineRenderer.useWorldSpace = true;
				GunLib.lineRenderer.material = GunLib.lineMaterial;
			}
			Vector3 position = Variables.taggerInstance.rightHandTransform.position;
			Color32 color = GunLib.GunTriggers ? new Color32(0, byte.MaxValue, 0, byte.MaxValue) : new Color32(byte.MaxValue, 0, 0, byte.MaxValue);
			GunLib.gunPointer.transform.position = pos;
			MeshRenderer component2 = GunLib.gunPointer.GetComponent<MeshRenderer>();
			bool flag4 = component2 != null;
			if (flag4)
			{
				component2.material.color = color;
			}
			for (int i = 0; i < 50; i++)
			{
				float num = (float)i / 49f;
				Vector3 vector = Vector3.Lerp(position, pos, num);
				bool flag5 = GunLib.isWiggling;
				if (flag5)
				{
					float num2 = Mathf.Sin(Time.time * 7.5f + num * 3.1415927f * 2f) * 0.05f;
					vector += Variables.taggerInstance.rightHandTransform.right * num2;
				}
				GunLib.lineRenderer.SetPosition(i, vector);
			}
			GunLib.lineRenderer.material.color = color;
			GunLib.SetGunVisibility(true);
		}

		// Token: 0x06000032 RID: 50 RVA: 0x000044D8 File Offset: 0x000026D8
		public static void SetupRaycast()
		{
			Ray ray = (Mouse.current.rightButton.isPressed || Mouse.current.leftButton.isPressed) ? Variables.thirdPersonCamera.GetComponent<Camera>().ScreenPointToRay(Mouse.current.position.ReadValue()) : new Ray(Variables.playerInstance.rightControllerTransform.position - Variables.playerInstance.rightControllerTransform.up, -Variables.playerInstance.rightControllerTransform.up);
			Physics.Raycast(ray, ref GunLib.raycastHit, 100f);
			bool flag = GunLib.lockedTargetRig != null;
			if (flag)
			{
				GunLib.SetupGunObjectPositions(GunLib.lockedTargetRig.transform.position);
			}
			else
			{
				GunLib.SetupGunObjectPositions(GunLib.raycastHit.point);
			}
		}

		// Token: 0x06000033 RID: 51 RVA: 0x000045B8 File Offset: 0x000027B8
		public static void SetGunVisibility(bool isVisible)
		{
			bool flag = GunLib.gunPointer != null;
			if (flag)
			{
				GunLib.gunPointer.SetActive(isVisible);
			}
			bool flag2 = GunLib.lineFollow != null;
			if (flag2)
			{
				GunLib.lineFollow.SetActive(isVisible);
			}
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00004600 File Offset: 0x00002800
		private void OnDestroy()
		{
			bool flag = GunLib.gunPointer != null;
			if (flag)
			{
				Object.Destroy(GunLib.gunPointer);
			}
			bool flag2 = GunLib.lineFollow != null;
			if (flag2)
			{
				Object.Destroy(GunLib.lineFollow);
			}
			bool flag3 = GunLib.lineMaterial != null;
			if (flag3)
			{
				Object.Destroy(GunLib.lineMaterial);
			}
		}

		// Token: 0x040000BE RID: 190
		public static bool isWiggling = true;

		// Token: 0x040000BF RID: 191
		public static VRRig lockedTargetRig;

		// Token: 0x040000C0 RID: 192
		public static VRRig potentialTargetRig;

		// Token: 0x040000C1 RID: 193
		public static GameObject lineFollow = null;

		// Token: 0x040000C2 RID: 194
		public static LineRenderer lineRenderer = null;

		// Token: 0x040000C3 RID: 195
		public static Material lineMaterial = null;

		// Token: 0x040000C4 RID: 196
		public static GameObject gunPointer = null;

		// Token: 0x040000C5 RID: 197
		public static RaycastHit raycastHit;

		// Token: 0x040000C6 RID: 198
		private const float WiggleSpeed = 7.5f;

		// Token: 0x040000C7 RID: 199
		private const float WiggleAmplitude = 0.05f;

		// Token: 0x040000C8 RID: 200
		private const int LineSegments = 50;
	}
}
