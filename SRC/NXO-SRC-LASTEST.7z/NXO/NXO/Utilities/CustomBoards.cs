﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Text;
using TMPro;
using UnityEngine;

namespace NXO.Utilities
{
	// Token: 0x02000008 RID: 8
	[NullableContext(1)]
	[Nullable(0)]
	public class CustomBoards : MonoBehaviour
	{
		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000026 RID: 38 RVA: 0x00003DA6 File Offset: 0x00001FA6
		// (set) Token: 0x06000027 RID: 39 RVA: 0x00003DAD File Offset: 0x00001FAD
		public static CustomBoards Instance { get; private set; }

		// Token: 0x06000028 RID: 40 RVA: 0x00003DB8 File Offset: 0x00001FB8
		private void Awake()
		{
			bool flag = CustomBoards.Instance != null && CustomBoards.Instance != this;
			if (flag)
			{
				Object.Destroy(base.gameObject);
			}
			else
			{
				CustomBoards.Instance = this;
				Object.DontDestroyOnLoad(base.gameObject);
				GameObject gameObject = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text");
				this.cocText = ((gameObject != null) ? gameObject.GetComponent<TextMeshPro>() : null);
				bool flag2 = this.cocText == null;
				if (flag2)
				{
					Debug.LogWarning("[CustomBoards] 'COC Text' not found.");
				}
				GameObject gameObject2 = GameObject.Find("CodeOfConduct");
				this.codeOfConductText = ((gameObject2 != null) ? gameObject2.GetComponent<TextMeshPro>() : null);
				bool flag3 = this.codeOfConductText == null;
				if (flag3)
				{
					Debug.LogWarning("[CustomBoards] 'CodeOfConduct' not found.");
				}
				Debug.Log("[CustomBoards] Initialized");
				bool flag4 = this.fetchMessageCoroutine == null;
				if (flag4)
				{
					this.fetchMessageCoroutine = base.StartCoroutine(this.FetchMessageFromGitHub());
				}
				this.InitializeCustomBoards();
			}
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00003EAC File Offset: 0x000020AC
		private void InitializeCustomBoards()
		{
			bool flag = this.codeOfConductText != null;
			if (flag)
			{
				this.codeOfConductText.text = "NXO REMASTERED <color=green>(5.0)</color>";
				this.codeOfConductText.color = this.titleTextColor;
				this.codeOfConductText.richText = true;
			}
			bool flag2 = this.cocText != null;
			if (flag2)
			{
				this.cocText.color = this.descriptionTextColor;
				this.cocText.richText = true;
			}
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00003F2D File Offset: 0x0000212D
		private IEnumerator FetchMessageFromGitHub()
		{
			CustomBoards.<FetchMessageFromGitHub>d__15 <FetchMessageFromGitHub>d__ = new CustomBoards.<FetchMessageFromGitHub>d__15(0);
			<FetchMessageFromGitHub>d__.<>4__this = this;
			return <FetchMessageFromGitHub>d__;
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00003F3C File Offset: 0x0000213C
		private void OnDestroy()
		{
			bool flag = this.fetchMessageCoroutine != null;
			if (flag)
			{
				base.StopCoroutine(this.fetchMessageCoroutine);
				this.fetchMessageCoroutine = null;
			}
		}

		// Token: 0x040000B5 RID: 181
		private TextMeshPro cocText;

		// Token: 0x040000B6 RID: 182
		private TextMeshPro codeOfConductText;

		// Token: 0x040000B7 RID: 183
		private GameObject treeRoom;

		// Token: 0x040000B8 RID: 184
		private readonly Color titleTextColor = Color.white;

		// Token: 0x040000B9 RID: 185
		private readonly Color descriptionTextColor = Color.white;

		// Token: 0x040000BA RID: 186
		private readonly Color boardColors = Color.black;

		// Token: 0x040000BB RID: 187
		private const string GitHubMessageUrl = "https://api.github.com/repos/NuggetGT/NXO-Resources/contents/NXO-Menu-Status.txt";

		// Token: 0x040000BC RID: 188
		private readonly StringBuilder dynamicMessage = new StringBuilder("Loading message...");

		// Token: 0x040000BD RID: 189
		private Coroutine fetchMessageCoroutine;
	}
}
