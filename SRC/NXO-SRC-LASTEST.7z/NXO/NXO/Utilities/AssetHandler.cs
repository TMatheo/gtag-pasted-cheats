﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;

namespace NXO.Utilities
{
	// Token: 0x02000005 RID: 5
	[NullableContext(1)]
	[Nullable(0)]
	public class AssetHandler
	{
		// Token: 0x06000005 RID: 5 RVA: 0x00002094 File Offset: 0x00000294
		public static AssetBundle LoadFromResources(string resourceName)
		{
			AssetBundle result;
			try
			{
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName);
				bool flag = manifestResourceStream == null;
				if (flag)
				{
					Debug.LogError("Failed to load AssetBundle: Resource '" + resourceName + "' not found.");
					result = null;
				}
				else
				{
					AssetBundle assetBundle = AssetBundle.LoadFromStream(manifestResourceStream);
					manifestResourceStream.Close();
					bool flag2 = assetBundle == null;
					if (flag2)
					{
						Debug.LogError("Failed to load AssetBundle from resource '" + resourceName + "'.");
					}
					result = assetBundle;
				}
			}
			catch (Exception ex)
			{
				Debug.LogError("Exception while loading AssetBundle '" + resourceName + "': " + ex.Message);
				result = null;
			}
			return result;
		}

		// Token: 0x06000006 RID: 6 RVA: 0x00002140 File Offset: 0x00000340
		public static void UnloadBundle(AssetBundle bundle, bool unloadAllLoadedObjects = false)
		{
			bool flag = bundle != null;
			if (flag)
			{
				bundle.Unload(unloadAllLoadedObjects);
				Debug.Log("AssetBundle unloaded.");
			}
			else
			{
				Debug.LogWarning("Attempted to unload a null AssetBundle.");
			}
		}

		// Token: 0x06000007 RID: 7 RVA: 0x00002180 File Offset: 0x00000380
		public static T LoadAsset<[Nullable(0)] T>(AssetBundle bundle, string assetName) where T : Object
		{
			bool flag = bundle == null;
			T result;
			if (flag)
			{
				Debug.LogError("Cannot load asset: AssetBundle is null.");
				result = default(T);
			}
			else
			{
				try
				{
					T t = bundle.LoadAsset<T>(assetName);
					bool flag2 = t == null;
					if (flag2)
					{
						Debug.LogError("Failed to load asset '" + assetName + "' from bundle.");
					}
					result = t;
				}
				catch (Exception ex)
				{
					Debug.LogError("Exception while loading asset '" + assetName + "': " + ex.Message);
					result = default(T);
				}
			}
			return result;
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002228 File Offset: 0x00000428
		public static void LoadAssetFromUrl(string url, string assetname, Action<GameObject> onLoaded)
		{
			GameObject gameObject;
			bool flag = AssetHandler.urlAssetCache.TryGetValue(assetname, ref gameObject);
			if (flag)
			{
				Debug.Log("Asset '" + assetname + "' loaded from cache.");
				if (onLoaded != null)
				{
					onLoaded.Invoke(gameObject);
				}
			}
			else
			{
				bool flag2 = !AssetHandler.downloadingUrlAssets.Add(assetname);
				if (flag2)
				{
					Debug.LogWarning("Asset '" + assetname + "' is already being downloaded.");
				}
				else
				{
					Debug.Log("Starting download for asset '" + assetname + "' from URL: " + url);
					MonoBehaviourHelper.Instance.StartCoroutine(AssetHandler.DownloadAssetFromUrl(url, assetname, onLoaded));
				}
			}
		}

		// Token: 0x06000009 RID: 9 RVA: 0x000022C6 File Offset: 0x000004C6
		private static IEnumerator DownloadAssetFromUrl(string url, string assetname, Action<GameObject> onLoaded)
		{
			AssetHandler.<DownloadAssetFromUrl>d__6 <DownloadAssetFromUrl>d__ = new AssetHandler.<DownloadAssetFromUrl>d__6(0);
			<DownloadAssetFromUrl>d__.url = url;
			<DownloadAssetFromUrl>d__.assetname = assetname;
			<DownloadAssetFromUrl>d__.onLoaded = onLoaded;
			return <DownloadAssetFromUrl>d__;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x000022E4 File Offset: 0x000004E4
		public static GameObject LoadAndInstantiateGameObject(AssetBundle bundle, string assetName)
		{
			GameObject gameObject = AssetHandler.LoadAsset<GameObject>(bundle, assetName);
			bool flag = gameObject == null;
			GameObject result;
			if (flag)
			{
				Debug.LogError("Failed to load or instantiate GameObject: " + assetName);
				result = null;
			}
			else
			{
				GameObject gameObject2 = Object.Instantiate<GameObject>(gameObject);
				gameObject2.name = assetName;
				result = gameObject2;
			}
			return result;
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00002330 File Offset: 0x00000530
		public static AudioClip LoadAudioClip(AssetBundle bundle, string assetName)
		{
			return AssetHandler.LoadAsset<AudioClip>(bundle, assetName);
		}

		// Token: 0x0600000C RID: 12 RVA: 0x0000234C File Offset: 0x0000054C
		public static void AttachAndPlaySound(GameObject target, AudioClip clip, float volume)
		{
			bool flag = target == null || clip == null;
			if (flag)
			{
				Debug.LogError("Failed to attach or play sound: Target GameObject or AudioClip is null.");
			}
			else
			{
				AudioSource audioSource = target.GetComponent<AudioSource>();
				bool flag2 = audioSource == null;
				if (flag2)
				{
					Debug.Log("No AudioSource found on " + target.name + ", adding one.");
					audioSource = target.AddComponent<AudioSource>();
				}
				audioSource.clip = clip;
				audioSource.volume = volume;
				audioSource.loop = false;
				audioSource.Play();
			}
		}

		// Token: 0x0600000D RID: 13 RVA: 0x000023D4 File Offset: 0x000005D4
		public static Font LoadFont(AssetBundle bundle, string assetName)
		{
			return AssetHandler.LoadAsset<Font>(bundle, assetName);
		}

		// Token: 0x0600000E RID: 14 RVA: 0x000023F0 File Offset: 0x000005F0
		public static void ApplyFontToText(GameObject target, Font font, int fontSize, Color? color = null)
		{
			bool flag = target == null || font == null;
			if (flag)
			{
				Debug.LogError("Failed to apply font: Target GameObject or Font is null.");
			}
			else
			{
				Text component = target.GetComponent<Text>();
				bool flag2 = component != null;
				if (flag2)
				{
					component.font = font;
					component.fontSize = fontSize;
					component.color = (color ?? Color.white);
				}
				else
				{
					Debug.LogError("Target GameObject does not have a Text component.");
				}
			}
		}

		// Token: 0x04000003 RID: 3
		public static Dictionary<string, GameObject> urlAssetCache = new Dictionary<string, GameObject>();

		// Token: 0x04000004 RID: 4
		private static HashSet<string> downloadingUrlAssets = new HashSet<string>();
	}
}
