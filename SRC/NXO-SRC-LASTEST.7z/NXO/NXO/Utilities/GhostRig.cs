﻿using System;
using NXO.Menu;
using UnityEngine;

namespace NXO.Utilities
{
	// Token: 0x02000009 RID: 9
	public class GhostRig
	{
		// Token: 0x0600002D RID: 45 RVA: 0x00003FA8 File Offset: 0x000021A8
		public static void HandleGhostRig()
		{
			try
			{
				bool flag = !Variables.taggerInstance.offlineVRRig.enabled;
				if (flag)
				{
					bool flag2 = Variables.vrrig == null;
					if (flag2)
					{
						Variables.vrrig = Object.Instantiate<VRRig>(Variables.taggerInstance.offlineVRRig, Variables.playerInstance.transform.position, Variables.playerInstance.transform.rotation);
						Variables.vrrig.headBodyOffset = Vector3.zero;
						Variables.vrrig.enabled = true;
						Variables.vrrig.transform.Find("VR Constraints/LeftArm/Left Arm IK/SlideAudio").gameObject.SetActive(false);
						Variables.vrrig.transform.Find("VR Constraints/RightArm/Right Arm IK/SlideAudio").gameObject.SetActive(false);
					}
					bool flag3 = Variables.vrrigMaterial == null;
					if (flag3)
					{
						Variables.vrrigMaterial = new Material(ColorLib.guiShader);
					}
					Variables.vrrigMaterial.color = ColorLib.MaterialToColorConverter(ColorLib.ThemeArraya[ColorLib.CurrentTheme]) - new Color32(0, 0, 0, 150);
					Variables.vrrig.mainSkin.material = Variables.vrrigMaterial;
					Variables.vrrig.headConstraint.transform.position = Variables.playerInstance.headCollider.transform.position;
					Variables.vrrig.headConstraint.transform.rotation = Variables.playerInstance.headCollider.transform.rotation;
					Variables.vrrig.leftHandTransform.position = Variables.playerInstance.leftControllerTransform.position;
					Variables.vrrig.leftHandTransform.rotation = Variables.playerInstance.leftControllerTransform.rotation;
					Variables.vrrig.rightHandTransform.position = Variables.playerInstance.rightControllerTransform.position;
					Variables.vrrig.rightHandTransform.rotation = Variables.playerInstance.rightControllerTransform.rotation;
					Variables.vrrig.transform.position = Variables.playerInstance.transform.position;
					Variables.vrrig.transform.rotation = Variables.playerInstance.transform.rotation;
				}
				else
				{
					Optimizations.DestroyAndNullify<VRRig>(ref Variables.vrrig, 0f);
					Optimizations.DestroyAndNullify<Material>(ref Variables.vrrigMaterial, 0f);
				}
			}
			catch (Exception ex)
			{
				Debug.LogError(string.Format("Error updating ghost rig. Exception: {0}", ex));
			}
		}
	}
}
