﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using BepInEx;
using GorillaNetworking;
using NXO.Menu;
using NXO.Mods;
using NXO.Mods.Categories;
using Photon.Pun;
using UnityEngine;
using UnityEngine.InputSystem;

namespace NXO.Utilities
{
	// Token: 0x0200000E RID: 14
	[NullableContext(1)]
	[Nullable(0)]
	public class NXOUI : MonoBehaviour
	{
		// Token: 0x06000055 RID: 85 RVA: 0x00004EA8 File Offset: 0x000030A8
		private void OnGUI()
		{
			bool isGuiVisible = NXOUI.IsGuiVisible;
			if (isGuiVisible)
			{
				this.DrawTitle();
				bool flag = NXOUI.ModNotifications.Count > 0;
				if (flag)
				{
					this.DrawModList();
				}
				bool flag2 = this.window == default(Rect);
				if (flag2)
				{
					this.window = new Rect((float)Screen.width - NXOUI.GlobalWidth - 10f, 10f, NXOUI.GlobalWidth, NXOUI.GlobalHeight);
				}
				this.window = GUI.Window(1, this.window, new GUI.WindowFunction(this.Window), "", GUIStyle.none);
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00004F54 File Offset: 0x00003154
		private void Awake()
		{
			foreach (ButtonHandler.Button button in ModButtons.buttons)
			{
				bool flag = button.Enabled && button.isToggle && !NXOUI.ModNotifications.Contains(button.buttonText);
				if (flag)
				{
					NXOUI.AddMod(button.buttonText);
				}
			}
			this.window = new Rect((float)Screen.width - NXOUI.GlobalWidth - 10f, 10f, NXOUI.GlobalWidth, NXOUI.GlobalHeight);
			NXOUI.input = "";
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00004FEB File Offset: 0x000031EB
		private void OnEnable()
		{
			this.GUITextures();
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00004FF4 File Offset: 0x000031F4
		private void OnDisable()
		{
			this.DestroyTextures();
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00005000 File Offset: 0x00003200
		public void GUITextures()
		{
			this.DestroyTextures();
			bool flag = this.texturesCreated;
			if (!flag)
			{
				string text = Settings.ThemeDescriptions[ColorLib.CurrentTheme];
				if (!true)
				{
				}
				uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
				Color32 color;
				if (num <= 1285846273U)
				{
					if (num != 207983069U)
					{
						if (num != 330075645U)
						{
							if (num == 1285846273U)
							{
								if (text == "Magenta Lerp")
								{
									color = ColorLib.Magenta;
									goto IL_159;
								}
							}
						}
						else if (text == "Green Lerp")
						{
							color = ColorLib.Green;
							goto IL_159;
						}
					}
					else if (text == "Red Lerp")
					{
						color = ColorLib.Red;
						goto IL_159;
					}
				}
				else if (num <= 3322973504U)
				{
					if (num != 2119602162U)
					{
						if (num == 3322973504U)
						{
							if (text == "Purple Lerp")
							{
								color = ColorLib.Purple;
								goto IL_159;
							}
						}
					}
					else if (text == "Yellow Lerp")
					{
						color = ColorLib.Yellow;
						goto IL_159;
					}
				}
				else if (num != 3365953284U)
				{
					if (num == 3865153310U)
					{
						if (text == "Blue Lerp")
						{
							color = ColorLib.Blue;
							goto IL_159;
						}
					}
				}
				else if (text == "Orange Lerp")
				{
					color = ColorLib.Orange;
					goto IL_159;
				}
				color = ColorLib.MaterialToColorConverter(ColorLib.ThemeArraya[ColorLib.CurrentTheme]);
				IL_159:
				if (!true)
				{
				}
				Color32 borderColor = color;
				NXOUI.bgTexture = this.CreateTexture((int)this.window.width, (int)this.window.height, ColorLib.Black, borderColor, 2, 15);
				NXOUI.tfTexture = this.CreateTexture((int)this.window.width - 20, 25, ColorLib.Black, borderColor, 1, 2);
				NXOUI.bTexture = this.CreateTexture(110, 25, ColorLib.Black, borderColor, 1, 2);
				this.texturesCreated = true;
			}
		}

		// Token: 0x0600005A RID: 90 RVA: 0x000051DC File Offset: 0x000033DC
		private void Window(int id)
		{
			GUI.DrawTexture(new Rect(0f, 0f, this.window.width, this.window.height), NXOUI.bgTexture);
			GUI.Label(new Rect(0f, 0f, this.window.width, 30f), "<color=white>NXO GUI | Right Alt To Hide</color>", new GUIStyle
			{
				alignment = 4,
				richText = true,
				font = Optimizations.ResourceLoader.CurrentFont
			});
			GUILayout.BeginArea(new Rect(10f, 30f, this.window.width - 20f, 25f));
			NXOUI.input = this.CreateTextField(NXOUI.input);
			GUILayout.EndArea();
			GUILayout.BeginArea(new Rect(10f, 60f, this.window.width - 20f, 25f));
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			this.CreateButton("Join Room", delegate
			{
				PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(NXOUI.input, 0);
			});
			this.CreateButton("Disconnect", new Action(PhotonNetwork.Disconnect));
			this.CreateButton("Set Name", delegate
			{
				PhotonNetwork.LocalPlayer.NickName = NXOUI.input;
				GorillaComputer.instance.savedName = NXOUI.input;
				GorillaComputer.instance.currentName = NXOUI.input;
			});
			GUILayout.EndHorizontal();
			GUILayout.EndArea();
			GUILayout.BeginArea(new Rect(10f, 85f, this.window.width - 20f, 25f));
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			this.CreateButton("Change Theme", new Action(Settings.CycleTheme));
			GUILayout.EndHorizontal();
			GUILayout.EndArea();
			GUILayout.BeginArea(new Rect(10f, 110f, this.window.width - 20f, 25f));
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			this.CreateButton("Freecam (" + (NXOUI.freecam ? "ON" : "OFF") + ")", delegate
			{
				NXOUI.freecam = !NXOUI.freecam;
			});
			bool flag = NXOUI.freecam;
			if (flag)
			{
				NXOUI.AddMod("Freecam");
				Transform transform = Variables.taggerInstance.headCollider.transform;
				float num = UnityInput.Current.GetKey(304) ? (Settings.FlySpeed + 3f) : Settings.FlySpeed;
				Variables.playerInstance.GetComponent<Rigidbody>().velocity = new Vector3(0f, 0.065f, 0f);
				Vector3 vector = Vector3.zero;
				bool key = UnityInput.Current.GetKey(119);
				if (key)
				{
					vector += transform.forward;
				}
				bool key2 = UnityInput.Current.GetKey(115);
				if (key2)
				{
					vector -= transform.forward;
				}
				bool key3 = UnityInput.Current.GetKey(97);
				if (key3)
				{
					vector -= transform.right;
				}
				bool key4 = UnityInput.Current.GetKey(100);
				if (key4)
				{
					vector += transform.right;
				}
				bool key5 = UnityInput.Current.GetKey(32);
				if (key5)
				{
					vector += transform.up;
				}
				bool key6 = UnityInput.Current.GetKey(306);
				if (key6)
				{
					vector -= transform.up;
				}
				Variables.taggerInstance.headCollider.transform.position += vector.normalized * num * Time.deltaTime;
				bool mouseButton = UnityInput.Current.GetMouseButton(1);
				if (mouseButton)
				{
					Vector3 vector2 = UnityInput.Current.mousePosition - Movement.OldMousePosition;
					float num2 = 0.1f;
					Variables.taggerInstance.mainCamera.transform.localEulerAngles += new Vector3(-vector2.y * num2, vector2.x * num2, 0f);
				}
				Movement.OldMousePosition = UnityInput.Current.mousePosition;
			}
			else
			{
				NXOUI.RemoveMod("Freecam");
			}
			GUILayout.EndHorizontal();
			GUILayout.EndArea();
			GUILayout.BeginArea(new Rect(10f, 135f, this.window.width - 20f, 25f));
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			this.CreateButton("First Person (" + (NXOUI.firstperson ? "ON" : "OFF") + ")", delegate
			{
				NXOUI.firstperson = !NXOUI.firstperson;
				bool flag8 = NXOUI.firstperson;
				if (flag8)
				{
					NXOUI.AddMod("First Person");
					Visuals.FPC(true);
				}
				else
				{
					NXOUI.RemoveMod("First Person");
					Visuals.FPC(false);
				}
			});
			GUILayout.EndHorizontal();
			GUILayout.EndArea();
			GUILayout.BeginArea(new Rect(10f, 160f, this.window.width - 20f, 25f));
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			this.CreateButton("Button Clicker (" + (NXOUI.buttonclicker ? "ON" : "OFF") + ")", delegate
			{
				NXOUI.buttonclicker = !NXOUI.buttonclicker;
			});
			bool flag2 = NXOUI.buttonclicker;
			if (flag2)
			{
				NXOUI.AddMod("Button Clicker");
				RaycastHit raycastHit;
				bool flag3 = Physics.Raycast(Variables.thirdPersonCamera.GetComponent<Camera>().ScreenPointToRay(Mouse.current.position.ReadValue()), ref raycastHit, 100f);
				if (flag3)
				{
					bool flag4 = Mouse.current.leftButton.isPressed && !Movement.didPress;
					if (flag4)
					{
						Movement.didPress = true;
						GorillaPressableButton componentInParent = raycastHit.collider.GetComponentInParent<GorillaPressableButton>();
						bool flag5 = componentInParent != null;
						if (flag5)
						{
							componentInParent.onPressButton.Invoke();
							componentInParent.ButtonActivation();
							componentInParent.ButtonActivationWithHand(true);
							GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(67, true, 0.05f);
						}
						else
						{
							GorillaKeyboardButton componentInParent2 = raycastHit.collider.GetComponentInParent<GorillaKeyboardButton>();
							bool flag6 = componentInParent2 != null;
							if (flag6)
							{
								GameEvents.OnGorrillaKeyboardButtonPressedEvent.Invoke(componentInParent2.Binding);
								componentInParent2.PressButtonColourUpdate();
								GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(66, true, 0.05f);
							}
						}
					}
					else
					{
						bool flag7 = !Mouse.current.leftButton.isPressed;
						if (flag7)
						{
							Movement.didPress = false;
						}
					}
				}
			}
			else
			{
				NXOUI.RemoveMod("Button Clicker");
			}
			GUILayout.EndHorizontal();
			GUILayout.EndArea();
			GUI.DragWindow();
		}

		// Token: 0x0600005B RID: 91 RVA: 0x000058A8 File Offset: 0x00003AA8
		private void DrawTitle()
		{
			GUIStyle guistyle = new GUIStyle(GUI.skin.box)
			{
				fontSize = 16,
				font = Optimizations.ResourceLoader.CurrentFont,
				fontStyle = 0,
				alignment = 4,
				wordWrap = false,
				normal = 
				{
					textColor = ColorLib.MaterialToColorConverter(ColorLib.ThemeArraya[ColorLib.CurrentTheme])
				}
			};
			string text = "NXO Remastered v5.0 | Left Alt to Open Menu On PC | Right Alt To Hide GUI";
			float num = guistyle.CalcSize(new GUIContent(text)).x + 10f;
			float num2 = 30f;
			Rect rect;
			rect..ctor(5f, 5f, num, num2);
			GUI.Box(rect, "", guistyle);
			GUI.Label(rect, text, guistyle);
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00005960 File Offset: 0x00003B60
		private void DrawModList()
		{
			GUIStyle guistyle = new GUIStyle(GUI.skin.box)
			{
				fontSize = 14,
				font = Optimizations.ResourceLoader.CurrentFont,
				fontStyle = 0,
				alignment = 4,
				wordWrap = false,
				normal = 
				{
					textColor = ColorLib.MaterialToColorConverter(ColorLib.ThemeArraya[ColorLib.CurrentTheme])
				}
			};
			float num = 5f;
			NXOUI.modEntries.Clear();
			foreach (string text in NXOUI.ModNotifications)
			{
				float x = guistyle.CalcSize(new GUIContent(text)).x;
				NXOUI.modEntries.Add(new ValueTuple<string, float>(text, x));
			}
			NXOUI.modEntries.Sort(([Nullable(new byte[]
			{
				0,
				1
			})] ValueTuple<string, float> a, [Nullable(new byte[]
			{
				0,
				1
			})] ValueTuple<string, float> b) => b.Item2.CompareTo(a.Item2));
			for (int i = 0; i < NXOUI.modEntries.Count; i++)
			{
				float num2 = 50f + (float)i * 30f;
				Rect rect;
				rect..ctor(num, num2, NXOUI.modEntries[i].Item2 + 10f, 25f);
				GUI.Box(rect, "", guistyle);
				GUI.Label(rect, NXOUI.modEntries[i].Item1, guistyle);
			}
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00005AEC File Offset: 0x00003CEC
		public static void AddMod(string text)
		{
			bool flag = !NXOUI.ModNotifications.Contains(text);
			if (flag)
			{
				NXOUI.ModNotifications.Add(text);
				while (NXOUI.ModNotifications.Count > 100)
				{
					NXOUI.ModNotifications.RemoveAt(0);
				}
			}
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00005B3C File Offset: 0x00003D3C
		public static void RemoveMod(string text)
		{
			NXOUI.ModNotifications.Remove(text);
		}

		// Token: 0x0600005F RID: 95 RVA: 0x00005B4C File Offset: 0x00003D4C
		private void DestroyTextures()
		{
			bool flag = !this.texturesCreated;
			if (!flag)
			{
				bool flag2 = NXOUI.bgTexture != null;
				if (flag2)
				{
					Object.Destroy(NXOUI.bgTexture);
					NXOUI.bgTexture = null;
				}
				bool flag3 = NXOUI.tfTexture != null;
				if (flag3)
				{
					Object.Destroy(NXOUI.tfTexture);
					NXOUI.tfTexture = null;
				}
				bool flag4 = NXOUI.bTexture != null;
				if (flag4)
				{
					Object.Destroy(NXOUI.bTexture);
					NXOUI.bTexture = null;
				}
				this.texturesCreated = false;
			}
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00005BD8 File Offset: 0x00003DD8
		private Texture2D CreateTexture(int width, int height, Color32 color, Color32 borderColor, int borderThickness, int cornerRadius)
		{
			Texture2D texture2D = new Texture2D(width, height);
			Color32 color2;
			color2..ctor(0, 0, 0, 0);
			NXOUI.<>c__DisplayClass25_0 CS$<>8__locals1;
			CS$<>8__locals1.x = 0;
			while (CS$<>8__locals1.x < width)
			{
				NXOUI.<>c__DisplayClass25_1 CS$<>8__locals2;
				CS$<>8__locals2.y = 0;
				int num2;
				while (CS$<>8__locals2.y < height)
				{
					bool flag = false;
					bool flag2 = false;
					bool flag3 = (CS$<>8__locals1.x < cornerRadius && CS$<>8__locals2.y < cornerRadius) || (CS$<>8__locals1.x >= width - cornerRadius && CS$<>8__locals2.y < cornerRadius) || (CS$<>8__locals1.x < cornerRadius && CS$<>8__locals2.y >= height - cornerRadius) || (CS$<>8__locals1.x >= width - cornerRadius && CS$<>8__locals2.y >= height - cornerRadius);
					if (flag3)
					{
						int cornerX = (CS$<>8__locals1.x < cornerRadius) ? cornerRadius : ((CS$<>8__locals1.x >= width - cornerRadius) ? (width - cornerRadius) : CS$<>8__locals1.x);
						int cornerY = (CS$<>8__locals2.y < cornerRadius) ? cornerRadius : ((CS$<>8__locals2.y >= height - cornerRadius) ? (height - cornerRadius) : CS$<>8__locals2.y);
						float num = NXOUI.<CreateTexture>g__GetCornerDistance|25_0(cornerX, cornerY, ref CS$<>8__locals1, ref CS$<>8__locals2);
						bool flag4 = num > (float)cornerRadius;
						if (flag4)
						{
							flag = true;
						}
						else
						{
							bool flag5 = num > (float)(cornerRadius - borderThickness);
							if (flag5)
							{
								flag2 = true;
							}
						}
					}
					else
					{
						bool flag6 = CS$<>8__locals1.x < borderThickness || CS$<>8__locals1.x >= width - borderThickness || CS$<>8__locals2.y < borderThickness || CS$<>8__locals2.y >= height - borderThickness;
						if (flag6)
						{
							flag2 = true;
						}
					}
					bool flag7 = flag;
					if (flag7)
					{
						texture2D.SetPixel(CS$<>8__locals1.x, CS$<>8__locals2.y, color2);
					}
					else
					{
						bool flag8 = flag2;
						if (flag8)
						{
							texture2D.SetPixel(CS$<>8__locals1.x, CS$<>8__locals2.y, borderColor);
						}
						else
						{
							texture2D.SetPixel(CS$<>8__locals1.x, CS$<>8__locals2.y, color);
						}
					}
					num2 = CS$<>8__locals2.y;
					CS$<>8__locals2.y = num2 + 1;
				}
				num2 = CS$<>8__locals1.x;
				CS$<>8__locals1.x = num2 + 1;
			}
			texture2D.Apply();
			return texture2D;
		}

		// Token: 0x06000061 RID: 97 RVA: 0x00005E08 File Offset: 0x00004008
		private string CreateTextField(string text)
		{
			GUIStyle guistyle = new GUIStyle(GUI.skin.textField)
			{
				alignment = 4,
				normal = 
				{
					background = NXOUI.tfTexture
				},
				active = 
				{
					background = NXOUI.tfTexture
				},
				hover = 
				{
					background = NXOUI.tfTexture
				},
				focused = 
				{
					background = NXOUI.tfTexture
				}
			};
			return GUILayout.TextField(text.ToUpper(), guistyle, Array.Empty<GUILayoutOption>());
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00005E88 File Offset: 0x00004088
		private void CreateButton(string text, Action method)
		{
			GUIStyle guistyle = new GUIStyle(GUI.skin.button)
			{
				normal = 
				{
					background = NXOUI.bTexture
				},
				active = 
				{
					background = NXOUI.bTexture
				},
				hover = 
				{
					background = NXOUI.bTexture
				},
				focused = 
				{
					background = NXOUI.bTexture
				}
			};
			bool flag = GUILayout.Button(text, guistyle, Array.Empty<GUILayoutOption>());
			if (flag)
			{
				method.Invoke();
			}
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00005F6C File Offset: 0x0000416C
		[CompilerGenerated]
		internal static float <CreateTexture>g__GetCornerDistance|25_0(int cornerX, int cornerY, ref NXOUI.<>c__DisplayClass25_0 A_2, ref NXOUI.<>c__DisplayClass25_1 A_3)
		{
			return Mathf.Sqrt((float)((A_2.x - cornerX) * (A_2.x - cornerX) + (A_3.y - cornerY) * (A_3.y - cornerY)));
		}

		// Token: 0x040000DB RID: 219
		public static bool IsGuiVisible = true;

		// Token: 0x040000DC RID: 220
		private Rect window;

		// Token: 0x040000DD RID: 221
		[Nullable(new byte[]
		{
			1,
			0,
			1
		})]
		private static readonly List<ValueTuple<string, float>> modEntries = new List<ValueTuple<string, float>>();

		// Token: 0x040000DE RID: 222
		private static string input = "";

		// Token: 0x040000DF RID: 223
		private static Texture2D bgTexture;

		// Token: 0x040000E0 RID: 224
		private static Texture2D tfTexture;

		// Token: 0x040000E1 RID: 225
		private static Texture2D bTexture;

		// Token: 0x040000E2 RID: 226
		private static bool freecam = false;

		// Token: 0x040000E3 RID: 227
		private static bool firstperson = false;

		// Token: 0x040000E4 RID: 228
		private static bool buttonclicker = false;

		// Token: 0x040000E5 RID: 229
		public static readonly List<string> ModNotifications = new List<string>();

		// Token: 0x040000E6 RID: 230
		private bool texturesCreated = false;

		// Token: 0x040000E7 RID: 231
		public static float GlobalHeight = 190f;

		// Token: 0x040000E8 RID: 232
		public static float GlobalWidth = 360f;
	}
}
