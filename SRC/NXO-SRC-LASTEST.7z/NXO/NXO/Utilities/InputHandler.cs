﻿using System;
using System.Runtime.CompilerServices;
using NXO.Menu;
using UnityEngine;

namespace NXO.Utilities
{
	// Token: 0x0200000B RID: 11
	[NullableContext(1)]
	[Nullable(0)]
	public static class InputHandler
	{
		// Token: 0x06000037 RID: 55 RVA: 0x0000468B File Offset: 0x0000288B
		public static bool RTrigger()
		{
			return Variables.pollerInstance.rightControllerIndexFloat > 0.1f;
		}

		// Token: 0x06000038 RID: 56 RVA: 0x0000469E File Offset: 0x0000289E
		public static bool LTrigger()
		{
			return Variables.pollerInstance.leftControllerIndexFloat > 0.1f;
		}

		// Token: 0x06000039 RID: 57 RVA: 0x000046B1 File Offset: 0x000028B1
		public static bool RGrip()
		{
			return Variables.pollerInstance.rightGrab;
		}

		// Token: 0x0600003A RID: 58 RVA: 0x000046BD File Offset: 0x000028BD
		public static bool LGrip()
		{
			return Variables.pollerInstance.leftGrab;
		}

		// Token: 0x0600003B RID: 59 RVA: 0x000046C9 File Offset: 0x000028C9
		public static bool RPrimary()
		{
			return Variables.pollerInstance.rightControllerPrimaryButton;
		}

		// Token: 0x0600003C RID: 60 RVA: 0x000046D5 File Offset: 0x000028D5
		public static bool LPrimary()
		{
			return Variables.pollerInstance.leftControllerPrimaryButton;
		}

		// Token: 0x0600003D RID: 61 RVA: 0x000046E1 File Offset: 0x000028E1
		public static bool RSecondary()
		{
			return Variables.pollerInstance.rightControllerSecondaryButton;
		}

		// Token: 0x0600003E RID: 62 RVA: 0x000046ED File Offset: 0x000028ED
		public static bool LSecondary()
		{
			return Variables.pollerInstance.leftControllerSecondaryButton;
		}

		// Token: 0x0600003F RID: 63 RVA: 0x000046F9 File Offset: 0x000028F9
		public static bool None()
		{
			return false;
		}

		// Token: 0x06000040 RID: 64 RVA: 0x000046FC File Offset: 0x000028FC
		public static void CycleControllerBind()
		{
			InputHandler.currentIndex = Array.IndexOf<InputHandler.ControllerInput>(InputHandler.controllerInputs, InputHandler.currentControllerInput);
			bool flag = InputHandler.currentIndex == -1;
			if (flag)
			{
				Debug.LogError("Error: Current input is not found in the array!");
			}
			else
			{
				InputHandler.currentIndex = (InputHandler.currentIndex + 1) % InputHandler.controllerInputs.Length;
				InputHandler.currentControllerInput = InputHandler.controllerInputs[InputHandler.currentIndex];
				bool flag2 = InputHandler.cycleControllerBindButton != null;
				if (flag2)
				{
					InputHandler.cycleControllerBindButton.buttonText = "Sound Input : " + InputHandler.currentControllerInput.Method.Name;
				}
			}
		}

		// Token: 0x06000041 RID: 65 RVA: 0x00004790 File Offset: 0x00002990
		public static bool IsCurrentControllerInputActive()
		{
			return InputHandler.currentControllerInput();
		}

		// Token: 0x040000C9 RID: 201
		public static int currentIndex = 0;

		// Token: 0x040000CA RID: 202
		public static InputHandler.ControllerInput currentControllerInput = new InputHandler.ControllerInput(InputHandler.None);

		// Token: 0x040000CB RID: 203
		public static string inputName = "None";

		// Token: 0x040000CC RID: 204
		public static InputHandler.ControllerInput[] controllerInputs = new InputHandler.ControllerInput[]
		{
			new InputHandler.ControllerInput(InputHandler.None),
			new InputHandler.ControllerInput(InputHandler.RPrimary),
			new InputHandler.ControllerInput(InputHandler.LPrimary),
			new InputHandler.ControllerInput(InputHandler.RSecondary),
			new InputHandler.ControllerInput(InputHandler.LSecondary),
			new InputHandler.ControllerInput(InputHandler.RTrigger),
			new InputHandler.ControllerInput(InputHandler.LTrigger),
			new InputHandler.ControllerInput(InputHandler.RGrip),
			new InputHandler.ControllerInput(InputHandler.LGrip)
		};

		// Token: 0x040000CD RID: 205
		public static ButtonHandler.Button cycleControllerBindButton;

		// Token: 0x02000037 RID: 55
		// (Invoke) Token: 0x060001C3 RID: 451
		[NullableContext(0)]
		public delegate bool ControllerInput();
	}
}
