﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace NXO.Utilities
{
	// Token: 0x0200000F RID: 15
	[NullableContext(1)]
	[Nullable(0)]
	public class PlatformLib
	{
		// Token: 0x06000066 RID: 102 RVA: 0x00005FA8 File Offset: 0x000041A8
		public static bool PlatformInput(bool isRightHand)
		{
			bool flag = PlatformLib.isTriggerPlatforms;
			bool result;
			if (flag)
			{
				result = (isRightHand ? InputHandler.RTrigger() : InputHandler.LTrigger());
			}
			else
			{
				result = (isRightHand ? InputHandler.RGrip() : InputHandler.LGrip());
			}
			return result;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x00005FE8 File Offset: 0x000041E8
		private static void OnDestroy()
		{
			bool flag = PlatformLib.leftSideObjects != null;
			if (flag)
			{
				PlatformLib.DestroySides(PlatformLib.leftSideObjects);
				PlatformLib.leftSideObjects = null;
			}
			bool flag2 = PlatformLib.rightSideObjects != null;
			if (flag2)
			{
				PlatformLib.DestroySides(PlatformLib.rightSideObjects);
				PlatformLib.rightSideObjects = null;
			}
			Object.Destroy(PlatformLib.RightIce);
			Object.Destroy(PlatformLib.leftIce);
			Object.Destroy(PlatformLib.leftPlatform);
			Object.Destroy(PlatformLib.rightPlatform);
			PlatformLib.leftControllerTransform = null;
			PlatformLib.rightControllerTransform = null;
			PlatformLib.defaultShader = null;
			PlatformLib.transparentMaterial = null;
			PlatformLib.frozoneMaterial = null;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00006080 File Offset: 0x00004280
		private static void CacheControllerTransforms()
		{
			bool flag = PlatformLib.leftControllerTransform == null || PlatformLib.rightControllerTransform == null;
			if (flag)
			{
				bool flag2 = Variables.playerInstance != null;
				if (flag2)
				{
					PlatformLib.leftControllerTransform = Variables.playerInstance.leftControllerTransform;
					PlatformLib.rightControllerTransform = Variables.playerInstance.rightControllerTransform;
				}
				else
				{
					Debug.LogError("GorillaLocomotion Player instance is null. Cannot cache controller transforms.");
				}
			}
		}

		// Token: 0x06000069 RID: 105 RVA: 0x000060F0 File Offset: 0x000042F0
		public static void CreateOrDestroyPlatform(ref GameObject platform, bool isGrabbing, Transform controllerTransform, bool isInvisible)
		{
			bool flag = controllerTransform == null;
			if (flag)
			{
				Debug.LogError("Controller transform is null. Cannot create or destroy platform.");
			}
			else if (isGrabbing)
			{
				bool flag2 = platform == null;
				if (flag2)
				{
					platform = PlatformLib.CreatePlatform(controllerTransform, isInvisible);
				}
			}
			else
			{
				bool flag3 = platform != null;
				if (flag3)
				{
					Object.Destroy(platform);
				}
			}
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00006150 File Offset: 0x00004350
		public static GameObject CreatePlatform(Transform controllerTransform, bool isInvisible)
		{
			bool flag = controllerTransform == null;
			GameObject result;
			if (flag)
			{
				Debug.LogError("Controller transform is null. Cannot create platform.");
				result = null;
			}
			else
			{
				PlatformLib.CacheCommonAssets();
				PlatformLib.CacheControllerTransforms();
				GameObject gameObject = GameObject.CreatePrimitive(3);
				gameObject.transform.localScale = PlatformLib.cachedPlatformScale;
				gameObject.transform.position = controllerTransform.position + new Vector3(0f, -0.02f, 0f);
				gameObject.transform.rotation = controllerTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
				Renderer component = gameObject.GetComponent<Renderer>();
				bool flag2 = component != null;
				if (flag2)
				{
					component.material = PlatformLib.transparentMaterial;
					if (isInvisible)
					{
						component.enabled = false;
					}
				}
				else
				{
					Debug.LogError("Renderer component missing on platform.");
				}
				GorillaSurfaceOverride gorillaSurfaceOverride = gameObject.AddComponent<GorillaSurfaceOverride>();
				bool flag3 = gorillaSurfaceOverride != null;
				if (flag3)
				{
					gorillaSurfaceOverride.overrideIndex = PlatformLib.surfaceOverrideIndex;
				}
				else
				{
					Debug.LogError("Failed to add GorillaSurfaceOverride to platform.");
				}
				result = gameObject;
			}
			return result;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00006270 File Offset: 0x00004470
		public static GameObject CreateFrozonePlatform(Transform controllerTransform)
		{
			bool flag = controllerTransform == null;
			GameObject result;
			if (flag)
			{
				Debug.LogError("Controller transform is null. Cannot create Frozone platform.");
				result = null;
			}
			else
			{
				PlatformLib.CacheCommonAssets();
				PlatformLib.CacheControllerTransforms();
				GameObject gameObject = GameObject.CreatePrimitive(3);
				gameObject.transform.localScale = PlatformLib.cachedPlatformScale;
				Renderer component = gameObject.GetComponent<Renderer>();
				bool flag2 = component != null;
				if (flag2)
				{
					component.material.color = PlatformLib.frozoneColor;
				}
				gameObject.transform.position = controllerTransform.position + new Vector3(0f, -0.06f, 0f);
				gameObject.transform.rotation = controllerTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
				GorillaSurfaceOverride gorillaSurfaceOverride = gameObject.AddComponent<GorillaSurfaceOverride>();
				bool flag3 = gorillaSurfaceOverride != null;
				if (flag3)
				{
					gorillaSurfaceOverride.overrideIndex = 59;
				}
				else
				{
					Debug.LogError("Failed to add GorillaSurfaceOverride to Frozone platform.");
				}
				result = gameObject;
			}
			return result;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00006374 File Offset: 0x00004574
		public static void CreateOrDestroyFrozonePlatform(ref GameObject icePlatform, bool isGrabbing, Transform controllerTransform)
		{
			bool flag = controllerTransform == null;
			if (flag)
			{
				Debug.LogError("Controller transform is null. Cannot create or destroy Frozone platform.");
			}
			else if (isGrabbing)
			{
				icePlatform = PlatformLib.CreateFrozonePlatform(controllerTransform);
				bool flag2 = icePlatform != null;
				if (flag2)
				{
					Object.Destroy(icePlatform, 0.75f);
				}
			}
		}

		// Token: 0x0600006D RID: 109 RVA: 0x000063C8 File Offset: 0x000045C8
		private static void CacheCommonAssets()
		{
			bool flag = PlatformLib.defaultShader == null;
			if (flag)
			{
				PlatformLib.defaultShader = Shader.Find("UI/Default");
			}
			bool flag2 = PlatformLib.transparentMaterial == null && PlatformLib.defaultShader != null;
			if (flag2)
			{
				PlatformLib.transparentMaterial = new Material(PlatformLib.defaultShader);
				PlatformLib.transparentMaterial = ColorLib.ThemeArraya[ColorLib.CurrentTheme];
			}
			bool flag3 = PlatformLib.frozoneMaterial == null && PlatformLib.defaultShader != null;
			if (flag3)
			{
				PlatformLib.frozoneMaterial = new Material(PlatformLib.defaultShader);
				PlatformLib.frozoneMaterial.color = PlatformLib.frozoneColor;
			}
			bool flag4 = PlatformLib.surfaceOverrideIndex == -1;
			if (flag4)
			{
				GameObject gameObject = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/sky jungle entrance 2/ElevatorClouds/Cloud_Platform_001 Variant");
				bool flag5 = gameObject != null;
				if (flag5)
				{
					GorillaSurfaceOverride component = gameObject.GetComponent<GorillaSurfaceOverride>();
					bool flag6 = component != null;
					if (flag6)
					{
						PlatformLib.surfaceOverrideIndex = component.overrideIndex;
					}
					else
					{
						Debug.LogError("GorillaSurfaceOverride component missing on surface object.");
					}
				}
				else
				{
					Debug.LogError("Surface object not found.");
				}
			}
		}

		// Token: 0x0600006E RID: 110 RVA: 0x000064E4 File Offset: 0x000046E4
		public static void DestroySides(GameObject[] sides)
		{
			bool flag = sides == null;
			if (flag)
			{
				Debug.LogWarning("Sides array is null. Cannot destroy sides.");
			}
			else
			{
				foreach (GameObject gameObject in sides)
				{
					bool flag2 = gameObject != null;
					if (flag2)
					{
						Object.Destroy(gameObject);
					}
				}
			}
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00006538 File Offset: 0x00004738
		public static void CreateOrDestroySides(ref GameObject[] sideObjects, bool isGrabbing, Transform controllerTransform, bool isInvisible)
		{
			bool flag = controllerTransform == null;
			if (flag)
			{
				Debug.LogError("Controller transform is null. Cannot create or destroy sides.");
			}
			else if (isGrabbing)
			{
				bool flag2 = sideObjects == null;
				if (flag2)
				{
					sideObjects = PlatformLib.CreateSides(controllerTransform, isInvisible);
				}
			}
			else
			{
				bool flag3 = sideObjects != null;
				if (flag3)
				{
					PlatformLib.DestroySides(sideObjects);
					sideObjects = null;
				}
			}
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00006594 File Offset: 0x00004794
		public static GameObject[] CreateSides(Transform handTransform, bool isInvisible)
		{
			bool flag = handTransform == null;
			GameObject[] result;
			if (flag)
			{
				Debug.LogError("Hand transform is null. Cannot create sides.");
				result = null;
			}
			else
			{
				PlatformLib.CacheCommonAssets();
				PlatformLib.CacheControllerTransforms();
				GameObject[] array = new GameObject[6];
				Vector3[] array2 = new Vector3[]
				{
					handTransform.right * -0.1f * 0.75f,
					handTransform.right * 0.1f * 0.75f,
					handTransform.up * 0.1f * 0.75f,
					handTransform.up * -0.1f * 0.75f,
					handTransform.forward * 0.1f * 0.75f,
					handTransform.forward * -0.1f * 0.75f
				};
				for (int i = 0; i < 6; i++)
				{
					array[i] = GameObject.CreatePrimitive(3);
					array[i].transform.localScale = ((i < 2) ? PlatformLib.cachedSideThicknessX : ((i < 4) ? PlatformLib.cachedSideThicknessY : PlatformLib.cachedSideThicknessZ));
					array[i].transform.position = handTransform.position + array2[i];
					array[i].transform.rotation = handTransform.rotation;
					Renderer component = array[i].GetComponent<Renderer>();
					bool flag2 = component != null;
					if (flag2)
					{
						component.material = PlatformLib.transparentMaterial;
						if (isInvisible)
						{
							component.enabled = false;
						}
					}
					GorillaSurfaceOverride gorillaSurfaceOverride = array[i].AddComponent<GorillaSurfaceOverride>();
					bool flag3 = gorillaSurfaceOverride != null;
					if (flag3)
					{
						gorillaSurfaceOverride.overrideIndex = PlatformLib.surfaceOverrideIndex;
					}
				}
				result = array;
			}
			return result;
		}

		// Token: 0x040000E9 RID: 233
		private static Shader defaultShader;

		// Token: 0x040000EA RID: 234
		private static Material transparentMaterial;

		// Token: 0x040000EB RID: 235
		private static Material frozoneMaterial;

		// Token: 0x040000EC RID: 236
		private static int surfaceOverrideIndex = -1;

		// Token: 0x040000ED RID: 237
		private static Transform leftControllerTransform;

		// Token: 0x040000EE RID: 238
		private static Transform rightControllerTransform;

		// Token: 0x040000EF RID: 239
		private static Vector3 cachedPlatformScale = new Vector3(0.28f, 0.015f, 0.28f);

		// Token: 0x040000F0 RID: 240
		private static Vector3 cachedSideThicknessX = new Vector3(0.01f, 0.2f, 0.2f) * 0.75f;

		// Token: 0x040000F1 RID: 241
		private static Vector3 cachedSideThicknessY = new Vector3(0.2f, 0.01f, 0.2f) * 0.75f;

		// Token: 0x040000F2 RID: 242
		private static Vector3 cachedSideThicknessZ = new Vector3(0.2f, 0.2f, 0.01f) * 0.75f;

		// Token: 0x040000F3 RID: 243
		private static Color frozoneColor = new Color(0.5254902f, 0.8392157f, 0.84705883f);

		// Token: 0x040000F4 RID: 244
		public static GameObject RightIce;

		// Token: 0x040000F5 RID: 245
		public static GameObject leftIce;

		// Token: 0x040000F6 RID: 246
		public static GameObject leftPlatform;

		// Token: 0x040000F7 RID: 247
		public static GameObject rightPlatform;

		// Token: 0x040000F8 RID: 248
		public static GameObject[] leftSideObjects;

		// Token: 0x040000F9 RID: 249
		public static GameObject[] rightSideObjects;

		// Token: 0x040000FA RID: 250
		public static bool leftPlatformEnabled = false;

		// Token: 0x040000FB RID: 251
		public static bool rightPlatformEnabled = false;

		// Token: 0x040000FC RID: 252
		public static bool isTriggerPlatforms = false;
	}
}
