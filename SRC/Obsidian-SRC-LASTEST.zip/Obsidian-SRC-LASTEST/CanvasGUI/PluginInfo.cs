﻿using System;

namespace CanvasGUI
{
	// Token: 0x02000037 RID: 55
	public class PluginInfo
	{
		// Token: 0x060001E7 RID: 487 RVA: 0x00653774 File Offset: 0x00651974
		public unsafe PluginInfo()
		{
			if ((*(&PluginInfo.qTcfIQynJ0) ^ *(&PluginInfo.qTcfIQynJ0)) != 0)
			{
				int[] array = new int[10];
				int num;
				int num2;
				int num4;
				int num3;
				if (num > num)
				{
					num2 = num - 182;
					if (num > num)
					{
						num3 = num2 + num4;
						num4 = -num2;
						*(ref PluginInfo.OxKhnPpa0p + (IntPtr)num2) = num2;
					}
					num4 = (int)((sbyte)num2);
				}
				num = (num2 ^ 93757847);
				num2 = num3 - num4;
				PluginInfo.OxKhnPpa0p = num3;
				*(ref PluginInfo.OxKhnPpa0p + (IntPtr)num4) = num4;
				if (num > num)
				{
					num4 = (num2 ^ num4);
					num = (int)((ushort)num);
					num4 = ~num;
					PluginInfo.OxKhnPpa0p = num;
					if (num > num)
					{
						num3 = num3;
						PluginInfo.OxKhnPpa0p = num3;
						num2 = num + num4;
					}
					num3 = (int)((byte)num2);
					array[num4 + 9 - num2] = num3 - -7;
				}
				num4 &= 561255860;
				num4 = *(ref PluginInfo.OxKhnPpa0p + (IntPtr)num);
				if (num > num)
				{
					num2 = 1319927016;
					if (num2 > num2)
					{
						num = ~num4;
						num2 = -num;
						num4 = -num4;
						PluginInfo.OxKhnPpa0p = num3;
						num2 = num4 / num2;
						num2 = ~num4;
					}
					num3 = *(ref num2 + (IntPtr)num4);
					num3 = array[num4 + 5 - num] + 9;
					if (num3 > num3)
					{
						num2 = num3 >> 3;
						num3 = (num2 | num4);
						num3 = (int)((ushort)num4);
						num2 = (num ^ 2132266666);
					}
					num += num4;
					array[num2 + 8 - num3] = (num | 7);
					num = num3 % num4;
					num3 = num / num4;
					num4 = (int)((ushort)num);
				}
				num4 = PluginInfo.OxKhnPpa0p;
				num4 = (int)((sbyte)num3);
				num = PluginInfo.OxKhnPpa0p;
				num4 = num2 * 762;
				num4 = (int)((byte)num4);
				num3 = (num4 | 486367755);
				array[num3 + 8 - num4] = (num3 | 1);
				num = num2 - 239;
				num3 = *(ref num4 + (IntPtr)num2);
				if (num3 > num3)
				{
					num2 = (int)((byte)num4);
					num = (num2 & 17923440);
				}
				num3 = num2;
				num = num2 + num4;
				num = (num2 | 1139720393);
				num4 = *(ref PluginInfo.OxKhnPpa0p + (IntPtr)num4);
				num = num2;
				num4 = num3 << 5;
				num4 += 822;
				num4 = (int)((ushort)num3);
				num3 = num * num4;
				array[num4 + 9 - num3] = (num4 | -9);
				num = num3 + num4;
				num2 = PluginInfo.OxKhnPpa0p;
			}
			base..ctor();
			for (;;)
			{
				IL_1D1:
				uint num5 = 638886994U;
				for (;;)
				{
					uint num6;
					switch ((num6 = (num5 ^ (uint)(*(&PluginInfo.oMytYgUmOk)))) % (uint)(*(&PluginInfo.XEFVON2mLg)))
					{
					case 0U:
						goto IL_1D1;
					case 1U:
					{
						uint num7 = num6 - (uint)(*(&PluginInfo.ob8ZIsGJu7)) | (uint)(*(&PluginInfo.Rrq5IMg3Td));
						num5 = (num7 - (uint)(*(&PluginInfo.iztePbwQAb)) ^ (uint)(*(&PluginInfo.v9FuENNYkp)));
						continue;
					}
					}
					return;
				}
			}
		}

		// Token: 0x0404FD81 RID: 327041
		public const string GUID = "com.obs.gorillatag.lol";

		// Token: 0x0404FD82 RID: 327042
		public const string Name = "Obsidian.LOL";

		// Token: 0x0404FD83 RID: 327043
		public const string Version = "2.0.1";

		// Token: 0x0404FD84 RID: 327044 RVA: 0x0014B430 File Offset: 0x00149630
		static int qTcfIQynJ0;

		// Token: 0x0404FD85 RID: 327045 RVA: 0x0014B438 File Offset: 0x00149638
		static int OxKhnPpa0p;

		// Token: 0x0404FD86 RID: 327046 RVA: 0x0014B440 File Offset: 0x00149640
		static readonly int oMytYgUmOk;

		// Token: 0x0404FD87 RID: 327047 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int XEFVON2mLg;

		// Token: 0x0404FD88 RID: 327048 RVA: 0x0014B448 File Offset: 0x00149648
		static readonly int ob8ZIsGJu7;

		// Token: 0x0404FD89 RID: 327049 RVA: 0x0014B450 File Offset: 0x00149650
		static readonly int Rrq5IMg3Td;

		// Token: 0x0404FD8A RID: 327050 RVA: 0x0014B458 File Offset: 0x00149658
		static readonly int iztePbwQAb;

		// Token: 0x0404FD8B RID: 327051 RVA: 0x0014B460 File Offset: 0x00149660
		static readonly int v9FuENNYkp;
	}
}
