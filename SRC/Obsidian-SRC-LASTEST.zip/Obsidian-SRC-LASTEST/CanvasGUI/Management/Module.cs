﻿using System;
using System.Runtime.CompilerServices;

namespace CanvasGUI.Management
{
	// Token: 0x0200003A RID: 58
	public class Module
	{
		// Token: 0x17000039 RID: 57
		// (get) Token: 0x060001EE RID: 494 RVA: 0x0065F8C8 File Offset: 0x0065DAC8
		// (set) Token: 0x060001EF RID: 495 RVA: 0x00660260 File Offset: 0x0065E460
		public unsafe string title
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Module.cPByxjID62) ^ *(&Module.cPByxjID62)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2;
					*(ref Module.4I1Ebl54R2 + (IntPtr)num2) = num2;
					int num3;
					int num4;
					int num5;
					if (num3 > num3)
					{
						if (num2 > num2)
						{
							num2 = Module.4I1Ebl54R2;
							Module.4I1Ebl54R2 = num4;
							num5 = num2 / num;
							num2 &= 604809475;
							num5 |= 1074274471;
							num3 = num * num3;
							array[num5 + 7 - num] = (num2 | 2);
						}
						num2 = ~num2;
						num5 = array[num2 + 8 - num5] + 4;
						if (num > num)
						{
							num3 |= num;
							num4 = num + num3;
							num4 = (int)((byte)num5);
							num = num4 % num;
							num4 = num % 842;
							num2 = (num5 & num);
						}
						num5 = num3 * num;
						num3 |= 1927048216;
						num4 = 462456992;
						*(ref num2 + (IntPtr)num) = num;
						*(ref num3 + (IntPtr)num) = num;
						*(ref Module.4I1Ebl54R2 + (IntPtr)num5) = num5;
					}
					num2 = -num3;
					num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
					num2 = num4 % num;
					*(ref num4 + (IntPtr)num) = num;
					if (num3 > num3)
					{
						num5 = array2[num + 7 - num5] + 6;
					}
					num3 %= num;
					num2 = (array[num3 + 8 - num3] ^ -6);
					num3 = num3;
					num5 = num3 / num;
					array[num5 + 7 - num3] = (num3 | -7);
					if (num4 > num4)
					{
						num3 ^= 543617963;
						if (num5 > num5)
						{
							num3 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
							num4 = num5 - num;
							num4 = num5 * 207;
							array2[num3 + 6 - num4] = num2 - 7;
							num = (int)((ushort)num4);
							num2 = (int)((sbyte)num2);
						}
						num2 = num;
						num2 = *(ref num + (IntPtr)num3);
						num2 = num2;
						num2 = 1069992037;
						num2 = num5 - num;
						if (num > num)
						{
							num2 = num5;
							num4 = num2 - num;
							num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
							num5 = num4;
							num4 = num3 % num;
							num = num2 * num;
							Module.4I1Ebl54R2 = num2;
							num /= num3;
							num3 = (num2 | num);
							num = array[num2 + 5 - num] + 8;
						}
					}
					*(ref num2 + (IntPtr)num) = num;
					num4 = num;
					num2 = num4 / 216;
					if (num2 > num2)
					{
						num = num3 * 329;
						num2 = num5 - num;
					}
					num = -num2;
					array2[num3 + 7 - num4] = num2 - -5;
					if (num4 > num4)
					{
						*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
						num5 = (array[num5 + 6 - num2] ^ 0);
						num2 = num;
						num2 = num4 - num;
					}
					num = -num4;
					*(ref Module.4I1Ebl54R2 + (IntPtr)num2) = num2;
					num3 = -num4;
					num2 |= num;
					num5 = (num4 ^ num);
					if (num5 > num5)
					{
						if (num3 > num3)
						{
							*(ref Module.4I1Ebl54R2 + (IntPtr)num5) = num5;
							num4 = (num2 & num);
							num = num3;
							num = num4;
							num2 = num5 + num;
							num5 = (array2[num4 + 8 - num3] ^ 5);
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
							num2 = -num3;
							num2 = (array[num3 + 5 - num3] ^ -5);
							num4 = (num2 & 309347435);
						}
						if (num3 > num3)
						{
							num3 = (int)((sbyte)num);
							num5 = num4 % 812;
							num = num4 + num;
							num5 = array[num4 + 7 - num4] + -4;
							num2 = (num3 & 772508775);
						}
						num4 = num3 + num;
						num4 = ~num;
						if (num5 > num5)
						{
							array2[num5 + 7 - num] = num5 - -8;
							num3 = num2 % 36;
						}
						num5 = (num & 1968908988);
						num3 = -num3;
						num4 = num;
						num3 ^= 1494263468;
					}
					array2[num + 8 - num5] = num3 - 2;
					if (num2 > num2)
					{
						num = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
						num3 = num;
						*(ref num4 + (IntPtr)num) = num;
						num4 = array[num5 + 8 - num2] + 6;
						num3 = (num2 | num);
						num5 = num2 + 322;
						num2 = num4 - 384;
					}
					if (num2 > num2)
					{
						num2 |= num;
					}
					num2 = 1413695969;
					num3 = ~num2;
					num2 = Module.4I1Ebl54R2;
					num2 = num3 / num;
					num5 += 232;
					if (num3 > num3)
					{
						num5 = Module.4I1Ebl54R2;
						num4 = num5 + 943;
						num3 = num4 - 430;
					}
					num4 = num5;
					if (num4 > num4)
					{
						num4 = -num5;
						num2 = num5 / num;
						if (num > num)
						{
							num2 = num5 / 377;
							num = (array2[num3 + 7 - num2] ^ 5);
							num3 = (num ^ num3);
							num = *(ref num4 + (IntPtr)num);
						}
						num5 = num3 % num;
						num4 = (int)((byte)num);
						num5 = num5;
					}
					if (num4 > num4)
					{
						num = num5 * num;
						if (num > num)
						{
							num2 = num3 * 981;
							num2 = num5 / 697;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num5) = num5;
							num3 = ~num4;
						}
						num5 = num3 - num;
						num2 = num3 - 538;
						num2 = num3 + num;
					}
					if (num > num)
					{
						num5 = Module.4I1Ebl54R2;
						if (num5 > num5)
						{
							num3 = num4 / num;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num5) = num5;
							num2 = num * 12;
							num5 = (num & 977599710);
							num2 = num4 + 329;
							num2 ^= num;
							array2[num5 + 8 - num5] = (num2 | -8);
							num4 = num5;
						}
					}
					num4 = (num & 1656493305);
				}
				return this.<title>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Module.kemI4HozXk) ^ *(&Module.kemI4HozXk)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = array[num + 6 - num2] ^ 3;
					int num3;
					num2 = (int)((ushort)num3);
					num3 = (int)((sbyte)num2);
					int num4;
					array[num + 8 - num4] = num2 - 4;
					int num5;
					num2 = (num5 & 840699423);
					num3 = num5 - 441;
					num3 = *(ref num5 + (IntPtr)num);
					num5 = num3 + num;
					num5 = (int)((short)num4);
					num4 = (num3 | 554559714);
					if (num3 > num3)
					{
						num4 = num2;
						array[num + 7 - num3] = (num2 | 0);
						num2 = 1124143676;
						num5 *= 304;
						num5 = Module.4I1Ebl54R2;
						num5 = (array[num4 + 6 - num4] ^ -6);
					}
					if (num3 > num3)
					{
						num4 = *(ref num2 + (IntPtr)num);
						num4 = *(ref num + (IntPtr)num4);
					}
					if (num2 > num2)
					{
						num4 = num3 % 151;
						if (num4 > num4)
						{
							num2 = (int)((byte)num4);
							num2 = -num2;
							num5 = ~num;
						}
						if (num2 > num2)
						{
							num4 = num4;
							num = -num;
							num5 = *(ref num2 + (IntPtr)num);
							num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
							num5 = (num3 ^ 877264984);
							num3 = (array[num3 + 9 - num2] ^ 8);
							num = (num4 & 1619563678);
							num = num4;
							num4 = -num5;
						}
						num5 = (num ^ 271044011);
						num2 = *(ref num2 + (IntPtr)num);
						if (num > num)
						{
							num4 = num2 + 770;
							num2 = ~num4;
							num5 = ~num;
							num = (num5 | 1620582898);
							num3 = num4;
							num2 = num5;
							array[num2 + 6 - num2] = (num4 | -4);
						}
						num = (array[num + 8 - num5] ^ -2);
						num5 = 964159322;
					}
					num4 = num4;
					num = num5 / 472;
					array[num2 + 9 - num4] = (num | -1);
					num3 = num2 % 471;
					num3 = (int)((byte)num5);
					if (num > num)
					{
						num = ~num5;
						num2 = num * num4;
						num5 = num2 % num;
						num3 = (num4 & 1842700622);
					}
					num3 = -num4;
				}
				this.<title>k__BackingField = value;
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060001F0 RID: 496 RVA: 0x006605F0 File Offset: 0x0065E7F0
		// (set) Token: 0x060001F1 RID: 497 RVA: 0x006607E8 File Offset: 0x0065E9E8
		public unsafe string tooltip
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Module.owpbWOJL97) ^ *(&Module.owpbWOJL97)) != 0)
				{
					int[] array = new int[10];
					int num = (int)((byte)num);
					int num3;
					int num2 = num3 & 946757478;
					num3 |= 1662579883;
					num2 = 1618956645;
					num = num3;
					num3 = num2 / 84;
					array[num3 + 6 - num] = num - -8;
					num = (num3 ^ num2);
					num3 = num % num3;
					num3 = (num ^ 929931273);
					if (num2 > num2)
					{
						num2 = Module.4I1Ebl54R2;
						num = 1247646171;
						num3 = (num | num3);
						if (num > num)
						{
							*(ref num + (IntPtr)num3) = num3;
						}
						num = array[num3 + 5 - num2] + -6;
					}
					num3 = (num2 ^ num3);
					num2 = (num & num3);
					num2 = (int)((ushort)num2);
					num3 = array[num2 + 6 - num2] + -8;
					num = num3 - num2;
					num2 |= 874760990;
					num3 = num3;
					num3 = num % num3;
					num &= num3;
					num3 = num2 + num3;
					num = num2 << 2;
					num2 = num;
					num = 1369648404;
					num = array[num3 + 7 - num2] + -4;
				}
				return this.<tooltip>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Module.MI4ANDYe4N) ^ *(&Module.MI4ANDYe4N)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					int num3;
					int num4;
					if (num > num)
					{
						num2 *= num;
						num3 = (num2 | 1950747051);
						num4 = num2 % num;
						if (num2 > num2)
						{
							num4 += 542;
							num3 = (num4 | num);
							num4 = num4;
							num = ~num;
							num = num4 / num;
							num4 = (num3 & num);
							*(ref num2 + (IntPtr)num) = num;
						}
						if (num2 > num2)
						{
							num4 = num + 542;
							num = num3 * num;
							num = num4;
							num3 = num4 + 153;
							num3 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
							num3 = -num;
							num4 = *(ref num3 + (IntPtr)num);
							num2 = num3 - 788;
							num3 ^= 1813557289;
							Module.4I1Ebl54R2 = num2;
						}
						if (num2 > num2)
						{
							num2 = (num4 ^ 79298102);
							num = (int)((short)num4);
						}
						num3 = (num ^ num3);
						num = num4 / 980;
						num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
					}
					num2 -= 85;
					num3 = array2[num2 + 7 - num] + 8;
					if (num2 > num2)
					{
						num2 = -num;
						num3 = array2[num4 + 8 - num2] + -2;
						num4 = Module.4I1Ebl54R2;
						num = num3 * num;
						num2 = -num3;
						num2 |= 1276206871;
						num = ~num3;
						num4 = (num2 | num);
						num = -num2;
					}
					Module.4I1Ebl54R2 = num2;
					num4 = (int)((short)num);
					num2 = num >> 6;
					num = num2 % num;
					num3 = num4 * 344;
					num4 = num * 931;
					Module.4I1Ebl54R2 = num4;
					num3 = *(ref num + (IntPtr)num3);
					if (num2 > num2)
					{
						num = (int)((short)num);
						num2 = num4;
						num3 = (num | 618829311);
						num4 = -num;
						*(ref Module.4I1Ebl54R2 + (IntPtr)num4) = num4;
						array2[num3 + 7 - num4] = (num4 | -7);
					}
					num4 = (num2 & num);
					if (num > num)
					{
						num3 = ~num;
						num2 = (int)((byte)num4);
						num2 = Module.4I1Ebl54R2;
						num = (num2 & num);
						if (num3 > num3)
						{
							num = num3 - num;
							array2[num4 + 5 - num3] = num - -6;
							array2[num3 + 6 - num3] = (num3 | 5);
							num4 = (num2 & num);
							num4 = (num | num3);
							num3 = array2[num3 + 7 - num] + -4;
							num2 = (num4 | 1209006994);
							Module.4I1Ebl54R2 = num3;
							num3 = array[num4 + 6 - num2] + -9;
						}
						num = num3 - num;
						num2 = num3 % num;
						array2[num + 5 - num3] = num4 - 9;
						num2 = (int)((short)num2);
					}
					num2 = ~num2;
					num /= num3;
					*(ref Module.4I1Ebl54R2 + (IntPtr)num2) = num2;
					num3 = num4 << 6;
					if (num > num)
					{
						num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num4);
						num4 = num >> 1;
						num = ~num2;
						num3 = num2 / 90;
						num4 %= 47;
					}
					num4 = ~num2;
					num = num3;
					num2 |= 574043252;
					num2 = num3;
					num = *(ref num4 + (IntPtr)num);
					num4 = num2 + num;
					num4 = Module.4I1Ebl54R2;
					num2 = (num | 191807844);
					num4 = (num3 | 1886775049);
					num = (num3 | 1729489249);
					num4 = ~num4;
					array[num2 + 8 - num4] = (num4 | 1);
					num /= num3;
					num3 = ~num3;
					num = num3 << 5;
					if (num2 > num2)
					{
						num3 = Module.4I1Ebl54R2;
						array2[num4 + 8 - num3] = num3 - -6;
						num3 = num3;
						*(ref num3 + (IntPtr)num) = num;
					}
					Module.4I1Ebl54R2 = num;
					num4 += 46;
					*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
					num = num4 * num;
					*(ref num + (IntPtr)num3) = num3;
					*(ref Module.4I1Ebl54R2 + (IntPtr)num4) = num4;
					num4 = (num3 & 281261399);
					array2[num4 + 8 - num2] = num4 - 5;
					num4 = num / num3;
					num4 = num2 - 492;
					if (num3 > num3)
					{
						array[num3 + 5 - num] = (num4 | -8);
						num4 ^= 1713297915;
						num4 = *(ref num2 + (IntPtr)num);
						Module.4I1Ebl54R2 = num3;
						if (num4 > num4)
						{
							num3 = num4 >> 2;
							num3 = (num & num3);
							num = num2 - 879;
							num = num4 * num;
							num3 = ~num4;
							num = *(ref num4 + (IntPtr)num);
							num2 = (num3 & 1334173342);
							num2 = (int)((ushort)num3);
							num4 = (int)((ushort)num);
						}
					}
				}
				this.<tooltip>k__BackingField = value;
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x00660F88 File Offset: 0x0065F188
		// (set) Token: 0x060001F3 RID: 499 RVA: 0x006611DC File Offset: 0x0065F3DC
		public unsafe string[] options
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Module.JVKot7m23q) ^ *(&Module.JVKot7m23q)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = num2 | 1179924552;
					int num4;
					int num5;
					int num3 = *(ref num4 + (IntPtr)num5);
					num5 = num2 << 7;
					num = 764954966;
					num5 = (num | num4);
					num5 = (num4 | 936388664);
					num4 = -num2;
					num = num4 * 838;
					num3 = (num5 ^ 949527212);
					num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
					num2 = num4;
					num = num5 / 735;
					if (num4 > num4)
					{
						if (num3 > num3)
						{
							*(ref Module.4I1Ebl54R2 + (IntPtr)num5) = num5;
							num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num4);
							num = num2;
							num2 = num;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num5) = num5;
							num4 = (num3 | num4);
							num2 = num5 / 911;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num5) = num5;
						}
						num5 = (int)((sbyte)num5);
						array[num4 + 9 - num2] = (num | -2);
						num5 = num5;
						num = *(ref num4 + (IntPtr)num5);
					}
					array[num5 + 8 - num5] = (num | -4);
					num2 = num3 % 259;
					array[num + 8 - num5] = (num3 | 9);
					num5 = Module.4I1Ebl54R2;
					num4 = num4;
					if (num5 > num5)
					{
						num *= 709;
					}
					num = num2 - 8;
					num2 = num4;
					*(ref num + (IntPtr)num4) = num4;
				}
				return this.<options>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Module.4TpVNHcarM) ^ *(&Module.4TpVNHcarM)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
					int num3 = -num;
					int num4;
					if (num3 > num3)
					{
						if (num4 > num4)
						{
							Module.4I1Ebl54R2 = num2;
							array[num + 9 - num2] = (num | 5);
							num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
							num2 = ~num3;
							num = (num3 | num);
							array[num2 + 8 - num] = (num2 | 2);
							num = (num4 ^ num);
							num3 = num3;
							num3 = *(ref num3 + (IntPtr)num);
						}
						num2 = num / 177;
						num3 /= num;
						*(ref num + (IntPtr)num3) = num3;
						if (num > num)
						{
							num |= 1855517098;
							num2 = num * 944;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
							num = num2;
						}
						if (num > num)
						{
							num4 = num3 - num;
							num4 = num2 / 389;
							num4 -= num;
						}
					}
					Module.4I1Ebl54R2 = num2;
					num3 = num;
					num = (num4 & 1164403572);
					num3 /= num;
					num3 = array[num2 + 8 - num4] + 3;
					num = num3 / 811;
					if (num2 > num2)
					{
						num3 = num - num3;
						num4 = num3 - num;
						num4 = num;
					}
					num = num2 + 237;
					Module.4I1Ebl54R2 = num4;
					num = num3;
					array[num2 + 9 - num4] = (num | -6);
					if (num > num)
					{
						num = 856523080;
						num4 = num - num3;
						if (num2 > num2)
						{
							num2 = ~num2;
						}
						num = num3;
						array[num + 7 - num2] = (num4 | -7);
						if (num > num)
						{
							num4 = array[num4 + 6 - num3] + 3;
						}
						num = (array[num4 + 7 - num3] ^ 4);
						num = num3 / 80;
					}
					num3 = ~num2;
					num = num3 + num;
					num2 = array[num + 8 - num] + -9;
					num2 = (num | num3);
					*(ref num3 + (IntPtr)num) = num;
					num3 = (num2 | 132284287);
					num4 = num2 % 277;
					num = (num2 ^ 1338790887);
					num2 = 348505676;
					num2 = num4 - num;
					num4 = num - num3;
					num3 += 584;
					if (num4 > num4)
					{
						num = (num3 | 1474425134);
						num2 = (int)((ushort)num4);
						num2 = array[num4 + 9 - num3] + 4;
						num4 = (num & 238777470);
					}
					num3 = *(ref num4 + (IntPtr)num);
					if (num > num)
					{
						num4 = num2 / num;
						num3 = num2 - 541;
						num = ~num2;
						num4 = Module.4I1Ebl54R2;
						if (num3 > num3)
						{
							num = num3 * num;
							array[num2 + 5 - num2] = num2 - -1;
							num = num3;
							num = (int)((byte)num3);
							num2 -= num;
							num = array[num + 7 - num] + 7;
							num3 = *(ref num + (IntPtr)num3);
							array[num3 + 7 - num2] = (num | -5);
							num3 = (num ^ num3);
						}
						num = (array[num + 5 - num2] ^ -8);
					}
					num = (num2 & 373305096);
					num2 = num3 / 864;
					num = ~num4;
					*(ref num3 + (IntPtr)num) = num;
				}
				this.<options>k__BackingField = value;
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060001F4 RID: 500 RVA: 0x00661754 File Offset: 0x0065F954
		// (set) Token: 0x060001F5 RID: 501 RVA: 0x00661BA0 File Offset: 0x0065FDA0
		public unsafe bool toggled
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Module.cu4Uqbkm51) ^ *(&Module.cu4Uqbkm51)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = num2 * num3;
					num = num2 - num3;
					int num4;
					int num5;
					if (num3 > num3)
					{
						*(ref num + (IntPtr)num3) = num3;
						num = (int)((byte)num4);
						if (num2 > num2)
						{
							num4 = num5 * num3;
							num2 = num5 / 914;
							num2 = num3 / 460;
							num4 = (num5 ^ num3);
							num = array[num3 + 6 - num3] + -4;
							num5 = -num2;
							num2 = (int)((short)num5);
						}
						num2 = *(ref num3 + (IntPtr)num2);
					}
					num5 = (int)((ushort)num4);
					num4 = -num3;
					num5 = -num;
					num4 = (num & 454924170);
					array[num2 + 5 - num5] = num4 - 7;
					num = num;
					num5 *= num3;
					if (num2 > num2)
					{
						if (num > num)
						{
							num5 = (num2 ^ num3);
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
							num2 = (num & 1931675975);
							Module.4I1Ebl54R2 = num2;
							num2 = ~num4;
							num = num3 + 765;
							num4 = (num3 | num2);
							num4 = (num2 | 1963418638);
						}
						num2 = num3;
						num4 = (num5 & 1294700188);
						Module.4I1Ebl54R2 = num5;
						num = Module.4I1Ebl54R2;
						num3 = -num5;
						num3 = num3;
						num5 = num3 << 6;
					}
					num5 ^= 1553329019;
					num5 = (num2 | 578715316);
					num5 = *(ref num + (IntPtr)num3);
					num2 = num4 * 285;
					num = num3;
					num2 = (num ^ 486637911);
					num5 %= num3;
					if (num5 > num5)
					{
						num3 = num4 << 4;
						num = (num2 ^ 339960661);
						*(ref num4 + (IntPtr)num3) = num3;
						num2 = 1685467128;
						if (num > num)
						{
							num4 = (num & num3);
							num2 = num5;
							num3 = (num4 & 1145870979);
							array[num4 + 7 - num4] = num5 - -6;
						}
						num4 = num2 / num3;
						if (num5 > num5)
						{
							Module.4I1Ebl54R2 = num3;
							num = Module.4I1Ebl54R2;
							num5 = array[num2 + 9 - num] + 9;
							num3 = ~num5;
							array[num2 + 6 - num3] = (num | 1);
							num = num3;
							num = (num2 & 1677575486);
							num4 = Module.4I1Ebl54R2;
							num4 = 1346742112;
							Module.4I1Ebl54R2 = num4;
						}
						num = ~num5;
					}
					num |= 1895210609;
					num = num4 + num3;
					num2 = num4 / num3;
					num = *(ref num3 + (IntPtr)num2);
					num4 = (num | num3);
					num3 = num2 * 459;
					num5 = num3 - 767;
					num4 *= num3;
				}
				return this.<toggled>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Module.sK4JbTmBrY) ^ *(&Module.sK4JbTmBrY)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num3;
					int num2;
					if (num > num)
					{
						num2 = num3;
						num = num2 / num3;
						num = -num3;
						num2 = -num;
						num2 -= 753;
						if (num2 > num2)
						{
							num = num2;
							num3 &= num2;
							num %= 16;
							num2 = num3 % num2;
							num = (num2 | 635914257);
							num3 = (num | num2);
							num3 = num << 6;
						}
						num = (num3 & num2);
						num = (num2 & num3);
						num = (int)((short)num3);
					}
					num = num3 - 186;
					*(ref num + (IntPtr)num2) = num2;
					num2 = (num & num2);
					num3 = 278684137;
					num3 = -num3;
					num3 = (int)((ushort)num2);
					num3 = num;
					if (num3 > num3)
					{
						num = num;
						array[num2 + 6 - num] = (num2 | 7);
						num3 = 2096312740;
						num3 ^= num2;
						num3 = -num2;
						num = ~num3;
					}
					num3 = -num2;
					if (num > num)
					{
						if (num > num)
						{
							num3 = -num2;
							num3 = num;
							num3 = array[num + 8 - num2] + 0;
						}
						num2 %= num3;
						num = 1592465049;
						if (num3 > num3)
						{
							*(ref num3 + (IntPtr)num2) = num2;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
							array[num2 + 7 - num3] = (num3 | 4);
							num2 = num3 % 301;
							num %= num2;
							num2 = *(ref num + (IntPtr)num2);
						}
						if (num3 > num3)
						{
							num2 = array[num2 + 5 - num] + -8;
							num += 97;
							num = num3 % 599;
							Module.4I1Ebl54R2 = num;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
							num3 |= num2;
							num3 = num2;
						}
					}
					*(ref Module.4I1Ebl54R2 + (IntPtr)num2) = num2;
					num += num2;
					num3 = (num2 & 1579177188);
					if (num > num)
					{
						num3 = num2 / 649;
						num = 179381001;
						*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
						num3 = -num3;
						num2 = array[num2 + 7 - num3] + -2;
						array[num3 + 5 - num2] = num - -9;
						if (num2 > num2)
						{
							Module.4I1Ebl54R2 = num2;
							num2 = num3 / 271;
							num3 = -num2;
							*(ref num2 + (IntPtr)num3) = num3;
							num2 += num3;
							num = num3;
							num = num2 % num3;
							num = (int)((sbyte)num);
						}
					}
					num2 = (int)((sbyte)num2);
					num3 = num3;
					if (num3 > num3)
					{
						num3 = array[num2 + 7 - num3] + 5;
						num = Module.4I1Ebl54R2;
						num = -num;
						if (num > num)
						{
							num2 >>= 5;
							num = (int)((ushort)num);
							num3 = (num & num2);
							num2 = num3;
							num = (num3 & num2);
							num -= 442;
							num = num2 * num3;
						}
						num2 /= 279;
					}
					num2 = num3 * 53;
					num2 = num3 / num2;
					num = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
					num3 = (num2 | 566752273);
					num = (int)((byte)num);
					num2 = num * num2;
					num2 = *(ref num3 + (IntPtr)num2);
					num = num2 % 116;
					if (num2 > num2)
					{
						if (num > num)
						{
							num = (num2 ^ num3);
							num = (num2 & num3);
							num = num2 + 865;
							num2 *= 223;
							num2 = (int)((byte)num3);
							array[num3 + 6 - num3] = num2 - -3;
							num3 = num >> 7;
						}
					}
					if (num2 > num2)
					{
						if (num2 > num2)
						{
							num = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
							num = num3 / 668;
							num3 = (int)((short)num3);
							num2 = (num3 ^ num2);
							*(ref num + (IntPtr)num2) = num2;
							num2 = (num3 & 6322644);
							num2 = num * num2;
							num2 = num3 - num2;
							num = (num2 | 1645749000);
							num3 = num3;
						}
						if (num3 > num3)
						{
							num3 /= 584;
							num2 = Module.4I1Ebl54R2;
						}
						num2 = (num3 ^ num2);
						array[num + 6 - num3] = num3 - -4;
						if (num2 > num2)
						{
							num3 = -num3;
							num2 = num3 + 631;
							num2 = num + num2;
							num2 = num + 291;
							num = num2 - 314;
							num = num2 / num3;
						}
					}
					num = num3 - 231;
					array[num3 + 6 - num2] = (num3 | -5);
					num3 = num3;
					num = num2;
					num = (array[num3 + 5 - num2] ^ -3);
					num3 = Module.4I1Ebl54R2;
					if (num > num)
					{
						if (num3 > num3)
						{
							*(ref num3 + (IntPtr)num2) = num2;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num2) = num2;
						}
						num = num2 << 1;
						*(ref num3 + (IntPtr)num2) = num2;
						num2 = (num3 | num2);
						num2 = num3 % num2;
						num2 ^= num3;
						num3 = ~num2;
						num3 = num * num2;
					}
					num = num2;
				}
				this.<toggled>k__BackingField = value;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060001F6 RID: 502 RVA: 0x006623E8 File Offset: 0x006605E8
		// (set) Token: 0x060001F7 RID: 503 RVA: 0x00662BE8 File Offset: 0x00660DE8
		public unsafe bool toggleable
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Module.mQRTD2cixG) ^ *(&Module.mQRTD2cixG)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
					int num3;
					Module.4I1Ebl54R2 = num3;
					num = ~num3;
					num3 = num2;
					num3 = (num & num3);
					num = array2[num + 7 - num2] + -4;
					num = Module.4I1Ebl54R2;
					if (num2 > num2)
					{
						num = num3;
						num2 = (num | num3);
						num2 = num;
						num3 = (array2[num + 7 - num3] ^ 2);
						array[num3 + 5 - num2] = num3 - 3;
					}
					num3 = array2[num + 5 - num2] + 7;
					array2[num2 + 8 - num3] = (num3 | -9);
					num2 = num - num3;
					num3 = -num2;
					num2 = num3 + 76;
					Module.4I1Ebl54R2 = num2;
					num2 &= 372624472;
					if (num2 > num2)
					{
						num2 ^= num3;
						num3 = num2;
						if (num3 > num3)
						{
							num3 = num2;
							num3 = (num2 | 1527969143);
							array2[num3 + 5 - num3] = num - -6;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
							array2[num2 + 6 - num2] = (num | -4);
							array2[num3 + 7 - num] = (num2 | -3);
							num = ~num;
						}
						if (num2 > num2)
						{
							num = array[num2 + 7 - num] + 0;
							num2 = num3 << 5;
							num3 = 709823647;
						}
						num2 = num * num3;
						array[num + 5 - num] = num2 - -2;
					}
					num3 = num + num3;
					num2 %= num3;
					if (num2 > num2)
					{
						num = -num;
						num = Module.4I1Ebl54R2;
						array2[num3 + 6 - num2] = (num3 | -10);
						num3 = ~num;
						if (num3 > num3)
						{
							num = num2;
							num = num2 + num3;
							num2 = num3;
							num3 = num2;
							num = (int)((byte)num3);
						}
						num3 = -num3;
						if (num > num)
						{
							num = (num2 ^ num3);
							num = num2 + num3;
						}
						num3 = 1382546020;
					}
					if (num3 > num3)
					{
						num3 = (int)((sbyte)num3);
						array2[num2 + 7 - num3] = (num3 | 1);
						num3 = array2[num2 + 7 - num] + -10;
					}
					*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
					if (num > num)
					{
						*(ref num3 + (IntPtr)num) = num;
						num2 = num3 - 913;
						if (num3 > num3)
						{
							*(ref num3 + (IntPtr)num) = num;
							num3 = num2 % 707;
							Module.4I1Ebl54R2 = num3;
							num2 = (num | 2032345560);
							num2 = (int)((ushort)num3);
						}
						num = num2 % 179;
						num3 = num2 * 643;
						if (num > num)
						{
							num3 = num2 / num3;
							num = (int)((sbyte)num3);
							num = num3 >> 7;
							num2 = (num3 ^ 1955393041);
							num = Module.4I1Ebl54R2;
							num2 = num2;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
						}
						num3 |= num;
					}
					num3 = -num3;
					num /= 945;
					num = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
					num ^= 411050621;
					*(ref num2 + (IntPtr)num3) = num3;
					num = num2 + num3;
					*(ref num + (IntPtr)num3) = num3;
					if (num3 > num3)
					{
						num = num3;
						num2 = -num2;
						num = -num2;
						if (num3 > num3)
						{
							num += num3;
							num &= num3;
						}
						num2 = (int)((ushort)num2);
					}
					num3 = (num2 | 734266855);
					num3 = (num & num3);
					num /= 881;
					num = num3;
					num *= num3;
					array[num3 + 5 - num2] = num2 - -4;
					num = (num2 ^ 809478850);
					num = (int)((byte)num3);
					Module.4I1Ebl54R2 = num;
					if (num3 > num3)
					{
						num = (num2 ^ num3);
						num = num3 % 674;
						Module.4I1Ebl54R2 = num3;
						num = (num2 & 583790956);
						num3 |= num;
						num3 = (num2 & num3);
						array[num2 + 9 - num2] = num2 - 7;
						if (num > num)
						{
							num3 |= num;
							num2 = Module.4I1Ebl54R2;
							num = *(ref num + (IntPtr)num3);
							*(ref num3 + (IntPtr)num) = num;
							num2 = (int)((sbyte)num3);
							array[num + 8 - num] = (num2 | 1);
							num2 = -num2;
							num *= num3;
							num2 = (int)((short)num);
							num |= num3;
						}
						if (num3 > num3)
						{
							num3 ^= 1163509934;
							num2 = (int)((sbyte)num2);
						}
					}
					array2[num3 + 8 - num3] = (num3 | 2);
					array2[num2 + 6 - num] = num3 - 1;
					num3 = -num2;
					num = num2 % 989;
					*(ref num3 + (IntPtr)num) = num;
					num2 = ~num3;
					num3 = num2 * num3;
					num2 = (int)((byte)num);
					num2 = Module.4I1Ebl54R2;
				}
				return this.<toggleable>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Module.k7xrvYa07R) ^ *(&Module.k7xrvYa07R)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num3;
					int num2;
					if (num > num)
					{
						if (num > num)
						{
							num2 = num3 + num;
							Module.4I1Ebl54R2 = num2;
							num /= num3;
							array2[num3 + 9 - num3] = (num2 | -3);
						}
						if (num2 > num2)
						{
							num3 = *(ref num + (IntPtr)num3);
							num3 ^= 198096555;
							num2 = array[num2 + 5 - num2] + 7;
						}
					}
					num = Module.4I1Ebl54R2;
					if (num3 > num3)
					{
						num3 = array2[num3 + 6 - num2] + 4;
						num2 = (num3 & 1669082116);
					}
					num2 = num - num3;
					num = Module.4I1Ebl54R2;
					num2 = num;
					num = 468819592;
					if (num2 > num2)
					{
						num3 = num3;
						num = num3 >> 2;
						if (num3 > num3)
						{
							num3 >>= 1;
							num2 = num3 + num;
							num3 = num2;
							num = num2 + 10;
						}
						num3 /= 982;
						num = 2140675972;
						num2 = num3 % 318;
						num = ~num2;
						num3 = (array[num + 9 - num2] ^ 1);
					}
					array2[num + 6 - num2] = num - -3;
					*(ref num2 + (IntPtr)num) = num;
					if (num > num)
					{
						num3 = num2 % num;
						num3 = (int)((ushort)num);
						num3 = Module.4I1Ebl54R2;
						num3 = (int)((short)num2);
						num2 = array[num + 6 - num3] + 2;
						if (num3 > num3)
						{
							num2 = (int)((byte)num2);
						}
					}
					num2 = Module.4I1Ebl54R2;
					if (num3 > num3)
					{
						num3 = (int)((ushort)num3);
						num = ~num;
						num3 = num - num3;
						num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
						num3 = Module.4I1Ebl54R2;
						num2 = array[num + 9 - num] + -8;
						num2 = (int)((byte)num2);
						num2 = num * num3;
						if (num3 > num3)
						{
							num3 ^= 1201062273;
							num3 = array[num2 + 6 - num] + -5;
							num2 = num3;
							num3 = -num3;
							num2 = array2[num + 6 - num3] + 2;
							num |= num3;
							num3 = num + num3;
							num = -num3;
						}
						num = num;
					}
					num = (num2 | num);
					num = array2[num + 5 - num2] + 6;
					if (num2 > num2)
					{
						*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
						if (num2 > num2)
						{
							*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
							num = -num;
							num = num;
							num = num2 + 798;
							num = (num2 ^ num);
							num2 = *(ref num3 + (IntPtr)num);
							num = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
							num2 |= num;
							num3 = num - num3;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
						}
						array2[num2 + 8 - num] = (num | -8);
					}
					if (num3 > num3)
					{
						num2 = (num & num3);
						num = (int)((ushort)num);
						if (num2 > num2)
						{
							num2 = (int)((sbyte)num);
							array2[num3 + 5 - num] = (num | 8);
							num3 <<= 5;
							num2 = num3 / num;
							num = (array2[num2 + 8 - num3] ^ -4);
							num2 = (array2[num3 + 5 - num3] ^ -6);
							num3 = (num | 619775747);
							num &= num3;
							num2 = num2;
						}
						num = num3;
						num = num3 + num;
						num3 = num2 + num;
					}
					num = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
					num3 = ~num;
					num = array[num2 + 5 - num2] + -10;
					num2 = (num ^ num3);
				}
				this.<toggleable>k__BackingField = value;
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x060001F8 RID: 504 RVA: 0x00663204 File Offset: 0x00661404
		// (set) Token: 0x060001F9 RID: 505 RVA: 0x006638C8 File Offset: 0x00661AC8
		public unsafe Action action
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Module.X97B7uYf43) ^ *(&Module.X97B7uYf43)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					num *= num2;
					array[num2 + 6 - num] = (num | 3);
					num2 = num - num2;
					Module.4I1Ebl54R2 = num;
					int num3;
					num = ~num3;
					int num4;
					if (num3 > num3)
					{
						num2 = (array[num4 + 8 - num2] ^ -4);
						Module.4I1Ebl54R2 = num2;
						num3 = num * 943;
						if (num4 > num4)
						{
							num = array[num3 + 5 - num2] + 9;
							num = num4 / 924;
							num4 = num3 * num2;
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
							num4 %= num2;
							num4 = Module.4I1Ebl54R2;
							num2 = *(ref num2 + (IntPtr)num);
							num2 = num / num2;
						}
						if (num > num)
						{
							num2 = array[num2 + 7 - num3] + -5;
							num2 = 2008099178;
							num3 = num4 + num2;
							num4 = num3 / num2;
							num = num2;
							num3 = *(ref num4 + (IntPtr)num2);
						}
						num2 = Module.4I1Ebl54R2;
						num2 = (num | num2);
						array[num3 + 5 - num3] = num3 - 4;
						num3 = ~num3;
					}
					if (num3 > num3)
					{
						Module.4I1Ebl54R2 = num;
						if (num3 > num3)
						{
							num2 = num3;
							Module.4I1Ebl54R2 = num4;
							num4 = (int)((byte)num4);
							num2 = num3 - num2;
							num = *(ref Module.4I1Ebl54R2 + (IntPtr)num3);
							array[num3 + 6 - num] = (num4 | 3);
							num4 = (int)((ushort)num3);
							num3 = 716266211;
							num4 = 846698826;
							num = num4 / 223;
						}
						num2 = (num3 & num2);
						num2 = Module.4I1Ebl54R2;
						num3 *= 269;
						Module.4I1Ebl54R2 = num4;
						num = -num3;
						if (num2 > num2)
						{
							num2 = num2;
							num2 = 1148586664;
							num4 = num2 * num;
							num3 = num4 % 37;
							num2 = *(ref num2 + (IntPtr)num);
							num = num4 * num2;
							num3 = (num2 ^ 1472660452);
							num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num3);
							num2 = array[num4 + 7 - num3] + -8;
						}
						num3 = num2;
						num3 = num2 * 995;
					}
					num = (array[num2 + 5 - num2] ^ -7);
					num -= 710;
					num = Module.4I1Ebl54R2;
					if (num > num)
					{
						num3 = -num2;
						num2 = num3 * 251;
						num3 = num2;
						num2 = num / 743;
						num = -num4;
						num3 = (num4 & num2);
					}
					num3 = num2 * num;
					if (num2 > num2)
					{
						array[num4 + 5 - num4] = num4 - -2;
						num3 = ~num;
						if (num3 > num3)
						{
							num4 *= num2;
							num4 = (num2 & num);
							num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
							num4 = Module.4I1Ebl54R2;
							num3 = (num4 & 505934120);
							num2 = -num4;
						}
					}
					num2 = num;
					if (num3 > num3)
					{
						num = num4 * num2;
						if (num3 > num3)
						{
							num3 = (int)((byte)num);
							num2 *= 976;
							num4 = num2 / 817;
							num = *(ref Module.4I1Ebl54R2 + (IntPtr)num4);
							num = num4;
							num2 = num3 % num2;
							num4 = -num2;
							num4 = num2 - 362;
							num4 = (num | num2);
							num = num3 >> 6;
						}
					}
					if (num3 > num3)
					{
						array[num + 7 - num4] = (num4 | 8);
						array[num4 + 7 - num3] = (num2 | -8);
					}
					array[num + 7 - num3] = num2 - 5;
					num4 ^= num2;
					array[num2 + 5 - num4] = num3 - -8;
					num4 = (num | num2);
					num2 = *(ref num3 + (IntPtr)num2);
					num4 = num2 * num;
					num2 = num4 / 911;
					num3 = (array[num4 + 5 - num3] ^ 3);
					num2 = Module.4I1Ebl54R2;
					num4 = *(ref num3 + (IntPtr)num2);
					*(ref num3 + (IntPtr)num2) = num2;
					num3 = num2 >> 3;
					num2 = *(ref num2 + (IntPtr)num);
					num4 /= 853;
					num3 = num * num2;
					num = (int)((ushort)num4);
					num2 = 1645169672;
				}
				return this.<action>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Module.ebtSkLclRy) ^ *(&Module.ebtSkLclRy)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					num |= num2;
					int num3 = (int)((short)num);
					int num4;
					if (num2 > num2)
					{
						num3 = num2;
						num = Module.4I1Ebl54R2;
						num2 = (num4 | num2);
						num2 = num3 - num2;
						num = num2 * num4;
						num = -num;
						if (num > num)
						{
							num3 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
							*(ref num2 + (IntPtr)num4) = num4;
							num = (num2 | num4);
							num = num4 << 7;
							num3 = num4 - num2;
						}
					}
					num = num4 % num2;
					num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num3);
					num2 = num3 - num2;
					num3 = num4;
					if (num2 > num2)
					{
						num2 = (int)((ushort)num2);
						if (num2 > num2)
						{
							num3 = num / 893;
							num4 = num3 % 942;
							num = num4 + num2;
							num2 = *(ref num2 + (IntPtr)num4);
							num = num;
						}
					}
					num3 = Module.4I1Ebl54R2;
					num = array2[num2 + 7 - num] + 2;
					num = num3 + num2;
					array2[num + 5 - num] = (num3 | 7);
					num4 = num2 - num4;
					*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
					num2 = (int)((short)num2);
					num3 = (int)((short)num3);
					num3 %= num2;
					array[num3 + 7 - num3] = (num4 | -7);
					if (num2 > num2)
					{
						num4 = num % 554;
						num4 = num2;
						if (num3 > num3)
						{
							num3 = num;
							num = num3;
							num3 = Module.4I1Ebl54R2;
							num2 = (int)((byte)num);
							num3 = array2[num4 + 7 - num3] + -3;
						}
						num4 = 1169257754;
						num4 = num3 - num2;
						num2 = Module.4I1Ebl54R2;
						num4 = (int)((ushort)num);
						num4 = num3;
					}
					num = num4 / num2;
					num = num4 % 852;
					num2 = num2;
					num3 = (num & num2);
					num -= 310;
					num = Module.4I1Ebl54R2;
					num = 423421989;
					*(ref Module.4I1Ebl54R2 + (IntPtr)num2) = num2;
					num3 >>= 5;
					Module.4I1Ebl54R2 = num2;
					num = -num2;
					num2 = (array2[num2 + 7 - num] ^ 0);
				}
				this.<action>k__BackingField = value;
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x060001FA RID: 506 RVA: 0x00663C6C File Offset: 0x00661E6C
		// (set) Token: 0x060001FB RID: 507 RVA: 0x00664438 File Offset: 0x00662638
		public unsafe Action disableAction
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Module.9BzyRuXNYD) ^ *(&Module.9BzyRuXNYD)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					array[num + 7 - num] = num2 - 2;
					int num3;
					num2 = -num3;
					num = -num3;
					num = num2;
					num3 = Module.4I1Ebl54R2;
					int num4 = array[num3 + 7 - num3] + -6;
					if (num3 > num3)
					{
						num2 = *(ref num3 + (IntPtr)num);
						num4 = num + 837;
						if (num4 > num4)
						{
							*(ref Module.4I1Ebl54R2 + (IntPtr)num4) = num4;
							num4 = Module.4I1Ebl54R2;
							num4 = num2 + num;
							*(ref num2 + (IntPtr)num) = num;
							num4 = 741381307;
							num4 = num2 - 248;
							num2 = num % 657;
							num &= num2;
						}
						num2 = num - num2;
						if (num3 > num3)
						{
							num = (num2 & num);
						}
						if (num4 > num4)
						{
							num2 = (num ^ num2);
							array[num2 + 7 - num] = (num4 | -3);
						}
					}
					num3 = ~num3;
					num4 /= 808;
					if (num3 > num3)
					{
						num4 = (num ^ 1293141832);
						num3 |= 1170016443;
					}
					num3 = num % 78;
					num4 = array[num2 + 7 - num4] + -1;
					num4 = 273969758;
					num4 = num2 - 806;
					num2 = num + 887;
					num3 += num;
					if (num3 > num3)
					{
						num3 = num4 % 945;
						num4 = ~num3;
						num3 = *(ref num4 + (IntPtr)num);
						array[num + 9 - num2] = (num3 | -10);
						num3 = num2 - num;
						num = (int)((byte)num);
						num2 = num4 * num;
						num4 = (array[num2 + 9 - num] ^ 9);
						if (num2 > num2)
						{
							num2 = (int)((short)num);
							num2 %= num;
							num = num2 + num;
							num2 = ~num;
							num4 = array[num + 6 - num4] + 9;
							num = num;
							num3 = (int)((ushort)num2);
							num3 = (array[num2 + 8 - num4] ^ -7);
							num = (array[num2 + 6 - num2] ^ 9);
						}
						num4 = num % 375;
					}
					num3 = Module.4I1Ebl54R2;
					num3 = num;
					num = ~num2;
					num3 = (array[num + 7 - num2] ^ 2);
					array[num3 + 7 - num3] = (num4 | -4);
					*(ref num2 + (IntPtr)num) = num;
					num2 = Module.4I1Ebl54R2;
					if (num4 > num4)
					{
						num2 = num3 - num;
						array[num3 + 6 - num2] = num4 - 0;
						num3 = -num2;
						num3 = num3;
					}
					num = (num4 | num);
					*(ref num4 + (IntPtr)num) = num;
					num2 >>= 1;
					Module.4I1Ebl54R2 = num2;
					num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num4);
					num2 = -num3;
					num3 = array[num4 + 7 - num3] + -5;
					num3 = -num;
					num4 = (num3 ^ 116339875);
					num4 = (num3 | num);
					array[num3 + 9 - num2] = num4 - 9;
					num = -num3;
					if (num2 > num2)
					{
						*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
						num = -num3;
						num3 = array[num4 + 9 - num3] + -8;
						num2 = num3 / num;
						if (num4 > num4)
						{
							num4 = array[num + 9 - num] + -10;
							num = (int)((ushort)num2);
							num3 = array[num3 + 8 - num2] + -10;
							num3 = (int)((ushort)num2);
						}
						num3 = *(ref Module.4I1Ebl54R2 + (IntPtr)num);
						num3 = 1837409143;
						if (num > num)
						{
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
							num4 = (array[num2 + 5 - num3] ^ 8);
							*(ref Module.4I1Ebl54R2 + (IntPtr)num3) = num3;
							num2 = num - num2;
							num2 = ~num3;
							num = ~num3;
							num4 -= num;
							num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
						}
						num3 = *(ref Module.4I1Ebl54R2 + (IntPtr)num3);
						array[num + 6 - num] = num - -8;
					}
					num2 = (array[num + 6 - num3] ^ 5);
					num3 = num4;
					if (num4 > num4)
					{
						num2 = num3 - 859;
						num4 = (num | num2);
						num2 = Module.4I1Ebl54R2;
					}
					num3 = num2 * num;
					num = num4 - num;
					num4 = num3;
					if (num2 > num2)
					{
						num2 ^= num;
						if (num3 > num3)
						{
							num = num4 - num;
							num2 = -num3;
							num4 = num;
							num = (array[num2 + 6 - num3] ^ 9);
							num = Module.4I1Ebl54R2;
							num2 = ~num2;
						}
						*(ref Module.4I1Ebl54R2 + (IntPtr)num4) = num4;
						num3 = -num2;
						num = 794506168;
					}
				}
				return this.<disableAction>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Module.3vDZAmTQWS) ^ *(&Module.3vDZAmTQWS)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = num2;
					int num3;
					num = num2 + num3;
					array[num3 + 5 - num2] = (num2 | -5);
					int num5;
					int num4 = num5 & num2;
					num4 = (num5 & 1658691821);
					num = (num2 ^ num3);
					num = (num2 ^ 1927340130);
					num4 = num - 466;
					if (num2 > num2)
					{
						num2 = num3;
						if (num3 > num3)
						{
							array[num2 + 9 - num2] = (num4 | -4);
							num4 = (int)((ushort)num5);
							*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
							num2 = array[num2 + 5 - num3] + -2;
							num3 += num2;
							num = (num2 | num3);
							num3 = ~num2;
						}
						num4 = num2 - 989;
						num5 = (num ^ 1109245440);
						num2 = num3 / 760;
						num4 = array[num5 + 7 - num2] + 6;
						num2 = (num3 & num2);
						num2 <<= 3;
					}
					num4 = -num4;
					if (num2 > num2)
					{
						num = num5 % num2;
						num2 = (int)((byte)num2);
					}
					num <<= 6;
					num5 = 119373399;
					num = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
					num4 = num2 % num3;
					Module.4I1Ebl54R2 = num5;
					num4 = array[num + 9 - num3] + -4;
					num5 = num2 / num3;
					Module.4I1Ebl54R2 = num3;
				}
				this.<disableAction>k__BackingField = value;
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x060001FC RID: 508 RVA: 0x00664694 File Offset: 0x00662894
		// (set) Token: 0x060001FD RID: 509 RVA: 0x00664C28 File Offset: 0x00662E28
		public unsafe bool onlyTurnOn
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Module.e6o3lIOeGk) ^ *(&Module.e6o3lIOeGk)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num3;
					int num2;
					int num4;
					if (num > num)
					{
						num2 = num3;
						if (num > num)
						{
							num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num4);
							num4 = num << 6;
							num3 = num - num4;
							num2 >>= 2;
							num = num3 / 514;
						}
						num2 = num4;
					}
					num4 = -num2;
					num4 = (array[num3 + 8 - num] ^ -5);
					num2 = (int)((byte)num3);
					num2 = ~num;
					num = num2;
					if (num4 > num4)
					{
						num4 = array2[num2 + 7 - num] + 7;
						num4 /= 1;
						if (num2 > num2)
						{
							num4 = Module.4I1Ebl54R2;
							num3 = (int)((sbyte)num4);
							num4 = num << 5;
							array2[num + 7 - num4] = num3 - -8;
							num4 = array[num3 + 8 - num4] + 5;
							num2 = (int)((sbyte)num4);
							num3 = num2 / 160;
						}
						num4 = *(ref num2 + (IntPtr)num4);
						num3 = num4;
						num2 = (int)((short)num3);
						num3 = num4 / num;
						num3 = (num | num4);
					}
					num4 = *(ref Module.4I1Ebl54R2 + (IntPtr)num3);
					num = num4 - 740;
					num4 = (num3 | 422413013);
					num4 = num3 << 6;
					if (num2 > num2)
					{
						num3 = 834925936;
						if (num > num)
						{
							num3 = num4;
							num4 |= num;
							num4 += num;
							num /= num4;
							num = (num2 & num4);
						}
						num3 = Module.4I1Ebl54R2;
						num4 *= num;
						num3 &= num4;
						num4 = ~num;
						num2 = num4 - 666;
						num = num;
						num = (int)((short)num4);
					}
					if (num3 > num3)
					{
						*(ref num + (IntPtr)num4) = num4;
						*(ref Module.4I1Ebl54R2 + (IntPtr)num) = num;
					}
					num = *(ref num2 + (IntPtr)num4);
					*(ref num4 + (IntPtr)num) = num;
					num2 = ~num2;
					num4 ^= num;
					num2 = (num3 & 1738639045);
					num %= 115;
					num2 = ~num;
					num4 = num << 7;
					num2 = (array2[num3 + 9 - num] ^ -8);
					num4 = num;
					num3 %= num4;
					num *= num4;
					num4 *= num;
					num4 = Module.4I1Ebl54R2;
					num = num3 % num4;
					num2 = num / num4;
					if (num > num)
					{
						if (num4 > num4)
						{
							num2 = num * num4;
							num4 = ~num2;
							num4 = (num2 ^ 892331350);
						}
						num2 = num * 193;
						num = 622584911;
						num2 ^= 1394098175;
						num = ~num2;
					}
					num3 = -num2;
					array[num2 + 7 - num2] = num2 - 8;
					num3 = num4 % 800;
					if (num2 > num2)
					{
						num = -num2;
						num = (num2 & 1102871428);
						num2 = (num4 & num);
						num4 = ~num;
						num3 = -num4;
						num2 = num4;
						num4 = ~num4;
					}
					num3 = num2 / num4;
					num2 = *(ref num3 + (IntPtr)num4);
					num = -num3;
					num2 = num4 - num;
					Module.4I1Ebl54R2 = num3;
					array2[num2 + 6 - num4] = num4 - -3;
					num3 = -num2;
					num4 = (array[num + 5 - num] ^ 5);
					num3 = (num4 & 2081630126);
					num2 = -num4;
					num &= num4;
				}
				return this.<onlyTurnOn>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Module.6zjJSWKIuM) ^ *(&Module.6zjJSWKIuM)) != 0)
				{
					int[] array = new int[10];
					int num;
					Module.4I1Ebl54R2 = num;
					int num2;
					num = num2 << 2;
					int num3 = num / 46;
					num ^= num2;
					num = num2 % 114;
					*(ref num + (IntPtr)num2) = num2;
					num2 = (int)((ushort)num3);
					num2 = (num ^ 1845737062);
					num = num3 - 624;
					if (num3 > num3)
					{
						num = array[num2 + 6 - num2] + -9;
						num2 = num - 852;
						if (num > num)
						{
							num3 = Module.4I1Ebl54R2;
							num = (num3 & num);
						}
						num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num2);
						num3 -= num;
						num += 187;
					}
					num2 <<= 3;
					num3 = (num2 ^ num);
					if (num3 > num3)
					{
						num2 = (int)((ushort)num2);
						num2 >>= 6;
					}
					num = (num3 & 1029707981);
					num2 = Module.4I1Ebl54R2;
					num2 = num % num2;
					num3 <<= 2;
					array[num3 + 9 - num] = num2 - -1;
					num3 = -num;
					num ^= 854921247;
					if (num2 > num2)
					{
						num <<= 6;
						num = num2 % num;
						if (num2 > num2)
						{
							num2 = (int)((short)num3);
						}
						num3 = (num & 877403641);
						num = (num3 ^ num);
						num2 = ~num3;
						num = (int)((sbyte)num3);
						if (num2 > num2)
						{
							array[num + 8 - num2] = (num | -7);
							num = -num3;
							num = (num3 | num);
							num2 = array[num + 5 - num3] + -4;
						}
						num3 = num % num2;
						num = num2 % num;
					}
					num = num3 / 447;
				}
				this.<onlyTurnOn>k__BackingField = value;
			}
		}

		// Token: 0x060001FE RID: 510 RVA: 0x00664F20 File Offset: 0x00663120
		public unsafe Module()
		{
			int num = 15;
			if ((*(&Module.WKH0AtYTS8) ^ *(&Module.WKH0AtYTS8)) != 0)
			{
				int[] array = new int[10];
				int[] array2 = new int[10];
				int num2;
				int num3;
				int num4;
				int num5;
				if (num2 > num2)
				{
					num3 = (int)((ushort)num2);
					num2 = num4 % num5;
				}
				int num6 = 150886229;
				num3 = array2[num2 + 7 - num3] + -3;
				num2 = -num6;
				num4 = Module.4I1Ebl54R2;
				num3 = (num6 & num5);
				num5 = num4 >> 3;
				if (num6 > num6)
				{
					if (num3 > num3)
					{
						num6 -= 104;
						array2[num6 + 9 - num4] = (num4 | 9);
						num3 = -num6;
						num2 = *(ref num6 + (IntPtr)num5);
						num6 = *(ref Module.4I1Ebl54R2 + (IntPtr)num5);
					}
					num4 = *(ref num5 + (IntPtr)num4);
					Module.4I1Ebl54R2 = num6;
					if (num4 > num4)
					{
						num4 %= num5;
						num5 = num4 + num5;
						num2 = *(ref Module.4I1Ebl54R2 + (IntPtr)num5);
						num5 = (int)((short)num3);
						num3 = num4 + 96;
						num4 = -num5;
						array[num3 + 9 - num4] = num3 - -3;
						num4 = num5 * num4;
					}
					*(ref Module.4I1Ebl54R2 + (IntPtr)num6) = num6;
					array2[num3 + 9 - num3] = num4 - 3;
					if (num2 > num2)
					{
						num6 = (int)((sbyte)num3);
						num4 = num5 + 131;
						num5 = -num5;
						num2 = num5 % num4;
						num5 = num3 * 54;
						num5 = num5;
						num3 += 777;
						array2[num3 + 6 - num6] = (num3 | 9);
					}
				}
				num4 = num2 << 7;
				if (num6 > num6)
				{
					if (num5 > num5)
					{
						num5 = num3;
						num6 = array2[num2 + 9 - num3] + -8;
						num5 = (num2 | 82719615);
						num4 >>= 5;
					}
					if (num5 > num5)
					{
						num5 = num2 + num5;
						num4 >>= 6;
						num6 = (num5 ^ num4);
						num5 = -num6;
						num6 = -num3;
						num3 = (num2 ^ 424008954);
						num6 = num4 / num5;
						num6 = Module.4I1Ebl54R2;
					}
					num4 = num2 * num5;
					if (num6 > num6)
					{
						num3 = (num2 | 1245687382);
						num4 = -num3;
						num6 <<= 3;
						*(ref Module.4I1Ebl54R2 + (IntPtr)num6) = num6;
						num3 = num5;
						num3 = (array2[num5 + 6 - num6] ^ -1);
						num3 = 1955232165;
						num4 = -num6;
						num2 = num2;
						num3 = num2 / num5;
					}
					num5 = (num2 ^ 753711331);
					num4 = (num3 ^ 908728567);
				}
				num4 = 63652679;
				if (num4 > num4)
				{
					num6 = num3 - 190;
					num2 = -num2;
					num4 = num6;
					num2 = num3 % num5;
					num5 = (array2[num2 + 5 - num5] ^ 0);
					if (num2 > num2)
					{
						num4 = (num5 & num4);
						num3 = (num4 ^ num5);
						num2 = (num6 | 856471010);
						num6 = (int)((byte)num5);
						num2 = num5;
						num5 = Module.4I1Ebl54R2;
						num6 = num3 * num5;
					}
					num3 = (num4 & 260216667);
					num6 = num2 / num5;
					*(ref num2 + (IntPtr)num5) = num5;
				}
				num6 = num2 - 50;
				num3 = num4 / num5;
				if (num4 > num4)
				{
					*(ref Module.4I1Ebl54R2 + (IntPtr)num2) = num2;
					num4 /= num5;
					num6 = Module.4I1Ebl54R2;
				}
				array2[num6 + 5 - num5] = num5 - -3;
				num5 = num3;
				num5 = ~num3;
				num2 = (num6 ^ 760895397);
				num3 = num2 / 756;
				num4 = (int)((short)num6);
			}
			int[] array3 = new int[num];
			int num7 = 479;
			if (num7 == 479)
			{
				array3[0] = 1965253573;
				int[] array4 = array3;
				int num8 = 0;
				int num9 = array3[0] * 2 % 61 % 75 % 74;
				array4[num8] = (array3[0] ^ num9 ^ (1965253573 ^ num9));
			}
			this.<onlyTurnOn>k__BackingField = (array3[0] != 0);
			base..ctor();
			for (;;)
			{
				IL_37F:
				uint num10 = 968378991U;
				for (;;)
				{
					uint num11;
					switch ((num11 = (num10 ^ (uint)(*(&Module.RrhdRFeW93)))) % (uint)(*(&Module.ePu3aUqQiC) + *(&Module.dsl9zCstYP)))
					{
					case 0U:
						goto IL_37F;
					case 1U:
					{
						uint num12 = (num11 | (uint)(*(&Module.UWw87EfuOM))) * (uint)(*(&Module.mabms9bcgh));
						num10 = ((num12 & (uint)(*(&Module.vDGfUiGhoO))) ^ (uint)(*(&Module.Xv8uiIdv5W)));
						continue;
					}
					}
					return;
				}
			}
		}

		// Token: 0x04050A85 RID: 330373 RVA: 0x0014E958 File Offset: 0x0014CB58
		static int cPByxjID62;

		// Token: 0x04050A86 RID: 330374 RVA: 0x0014E960 File Offset: 0x0014CB60
		static int 4I1Ebl54R2;

		// Token: 0x04050A87 RID: 330375 RVA: 0x0014E968 File Offset: 0x0014CB68
		static int kemI4HozXk;

		// Token: 0x04050A88 RID: 330376 RVA: 0x0014E970 File Offset: 0x0014CB70
		static int owpbWOJL97;

		// Token: 0x04050A89 RID: 330377 RVA: 0x0014E978 File Offset: 0x0014CB78
		static int MI4ANDYe4N;

		// Token: 0x04050A8A RID: 330378 RVA: 0x0014E980 File Offset: 0x0014CB80
		static int JVKot7m23q;

		// Token: 0x04050A8B RID: 330379 RVA: 0x0014E988 File Offset: 0x0014CB88
		static int 4TpVNHcarM;

		// Token: 0x04050A8C RID: 330380 RVA: 0x0014E990 File Offset: 0x0014CB90
		static int cu4Uqbkm51;

		// Token: 0x04050A8D RID: 330381 RVA: 0x0014E998 File Offset: 0x0014CB98
		static int sK4JbTmBrY;

		// Token: 0x04050A8E RID: 330382 RVA: 0x0014E9A0 File Offset: 0x0014CBA0
		static int mQRTD2cixG;

		// Token: 0x04050A8F RID: 330383 RVA: 0x0014E9A8 File Offset: 0x0014CBA8
		static int k7xrvYa07R;

		// Token: 0x04050A90 RID: 330384 RVA: 0x0014E9B0 File Offset: 0x0014CBB0
		static int X97B7uYf43;

		// Token: 0x04050A91 RID: 330385 RVA: 0x0014E9B8 File Offset: 0x0014CBB8
		static int ebtSkLclRy;

		// Token: 0x04050A92 RID: 330386 RVA: 0x0014E9C0 File Offset: 0x0014CBC0
		static int 9BzyRuXNYD;

		// Token: 0x04050A93 RID: 330387 RVA: 0x0014E9C8 File Offset: 0x0014CBC8
		static int 3vDZAmTQWS;

		// Token: 0x04050A94 RID: 330388 RVA: 0x0014E9D0 File Offset: 0x0014CBD0
		static int e6o3lIOeGk;

		// Token: 0x04050A95 RID: 330389 RVA: 0x0014E9D8 File Offset: 0x0014CBD8
		static int 6zjJSWKIuM;

		// Token: 0x04050A96 RID: 330390 RVA: 0x0014E9E0 File Offset: 0x0014CBE0
		static int WKH0AtYTS8;

		// Token: 0x04050A97 RID: 330391 RVA: 0x0014E9E8 File Offset: 0x0014CBE8
		static readonly int RrhdRFeW93;

		// Token: 0x04050A98 RID: 330392 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ePu3aUqQiC;

		// Token: 0x04050A99 RID: 330393 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int dsl9zCstYP;

		// Token: 0x04050A9A RID: 330394 RVA: 0x0014E9F0 File Offset: 0x0014CBF0
		static readonly int UWw87EfuOM;

		// Token: 0x04050A9B RID: 330395 RVA: 0x0014E9F8 File Offset: 0x0014CBF8
		static readonly int mabms9bcgh;

		// Token: 0x04050A9C RID: 330396 RVA: 0x0014EA00 File Offset: 0x0014CC00
		static readonly int vDGfUiGhoO;

		// Token: 0x04050A9D RID: 330397 RVA: 0x0014EA08 File Offset: 0x0014CC08
		static readonly int Xv8uiIdv5W;
	}
}
