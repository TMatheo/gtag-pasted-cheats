﻿using System;
using System.Runtime.CompilerServices;

namespace CanvasGUI.Management
{
	// Token: 0x0200003B RID: 59
	public class Category
	{
		// Token: 0x17000041 RID: 65
		// (get) Token: 0x060001FF RID: 511 RVA: 0x00665308 File Offset: 0x00663508
		// (set) Token: 0x06000200 RID: 512 RVA: 0x006657D4 File Offset: 0x006639D4
		public unsafe string name
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Category.2MO8TCX5NI) ^ *(&Category.2MO8TCX5NI)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					num ^= 1155600015;
					int num2 = Category.f3GyHDM3Ho;
					array2[num2 + 6 - num2] = (num | 8);
					int num3;
					num2 = num - num3;
					num3 = 1015400267;
					num = num2 / 474;
					int num4;
					if (num > num)
					{
						num3 = (num4 ^ num3);
						num = (num2 & num3);
						num3 = -num4;
						num3 = ~num;
						num /= num3;
						num2 = (num4 | num3);
						num2 = ~num;
						num4 |= 795971158;
					}
					*(ref num3 + (IntPtr)num2) = num2;
					num4 = (int)((byte)num2);
					num = num2 * num3;
					num2 = num2;
					num3 = num / num3;
					num = num3;
					Category.f3GyHDM3Ho = num2;
					array[num + 7 - num2] = (num | -6);
					num4 %= 183;
					num4 = *(ref num2 + (IntPtr)num3);
					if (num3 > num3)
					{
						num4 |= 1065900415;
						num3 = (num4 | 1569289420);
						num2 = *(ref Category.f3GyHDM3Ho + (IntPtr)num);
						if (num2 > num2)
						{
							num4 = num3;
						}
						num2 = *(ref num3 + (IntPtr)num2);
					}
					num2 = array[num + 5 - num3] + -2;
					num3 = num4 / 311;
					num4 = (int)((byte)num2);
					num2 = (int)((ushort)num3);
					if (num > num)
					{
						num3 = Category.f3GyHDM3Ho;
						array2[num2 + 8 - num3] = (num4 | 2);
						num = -num2;
						array2[num4 + 7 - num2] = num4 - 4;
						*(ref num4 + (IntPtr)num3) = num3;
						num = (array[num3 + 5 - num] ^ 8);
						if (num4 > num4)
						{
							num = (num2 | 224973227);
							num2 ^= 618266134;
							num2 = num % 77;
						}
					}
					num = Category.f3GyHDM3Ho;
					num2 = -num2;
					num3 = ~num2;
					if (num4 > num4)
					{
						num = array[num2 + 6 - num2] + -9;
						num3 = num * num3;
						num = (num2 & 1411456070);
						*(ref Category.f3GyHDM3Ho + (IntPtr)num4) = num4;
						num4 = (int)((ushort)num);
						num2 = (array2[num4 + 6 - num2] ^ -10);
						num4 = num3 - num2;
						num3 = num2 / 419;
						array[num4 + 6 - num] = (num4 | -4);
						if (num4 > num4)
						{
							num |= 1830367049;
						}
					}
					array[num2 + 9 - num4] = num - -9;
					if (num > num)
					{
						num4 = num / num3;
						num4 = -num4;
						if (num3 > num3)
						{
							num = -num2;
							num3 = num4;
						}
						array2[num + 9 - num3] = num3 - -2;
						num = (num4 | num3);
					}
					if (num2 > num2)
					{
						num = (num2 | num3);
						num2 = (num3 | num2);
						num2 = num3;
					}
					num = num4 >> 2;
					num2 -= 974;
				}
				return this.<name>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Category.bKgJ5Uzx31) ^ *(&Category.bKgJ5Uzx31)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					if (num > num)
					{
						array[num2 + 9 - num2] = num - 0;
					}
					int num3 = num2 % 326;
					num2 = array[num3 + 8 - num2] + -4;
					if (num2 > num2)
					{
						num3 = num;
						num2 = num;
						num = (array[num + 8 - num2] ^ 8);
						num3 = num * 161;
						num2 = num - 168;
						num3 = num3;
						num2 >>= 4;
						num = (num2 ^ num);
						num2 = num3 % num;
						num3 = ~num3;
					}
					num3 = (array[num2 + 7 - num2] ^ -4);
					num3 = (array[num3 + 8 - num] ^ -7);
					num2 = (num | 1398020786);
					*(ref num3 + (IntPtr)num) = num;
					array[num2 + 9 - num3] = num2 - -9;
					if (num > num)
					{
						num2 = num3 / 40;
						num3 = num % 665;
						num = 911234313;
					}
					num3 = -num2;
					num3 = 1336213506;
					num2 = (num3 ^ num);
					Category.f3GyHDM3Ho = num2;
					num3 = array[num3 + 7 - num2] + 1;
					num3 = (array[num + 8 - num] ^ -10);
					num3 = *(ref Category.f3GyHDM3Ho + (IntPtr)num2);
					num &= num2;
					num = num2;
					Category.f3GyHDM3Ho = num3;
					num3 = array[num + 8 - num3] + -3;
					if (num2 > num2)
					{
						if (num2 > num2)
						{
							num = num;
							num2 = array[num + 7 - num2] + 0;
							Category.f3GyHDM3Ho = num;
							num2 = num2;
							array[num3 + 9 - num] = (num2 | -4);
							num2 = num / 939;
						}
						num2 = (array[num3 + 5 - num3] ^ 2);
						num3 = num % num2;
						array[num3 + 9 - num3] = num2 - 8;
						num2 = num3;
						num3 = num2 * num;
						num3 /= num;
						num3 = (int)((short)num);
					}
					num = ~num3;
					num3 %= 922;
					num3 = num * num2;
					num2 &= 1215265704;
					if (num3 > num3)
					{
						array[num + 8 - num2] = (num | -8);
						num3 -= num;
						num3 = 1392664294;
						num2 = 569448785;
						num = (int)((sbyte)num3);
						num3 = num2;
						num3 = ~num2;
						array[num2 + 8 - num] = (num3 | 2);
						num2 = -num;
					}
					*(ref Category.f3GyHDM3Ho + (IntPtr)num3) = num3;
					num2 = (num | 1291355140);
					num3 = array[num3 + 8 - num] + -8;
					array[num + 6 - num] = (num | -1);
					num /= num2;
					*(ref Category.f3GyHDM3Ho + (IntPtr)num) = num;
					num |= num2;
					num = (int)((short)num3);
				}
				this.<name>k__BackingField = value;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000201 RID: 513 RVA: 0x00665C9C File Offset: 0x00663E9C
		// (set) Token: 0x06000202 RID: 514 RVA: 0x00666078 File Offset: 0x00664278
		public unsafe Module[] buttons
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Category.u5LIstkl0P) ^ *(&Category.u5LIstkl0P)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = (int)((short)num2);
					int num4;
					int num3 = num4 / 296;
					if (num > num)
					{
						num4 = *(ref num3 + (IntPtr)num2);
						num3 = array[num2 + 6 - num4] + 4;
						num2 = (int)((short)num2);
						if (num2 > num2)
						{
							num = num2 % 58;
							num3 = num % 647;
							num3 = 957552169;
							array[num3 + 6 - num4] = (num3 | -3);
							*(ref num4 + (IntPtr)num2) = num2;
							*(ref Category.f3GyHDM3Ho + (IntPtr)num2) = num2;
						}
						array[num3 + 8 - num4] = num4 - 4;
						num &= num2;
						num = Category.f3GyHDM3Ho;
					}
					num = 819392301;
					if (num > num)
					{
						array[num2 + 7 - num] = (num2 | -5);
						num4 = 1489523071;
						num = Category.f3GyHDM3Ho;
						num2 = -num2;
					}
					num = num4 % 303;
					num2 &= 506463625;
					num = num4 % num2;
					num = num3 * 592;
					if (num4 > num4)
					{
						num = ~num2;
						num3 = num2;
						num4 = num3;
						num4 = (int)((short)num3);
						array[num2 + 8 - num4] = num3 - 7;
						num2 = num4 >> 2;
						num4 = array[num + 8 - num] + -6;
					}
					num2 = ~num;
					Category.f3GyHDM3Ho = num;
					num4 = 191011730;
					num4 = num3 >> 3;
					num3 = (array[num4 + 5 - num2] ^ 4);
					if (num3 > num3)
					{
						num2 = num4 - num2;
						if (num3 > num3)
						{
							num3 ^= num2;
							num2 = -num;
							num2 = num4 % 673;
							num = num;
						}
						num4 = num / 29;
						if (num3 > num3)
						{
							Category.f3GyHDM3Ho = num2;
							num2 = 1298075557;
							num3 = num + 8;
							num3 /= num2;
							num2 = -num3;
						}
						array[num2 + 9 - num3] = (num | 8);
						num = (num2 ^ num4);
						num4 = *(ref num3 + (IntPtr)num2);
						num = ~num;
						num3 = (num4 ^ 691682009);
						num2 = (num & 1155383932);
					}
					num = (num2 | 514185877);
					*(ref num3 + (IntPtr)num2) = num2;
					num4 = array[num + 9 - num] + -10;
				}
				return this.<buttons>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Category.9P5lrdDTt6) ^ *(&Category.9P5lrdDTt6)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = *(ref Category.f3GyHDM3Ho + (IntPtr)num2);
					int num3 = -num3;
					int num4;
					if (num2 > num2)
					{
						if (num4 > num4)
						{
							num = num2;
							num4 %= num2;
							num4 = Category.f3GyHDM3Ho;
						}
					}
					num3 = *(ref num4 + (IntPtr)num2);
					num2 = 120516101;
					num3 /= num2;
					num4 = num2 >> 3;
					num3 = num + num2;
					num2 = Category.f3GyHDM3Ho;
					num2 = num3 - 358;
					num2 = *(ref num3 + (IntPtr)num2);
					num3 = Category.f3GyHDM3Ho;
					num4 = 1059696555;
					num = -num2;
					num *= 915;
					num2 = num4 - 141;
					num3 = (num4 & 1265987603);
					num3 = (int)((ushort)num);
					num2 = num / 238;
					num = (num2 ^ 1912977747);
					num3 = (num2 | 2068883588);
					num = num2 / num;
					num4 >>= 1;
					*(ref Category.f3GyHDM3Ho + (IntPtr)num) = num;
					num4 = (array2[num + 7 - num4] ^ -8);
					array[num2 + 9 - num] = (num3 | -8);
					num4 = Category.f3GyHDM3Ho;
					num4 = array[num4 + 8 - num2] + -7;
					if (num4 > num4)
					{
						if (num4 > num4)
						{
							num4 = num3 + 719;
							num3 = *(ref Category.f3GyHDM3Ho + (IntPtr)num2);
							*(ref num2 + (IntPtr)num) = num;
							num3 = (num4 & 305702293);
							num2 = array2[num2 + 9 - num] + -9;
							num4 = ~num4;
							num3 = *(ref Category.f3GyHDM3Ho + (IntPtr)num);
						}
						num3 = *(ref Category.f3GyHDM3Ho + (IntPtr)num2);
						array[num2 + 7 - num3] = (num | 4);
						if (num4 > num4)
						{
							num4 ^= num2;
							num2 = (num4 ^ num2);
							num = (num4 | num2);
							num4 %= num2;
						}
						num3 = *(ref Category.f3GyHDM3Ho + (IntPtr)num3);
					}
					num &= 420806000;
					if (num > num)
					{
						num /= num2;
						num4 = num2;
						num = array[num4 + 9 - num] + 8;
						num = -num;
						num |= num2;
					}
					num3 = (num4 | num2);
					num3 |= 171979321;
					array2[num2 + 5 - num3] = (num2 | 0);
					num4 = num2;
					num2 = num4 - num2;
					num = num2;
					array[num + 6 - num3] = num2 - -4;
					num2 = -num2;
				}
				this.<buttons>k__BackingField = value;
			}
		}

		// Token: 0x06000203 RID: 515 RVA: 0x00666494 File Offset: 0x00664694
		public unsafe Category(string name, Module[] buttons)
		{
			if ((*(&Category.heLohrpFC9) ^ *(&Category.heLohrpFC9)) != 0)
			{
				int[] array = new int[10];
				int num2;
				int num = *(ref Category.f3GyHDM3Ho + (IntPtr)num2);
				num2 = -num2;
				int num3;
				num = num3 - num2;
				int num4;
				if (num > num)
				{
					num4 = (num3 ^ num2);
					if (num3 > num3)
					{
						num4 = *(ref Category.f3GyHDM3Ho + (IntPtr)num);
					}
					num = num4 + num3;
					num3 = (array[num2 + 7 - num2] ^ 6);
				}
				num2 = -num4;
				num3 = num2 - 722;
				array[num + 5 - num2] = (num2 | 8);
				num = num3 % num2;
				num = (int)((byte)num);
				num4 = -num3;
				num4 = num2;
				num3 = num4 >> 2;
				num2 = array[num4 + 6 - num4] + -8;
				num4 = (num & 2027008445);
				num2 = num - 168;
				num4 |= num3;
				if (num > num)
				{
					num4 = 1870293037;
					num2 = *(ref num3 + (IntPtr)num2);
					*(ref Category.f3GyHDM3Ho + (IntPtr)num3) = num3;
					num = ~num2;
				}
				num = num2 - 837;
				Category.f3GyHDM3Ho = num4;
				if (num > num)
				{
					num3 = (int)((byte)num);
					num = 239317750;
					num = num3;
				}
				if (num4 > num4)
				{
					num4 = (num3 & num2);
					if (num2 > num2)
					{
						*(ref num3 + (IntPtr)num2) = num2;
						num = (num2 & 1803483616);
						num = (int)((sbyte)num3);
						num4 = 201575351;
						num = (num2 | num3);
						num = (array[num3 + 8 - num4] ^ -6);
						num3 = num + num3;
						num3 &= num2;
						num4 = num;
					}
					num = (int)((short)num3);
					if (num2 > num2)
					{
						num2 += 676;
						num = (num3 ^ 844398490);
						num4 = (num3 ^ num2);
						num2 = array[num4 + 9 - num] + 6;
						num = num3 >> 5;
						num3 = num + num3;
						array[num3 + 7 - num2] = (num3 | 7);
					}
					if (num > num)
					{
						num2 = num4 % 869;
						num4 = (array[num2 + 8 - num] ^ 2);
						num = (num3 & 1946690208);
						num3 = num2 / num3;
						num = num4 / 606;
						num = (num3 ^ num2);
						num = num4 + num3;
						num3 |= 301918365;
						num = (num4 & 619299969);
					}
					num2 = num4 + 108;
					if (num > num)
					{
						num4 = (array[num4 + 5 - num] ^ -7);
						num4 = num3;
						*(ref Category.f3GyHDM3Ho + (IntPtr)num) = num;
						num4 = *(ref Category.f3GyHDM3Ho + (IntPtr)num2);
						array[num4 + 5 - num2] = (num3 | 0);
						num4 = (array[num2 + 6 - num] ^ -10);
						num = Category.f3GyHDM3Ho;
					}
					num2 = (num & 1175305312);
					num = num4 + num3;
					if (num > num)
					{
						num4 += num3;
					}
				}
				num3 = *(ref num3 + (IntPtr)num2);
				array[num + 7 - num2] = num - -1;
				num3 = num << 2;
				num = (num4 | num3);
				if (num3 > num3)
				{
					num4 = -num4;
					if (num > num)
					{
						num = ~num;
						num = num2 - num3;
						Category.f3GyHDM3Ho = num4;
						num = num2 - num3;
						num3 = num3;
					}
					if (num3 > num3)
					{
						num = Category.f3GyHDM3Ho;
						num4 = num2 % 702;
						num4 = num3 / num2;
						num = (num2 | num3);
						num3 = (array[num3 + 5 - num] ^ -7);
						num4 = *(ref Category.f3GyHDM3Ho + (IntPtr)num4);
					}
					num2 = -num;
					if (num > num)
					{
						num3 = num / 322;
						num2 = (array[num3 + 8 - num2] ^ 5);
					}
					num3 = num2;
					num = -num;
					num2 = num4 - num3;
					if (num > num)
					{
						num3 = (int)((byte)num3);
						num2 = num3 / 381;
						num2 = (num3 ^ num2);
						num = ~num4;
						num2 = (int)((ushort)num3);
						*(ref num3 + (IntPtr)num2) = num2;
						array[num2 + 7 - num4] = (num4 | 3);
						num3 = *(ref num4 + (IntPtr)num3);
						Category.f3GyHDM3Ho = num4;
						num3 >>= 1;
					}
					num4 = (int)((short)num);
				}
				*(ref num4 + (IntPtr)num3) = num3;
				num = 2034808057;
				num = (num3 ^ 520337973);
				num4 = (array[num + 9 - num3] ^ 4);
			}
			base..ctor();
			this.name = name;
			this.buttons = buttons;
		}

		// Token: 0x04050AA0 RID: 330400 RVA: 0x0014EA10 File Offset: 0x0014CC10
		static int 2MO8TCX5NI;

		// Token: 0x04050AA1 RID: 330401 RVA: 0x0014EA18 File Offset: 0x0014CC18
		static int f3GyHDM3Ho;

		// Token: 0x04050AA2 RID: 330402 RVA: 0x0014EA20 File Offset: 0x0014CC20
		static int bKgJ5Uzx31;

		// Token: 0x04050AA3 RID: 330403 RVA: 0x0014EA28 File Offset: 0x0014CC28
		static int u5LIstkl0P;

		// Token: 0x04050AA4 RID: 330404 RVA: 0x0014EA30 File Offset: 0x0014CC30
		static int 9P5lrdDTt6;

		// Token: 0x04050AA5 RID: 330405 RVA: 0x0014EA38 File Offset: 0x0014CC38
		static int heLohrpFC9;
	}
}
