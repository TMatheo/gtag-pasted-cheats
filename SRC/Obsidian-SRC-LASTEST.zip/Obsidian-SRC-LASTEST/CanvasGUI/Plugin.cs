﻿using System;
using BepInEx;

namespace CanvasGUI
{
	// Token: 0x02000036 RID: 54
	[BepInPlugin("com.obs.gorillatag.lol", "Obsidian.LOL", "2.0.1")]
	public class Plugin : BaseUnityPlugin
	{
		// Token: 0x060001E2 RID: 482 RVA: 0x00651AA4 File Offset: 0x0064FCA4
		public unsafe void OnEnable()
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			int num = 15;
			if ((*(&Plugin.Fi1vAp3lsS) ^ *(&Plugin.Fi1vAp3lsS)) != 0)
			{
				int[] array = new int[10];
				int num3;
				int num2 = *(ref Plugin.iP87Nyibfe + (IntPtr)num3);
				int num5;
				int num4 = num5 * 879;
				num2 = array[num3 + 6 - num3] + 3;
				num5 = num4;
				num5 *= 667;
				num4 = *(ref Plugin.iP87Nyibfe + (IntPtr)num3);
				num2 = ~num4;
				num2 = num4 + num2;
				if (num5 > num5)
				{
					num3 = Plugin.iP87Nyibfe;
				}
				num2 = num3 % num2;
				if (num4 > num4)
				{
					num4 = (num5 | 1596644410);
					num5 = Plugin.iP87Nyibfe;
					if (num3 > num3)
					{
						num2 = 1679498827;
						num3 = 126983879;
						num2 = num3;
						num3 = num2 % num3;
						num5 = (int)((short)num4);
					}
				}
				*(ref Plugin.iP87Nyibfe + (IntPtr)num5) = num5;
				num2 = 886492866;
				num5 = num2;
				num3 = -num2;
				*(ref Plugin.iP87Nyibfe + (IntPtr)num3) = num3;
				if (num4 > num4)
				{
					if (num4 > num4)
					{
						num5 %= 809;
						num2 = (num3 | num2);
						num2 = *(ref Plugin.iP87Nyibfe + (IntPtr)num5);
						num5 = (int)((byte)num2);
						num5 = -num4;
						num5 = ~num3;
						num2 &= 1475721695;
						num3 = -num4;
						num4 = (int)((byte)num4);
					}
					num4 = (int)((short)num4);
					num4 = *(ref Plugin.iP87Nyibfe + (IntPtr)num3);
					if (num4 > num4)
					{
						num3 = num2 / num3;
						num4 = num2;
						num4 = num4;
						num2 = num5 >> 5;
						array[num5 + 9 - num5] = num2 - 9;
						num3 = num4 % num2;
					}
					num2 = 1008056326;
					num5 = -num5;
					num2 = *(ref num2 + (IntPtr)num3);
					num2 %= 513;
				}
				num4 = (array[num5 + 9 - num4] ^ -1);
				num2 = num5 % 717;
				num4 = num4;
				num4 = num3 - num2;
			}
			int[] array2 = new int[num];
			for (;;)
			{
				IL_1D7:
				uint num6 = 2832641943U;
				for (;;)
				{
					uint num7;
					switch ((num7 = (num6 ^ (uint)(*(&Plugin.vszYykqsUw)))) % (uint)(*(&Plugin.C5ZODQX2vN)))
					{
					case 0U:
					{
						array2[2] = 1846245392;
						uint[] array3 = new uint[*(&Plugin.8Euzoyfzfq)];
						array3[*(&Plugin.0ixtPwbbrR)] = (uint)(*(&Plugin.oEVnCt5cNq) + *(&Plugin.O03utYPwgd));
						array3[*(&Plugin.kbH7nAf3XU)] = (uint)(*(&Plugin.d1n353tHx4));
						array3[*(&Plugin.2CmybAoD91)] = (uint)(*(&Plugin.hp5OqM7YAB));
						num6 = ((num7 ^ array3[*(&Plugin.NCF2NXNAyz)]) - (uint)(*(&Plugin.pH8lkizSfn)) - (uint)(*(&Plugin.Wb3gxx5ZNt)) ^ (uint)(*(&Plugin.6UHwr07tlE)));
						continue;
					}
					case 1U:
					{
						array2[1] = 1167378691;
						uint num8 = num7 & (uint)(*(&Plugin.rbs1gLaDW3) + *(&Plugin.74VhfpD2bq));
						num6 = (((num8 | (uint)(*(&Plugin.WlKFNCmHat))) - (uint)(*(&Plugin.wDmAX5r9Hl) + *(&Plugin.ChGUkhLEUr)) | (uint)(*(&Plugin.dAlKSGRmne))) ^ (uint)(*(&Plugin.jTmnH4SVKj)));
						continue;
					}
					case 2U:
					{
						int[] array4 = array2;
						int num9 = 1;
						int num10 = (array2[1] << 6) + 262;
						array4[num9] = (array2[1] ^ num10 ^ (667453007 ^ num10));
						int[] array5 = array2;
						int num11 = 2;
						int num12 = array2[2];
						num10 = -((((111 == 0) ? (num12 - 94) : (num12 + 111)) >> 5 ^ -494) - -359 - 271);
						array5[num11] = (array2[2] ^ num10 ^ (667453007 ^ num10));
						int[] array6 = array2;
						int num13 = 3;
						num10 = (array2[3] * -270 * -154 >> 6) - -110;
						array6[num13] = (array2[3] ^ num10 ^ (667453007 ^ num10));
						num6 = 4194322103U;
						continue;
					}
					case 3U:
					{
						int num14 = 107;
						uint[] array7 = new uint[*(&Plugin.5ChXvGp9RK)];
						array7[*(&Plugin.SUnYvg3vH6)] = (uint)(*(&Plugin.qSmZV4dgMg));
						array7[*(&Plugin.megWXtKbms)] = (uint)(*(&Plugin.5raJerSBcg) + *(&Plugin.XlvygnZHC0));
						array7[*(&Plugin.mIwviyxQBC)] = (uint)(*(&Plugin.WbJZB81c5n));
						array7[*(&Plugin.mcEpIAsr0t)] = (uint)(*(&Plugin.UCZwFx5plp));
						num6 = (((num7 | array7[*(&Plugin.4BAZK6cWxh)]) ^ (uint)(*(&Plugin.w6MYOKDHmh)) ^ array7[*(&Plugin.FGaRsTBWTN) + *(&Plugin.DL1PtlbpeM)]) - array7[*(&Plugin.iW3S7X0Bh4)] ^ (uint)(*(&Plugin.txCEkxksr0)));
						continue;
					}
					case 4U:
						num6 = 3807307516U;
						continue;
					case 5U:
					{
						int num14;
						num6 = (((num14 != 107) ? 3621187667U : 2547428775U) ^ num7 * 3246211949U);
						continue;
					}
					case 6U:
					{
						calli(System.Void(System.Boolean), array2[0], Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array2[1] ^ array2[2]) - array2[3]]);
						uint num15 = num7 * (uint)(*(&Plugin.3PF9DMadx1) + *(&Plugin.1Cde9nM2hE));
						num6 = ((num15 + (uint)(*(&Plugin.S8OKUQJ94x)) | (uint)(*(&Plugin.6Han6JYZzU))) ^ (uint)(*(&Plugin.1eooFh6tpo)));
						continue;
					}
					case 7U:
					{
						array2[0] = 667453006;
						uint num16 = num7 & (uint)(*(&Plugin.F4gOJ7EYnp));
						num6 = ((num16 * (uint)(*(&Plugin.jO7yQoGcpE)) & (uint)(*(&Plugin.XZ0oxdkcOi))) ^ (uint)(*(&Plugin.cgmzXh2C0o)));
						continue;
					}
					case 8U:
						goto IL_1D7;
					case 10U:
					{
						array2[3] = 207038604;
						uint num17 = num7 - (uint)(*(&Plugin.wnPJLZqTnI));
						uint num18 = num17 - (uint)(*(&Plugin.Xo3WpwJjEZ));
						uint num19 = num18 + (uint)(*(&Plugin.byxF3VAM4u));
						uint num20 = num19 ^ (uint)(*(&Plugin.kFqa0sMtUY) + *(&Plugin.HmvEWRbuG4));
						uint num21 = num20 | (uint)(*(&Plugin.qXpMn80JP0));
						num6 = ((num21 & (uint)(*(&Plugin.YdZ2hR8cg6))) ^ (uint)(*(&Plugin.kaOpRzCstm)));
						continue;
					}
					case 11U:
					{
						int[] array8 = array2;
						int num22 = 0;
						int num23 = (array2[0] + 439) * 35;
						int num10 = -((-347 == 0) ? (num23 - 85) : (num23 + -347)) << 2;
						array8[num22] = (array2[0] ^ num10 ^ (667453007 ^ num10));
						num6 = 2214012866U;
						continue;
					}
					case 12U:
					{
						uint[] array9 = new uint[*(&Plugin.5FCjdkF6pm)];
						array9[*(&Plugin.sYma8tMITU)] = (uint)(*(&Plugin.dAyZeQIxp5));
						array9[*(&Plugin.At7nQdTTyX)] = (uint)(*(&Plugin.S4V5LVKmF1));
						array9[*(&Plugin.lbZWX4QnFN)] = (uint)(*(&Plugin.bSQtm9a9Jf));
						array9[*(&Plugin.Z2U6Cjo3NI) + *(&Plugin.FgryUiTlQW)] = (uint)(*(&Plugin.MqNk5AnlSL));
						array9[*(&Plugin.5LcjbsHdTx)] = (uint)(*(&Plugin.QWZ7I5kcZD) + *(&Plugin.qysxStotAC));
						num6 = (((num7 & (uint)(*(&Plugin.6ClCN4DIWm))) - (uint)(*(&Plugin.b0RdF0RQcA) + *(&Plugin.ZKMPfGdpQs)) | (uint)(*(&Plugin.DXcR0NvXuO))) - (uint)(*(&Plugin.1cGxlzhOrc)) ^ array9[*(&Plugin.bYR9mv0VgG)] ^ (uint)(*(&Plugin.aY1niDXAm2)));
						continue;
					}
					}
					return;
				}
			}
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x006520CC File Offset: 0x006502CC
		public unsafe void OnDisable()
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			int num = 15;
			if ((*(&Plugin.jmztdY8jJN) ^ *(&Plugin.jmztdY8jJN)) != 0)
			{
				int[] array = new int[10];
				int num3;
				int num2 = num3 / 993;
				int num4;
				num4 >>= 1;
				int num5;
				*(ref num3 + (IntPtr)num5) = num5;
				num2 += num5;
				array[num3 + 6 - num2] = num5 - 9;
				if (num2 > num2)
				{
					num5 = num3 % num5;
					if (num2 > num2)
					{
						num5 = num3 >> 6;
						num3 = num2;
						num4 = num2 * 413;
						*(ref num3 + (IntPtr)num5) = num5;
					}
					num3 = (num4 | num5);
					if (num4 > num4)
					{
						num5 = (num3 | 386848907);
						num2 = ~num3;
					}
					num5 = num4 / 291;
					*(ref Plugin.iP87Nyibfe + (IntPtr)num3) = num3;
					if (num2 > num2)
					{
						num5 = (num2 | num5);
						*(ref num3 + (IntPtr)num5) = num5;
						*(ref Plugin.iP87Nyibfe + (IntPtr)num4) = num4;
					}
					if (num4 > num4)
					{
						num5 = *(ref Plugin.iP87Nyibfe + (IntPtr)num5);
						num4 = num2 / num5;
						num4 = num2 << 5;
						array[num3 + 6 - num2] = num5 - 9;
						num3 |= 1403827454;
						num5 ^= num4;
						array[num5 + 7 - num4] = num3 - -9;
						num3 = num2;
					}
					if (num2 > num2)
					{
						num4 = (num2 | 1959793650);
						num2 = num4 % 826;
						num2 = -num4;
						*(ref Plugin.iP87Nyibfe + (IntPtr)num2) = num2;
						num2 %= 405;
						num5 = num3 % num5;
						num3 = (int)((sbyte)num4);
						num3 = (num4 ^ 841588593);
					}
				}
				if (num2 > num2)
				{
					num4 = num3 << 3;
					num3 = -num2;
					num3 += num5;
					num3 = ~num3;
					num2 = *(ref Plugin.iP87Nyibfe + (IntPtr)num2);
					num3 = num4 >> 7;
					*(ref Plugin.iP87Nyibfe + (IntPtr)num4) = num4;
					num3 = *(ref num2 + (IntPtr)num5);
					num3 = ~num3;
					num3 = num4 * num5;
				}
				array[num5 + 8 - num5] = (num4 | 5);
				num3 = (num5 | 1842432788);
				if (num5 > num5)
				{
					num2 = num5 << 7;
					num5 = num2 - num5;
					num3 = num4 + num5;
					if (num2 > num2)
					{
						*(ref num2 + (IntPtr)num5) = num5;
						num4 = (int)((ushort)num5);
						num3 /= num5;
						num2 = (array[num4 + 6 - num3] ^ -8);
						num3 = -num4;
						num5 = array[num4 + 8 - num4] + 0;
						array[num3 + 7 - num4] = num4 - 2;
						num3 >>= 3;
					}
					if (num2 > num2)
					{
						num3 = -num3;
						num4 = (int)((sbyte)num5);
						num2 -= num5;
						num2 = (array[num3 + 8 - num2] ^ 8);
						num4 = (int)((short)num2);
						num4 = num4;
						num5 = -num2;
						num3 = num5 / 466;
						num3 = (num5 & 842068611);
						num5 = num4 / 229;
					}
					if (num5 > num5)
					{
						num5 = num3 / 959;
						num5 = -num4;
						num5 &= 539529806;
						num4 |= 249181341;
						num3 = 2008311638;
						num4 = -num2;
					}
					num2 = (num4 & num5);
					num3 = num5 * num4;
					num5 = (num2 & 1408653801);
					num3 = Plugin.iP87Nyibfe;
				}
				if (num3 > num3)
				{
					num2 = (int)((sbyte)num4);
					num2 = num4 + 591;
					num3 = num5;
					num4 = *(ref Plugin.iP87Nyibfe + (IntPtr)num2);
					num2 = (int)((short)num2);
				}
				num3 = ~num3;
				if (num4 > num4)
				{
					num5 = num2 * 727;
					num5 = (num4 | num5);
					num4 = num5 / num4;
					*(ref Plugin.iP87Nyibfe + (IntPtr)num5) = num5;
				}
				num4 = num5;
				num4 = num2 - 326;
				num3 = (num2 & num5);
				num3 = 1102097718;
				num2 = num5 >> 1;
				num5 = (int)((short)num4);
				num5 = num4 * 555;
				num2 = num4 * 769;
				Plugin.iP87Nyibfe = num2;
				if (num2 > num2)
				{
					num2 = num5 / 495;
					num5 = (array[num2 + 5 - num3] ^ 2);
					num5 = ~num5;
					num3 = num2 + num5;
					if (num4 > num4)
					{
						num4 = -num4;
					}
					num3 = Plugin.iP87Nyibfe;
					num5 = ~num3;
					num5 = ~num3;
				}
				array[num4 + 7 - num2] = num4 - -10;
				num2 = num4 % num5;
				array[num3 + 5 - num5] = num2 - 3;
				num4 = (array[num4 + 7 - num5] ^ -8);
				num5 = num2 >> 3;
				num4 /= 504;
				array[num2 + 7 - num3] = num3 - 9;
				num4 = *(ref Plugin.iP87Nyibfe + (IntPtr)num5);
				num2 = num4 / num5;
				num5 = num5;
				num4 = num5 + 930;
				num4 = (array[num2 + 5 - num3] ^ 3);
				if (num3 > num3)
				{
					num5 = -num3;
					num2 = Plugin.iP87Nyibfe;
					Plugin.iP87Nyibfe = num2;
					num4 = num2 + 495;
				}
				num2 = num3 % num5;
				num3 = *(ref Plugin.iP87Nyibfe + (IntPtr)num3);
				num3 = (num5 & num4);
				num4 = num2;
				num2 = (num3 ^ 2102934690);
				array[num5 + 9 - num2] = (num2 | 2);
				num2 = (num4 ^ num5);
				num5 = *(ref num3 + (IntPtr)num5);
				if (num2 > num2)
				{
					num4 = (int)((ushort)num4);
					num3 = -num3;
					num2 = (num3 & num5);
					num5 = (num2 & num5);
				}
				if (num5 > num5)
				{
					num4 = *(ref Plugin.iP87Nyibfe + (IntPtr)num2);
					num5 = num4 >> 7;
					num4 = *(ref num2 + (IntPtr)num5);
					num3 = *(ref Plugin.iP87Nyibfe + (IntPtr)num4);
					*(ref Plugin.iP87Nyibfe + (IntPtr)num2) = num2;
					num5 = (num3 & 1472931020);
					if (num4 > num4)
					{
						num4 = Plugin.iP87Nyibfe;
						num5 = num3 >> 5;
						num5 = num4 - 858;
						num4 = -num5;
					}
					num2 = ~num2;
					*(ref num3 + (IntPtr)num5) = num5;
				}
			}
			int[] array2 = new int[num];
			for (;;)
			{
				IL_556:
				uint num6 = 2883473368U;
				for (;;)
				{
					uint num7;
					switch ((num7 = (num6 ^ (uint)(*(&Plugin.mJLoT5B5pw)))) % (uint)(*(&Plugin.DaiA5um0i0)))
					{
					case 0U:
					{
						array2[0] = 1269966287;
						uint[] array3 = new uint[*(&Plugin.GV3PjwMJ30)];
						array3[*(&Plugin.4yhnBqYFBw)] = (uint)(*(&Plugin.CdJfMyFZ0C));
						array3[*(&Plugin.9KhyXrliwe)] = (uint)(*(&Plugin.eDcRwvS38t));
						array3[*(&Plugin.JhtWUmLYDu)] = (uint)(*(&Plugin.qxT10uQtPT));
						array3[*(&Plugin.E0ThR9B2sb)] = (uint)(*(&Plugin.gMaG3caLev));
						uint num8 = (num7 + array3[*(&Plugin.gNfBxrtlaC)] | (uint)(*(&Plugin.ejoopSNLEU))) ^ array3[*(&Plugin.kSplNeWM7Y)];
						num6 = (num8 * (uint)(*(&Plugin.TFOdx0URuk)) ^ (uint)(*(&Plugin.Qacq66ivak)));
						continue;
					}
					case 2U:
					{
						int[] array4 = array2;
						int num9 = 2;
						int num10 = array2[2];
						int num12;
						int num11 = (-187 == 0) ? (num12 = num10 - 57) : (num12 = num10 + -187);
						int num14;
						int num13 = (-218 == 0) ? (num14 = num11 - 96) : (num14 = num12 + -218);
						int num15 = (70 == 0) ? (num13 - 28) : (num14 + 70);
						array4[num9] = (array2[2] ^ num15 ^ (1269966287 ^ num15));
						num6 = 2497590134U;
						continue;
					}
					case 3U:
					{
						array2[1] = 1858983385;
						array2[2] = 180646276;
						array2[3] = 800819138;
						int[] array5 = array2;
						int num16 = 0;
						int num15 = -(array2[0] * 496) ^ -72;
						array5[num16] = (array2[0] ^ num15 ^ (1269966287 ^ num15));
						uint[] array6 = new uint[*(&Plugin.OOGKKNi3yS) + *(&Plugin.UgnBsZVK1z)];
						array6[*(&Plugin.85beEK09pQ)] = (uint)(*(&Plugin.6kvXJE8ETj));
						array6[*(&Plugin.SbdbPtxa7g)] = (uint)(*(&Plugin.lY4lmTxlGA));
						array6[*(&Plugin.XjOhWuvQ2n)] = (uint)(*(&Plugin.aR0SghbAPU));
						array6[*(&Plugin.WZBIoiqJuz) + *(&Plugin.RX7SLtM6Ef)] = (uint)(*(&Plugin.8hiUGUhmEF));
						array6[*(&Plugin.2wVvn7hG2y) + *(&Plugin.DlfCWDTiGx)] = (uint)(*(&Plugin.Ue5uWz1rCU));
						array6[*(&Plugin.AEEp7eBLoO) + *(&Plugin.LFEQbXCf7C)] = (uint)(*(&Plugin.B9fRuX1lZy) + *(&Plugin.G0Eix9gzE1));
						uint num17 = num7 ^ array6[*(&Plugin.CH32mOapT9)];
						uint num18 = ((num17 | (uint)(*(&Plugin.xVt9SBix4k))) + (uint)(*(&Plugin.nZwzIUBgdc)) | array6[*(&Plugin.0MbGA3Fnog)]) ^ (uint)(*(&Plugin.6LSZBuHEPv));
						num6 = (num18 ^ (uint)(*(&Plugin.as5eNmUDuR)) ^ (uint)(*(&Plugin.N4M0Ik4m9Y) + *(&Plugin.65JYncHWyX)));
						continue;
					}
					case 4U:
					{
						int[] array7 = array2;
						int num19 = 1;
						int num15 = (array2[1] % 64 - -325) % 39;
						array7[num19] = (array2[1] ^ num15 ^ (1269966287 ^ num15));
						uint num20 = num7 + (uint)(*(&Plugin.N6QrCIR73X)) | (uint)(*(&Plugin.jC3WSC9bRb)) | (uint)(*(&Plugin.zeF1zfjg0v));
						uint num21 = num20 * (uint)(*(&Plugin.e8PWEQney9));
						num6 = (num21 * (uint)(*(&Plugin.T7tlz3CwFk)) ^ (uint)(*(&Plugin.cpFXit1Z2g)));
						continue;
					}
					case 5U:
					{
						uint[] array8 = new uint[*(&Plugin.PxDMNyTjFw)];
						array8[*(&Plugin.UaTQKw6vTB)] = (uint)(*(&Plugin.HctCRa5osU) + *(&Plugin.5GKyYzF8af));
						array8[*(&Plugin.lc03cnGSzJ)] = (uint)(*(&Plugin.x0ghtxDB5x));
						array8[*(&Plugin.2p0u1OPe1V) + *(&Plugin.q7Uxaol0jn)] = (uint)(*(&Plugin.TnzjhFjnFl) + *(&Plugin.vECnm6lGBO));
						uint num22 = num7 & array8[*(&Plugin.XmadczftHE)];
						uint num23 = num22 | array8[*(&Plugin.LNbRePzQMw)];
						num6 = (num23 - array8[*(&Plugin.plZQkm5rLe)] ^ (uint)(*(&Plugin.CfyVQrMVHr) + *(&Plugin.j0gAahnvJW)));
						continue;
					}
					case 6U:
						num6 = 3053571819U;
						continue;
					case 7U:
						goto IL_556;
					case 8U:
					{
						int[] array9 = array2;
						int num24 = 3;
						int num15 = (array2[3] - -259 - 232) * -15;
						array9[num24] = (array2[3] ^ num15 ^ (1269966287 ^ num15));
						uint num25 = num7 | (uint)(*(&Plugin.jvGH3lxgSC));
						uint num26 = num25 & (uint)(*(&Plugin.YenRH2udB5));
						uint num27 = ((num26 ^ (uint)(*(&Plugin.dwaPSy21yU))) | (uint)(*(&Plugin.ZOmRah0lsO))) * (uint)(*(&Plugin.GfeDM8CxPp));
						num6 = ((num27 | (uint)(*(&Plugin.8XX6DxU0yE))) ^ (uint)(*(&Plugin.s5s7mK1V1k)));
						continue;
					}
					case 9U:
					{
						int num28 = 982;
						num6 = (((num28 != 982) ? 3113821820U : 2404509067U) ^ num7 * 2028493398U);
						continue;
					}
					case 10U:
						calli(System.Void(System.Boolean), array2[0], Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array2[1] ^ array2[2]) - array2[3]]);
						num6 = ((num7 ^ (uint)(*(&Plugin.BIvxy7SWDU) + *(&Plugin.vFmIWB1qOm))) - (uint)(*(&Plugin.N9wofLxgaB)) ^ (uint)(*(&Plugin.Gr5pozmkHG)) ^ (uint)(*(&Plugin.e8xeSnSjkk)));
						continue;
					}
					return;
				}
			}
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x00652A74 File Offset: 0x00650C74
		public unsafe void Start()
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			int num = 15;
			if ((*(&Plugin.JSaVxWkuQ8) ^ *(&Plugin.JSaVxWkuQ8)) != 0)
			{
				int[] array = new int[10];
				int[] array2 = new int[10];
				int num2;
				int num3;
				int num4;
				if (num2 > num2)
				{
					array2[num3 + 5 - num4] = num3 - -4;
					*(ref num3 + (IntPtr)num4) = num4;
					if (num2 > num2)
					{
						num4 = 405370617;
						num4 -= num3;
					}
					num2 = 9511113;
				}
				if (num3 > num3)
				{
					num3 = num4;
					num3 = (int)((ushort)num3);
					num4 = num2 - 237;
					num4 = num2 << 4;
					num2 = array[num2 + 9 - num3] + 5;
					if (num2 > num2)
					{
						num2 = num2;
						num3 = *(ref Plugin.iP87Nyibfe + (IntPtr)num4);
						num3 = *(ref Plugin.iP87Nyibfe + (IntPtr)num2);
						num4 = num3;
					}
				}
				num3 = ~num4;
				array[num4 + 5 - num3] = (num3 | -1);
				num2 = num3 + 788;
				num4 = (num3 ^ 860972786);
				if (num4 > num4)
				{
					num2 = -num4;
				}
				num2 = num4 - num3;
				num2 |= 2048469032;
				num4 = *(ref num3 + (IntPtr)num4);
				num4 = (num2 ^ 1791976108);
				array[num3 + 8 - num2] = (num2 | -10);
				num2 = ~num3;
				num4 *= num3;
				num3 = -num4;
				num4 = array[num3 + 6 - num2] + 4;
				num2 = ~num3;
				num4 = (array[num3 + 9 - num3] ^ -4);
				num4 = num3 % 257;
				num3 = num4;
				num3 = num2;
				*(ref Plugin.iP87Nyibfe + (IntPtr)num2) = num2;
				if (num4 > num4)
				{
					num3 = num4;
					num2 = num4 >> 5;
					num4 = num3 / num4;
				}
				num2 = (array[num3 + 9 - num4] ^ 9);
				if (num2 > num2)
				{
					if (num3 > num3)
					{
						num3 = (num2 & num4);
						num2 >>= 5;
						num4 += num3;
						num2 = (num3 ^ 2117695314);
					}
					if (num4 > num4)
					{
						num2 = *(ref num3 + (IntPtr)num4);
						num3 = num4 - 274;
						num4 = array2[num4 + 9 - num4] + 1;
						num4 = num3;
						*(ref num3 + (IntPtr)num4) = num4;
						array[num3 + 5 - num4] = num2 - 5;
						num2 = -num3;
						num4 = ~num4;
					}
					num4 = num2 + num4;
					num2 = num3 * 704;
					num3 = num4 - 203;
					if (num4 > num4)
					{
						*(ref num2 + (IntPtr)num4) = num4;
						*(ref num4 + (IntPtr)num3) = num3;
						num4 = num2 - num4;
						num4 >>= 3;
						num2 = (num3 & 880790696);
						num2 = (int)((byte)num3);
					}
					num3 /= 100;
				}
				num3 = num4 % 202;
				array[num3 + 5 - num3] = num2 - 4;
				num3 = num3;
				if (num2 > num2)
				{
					num4 = (array[num3 + 5 - num4] ^ -5);
					num3 = (num2 | 1210498681);
					num4 = num3 + 598;
					num4 = (num2 ^ num4);
					Plugin.iP87Nyibfe = num3;
					num4 = -num3;
					num2 = (int)((byte)num3);
				}
				num2 = Plugin.iP87Nyibfe;
				num3 = array2[num4 + 6 - num4] + -6;
				array2[num4 + 6 - num4] = (num3 | -3);
				if (num2 > num2)
				{
					num3 = (num2 | num4);
					if (num3 > num3)
					{
						num4 = *(ref Plugin.iP87Nyibfe + (IntPtr)num2);
						num4 = num2 + 684;
						num4 = num2;
						num4 >>= 4;
						num4 = (int)((ushort)num4);
						num2 = (num3 ^ num4);
						num4 = Plugin.iP87Nyibfe;
						num3 = Plugin.iP87Nyibfe;
						*(ref Plugin.iP87Nyibfe + (IntPtr)num3) = num3;
					}
					num4 = *(ref Plugin.iP87Nyibfe + (IntPtr)num4);
				}
				num2 = Plugin.iP87Nyibfe;
				if (num2 > num2)
				{
					num4 = (int)((ushort)num2);
					num4 = (num3 & num4);
				}
				num3 *= 108;
				num2 = num4 >> 3;
				num2 = num3;
				num3 = num2 >> 7;
				num3 = *(ref num4 + (IntPtr)num3);
				num3 = -num3;
				num4 = 1138976806;
				array2[num2 + 5 - num4] = (num3 | 8);
			}
			int[] array3 = new int[num];
			int num5 = 613;
			for (;;)
			{
				IL_3AA:
				uint num6 = 3348533491U;
				for (;;)
				{
					uint num7;
					switch ((num7 = (num6 ^ (uint)(*(&Plugin.TLHOWBVGRn)))) % (uint)(*(&Plugin.Jv5BOEJ7eg) + *(&Plugin.ZQiHIPMSV2)))
					{
					case 1U:
						num6 = 3227087027U;
						continue;
					case 2U:
					{
						int[] array4 = array3;
						int num8 = 1;
						int num9 = ((array3[1] >> 6 << 5) + 15) % 45 - 402;
						array4[num8] = (array3[1] ^ num9 ^ (2137271439 ^ num9));
						uint num10 = ((num7 | (uint)(*(&Plugin.tGPiMlwdSm) + *(&Plugin.hHql6j3QHX))) & (uint)(*(&Plugin.xe1jsKAbLE))) | (uint)(*(&Plugin.zVtl4Umpaw));
						num6 = (num10 * (uint)(*(&Plugin.EotWvASlum)) * (uint)(*(&Plugin.J3thwOOp0C)) ^ (uint)(*(&Plugin.lVRNxMXFrl) + *(&Plugin.6N0UTJvfys)));
						continue;
					}
					case 3U:
					{
						array3[0] = 724534030;
						uint num11 = (num7 | (uint)(*(&Plugin.2O50s4krSm))) + (uint)(*(&Plugin.dfSd6tCvPN));
						uint num12 = num11 & (uint)(*(&Plugin.dVFEKCm9GH) + *(&Plugin.zDuYu5zFSU));
						uint num13 = num12 * (uint)(*(&Plugin.eco1D48ELY));
						num6 = ((num13 | (uint)(*(&Plugin.MaDIYgI1pq))) ^ (uint)(*(&Plugin.RkkLwau3tB)));
						continue;
					}
					case 4U:
						goto IL_3AA;
					case 5U:
					{
						array3[1] = 457218591;
						array3[2] = 1326135858;
						uint num14 = num7 + (uint)(*(&Plugin.36c5tBrNAQ));
						uint num15 = num14 ^ (uint)(*(&Plugin.Ehyr4Y9mAN));
						num6 = (num15 ^ (uint)(*(&Plugin.w8amC31dEm)) ^ (uint)(*(&Plugin.KEVJfQ7IYW)));
						continue;
					}
					case 6U:
						num6 = (((num5 != 613) ? 869998397U : 703492556U) ^ num7 * 1838499793U);
						continue;
					case 7U:
					{
						int[] array5 = array3;
						int num16 = 2;
						int num9 = -(-(~array3[2] + -189));
						array5[num16] = (array3[2] ^ num9 ^ (2137271439 ^ num9));
						uint[] array6 = new uint[*(&Plugin.2Zri45mMyp)];
						array6[*(&Plugin.F6yYLsWfij)] = (uint)(*(&Plugin.mN3Iq5DYNn));
						array6[*(&Plugin.dt0IJLnsT1)] = (uint)(*(&Plugin.jLQBgAZbJk));
						array6[*(&Plugin.wP6PFofi29)] = (uint)(*(&Plugin.2N8KMWGqO9));
						array6[*(&Plugin.FoMr9b62mq)] = (uint)(*(&Plugin.flOn0OxkCe));
						uint num17 = num7 * array6[*(&Plugin.pEzT9WMFzJ)];
						uint num18 = num17 ^ (uint)(*(&Plugin.3tNKfIDPQo));
						num6 = ((num18 | (uint)(*(&Plugin.sn6MdQ8UU8))) + array6[*(&Plugin.ifntTAz2rn)] ^ (uint)(*(&Plugin.O0CcwwYEIs)));
						continue;
					}
					case 8U:
					{
						int[] array7 = array3;
						int num19 = 0;
						int num9 = array3[0] + -279 & -293;
						array7[num19] = (array3[0] ^ num9 ^ (2137271439 ^ num9));
						uint num20 = (num7 | (uint)(*(&Plugin.z51Ymtw2QX))) + (uint)(*(&Plugin.aH3fO4g02z));
						uint num21 = num20 & (uint)(*(&Plugin.JNIXG9MoMo));
						num6 = (num21 - (uint)(*(&Plugin.b1OnY1HB9S)) ^ (uint)(*(&Plugin.H9NqMCK04k)));
						continue;
					}
					}
					goto Block_16;
				}
			}
			Block_16:
			calli(System.Void(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array3[0] ^ array3[1]) - array3[2]]);
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x006530CC File Offset: 0x006512CC
		public unsafe void Update()
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			int num = 15;
			if ((*(&Plugin.0U6Y3yiblT) ^ *(&Plugin.0U6Y3yiblT)) != 0)
			{
				int[] array = new int[10];
				int[] array2 = new int[10];
				int num2;
				int num4;
				int num3;
				int num5;
				int num6;
				if (num2 > num2)
				{
					num3 = array[num4 + 6 - num2] + 7;
					num2 = -num5;
					if (num2 > num2)
					{
						num2 ^= num3;
						num2 = Plugin.iP87Nyibfe;
						num5 = -num6;
						array2[num5 + 6 - num2] = num4 - -4;
					}
					if (num3 > num3)
					{
						num5 = num3 / num6;
						num4 = (int)((ushort)num6);
						num5 = Plugin.iP87Nyibfe;
						num2 = (num5 ^ num3);
						num4 += num3;
					}
					num4 = num3;
				}
				num2 = (num3 ^ 50449209);
				num6 = num4 + 418;
				num3 = num2 << 7;
				num2 = (num5 | 663059628);
				if (num6 > num6)
				{
					num4 = num2 << 7;
					num6 = *(ref Plugin.iP87Nyibfe + (IntPtr)num4);
					num4 = 1152856487;
					num4 = num2 * num3;
				}
				num3 = ~num4;
				num3 = num2 / num3;
				if (num6 > num6)
				{
					num4 = num5;
				}
				num4 = ~num4;
				num4 = num2 - 765;
				num6 = (num2 & num3);
				num5 = num3;
				num3 = *(ref Plugin.iP87Nyibfe + (IntPtr)num5);
				*(ref Plugin.iP87Nyibfe + (IntPtr)num2) = num2;
				num4 = num6 - num3;
				num3 = num4 - 668;
				num6 >>= 6;
				array[num5 + 5 - num3] = num5 - -4;
				num6 = (num3 ^ num6);
				num2 = (num5 ^ 576910279);
				num3 ^= 1235008949;
				num5 = *(ref num5 + (IntPtr)num3);
				num5 = (num3 | 1132513476);
				if (num4 > num4)
				{
					num5 = array[num4 + 7 - num3] + -3;
					num3 &= num6;
					*(ref num4 + (IntPtr)num3) = num3;
				}
				num3 = -num3;
				num4 = (num3 & 894042068);
				Plugin.iP87Nyibfe = num3;
				if (num3 > num3)
				{
					num2 = (num3 | 50447110);
					num6 = ~num5;
					if (num4 > num4)
					{
						num4 = num5 / num3;
					}
				}
				num3 = -num3;
				num2 = ~num3;
			}
			int[] array3 = new int[num];
			for (;;)
			{
				IL_208:
				uint num7 = 2753422580U;
				for (;;)
				{
					uint num8;
					switch ((num8 = (num7 ^ (uint)(*(&Plugin.KiUYwCImzt)))) % (uint)(*(&Plugin.X1v1kYFd1f) + *(&Plugin.TKhna1keaq)))
					{
					case 1U:
					{
						int num9 = 463;
						num7 = (((num9 == 463) ? 2594526572U : 3632771820U) ^ num8 * 3869252799U);
						continue;
					}
					case 2U:
					{
						int[] array4 = array3;
						int num10 = 0;
						int num11 = array3[0] * -114 - 317;
						int num12 = ((-183 == 0) ? (num11 - 78) : (num11 + -183)) - -448;
						int num13 = (-160 == 0) ? (num12 - 38) : (num12 + -160);
						array4[num10] = (array3[0] ^ num13 ^ (1226854147 ^ num13));
						int[] array5 = array3;
						int num14 = 1;
						num13 = (array3[1] << 7 ^ -351);
						array5[num14] = (array3[1] ^ num13 ^ (1226854147 ^ num13));
						num7 = 3127140753U;
						continue;
					}
					case 3U:
					{
						int[] array6 = array3;
						int num15 = 2;
						int num13 = (array3[2] + 360 << 1 ^ 203) % 27 * -258;
						array6[num15] = (array3[2] ^ num13 ^ (1226854147 ^ num13));
						uint num16 = num8 ^ (uint)(*(&Plugin.NsCzdVBuIn));
						num7 = (((num16 ^ (uint)(*(&Plugin.ieVLZGZDCo) + *(&Plugin.krXZl387px))) & (uint)(*(&Plugin.ZUms92b7Em))) ^ (uint)(*(&Plugin.g2lOpnlRRt)));
						continue;
					}
					case 4U:
						goto IL_208;
					case 5U:
					{
						array3[0] = 1775540079;
						array3[1] = 56469760;
						array3[2] = 598307604;
						uint[] array7 = new uint[*(&Plugin.24MlxAKP7Q)];
						array7[*(&Plugin.1MD8PWFL1X)] = (uint)(*(&Plugin.r4NmZAAr85));
						array7[*(&Plugin.cnLI1doJEk)] = (uint)(*(&Plugin.N0gknGHjYD));
						array7[*(&Plugin.vYmD97qjMw)] = (uint)(*(&Plugin.AdRByOA4Gv));
						array7[*(&Plugin.r6HRJ0Xn9S) + *(&Plugin.3bT4JDBIJ3)] = (uint)(*(&Plugin.xF6RjujevZ));
						array7[*(&Plugin.FNcmVzRV3I)] = (uint)(*(&Plugin.jDk43jKW2u));
						uint num17 = (num8 ^ (uint)(*(&Plugin.M2uM8m90rZ))) + array7[*(&Plugin.R31kMq8qiT)];
						uint num18 = num17 - array7[*(&Plugin.wpPAUueCYA)] + array7[*(&Plugin.jNmAMNcQot)];
						num7 = (num18 ^ array7[*(&Plugin.0aoe1qLArN)] ^ (uint)(*(&Plugin.ldxi8hmu2O) + *(&Plugin.H6cqzEQ0X9)));
						continue;
					}
					case 6U:
						num7 = 3866517178U;
						continue;
					}
					goto Block_10;
				}
			}
			Block_10:
			calli(System.Void(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array3[0] ^ array3[1]) - array3[2]]);
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x0065351C File Offset: 0x0065171C
		public unsafe Plugin()
		{
			if ((*(&Plugin.l5zhZctHRl) ^ *(&Plugin.l5zhZctHRl)) != 0)
			{
				int[] array = new int[10];
				int num2;
				int num = num2 << 6;
				int num3;
				num2 = num3;
				num = num2;
				array[num2 + 7 - num2] = (num3 | 1);
				if (num3 > num3)
				{
					num3 = num2;
					array[num + 5 - num2] = num2 - -1;
					array[num3 + 9 - num2] = num - -5;
					num2 = (int)((short)num);
				}
				num3 = num;
				num2 = (num & num3);
				num2 = (int)((sbyte)num);
				num = *(ref num2 + (IntPtr)num3);
				num = array[num + 5 - num] + -8;
				num = num2 << 7;
				num3 = num - 502;
				num = -num2;
				num3 = (array[num + 7 - num2] ^ -3);
				num3 = num3;
				num2 *= 593;
				num3 *= num2;
				num2 = num3;
				num3 = num << 4;
				if (num3 > num3)
				{
					num3 = (array[num + 6 - num3] ^ 3);
					num = (int)((ushort)num2);
					if (num2 > num2)
					{
						num = (int)((byte)num3);
						num3 = num2 * 527;
					}
					num3 = array[num + 9 - num] + 7;
					num3 = ~num;
					if (num2 > num2)
					{
						num2 = -num;
						array[num3 + 6 - num3] = num2 - -7;
						num2 = num3 << 2;
						num3 &= num2;
						num = *(ref num2 + (IntPtr)num3);
						num *= 22;
						num2 += 361;
						num3 = 599442222;
						num3 = num << 6;
					}
					num -= num3;
					num3 = num2 / 539;
				}
				if (num3 > num3)
				{
					num3 = (int)((byte)num2);
					*(ref num3 + (IntPtr)num2) = num2;
					num2 %= num3;
					num3 = (int)((sbyte)num3);
					num2 = num;
					num3 = (num | 426693585);
					num2 = Plugin.iP87Nyibfe;
					num2 = num3 + num2;
					num3 = (num2 | num3);
				}
				array[num2 + 9 - num2] = num2 - 8;
				num2 = (num | 1504245138);
				*(ref num + (IntPtr)num3) = num3;
				if (num3 > num3)
				{
					num = num3;
					array[num3 + 9 - num3] = (num3 | 9);
					*(ref Plugin.iP87Nyibfe + (IntPtr)num2) = num2;
					num3 <<= 2;
					if (num > num)
					{
						num3 = num3;
						array[num2 + 7 - num] = num2 - 6;
						num = (num2 & num3);
						num3 = Plugin.iP87Nyibfe;
						num2 = ~num3;
					}
					if (num2 > num2)
					{
						num = num;
						num2 += 223;
						array[num3 + 6 - num2] = (num | 4);
						array[num3 + 9 - num] = (num | -10);
						num3 = (int)((short)num2);
						array[num3 + 7 - num3] = (num | 9);
					}
					array[num2 + 6 - num] = num - -10;
					num2 = ~num2;
				}
				num3 = num % num3;
				num3 = (num | num3);
				num2 = array[num3 + 7 - num] + -4;
				num3 = *(ref Plugin.iP87Nyibfe + (IntPtr)num2);
				*(ref Plugin.iP87Nyibfe + (IntPtr)num) = num;
				num = (int)((ushort)num2);
				num = num2 % num3;
				array[num + 6 - num2] = num3 - -7;
			}
			base..ctor();
		}

		// Token: 0x0404FCA2 RID: 326818 RVA: 0x0014AFF0 File Offset: 0x001491F0
		static int Fi1vAp3lsS;

		// Token: 0x0404FCA3 RID: 326819 RVA: 0x0014AFF8 File Offset: 0x001491F8
		static int iP87Nyibfe;

		// Token: 0x0404FCA4 RID: 326820 RVA: 0x0014B000 File Offset: 0x00149200
		static int jmztdY8jJN;

		// Token: 0x0404FCA5 RID: 326821 RVA: 0x0014B008 File Offset: 0x00149208
		static int JSaVxWkuQ8;

		// Token: 0x0404FCA6 RID: 326822 RVA: 0x0014B010 File Offset: 0x00149210
		static int 0U6Y3yiblT;

		// Token: 0x0404FCA7 RID: 326823 RVA: 0x0014B018 File Offset: 0x00149218
		static int l5zhZctHRl;

		// Token: 0x0404FCA8 RID: 326824 RVA: 0x0014B020 File Offset: 0x00149220
		static readonly int vszYykqsUw;

		// Token: 0x0404FCA9 RID: 326825 RVA: 0x0001E440 File Offset: 0x0001C640
		static readonly int C5ZODQX2vN;

		// Token: 0x0404FCAA RID: 326826 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 5ChXvGp9RK;

		// Token: 0x0404FCAB RID: 326827 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int SUnYvg3vH6;

		// Token: 0x0404FCAC RID: 326828 RVA: 0x0014B028 File Offset: 0x00149228
		static readonly int qSmZV4dgMg;

		// Token: 0x0404FCAD RID: 326829 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int megWXtKbms;

		// Token: 0x0404FCAE RID: 326830 RVA: 0x0014B030 File Offset: 0x00149230
		static readonly int 5raJerSBcg;

		// Token: 0x0404FCAF RID: 326831 RVA: 0x0014B038 File Offset: 0x00149238
		static readonly int XlvygnZHC0;

		// Token: 0x0404FCB0 RID: 326832 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int mIwviyxQBC;

		// Token: 0x0404FCB1 RID: 326833 RVA: 0x0014B040 File Offset: 0x00149240
		static readonly int WbJZB81c5n;

		// Token: 0x0404FCB2 RID: 326834 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int mcEpIAsr0t;

		// Token: 0x0404FCB3 RID: 326835 RVA: 0x0014B048 File Offset: 0x00149248
		static readonly int UCZwFx5plp;

		// Token: 0x0404FCB4 RID: 326836 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 4BAZK6cWxh;

		// Token: 0x0404FCB5 RID: 326837 RVA: 0x0014B050 File Offset: 0x00149250
		static readonly int w6MYOKDHmh;

		// Token: 0x0404FCB6 RID: 326838 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int FGaRsTBWTN;

		// Token: 0x0404FCB7 RID: 326839 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int DL1PtlbpeM;

		// Token: 0x0404FCB8 RID: 326840 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int iW3S7X0Bh4;

		// Token: 0x0404FCB9 RID: 326841 RVA: 0x0014B058 File Offset: 0x00149258
		static readonly int txCEkxksr0;

		// Token: 0x0404FCBA RID: 326842 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 5FCjdkF6pm;

		// Token: 0x0404FCBB RID: 326843 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sYma8tMITU;

		// Token: 0x0404FCBC RID: 326844 RVA: 0x0014B060 File Offset: 0x00149260
		static readonly int dAyZeQIxp5;

		// Token: 0x0404FCBD RID: 326845 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int At7nQdTTyX;

		// Token: 0x0404FCBE RID: 326846 RVA: 0x0014B068 File Offset: 0x00149268
		static readonly int S4V5LVKmF1;

		// Token: 0x0404FCBF RID: 326847 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int lbZWX4QnFN;

		// Token: 0x0404FCC0 RID: 326848 RVA: 0x0014B070 File Offset: 0x00149270
		static readonly int bSQtm9a9Jf;

		// Token: 0x0404FCC1 RID: 326849 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Z2U6Cjo3NI;

		// Token: 0x0404FCC2 RID: 326850 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int FgryUiTlQW;

		// Token: 0x0404FCC3 RID: 326851 RVA: 0x0014B078 File Offset: 0x00149278
		static readonly int MqNk5AnlSL;

		// Token: 0x0404FCC4 RID: 326852 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 5LcjbsHdTx;

		// Token: 0x0404FCC5 RID: 326853 RVA: 0x0014B080 File Offset: 0x00149280
		static readonly int QWZ7I5kcZD;

		// Token: 0x0404FCC6 RID: 326854 RVA: 0x0014B088 File Offset: 0x00149288
		static readonly int qysxStotAC;

		// Token: 0x0404FCC7 RID: 326855 RVA: 0x0014B060 File Offset: 0x00149260
		static readonly int 6ClCN4DIWm;

		// Token: 0x0404FCC8 RID: 326856 RVA: 0x0014B090 File Offset: 0x00149290
		static readonly int b0RdF0RQcA;

		// Token: 0x0404FCC9 RID: 326857 RVA: 0x0014B098 File Offset: 0x00149298
		static readonly int ZKMPfGdpQs;

		// Token: 0x0404FCCA RID: 326858 RVA: 0x0014B070 File Offset: 0x00149270
		static readonly int DXcR0NvXuO;

		// Token: 0x0404FCCB RID: 326859 RVA: 0x0014B078 File Offset: 0x00149278
		static readonly int 1cGxlzhOrc;

		// Token: 0x0404FCCC RID: 326860 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int bYR9mv0VgG;

		// Token: 0x0404FCCD RID: 326861 RVA: 0x0014B0A0 File Offset: 0x001492A0
		static readonly int aY1niDXAm2;

		// Token: 0x0404FCCE RID: 326862 RVA: 0x0014B0A8 File Offset: 0x001492A8
		static readonly int F4gOJ7EYnp;

		// Token: 0x0404FCCF RID: 326863 RVA: 0x0014B0B0 File Offset: 0x001492B0
		static readonly int jO7yQoGcpE;

		// Token: 0x0404FCD0 RID: 326864 RVA: 0x0014B0B8 File Offset: 0x001492B8
		static readonly int XZ0oxdkcOi;

		// Token: 0x0404FCD1 RID: 326865 RVA: 0x0014B0C0 File Offset: 0x001492C0
		static readonly int cgmzXh2C0o;

		// Token: 0x0404FCD2 RID: 326866 RVA: 0x0014B0C8 File Offset: 0x001492C8
		static readonly int rbs1gLaDW3;

		// Token: 0x0404FCD3 RID: 326867 RVA: 0x0014B0D0 File Offset: 0x001492D0
		static readonly int 74VhfpD2bq;

		// Token: 0x0404FCD4 RID: 326868 RVA: 0x0014B0D8 File Offset: 0x001492D8
		static readonly int WlKFNCmHat;

		// Token: 0x0404FCD5 RID: 326869 RVA: 0x0014B0E0 File Offset: 0x001492E0
		static readonly int wDmAX5r9Hl;

		// Token: 0x0404FCD6 RID: 326870 RVA: 0x0014B0E8 File Offset: 0x001492E8
		static readonly int ChGUkhLEUr;

		// Token: 0x0404FCD7 RID: 326871 RVA: 0x0014B0F0 File Offset: 0x001492F0
		static readonly int dAlKSGRmne;

		// Token: 0x0404FCD8 RID: 326872 RVA: 0x0014B0F8 File Offset: 0x001492F8
		static readonly int jTmnH4SVKj;

		// Token: 0x0404FCD9 RID: 326873 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 8Euzoyfzfq;

		// Token: 0x0404FCDA RID: 326874 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 0ixtPwbbrR;

		// Token: 0x0404FCDB RID: 326875 RVA: 0x0014B100 File Offset: 0x00149300
		static readonly int oEVnCt5cNq;

		// Token: 0x0404FCDC RID: 326876 RVA: 0x0014B108 File Offset: 0x00149308
		static readonly int O03utYPwgd;

		// Token: 0x0404FCDD RID: 326877 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kbH7nAf3XU;

		// Token: 0x0404FCDE RID: 326878 RVA: 0x0014B110 File Offset: 0x00149310
		static readonly int d1n353tHx4;

		// Token: 0x0404FCDF RID: 326879 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 2CmybAoD91;

		// Token: 0x0404FCE0 RID: 326880 RVA: 0x0014B118 File Offset: 0x00149318
		static readonly int hp5OqM7YAB;

		// Token: 0x0404FCE1 RID: 326881 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int NCF2NXNAyz;

		// Token: 0x0404FCE2 RID: 326882 RVA: 0x0014B110 File Offset: 0x00149310
		static readonly int pH8lkizSfn;

		// Token: 0x0404FCE3 RID: 326883 RVA: 0x0014B118 File Offset: 0x00149318
		static readonly int Wb3gxx5ZNt;

		// Token: 0x0404FCE4 RID: 326884 RVA: 0x0014B120 File Offset: 0x00149320
		static readonly int 6UHwr07tlE;

		// Token: 0x0404FCE5 RID: 326885 RVA: 0x0014B128 File Offset: 0x00149328
		static readonly int wnPJLZqTnI;

		// Token: 0x0404FCE6 RID: 326886 RVA: 0x0014B130 File Offset: 0x00149330
		static readonly int Xo3WpwJjEZ;

		// Token: 0x0404FCE7 RID: 326887 RVA: 0x0014B138 File Offset: 0x00149338
		static readonly int byxF3VAM4u;

		// Token: 0x0404FCE8 RID: 326888 RVA: 0x0014B140 File Offset: 0x00149340
		static readonly int kFqa0sMtUY;

		// Token: 0x0404FCE9 RID: 326889 RVA: 0x0014B148 File Offset: 0x00149348
		static readonly int HmvEWRbuG4;

		// Token: 0x0404FCEA RID: 326890 RVA: 0x0014B150 File Offset: 0x00149350
		static readonly int qXpMn80JP0;

		// Token: 0x0404FCEB RID: 326891 RVA: 0x0014B158 File Offset: 0x00149358
		static readonly int YdZ2hR8cg6;

		// Token: 0x0404FCEC RID: 326892 RVA: 0x0014B160 File Offset: 0x00149360
		static readonly int kaOpRzCstm;

		// Token: 0x0404FCED RID: 326893 RVA: 0x0014B168 File Offset: 0x00149368
		static readonly int 3PF9DMadx1;

		// Token: 0x0404FCEE RID: 326894 RVA: 0x0014B170 File Offset: 0x00149370
		static readonly int 1Cde9nM2hE;

		// Token: 0x0404FCEF RID: 326895 RVA: 0x0014B178 File Offset: 0x00149378
		static readonly int S8OKUQJ94x;

		// Token: 0x0404FCF0 RID: 326896 RVA: 0x0014B180 File Offset: 0x00149380
		static readonly int 6Han6JYZzU;

		// Token: 0x0404FCF1 RID: 326897 RVA: 0x0014B188 File Offset: 0x00149388
		static readonly int 1eooFh6tpo;

		// Token: 0x0404FCF2 RID: 326898 RVA: 0x0014B190 File Offset: 0x00149390
		static readonly int mJLoT5B5pw;

		// Token: 0x0404FCF3 RID: 326899 RVA: 0x00031090 File Offset: 0x0002F290
		static readonly int DaiA5um0i0;

		// Token: 0x0404FCF4 RID: 326900 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int PxDMNyTjFw;

		// Token: 0x0404FCF5 RID: 326901 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int UaTQKw6vTB;

		// Token: 0x0404FCF6 RID: 326902 RVA: 0x0014B198 File Offset: 0x00149398
		static readonly int HctCRa5osU;

		// Token: 0x0404FCF7 RID: 326903 RVA: 0x0014B1A0 File Offset: 0x001493A0
		static readonly int 5GKyYzF8af;

		// Token: 0x0404FCF8 RID: 326904 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lc03cnGSzJ;

		// Token: 0x0404FCF9 RID: 326905 RVA: 0x0014B1A8 File Offset: 0x001493A8
		static readonly int x0ghtxDB5x;

		// Token: 0x0404FCFA RID: 326906 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2p0u1OPe1V;

		// Token: 0x0404FCFB RID: 326907 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int q7Uxaol0jn;

		// Token: 0x0404FCFC RID: 326908 RVA: 0x0014B1B0 File Offset: 0x001493B0
		static readonly int TnzjhFjnFl;

		// Token: 0x0404FCFD RID: 326909 RVA: 0x0014B1B8 File Offset: 0x001493B8
		static readonly int vECnm6lGBO;

		// Token: 0x0404FCFE RID: 326910 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int XmadczftHE;

		// Token: 0x0404FCFF RID: 326911 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int LNbRePzQMw;

		// Token: 0x0404FD00 RID: 326912 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int plZQkm5rLe;

		// Token: 0x0404FD01 RID: 326913 RVA: 0x0014B1C0 File Offset: 0x001493C0
		static readonly int CfyVQrMVHr;

		// Token: 0x0404FD02 RID: 326914 RVA: 0x0014B1C8 File Offset: 0x001493C8
		static readonly int j0gAahnvJW;

		// Token: 0x0404FD03 RID: 326915 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int GV3PjwMJ30;

		// Token: 0x0404FD04 RID: 326916 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 4yhnBqYFBw;

		// Token: 0x0404FD05 RID: 326917 RVA: 0x0014B1D0 File Offset: 0x001493D0
		static readonly int CdJfMyFZ0C;

		// Token: 0x0404FD06 RID: 326918 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9KhyXrliwe;

		// Token: 0x0404FD07 RID: 326919 RVA: 0x0014B1D8 File Offset: 0x001493D8
		static readonly int eDcRwvS38t;

		// Token: 0x0404FD08 RID: 326920 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int JhtWUmLYDu;

		// Token: 0x0404FD09 RID: 326921 RVA: 0x0014B1E0 File Offset: 0x001493E0
		static readonly int qxT10uQtPT;

		// Token: 0x0404FD0A RID: 326922 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int E0ThR9B2sb;

		// Token: 0x0404FD0B RID: 326923 RVA: 0x0014B1E8 File Offset: 0x001493E8
		static readonly int gMaG3caLev;

		// Token: 0x0404FD0C RID: 326924 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int gNfBxrtlaC;

		// Token: 0x0404FD0D RID: 326925 RVA: 0x0014B1D8 File Offset: 0x001493D8
		static readonly int ejoopSNLEU;

		// Token: 0x0404FD0E RID: 326926 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int kSplNeWM7Y;

		// Token: 0x0404FD0F RID: 326927 RVA: 0x0014B1E8 File Offset: 0x001493E8
		static readonly int TFOdx0URuk;

		// Token: 0x0404FD10 RID: 326928 RVA: 0x0014B1F0 File Offset: 0x001493F0
		static readonly int Qacq66ivak;

		// Token: 0x0404FD11 RID: 326929 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int OOGKKNi3yS;

		// Token: 0x0404FD12 RID: 326930 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int UgnBsZVK1z;

		// Token: 0x0404FD13 RID: 326931 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 85beEK09pQ;

		// Token: 0x0404FD14 RID: 326932 RVA: 0x0014B1F8 File Offset: 0x001493F8
		static readonly int 6kvXJE8ETj;

		// Token: 0x0404FD15 RID: 326933 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int SbdbPtxa7g;

		// Token: 0x0404FD16 RID: 326934 RVA: 0x0014B200 File Offset: 0x00149400
		static readonly int lY4lmTxlGA;

		// Token: 0x0404FD17 RID: 326935 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int XjOhWuvQ2n;

		// Token: 0x0404FD18 RID: 326936 RVA: 0x0014B208 File Offset: 0x00149408
		static readonly int aR0SghbAPU;

		// Token: 0x0404FD19 RID: 326937 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int WZBIoiqJuz;

		// Token: 0x0404FD1A RID: 326938 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int RX7SLtM6Ef;

		// Token: 0x0404FD1B RID: 326939 RVA: 0x0014B210 File Offset: 0x00149410
		static readonly int 8hiUGUhmEF;

		// Token: 0x0404FD1C RID: 326940 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 2wVvn7hG2y;

		// Token: 0x0404FD1D RID: 326941 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DlfCWDTiGx;

		// Token: 0x0404FD1E RID: 326942 RVA: 0x0014B218 File Offset: 0x00149418
		static readonly int Ue5uWz1rCU;

		// Token: 0x0404FD1F RID: 326943 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int AEEp7eBLoO;

		// Token: 0x0404FD20 RID: 326944 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int LFEQbXCf7C;

		// Token: 0x0404FD21 RID: 326945 RVA: 0x0014B220 File Offset: 0x00149420
		static readonly int B9fRuX1lZy;

		// Token: 0x0404FD22 RID: 326946 RVA: 0x0014B228 File Offset: 0x00149428
		static readonly int G0Eix9gzE1;

		// Token: 0x0404FD23 RID: 326947 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int CH32mOapT9;

		// Token: 0x0404FD24 RID: 326948 RVA: 0x0014B200 File Offset: 0x00149400
		static readonly int xVt9SBix4k;

		// Token: 0x0404FD25 RID: 326949 RVA: 0x0014B208 File Offset: 0x00149408
		static readonly int nZwzIUBgdc;

		// Token: 0x0404FD26 RID: 326950 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 0MbGA3Fnog;

		// Token: 0x0404FD27 RID: 326951 RVA: 0x0014B218 File Offset: 0x00149418
		static readonly int 6LSZBuHEPv;

		// Token: 0x0404FD28 RID: 326952 RVA: 0x0014B230 File Offset: 0x00149430
		static readonly int as5eNmUDuR;

		// Token: 0x0404FD29 RID: 326953 RVA: 0x0014B238 File Offset: 0x00149438
		static readonly int N4M0Ik4m9Y;

		// Token: 0x0404FD2A RID: 326954 RVA: 0x0014B240 File Offset: 0x00149440
		static readonly int 65JYncHWyX;

		// Token: 0x0404FD2B RID: 326955 RVA: 0x0014B248 File Offset: 0x00149448
		static readonly int N6QrCIR73X;

		// Token: 0x0404FD2C RID: 326956 RVA: 0x0014B250 File Offset: 0x00149450
		static readonly int jC3WSC9bRb;

		// Token: 0x0404FD2D RID: 326957 RVA: 0x0014B258 File Offset: 0x00149458
		static readonly int zeF1zfjg0v;

		// Token: 0x0404FD2E RID: 326958 RVA: 0x0014B260 File Offset: 0x00149460
		static readonly int e8PWEQney9;

		// Token: 0x0404FD2F RID: 326959 RVA: 0x0014B268 File Offset: 0x00149468
		static readonly int T7tlz3CwFk;

		// Token: 0x0404FD30 RID: 326960 RVA: 0x0014B270 File Offset: 0x00149470
		static readonly int cpFXit1Z2g;

		// Token: 0x0404FD31 RID: 326961 RVA: 0x0014B278 File Offset: 0x00149478
		static readonly int jvGH3lxgSC;

		// Token: 0x0404FD32 RID: 326962 RVA: 0x0014B280 File Offset: 0x00149480
		static readonly int YenRH2udB5;

		// Token: 0x0404FD33 RID: 326963 RVA: 0x0014B288 File Offset: 0x00149488
		static readonly int dwaPSy21yU;

		// Token: 0x0404FD34 RID: 326964 RVA: 0x0014B290 File Offset: 0x00149490
		static readonly int ZOmRah0lsO;

		// Token: 0x0404FD35 RID: 326965 RVA: 0x0014B298 File Offset: 0x00149498
		static readonly int GfeDM8CxPp;

		// Token: 0x0404FD36 RID: 326966 RVA: 0x0014B2A0 File Offset: 0x001494A0
		static readonly int 8XX6DxU0yE;

		// Token: 0x0404FD37 RID: 326967 RVA: 0x0014B2A8 File Offset: 0x001494A8
		static readonly int s5s7mK1V1k;

		// Token: 0x0404FD38 RID: 326968 RVA: 0x0014B2B0 File Offset: 0x001494B0
		static readonly int BIvxy7SWDU;

		// Token: 0x0404FD39 RID: 326969 RVA: 0x0014B2B8 File Offset: 0x001494B8
		static readonly int vFmIWB1qOm;

		// Token: 0x0404FD3A RID: 326970 RVA: 0x0014B2C0 File Offset: 0x001494C0
		static readonly int N9wofLxgaB;

		// Token: 0x0404FD3B RID: 326971 RVA: 0x0014B2C8 File Offset: 0x001494C8
		static readonly int Gr5pozmkHG;

		// Token: 0x0404FD3C RID: 326972 RVA: 0x0014B2D0 File Offset: 0x001494D0
		static readonly int e8xeSnSjkk;

		// Token: 0x0404FD3D RID: 326973 RVA: 0x0014B2D8 File Offset: 0x001494D8
		static readonly int TLHOWBVGRn;

		// Token: 0x0404FD3E RID: 326974 RVA: 0x00024CA8 File Offset: 0x00022EA8
		static readonly int Jv5BOEJ7eg;

		// Token: 0x0404FD3F RID: 326975 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ZQiHIPMSV2;

		// Token: 0x0404FD40 RID: 326976 RVA: 0x0014B2E0 File Offset: 0x001494E0
		static readonly int 2O50s4krSm;

		// Token: 0x0404FD41 RID: 326977 RVA: 0x0014B2E8 File Offset: 0x001494E8
		static readonly int dfSd6tCvPN;

		// Token: 0x0404FD42 RID: 326978 RVA: 0x0014B2F0 File Offset: 0x001494F0
		static readonly int dVFEKCm9GH;

		// Token: 0x0404FD43 RID: 326979 RVA: 0x0014B2F8 File Offset: 0x001494F8
		static readonly int zDuYu5zFSU;

		// Token: 0x0404FD44 RID: 326980 RVA: 0x0014B300 File Offset: 0x00149500
		static readonly int eco1D48ELY;

		// Token: 0x0404FD45 RID: 326981 RVA: 0x0014B308 File Offset: 0x00149508
		static readonly int MaDIYgI1pq;

		// Token: 0x0404FD46 RID: 326982 RVA: 0x0014B310 File Offset: 0x00149510
		static readonly int RkkLwau3tB;

		// Token: 0x0404FD47 RID: 326983 RVA: 0x0014B318 File Offset: 0x00149518
		static readonly int 36c5tBrNAQ;

		// Token: 0x0404FD48 RID: 326984 RVA: 0x0014B320 File Offset: 0x00149520
		static readonly int Ehyr4Y9mAN;

		// Token: 0x0404FD49 RID: 326985 RVA: 0x0014B328 File Offset: 0x00149528
		static readonly int w8amC31dEm;

		// Token: 0x0404FD4A RID: 326986 RVA: 0x0014B330 File Offset: 0x00149530
		static readonly int KEVJfQ7IYW;

		// Token: 0x0404FD4B RID: 326987 RVA: 0x0014B338 File Offset: 0x00149538
		static readonly int z51Ymtw2QX;

		// Token: 0x0404FD4C RID: 326988 RVA: 0x0014B340 File Offset: 0x00149540
		static readonly int aH3fO4g02z;

		// Token: 0x0404FD4D RID: 326989 RVA: 0x0014B348 File Offset: 0x00149548
		static readonly int JNIXG9MoMo;

		// Token: 0x0404FD4E RID: 326990 RVA: 0x0014B350 File Offset: 0x00149550
		static readonly int b1OnY1HB9S;

		// Token: 0x0404FD4F RID: 326991 RVA: 0x0014B358 File Offset: 0x00149558
		static readonly int H9NqMCK04k;

		// Token: 0x0404FD50 RID: 326992 RVA: 0x0014B360 File Offset: 0x00149560
		static readonly int tGPiMlwdSm;

		// Token: 0x0404FD51 RID: 326993 RVA: 0x0014B368 File Offset: 0x00149568
		static readonly int hHql6j3QHX;

		// Token: 0x0404FD52 RID: 326994 RVA: 0x0014B370 File Offset: 0x00149570
		static readonly int xe1jsKAbLE;

		// Token: 0x0404FD53 RID: 326995 RVA: 0x0014B378 File Offset: 0x00149578
		static readonly int zVtl4Umpaw;

		// Token: 0x0404FD54 RID: 326996 RVA: 0x0014B380 File Offset: 0x00149580
		static readonly int EotWvASlum;

		// Token: 0x0404FD55 RID: 326997 RVA: 0x0014B388 File Offset: 0x00149588
		static readonly int J3thwOOp0C;

		// Token: 0x0404FD56 RID: 326998 RVA: 0x0014B390 File Offset: 0x00149590
		static readonly int lVRNxMXFrl;

		// Token: 0x0404FD57 RID: 326999 RVA: 0x0014B398 File Offset: 0x00149598
		static readonly int 6N0UTJvfys;

		// Token: 0x0404FD58 RID: 327000 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 2Zri45mMyp;

		// Token: 0x0404FD59 RID: 327001 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int F6yYLsWfij;

		// Token: 0x0404FD5A RID: 327002 RVA: 0x0014B3A0 File Offset: 0x001495A0
		static readonly int mN3Iq5DYNn;

		// Token: 0x0404FD5B RID: 327003 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int dt0IJLnsT1;

		// Token: 0x0404FD5C RID: 327004 RVA: 0x0014B3A8 File Offset: 0x001495A8
		static readonly int jLQBgAZbJk;

		// Token: 0x0404FD5D RID: 327005 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int wP6PFofi29;

		// Token: 0x0404FD5E RID: 327006 RVA: 0x0014B3B0 File Offset: 0x001495B0
		static readonly int 2N8KMWGqO9;

		// Token: 0x0404FD5F RID: 327007 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int FoMr9b62mq;

		// Token: 0x0404FD60 RID: 327008 RVA: 0x0014B3B8 File Offset: 0x001495B8
		static readonly int flOn0OxkCe;

		// Token: 0x0404FD61 RID: 327009 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int pEzT9WMFzJ;

		// Token: 0x0404FD62 RID: 327010 RVA: 0x0014B3A8 File Offset: 0x001495A8
		static readonly int 3tNKfIDPQo;

		// Token: 0x0404FD63 RID: 327011 RVA: 0x0014B3B0 File Offset: 0x001495B0
		static readonly int sn6MdQ8UU8;

		// Token: 0x0404FD64 RID: 327012 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ifntTAz2rn;

		// Token: 0x0404FD65 RID: 327013 RVA: 0x0014B3C0 File Offset: 0x001495C0
		static readonly int O0CcwwYEIs;

		// Token: 0x0404FD66 RID: 327014 RVA: 0x0014B3C8 File Offset: 0x001495C8
		static readonly int KiUYwCImzt;

		// Token: 0x0404FD67 RID: 327015 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int X1v1kYFd1f;

		// Token: 0x0404FD68 RID: 327016 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int TKhna1keaq;

		// Token: 0x0404FD69 RID: 327017 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 24MlxAKP7Q;

		// Token: 0x0404FD6A RID: 327018 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 1MD8PWFL1X;

		// Token: 0x0404FD6B RID: 327019 RVA: 0x0014B3D0 File Offset: 0x001495D0
		static readonly int r4NmZAAr85;

		// Token: 0x0404FD6C RID: 327020 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int cnLI1doJEk;

		// Token: 0x0404FD6D RID: 327021 RVA: 0x0014B3D8 File Offset: 0x001495D8
		static readonly int N0gknGHjYD;

		// Token: 0x0404FD6E RID: 327022 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int vYmD97qjMw;

		// Token: 0x0404FD6F RID: 327023 RVA: 0x0014B3E0 File Offset: 0x001495E0
		static readonly int AdRByOA4Gv;

		// Token: 0x0404FD70 RID: 327024 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int r6HRJ0Xn9S;

		// Token: 0x0404FD71 RID: 327025 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 3bT4JDBIJ3;

		// Token: 0x0404FD72 RID: 327026 RVA: 0x0014B3E8 File Offset: 0x001495E8
		static readonly int xF6RjujevZ;

		// Token: 0x0404FD73 RID: 327027 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int FNcmVzRV3I;

		// Token: 0x0404FD74 RID: 327028 RVA: 0x0014B3F0 File Offset: 0x001495F0
		static readonly int jDk43jKW2u;

		// Token: 0x0404FD75 RID: 327029 RVA: 0x0014B3D0 File Offset: 0x001495D0
		static readonly int M2uM8m90rZ;

		// Token: 0x0404FD76 RID: 327030 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int R31kMq8qiT;

		// Token: 0x0404FD77 RID: 327031 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int wpPAUueCYA;

		// Token: 0x0404FD78 RID: 327032 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int jNmAMNcQot;

		// Token: 0x0404FD79 RID: 327033 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 0aoe1qLArN;

		// Token: 0x0404FD7A RID: 327034 RVA: 0x0014B3F8 File Offset: 0x001495F8
		static readonly int ldxi8hmu2O;

		// Token: 0x0404FD7B RID: 327035 RVA: 0x0014B400 File Offset: 0x00149600
		static readonly int H6cqzEQ0X9;

		// Token: 0x0404FD7C RID: 327036 RVA: 0x0014B408 File Offset: 0x00149608
		static readonly int NsCzdVBuIn;

		// Token: 0x0404FD7D RID: 327037 RVA: 0x0014B410 File Offset: 0x00149610
		static readonly int ieVLZGZDCo;

		// Token: 0x0404FD7E RID: 327038 RVA: 0x0014B418 File Offset: 0x00149618
		static readonly int krXZl387px;

		// Token: 0x0404FD7F RID: 327039 RVA: 0x0014B420 File Offset: 0x00149620
		static readonly int ZUms92b7Em;

		// Token: 0x0404FD80 RID: 327040 RVA: 0x0014B428 File Offset: 0x00149628
		static readonly int g2lOpnlRRt;
	}
}
