﻿using System;
using HarmonyLib;

namespace CanvasGUI
{
	// Token: 0x02000029 RID: 41
	internal class GorillaNotRemover
	{
		// Token: 0x060001CD RID: 461 RVA: 0x00639DB8 File Offset: 0x00637FB8
		public unsafe GorillaNotRemover()
		{
			if ((*(&GorillaNotRemover.1lOMKvUWIU) ^ *(&GorillaNotRemover.1lOMKvUWIU)) != 0)
			{
				int[] array = new int[10];
				int[] array2 = new int[10];
				int num2;
				int num = num2 - 262;
				int num3;
				int num4;
				if (num3 > num3)
				{
					array2[num + 8 - num] = num4 - 5;
					num4 = (array2[num4 + 8 - num3] ^ 8);
					num3 >>= 5;
				}
				num = num2;
				num2 = -num4;
				num = *(ref num4 + (IntPtr)num2);
				if (num > num)
				{
					num ^= 1296149858;
					num3 = (num | num4);
				}
				num3 = GorillaNotRemover.o7ZTxZXQ4L;
				num2 = (num3 ^ num4);
				num4 = num2;
				if (num3 > num3)
				{
					num = (num3 ^ 1055788777);
					num3 = (int)((short)num2);
					num4 = num % num4;
					num2 = num >> 6;
				}
				num = (int)((sbyte)num);
				*(ref GorillaNotRemover.o7ZTxZXQ4L + (IntPtr)num) = num;
				num = (num4 & 899601812);
				array2[num4 + 5 - num4] = (num4 | 8);
				num3 %= 963;
				num = array[num3 + 9 - num3] + 2;
				num2 = (num3 ^ 1993398712);
				num3 = 224901884;
				if (num3 > num3)
				{
					if (num2 > num2)
					{
						num3 = num4 + num2;
						num4 = *(ref num4 + (IntPtr)num2);
						num3 = ~num;
					}
					num2 = num % num4;
					if (num4 > num4)
					{
						num3 = num % 727;
						num2 = num4 - 130;
					}
					if (num3 > num3)
					{
						num3 = (num4 | num2);
						num3 = *(ref num2 + (IntPtr)num4);
						num = (num2 & num4);
						num2 = num4 - num2;
						num *= 324;
						num3 = (num2 | num4);
						num3 = num2 * 54;
						*(ref num2 + (IntPtr)num4) = num4;
					}
					num = num3 % num4;
					num = (num2 & 951133540);
					num3 -= 231;
					num = (num3 | num4);
				}
				num /= 392;
				num3 = num4 + num2;
				if (num4 > num4)
				{
					if (num3 > num3)
					{
						num3 = num2;
						num = num3 >> 2;
						num4 = 1889588540;
						array2[num4 + 7 - num3] = num4 - 4;
						num3 = *(ref num + (IntPtr)num4);
						num4 = num3 * num4;
						num2 = *(ref GorillaNotRemover.o7ZTxZXQ4L + (IntPtr)num);
					}
					num = num4 >> 4;
					if (num2 > num2)
					{
						num2 = num / 131;
						num2 = (array2[num3 + 5 - num4] ^ -10);
						num2 |= 1749387685;
					}
					num = -num2;
					num4 = *(ref GorillaNotRemover.o7ZTxZXQ4L + (IntPtr)num);
					num = num3;
					num4 = num3 % 830;
					num4 = (array2[num + 7 - num] ^ 5);
				}
				num = num4 - num2;
				array2[num3 + 7 - num2] = (num3 | 8);
				if (num2 > num2)
				{
					num4 = (int)((ushort)num2);
				}
				num2 = 1207723022;
				num2 = array2[num3 + 8 - num3] + 0;
				num2 = num4 * 112;
				*(ref GorillaNotRemover.o7ZTxZXQ4L + (IntPtr)num) = num;
			}
			base..ctor();
		}

		// Token: 0x0404DFB4 RID: 319412
		public static bool NoAntiCheat;

		// Token: 0x0404DFB5 RID: 319413 RVA: 0x00143980 File Offset: 0x00141B80
		static int 1lOMKvUWIU;

		// Token: 0x0404DFB6 RID: 319414 RVA: 0x00143988 File Offset: 0x00141B88
		static int o7ZTxZXQ4L;

		// Token: 0x0200002A RID: 42
		[HarmonyPatch(typeof(GorillaNot), "DispatchReport")]
		internal class NoReportPatch
		{
			// Token: 0x060001CE RID: 462 RVA: 0x0063A004 File Offset: 0x00638204
			private unsafe static bool Prefix()
			{
				"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
				if ((*(&GorillaNotRemover.NoReportPatch.H95LWv1h4u) ^ *(&GorillaNotRemover.NoReportPatch.H95LWv1h4u)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num = -num;
					int num3;
					int num2 = *(ref num3 + (IntPtr)num2);
					num3 = *(ref GorillaNotRemover.NoReportPatch.z04IBKxnDu + (IntPtr)num);
					int num4 = num;
					num4 = num2 % 258;
					num = -num2;
					num3 = num % 560;
					num4 = -num4;
					int num5;
					num2 ^= num5;
					num3 *= 824;
					num2 = num - num2;
					array[num5 + 6 - num5] = num3 - -8;
					if (num2 > num2)
					{
						if (num3 > num3)
						{
							num4 = num3 << 1;
						}
						num3 = GorillaNotRemover.NoReportPatch.z04IBKxnDu;
						num3 = ~num4;
						if (num3 > num3)
						{
							num3 = -num3;
							num = *(ref num3 + (IntPtr)num2);
							num ^= num2;
							num5 = (num3 ^ num2);
							num -= 520;
							num2 = (num & 574228724);
						}
						num5 = num >> 1;
						GorillaNotRemover.NoReportPatch.z04IBKxnDu = num2;
					}
					num3 = (num2 & num5);
					num5 &= 995519891;
					num5 = 1256525072;
					num2 = (num4 ^ num2);
					num2 = -num5;
					num5 = (array2[num2 + 7 - num4] ^ 8);
					*(ref num + (IntPtr)num2) = num2;
					num5 = *(ref GorillaNotRemover.NoReportPatch.z04IBKxnDu + (IntPtr)num5);
					array[num3 + 7 - num] = num4 - 1;
					num = num4 - num2;
					num3 = 1191662971;
					num3 = (int)((sbyte)num4);
					num4 = num * 717;
					num2 = num4 / 131;
					num5 = num4 / 836;
					num5 = num3 * num2;
					if (num3 > num3)
					{
						num2 = *(ref GorillaNotRemover.NoReportPatch.z04IBKxnDu + (IntPtr)num2);
						num5 ^= 870665398;
						num2 = -num4;
						num4 <<= 4;
						if (num5 > num5)
						{
							num5 = num5;
						}
						num4 = -num;
						num5 = (num | num2);
						*(ref num3 + (IntPtr)num2) = num2;
						num2 = num5 * 144;
						num4 = *(ref GorillaNotRemover.NoReportPatch.z04IBKxnDu + (IntPtr)num5);
					}
					num2 = num2;
					array2[num3 + 7 - num2] = num4 - -6;
					num3 = (int)((short)num3);
					num5 = num2 % num5;
					num5 = -num3;
					if (num3 > num3)
					{
						num = num2 % num5;
						num5 = (num ^ 1211801058);
						GorillaNotRemover.NoReportPatch.z04IBKxnDu = num5;
						num4 *= num2;
						num3 = num4 - 821;
						if (num3 > num3)
						{
							num4 = num2;
							num2 = num * num2;
							num3 = num5 + num2;
							num2 = -num2;
							num3 = num2 / num5;
							GorillaNotRemover.NoReportPatch.z04IBKxnDu = num;
							num4 &= 806168739;
						}
					}
				}
				int[] array3 = new int[15];
				int num6 = 621;
				if (num6 == 621)
				{
					array3[0] = 891662921;
					int[] array4 = array3;
					int num7 = 0;
					int num8 = array3[0] % 7 % 94 ^ 354;
					int num9 = (229 == 0) ? (num8 - 32) : (num8 + 229);
					array4[num7] = (array3[0] ^ num9 ^ (891662921 ^ num9));
				}
				return array3[0] != 0;
			}

			// Token: 0x060001CF RID: 463 RVA: 0x0063A308 File Offset: 0x00638508
			public unsafe NoReportPatch()
			{
				if ((*(&GorillaNotRemover.NoReportPatch.EtEJvb3xTi) ^ *(&GorillaNotRemover.NoReportPatch.EtEJvb3xTi)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					*(ref num + (IntPtr)num2) = num2;
					*(ref GorillaNotRemover.NoReportPatch.z04IBKxnDu + (IntPtr)num) = num;
					num = num2 + 560;
					int num3;
					if (num > num)
					{
						num |= num2;
						num3 = ~num3;
						num2 *= 246;
						num2 = GorillaNotRemover.NoReportPatch.z04IBKxnDu;
						num = -num3;
						if (num3 > num3)
						{
							num3 = num * num2;
							num = (int)((short)num2);
							num2 = num3 - num2;
							num2 %= num3;
							num2 = num3 - 910;
							array[num2 + 6 - num2] = (num2 | 9);
							num2 += num3;
							num2 = ~num2;
						}
						num3 = num2 + 806;
						num2 = (int)((short)num3);
						num = num2 % num3;
					}
					array[num + 5 - num2] = num3 - 7;
					num2 = (int)((short)num2);
					*(ref GorillaNotRemover.NoReportPatch.z04IBKxnDu + (IntPtr)num2) = num2;
					num = -num;
					num = array[num2 + 8 - num] + -9;
					num2 = ~num2;
					if (num2 > num2)
					{
						if (num3 > num3)
						{
							num2 = num3;
							num2 = -num2;
							num = (num3 & 570926883);
							*(ref num3 + (IntPtr)num2) = num2;
							*(ref GorillaNotRemover.NoReportPatch.z04IBKxnDu + (IntPtr)num2) = num2;
							num3 = (array[num3 + 8 - num3] ^ 8);
						}
						num3 += 987;
						array[num + 9 - num] = num2 - -3;
					}
					num3 = num % 233;
					num2 = num3;
					num3 = num * 821;
					num = num2;
					num2 = (array[num3 + 6 - num2] ^ 7);
					num2 = num + 211;
					num2 = *(ref num + (IntPtr)num2);
					num = (int)((short)num);
					num = GorillaNotRemover.NoReportPatch.z04IBKxnDu;
					num2 = (num & num2);
					num3 = -num;
					num3 = (int)((sbyte)num3);
					num2 = ~num;
				}
				base..ctor();
			}

			// Token: 0x0404DFB7 RID: 319415 RVA: 0x00143990 File Offset: 0x00141B90
			static int H95LWv1h4u;

			// Token: 0x0404DFB8 RID: 319416 RVA: 0x00143998 File Offset: 0x00141B98
			static int z04IBKxnDu;

			// Token: 0x0404DFB9 RID: 319417 RVA: 0x001439A0 File Offset: 0x00141BA0
			static int EtEJvb3xTi;
		}

		// Token: 0x0200002B RID: 43
		[HarmonyPatch(typeof(GorillaNot), "CheckReports")]
		internal static class NoCheckReports
		{
			// Token: 0x060001D0 RID: 464 RVA: 0x0063A618 File Offset: 0x00638818
			private unsafe static bool Prefix()
			{
				"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
				if ((*(&GorillaNotRemover.NoCheckReports.ZqU9X2qC0Y) ^ *(&GorillaNotRemover.NoCheckReports.ZqU9X2qC0Y)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = array[num2 + 9 - num3] ^ -6;
					int num4 = 1954390324;
					num4 = num2 % 601;
					int num5;
					array[num2 + 6 - num4] = (num5 | -1);
					if (num3 > num3)
					{
						num5 = (int)((byte)num2);
						num5 = num4 + 767;
						num3 = (num2 ^ num5);
					}
					num5 -= num3;
					num5 = array[num + 5 - num3] + 0;
					num3 = num;
					num3 = num5;
					num3 = num2 / num5;
					num = num3 % 943;
					num4 = -num5;
					num5 = *(ref num + (IntPtr)num5);
					num4 = ~num3;
					num2 = num * 620;
					num2 = array[num + 8 - num4] + 7;
					array[num2 + 5 - num4] = num3 - 2;
					GorillaNotRemover.NoCheckReports.4wbYeyDQSm = num;
					num4 = ~num5;
					if (num3 > num3)
					{
						num4 = num3 - num5;
						if (num3 > num3)
						{
							num3 = num >> 4;
						}
						GorillaNotRemover.NoCheckReports.4wbYeyDQSm = num2;
						if (num5 > num5)
						{
							num = (int)((byte)num3);
							num3 = num5;
							num = (array[num + 8 - num5] ^ -6);
							num = ~num;
							num4 &= num5;
							num4 = -num2;
							num5 = ~num2;
							num2 = (int)((short)num);
						}
						array[num + 8 - num3] = (num2 | 3);
						*(ref num5 + (IntPtr)num3) = num3;
						num3 = *(ref GorillaNotRemover.NoCheckReports.4wbYeyDQSm + (IntPtr)num4);
					}
					num5 = *(ref GorillaNotRemover.NoCheckReports.4wbYeyDQSm + (IntPtr)num2);
					if (num5 > num5)
					{
						num4 = num;
						if (num3 > num3)
						{
							num3 = (num2 | num5);
							num4 = *(ref num + (IntPtr)num5);
							num5 -= 967;
							num5 = ~num3;
							num4 = num3 / num5;
							num = *(ref num + (IntPtr)num5);
							array[num5 + 8 - num3] = (num3 | 7);
							num5 = (num2 | 1367789512);
							num2 = ~num3;
							num5 = num2 >> 3;
						}
					}
					GorillaNotRemover.NoCheckReports.4wbYeyDQSm = num;
					num4 = (array[num2 + 8 - num4] ^ 3);
					num4 = num >> 4;
					num = (int)((short)num5);
					num3 = array[num2 + 8 - num2] + 5;
					num4 = num2 / 32;
					num4 = num2 % num5;
					num4 = (int)((short)num5);
					num4 = (array[num2 + 9 - num3] ^ -10);
					num3 = (num5 | num3);
					num = (num4 ^ 1004687936);
					if (num > num)
					{
						if (num3 > num3)
						{
							num5 = num3 >> 5;
							num = num4 - 612;
							num4 = -num4;
							*(ref GorillaNotRemover.NoCheckReports.4wbYeyDQSm + (IntPtr)num2) = num2;
							num3 = GorillaNotRemover.NoCheckReports.4wbYeyDQSm;
							num = (array[num + 9 - num] ^ 6);
							num4 = num5 * 889;
							num2 = (num3 ^ 2093369147);
						}
						num2 = (int)((byte)num3);
						if (num > num)
						{
							num = num3 % num5;
							num2 = num3;
							num4 = (num5 & num3);
							num5 *= num3;
							num5 = GorillaNotRemover.NoCheckReports.4wbYeyDQSm;
						}
						num = num5;
					}
					num4 = GorillaNotRemover.NoCheckReports.4wbYeyDQSm;
					if (num5 > num5)
					{
						num5 *= num3;
						num5 = (int)((sbyte)num2);
						if (num3 > num3)
						{
							num3 = num2 + 936;
							num = -num2;
						}
						if (num3 > num3)
						{
							*(ref num3 + (IntPtr)num5) = num5;
							num2 = -num;
							num4 = (num | 754476184);
							array[num + 7 - num2] = (num5 | -3);
							num = GorillaNotRemover.NoCheckReports.4wbYeyDQSm;
						}
						num4 = num2 + 901;
						num = num3;
					}
					*(ref num5 + (IntPtr)num3) = num3;
					*(ref num4 + (IntPtr)num5) = num5;
					*(ref num4 + (IntPtr)num5) = num5;
				}
				int[] array2 = new int[15];
				int num6 = 450;
				if (num6 == 450)
				{
					array2[0] = 1810373317;
					int[] array3 = array2;
					int num7 = 0;
					int num8 = (array2[0] << 2 ^ -93) - -259;
					array3[num7] = (array2[0] ^ num8 ^ (1810373317 ^ num8));
				}
				return array2[0] != 0;
			}

			// Token: 0x0404DFBA RID: 319418 RVA: 0x001439A8 File Offset: 0x00141BA8
			static int ZqU9X2qC0Y;

			// Token: 0x0404DFBB RID: 319419 RVA: 0x001439B0 File Offset: 0x00141BB0
			static int 4wbYeyDQSm;
		}
	}
}
