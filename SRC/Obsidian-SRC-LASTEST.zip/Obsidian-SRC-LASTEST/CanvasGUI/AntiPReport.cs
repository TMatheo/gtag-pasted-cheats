﻿using System;
using HarmonyLib;
using PlayFab;

namespace CanvasGUI
{
	// Token: 0x0200002E RID: 46
	[HarmonyPatch(typeof(PlayFabClientInstanceAPI), "ReportPlayer")]
	internal class AntiPReport
	{
		// Token: 0x060001D3 RID: 467 RVA: 0x00640AFC File Offset: 0x0063ECFC
		private unsafe static bool Prefix()
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			if ((*(&AntiPReport.84m5g1jFDV) ^ *(&AntiPReport.84m5g1jFDV)) != 0)
			{
				goto IL_24;
			}
			goto IL_696;
			uint num2;
			bool result;
			for (;;)
			{
				IL_29:
				uint num;
				switch ((num = (num2 ^ (uint)(*(&AntiPReport.Hvm7yonhcU)))) % (uint)(*(&AntiPReport.XbF6f6Snyu) + *(&AntiPReport.dDeTp2pwoG)))
				{
				case 0U:
					num2 = 1727450442U;
					continue;
				case 1U:
				{
					int num4;
					int num5;
					int num3 = num4 | num5;
					uint[] array = new uint[*(&AntiPReport.iUA4sBeS5X)];
					array[*(&AntiPReport.5i7RJM4gFq)] = (uint)(*(&AntiPReport.Whgm67RO0A));
					array[*(&AntiPReport.Eq3jDSWX99)] = (uint)(*(&AntiPReport.vlugISnoKi));
					array[*(&AntiPReport.oECYEBxX7u)] = (uint)(*(&AntiPReport.uPb4TPpYN1) + *(&AntiPReport.0hgG5vwAeo));
					array[*(&AntiPReport.UnDSW9neeC) + *(&AntiPReport.e8ZOPfJ0M2)] = (uint)(*(&AntiPReport.mOaTrGi6dS));
					uint num6 = num * array[*(&AntiPReport.Ox2TZGMJiT)];
					uint num7 = num6 * (uint)(*(&AntiPReport.lK3LX1IS0Z) + *(&AntiPReport.l6xmBFNukP)) & (uint)(*(&AntiPReport.brBMxqGGyI) + *(&AntiPReport.TAS2RbVO60));
					num2 = ((num7 & array[*(&AntiPReport.8PFDrS9QRU)]) ^ (uint)(*(&AntiPReport.3bjS23IrYq)));
					continue;
				}
				case 2U:
					num2 = 1335725050U;
					continue;
				case 3U:
				{
					int num4;
					int num5;
					int num3 = num4 % num5;
					num4 += 299;
					num2 = 101724295U;
					continue;
				}
				case 4U:
				{
					uint num8 = num * (uint)(*(&AntiPReport.DASeolV1OG));
					uint num9 = num8 | (uint)(*(&AntiPReport.lrXuxlaCyr));
					num2 = ((num9 | (uint)(*(&AntiPReport.n9ipaDdq7l))) ^ (uint)(*(&AntiPReport.GFoAt9Yx5y)));
					continue;
				}
				case 5U:
				{
					int num4;
					int num5 = num4 ^ num5;
					uint num10 = num & (uint)(*(&AntiPReport.osOlWBXrc7));
					uint num11 = num10 & (uint)(*(&AntiPReport.1czxXhJiiT));
					uint num12 = num11 - (uint)(*(&AntiPReport.drspDXxxYE));
					uint num13 = num12 & (uint)(*(&AntiPReport.9VBiNyJfpr));
					num2 = ((num13 & (uint)(*(&AntiPReport.zMAJ8fi33g))) ^ (uint)(*(&AntiPReport.PAtOC79jh9) + *(&AntiPReport.NkTX8gbRki)));
					continue;
				}
				case 6U:
				{
					int num3;
					int num4 = (int)((short)num3);
					uint num14 = num + (uint)(*(&AntiPReport.lChSr81KmI));
					uint num15 = (num14 + (uint)(*(&AntiPReport.3UBrd8LYCy))) * (uint)(*(&AntiPReport.N8RMjlbX3M));
					num2 = (num15 + (uint)(*(&AntiPReport.c6Yw8ZF8SC)) ^ (uint)(*(&AntiPReport.fOqwUYZPul)));
					continue;
				}
				case 7U:
				{
					int num3;
					num3 *= 933;
					uint[] array2 = new uint[*(&AntiPReport.c6rZfGdPDD) + *(&AntiPReport.8p55Ioqrra)];
					array2[*(&AntiPReport.SjFQ0m1nIn)] = (uint)(*(&AntiPReport.p1UK3DXqp3));
					array2[*(&AntiPReport.CbhyK8PTX4)] = (uint)(*(&AntiPReport.6pkCj30bi2));
					array2[*(&AntiPReport.P0GaXHUvCE)] = (uint)(*(&AntiPReport.RAByX0BRG2));
					array2[*(&AntiPReport.XhPOqAQSk9) + *(&AntiPReport.N6HwoMVHaC)] = (uint)(*(&AntiPReport.ndQSn6nwot));
					array2[*(&AntiPReport.2jUpesk2tX)] = (uint)(*(&AntiPReport.1CLD1U3PKL));
					uint num16 = num + array2[*(&AntiPReport.e30DP4Q7ku)];
					uint num17 = num16 | array2[*(&AntiPReport.Wen1HnlbS5)];
					uint num18 = num17 + array2[*(&AntiPReport.ldXDLlSNaS)];
					num2 = ((num18 & (uint)(*(&AntiPReport.DYmdO8tQak))) ^ (uint)(*(&AntiPReport.bmR9BXYT5O)) ^ (uint)(*(&AntiPReport.tb6OjBfw2n)));
					continue;
				}
				case 8U:
				{
					int num3;
					num3 %= 103;
					num2 = (((num ^ (uint)(*(&AntiPReport.6g3tKMs3Sf) + *(&AntiPReport.zOljnxBRYz))) - (uint)(*(&AntiPReport.nVQSevYru4))) * (uint)(*(&AntiPReport.syIq6Imh0J)) - (uint)(*(&AntiPReport.nJzEPLVUVy)) + (uint)(*(&AntiPReport.aZFBflPkPY)) + (uint)(*(&AntiPReport.yAJXxAF5mf)) ^ (uint)(*(&AntiPReport.LeaPLdfLCS)));
					continue;
				}
				case 9U:
				{
					int num5;
					num5 >>= 5;
					int num4 = AntiPReport.SIfJI06jVz;
					uint[] array3 = new uint[*(&AntiPReport.xryENby1BP)];
					array3[*(&AntiPReport.xV8ULToKlZ)] = (uint)(*(&AntiPReport.GnRvVDOxe9));
					array3[*(&AntiPReport.h4iWg0Pu36)] = (uint)(*(&AntiPReport.3QxWbHZO3A));
					array3[*(&AntiPReport.WwcpVJZCtK)] = (uint)(*(&AntiPReport.NAXCs2wmyV) + *(&AntiPReport.D3Rpgz05UN));
					array3[*(&AntiPReport.n94dmuc3AW)] = (uint)(*(&AntiPReport.aNBst23uoi));
					uint num19 = (num & array3[*(&AntiPReport.Uxai7dfxJf)]) + array3[*(&AntiPReport.TesfgNG3a7)];
					num2 = ((num19 * (uint)(*(&AntiPReport.a2lb401i5n)) & array3[*(&AntiPReport.6FRv20jVgI) + *(&AntiPReport.PoufC6egLf)]) ^ (uint)(*(&AntiPReport.wAUqIcL8oH) + *(&AntiPReport.l61gjON7mq)));
					continue;
				}
				case 10U:
				{
					int num3;
					int num4 = num3 * 920;
					uint num20 = num | (uint)(*(&AntiPReport.pw1JBJXixU) + *(&AntiPReport.pPDwUGLOl7)) | (uint)(*(&AntiPReport.8PYkgHo7SH) + *(&AntiPReport.YhBnTCw350));
					uint num21 = num20 + (uint)(*(&AntiPReport.vSwgNnYWQ6) + *(&AntiPReport.u9OCyZYRm3));
					uint num22 = num21 * (uint)(*(&AntiPReport.eZQp5HNadR)) | (uint)(*(&AntiPReport.TSSuLpc1X3));
					num2 = (num22 - (uint)(*(&AntiPReport.tSqWXZS9y3) + *(&AntiPReport.ofQBVWCHkF)) ^ (uint)(*(&AntiPReport.Z739mcqe0I)));
					continue;
				}
				case 11U:
				{
					int num5;
					int num4 = num5 ^ 334021362;
					int num3;
					num5 = -num3;
					int[] array4;
					array4[num4 + 8 - num5] = num5 - 0;
					uint num23 = num + (uint)(*(&AntiPReport.Xn31eQqjrh));
					uint num24 = num23 ^ (uint)(*(&AntiPReport.y432y9lwfQ));
					num2 = (num24 + (uint)(*(&AntiPReport.zk8peO3mLb)) ^ (uint)(*(&AntiPReport.ERSVIlG2uv)));
					continue;
				}
				case 12U:
				{
					int num3;
					int num5 = (int)((ushort)num3);
					num2 = (((num3 <= num3) ? 3483837978U : 3549251476U) ^ num * 2916388146U);
					continue;
				}
				case 14U:
				{
					int num3 = 234971729;
					int num5;
					*(ref AntiPReport.SIfJI06jVz + (IntPtr)num5) = num5;
					uint[] array5 = new uint[*(&AntiPReport.llX7CDH6rg)];
					array5[*(&AntiPReport.2vzGTZv5D3)] = (uint)(*(&AntiPReport.wIhrzF1TvE) + *(&AntiPReport.oPzqO4kEix));
					array5[*(&AntiPReport.1dgpbGTh2f)] = (uint)(*(&AntiPReport.lY4UbdDpH7));
					array5[*(&AntiPReport.MxLn2m5I2Z)] = (uint)(*(&AntiPReport.zqWQCSm1Pt));
					array5[*(&AntiPReport.vUaQcQVfPv) + *(&AntiPReport.047llDS3xz)] = (uint)(*(&AntiPReport.KLodq4BoSI));
					uint num25 = num + (uint)(*(&AntiPReport.0LZYL1X5Kl) + *(&AntiPReport.Qa3Gi4tuo8));
					uint num26 = num25 * (uint)(*(&AntiPReport.AtEaikp6jh));
					num2 = ((num26 + (uint)(*(&AntiPReport.OrNG5oeiZu))) * (uint)(*(&AntiPReport.qWsMitSi5w)) ^ (uint)(*(&AntiPReport.KQ9UIHH90l) + *(&AntiPReport.LaVmWjNwL4)));
					continue;
				}
				case 15U:
				{
					uint num27 = (num ^ (uint)(*(&AntiPReport.pEXoVARWL9))) - (uint)(*(&AntiPReport.qJiF3xiuoI));
					uint num28 = num27 & (uint)(*(&AntiPReport.gcJ5gfC3p3));
					uint num29 = num28 - (uint)(*(&AntiPReport.5RkRgXJ0fC));
					uint num30 = num29 * (uint)(*(&AntiPReport.vfEcdinjE1));
					num2 = ((num30 | (uint)(*(&AntiPReport.gYHCsN4cH0))) ^ (uint)(*(&AntiPReport.8YrRDYjRig)));
					continue;
				}
				case 16U:
				{
					int num4;
					num4 -= 430;
					uint[] array6 = new uint[*(&AntiPReport.pOtPHwoFBp)];
					array6[*(&AntiPReport.s6YsDnPPmp)] = (uint)(*(&AntiPReport.qx1DXqJltT));
					array6[*(&AntiPReport.PAEwrudYWe)] = (uint)(*(&AntiPReport.PsbcZGHh8l));
					array6[*(&AntiPReport.yILUy1Xq1a) + *(&AntiPReport.mDVrar2lBS)] = (uint)(*(&AntiPReport.K03HZ8VZoQ));
					uint num31 = (num ^ (uint)(*(&AntiPReport.jmnIeGzt7z) + *(&AntiPReport.Xxg52MWuBr))) + (uint)(*(&AntiPReport.Offqb8OD40));
					num2 = ((num31 & array6[*(&AntiPReport.f7Bl19aNMU)]) ^ (uint)(*(&AntiPReport.2InM4XT8ON)));
					continue;
				}
				case 17U:
				{
					int num3;
					int num4 = num3 % 411;
					uint num32 = (num | (uint)(*(&AntiPReport.6l3693JJv5))) ^ (uint)(*(&AntiPReport.s2Y4ZO4bX0));
					uint num33 = num32 | (uint)(*(&AntiPReport.yWvW0cbsLF));
					num2 = (num33 * (uint)(*(&AntiPReport.LoblLVTfSd)) - (uint)(*(&AntiPReport.vStC7ry65Y)) ^ (uint)(*(&AntiPReport.tlZg3k0gGg)));
					continue;
				}
				case 18U:
				{
					int num3;
					num2 = (((num3 > num3) ? 2915670715U : 2650435750U) ^ num * 2596215218U);
					continue;
				}
				case 19U:
				{
					int num5 = num5;
					int num4;
					num5 = (int)((ushort)num4);
					uint num34 = num | (uint)(*(&AntiPReport.7Hqj85P5qT));
					uint num35 = num34 + (uint)(*(&AntiPReport.LSEYTgAqFC) + *(&AntiPReport.13t3jdQALa));
					uint num36 = num35 ^ (uint)(*(&AntiPReport.MZn9XnxDRW));
					num2 = ((num36 | (uint)(*(&AntiPReport.9NodQ4xcIH))) ^ (uint)(*(&AntiPReport.DfPBPDYx9f)));
					continue;
				}
				case 20U:
					num2 = 437641487U;
					continue;
				case 21U:
				{
					int num5;
					num2 = (((num5 > num5) ? 1083028996U : 851885245U) ^ num * 2674484142U);
					continue;
				}
				case 22U:
				{
					int num5;
					int num3;
					num5 &= num3;
					uint[] array7 = new uint[*(&AntiPReport.ouWRsvIGY7)];
					array7[*(&AntiPReport.VVXa06vkma)] = (uint)(*(&AntiPReport.okrZgTxO5y));
					array7[*(&AntiPReport.th4f1CnC8X)] = (uint)(*(&AntiPReport.TFkqvQjbpn));
					array7[*(&AntiPReport.cmVLBDC6uY)] = (uint)(*(&AntiPReport.73KjNxa1ix));
					uint num37 = num - (uint)(*(&AntiPReport.SsmOHi9BnQ)) + array7[*(&AntiPReport.uWiSVHMsdx)];
					num2 = (num37 + (uint)(*(&AntiPReport.ArRjaZ5Ac8)) ^ (uint)(*(&AntiPReport.0r21VuAGEc)));
					continue;
				}
				case 23U:
				{
					int[] array4 = new int[10];
					uint[] array8 = new uint[*(&AntiPReport.mI7Q54NHys)];
					array8[*(&AntiPReport.cFGmBfw8zp)] = (uint)(*(&AntiPReport.c95P7DQTR5));
					array8[*(&AntiPReport.912WsPezAk)] = (uint)(*(&AntiPReport.sKzGRY71RK));
					array8[*(&AntiPReport.Gq69omNrS1)] = (uint)(*(&AntiPReport.n3z2tlMu4w));
					array8[*(&AntiPReport.A68P6RKz8i) + *(&AntiPReport.GYBHzS43rF)] = (uint)(*(&AntiPReport.CwgI6yU6Xq));
					uint num38 = num - (uint)(*(&AntiPReport.MM7fJJsrCW));
					num2 = ((num38 | (uint)(*(&AntiPReport.cXtuvP2sDa))) - array8[*(&AntiPReport.qSDytOazSH)] - array8[*(&AntiPReport.7NcRW4bf7q)] ^ (uint)(*(&AntiPReport.kN1UnoCwXr)));
					continue;
				}
				case 24U:
				{
					int[] array9;
					result = (array9[0] != 0);
					uint[] array10 = new uint[*(&AntiPReport.VEavUqJ9kW)];
					array10[*(&AntiPReport.XHIOtKbQQ2)] = (uint)(*(&AntiPReport.C3M0pII1N9));
					array10[*(&AntiPReport.YJnwYnvl2g)] = (uint)(*(&AntiPReport.7xPK7USD5b));
					array10[*(&AntiPReport.yPdH2b1jFM) + *(&AntiPReport.iRvk8NeVzF)] = (uint)(*(&AntiPReport.YzYu4PoC3V));
					array10[*(&AntiPReport.zF6wLIqf47) + *(&AntiPReport.vMfq7qBoMt)] = (uint)(*(&AntiPReport.z6OzC81sMm));
					uint num39 = (num & array10[*(&AntiPReport.xzqtWdV8Zz)]) + array10[*(&AntiPReport.h8b1UMTswO)];
					uint num40 = num39 ^ array10[*(&AntiPReport.N9zJg30GuM)];
					num2 = ((num40 & (uint)(*(&AntiPReport.R7SRK6gvTe))) ^ (uint)(*(&AntiPReport.UCPXM0eWf0)));
					continue;
				}
				case 25U:
					goto IL_24;
				case 26U:
				{
					int num5;
					int num3;
					num3 -= num5;
					uint[] array11 = new uint[*(&AntiPReport.aEW5dSsHKV)];
					array11[*(&AntiPReport.2BScVmAcRP)] = (uint)(*(&AntiPReport.GZr0n690zB));
					array11[*(&AntiPReport.GDh68toO3e)] = (uint)(*(&AntiPReport.R7vRmKM84i));
					array11[*(&AntiPReport.dD4xMAWgRh) + *(&AntiPReport.T2RJOzdVdl)] = (uint)(*(&AntiPReport.8wix7IoZNd));
					array11[*(&AntiPReport.tB6QhDJut7)] = (uint)(*(&AntiPReport.WI6WKZqmCx));
					array11[*(&AntiPReport.q0eSkreG0E)] = (uint)(*(&AntiPReport.W6SyxS6BlL));
					uint num41 = num & (uint)(*(&AntiPReport.ptlfO0zMmh));
					uint num42 = num41 + (uint)(*(&AntiPReport.cCWZw2gnq0)) | array11[*(&AntiPReport.iC3plZzHi2) + *(&AntiPReport.cpA1I7O8Du)];
					num2 = ((num42 * (uint)(*(&AntiPReport.1ReSmTk3C4)) & array11[*(&AntiPReport.vTUumn064z)]) ^ (uint)(*(&AntiPReport.AsouEwBfRz) + *(&AntiPReport.oij58RikCS)));
					continue;
				}
				case 27U:
					goto IL_696;
				case 28U:
				{
					int num4 = 1774349531;
					uint[] array12 = new uint[*(&AntiPReport.COp8Du4IwN) + *(&AntiPReport.HYPj9mYdu0)];
					array12[*(&AntiPReport.ZyHmIFUUfL)] = (uint)(*(&AntiPReport.ST3VvKO2iY));
					array12[*(&AntiPReport.aknCfQ1GHh)] = (uint)(*(&AntiPReport.3uPZ9OHCz7));
					array12[*(&AntiPReport.aknl4xf4xy) + *(&AntiPReport.Xf5WayLFG2)] = (uint)(*(&AntiPReport.OOM7RiEdVh));
					array12[*(&AntiPReport.CLDk8z7BHr)] = (uint)(*(&AntiPReport.u7SSKXy29L));
					array12[*(&AntiPReport.DC67tLXqTW)] = (uint)(*(&AntiPReport.tCiQwLcVYk));
					array12[*(&AntiPReport.1J7YHR53w3)] = (uint)(*(&AntiPReport.tLeKeAPF1w));
					uint num43 = num - (uint)(*(&AntiPReport.bRsv8sYCg8));
					uint num44 = (num43 ^ (uint)(*(&AntiPReport.5deYT4Fhzc)) ^ (uint)(*(&AntiPReport.Qe3anhhXwv))) + array12[*(&AntiPReport.5WdmJkbMZZ)] + array12[*(&AntiPReport.23Xx8PrF1j)];
					num2 = (num44 * array12[*(&AntiPReport.5sQZg7XRIb) + *(&AntiPReport.KBQvDi92Pt)] ^ (uint)(*(&AntiPReport.d2HZjWHFbX) + *(&AntiPReport.0cgM0NGEGL)));
					continue;
				}
				case 29U:
				{
					int num4;
					num4 |= 644686937;
					num2 = 704397853U;
					continue;
				}
				case 30U:
					num2 = 770410968U;
					continue;
				case 31U:
				{
					int[] array9;
					array9[0] = 1542280419;
					uint[] array13 = new uint[*(&AntiPReport.gYWNtwTmLL)];
					array13[*(&AntiPReport.WYSx7JGjxy)] = (uint)(*(&AntiPReport.bbjvUzpmxU));
					array13[*(&AntiPReport.4GnczgxRFT)] = (uint)(*(&AntiPReport.ymqykMQPG8));
					array13[*(&AntiPReport.F9NAuFyl33)] = (uint)(*(&AntiPReport.Gqz0RQu08b));
					uint num45 = (num | array13[*(&AntiPReport.WzddAzuuLH)]) - (uint)(*(&AntiPReport.iZgzP43nru));
					num2 = (num45 - (uint)(*(&AntiPReport.rMXMNHw0hU)) ^ (uint)(*(&AntiPReport.baRolPgtA5)));
					continue;
				}
				case 32U:
				{
					int[] array9;
					int[] array14 = array9;
					int num46 = 0;
					int num47 = ~(array9[0] - -275);
					int num48 = (-367 == 0) ? (num47 - 32) : (num47 + -367);
					array14[num46] = (array9[0] ^ num48 ^ (1542280419 ^ num48));
					num2 = 1517818606U;
					continue;
				}
				case 33U:
				{
					uint num49 = (num & (uint)(*(&AntiPReport.fAirod16K2))) + (uint)(*(&AntiPReport.TlY36qTks5));
					num2 = (num49 * (uint)(*(&AntiPReport.Ztq5gcGdoW)) + (uint)(*(&AntiPReport.4KfzGHO2A6)) ^ (uint)(*(&AntiPReport.ljDDHLiAzM)));
					continue;
				}
				case 34U:
				{
					uint[] array15 = new uint[*(&AntiPReport.oI68Zx9hNc)];
					array15[*(&AntiPReport.mPOMhjqKqX)] = (uint)(*(&AntiPReport.qiYS4Kuc6q));
					array15[*(&AntiPReport.Ydk3hIBU1X)] = (uint)(*(&AntiPReport.78i01EyCzm) + *(&AntiPReport.KUqIKGunDO));
					array15[*(&AntiPReport.DhkhEIoVpY)] = (uint)(*(&AntiPReport.iVSTar9haz));
					array15[*(&AntiPReport.WrmTfExctb)] = (uint)(*(&AntiPReport.YXRnTZYBwt));
					array15[*(&AntiPReport.adXaEyCWrd) + *(&AntiPReport.HMNO1V4QBA)] = (uint)(*(&AntiPReport.UMlOAKEo9A));
					uint num50 = (num * (uint)(*(&AntiPReport.T8vrZ3ULPq)) & (uint)(*(&AntiPReport.CbuQTLKCv8)) & (uint)(*(&AntiPReport.fHAwYN1Ja4) + *(&AntiPReport.uXWrJIbgy7))) - (uint)(*(&AntiPReport.AsBU83bV4z));
					num2 = (num50 ^ (uint)(*(&AntiPReport.AB2BfM89TL)) ^ (uint)(*(&AntiPReport.CLvU6oFCGL)));
					continue;
				}
				case 35U:
				{
					int num4;
					int num3 = num4;
					uint[] array16 = new uint[*(&AntiPReport.ca7qtEbxtE)];
					array16[*(&AntiPReport.5ZJ4FgmsZI)] = (uint)(*(&AntiPReport.oexwVkP4rk));
					array16[*(&AntiPReport.exZvAUUDT3)] = (uint)(*(&AntiPReport.QAN0dUbebW));
					array16[*(&AntiPReport.7HH728nLVI) + *(&AntiPReport.zgFIjH9X3u)] = (uint)(*(&AntiPReport.MjZf2nQ6TA) + *(&AntiPReport.JudVmXpc3C));
					num2 = ((num ^ array16[*(&AntiPReport.rJrKEt4ERV)]) * array16[*(&AntiPReport.VDlrKYrlEO)] * array16[*(&AntiPReport.rq1U9EDufM) + *(&AntiPReport.bhe0DC1PbJ)] ^ (uint)(*(&AntiPReport.sMo7pFIvKO)));
					continue;
				}
				case 36U:
				{
					int num3;
					num3 /= 444;
					int num4;
					num2 = (((num4 > num4) ? 4044008926U : 4253099981U) ^ num * 4119673644U);
					continue;
				}
				case 37U:
				{
					int num4;
					num2 = (((num4 <= num4) ? 4184959027U : 2845963109U) ^ num * 1767216749U);
					continue;
				}
				case 38U:
				{
					int num5 = 1214395887;
					uint num51 = num + (uint)(*(&AntiPReport.UxL7wYiyGU));
					uint num52 = (((num51 & (uint)(*(&AntiPReport.wyOBrvuqsR))) | (uint)(*(&AntiPReport.OE4fDtg72v))) & (uint)(*(&AntiPReport.jMNG6QMaqy))) * (uint)(*(&AntiPReport.iNjlkpx7Al));
					num2 = ((num52 | (uint)(*(&AntiPReport.mWRrBQ3p3D))) ^ (uint)(*(&AntiPReport.1k5UvjkHEb)));
					continue;
				}
				case 39U:
				{
					int num3;
					int num4 = (int)((ushort)num3);
					uint num53 = num * (uint)(*(&AntiPReport.zHuEamuUsF));
					uint num54 = (num53 & (uint)(*(&AntiPReport.gdQaq76OsE))) - (uint)(*(&AntiPReport.2NG9S9Re1L));
					uint num55 = num54 + (uint)(*(&AntiPReport.MMnSWVLTWV));
					uint num56 = num55 + (uint)(*(&AntiPReport.ouQMfB7QGX) + *(&AntiPReport.bLgqsmAvvb));
					num2 = (num56 * (uint)(*(&AntiPReport.VPch3U07DU)) ^ (uint)(*(&AntiPReport.vm2WZI63dR)));
					continue;
				}
				case 40U:
				{
					int num57;
					num2 = (((num57 == 331) ? 1425556669U : 2053405366U) ^ num * 3200373538U);
					continue;
				}
				case 41U:
				{
					int num5;
					int num3;
					int num4 = num3 / num5;
					num5 = num4 % 683;
					uint[] array17 = new uint[*(&AntiPReport.hcKsh9HDPP) + *(&AntiPReport.vCtIGqOCD7)];
					array17[*(&AntiPReport.3XgP8uztkK)] = (uint)(*(&AntiPReport.mQCYjfsSIN));
					array17[*(&AntiPReport.AzGDez9mi8)] = (uint)(*(&AntiPReport.Evax5J54tx));
					array17[*(&AntiPReport.JYcFnfAVjl)] = (uint)(*(&AntiPReport.85406DRdvI));
					uint num58 = num - array17[*(&AntiPReport.uNLmF0zOdZ)];
					num2 = (num58 * (uint)(*(&AntiPReport.jyiVDmXBZ9)) * array17[*(&AntiPReport.yoC7AI1j02)] ^ (uint)(*(&AntiPReport.2cJlC5N09w)));
					continue;
				}
				case 42U:
				{
					uint[] array18 = new uint[*(&AntiPReport.z5FnHJUQOe) + *(&AntiPReport.HSEOtJntOz)];
					array18[*(&AntiPReport.REmNQMtYwV)] = (uint)(*(&AntiPReport.FP3m9EmAn5));
					array18[*(&AntiPReport.cvRwrWeULy)] = (uint)(*(&AntiPReport.nyWNAvT2X4));
					array18[*(&AntiPReport.a5d2Z1YcPp) + *(&AntiPReport.gmGSWgwzf4)] = (uint)(*(&AntiPReport.sYM8sQ3qlN));
					array18[*(&AntiPReport.vunsehSYXz) + *(&AntiPReport.7CFgRArD0d)] = (uint)(*(&AntiPReport.8eWcLCsfKI));
					array18[*(&AntiPReport.8r0B4w9Yyz)] = (uint)(*(&AntiPReport.OYcp6qSqqr) + *(&AntiPReport.j0zIPQXLhc));
					array18[*(&AntiPReport.yxOO1PLDmf) + *(&AntiPReport.BTPBPkBqff)] = (uint)(*(&AntiPReport.tCycjI2swn));
					uint num59 = num | (uint)(*(&AntiPReport.Yx1VAbJOyr));
					uint num60 = (((num59 & (uint)(*(&AntiPReport.eODLpPky2o))) ^ (uint)(*(&AntiPReport.PqpCtw8vot))) - (uint)(*(&AntiPReport.XdR9GOc3Ay))) * (uint)(*(&AntiPReport.ax2yAe8nxT));
					num2 = (num60 + (uint)(*(&AntiPReport.hEzHXrHzlO)) ^ (uint)(*(&AntiPReport.cXjFTB7EEb)));
					continue;
				}
				case 43U:
				{
					int num4;
					int num3 = num4 + 7;
					int num5;
					int[] array4;
					num4 = array4[num5 + 8 - num4] + 6;
					num3 = num5 >> 6;
					uint[] array19 = new uint[*(&AntiPReport.vBdsGko4Uk)];
					array19[*(&AntiPReport.u8xuQLm8ff)] = (uint)(*(&AntiPReport.r0yeO1b9AX) + *(&AntiPReport.So0QE7vW7G));
					array19[*(&AntiPReport.oE5rk5nyBq)] = (uint)(*(&AntiPReport.RKM385M9eO) + *(&AntiPReport.Jo47RFHhpT));
					array19[*(&AntiPReport.ZPBZ1m4H3T)] = (uint)(*(&AntiPReport.Nm7TFIc7RJ));
					num2 = (((num + (uint)(*(&AntiPReport.uw2s69J7Ze))) * (uint)(*(&AntiPReport.xGJsQCJxBV)) | (uint)(*(&AntiPReport.AFFLAgrk2J))) ^ (uint)(*(&AntiPReport.nKPgjnWSc1)));
					continue;
				}
				case 44U:
				{
					int num3;
					num3 |= 900707089;
					int num4;
					int num5 = num4 | 1688375402;
					uint[] array20 = new uint[*(&AntiPReport.Qa19LSrbj9)];
					array20[*(&AntiPReport.4pvUtwpOWP)] = (uint)(*(&AntiPReport.XDXQdglitN));
					array20[*(&AntiPReport.2tBt9Yt8dL)] = (uint)(*(&AntiPReport.hbDMgZg8lV));
					array20[*(&AntiPReport.52ffYMClgo)] = (uint)(*(&AntiPReport.rIrVGLnBVU));
					uint num61 = num | array20[*(&AntiPReport.DruLs5AKtE)];
					num2 = ((num61 * (uint)(*(&AntiPReport.An6XR9NgVw)) & (uint)(*(&AntiPReport.VHczeYurGV) + *(&AntiPReport.vemQSOIUxc))) ^ (uint)(*(&AntiPReport.M21boDMUEG)));
					continue;
				}
				case 45U:
				{
					int[] array9 = new int[15];
					uint[] array21 = new uint[*(&AntiPReport.EEwVWITHEu)];
					array21[*(&AntiPReport.T8SWzEcnEl)] = (uint)(*(&AntiPReport.Ho4mAfDWAy));
					array21[*(&AntiPReport.MnH9mjMNSR)] = (uint)(*(&AntiPReport.tVmNSIxRLp));
					array21[*(&AntiPReport.hvsUqaJJV1)] = (uint)(*(&AntiPReport.F6GQhp1SuQ) + *(&AntiPReport.1OUw1wBqU1));
					array21[*(&AntiPReport.svLVQb4xSM)] = (uint)(*(&AntiPReport.ZD1bMxOWqm));
					array21[*(&AntiPReport.Reh4xSa5c4) + *(&AntiPReport.YczdJUuv9F)] = (uint)(*(&AntiPReport.vD9h1yX2kE));
					uint num62 = num ^ array21[*(&AntiPReport.hpAskNNRh8)];
					num2 = ((((num62 ^ array21[*(&AntiPReport.A9UYx6NXS2)]) & (uint)(*(&AntiPReport.CdWk1Ne9D9) + *(&AntiPReport.4hVYXsbG35))) | array21[*(&AntiPReport.GdNAEvtlu4)]) + array21[*(&AntiPReport.k9ksBDSa1W)] ^ (uint)(*(&AntiPReport.tNNiDcn5BE)));
					continue;
				}
				case 46U:
				{
					int num4;
					int num3 = num4 - 361;
					uint[] array22 = new uint[*(&AntiPReport.ZLV4RnA21y)];
					array22[*(&AntiPReport.RGBxW8r38x)] = (uint)(*(&AntiPReport.gfsxiQBFz9) + *(&AntiPReport.gfXAW95ECe));
					array22[*(&AntiPReport.HPHBUEYiQY)] = (uint)(*(&AntiPReport.2TyXX3dhWA));
					array22[*(&AntiPReport.m4D2RwtAaX) + *(&AntiPReport.Cm0dqRXqdd)] = (uint)(*(&AntiPReport.2dzaHMr9nd));
					array22[*(&AntiPReport.gYsB2MMPth)] = (uint)(*(&AntiPReport.VXH2WPdUrG));
					array22[*(&AntiPReport.gwD3IIFmvE) + *(&AntiPReport.EtX71o4yld)] = (uint)(*(&AntiPReport.EH75HeV6E1));
					array22[*(&AntiPReport.tWRg6tUz3t)] = (uint)(*(&AntiPReport.Hjeodl9KBr));
					uint num63 = (num ^ array22[*(&AntiPReport.VosOCYzHvo)]) - array22[*(&AntiPReport.xIi3Vrc1AH)] & (uint)(*(&AntiPReport.TE52VenScg));
					uint num64 = num63 + array22[*(&AntiPReport.fL5WgEoDeh) + *(&AntiPReport.4NDP59AlSv)];
					num2 = ((num64 * array22[*(&AntiPReport.JHJ4XQt02h)] | array22[*(&AntiPReport.vgoPIlNMWR) + *(&AntiPReport.DYXcMGBp6W)]) ^ (uint)(*(&AntiPReport.eC9rWXCA8Q)));
					continue;
				}
				case 47U:
				{
					int num3 = -num3;
					uint[] array23 = new uint[*(&AntiPReport.MJE8O1nmuZ)];
					array23[*(&AntiPReport.Qy0HGCk0zJ)] = (uint)(*(&AntiPReport.0S0ulseE5z));
					array23[*(&AntiPReport.b5wDgTyILs)] = (uint)(*(&AntiPReport.teVBHBlYFx) + *(&AntiPReport.mQP6V4TTXg));
					array23[*(&AntiPReport.Wjq48UCwlx)] = (uint)(*(&AntiPReport.ObpGaV7ynj) + *(&AntiPReport.GF8HMLpzsm));
					array23[*(&AntiPReport.AfvoWKyaDw) + *(&AntiPReport.8yxSjKlJgA)] = (uint)(*(&AntiPReport.7epyZQkjrx));
					uint num65 = (num ^ array23[*(&AntiPReport.pME8wsqAuP)]) * (uint)(*(&AntiPReport.hgu1kSSqiB) + *(&AntiPReport.kgTspg07PF));
					num2 = (((num65 ^ array23[*(&AntiPReport.kOsQGwuzg0) + *(&AntiPReport.ekYQcauxNH)]) & array23[*(&AntiPReport.83AqMI3WSQ)]) ^ (uint)(*(&AntiPReport.2tuppSyevy)));
					continue;
				}
				case 48U:
				{
					int num4;
					int num5;
					*(ref num4 + (IntPtr)num5) = num5;
					uint[] array24 = new uint[*(&AntiPReport.BBYetAq6ku)];
					array24[*(&AntiPReport.Uai5AYRsTL)] = (uint)(*(&AntiPReport.L9NvlzTJQk));
					array24[*(&AntiPReport.pHSeZU18y2)] = (uint)(*(&AntiPReport.o3XTAVE6VA) + *(&AntiPReport.0OjRGBxm24));
					array24[*(&AntiPReport.rgpAEMHDfq) + *(&AntiPReport.hT4ahRm3vQ)] = (uint)(*(&AntiPReport.vWxQubhAYY));
					uint num66 = num + array24[*(&AntiPReport.gPF4LIOXOx)] ^ (uint)(*(&AntiPReport.NAbpdgUIuy));
					num2 = ((num66 | (uint)(*(&AntiPReport.Z30lJUsZPm))) ^ (uint)(*(&AntiPReport.pHpHKSOAPZ)));
					continue;
				}
				case 49U:
				{
					int num57 = 331;
					uint num67 = num ^ (uint)(*(&AntiPReport.eHdWvjQVfF));
					num2 = ((num67 + (uint)(*(&AntiPReport.e3PIY57nXT)) | (uint)(*(&AntiPReport.aBPhM3Po7l) + *(&AntiPReport.IxjpadgO6b))) ^ (uint)(*(&AntiPReport.x74w2z8FJI)));
					continue;
				}
				}
				break;
			}
			return result;
			IL_24:
			num2 = 432751537U;
			goto IL_29;
			IL_696:
			num2 = 377188807U;
			goto IL_29;
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x00641FC0 File Offset: 0x006401C0
		public unsafe AntiPReport()
		{
			if ((*(&AntiPReport.GNHchPigZo) ^ *(&AntiPReport.GNHchPigZo)) != 0)
			{
				int[] array = new int[10];
				int num2;
				int num = *(ref AntiPReport.SIfJI06jVz + (IntPtr)num2);
				int num3 = array[num3 + 9 - num] ^ 5;
				num3 *= num;
				num -= 511;
				num2 = 620205332;
				num3 = *(ref AntiPReport.SIfJI06jVz + (IntPtr)num3);
				num = *(ref AntiPReport.SIfJI06jVz + (IntPtr)num);
				num = (num2 | num);
				num -= num2;
				if (num > num)
				{
					*(ref num2 + (IntPtr)num) = num;
					num3 = num % 322;
					if (num3 > num3)
					{
						*(ref num2 + (IntPtr)num) = num;
					}
				}
				num2 = 594802922;
				num2 += 993;
				num3 = num3;
				num -= 199;
				num3 = (int)((short)num3);
				array[num + 9 - num3] = num3 - 5;
				array[num2 + 8 - num2] = num - 4;
				if (num3 > num3)
				{
					num2 = num / 651;
					num = num2;
					num = num3;
					num2 |= 1541828125;
					num2 = (int)((sbyte)num3);
					num = num3 << 4;
				}
				num = (int)((sbyte)num3);
				num3 |= 35910010;
				num3 = num2 - 891;
				if (num3 > num3)
				{
					if (num > num)
					{
						num <<= 2;
					}
					if (num > num)
					{
						num2 = (num & 415080436);
						*(ref num2 + (IntPtr)num) = num;
						array[num3 + 5 - num2] = num2 - 1;
						num3 = ~num2;
						num %= 790;
						num3 = num % num2;
					}
					num3 = (num & 2023140040);
					num = (num2 & num);
					num3 = (num | 193680456);
					*(ref num2 + (IntPtr)num) = num;
					num = (num2 | 1794160027);
					num3 += 156;
					num3 = num2 << 4;
				}
				num2 = num;
				AntiPReport.SIfJI06jVz = num2;
			}
			base..ctor();
			for (;;)
			{
				IL_179:
				uint num4 = 862390545U;
				for (;;)
				{
					uint num5;
					switch ((num5 = (num4 ^ (uint)(*(&AntiPReport.unOy8wFpxe)))) % (uint)(*(&AntiPReport.vfPk3teVM7) + *(&AntiPReport.KcNn5y6rYT)))
					{
					case 1U:
					{
						uint[] array2 = new uint[*(&AntiPReport.yYPsFWxECs)];
						array2[*(&AntiPReport.HSLyZh6KbM)] = (uint)(*(&AntiPReport.Kt0JARak2J));
						array2[*(&AntiPReport.zYReqXQgfh)] = (uint)(*(&AntiPReport.6ZSd02RZNY));
						array2[*(&AntiPReport.1vPLJEiGsx) + *(&AntiPReport.5MM32tAqHC)] = (uint)(*(&AntiPReport.Qao4QubXSI));
						array2[*(&AntiPReport.ABWeRDIFVm)] = (uint)(*(&AntiPReport.yKxsluNZlH));
						array2[*(&AntiPReport.1kSLHbGV5Y)] = (uint)(*(&AntiPReport.mLxkw4zrly) + *(&AntiPReport.k5VeNGn6Sg));
						uint num6 = num5 & (uint)(*(&AntiPReport.hCwLQatLW0));
						uint num7 = num6 - array2[*(&AntiPReport.6wK7AnXN5r)] - array2[*(&AntiPReport.4gxwg6Ox7B) + *(&AntiPReport.yKCZ0kZmTW)];
						uint num8 = num7 - array2[*(&AntiPReport.KoUv1xuYej) + *(&AntiPReport.sZAllBO9oU)];
						num4 = (num8 * array2[*(&AntiPReport.L5NUBwtvGZ) + *(&AntiPReport.Ov3jhQLC4s)] ^ (uint)(*(&AntiPReport.L0TXSYKbxz)));
						continue;
					}
					case 2U:
						goto IL_179;
					}
					return;
				}
			}
		}

		// Token: 0x0404E798 RID: 321432 RVA: 0x00145A28 File Offset: 0x00143C28
		static int 84m5g1jFDV;

		// Token: 0x0404E799 RID: 321433 RVA: 0x00145A30 File Offset: 0x00143C30
		static int SIfJI06jVz;

		// Token: 0x0404E79A RID: 321434 RVA: 0x00145A38 File Offset: 0x00143C38
		static int GNHchPigZo;

		// Token: 0x0404E79B RID: 321435 RVA: 0x00145A40 File Offset: 0x00143C40
		static readonly int Hvm7yonhcU;

		// Token: 0x0404E79C RID: 321436 RVA: 0x0003AFA0 File Offset: 0x000391A0
		static readonly int XbF6f6Snyu;

		// Token: 0x0404E79D RID: 321437 RVA: 0x0002E740 File Offset: 0x0002C940
		static readonly int dDeTp2pwoG;

		// Token: 0x0404E79E RID: 321438 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int mI7Q54NHys;

		// Token: 0x0404E79F RID: 321439 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int cFGmBfw8zp;

		// Token: 0x0404E7A0 RID: 321440 RVA: 0x00145A48 File Offset: 0x00143C48
		static readonly int c95P7DQTR5;

		// Token: 0x0404E7A1 RID: 321441 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 912WsPezAk;

		// Token: 0x0404E7A2 RID: 321442 RVA: 0x00145A50 File Offset: 0x00143C50
		static readonly int sKzGRY71RK;

		// Token: 0x0404E7A3 RID: 321443 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Gq69omNrS1;

		// Token: 0x0404E7A4 RID: 321444 RVA: 0x00145A58 File Offset: 0x00143C58
		static readonly int n3z2tlMu4w;

		// Token: 0x0404E7A5 RID: 321445 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int A68P6RKz8i;

		// Token: 0x0404E7A6 RID: 321446 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int GYBHzS43rF;

		// Token: 0x0404E7A7 RID: 321447 RVA: 0x00145A60 File Offset: 0x00143C60
		static readonly int CwgI6yU6Xq;

		// Token: 0x0404E7A8 RID: 321448 RVA: 0x00145A48 File Offset: 0x00143C48
		static readonly int MM7fJJsrCW;

		// Token: 0x0404E7A9 RID: 321449 RVA: 0x00145A50 File Offset: 0x00143C50
		static readonly int cXtuvP2sDa;

		// Token: 0x0404E7AA RID: 321450 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int qSDytOazSH;

		// Token: 0x0404E7AB RID: 321451 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 7NcRW4bf7q;

		// Token: 0x0404E7AC RID: 321452 RVA: 0x00145A68 File Offset: 0x00143C68
		static readonly int kN1UnoCwXr;

		// Token: 0x0404E7AD RID: 321453 RVA: 0x00145A70 File Offset: 0x00143C70
		static readonly int 6l3693JJv5;

		// Token: 0x0404E7AE RID: 321454 RVA: 0x00145A78 File Offset: 0x00143C78
		static readonly int s2Y4ZO4bX0;

		// Token: 0x0404E7AF RID: 321455 RVA: 0x00145A80 File Offset: 0x00143C80
		static readonly int yWvW0cbsLF;

		// Token: 0x0404E7B0 RID: 321456 RVA: 0x00145A88 File Offset: 0x00143C88
		static readonly int LoblLVTfSd;

		// Token: 0x0404E7B1 RID: 321457 RVA: 0x00145A90 File Offset: 0x00143C90
		static readonly int vStC7ry65Y;

		// Token: 0x0404E7B2 RID: 321458 RVA: 0x00145A98 File Offset: 0x00143C98
		static readonly int tlZg3k0gGg;

		// Token: 0x0404E7B3 RID: 321459 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ca7qtEbxtE;

		// Token: 0x0404E7B4 RID: 321460 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 5ZJ4FgmsZI;

		// Token: 0x0404E7B5 RID: 321461 RVA: 0x00145AA0 File Offset: 0x00143CA0
		static readonly int oexwVkP4rk;

		// Token: 0x0404E7B6 RID: 321462 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int exZvAUUDT3;

		// Token: 0x0404E7B7 RID: 321463 RVA: 0x00145AA8 File Offset: 0x00143CA8
		static readonly int QAN0dUbebW;

		// Token: 0x0404E7B8 RID: 321464 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7HH728nLVI;

		// Token: 0x0404E7B9 RID: 321465 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int zgFIjH9X3u;

		// Token: 0x0404E7BA RID: 321466 RVA: 0x00145AB0 File Offset: 0x00143CB0
		static readonly int MjZf2nQ6TA;

		// Token: 0x0404E7BB RID: 321467 RVA: 0x00145AB8 File Offset: 0x00143CB8
		static readonly int JudVmXpc3C;

		// Token: 0x0404E7BC RID: 321468 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int rJrKEt4ERV;

		// Token: 0x0404E7BD RID: 321469 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int VDlrKYrlEO;

		// Token: 0x0404E7BE RID: 321470 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int rq1U9EDufM;

		// Token: 0x0404E7BF RID: 321471 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bhe0DC1PbJ;

		// Token: 0x0404E7C0 RID: 321472 RVA: 0x00145AC0 File Offset: 0x00143CC0
		static readonly int sMo7pFIvKO;

		// Token: 0x0404E7C1 RID: 321473 RVA: 0x00145AC8 File Offset: 0x00143CC8
		static readonly int pEXoVARWL9;

		// Token: 0x0404E7C2 RID: 321474 RVA: 0x00145AD0 File Offset: 0x00143CD0
		static readonly int qJiF3xiuoI;

		// Token: 0x0404E7C3 RID: 321475 RVA: 0x00145AD8 File Offset: 0x00143CD8
		static readonly int gcJ5gfC3p3;

		// Token: 0x0404E7C4 RID: 321476 RVA: 0x00145AE0 File Offset: 0x00143CE0
		static readonly int 5RkRgXJ0fC;

		// Token: 0x0404E7C5 RID: 321477 RVA: 0x00145AE8 File Offset: 0x00143CE8
		static readonly int vfEcdinjE1;

		// Token: 0x0404E7C6 RID: 321478 RVA: 0x00145AF0 File Offset: 0x00143CF0
		static readonly int gYHCsN4cH0;

		// Token: 0x0404E7C7 RID: 321479 RVA: 0x00145AF8 File Offset: 0x00143CF8
		static readonly int 8YrRDYjRig;

		// Token: 0x0404E7C8 RID: 321480 RVA: 0x00145B00 File Offset: 0x00143D00
		static readonly int osOlWBXrc7;

		// Token: 0x0404E7C9 RID: 321481 RVA: 0x00145B08 File Offset: 0x00143D08
		static readonly int 1czxXhJiiT;

		// Token: 0x0404E7CA RID: 321482 RVA: 0x00145B10 File Offset: 0x00143D10
		static readonly int drspDXxxYE;

		// Token: 0x0404E7CB RID: 321483 RVA: 0x00145B18 File Offset: 0x00143D18
		static readonly int 9VBiNyJfpr;

		// Token: 0x0404E7CC RID: 321484 RVA: 0x00145B20 File Offset: 0x00143D20
		static readonly int zMAJ8fi33g;

		// Token: 0x0404E7CD RID: 321485 RVA: 0x00145B28 File Offset: 0x00143D28
		static readonly int PAtOC79jh9;

		// Token: 0x0404E7CE RID: 321486 RVA: 0x00145B30 File Offset: 0x00143D30
		static readonly int NkTX8gbRki;

		// Token: 0x0404E7CF RID: 321487 RVA: 0x00145B38 File Offset: 0x00143D38
		static readonly int Xn31eQqjrh;

		// Token: 0x0404E7D0 RID: 321488 RVA: 0x00145B40 File Offset: 0x00143D40
		static readonly int y432y9lwfQ;

		// Token: 0x0404E7D1 RID: 321489 RVA: 0x00145B48 File Offset: 0x00143D48
		static readonly int zk8peO3mLb;

		// Token: 0x0404E7D2 RID: 321490 RVA: 0x00145B50 File Offset: 0x00143D50
		static readonly int ERSVIlG2uv;

		// Token: 0x0404E7D3 RID: 321491 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Qa19LSrbj9;

		// Token: 0x0404E7D4 RID: 321492 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 4pvUtwpOWP;

		// Token: 0x0404E7D5 RID: 321493 RVA: 0x00145B58 File Offset: 0x00143D58
		static readonly int XDXQdglitN;

		// Token: 0x0404E7D6 RID: 321494 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2tBt9Yt8dL;

		// Token: 0x0404E7D7 RID: 321495 RVA: 0x00145B60 File Offset: 0x00143D60
		static readonly int hbDMgZg8lV;

		// Token: 0x0404E7D8 RID: 321496 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 52ffYMClgo;

		// Token: 0x0404E7D9 RID: 321497 RVA: 0x00145B68 File Offset: 0x00143D68
		static readonly int rIrVGLnBVU;

		// Token: 0x0404E7DA RID: 321498 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int DruLs5AKtE;

		// Token: 0x0404E7DB RID: 321499 RVA: 0x00145B60 File Offset: 0x00143D60
		static readonly int An6XR9NgVw;

		// Token: 0x0404E7DC RID: 321500 RVA: 0x00145B70 File Offset: 0x00143D70
		static readonly int VHczeYurGV;

		// Token: 0x0404E7DD RID: 321501 RVA: 0x00145B78 File Offset: 0x00143D78
		static readonly int vemQSOIUxc;

		// Token: 0x0404E7DE RID: 321502 RVA: 0x00145B80 File Offset: 0x00143D80
		static readonly int M21boDMUEG;

		// Token: 0x0404E7DF RID: 321503 RVA: 0x00145B88 File Offset: 0x00143D88
		static readonly int 7Hqj85P5qT;

		// Token: 0x0404E7E0 RID: 321504 RVA: 0x00145B90 File Offset: 0x00143D90
		static readonly int LSEYTgAqFC;

		// Token: 0x0404E7E1 RID: 321505 RVA: 0x00145B98 File Offset: 0x00143D98
		static readonly int 13t3jdQALa;

		// Token: 0x0404E7E2 RID: 321506 RVA: 0x00145BA0 File Offset: 0x00143DA0
		static readonly int MZn9XnxDRW;

		// Token: 0x0404E7E3 RID: 321507 RVA: 0x00145BA8 File Offset: 0x00143DA8
		static readonly int 9NodQ4xcIH;

		// Token: 0x0404E7E4 RID: 321508 RVA: 0x00145BB0 File Offset: 0x00143DB0
		static readonly int DfPBPDYx9f;

		// Token: 0x0404E7E5 RID: 321509 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int pOtPHwoFBp;

		// Token: 0x0404E7E6 RID: 321510 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int s6YsDnPPmp;

		// Token: 0x0404E7E7 RID: 321511 RVA: 0x00145BB8 File Offset: 0x00143DB8
		static readonly int qx1DXqJltT;

		// Token: 0x0404E7E8 RID: 321512 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int PAEwrudYWe;

		// Token: 0x0404E7E9 RID: 321513 RVA: 0x00145BC0 File Offset: 0x00143DC0
		static readonly int PsbcZGHh8l;

		// Token: 0x0404E7EA RID: 321514 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yILUy1Xq1a;

		// Token: 0x0404E7EB RID: 321515 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mDVrar2lBS;

		// Token: 0x0404E7EC RID: 321516 RVA: 0x00145BC8 File Offset: 0x00143DC8
		static readonly int K03HZ8VZoQ;

		// Token: 0x0404E7ED RID: 321517 RVA: 0x00145BD0 File Offset: 0x00143DD0
		static readonly int jmnIeGzt7z;

		// Token: 0x0404E7EE RID: 321518 RVA: 0x00145BD8 File Offset: 0x00143DD8
		static readonly int Xxg52MWuBr;

		// Token: 0x0404E7EF RID: 321519 RVA: 0x00145BC0 File Offset: 0x00143DC0
		static readonly int Offqb8OD40;

		// Token: 0x0404E7F0 RID: 321520 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int f7Bl19aNMU;

		// Token: 0x0404E7F1 RID: 321521 RVA: 0x00145BE0 File Offset: 0x00143DE0
		static readonly int 2InM4XT8ON;

		// Token: 0x0404E7F2 RID: 321522 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int llX7CDH6rg;

		// Token: 0x0404E7F3 RID: 321523 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 2vzGTZv5D3;

		// Token: 0x0404E7F4 RID: 321524 RVA: 0x00145BE8 File Offset: 0x00143DE8
		static readonly int wIhrzF1TvE;

		// Token: 0x0404E7F5 RID: 321525 RVA: 0x00145BF0 File Offset: 0x00143DF0
		static readonly int oPzqO4kEix;

		// Token: 0x0404E7F6 RID: 321526 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1dgpbGTh2f;

		// Token: 0x0404E7F7 RID: 321527 RVA: 0x00145BF8 File Offset: 0x00143DF8
		static readonly int lY4UbdDpH7;

		// Token: 0x0404E7F8 RID: 321528 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int MxLn2m5I2Z;

		// Token: 0x0404E7F9 RID: 321529 RVA: 0x00145C00 File Offset: 0x00143E00
		static readonly int zqWQCSm1Pt;

		// Token: 0x0404E7FA RID: 321530 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int vUaQcQVfPv;

		// Token: 0x0404E7FB RID: 321531 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 047llDS3xz;

		// Token: 0x0404E7FC RID: 321532 RVA: 0x00145C08 File Offset: 0x00143E08
		static readonly int KLodq4BoSI;

		// Token: 0x0404E7FD RID: 321533 RVA: 0x00145C10 File Offset: 0x00143E10
		static readonly int 0LZYL1X5Kl;

		// Token: 0x0404E7FE RID: 321534 RVA: 0x00145C18 File Offset: 0x00143E18
		static readonly int Qa3Gi4tuo8;

		// Token: 0x0404E7FF RID: 321535 RVA: 0x00145BF8 File Offset: 0x00143DF8
		static readonly int AtEaikp6jh;

		// Token: 0x0404E800 RID: 321536 RVA: 0x00145C00 File Offset: 0x00143E00
		static readonly int OrNG5oeiZu;

		// Token: 0x0404E801 RID: 321537 RVA: 0x00145C08 File Offset: 0x00143E08
		static readonly int qWsMitSi5w;

		// Token: 0x0404E802 RID: 321538 RVA: 0x00145C20 File Offset: 0x00143E20
		static readonly int KQ9UIHH90l;

		// Token: 0x0404E803 RID: 321539 RVA: 0x00145C28 File Offset: 0x00143E28
		static readonly int LaVmWjNwL4;

		// Token: 0x0404E804 RID: 321540 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int ZLV4RnA21y;

		// Token: 0x0404E805 RID: 321541 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int RGBxW8r38x;

		// Token: 0x0404E806 RID: 321542 RVA: 0x00145C30 File Offset: 0x00143E30
		static readonly int gfsxiQBFz9;

		// Token: 0x0404E807 RID: 321543 RVA: 0x00145C38 File Offset: 0x00143E38
		static readonly int gfXAW95ECe;

		// Token: 0x0404E808 RID: 321544 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int HPHBUEYiQY;

		// Token: 0x0404E809 RID: 321545 RVA: 0x00145C40 File Offset: 0x00143E40
		static readonly int 2TyXX3dhWA;

		// Token: 0x0404E80A RID: 321546 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int m4D2RwtAaX;

		// Token: 0x0404E80B RID: 321547 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Cm0dqRXqdd;

		// Token: 0x0404E80C RID: 321548 RVA: 0x00145C48 File Offset: 0x00143E48
		static readonly int 2dzaHMr9nd;

		// Token: 0x0404E80D RID: 321549 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int gYsB2MMPth;

		// Token: 0x0404E80E RID: 321550 RVA: 0x00145C50 File Offset: 0x00143E50
		static readonly int VXH2WPdUrG;

		// Token: 0x0404E80F RID: 321551 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int gwD3IIFmvE;

		// Token: 0x0404E810 RID: 321552 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int EtX71o4yld;

		// Token: 0x0404E811 RID: 321553 RVA: 0x00145C58 File Offset: 0x00143E58
		static readonly int EH75HeV6E1;

		// Token: 0x0404E812 RID: 321554 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int tWRg6tUz3t;

		// Token: 0x0404E813 RID: 321555 RVA: 0x00145C60 File Offset: 0x00143E60
		static readonly int Hjeodl9KBr;

		// Token: 0x0404E814 RID: 321556 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int VosOCYzHvo;

		// Token: 0x0404E815 RID: 321557 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xIi3Vrc1AH;

		// Token: 0x0404E816 RID: 321558 RVA: 0x00145C48 File Offset: 0x00143E48
		static readonly int TE52VenScg;

		// Token: 0x0404E817 RID: 321559 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int fL5WgEoDeh;

		// Token: 0x0404E818 RID: 321560 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 4NDP59AlSv;

		// Token: 0x0404E819 RID: 321561 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int JHJ4XQt02h;

		// Token: 0x0404E81A RID: 321562 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vgoPIlNMWR;

		// Token: 0x0404E81B RID: 321563 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int DYXcMGBp6W;

		// Token: 0x0404E81C RID: 321564 RVA: 0x00145C68 File Offset: 0x00143E68
		static readonly int eC9rWXCA8Q;

		// Token: 0x0404E81D RID: 321565 RVA: 0x00145C70 File Offset: 0x00143E70
		static readonly int UxL7wYiyGU;

		// Token: 0x0404E81E RID: 321566 RVA: 0x00145C78 File Offset: 0x00143E78
		static readonly int wyOBrvuqsR;

		// Token: 0x0404E81F RID: 321567 RVA: 0x00145C80 File Offset: 0x00143E80
		static readonly int OE4fDtg72v;

		// Token: 0x0404E820 RID: 321568 RVA: 0x00145C88 File Offset: 0x00143E88
		static readonly int jMNG6QMaqy;

		// Token: 0x0404E821 RID: 321569 RVA: 0x00145C90 File Offset: 0x00143E90
		static readonly int iNjlkpx7Al;

		// Token: 0x0404E822 RID: 321570 RVA: 0x00145C98 File Offset: 0x00143E98
		static readonly int mWRrBQ3p3D;

		// Token: 0x0404E823 RID: 321571 RVA: 0x00145CA0 File Offset: 0x00143EA0
		static readonly int 1k5UvjkHEb;

		// Token: 0x0404E824 RID: 321572 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int iUA4sBeS5X;

		// Token: 0x0404E825 RID: 321573 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 5i7RJM4gFq;

		// Token: 0x0404E826 RID: 321574 RVA: 0x00145CA8 File Offset: 0x00143EA8
		static readonly int Whgm67RO0A;

		// Token: 0x0404E827 RID: 321575 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Eq3jDSWX99;

		// Token: 0x0404E828 RID: 321576 RVA: 0x00145CB0 File Offset: 0x00143EB0
		static readonly int vlugISnoKi;

		// Token: 0x0404E829 RID: 321577 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int oECYEBxX7u;

		// Token: 0x0404E82A RID: 321578 RVA: 0x00145CB8 File Offset: 0x00143EB8
		static readonly int uPb4TPpYN1;

		// Token: 0x0404E82B RID: 321579 RVA: 0x00145CC0 File Offset: 0x00143EC0
		static readonly int 0hgG5vwAeo;

		// Token: 0x0404E82C RID: 321580 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int UnDSW9neeC;

		// Token: 0x0404E82D RID: 321581 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int e8ZOPfJ0M2;

		// Token: 0x0404E82E RID: 321582 RVA: 0x00145CC8 File Offset: 0x00143EC8
		static readonly int mOaTrGi6dS;

		// Token: 0x0404E82F RID: 321583 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Ox2TZGMJiT;

		// Token: 0x0404E830 RID: 321584 RVA: 0x00145CD0 File Offset: 0x00143ED0
		static readonly int lK3LX1IS0Z;

		// Token: 0x0404E831 RID: 321585 RVA: 0x00145CD8 File Offset: 0x00143ED8
		static readonly int l6xmBFNukP;

		// Token: 0x0404E832 RID: 321586 RVA: 0x00145CE0 File Offset: 0x00143EE0
		static readonly int brBMxqGGyI;

		// Token: 0x0404E833 RID: 321587 RVA: 0x00145CE8 File Offset: 0x00143EE8
		static readonly int TAS2RbVO60;

		// Token: 0x0404E834 RID: 321588 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 8PFDrS9QRU;

		// Token: 0x0404E835 RID: 321589 RVA: 0x00145CF0 File Offset: 0x00143EF0
		static readonly int 3bjS23IrYq;

		// Token: 0x0404E836 RID: 321590 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int vBdsGko4Uk;

		// Token: 0x0404E837 RID: 321591 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int u8xuQLm8ff;

		// Token: 0x0404E838 RID: 321592 RVA: 0x00145CF8 File Offset: 0x00143EF8
		static readonly int r0yeO1b9AX;

		// Token: 0x0404E839 RID: 321593 RVA: 0x00145D00 File Offset: 0x00143F00
		static readonly int So0QE7vW7G;

		// Token: 0x0404E83A RID: 321594 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int oE5rk5nyBq;

		// Token: 0x0404E83B RID: 321595 RVA: 0x00145D08 File Offset: 0x00143F08
		static readonly int RKM385M9eO;

		// Token: 0x0404E83C RID: 321596 RVA: 0x00145D10 File Offset: 0x00143F10
		static readonly int Jo47RFHhpT;

		// Token: 0x0404E83D RID: 321597 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ZPBZ1m4H3T;

		// Token: 0x0404E83E RID: 321598 RVA: 0x00145D18 File Offset: 0x00143F18
		static readonly int Nm7TFIc7RJ;

		// Token: 0x0404E83F RID: 321599 RVA: 0x00145D20 File Offset: 0x00143F20
		static readonly int uw2s69J7Ze;

		// Token: 0x0404E840 RID: 321600 RVA: 0x00145D28 File Offset: 0x00143F28
		static readonly int xGJsQCJxBV;

		// Token: 0x0404E841 RID: 321601 RVA: 0x00145D18 File Offset: 0x00143F18
		static readonly int AFFLAgrk2J;

		// Token: 0x0404E842 RID: 321602 RVA: 0x00145D30 File Offset: 0x00143F30
		static readonly int nKPgjnWSc1;

		// Token: 0x0404E843 RID: 321603 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int c6rZfGdPDD;

		// Token: 0x0404E844 RID: 321604 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 8p55Ioqrra;

		// Token: 0x0404E845 RID: 321605 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int SjFQ0m1nIn;

		// Token: 0x0404E846 RID: 321606 RVA: 0x00145D38 File Offset: 0x00143F38
		static readonly int p1UK3DXqp3;

		// Token: 0x0404E847 RID: 321607 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int CbhyK8PTX4;

		// Token: 0x0404E848 RID: 321608 RVA: 0x00145D40 File Offset: 0x00143F40
		static readonly int 6pkCj30bi2;

		// Token: 0x0404E849 RID: 321609 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int P0GaXHUvCE;

		// Token: 0x0404E84A RID: 321610 RVA: 0x00145D48 File Offset: 0x00143F48
		static readonly int RAByX0BRG2;

		// Token: 0x0404E84B RID: 321611 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int XhPOqAQSk9;

		// Token: 0x0404E84C RID: 321612 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int N6HwoMVHaC;

		// Token: 0x0404E84D RID: 321613 RVA: 0x00145D50 File Offset: 0x00143F50
		static readonly int ndQSn6nwot;

		// Token: 0x0404E84E RID: 321614 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 2jUpesk2tX;

		// Token: 0x0404E84F RID: 321615 RVA: 0x00145D58 File Offset: 0x00143F58
		static readonly int 1CLD1U3PKL;

		// Token: 0x0404E850 RID: 321616 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int e30DP4Q7ku;

		// Token: 0x0404E851 RID: 321617 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Wen1HnlbS5;

		// Token: 0x0404E852 RID: 321618 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ldXDLlSNaS;

		// Token: 0x0404E853 RID: 321619 RVA: 0x00145D50 File Offset: 0x00143F50
		static readonly int DYmdO8tQak;

		// Token: 0x0404E854 RID: 321620 RVA: 0x00145D58 File Offset: 0x00143F58
		static readonly int bmR9BXYT5O;

		// Token: 0x0404E855 RID: 321621 RVA: 0x00145D60 File Offset: 0x00143F60
		static readonly int tb6OjBfw2n;

		// Token: 0x0404E856 RID: 321622 RVA: 0x00145D68 File Offset: 0x00143F68
		static readonly int lChSr81KmI;

		// Token: 0x0404E857 RID: 321623 RVA: 0x00145D70 File Offset: 0x00143F70
		static readonly int 3UBrd8LYCy;

		// Token: 0x0404E858 RID: 321624 RVA: 0x00145D78 File Offset: 0x00143F78
		static readonly int N8RMjlbX3M;

		// Token: 0x0404E859 RID: 321625 RVA: 0x00145D80 File Offset: 0x00143F80
		static readonly int c6Yw8ZF8SC;

		// Token: 0x0404E85A RID: 321626 RVA: 0x00145D88 File Offset: 0x00143F88
		static readonly int fOqwUYZPul;

		// Token: 0x0404E85B RID: 321627 RVA: 0x00145D90 File Offset: 0x00143F90
		static readonly int zHuEamuUsF;

		// Token: 0x0404E85C RID: 321628 RVA: 0x00145D98 File Offset: 0x00143F98
		static readonly int gdQaq76OsE;

		// Token: 0x0404E85D RID: 321629 RVA: 0x00145DA0 File Offset: 0x00143FA0
		static readonly int 2NG9S9Re1L;

		// Token: 0x0404E85E RID: 321630 RVA: 0x00145DA8 File Offset: 0x00143FA8
		static readonly int MMnSWVLTWV;

		// Token: 0x0404E85F RID: 321631 RVA: 0x00145DB0 File Offset: 0x00143FB0
		static readonly int ouQMfB7QGX;

		// Token: 0x0404E860 RID: 321632 RVA: 0x00145DB8 File Offset: 0x00143FB8
		static readonly int bLgqsmAvvb;

		// Token: 0x0404E861 RID: 321633 RVA: 0x00145DC0 File Offset: 0x00143FC0
		static readonly int VPch3U07DU;

		// Token: 0x0404E862 RID: 321634 RVA: 0x00145DC8 File Offset: 0x00143FC8
		static readonly int vm2WZI63dR;

		// Token: 0x0404E863 RID: 321635 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int BBYetAq6ku;

		// Token: 0x0404E864 RID: 321636 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Uai5AYRsTL;

		// Token: 0x0404E865 RID: 321637 RVA: 0x00145DD0 File Offset: 0x00143FD0
		static readonly int L9NvlzTJQk;

		// Token: 0x0404E866 RID: 321638 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int pHSeZU18y2;

		// Token: 0x0404E867 RID: 321639 RVA: 0x00145DD8 File Offset: 0x00143FD8
		static readonly int o3XTAVE6VA;

		// Token: 0x0404E868 RID: 321640 RVA: 0x00145DE0 File Offset: 0x00143FE0
		static readonly int 0OjRGBxm24;

		// Token: 0x0404E869 RID: 321641 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int rgpAEMHDfq;

		// Token: 0x0404E86A RID: 321642 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int hT4ahRm3vQ;

		// Token: 0x0404E86B RID: 321643 RVA: 0x00145DE8 File Offset: 0x00143FE8
		static readonly int vWxQubhAYY;

		// Token: 0x0404E86C RID: 321644 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int gPF4LIOXOx;

		// Token: 0x0404E86D RID: 321645 RVA: 0x00145DF0 File Offset: 0x00143FF0
		static readonly int NAbpdgUIuy;

		// Token: 0x0404E86E RID: 321646 RVA: 0x00145DE8 File Offset: 0x00143FE8
		static readonly int Z30lJUsZPm;

		// Token: 0x0404E86F RID: 321647 RVA: 0x00145DF8 File Offset: 0x00143FF8
		static readonly int pHpHKSOAPZ;

		// Token: 0x0404E870 RID: 321648 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int COp8Du4IwN;

		// Token: 0x0404E871 RID: 321649 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int HYPj9mYdu0;

		// Token: 0x0404E872 RID: 321650 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ZyHmIFUUfL;

		// Token: 0x0404E873 RID: 321651 RVA: 0x00145E00 File Offset: 0x00144000
		static readonly int ST3VvKO2iY;

		// Token: 0x0404E874 RID: 321652 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int aknCfQ1GHh;

		// Token: 0x0404E875 RID: 321653 RVA: 0x00145E08 File Offset: 0x00144008
		static readonly int 3uPZ9OHCz7;

		// Token: 0x0404E876 RID: 321654 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int aknl4xf4xy;

		// Token: 0x0404E877 RID: 321655 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Xf5WayLFG2;

		// Token: 0x0404E878 RID: 321656 RVA: 0x00145E10 File Offset: 0x00144010
		static readonly int OOM7RiEdVh;

		// Token: 0x0404E879 RID: 321657 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int CLDk8z7BHr;

		// Token: 0x0404E87A RID: 321658 RVA: 0x00145E18 File Offset: 0x00144018
		static readonly int u7SSKXy29L;

		// Token: 0x0404E87B RID: 321659 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int DC67tLXqTW;

		// Token: 0x0404E87C RID: 321660 RVA: 0x00145E20 File Offset: 0x00144020
		static readonly int tCiQwLcVYk;

		// Token: 0x0404E87D RID: 321661 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 1J7YHR53w3;

		// Token: 0x0404E87E RID: 321662 RVA: 0x00145E28 File Offset: 0x00144028
		static readonly int tLeKeAPF1w;

		// Token: 0x0404E87F RID: 321663 RVA: 0x00145E00 File Offset: 0x00144000
		static readonly int bRsv8sYCg8;

		// Token: 0x0404E880 RID: 321664 RVA: 0x00145E08 File Offset: 0x00144008
		static readonly int 5deYT4Fhzc;

		// Token: 0x0404E881 RID: 321665 RVA: 0x00145E10 File Offset: 0x00144010
		static readonly int Qe3anhhXwv;

		// Token: 0x0404E882 RID: 321666 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 5WdmJkbMZZ;

		// Token: 0x0404E883 RID: 321667 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 23Xx8PrF1j;

		// Token: 0x0404E884 RID: 321668 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 5sQZg7XRIb;

		// Token: 0x0404E885 RID: 321669 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int KBQvDi92Pt;

		// Token: 0x0404E886 RID: 321670 RVA: 0x00145E30 File Offset: 0x00144030
		static readonly int d2HZjWHFbX;

		// Token: 0x0404E887 RID: 321671 RVA: 0x00145E38 File Offset: 0x00144038
		static readonly int 0cgM0NGEGL;

		// Token: 0x0404E888 RID: 321672 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int MJE8O1nmuZ;

		// Token: 0x0404E889 RID: 321673 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Qy0HGCk0zJ;

		// Token: 0x0404E88A RID: 321674 RVA: 0x00145E40 File Offset: 0x00144040
		static readonly int 0S0ulseE5z;

		// Token: 0x0404E88B RID: 321675 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int b5wDgTyILs;

		// Token: 0x0404E88C RID: 321676 RVA: 0x00145E48 File Offset: 0x00144048
		static readonly int teVBHBlYFx;

		// Token: 0x0404E88D RID: 321677 RVA: 0x00145E50 File Offset: 0x00144050
		static readonly int mQP6V4TTXg;

		// Token: 0x0404E88E RID: 321678 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Wjq48UCwlx;

		// Token: 0x0404E88F RID: 321679 RVA: 0x00145E58 File Offset: 0x00144058
		static readonly int ObpGaV7ynj;

		// Token: 0x0404E890 RID: 321680 RVA: 0x00145E60 File Offset: 0x00144060
		static readonly int GF8HMLpzsm;

		// Token: 0x0404E891 RID: 321681 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int AfvoWKyaDw;

		// Token: 0x0404E892 RID: 321682 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8yxSjKlJgA;

		// Token: 0x0404E893 RID: 321683 RVA: 0x00145E68 File Offset: 0x00144068
		static readonly int 7epyZQkjrx;

		// Token: 0x0404E894 RID: 321684 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int pME8wsqAuP;

		// Token: 0x0404E895 RID: 321685 RVA: 0x00145E70 File Offset: 0x00144070
		static readonly int hgu1kSSqiB;

		// Token: 0x0404E896 RID: 321686 RVA: 0x00145E78 File Offset: 0x00144078
		static readonly int kgTspg07PF;

		// Token: 0x0404E897 RID: 321687 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kOsQGwuzg0;

		// Token: 0x0404E898 RID: 321688 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ekYQcauxNH;

		// Token: 0x0404E899 RID: 321689 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 83AqMI3WSQ;

		// Token: 0x0404E89A RID: 321690 RVA: 0x00145E80 File Offset: 0x00144080
		static readonly int 2tuppSyevy;

		// Token: 0x0404E89B RID: 321691 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int hcKsh9HDPP;

		// Token: 0x0404E89C RID: 321692 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vCtIGqOCD7;

		// Token: 0x0404E89D RID: 321693 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 3XgP8uztkK;

		// Token: 0x0404E89E RID: 321694 RVA: 0x00145E88 File Offset: 0x00144088
		static readonly int mQCYjfsSIN;

		// Token: 0x0404E89F RID: 321695 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int AzGDez9mi8;

		// Token: 0x0404E8A0 RID: 321696 RVA: 0x00145E90 File Offset: 0x00144090
		static readonly int Evax5J54tx;

		// Token: 0x0404E8A1 RID: 321697 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int JYcFnfAVjl;

		// Token: 0x0404E8A2 RID: 321698 RVA: 0x00145E98 File Offset: 0x00144098
		static readonly int 85406DRdvI;

		// Token: 0x0404E8A3 RID: 321699 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int uNLmF0zOdZ;

		// Token: 0x0404E8A4 RID: 321700 RVA: 0x00145E90 File Offset: 0x00144090
		static readonly int jyiVDmXBZ9;

		// Token: 0x0404E8A5 RID: 321701 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int yoC7AI1j02;

		// Token: 0x0404E8A6 RID: 321702 RVA: 0x00145EA0 File Offset: 0x001440A0
		static readonly int 2cJlC5N09w;

		// Token: 0x0404E8A7 RID: 321703 RVA: 0x00145EA8 File Offset: 0x001440A8
		static readonly int pw1JBJXixU;

		// Token: 0x0404E8A8 RID: 321704 RVA: 0x00145EB0 File Offset: 0x001440B0
		static readonly int pPDwUGLOl7;

		// Token: 0x0404E8A9 RID: 321705 RVA: 0x00145EB8 File Offset: 0x001440B8
		static readonly int 8PYkgHo7SH;

		// Token: 0x0404E8AA RID: 321706 RVA: 0x00145EC0 File Offset: 0x001440C0
		static readonly int YhBnTCw350;

		// Token: 0x0404E8AB RID: 321707 RVA: 0x00145EC8 File Offset: 0x001440C8
		static readonly int vSwgNnYWQ6;

		// Token: 0x0404E8AC RID: 321708 RVA: 0x00145ED0 File Offset: 0x001440D0
		static readonly int u9OCyZYRm3;

		// Token: 0x0404E8AD RID: 321709 RVA: 0x00145ED8 File Offset: 0x001440D8
		static readonly int eZQp5HNadR;

		// Token: 0x0404E8AE RID: 321710 RVA: 0x00145EE0 File Offset: 0x001440E0
		static readonly int TSSuLpc1X3;

		// Token: 0x0404E8AF RID: 321711 RVA: 0x00145EE8 File Offset: 0x001440E8
		static readonly int tSqWXZS9y3;

		// Token: 0x0404E8B0 RID: 321712 RVA: 0x00145EF0 File Offset: 0x001440F0
		static readonly int ofQBVWCHkF;

		// Token: 0x0404E8B1 RID: 321713 RVA: 0x00145EF8 File Offset: 0x001440F8
		static readonly int Z739mcqe0I;

		// Token: 0x0404E8B2 RID: 321714 RVA: 0x00145F00 File Offset: 0x00144100
		static readonly int 6g3tKMs3Sf;

		// Token: 0x0404E8B3 RID: 321715 RVA: 0x00145F08 File Offset: 0x00144108
		static readonly int zOljnxBRYz;

		// Token: 0x0404E8B4 RID: 321716 RVA: 0x00145F10 File Offset: 0x00144110
		static readonly int nVQSevYru4;

		// Token: 0x0404E8B5 RID: 321717 RVA: 0x00145F18 File Offset: 0x00144118
		static readonly int syIq6Imh0J;

		// Token: 0x0404E8B6 RID: 321718 RVA: 0x00145F20 File Offset: 0x00144120
		static readonly int nJzEPLVUVy;

		// Token: 0x0404E8B7 RID: 321719 RVA: 0x00145F28 File Offset: 0x00144128
		static readonly int aZFBflPkPY;

		// Token: 0x0404E8B8 RID: 321720 RVA: 0x00145F30 File Offset: 0x00144130
		static readonly int yAJXxAF5mf;

		// Token: 0x0404E8B9 RID: 321721 RVA: 0x00145F38 File Offset: 0x00144138
		static readonly int LeaPLdfLCS;

		// Token: 0x0404E8BA RID: 321722 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int aEW5dSsHKV;

		// Token: 0x0404E8BB RID: 321723 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 2BScVmAcRP;

		// Token: 0x0404E8BC RID: 321724 RVA: 0x00145F40 File Offset: 0x00144140
		static readonly int GZr0n690zB;

		// Token: 0x0404E8BD RID: 321725 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int GDh68toO3e;

		// Token: 0x0404E8BE RID: 321726 RVA: 0x00145F48 File Offset: 0x00144148
		static readonly int R7vRmKM84i;

		// Token: 0x0404E8BF RID: 321727 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int dD4xMAWgRh;

		// Token: 0x0404E8C0 RID: 321728 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int T2RJOzdVdl;

		// Token: 0x0404E8C1 RID: 321729 RVA: 0x00145F50 File Offset: 0x00144150
		static readonly int 8wix7IoZNd;

		// Token: 0x0404E8C2 RID: 321730 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int tB6QhDJut7;

		// Token: 0x0404E8C3 RID: 321731 RVA: 0x00145F58 File Offset: 0x00144158
		static readonly int WI6WKZqmCx;

		// Token: 0x0404E8C4 RID: 321732 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int q0eSkreG0E;

		// Token: 0x0404E8C5 RID: 321733 RVA: 0x00145F60 File Offset: 0x00144160
		static readonly int W6SyxS6BlL;

		// Token: 0x0404E8C6 RID: 321734 RVA: 0x00145F40 File Offset: 0x00144140
		static readonly int ptlfO0zMmh;

		// Token: 0x0404E8C7 RID: 321735 RVA: 0x00145F48 File Offset: 0x00144148
		static readonly int cCWZw2gnq0;

		// Token: 0x0404E8C8 RID: 321736 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int iC3plZzHi2;

		// Token: 0x0404E8C9 RID: 321737 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int cpA1I7O8Du;

		// Token: 0x0404E8CA RID: 321738 RVA: 0x00145F58 File Offset: 0x00144158
		static readonly int 1ReSmTk3C4;

		// Token: 0x0404E8CB RID: 321739 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int vTUumn064z;

		// Token: 0x0404E8CC RID: 321740 RVA: 0x00145F68 File Offset: 0x00144168
		static readonly int AsouEwBfRz;

		// Token: 0x0404E8CD RID: 321741 RVA: 0x00145F70 File Offset: 0x00144170
		static readonly int oij58RikCS;

		// Token: 0x0404E8CE RID: 321742 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int z5FnHJUQOe;

		// Token: 0x0404E8CF RID: 321743 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int HSEOtJntOz;

		// Token: 0x0404E8D0 RID: 321744 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int REmNQMtYwV;

		// Token: 0x0404E8D1 RID: 321745 RVA: 0x00145F78 File Offset: 0x00144178
		static readonly int FP3m9EmAn5;

		// Token: 0x0404E8D2 RID: 321746 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int cvRwrWeULy;

		// Token: 0x0404E8D3 RID: 321747 RVA: 0x00145F80 File Offset: 0x00144180
		static readonly int nyWNAvT2X4;

		// Token: 0x0404E8D4 RID: 321748 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int a5d2Z1YcPp;

		// Token: 0x0404E8D5 RID: 321749 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gmGSWgwzf4;

		// Token: 0x0404E8D6 RID: 321750 RVA: 0x00145F88 File Offset: 0x00144188
		static readonly int sYM8sQ3qlN;

		// Token: 0x0404E8D7 RID: 321751 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vunsehSYXz;

		// Token: 0x0404E8D8 RID: 321752 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 7CFgRArD0d;

		// Token: 0x0404E8D9 RID: 321753 RVA: 0x00145F90 File Offset: 0x00144190
		static readonly int 8eWcLCsfKI;

		// Token: 0x0404E8DA RID: 321754 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 8r0B4w9Yyz;

		// Token: 0x0404E8DB RID: 321755 RVA: 0x00145F98 File Offset: 0x00144198
		static readonly int OYcp6qSqqr;

		// Token: 0x0404E8DC RID: 321756 RVA: 0x00145FA0 File Offset: 0x001441A0
		static readonly int j0zIPQXLhc;

		// Token: 0x0404E8DD RID: 321757 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yxOO1PLDmf;

		// Token: 0x0404E8DE RID: 321758 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int BTPBPkBqff;

		// Token: 0x0404E8DF RID: 321759 RVA: 0x00145FA8 File Offset: 0x001441A8
		static readonly int tCycjI2swn;

		// Token: 0x0404E8E0 RID: 321760 RVA: 0x00145F78 File Offset: 0x00144178
		static readonly int Yx1VAbJOyr;

		// Token: 0x0404E8E1 RID: 321761 RVA: 0x00145F80 File Offset: 0x00144180
		static readonly int eODLpPky2o;

		// Token: 0x0404E8E2 RID: 321762 RVA: 0x00145F88 File Offset: 0x00144188
		static readonly int PqpCtw8vot;

		// Token: 0x0404E8E3 RID: 321763 RVA: 0x00145F90 File Offset: 0x00144190
		static readonly int XdR9GOc3Ay;

		// Token: 0x0404E8E4 RID: 321764 RVA: 0x00145FB0 File Offset: 0x001441B0
		static readonly int ax2yAe8nxT;

		// Token: 0x0404E8E5 RID: 321765 RVA: 0x00145FA8 File Offset: 0x001441A8
		static readonly int hEzHXrHzlO;

		// Token: 0x0404E8E6 RID: 321766 RVA: 0x00145FB8 File Offset: 0x001441B8
		static readonly int cXjFTB7EEb;

		// Token: 0x0404E8E7 RID: 321767 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int xryENby1BP;

		// Token: 0x0404E8E8 RID: 321768 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int xV8ULToKlZ;

		// Token: 0x0404E8E9 RID: 321769 RVA: 0x00145FC0 File Offset: 0x001441C0
		static readonly int GnRvVDOxe9;

		// Token: 0x0404E8EA RID: 321770 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int h4iWg0Pu36;

		// Token: 0x0404E8EB RID: 321771 RVA: 0x00145FC8 File Offset: 0x001441C8
		static readonly int 3QxWbHZO3A;

		// Token: 0x0404E8EC RID: 321772 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int WwcpVJZCtK;

		// Token: 0x0404E8ED RID: 321773 RVA: 0x00145FD0 File Offset: 0x001441D0
		static readonly int NAXCs2wmyV;

		// Token: 0x0404E8EE RID: 321774 RVA: 0x00145FD8 File Offset: 0x001441D8
		static readonly int D3Rpgz05UN;

		// Token: 0x0404E8EF RID: 321775 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int n94dmuc3AW;

		// Token: 0x0404E8F0 RID: 321776 RVA: 0x00145FE0 File Offset: 0x001441E0
		static readonly int aNBst23uoi;

		// Token: 0x0404E8F1 RID: 321777 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Uxai7dfxJf;

		// Token: 0x0404E8F2 RID: 321778 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TesfgNG3a7;

		// Token: 0x0404E8F3 RID: 321779 RVA: 0x00145FE8 File Offset: 0x001441E8
		static readonly int a2lb401i5n;

		// Token: 0x0404E8F4 RID: 321780 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6FRv20jVgI;

		// Token: 0x0404E8F5 RID: 321781 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int PoufC6egLf;

		// Token: 0x0404E8F6 RID: 321782 RVA: 0x00145FF0 File Offset: 0x001441F0
		static readonly int wAUqIcL8oH;

		// Token: 0x0404E8F7 RID: 321783 RVA: 0x00145FF8 File Offset: 0x001441F8
		static readonly int l61gjON7mq;

		// Token: 0x0404E8F8 RID: 321784 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ouWRsvIGY7;

		// Token: 0x0404E8F9 RID: 321785 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int VVXa06vkma;

		// Token: 0x0404E8FA RID: 321786 RVA: 0x00146000 File Offset: 0x00144200
		static readonly int okrZgTxO5y;

		// Token: 0x0404E8FB RID: 321787 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int th4f1CnC8X;

		// Token: 0x0404E8FC RID: 321788 RVA: 0x00146008 File Offset: 0x00144208
		static readonly int TFkqvQjbpn;

		// Token: 0x0404E8FD RID: 321789 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int cmVLBDC6uY;

		// Token: 0x0404E8FE RID: 321790 RVA: 0x00146010 File Offset: 0x00144210
		static readonly int 73KjNxa1ix;

		// Token: 0x0404E8FF RID: 321791 RVA: 0x00146000 File Offset: 0x00144200
		static readonly int SsmOHi9BnQ;

		// Token: 0x0404E900 RID: 321792 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int uWiSVHMsdx;

		// Token: 0x0404E901 RID: 321793 RVA: 0x00146010 File Offset: 0x00144210
		static readonly int ArRjaZ5Ac8;

		// Token: 0x0404E902 RID: 321794 RVA: 0x00146018 File Offset: 0x00144218
		static readonly int 0r21VuAGEc;

		// Token: 0x0404E903 RID: 321795 RVA: 0x00146020 File Offset: 0x00144220
		static readonly int DASeolV1OG;

		// Token: 0x0404E904 RID: 321796 RVA: 0x00146028 File Offset: 0x00144228
		static readonly int lrXuxlaCyr;

		// Token: 0x0404E905 RID: 321797 RVA: 0x00146030 File Offset: 0x00144230
		static readonly int n9ipaDdq7l;

		// Token: 0x0404E906 RID: 321798 RVA: 0x00146038 File Offset: 0x00144238
		static readonly int GFoAt9Yx5y;

		// Token: 0x0404E907 RID: 321799 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int EEwVWITHEu;

		// Token: 0x0404E908 RID: 321800 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int T8SWzEcnEl;

		// Token: 0x0404E909 RID: 321801 RVA: 0x00146040 File Offset: 0x00144240
		static readonly int Ho4mAfDWAy;

		// Token: 0x0404E90A RID: 321802 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int MnH9mjMNSR;

		// Token: 0x0404E90B RID: 321803 RVA: 0x00146048 File Offset: 0x00144248
		static readonly int tVmNSIxRLp;

		// Token: 0x0404E90C RID: 321804 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int hvsUqaJJV1;

		// Token: 0x0404E90D RID: 321805 RVA: 0x00146050 File Offset: 0x00144250
		static readonly int F6GQhp1SuQ;

		// Token: 0x0404E90E RID: 321806 RVA: 0x00146058 File Offset: 0x00144258
		static readonly int 1OUw1wBqU1;

		// Token: 0x0404E90F RID: 321807 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int svLVQb4xSM;

		// Token: 0x0404E910 RID: 321808 RVA: 0x00146060 File Offset: 0x00144260
		static readonly int ZD1bMxOWqm;

		// Token: 0x0404E911 RID: 321809 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Reh4xSa5c4;

		// Token: 0x0404E912 RID: 321810 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YczdJUuv9F;

		// Token: 0x0404E913 RID: 321811 RVA: 0x00146068 File Offset: 0x00144268
		static readonly int vD9h1yX2kE;

		// Token: 0x0404E914 RID: 321812 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int hpAskNNRh8;

		// Token: 0x0404E915 RID: 321813 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int A9UYx6NXS2;

		// Token: 0x0404E916 RID: 321814 RVA: 0x00146070 File Offset: 0x00144270
		static readonly int CdWk1Ne9D9;

		// Token: 0x0404E917 RID: 321815 RVA: 0x00146078 File Offset: 0x00144278
		static readonly int 4hVYXsbG35;

		// Token: 0x0404E918 RID: 321816 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int GdNAEvtlu4;

		// Token: 0x0404E919 RID: 321817 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int k9ksBDSa1W;

		// Token: 0x0404E91A RID: 321818 RVA: 0x00146080 File Offset: 0x00144280
		static readonly int tNNiDcn5BE;

		// Token: 0x0404E91B RID: 321819 RVA: 0x00146088 File Offset: 0x00144288
		static readonly int eHdWvjQVfF;

		// Token: 0x0404E91C RID: 321820 RVA: 0x00146090 File Offset: 0x00144290
		static readonly int e3PIY57nXT;

		// Token: 0x0404E91D RID: 321821 RVA: 0x00146098 File Offset: 0x00144298
		static readonly int aBPhM3Po7l;

		// Token: 0x0404E91E RID: 321822 RVA: 0x001460A0 File Offset: 0x001442A0
		static readonly int IxjpadgO6b;

		// Token: 0x0404E91F RID: 321823 RVA: 0x001460A8 File Offset: 0x001442A8
		static readonly int x74w2z8FJI;

		// Token: 0x0404E920 RID: 321824 RVA: 0x001460B0 File Offset: 0x001442B0
		static readonly int fAirod16K2;

		// Token: 0x0404E921 RID: 321825 RVA: 0x001460B8 File Offset: 0x001442B8
		static readonly int TlY36qTks5;

		// Token: 0x0404E922 RID: 321826 RVA: 0x001460C0 File Offset: 0x001442C0
		static readonly int Ztq5gcGdoW;

		// Token: 0x0404E923 RID: 321827 RVA: 0x001460C8 File Offset: 0x001442C8
		static readonly int 4KfzGHO2A6;

		// Token: 0x0404E924 RID: 321828 RVA: 0x001460D0 File Offset: 0x001442D0
		static readonly int ljDDHLiAzM;

		// Token: 0x0404E925 RID: 321829 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int gYWNtwTmLL;

		// Token: 0x0404E926 RID: 321830 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int WYSx7JGjxy;

		// Token: 0x0404E927 RID: 321831 RVA: 0x001460D8 File Offset: 0x001442D8
		static readonly int bbjvUzpmxU;

		// Token: 0x0404E928 RID: 321832 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4GnczgxRFT;

		// Token: 0x0404E929 RID: 321833 RVA: 0x001460E0 File Offset: 0x001442E0
		static readonly int ymqykMQPG8;

		// Token: 0x0404E92A RID: 321834 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int F9NAuFyl33;

		// Token: 0x0404E92B RID: 321835 RVA: 0x001460E8 File Offset: 0x001442E8
		static readonly int Gqz0RQu08b;

		// Token: 0x0404E92C RID: 321836 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int WzddAzuuLH;

		// Token: 0x0404E92D RID: 321837 RVA: 0x001460E0 File Offset: 0x001442E0
		static readonly int iZgzP43nru;

		// Token: 0x0404E92E RID: 321838 RVA: 0x001460E8 File Offset: 0x001442E8
		static readonly int rMXMNHw0hU;

		// Token: 0x0404E92F RID: 321839 RVA: 0x001460F0 File Offset: 0x001442F0
		static readonly int baRolPgtA5;

		// Token: 0x0404E930 RID: 321840 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int VEavUqJ9kW;

		// Token: 0x0404E931 RID: 321841 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int XHIOtKbQQ2;

		// Token: 0x0404E932 RID: 321842 RVA: 0x001460F8 File Offset: 0x001442F8
		static readonly int C3M0pII1N9;

		// Token: 0x0404E933 RID: 321843 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YJnwYnvl2g;

		// Token: 0x0404E934 RID: 321844 RVA: 0x00146100 File Offset: 0x00144300
		static readonly int 7xPK7USD5b;

		// Token: 0x0404E935 RID: 321845 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yPdH2b1jFM;

		// Token: 0x0404E936 RID: 321846 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int iRvk8NeVzF;

		// Token: 0x0404E937 RID: 321847 RVA: 0x00146108 File Offset: 0x00144308
		static readonly int YzYu4PoC3V;

		// Token: 0x0404E938 RID: 321848 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int zF6wLIqf47;

		// Token: 0x0404E939 RID: 321849 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vMfq7qBoMt;

		// Token: 0x0404E93A RID: 321850 RVA: 0x00146110 File Offset: 0x00144310
		static readonly int z6OzC81sMm;

		// Token: 0x0404E93B RID: 321851 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int xzqtWdV8Zz;

		// Token: 0x0404E93C RID: 321852 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int h8b1UMTswO;

		// Token: 0x0404E93D RID: 321853 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int N9zJg30GuM;

		// Token: 0x0404E93E RID: 321854 RVA: 0x00146110 File Offset: 0x00144310
		static readonly int R7SRK6gvTe;

		// Token: 0x0404E93F RID: 321855 RVA: 0x00146118 File Offset: 0x00144318
		static readonly int UCPXM0eWf0;

		// Token: 0x0404E940 RID: 321856 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int oI68Zx9hNc;

		// Token: 0x0404E941 RID: 321857 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int mPOMhjqKqX;

		// Token: 0x0404E942 RID: 321858 RVA: 0x00146120 File Offset: 0x00144320
		static readonly int qiYS4Kuc6q;

		// Token: 0x0404E943 RID: 321859 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Ydk3hIBU1X;

		// Token: 0x0404E944 RID: 321860 RVA: 0x00146128 File Offset: 0x00144328
		static readonly int 78i01EyCzm;

		// Token: 0x0404E945 RID: 321861 RVA: 0x00146130 File Offset: 0x00144330
		static readonly int KUqIKGunDO;

		// Token: 0x0404E946 RID: 321862 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DhkhEIoVpY;

		// Token: 0x0404E947 RID: 321863 RVA: 0x00146138 File Offset: 0x00144338
		static readonly int iVSTar9haz;

		// Token: 0x0404E948 RID: 321864 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int WrmTfExctb;

		// Token: 0x0404E949 RID: 321865 RVA: 0x00146140 File Offset: 0x00144340
		static readonly int YXRnTZYBwt;

		// Token: 0x0404E94A RID: 321866 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int adXaEyCWrd;

		// Token: 0x0404E94B RID: 321867 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int HMNO1V4QBA;

		// Token: 0x0404E94C RID: 321868 RVA: 0x00146148 File Offset: 0x00144348
		static readonly int UMlOAKEo9A;

		// Token: 0x0404E94D RID: 321869 RVA: 0x00146120 File Offset: 0x00144320
		static readonly int T8vrZ3ULPq;

		// Token: 0x0404E94E RID: 321870 RVA: 0x00146150 File Offset: 0x00144350
		static readonly int CbuQTLKCv8;

		// Token: 0x0404E94F RID: 321871 RVA: 0x00146158 File Offset: 0x00144358
		static readonly int fHAwYN1Ja4;

		// Token: 0x0404E950 RID: 321872 RVA: 0x00146160 File Offset: 0x00144360
		static readonly int uXWrJIbgy7;

		// Token: 0x0404E951 RID: 321873 RVA: 0x00146140 File Offset: 0x00144340
		static readonly int AsBU83bV4z;

		// Token: 0x0404E952 RID: 321874 RVA: 0x00146148 File Offset: 0x00144348
		static readonly int AB2BfM89TL;

		// Token: 0x0404E953 RID: 321875 RVA: 0x00146168 File Offset: 0x00144368
		static readonly int CLvU6oFCGL;

		// Token: 0x0404E954 RID: 321876 RVA: 0x00146170 File Offset: 0x00144370
		static readonly int unOy8wFpxe;

		// Token: 0x0404E955 RID: 321877 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vfPk3teVM7;

		// Token: 0x0404E956 RID: 321878 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int KcNn5y6rYT;

		// Token: 0x0404E957 RID: 321879 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int yYPsFWxECs;

		// Token: 0x0404E958 RID: 321880 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int HSLyZh6KbM;

		// Token: 0x0404E959 RID: 321881 RVA: 0x00146178 File Offset: 0x00144378
		static readonly int Kt0JARak2J;

		// Token: 0x0404E95A RID: 321882 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int zYReqXQgfh;

		// Token: 0x0404E95B RID: 321883 RVA: 0x00146180 File Offset: 0x00144380
		static readonly int 6ZSd02RZNY;

		// Token: 0x0404E95C RID: 321884 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1vPLJEiGsx;

		// Token: 0x0404E95D RID: 321885 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 5MM32tAqHC;

		// Token: 0x0404E95E RID: 321886 RVA: 0x00146188 File Offset: 0x00144388
		static readonly int Qao4QubXSI;

		// Token: 0x0404E95F RID: 321887 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ABWeRDIFVm;

		// Token: 0x0404E960 RID: 321888 RVA: 0x00146190 File Offset: 0x00144390
		static readonly int yKxsluNZlH;

		// Token: 0x0404E961 RID: 321889 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 1kSLHbGV5Y;

		// Token: 0x0404E962 RID: 321890 RVA: 0x00146198 File Offset: 0x00144398
		static readonly int mLxkw4zrly;

		// Token: 0x0404E963 RID: 321891 RVA: 0x001461A0 File Offset: 0x001443A0
		static readonly int k5VeNGn6Sg;

		// Token: 0x0404E964 RID: 321892 RVA: 0x00146178 File Offset: 0x00144378
		static readonly int hCwLQatLW0;

		// Token: 0x0404E965 RID: 321893 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6wK7AnXN5r;

		// Token: 0x0404E966 RID: 321894 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4gxwg6Ox7B;

		// Token: 0x0404E967 RID: 321895 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yKCZ0kZmTW;

		// Token: 0x0404E968 RID: 321896 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KoUv1xuYej;

		// Token: 0x0404E969 RID: 321897 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int sZAllBO9oU;

		// Token: 0x0404E96A RID: 321898 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int L5NUBwtvGZ;

		// Token: 0x0404E96B RID: 321899 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Ov3jhQLC4s;

		// Token: 0x0404E96C RID: 321900 RVA: 0x001461A8 File Offset: 0x001443A8
		static readonly int L0TXSYKbxz;
	}
}
