﻿using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UMWixflZOX;

namespace CanvasGUI
{
	// Token: 0x02000027 RID: 39
	public class HarmonyPatches
	{
		// Token: 0x17000038 RID: 56
		// (get) Token: 0x060001C7 RID: 455 RVA: 0x0063497C File Offset: 0x00632B7C
		// (set) Token: 0x060001C8 RID: 456 RVA: 0x006350BC File Offset: 0x006332BC
		public unsafe static bool patched
		{
			[CompilerGenerated]
			get
			{
				if ((*(&HarmonyPatches.Ow2W7v2yaQ) ^ *(&HarmonyPatches.Ow2W7v2yaQ)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2;
					num >>= 6;
					int num3;
					num = num3 >> 5;
					num2 = -num;
					num2 -= num;
					num3 = num2 * num;
					num = (int)((byte)num3);
					num = HarmonyPatches.WU3kLcVUpZ;
					int num4;
					if (num4 > num4)
					{
						if (num4 > num4)
						{
							num2 = (array2[num3 + 8 - num4] ^ 1);
							num4 = array[num2 + 6 - num] + -8;
							num3 = (int)((short)num);
							num2 = num;
						}
						if (num3 > num3)
						{
							num4 = array[num + 9 - num3] + -4;
							num2 = -num;
							num4 = num3;
							num2 = (num ^ num2);
							num = num4 - 442;
							num2 = num >> 2;
							*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num3) = num3;
							num3 = num2 - num;
							*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num) = num;
						}
						num4 = HarmonyPatches.WU3kLcVUpZ;
						array2[num + 8 - num4] = (num4 | 9);
						num4 = num * 846;
						num3 = num2 - 314;
						num4 = (int)((sbyte)num);
						num = ~num2;
						*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num2) = num2;
						num3 = (num2 & num);
					}
					num /= num2;
					num4 |= 1391665003;
					num4 = (num | 626166676);
					num2 = (int)((sbyte)num2);
					num3 = num - num2;
					num2 = num3 + 89;
					if (num > num)
					{
						if (num4 > num4)
						{
							num2 = *(ref num + (IntPtr)num2);
							num4 = (int)((ushort)num2);
							num = (int)((short)num3);
							num3 = *(ref num2 + (IntPtr)num);
							num = num2 * num;
							array2[num4 + 9 - num] = num2 - 3;
							num3 = num4;
							num2 = *(ref num2 + (IntPtr)num);
							num3 = 731575490;
						}
						num = -num3;
						num2 = (num3 | num2);
						num2 = num4 / 729;
						num2 = num + num2;
						num3 = num / 621;
						num4 = (int)((ushort)num);
						num2 = (num4 ^ 1068117240);
					}
					if (num2 > num2)
					{
						num ^= num2;
						*(ref num + (IntPtr)num2) = num2;
						HarmonyPatches.WU3kLcVUpZ = num;
						num4 = num;
						if (num4 > num4)
						{
							num4 |= num2;
							num = num4 % num2;
							array[num3 + 8 - num4] = (num2 | -3);
							num3 /= 972;
							num = (int)((ushort)num4);
							num4 = (num3 ^ num2);
						}
						num = -num4;
						if (num3 > num3)
						{
							num = num4 << 2;
							num4 = (num & num2);
							array[num2 + 9 - num4] = (num2 | -2);
							num3 = num4 * num2;
							num3 = num2 % num;
							num3 *= num2;
							num3 %= num2;
							num4 = num2;
							num2 = num;
							num2 = (int)((ushort)num3);
						}
						num = -num4;
					}
					if (num > num)
					{
						array2[num2 + 6 - num3] = num - -1;
						if (num > num)
						{
							num2 = (int)((sbyte)num);
							num3 = (array[num4 + 9 - num3] ^ -10);
							array2[num2 + 8 - num3] = num - 1;
							num4 = -num;
							num |= 640097107;
							num3 = num + num2;
						}
						num4 = (num ^ num2);
						if (num3 > num3)
						{
							num4 = (num ^ num2);
						}
					}
					num4 = (num3 | 1982555913);
					num2 = -num;
					num2 = -num;
					if (num3 > num3)
					{
						num = array[num4 + 9 - num4] + 4;
						num4 = -num3;
						if (num2 > num2)
						{
							num4 = num2 * num;
							num3 = num * 148;
							num = num3;
						}
						if (num > num)
						{
							num4 = num2;
							num4 = (int)((byte)num3);
							num3 *= num2;
							num4 = (int)((sbyte)num4);
							*(ref num3 + (IntPtr)num2) = num2;
							*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num4) = num4;
						}
						array[num2 + 9 - num2] = num2 - 9;
						num4 = ~num2;
						num2 = num;
						num4 = (int)((short)num2);
					}
					num2 = num3 * 346;
					num4 = array[num2 + 9 - num] + 6;
					num += 677;
					num = num2;
					num4 = num + num2;
					num = -num2;
					num2 = num >> 3;
					num4 = num - num2;
					num3 = num4 * 397;
					*(ref num2 + (IntPtr)num) = num;
					num2 = num2;
				}
				return HarmonyPatches.<patched>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&HarmonyPatches.BbqwsE907N) ^ *(&HarmonyPatches.BbqwsE907N)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = *(ref num + (IntPtr)num2);
					int num3;
					if (num > num)
					{
						num3 = HarmonyPatches.WU3kLcVUpZ;
						num3 = (num & num2);
					}
					int num4;
					num2 = (num4 | num2);
					int num5;
					num3 = num5 * num2;
					num4 = num3 >> 6;
					*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num4) = num4;
					array[num + 9 - num3] = (num4 | -5);
					num5 = num3 % 189;
					num5 = num << 2;
					num = num5 / 616;
					num2 = (num4 & 1988941397);
					array[num3 + 8 - num5] = num5 - 6;
					num4 = (int)((ushort)num3);
					num5 = num4 - 353;
					array[num + 5 - num3] = num4 - 2;
					HarmonyPatches.WU3kLcVUpZ = num4;
					num2 ^= num3;
					num = 1159222519;
					num2 = -num3;
					num2 = (int)((short)num2);
					num = *(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num);
					num2 = num3 / 61;
					num3 = (num5 ^ 16744446);
					num2 = *(ref num2 + (IntPtr)num3);
					num2 ^= num3;
					*(ref num5 + (IntPtr)num2) = num2;
					array[num4 + 8 - num2] = num5 - 1;
					array[num5 + 7 - num] = (num | -9);
					array[num4 + 6 - num2] = num4 - -5;
					num5 = (num & 2099208420);
					num5 = *(ref num3 + (IntPtr)num2);
					if (num3 > num3)
					{
						*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num2) = num2;
						num4 = num >> 6;
						num4 = (int)((short)num5);
						num |= 891396152;
						num4 = num2 * 167;
						num5 = num2;
						num3 = 283369593;
					}
					num = (num5 & 2017218912);
					HarmonyPatches.WU3kLcVUpZ = num3;
					if (num > num)
					{
						num3 = ~num2;
					}
					num3 = (num & num2);
					HarmonyPatches.WU3kLcVUpZ = num4;
				}
				HarmonyPatches.<patched>k__BackingField = value;
			}
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x006353BC File Offset: 0x006335BC
		public unsafe static void Patch(bool toggle)
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			if ((*(&HarmonyPatches.u8PpHuDDMi) ^ *(&HarmonyPatches.u8PpHuDDMi)) != 0)
			{
				goto IL_24;
			}
			goto IL_19FC;
			uint num2;
			for (;;)
			{
				IL_29:
				uint num;
				switch ((num = (num2 ^ (uint)(*(&HarmonyPatches.KUAfGH2rUb)))) % (uint)(*(&HarmonyPatches.uq4v03wj4S)))
				{
				case 0U:
				{
					int num3;
					num2 = (((num3 > num3) ? 596882470U : 852201491U) ^ num * 2543348862U);
					continue;
				}
				case 1U:
					num2 = 2637865865U;
					continue;
				case 2U:
				{
					bool flag = HarmonyPatches.instance != null;
					uint num4 = num ^ (uint)(*(&HarmonyPatches.9VlGT860Pb));
					num2 = ((num4 - (uint)(*(&HarmonyPatches.62BCvt0qpO))) * (uint)(*(&HarmonyPatches.c7njMNR1HH)) ^ (uint)(*(&HarmonyPatches.x1DbpGOuXS) + *(&HarmonyPatches.f6OC8XIemI)));
					continue;
				}
				case 3U:
				{
					uint[] array = new uint[*(&HarmonyPatches.oQeEFc1zVc)];
					array[*(&HarmonyPatches.F3RewYLXRa)] = (uint)(*(&HarmonyPatches.QdoA5tifoi));
					array[*(&HarmonyPatches.Pgjnhr8NrP)] = (uint)(*(&HarmonyPatches.SfFAZpAJS5));
					array[*(&HarmonyPatches.fujbJLleIV)] = (uint)(*(&HarmonyPatches.3WLxNiTn6E));
					uint num5 = num + array[*(&HarmonyPatches.Z7pBIvYokQ)];
					uint num6 = num5 | (uint)(*(&HarmonyPatches.sZMsCe6IeW));
					num2 = (num6 - array[*(&HarmonyPatches.GeFVV5USw0)] ^ (uint)(*(&HarmonyPatches.VXMOghFhSX)));
					continue;
				}
				case 4U:
					num2 = 2150634867U;
					continue;
				case 5U:
					goto IL_24;
				case 6U:
				{
					int num7 = HarmonyPatches.WU3kLcVUpZ;
					int num8;
					int num9;
					num8 &= num9;
					int[] array2;
					int num3 = array2[num8 + 8 - num8] + 3;
					num3 = num7 >> 5;
					uint num10 = ((num | (uint)(*(&HarmonyPatches.MTUp31Ljz4))) - (uint)(*(&HarmonyPatches.ZomfeigX7l))) * (uint)(*(&HarmonyPatches.BoJm9fa12K));
					uint num11 = num10 - (uint)(*(&HarmonyPatches.eWqVaoRzsU) + *(&HarmonyPatches.9UZ70MkIG2));
					uint num12 = num11 * (uint)(*(&HarmonyPatches.TD9y6hKrpX));
					num2 = ((num12 & (uint)(*(&HarmonyPatches.bUqoaC7QF0))) ^ (uint)(*(&HarmonyPatches.QqpmmqPLwx)));
					continue;
				}
				case 7U:
				{
					uint[] array3 = new uint[*(&HarmonyPatches.hBIpxd12vT) + *(&HarmonyPatches.bfMfT7LzTY)];
					array3[*(&HarmonyPatches.h0Zb5wTq7l)] = (uint)(*(&HarmonyPatches.Iq06pBp7AN) + *(&HarmonyPatches.XDlb4jUpCG));
					array3[*(&HarmonyPatches.CAo5JrmquA)] = (uint)(*(&HarmonyPatches.JL4KKupQ0R));
					array3[*(&HarmonyPatches.SOzFBeP8gW)] = (uint)(*(&HarmonyPatches.coo0iHC4x8));
					uint num13 = num + array3[*(&HarmonyPatches.Z8N9DLJbQK)] | (uint)(*(&HarmonyPatches.3DzuyyKi3o));
					num2 = ((num13 | (uint)(*(&HarmonyPatches.bnJXifgDlC))) ^ (uint)(*(&HarmonyPatches.sud22TA0Cz)));
					continue;
				}
				case 8U:
				{
					int num9 = num9;
					int num8 = num9 + 242;
					uint num14 = num - (uint)(*(&HarmonyPatches.X2fURkCxOx));
					uint num15 = num14 | (uint)(*(&HarmonyPatches.wx4kM7obKx) + *(&HarmonyPatches.pggq976U75));
					uint num16 = num15 ^ (uint)(*(&HarmonyPatches.uXzYducjua));
					uint num17 = num16 + (uint)(*(&HarmonyPatches.eEHPVLKACO));
					num2 = (num17 - (uint)(*(&HarmonyPatches.T9w4Z1WyUU)) ^ (uint)(*(&HarmonyPatches.ns0SDZ8gHc)));
					continue;
				}
				case 9U:
					num2 = 3130239995U;
					continue;
				case 10U:
					num2 = 3357929016U;
					continue;
				case 11U:
				{
					int[] array5;
					int[] array4 = array5;
					int num18 = 3;
					int num19 = -((array5[3] - 7) % 18 + -359) * -124;
					array4[num18] = (array5[3] ^ num19 ^ (588907181 ^ num19));
					uint[] array6 = new uint[*(&HarmonyPatches.0z0vrmTcgS) + *(&HarmonyPatches.NBivq66iHR)];
					array6[*(&HarmonyPatches.EDK3I704kY)] = (uint)(*(&HarmonyPatches.Wr2qNWLJwZ));
					array6[*(&HarmonyPatches.asEcSnNuDz)] = (uint)(*(&HarmonyPatches.4H2rvwp6nu) + *(&HarmonyPatches.wY2I5fJ1iT));
					array6[*(&HarmonyPatches.vwvs0V9rle)] = (uint)(*(&HarmonyPatches.tF0vdOzK4a));
					array6[*(&HarmonyPatches.rPgCmC05gw)] = (uint)(*(&HarmonyPatches.eWMtDHWK0a));
					uint num20 = num + (uint)(*(&HarmonyPatches.x7UJBrhGor));
					uint num21 = (num20 ^ array6[*(&HarmonyPatches.p87HmgQsFy)]) | (uint)(*(&HarmonyPatches.fDLy9X2HrV) + *(&HarmonyPatches.2pTemt4WB5));
					num2 = (num21 ^ (uint)(*(&HarmonyPatches.etRyHgYEGh)) ^ (uint)(*(&HarmonyPatches.1nEB5uwfJn)));
					continue;
				}
				case 12U:
				{
					int[] array5;
					int[] array7 = array5;
					int num22 = 5;
					int num19 = array5[5] + 262 - 54;
					array7[num22] = (array5[5] ^ num19 ^ (588907181 ^ num19));
					int[] array8 = array5;
					int num23 = 6;
					num19 = (-(array5[6] % 80) & -32);
					array8[num23] = (array5[6] ^ num19 ^ (588907181 ^ num19));
					uint num24 = num & (uint)(*(&HarmonyPatches.yaZSz9ocf2));
					uint num25 = (num24 | (uint)(*(&HarmonyPatches.l3rJUvwWrd))) ^ (uint)(*(&HarmonyPatches.8yAJeOkSj2));
					uint num26 = num25 - (uint)(*(&HarmonyPatches.7YNXHDU89H));
					num2 = ((num26 | (uint)(*(&HarmonyPatches.16jO5865rJ)) | (uint)(*(&HarmonyPatches.8Zyqp9aPyk))) ^ (uint)(*(&HarmonyPatches.ZW3m5NqTBQ)));
					continue;
				}
				case 13U:
				{
					int[] array5;
					int[] array9 = array5;
					int num27 = 4;
					int num28 = (array5[4] >> 5) % 48 % 87;
					int num19 = ((45 == 0) ? (num28 - 8) : (num28 + 45)) >> 4;
					array9[num27] = (array5[4] ^ num19 ^ (588907181 ^ num19));
					num2 = 3263101587U;
					continue;
				}
				case 14U:
				{
					int num8;
					int num9;
					int num7 = num8 - num9;
					uint num29 = num + (uint)(*(&HarmonyPatches.SlqabIMZn9));
					uint num30 = num29 - (uint)(*(&HarmonyPatches.JirNx5Za4B));
					num2 = (((num30 | (uint)(*(&HarmonyPatches.1WUKTCRvjJ))) & (uint)(*(&HarmonyPatches.FeOllGLq7H))) + (uint)(*(&HarmonyPatches.gU7RDpdE1Q)) ^ (uint)(*(&HarmonyPatches.tUygO6RgGZ)));
					continue;
				}
				case 15U:
				{
					int[] array5;
					int[] array10 = array5;
					int num31 = 0;
					int num19 = ~(~(~(array5[0] ^ 432)) << 7) ^ 369;
					array10[num31] = (array5[0] ^ num19 ^ (588907181 ^ num19));
					uint num32 = (num ^ (uint)(*(&HarmonyPatches.97yvT52Ey2))) - (uint)(*(&HarmonyPatches.72CKBPo4aw) + *(&HarmonyPatches.sWoWPBr1gD));
					num2 = ((num32 | (uint)(*(&HarmonyPatches.MB5eCtLkug))) ^ (uint)(*(&HarmonyPatches.ovgtv1p990)));
					continue;
				}
				case 16U:
				{
					int num9 = ~num9;
					uint num33 = num - (uint)(*(&HarmonyPatches.u9s2b30g43) + *(&HarmonyPatches.VcUOtSzAOI)) | (uint)(*(&HarmonyPatches.zyFr9lKwDl));
					uint num34 = num33 | (uint)(*(&HarmonyPatches.2aHN4GUNfm));
					uint num35 = num34 + (uint)(*(&HarmonyPatches.6o30zuv6Ic));
					uint num36 = num35 * (uint)(*(&HarmonyPatches.KC9Kx63B20));
					num2 = (num36 + (uint)(*(&HarmonyPatches.tEcTB4UGUm) + *(&HarmonyPatches.7mflML4O2P)) ^ (uint)(*(&HarmonyPatches.0Nola0a7a8)));
					continue;
				}
				case 17U:
				{
					int[] array5;
					array5[1] = 3430532;
					uint num37 = (num * (uint)(*(&HarmonyPatches.yZZ91X7Dmn)) ^ (uint)(*(&HarmonyPatches.G9IwW5we0n) + *(&HarmonyPatches.ELazPxDgQb))) | (uint)(*(&HarmonyPatches.Wb9HiUHIaF) + *(&HarmonyPatches.Y1gsvDhvlk));
					num2 = ((num37 & (uint)(*(&HarmonyPatches.4Tph6n9ktD))) ^ (uint)(*(&HarmonyPatches.UaxLQpAAOC)));
					continue;
				}
				case 18U:
				{
					int[] array5;
					array5[10] = 2125664644;
					uint num38 = num ^ (uint)(*(&HarmonyPatches.L7R0vNIiUV) + *(&HarmonyPatches.OFkmp57kYA));
					num2 = ((num38 * (uint)(*(&HarmonyPatches.4eUOsmhrvr)) & (uint)(*(&HarmonyPatches.nDoKtqZ0XP)) & (uint)(*(&HarmonyPatches.hFG7ACyFNE) + *(&HarmonyPatches.WgQ4jqmCIJ))) ^ (uint)(*(&HarmonyPatches.qbxnrLbZ38)) ^ (uint)(*(&HarmonyPatches.fHNJdyYXNp)));
					continue;
				}
				case 19U:
				{
					int num7;
					int num9;
					int num8 = num9 % num7;
					uint num39 = num | (uint)(*(&HarmonyPatches.eEqtSlYRVy));
					uint num40 = num39 + (uint)(*(&HarmonyPatches.x5Ssmuk48m) + *(&HarmonyPatches.XnPaxwNzM6));
					uint num41 = num40 ^ (uint)(*(&HarmonyPatches.Mn3ktOTCly));
					num2 = (((num41 | (uint)(*(&HarmonyPatches.dFcghrZHqS))) & (uint)(*(&HarmonyPatches.yEhfE0zQ6g) + *(&HarmonyPatches.XjEZlJCs9X))) ^ (uint)(*(&HarmonyPatches.bhSKISLs3F)));
					continue;
				}
				case 20U:
				{
					int num8;
					int num3 = ~num8;
					uint[] array11 = new uint[*(&HarmonyPatches.ZZWVGSRGAW) + *(&HarmonyPatches.xRW8Rh2Kdh)];
					array11[*(&HarmonyPatches.0YTFx8HCvP)] = (uint)(*(&HarmonyPatches.VtyVNDh5xw));
					array11[*(&HarmonyPatches.thS6YmELzL)] = (uint)(*(&HarmonyPatches.JL6TvBGRhI));
					array11[*(&HarmonyPatches.KOUvADdBvO) + *(&HarmonyPatches.97XrxSGXqL)] = (uint)(*(&HarmonyPatches.35MjGKxejL));
					array11[*(&HarmonyPatches.6QXoleMh6V)] = (uint)(*(&HarmonyPatches.ICakMLxPfc));
					array11[*(&HarmonyPatches.4slVOPBvoz)] = (uint)(*(&HarmonyPatches.Q9bjStjsFT));
					array11[*(&HarmonyPatches.FjbVC1fmX4)] = (uint)(*(&HarmonyPatches.Xi8GRNpCaW));
					uint num42 = num + array11[*(&HarmonyPatches.cb2GEJk0Sd)] + array11[*(&HarmonyPatches.mEJMXVRQSX)] & array11[*(&HarmonyPatches.tZXucsAVSE)];
					uint num43 = num42 + (uint)(*(&HarmonyPatches.DhSs0orUQ3));
					uint num44 = num43 + array11[*(&HarmonyPatches.QpT4SSYwt5) + *(&HarmonyPatches.6ZtCnDEIoV)];
					num2 = ((num44 & array11[*(&HarmonyPatches.JPhOZFvaWs)]) ^ (uint)(*(&HarmonyPatches.o79ZHEGccJ)));
					continue;
				}
				case 21U:
				{
					int num7;
					num7 += 824;
					uint[] array12 = new uint[*(&HarmonyPatches.rdqov7SC6R)];
					array12[*(&HarmonyPatches.24dWfvBSFz)] = (uint)(*(&HarmonyPatches.BRjlosztzc));
					array12[*(&HarmonyPatches.C5wDqn7CIj)] = (uint)(*(&HarmonyPatches.NbZIOlxdGO) + *(&HarmonyPatches.swauqa4EAC));
					array12[*(&HarmonyPatches.IiNdO6IZp1)] = (uint)(*(&HarmonyPatches.x8Kfmk1aXC));
					array12[*(&HarmonyPatches.5WmltQfBXQ)] = (uint)(*(&HarmonyPatches.t3CFboO53R));
					array12[*(&HarmonyPatches.dXxOatl4IF)] = (uint)(*(&HarmonyPatches.idq7Gw6lu8));
					uint num45 = num | (uint)(*(&HarmonyPatches.bGCZI46FE7));
					num2 = (((num45 + (uint)(*(&HarmonyPatches.V5gGjiiXL9)) | array12[*(&HarmonyPatches.pk3RsPME8p) + *(&HarmonyPatches.rmL5zWUYGg)]) - array12[*(&HarmonyPatches.xgzKum7kXi) + *(&HarmonyPatches.NiavS0Nvr3)] | (uint)(*(&HarmonyPatches.s1GZQsukQM))) ^ (uint)(*(&HarmonyPatches.OKRoMIvshG)));
					continue;
				}
				case 22U:
				{
					int[] array5;
					int[] array13 = array5;
					int num46 = 12;
					int num47 = array5[12];
					int num19 = -(((109 == 0) ? (num47 - 47) : (num47 + 109)) - -139) + -226;
					array13[num46] = (array5[12] ^ num19 ^ (588907181 ^ num19));
					num2 = 2742694115U;
					continue;
				}
				case 23U:
				{
					int num9;
					num2 = (((num9 > num9) ? 4234785385U : 2874423868U) ^ num * 3042972819U);
					continue;
				}
				case 24U:
				{
					int[] array5;
					calli(System.Void(System.Boolean), 0, Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array5[18] ^ array5[19]) - array5[20]]);
					num2 = 3294438108U;
					continue;
				}
				case 25U:
				{
					int[] array5;
					array5[17] = 1652870131;
					array5[18] = 1608184552;
					array5[19] = 1024415821;
					array5[20] = 1104128755;
					num2 = (((num * (uint)(*(&HarmonyPatches.PB81UjrQF8)) ^ (uint)(*(&HarmonyPatches.u12nh5Re4B))) | (uint)(*(&HarmonyPatches.q9WEbh0Vmt))) ^ (uint)(*(&HarmonyPatches.tsJAGetQia)));
					continue;
				}
				case 26U:
				{
					bool flag2;
					num2 = (((!flag2) ? 1918898680U : 526844232U) ^ num * 1641048886U);
					continue;
				}
				case 27U:
				{
					int num9 = -num9;
					uint[] array14 = new uint[*(&HarmonyPatches.ta3eGjyNR5)];
					array14[*(&HarmonyPatches.fA1ok1tkGW)] = (uint)(*(&HarmonyPatches.ZE5v7NSav3));
					array14[*(&HarmonyPatches.7BZDEcfEFl)] = (uint)(*(&HarmonyPatches.qrCkbrEeAW));
					array14[*(&HarmonyPatches.FyI2JpfHg2)] = (uint)(*(&HarmonyPatches.RYcY8elxkH));
					uint num48 = num * array14[*(&HarmonyPatches.VofeqsBVTQ)];
					num2 = ((num48 - (uint)(*(&HarmonyPatches.IxZYxJ2g4Y) + *(&HarmonyPatches.7XiNURPol7)) & array14[*(&HarmonyPatches.FR43BbSnMa)]) ^ (uint)(*(&HarmonyPatches.oJyPtd9Dkz)));
					continue;
				}
				case 28U:
				{
					int[] array5;
					array5[13] = 718958365;
					array5[14] = 932175737;
					array5[15] = 1695835274;
					array5[16] = 613068578;
					uint num49 = (num & (uint)(*(&HarmonyPatches.F58xc9VqYc))) - (uint)(*(&HarmonyPatches.os15nJIGFm));
					uint num50 = num49 | (uint)(*(&HarmonyPatches.IYrEDYNl8C) + *(&HarmonyPatches.oZW4t44HIN));
					uint num51 = num50 | (uint)(*(&HarmonyPatches.Sira9FoVtV));
					num2 = (num51 * (uint)(*(&HarmonyPatches.fsH29rN4uD)) ^ (uint)(*(&HarmonyPatches.wurWyPW6Ms)));
					continue;
				}
				case 29U:
				{
					int[] array5;
					array5[12] = 1045401350;
					uint[] array15 = new uint[*(&HarmonyPatches.g4IYEYQPGH) + *(&HarmonyPatches.zqSzu0hO2T)];
					array15[*(&HarmonyPatches.HKMqb2kVVZ)] = (uint)(*(&HarmonyPatches.ySgCOXGaX7));
					array15[*(&HarmonyPatches.8sAKurZ8FD)] = (uint)(*(&HarmonyPatches.lLHQQVsc7M));
					array15[*(&HarmonyPatches.y43qTgJQkW)] = (uint)(*(&HarmonyPatches.tH04VZKB5t));
					array15[*(&HarmonyPatches.dlPSymKPv3)] = (uint)(*(&HarmonyPatches.pocLJDyT0N));
					array15[*(&HarmonyPatches.hIXsTdVM50)] = (uint)(*(&HarmonyPatches.LqgOsNpl2q));
					array15[*(&HarmonyPatches.V4frrFpovS) + *(&HarmonyPatches.l0LsLUNh8U)] = (uint)(*(&HarmonyPatches.R8U4s9HOd5) + *(&HarmonyPatches.YMbJ1nnqBN));
					uint num52 = num - array15[*(&HarmonyPatches.yqbmPUfyCX)] + array15[*(&HarmonyPatches.9HmhZXkk8s)];
					uint num53 = num52 & array15[*(&HarmonyPatches.7aLz4YZB0i) + *(&HarmonyPatches.rgfvfkhrpX)];
					uint num54 = num53 * array15[*(&HarmonyPatches.eTLF6Qk3ud) + *(&HarmonyPatches.CDrTQXels1)] ^ (uint)(*(&HarmonyPatches.5e7eqdl1Cz));
					num2 = ((num54 & array15[*(&HarmonyPatches.035kNnPG3n)]) ^ (uint)(*(&HarmonyPatches.xgQWfnzMeH)));
					continue;
				}
				case 30U:
				{
					int[] array5;
					calli(System.Void(System.Boolean), array5[11], Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array5[12] ^ array5[13]) - array5[14]]);
					uint[] array16 = new uint[*(&HarmonyPatches.VyrWdYy4Cu)];
					array16[*(&HarmonyPatches.6dBIgvzzai)] = (uint)(*(&HarmonyPatches.pFzOcIj71e));
					array16[*(&HarmonyPatches.xUgETm6x3J)] = (uint)(*(&HarmonyPatches.qmA0FOtVVG));
					array16[*(&HarmonyPatches.eLZdKP8c4U)] = (uint)(*(&HarmonyPatches.y1Ch7m76y3));
					array16[*(&HarmonyPatches.zB6R1DF8JN) + *(&HarmonyPatches.YOlvAm4C4E)] = (uint)(*(&HarmonyPatches.od3iUyjc3c) + *(&HarmonyPatches.QwgbRcPIlG));
					array16[*(&HarmonyPatches.K9Tq6kQQhU)] = (uint)(*(&HarmonyPatches.r5CuPVIX6D));
					uint num55 = (num - (uint)(*(&HarmonyPatches.dmFq7mrJeh))) * array16[*(&HarmonyPatches.Wwax4oKMmu)];
					uint num56 = num55 + (uint)(*(&HarmonyPatches.iS5iuVuwM6) + *(&HarmonyPatches.T1Linh4nsU));
					uint num57 = num56 | array16[*(&HarmonyPatches.2Gw975ePzl)];
					num2 = (num57 ^ (uint)(*(&HarmonyPatches.L6uMeKrg5m)) ^ (uint)(*(&HarmonyPatches.157iOfk2JW)));
					continue;
				}
				case 31U:
				{
					int num7;
					int num8 = (int)((sbyte)num7);
					uint num58 = num * (uint)(*(&HarmonyPatches.nl1yb3pQJ1)) * (uint)(*(&HarmonyPatches.KLppXHIRYY) + *(&HarmonyPatches.57GZ7jVaGA));
					num2 = (num58 * (uint)(*(&HarmonyPatches.eOqpf9TDhF)) ^ (uint)(*(&HarmonyPatches.lTELFhvcns)));
					continue;
				}
				case 32U:
				{
					int[] array5;
					array5[11] = 588907180;
					uint num59 = (num ^ (uint)(*(&HarmonyPatches.xceqVHxtlC))) + (uint)(*(&HarmonyPatches.EWrNiFSdPz));
					num2 = (num59 - (uint)(*(&HarmonyPatches.kYLOjOSGav)) - (uint)(*(&HarmonyPatches.SOycVO7HRj)) ^ (uint)(*(&HarmonyPatches.Xsy03Ja9kY)));
					continue;
				}
				case 33U:
				{
					int num3;
					int num9 = num3 >> 3;
					uint num60 = num ^ (uint)(*(&HarmonyPatches.HLiG2I2lJP));
					uint num61 = num60 ^ (uint)(*(&HarmonyPatches.BzNARwpdcd));
					uint num62 = num61 + (uint)(*(&HarmonyPatches.QSwS1UYbsp)) & (uint)(*(&HarmonyPatches.JbA9sWQomy));
					num2 = (num62 ^ (uint)(*(&HarmonyPatches.3ZiLLe4Uf7)) ^ (uint)(*(&HarmonyPatches.r6JkOzYPPi)));
					continue;
				}
				case 34U:
				{
					int num9;
					int num7 = num9 | 761595320;
					num7 = num9 / 959;
					int num3 = HarmonyPatches.WU3kLcVUpZ;
					uint[] array17 = new uint[*(&HarmonyPatches.p3x7O9K5EK)];
					array17[*(&HarmonyPatches.hfP4aUXmxp)] = (uint)(*(&HarmonyPatches.BjoUEFglA7));
					array17[*(&HarmonyPatches.1mB2UQdQeq)] = (uint)(*(&HarmonyPatches.hXmf5OphiZ) + *(&HarmonyPatches.RMIvHGPd3J));
					array17[*(&HarmonyPatches.cj4GT5eWkJ)] = (uint)(*(&HarmonyPatches.0HHGHn6JZz));
					array17[*(&HarmonyPatches.Z8ClqodPvN)] = (uint)(*(&HarmonyPatches.BAWVO7cfMA));
					array17[*(&HarmonyPatches.tS7ZiKECod)] = (uint)(*(&HarmonyPatches.JFEDtdhTao));
					uint num63 = (num ^ array17[*(&HarmonyPatches.bPlWI0uw2J)]) - array17[*(&HarmonyPatches.Lb7ZGGBnDg)];
					num2 = (((num63 ^ (uint)(*(&HarmonyPatches.kblSE56Tlu))) | array17[*(&HarmonyPatches.aJFhierlRr) + *(&HarmonyPatches.ZSKeRsIo6m)] | (uint)(*(&HarmonyPatches.c3Q4EAoSSM))) ^ (uint)(*(&HarmonyPatches.3bKHsCWZ0l)));
					continue;
				}
				case 35U:
				{
					int num9;
					int num8 = -num9;
					uint[] array18 = new uint[*(&HarmonyPatches.OYw0ciSvUh)];
					array18[*(&HarmonyPatches.15zfwHrYoM)] = (uint)(*(&HarmonyPatches.etHSFrfSV6));
					array18[*(&HarmonyPatches.bTSzXCCJZ6)] = (uint)(*(&HarmonyPatches.RU3a8zPYuE) + *(&HarmonyPatches.PJh7MfQevu));
					array18[*(&HarmonyPatches.C9aYGinAIt)] = (uint)(*(&HarmonyPatches.Fh9s4JzqTP));
					uint num64 = num - array18[*(&HarmonyPatches.bHiQqSwUm1)] ^ array18[*(&HarmonyPatches.vhXo4R4fUa)];
					num2 = (num64 ^ (uint)(*(&HarmonyPatches.MPPA9rJzCC)) ^ (uint)(*(&HarmonyPatches.pkLgS4bJry)));
					continue;
				}
				case 36U:
				{
					int[] array5;
					int[] array19 = array5;
					int num65 = 19;
					int num19 = (array5[19] * -494 + 401) * -199;
					array19[num65] = (array5[19] ^ num19 ^ (588907181 ^ num19));
					int[] array20 = array5;
					int num66 = 20;
					num19 = -(array5[20] % 61 ^ -391);
					array20[num66] = (array5[20] ^ num19 ^ (588907181 ^ num19));
					uint[] array21 = new uint[*(&HarmonyPatches.Uv15ZbEiZG) + *(&HarmonyPatches.pvXWMZCgb3)];
					array21[*(&HarmonyPatches.zfye8HvOC0)] = (uint)(*(&HarmonyPatches.bdbJAuOZgL));
					array21[*(&HarmonyPatches.YlH75NNawd)] = (uint)(*(&HarmonyPatches.MJEoyz7W6S));
					array21[*(&HarmonyPatches.pzgioMUOWc)] = (uint)(*(&HarmonyPatches.LnAQeOX1iv));
					array21[*(&HarmonyPatches.4VcioRZwVK) + *(&HarmonyPatches.x1dOgjEjSt)] = (uint)(*(&HarmonyPatches.28EURiJyJj));
					array21[*(&HarmonyPatches.bGxKYUW73W)] = (uint)(*(&HarmonyPatches.xh3LpTKwu5));
					array21[*(&HarmonyPatches.Jyiz35RIRF)] = (uint)(*(&HarmonyPatches.IknvsqESzL));
					uint num67 = (num ^ array21[*(&HarmonyPatches.MGp56VF2p7)]) & array21[*(&HarmonyPatches.YXEOanh8Rd)];
					uint num68 = num67 + array21[*(&HarmonyPatches.COqyOM4Hc8)] ^ array21[*(&HarmonyPatches.P16isDIn2h)];
					num2 = (((num68 | (uint)(*(&HarmonyPatches.zYdTrvfYVF))) & (uint)(*(&HarmonyPatches.JGBWI7Z1qt))) ^ (uint)(*(&HarmonyPatches.b7ZqsgagfW)));
					continue;
				}
				case 37U:
				{
					uint[] array22 = new uint[*(&HarmonyPatches.p65Aed2HPX)];
					array22[*(&HarmonyPatches.RDp70OQxFV)] = (uint)(*(&HarmonyPatches.SYQRcIAMMI));
					array22[*(&HarmonyPatches.pP2cFsDwco)] = (uint)(*(&HarmonyPatches.yfhYTE22DU));
					array22[*(&HarmonyPatches.Uumt2RqohV)] = (uint)(*(&HarmonyPatches.dq5GsBKM2H) + *(&HarmonyPatches.KdUbgx017X));
					array22[*(&HarmonyPatches.QII2y5mIjy) + *(&HarmonyPatches.CZOHKIjbqR)] = (uint)(*(&HarmonyPatches.3pA6J0ZLMF) + *(&HarmonyPatches.ayqKEUhDSx));
					uint num69 = num | (uint)(*(&HarmonyPatches.ZCnDFvPNQY));
					uint num70 = num69 + array22[*(&HarmonyPatches.NZLqdlIMs7)];
					num2 = ((num70 * array22[*(&HarmonyPatches.fb5eXOtDCz)] | array22[*(&HarmonyPatches.lfI311C60Y)]) ^ (uint)(*(&HarmonyPatches.lL4y1Bn9qd)));
					continue;
				}
				case 38U:
					num2 = ((toggle ? 2274825875U : 3063339487U) ^ num * 3273323438U);
					continue;
				case 39U:
				{
					int num3 = *(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num3);
					int num8;
					int num7 = *(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num8);
					uint num71 = (num | (uint)(*(&HarmonyPatches.WFI3HIGXf2))) - (uint)(*(&HarmonyPatches.ZCFFb3AD4X)) & (uint)(*(&HarmonyPatches.prIT0QvXWv));
					num2 = (num71 - (uint)(*(&HarmonyPatches.pGX1JRaLSd)) - (uint)(*(&HarmonyPatches.CoMG7YcMsO)) ^ (uint)(*(&HarmonyPatches.SIyfZp6zD0) + *(&HarmonyPatches.WtBtNSpO5J)));
					continue;
				}
				case 40U:
				{
					int[] array5;
					int[] array23 = array5;
					int num72 = 17;
					int num19 = (array5[17] ^ -179) - 73 | 478;
					array23[num72] = (array5[17] ^ num19 ^ (588907181 ^ num19));
					int[] array24 = array5;
					int num73 = 18;
					int num74 = -array5[18];
					int num76;
					int num75 = (-103 == 0) ? (num76 = num74 - 42) : (num76 = num74 + -103);
					num19 = (((-406 == 0) ? (num75 - 59) : (num76 + -406)) >> 4 & 29);
					array24[num73] = (array5[18] ^ num19 ^ (588907181 ^ num19));
					num2 = 3233417947U;
					continue;
				}
				case 41U:
				{
					int num8;
					num8 |= 782942219;
					uint[] array25 = new uint[*(&HarmonyPatches.UTAWWSWYxT)];
					array25[*(&HarmonyPatches.Ju0I0WEGyJ)] = (uint)(*(&HarmonyPatches.AxW8XIbW1h));
					array25[*(&HarmonyPatches.c4qUUM5vVR)] = (uint)(*(&HarmonyPatches.7UP6pMp40y));
					array25[*(&HarmonyPatches.v614xg7C9O)] = (uint)(*(&HarmonyPatches.09gP0PDfyn));
					array25[*(&HarmonyPatches.bTuhLqhZSK)] = (uint)(*(&HarmonyPatches.cggCwgCwgx));
					array25[*(&HarmonyPatches.P2vHa7x9Ga)] = (uint)(*(&HarmonyPatches.IJGMXbLUsG));
					array25[*(&HarmonyPatches.8htzvTcedT) + *(&HarmonyPatches.MR8BXihnGO)] = (uint)(*(&HarmonyPatches.3iT2BSaUoU) + *(&HarmonyPatches.VsDayrI6WH));
					uint num77 = num - array25[*(&HarmonyPatches.eSgxO1LEyz)] & array25[*(&HarmonyPatches.4hNeMaO1xc)];
					uint num78 = num77 ^ array25[*(&HarmonyPatches.2IzI8dOiMp)];
					num2 = ((num78 - (uint)(*(&HarmonyPatches.ZkQ9tkBgoK)) + (uint)(*(&HarmonyPatches.HWfzaxejNX)) | array25[*(&HarmonyPatches.dRJ4OVdYyu)]) ^ (uint)(*(&HarmonyPatches.mm1JZTROum)));
					continue;
				}
				case 42U:
				{
					int num3;
					int num9 = num3 ^ num9;
					uint[] array26 = new uint[*(&HarmonyPatches.NrY9XSe57I)];
					array26[*(&HarmonyPatches.5yobQAsQIU)] = (uint)(*(&HarmonyPatches.6ysU3hDhSA));
					array26[*(&HarmonyPatches.0lDL3TZp2h)] = (uint)(*(&HarmonyPatches.dOjhvz6ICs));
					array26[*(&HarmonyPatches.GoyN1Y8DFz)] = (uint)(*(&HarmonyPatches.O7n6SUudi7));
					array26[*(&HarmonyPatches.lCXl0sOLjD)] = (uint)(*(&HarmonyPatches.k5ej3Mw0Ue));
					array26[*(&HarmonyPatches.UVkDSflmOb)] = (uint)(*(&HarmonyPatches.FdkFHERNWI));
					uint num79 = num | array26[*(&HarmonyPatches.JxeBOTdDDG)];
					uint num80 = num79 ^ (uint)(*(&HarmonyPatches.h4JDmPbTTU));
					num2 = (((num80 * (uint)(*(&HarmonyPatches.Hm6I8HUYcy)) ^ array26[*(&HarmonyPatches.4jdLVh1jy8)]) | array26[*(&HarmonyPatches.ChjI3LUhd1) + *(&HarmonyPatches.m74CAh1VCH)]) ^ (uint)(*(&HarmonyPatches.8FlOL8a7sF)));
					continue;
				}
				case 43U:
				{
					uint[] array27 = new uint[*(&HarmonyPatches.dpJqz7oNEf)];
					array27[*(&HarmonyPatches.8wUHKP1ViH)] = (uint)(*(&HarmonyPatches.hithqDkhaP));
					array27[*(&HarmonyPatches.wqtwnpZV52)] = (uint)(*(&HarmonyPatches.DaOVu1SXnw));
					array27[*(&HarmonyPatches.tWXJD46m9v)] = (uint)(*(&HarmonyPatches.WGwytSChdf));
					uint num81 = num ^ (uint)(*(&HarmonyPatches.0fapEGUXwy));
					num2 = (num81 - (uint)(*(&HarmonyPatches.vN4ogZTkss)) ^ array27[*(&HarmonyPatches.swVJf6oalc)] ^ (uint)(*(&HarmonyPatches.yu3I6N6rF7)));
					continue;
				}
				case 44U:
				{
					uint num82 = num - (uint)(*(&HarmonyPatches.e4FtnnvXHd));
					uint num83 = num82 - (uint)(*(&HarmonyPatches.qfwXzIzjZv));
					num2 = (num83 * (uint)(*(&HarmonyPatches.nR6IG19wkK)) - (uint)(*(&HarmonyPatches.U928kOAStf)) + (uint)(*(&HarmonyPatches.MCtND5LC1k)) ^ (uint)(*(&HarmonyPatches.q0GutN77nv) + *(&HarmonyPatches.o8w6Irnxwk)) ^ (uint)(*(&HarmonyPatches.Hh04ikhsFK)));
					continue;
				}
				case 45U:
				{
					int[] array5;
					int[] array28 = array5;
					int num84 = 14;
					int num85 = array5[14];
					int num19 = ~(((-136 == 0) ? (num85 - 8) : (num85 + -136)) + 49 - -264 ^ 78) * 102;
					array28[num84] = (array5[14] ^ num19 ^ (588907181 ^ num19));
					int[] array29 = array5;
					int num86 = 15;
					int num87 = array5[15] % 90 * -332;
					num19 = ((-162 == 0) ? (num87 - 66) : (num87 + -162));
					array29[num86] = (array5[15] ^ num19 ^ (588907181 ^ num19));
					int[] array30 = array5;
					int num88 = 16;
					num19 = (array5[16] - -227 | -218) % 72;
					array30[num88] = (array5[16] ^ num19 ^ (588907181 ^ num19));
					num2 = 2487162391U;
					continue;
				}
				case 46U:
					goto IL_19FC;
				case 47U:
				{
					int[] array5;
					array5[2] = 1949411305;
					array5[3] = 588907181;
					array5[4] = 588907509;
					uint[] array31 = new uint[*(&HarmonyPatches.xoDuOMosDM) + *(&HarmonyPatches.QS5qgDvbL4)];
					array31[*(&HarmonyPatches.VgYWv8EVbG)] = (uint)(*(&HarmonyPatches.CggiwQP4Tt));
					array31[*(&HarmonyPatches.8QhhxCeHoN)] = (uint)(*(&HarmonyPatches.3jyTrRQr9Q));
					array31[*(&HarmonyPatches.ITQ7JtvX3Q)] = (uint)(*(&HarmonyPatches.x1Hc6E90it));
					array31[*(&HarmonyPatches.d6rOMdsM1e)] = (uint)(*(&HarmonyPatches.9i5Dlp9jYE));
					array31[*(&HarmonyPatches.QHNXZCbWXm) + *(&HarmonyPatches.RZIQwMmCuq)] = (uint)(*(&HarmonyPatches.BifZRP6E0Q));
					uint num89 = (num & array31[*(&HarmonyPatches.EZbdcVsTyJ)]) * array31[*(&HarmonyPatches.BVzPNjZoQZ)];
					uint num90 = num89 ^ array31[*(&HarmonyPatches.D7zsDrmyGK)];
					num2 = (num90 - (uint)(*(&HarmonyPatches.GXfGh18oxb)) ^ (uint)(*(&HarmonyPatches.dSNkoptQMr)) ^ (uint)(*(&HarmonyPatches.zRybNHktav)));
					continue;
				}
				case 48U:
				{
					int num7;
					int num8 = num7 + 280;
					int num3;
					num2 = (((num3 > num3) ? 3520832461U : 3205751357U) ^ num * 2193470625U);
					continue;
				}
				case 49U:
				{
					int[] array5;
					HarmonyPatches.instance.PatchAll(calli(System.Reflection.Assembly(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array5[8] ^ array5[9]) - array5[10]]));
					num2 = 4173324440U;
					continue;
				}
				case 50U:
					num2 = 2939095751U;
					continue;
				case 51U:
				{
					int num8;
					int num9 = num8;
					int num7;
					num7 |= num9;
					uint num91 = num - (uint)(*(&HarmonyPatches.vSXQ8hKUyn));
					num2 = (num91 + (uint)(*(&HarmonyPatches.PUW3DM2hQ8) + *(&HarmonyPatches.I7SjMLW1W9)) + (uint)(*(&HarmonyPatches.0vygo418Cc)) ^ (uint)(*(&HarmonyPatches.hyAZxVORcG)));
					continue;
				}
				case 52U:
					num2 = 3532849661U;
					continue;
				case 53U:
				{
					int[] array5 = new int[23];
					uint num92 = (num - (uint)(*(&HarmonyPatches.fFckvByoTU) + *(&HarmonyPatches.T5IKdl8BR2))) * (uint)(*(&HarmonyPatches.rUO1TbUtT0)) + (uint)(*(&HarmonyPatches.eyTGwVQZAg));
					num2 = (((num92 ^ (uint)(*(&HarmonyPatches.C9q4AkxrPf) + *(&HarmonyPatches.y3GXzL1kQU))) & (uint)(*(&HarmonyPatches.qFVd0elBXH))) ^ (uint)(*(&HarmonyPatches.ViBuzrnT1t)) ^ (uint)(*(&HarmonyPatches.nmexCks5Rl)));
					continue;
				}
				case 54U:
				{
					int num7;
					int num9;
					*(ref num7 + (IntPtr)num9) = num9;
					num2 = 3324614265U;
					continue;
				}
				case 55U:
				{
					int[] array2 = new int[10];
					int num8;
					num2 = (((num8 > num8) ? 2693841336U : 3071683086U) ^ num * 616992720U);
					continue;
				}
				case 56U:
				{
					int[] array5;
					num2 = (((calli(System.Boolean(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array5[0] ^ array5[1]) - array5[2]]) == array5[3]) ? 1653261480U : 810915366U) ^ num * 479682175U);
					continue;
				}
				case 57U:
				{
					int num3;
					*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num3) = num3;
					uint[] array32 = new uint[*(&HarmonyPatches.4RuA0bW2Y2)];
					array32[*(&HarmonyPatches.djJU3pouhx)] = (uint)(*(&HarmonyPatches.OUCQlmXXMQ));
					array32[*(&HarmonyPatches.S952cJjqy9)] = (uint)(*(&HarmonyPatches.pE1NWrhUt6));
					array32[*(&HarmonyPatches.Cen9ikPeZN)] = (uint)(*(&HarmonyPatches.D9qIkeoQ1t));
					array32[*(&HarmonyPatches.G76iHKcz34)] = (uint)(*(&HarmonyPatches.FCnQNxV6U2));
					array32[*(&HarmonyPatches.4FQk5qYtm2)] = (uint)(*(&HarmonyPatches.CQdA0EiE1Y));
					uint num93 = num + array32[*(&HarmonyPatches.IZkfHAWa5x)] ^ array32[*(&HarmonyPatches.Is69yArVnb)];
					uint num94 = (num93 | array32[*(&HarmonyPatches.vtNA1zjnZJ) + *(&HarmonyPatches.OQE6tfevc4)]) * (uint)(*(&HarmonyPatches.U8yzuUTdLz));
					num2 = (num94 ^ (uint)(*(&HarmonyPatches.XNbamZMjnS)) ^ (uint)(*(&HarmonyPatches.bsAwi1n9PT) + *(&HarmonyPatches.f52sHw5XQg)));
					continue;
				}
				case 58U:
				{
					bool flag;
					num2 = ((flag ? 3554002738U : 2384131947U) ^ num * 3085519118U);
					continue;
				}
				case 59U:
				{
					int[] array5;
					int[] array33 = array5;
					int num95 = 1;
					int num19 = -array5[1] * 236;
					array33[num95] = (array5[1] ^ num19 ^ (588907181 ^ num19));
					int[] array34 = array5;
					int num96 = 2;
					int num97 = -(~array5[2]);
					num19 = ((-281 == 0) ? (num97 - 31) : (num97 + -281)) * -474 >> 6;
					array34[num96] = (array5[2] ^ num19 ^ (588907181 ^ num19));
					num2 = 3829148692U;
					continue;
				}
				case 60U:
				{
					int[] array5;
					int[] array35 = array5;
					int num98 = 13;
					int num19 = ((array5[13] % 52 | 289) % 53 << 6) * -449;
					array35[num98] = (array5[13] ^ num19 ^ (588907181 ^ num19));
					uint num99 = num * (uint)(*(&HarmonyPatches.vnBSSuvesX));
					uint num100 = num99 - (uint)(*(&HarmonyPatches.mJl4nXn72H));
					uint num101 = (num100 - (uint)(*(&HarmonyPatches.9SdfOqvKrt)) | (uint)(*(&HarmonyPatches.eXcFW9C1G7))) & (uint)(*(&HarmonyPatches.siN4GIA9wV));
					num2 = (num101 + (uint)(*(&HarmonyPatches.gFU5ncKgDl)) ^ (uint)(*(&HarmonyPatches.8lw92Pqghn)));
					continue;
				}
				case 61U:
				{
					int[] array5;
					array5[6] = 1663693209;
					array5[7] = 1510940780;
					array5[8] = 1821104188;
					uint[] array36 = new uint[*(&HarmonyPatches.FvzRDWh0HX)];
					array36[*(&HarmonyPatches.qJqDh7xvTR)] = (uint)(*(&HarmonyPatches.aiiaC5jLOT));
					array36[*(&HarmonyPatches.QPQU5EKRxs)] = (uint)(*(&HarmonyPatches.gj2IvNpmez));
					array36[*(&HarmonyPatches.kgeBxgNYOI)] = (uint)(*(&HarmonyPatches.xVlxHb2WHd));
					array36[*(&HarmonyPatches.xg8lu1qZpz)] = (uint)(*(&HarmonyPatches.P7rZttvPgY));
					num2 = ((num * (uint)(*(&HarmonyPatches.0vCp4L7EBU)) + (uint)(*(&HarmonyPatches.UTeABDi3R6) + *(&HarmonyPatches.0ytZ20oMDX)) + array36[*(&HarmonyPatches.pnztnBdTqj) + *(&HarmonyPatches.3lYVe6cqXp)] | (uint)(*(&HarmonyPatches.L27kiBCnwE))) ^ (uint)(*(&HarmonyPatches.gvBoorduWA) + *(&HarmonyPatches.kOMrCOaX45)));
					continue;
				}
				case 62U:
				{
					HarmonyPatches.instance.UnpatchSelf();
					uint[] array37 = new uint[*(&HarmonyPatches.ev9Vu1YjIt)];
					array37[*(&HarmonyPatches.mFMLndCdad)] = (uint)(*(&HarmonyPatches.lFo6hHtUuO));
					array37[*(&HarmonyPatches.MGs9j17OEe)] = (uint)(*(&HarmonyPatches.sXRq6Bbf2R));
					array37[*(&HarmonyPatches.J2womYGCyn)] = (uint)(*(&HarmonyPatches.HEy3gfWNmw));
					array37[*(&HarmonyPatches.fxZ5uOy7Af)] = (uint)(*(&HarmonyPatches.qObdFUUEXK));
					array37[*(&HarmonyPatches.u5aaXoiXKa) + *(&HarmonyPatches.pN3GwVc03X)] = (uint)(*(&HarmonyPatches.kIBT63mVyM));
					uint num102 = num ^ (uint)(*(&HarmonyPatches.LS0cCjX8iG));
					num2 = ((num102 * (uint)(*(&HarmonyPatches.paxk0cUVru)) * (uint)(*(&HarmonyPatches.1eK9kl4Hee)) ^ (uint)(*(&HarmonyPatches.BNj8PXXbEM))) - (uint)(*(&HarmonyPatches.8dSxsJVade)) ^ (uint)(*(&HarmonyPatches.iRoEUrH01a)));
					continue;
				}
				case 63U:
				{
					int[] array5;
					int[] array38 = array5;
					int num103 = 11;
					int num104 = array5[11];
					int num106;
					int num105 = (156 == 0) ? (num106 = num104 - 26) : (num106 = num104 + 156);
					int num19 = -(-((-473 == 0) ? (num105 - 41) : (num106 + -473)) ^ -296);
					array38[num103] = (array5[11] ^ num19 ^ (588907181 ^ num19));
					num2 = 3362753065U;
					continue;
				}
				case 64U:
				{
					int num3;
					num2 = (((num3 > num3) ? 1725171612U : 1373149686U) ^ num * 3644308206U);
					continue;
				}
				case 65U:
				{
					int[] array5;
					bool flag3 = calli(System.Boolean(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array5[15] ^ array5[16]) - array5[17]]);
					uint[] array39 = new uint[*(&HarmonyPatches.z9muJCrC4G)];
					array39[*(&HarmonyPatches.qEsIoFzjWo)] = (uint)(*(&HarmonyPatches.eGTWtgtklz));
					array39[*(&HarmonyPatches.ExP8RxOTSn)] = (uint)(*(&HarmonyPatches.YL0QmaNGY3));
					array39[*(&HarmonyPatches.ijH7otqQAn)] = (uint)(*(&HarmonyPatches.TGbEB3zu00));
					array39[*(&HarmonyPatches.0fRtPTPCuT)] = (uint)(*(&HarmonyPatches.SnMrRfpSUh));
					array39[*(&HarmonyPatches.H8SoURuvOs)] = (uint)(*(&HarmonyPatches.ldPhCCRXrU));
					array39[*(&HarmonyPatches.engrUq4txg) + *(&HarmonyPatches.NhZSt2NmZ8)] = (uint)(*(&HarmonyPatches.idxBszXopP));
					uint num107 = num - (uint)(*(&HarmonyPatches.NRk9DdckUn));
					uint num108 = num107 + (uint)(*(&HarmonyPatches.XA8sfDD6xK));
					uint num109 = num108 - (uint)(*(&HarmonyPatches.yo8twA0f9f));
					uint num110 = num109 ^ (uint)(*(&HarmonyPatches.SPEiS66aPQ));
					num2 = (((num110 & (uint)(*(&HarmonyPatches.anSvkifEfo))) | array39[*(&HarmonyPatches.vb1eajT1ND) + *(&HarmonyPatches.m6kyVH6Zai)]) ^ (uint)(*(&HarmonyPatches.HnrguLWMIN)));
					continue;
				}
				case 66U:
				{
					int[] array5;
					array5[9] = 824364361;
					uint num111 = num - (uint)(*(&HarmonyPatches.X7yXLxpPLl)) ^ (uint)(*(&HarmonyPatches.8zgmCIktrw));
					uint num112 = num111 ^ (uint)(*(&HarmonyPatches.crTWF6pPhT));
					num2 = (num112 - (uint)(*(&HarmonyPatches.los1qi6nc0)) + (uint)(*(&HarmonyPatches.BOjvBusjp4) + *(&HarmonyPatches.oqqIcpobSO)) ^ (uint)(*(&HarmonyPatches.IZr2AUGo5e)));
					continue;
				}
				case 67U:
				{
					int num8;
					int num9 = num8;
					uint[] array40 = new uint[*(&HarmonyPatches.tp8L2FrEqA) + *(&HarmonyPatches.5QoqAMseJi)];
					array40[*(&HarmonyPatches.366Rtx0nZg)] = (uint)(*(&HarmonyPatches.HLcJ04M284));
					array40[*(&HarmonyPatches.K1WogHlKpM)] = (uint)(*(&HarmonyPatches.4uXAjxsqbF));
					array40[*(&HarmonyPatches.ODoJ3uxf0F)] = (uint)(*(&HarmonyPatches.A0fOYCkSvm));
					array40[*(&HarmonyPatches.Lp8NmXxcjC) + *(&HarmonyPatches.Lfa2pGNMvw)] = (uint)(*(&HarmonyPatches.TFUjMDOJlh) + *(&HarmonyPatches.Ma5z3jFahf));
					uint num113 = (num & array40[*(&HarmonyPatches.6V6x3eZniR)]) * array40[*(&HarmonyPatches.yXg8SGVYBi)];
					num2 = (num113 * (uint)(*(&HarmonyPatches.Io0Bzvjl8G)) * (uint)(*(&HarmonyPatches.BxpQz8Jhqr)) ^ (uint)(*(&HarmonyPatches.olkTtz47hx)));
					continue;
				}
				case 68U:
				{
					int num9;
					int num7 = -num9;
					uint[] array41 = new uint[*(&HarmonyPatches.lE2LJ7GSKZ)];
					array41[*(&HarmonyPatches.cWtWK03gXW)] = (uint)(*(&HarmonyPatches.0OUeuxjSd0) + *(&HarmonyPatches.SMEwVBZstD));
					array41[*(&HarmonyPatches.UAdw7SacF2)] = (uint)(*(&HarmonyPatches.jcpN8WtYbW));
					array41[*(&HarmonyPatches.YyyTGQR6AI)] = (uint)(*(&HarmonyPatches.bLxUCzvhgc) + *(&HarmonyPatches.XHNkQzg0y9));
					uint num114 = num & array41[*(&HarmonyPatches.SARXpgMJqr)] & array41[*(&HarmonyPatches.Adb6bYpVLI)];
					num2 = ((num114 & array41[*(&HarmonyPatches.lL298QkODQ)]) ^ (uint)(*(&HarmonyPatches.taIB0a4aof)));
					continue;
				}
				case 69U:
				{
					int num7;
					int num9;
					*(ref num7 + (IntPtr)num9) = num9;
					uint[] array42 = new uint[*(&HarmonyPatches.UOlWIoxQFw)];
					array42[*(&HarmonyPatches.jiq4tAHEfN)] = (uint)(*(&HarmonyPatches.g7ZAR8ZT5i));
					array42[*(&HarmonyPatches.7lpeB4oLGu)] = (uint)(*(&HarmonyPatches.RfVjIFREqG));
					array42[*(&HarmonyPatches.6B7PnWzkEJ)] = (uint)(*(&HarmonyPatches.OeUgz83L3y));
					uint num115 = num + (uint)(*(&HarmonyPatches.W68u5Amz1M));
					num2 = ((num115 | (uint)(*(&HarmonyPatches.rVnyl5na0o))) - (uint)(*(&HarmonyPatches.FDG7gwKyuK)) ^ (uint)(*(&HarmonyPatches.MFL1uADNTn)));
					continue;
				}
				case 70U:
				{
					int num7;
					int num9 = (int)((ushort)num7);
					int num3 = num9;
					num3 = ~num3;
					num2 = ((num - (uint)(*(&HarmonyPatches.d8YgjrMWkV))) * (uint)(*(&HarmonyPatches.QMayc6NlvP) + *(&HarmonyPatches.8vpr1G7Q4k)) + (uint)(*(&HarmonyPatches.llWdXUQTxx)) + (uint)(*(&HarmonyPatches.A8kunqicB9) + *(&HarmonyPatches.KRNtqsSqpd)) ^ (uint)(*(&HarmonyPatches.t5b9tpz6bI)));
					continue;
				}
				case 71U:
				{
					int num8;
					int num9 = num8 * num9;
					uint num116 = num ^ (uint)(*(&HarmonyPatches.1a0d3pUGmr));
					uint num117 = num116 + (uint)(*(&HarmonyPatches.utdxegYCHo));
					uint num118 = num117 ^ (uint)(*(&HarmonyPatches.jN4SavprWp));
					num2 = (num118 - (uint)(*(&HarmonyPatches.yojiPGdeXX)) ^ (uint)(*(&HarmonyPatches.UXcJg90BBr)));
					continue;
				}
				case 72U:
				{
					int[] array5;
					array5[5] = 440193860;
					uint num119 = num * (uint)(*(&HarmonyPatches.t4NoDozsrV)) - (uint)(*(&HarmonyPatches.lv1y5vtODX));
					uint num120 = num119 ^ (uint)(*(&HarmonyPatches.8VmZVziD3a));
					uint num121 = num120 * (uint)(*(&HarmonyPatches.ROOBriEjhA));
					num2 = ((num121 | (uint)(*(&HarmonyPatches.zAi0FDZ9fc))) ^ (uint)(*(&HarmonyPatches.XWpCxXSySN)));
					continue;
				}
				case 73U:
				{
					int[] array5;
					int[] array43 = array5;
					int num122 = 10;
					int num19 = (-(~array5[10]) | -166) + -132 << 4;
					array43[num122] = (array5[10] ^ num19 ^ (588907181 ^ num19));
					uint num123 = (num & (uint)(*(&HarmonyPatches.bxWkmCOwNg))) ^ (uint)(*(&HarmonyPatches.SpkZ4hkgsH));
					num2 = (num123 * (uint)(*(&HarmonyPatches.nEJYreC6Ss)) ^ (uint)(*(&HarmonyPatches.Rm3asKCNDn)));
					continue;
				}
				case 74U:
				{
					int num3;
					int num7 = -num3;
					uint[] array44 = new uint[*(&HarmonyPatches.JQv8EsAmsP) + *(&HarmonyPatches.K1SQcKiSVV)];
					array44[*(&HarmonyPatches.xBjqhw9WLZ)] = (uint)(*(&HarmonyPatches.YRvSRpzGAu));
					array44[*(&HarmonyPatches.NJ7Myp7h21)] = (uint)(*(&HarmonyPatches.C3Cf6HqEaR));
					array44[*(&HarmonyPatches.sobT02FA9w)] = (uint)(*(&HarmonyPatches.VcSlInEX12));
					array44[*(&HarmonyPatches.zcdTWfPPVJ)] = (uint)(*(&HarmonyPatches.8upsBjroV6));
					array44[*(&HarmonyPatches.j7iGgjlbXS)] = (uint)(*(&HarmonyPatches.DTMicQKH6V));
					array44[*(&HarmonyPatches.n0ozxkxjji)] = (uint)(*(&HarmonyPatches.6ZB5S23Xww));
					uint num124 = num | (uint)(*(&HarmonyPatches.3x1CFphGQv)) | (uint)(*(&HarmonyPatches.ZjrASsSsT5));
					uint num125 = num124 + (uint)(*(&HarmonyPatches.wB2zWnRRQk));
					num2 = (((num125 ^ (uint)(*(&HarmonyPatches.WwVKbz9mtH))) & (uint)(*(&HarmonyPatches.DqTyJWsBmj)) & array44[*(&HarmonyPatches.kKE0A25Cpc)]) ^ (uint)(*(&HarmonyPatches.XQ0pYmOhjd)));
					continue;
				}
				case 75U:
				{
					int[] array5;
					HarmonyPatches.instance = new Harmony(calli(System.Object(System.Int32), lDwvHqL9gN.JDHAGENDM[array5[4]], Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array5[5] ^ array5[6]) - array5[7]]));
					uint[] array45 = new uint[*(&HarmonyPatches.kSGYdqGx9C)];
					array45[*(&HarmonyPatches.0XQsUEddRP)] = (uint)(*(&HarmonyPatches.powFAL7Jov));
					array45[*(&HarmonyPatches.CULYaaZish)] = (uint)(*(&HarmonyPatches.RzBaR2p6jS));
					array45[*(&HarmonyPatches.Z2Sln6fAXR)] = (uint)(*(&HarmonyPatches.s6IOAfL2R3) + *(&HarmonyPatches.o4ut80mWyI));
					array45[*(&HarmonyPatches.gBjWVJCkud)] = (uint)(*(&HarmonyPatches.4YLbyUqwav));
					array45[*(&HarmonyPatches.qwoqnfHinx) + *(&HarmonyPatches.TJMPurXv20)] = (uint)(*(&HarmonyPatches.dlHx8PtT5n));
					uint num126 = (num + array45[*(&HarmonyPatches.Jz6CbuX2t0)] ^ (uint)(*(&HarmonyPatches.Bd77KvM5qH))) | (uint)(*(&HarmonyPatches.744jSFp0sX));
					uint num127 = num126 * array45[*(&HarmonyPatches.vyn9ndNKxA)];
					num2 = ((num127 & array45[*(&HarmonyPatches.TeCCy9oJnM) + *(&HarmonyPatches.DxnxqP5WuW)]) ^ (uint)(*(&HarmonyPatches.EhKVEN07Tr)));
					continue;
				}
				case 76U:
					num2 = 3967084597U;
					continue;
				case 77U:
				{
					int num7;
					num2 = (((num7 > num7) ? 481882317U : 1600076276U) ^ num * 1610809669U);
					continue;
				}
				case 78U:
				{
					int num7;
					int num8 = num7 & 2028247194;
					uint[] array46 = new uint[*(&HarmonyPatches.hOYczngiCI) + *(&HarmonyPatches.9mt62FJ5hY)];
					array46[*(&HarmonyPatches.C4ptTMvuwb)] = (uint)(*(&HarmonyPatches.4oqoHjQHsm));
					array46[*(&HarmonyPatches.j5bOYrnfRb)] = (uint)(*(&HarmonyPatches.z5enonjpIm) + *(&HarmonyPatches.2vwlOV6EzS));
					array46[*(&HarmonyPatches.zBM5yHcaVl)] = (uint)(*(&HarmonyPatches.iQdVl8JC9e));
					array46[*(&HarmonyPatches.Al9FtyJ0AC)] = (uint)(*(&HarmonyPatches.vip8lytjzh));
					array46[*(&HarmonyPatches.LITgDmSaAQ)] = (uint)(*(&HarmonyPatches.L4EVSNCGL9));
					uint num128 = num - (uint)(*(&HarmonyPatches.7laS0Aketx));
					num2 = ((num128 ^ array46[*(&HarmonyPatches.OkNcT1RcBG)]) * array46[*(&HarmonyPatches.gszu01dUqY) + *(&HarmonyPatches.vnXzkjsBqD)] * array46[*(&HarmonyPatches.CxrNBlqmCa)] - array46[*(&HarmonyPatches.6kEEdOvqb9)] ^ (uint)(*(&HarmonyPatches.gPxUClMY1t)));
					continue;
				}
				case 79U:
				{
					int[] array5;
					array5[0] = 1461714698;
					uint num129 = ((num & (uint)(*(&HarmonyPatches.kjzLAIMHSU))) ^ (uint)(*(&HarmonyPatches.9czuwDKQJH) + *(&HarmonyPatches.b4vT9AUwsS))) & (uint)(*(&HarmonyPatches.clevIJ6KIW));
					num2 = (num129 ^ (uint)(*(&HarmonyPatches.ugHRdW5IV2)) ^ (uint)(*(&HarmonyPatches.Dpi7fqxfLA)));
					continue;
				}
				case 81U:
				{
					int[] array5;
					int[] array47 = array5;
					int num130 = 9;
					int num131 = array5[9] % 63 << 4;
					int num19 = (-93 == 0) ? (num131 - 94) : (num131 + -93);
					array47[num130] = (array5[9] ^ num19 ^ (588907181 ^ num19));
					num2 = 3672617590U;
					continue;
				}
				case 82U:
					num2 = 2616249387U;
					continue;
				case 83U:
				{
					int num8;
					int num9 = num8 + num9;
					int num7;
					num8 = num7 * 575;
					uint[] array48 = new uint[*(&HarmonyPatches.czubUAeCVb) + *(&HarmonyPatches.yjoHdhS2be)];
					array48[*(&HarmonyPatches.UlHbGTnd3p)] = (uint)(*(&HarmonyPatches.tNQjvdXWKZ));
					array48[*(&HarmonyPatches.K4elCxE3Pp)] = (uint)(*(&HarmonyPatches.Axwbz1rTVB));
					array48[*(&HarmonyPatches.WBJqskSFVA)] = (uint)(*(&HarmonyPatches.J6rCTaHgZT) + *(&HarmonyPatches.PtNNo5bzu4));
					array48[*(&HarmonyPatches.vEBIDJvx2b)] = (uint)(*(&HarmonyPatches.f9iPgEFtHY));
					array48[*(&HarmonyPatches.uK4Cwmy6Bx) + *(&HarmonyPatches.IcUbOF5i9K)] = (uint)(*(&HarmonyPatches.pTn7xPL8rk));
					uint num132 = ((num ^ (uint)(*(&HarmonyPatches.zrsVKlK8Wa))) * (uint)(*(&HarmonyPatches.UywFSCoHAa) + *(&HarmonyPatches.Igu6tag6Og)) ^ array48[*(&HarmonyPatches.b0Pa7bu9Qn)]) * array48[*(&HarmonyPatches.56Mj00hipu) + *(&HarmonyPatches.kD7QbS7vlt)];
					num2 = ((num132 | array48[*(&HarmonyPatches.EOu08ejVI1)]) ^ (uint)(*(&HarmonyPatches.So0WfMULG3) + *(&HarmonyPatches.28Qd5X288o)));
					continue;
				}
				case 84U:
				{
					int num3;
					int num7 = ~num3;
					int num9 = num3 % 663;
					uint[] array49 = new uint[*(&HarmonyPatches.B32tpyAyEw)];
					array49[*(&HarmonyPatches.KS8ywdgzPJ)] = (uint)(*(&HarmonyPatches.U4eyaT62v1));
					array49[*(&HarmonyPatches.7FYQ762E1z)] = (uint)(*(&HarmonyPatches.3D4QSO0MnU));
					array49[*(&HarmonyPatches.yYBTvHZESV)] = (uint)(*(&HarmonyPatches.2HCMyE4s0z));
					uint num133 = (num | array49[*(&HarmonyPatches.kb8ZPRANgL)]) * (uint)(*(&HarmonyPatches.ctPbCjDEe0));
					num2 = ((num133 | (uint)(*(&HarmonyPatches.hyvf6vAsbN))) ^ (uint)(*(&HarmonyPatches.UIVxtXZmEe)));
					continue;
				}
				case 85U:
				{
					int[] array5;
					int[] array50 = array5;
					int num134 = 7;
					int num135 = array5[7] + -118 + -78 | -144;
					int num19 = (((-267 == 0) ? (num135 - 27) : (num135 + -267)) | -10) * -468;
					array50[num134] = (array5[7] ^ num19 ^ (588907181 ^ num19));
					int[] array51 = array5;
					int num136 = 8;
					int num137 = array5[8] - 487;
					num19 = ((-268 == 0) ? (num137 - 15) : (num137 + -268)) % 26 - 144 << 6 << 4;
					array51[num136] = (array5[8] ^ num19 ^ (588907181 ^ num19));
					num2 = 3701966254U;
					continue;
				}
				case 86U:
				{
					uint[] array52 = new uint[*(&HarmonyPatches.SmBPkpfb12) + *(&HarmonyPatches.hOKIX5fAKX)];
					array52[*(&HarmonyPatches.xFtSxl24TZ)] = (uint)(*(&HarmonyPatches.y3xXs1MaFz));
					array52[*(&HarmonyPatches.e1LphWJ6xK)] = (uint)(*(&HarmonyPatches.CvSP4N2tc8) + *(&HarmonyPatches.wkIcDobwaf));
					array52[*(&HarmonyPatches.sE4U353Eva) + *(&HarmonyPatches.c6GJXDkhcf)] = (uint)(*(&HarmonyPatches.8d8GC3ttl3));
					array52[*(&HarmonyPatches.5WfRb708W8)] = (uint)(*(&HarmonyPatches.Ty8Bgzd8FA) + *(&HarmonyPatches.E3T5hPFxR9));
					array52[*(&HarmonyPatches.MJc1fFbysZ)] = (uint)(*(&HarmonyPatches.MmKdLKf7kN));
					array52[*(&HarmonyPatches.ZuolyBCjuM)] = (uint)(*(&HarmonyPatches.1CqWwJWGga));
					uint num138 = (num * (uint)(*(&HarmonyPatches.YoQpyctzuX)) | array52[*(&HarmonyPatches.tINEjbe0Dd)]) ^ (uint)(*(&HarmonyPatches.C2EghJ5xrB));
					uint num139 = num138 & array52[*(&HarmonyPatches.xZaKyue8xW)];
					uint num140 = num139 * (uint)(*(&HarmonyPatches.SNzXctzlxU));
					num2 = (num140 + (uint)(*(&HarmonyPatches.ofDCXfktIo)) ^ (uint)(*(&HarmonyPatches.g5IsjTsCPz) + *(&HarmonyPatches.7gDqLzCqDy)));
					continue;
				}
				case 87U:
				{
					int num7;
					int num3 = -num7;
					uint num141 = num & (uint)(*(&HarmonyPatches.7u2HNY0Yt5));
					uint num142 = num141 - (uint)(*(&HarmonyPatches.7aP5ho9mvX));
					num2 = ((num142 | (uint)(*(&HarmonyPatches.VTj4Ngww0f))) ^ (uint)(*(&HarmonyPatches.VhZ6z5w0Le)));
					continue;
				}
				case 88U:
				{
					uint[] array53 = new uint[*(&HarmonyPatches.thdS2bg5kz)];
					array53[*(&HarmonyPatches.0f7kuXH9Dd)] = (uint)(*(&HarmonyPatches.0YrGc6IOvc));
					array53[*(&HarmonyPatches.VmFc1ocbTD)] = (uint)(*(&HarmonyPatches.ov5GvW8Wx0));
					array53[*(&HarmonyPatches.XkyqgVzX05)] = (uint)(*(&HarmonyPatches.TRJIdOZetG));
					array53[*(&HarmonyPatches.5pqAzEdlVF)] = (uint)(*(&HarmonyPatches.8vb5EvxY5g));
					array53[*(&HarmonyPatches.yFlYuWlxmh)] = (uint)(*(&HarmonyPatches.6dnq4s4y1c) + *(&HarmonyPatches.1NCu6hzODs));
					array53[*(&HarmonyPatches.aBiNS0DRQc)] = (uint)(*(&HarmonyPatches.cq9xJeIvAW));
					uint num143 = ((num + (uint)(*(&HarmonyPatches.19hdolD1bM))) * array53[*(&HarmonyPatches.hXu4G55aXE)] & (uint)(*(&HarmonyPatches.omhZ9LOOlb))) + array53[*(&HarmonyPatches.YDOq0bdFiq) + *(&HarmonyPatches.xMzD4F6ErN)];
					uint num144 = num143 ^ array53[*(&HarmonyPatches.jsX6rObIdc) + *(&HarmonyPatches.WyP9xdJDDp)];
					num2 = (num144 - array53[*(&HarmonyPatches.c01rRcwee4)] ^ (uint)(*(&HarmonyPatches.PJgX2qqR9m)));
					continue;
				}
				case 89U:
				{
					int num7;
					num7 %= 358;
					int num8;
					int[] array2;
					num7 = array2[num8 + 7 - num8] + -9;
					uint num145 = num * (uint)(*(&HarmonyPatches.YsMnUgn9sK));
					num2 = ((num145 * (uint)(*(&HarmonyPatches.9oUyMHbWvY)) & (uint)(*(&HarmonyPatches.Hnr3hfeWaG))) ^ (uint)(*(&HarmonyPatches.gQzl9uFfjr)));
					continue;
				}
				case 90U:
				{
					int num146 = 854;
					num2 = (((num146 != 854) ? 259290117U : 1586542890U) ^ num * 685162795U);
					continue;
				}
				case 91U:
					num2 = 2724268974U;
					continue;
				case 92U:
				{
					int num3;
					int num9 = (int)((byte)num3);
					int num8;
					num8 %= 98;
					num9 = HarmonyPatches.WU3kLcVUpZ;
					uint[] array54 = new uint[*(&HarmonyPatches.hJsaT3sjLd) + *(&HarmonyPatches.IQBBlnL83q)];
					array54[*(&HarmonyPatches.mDiOjaBTFm)] = (uint)(*(&HarmonyPatches.1IbQzMlIkU));
					array54[*(&HarmonyPatches.yMlWWFgXVL)] = (uint)(*(&HarmonyPatches.ux6e2eke03) + *(&HarmonyPatches.1ZejlAzvLZ));
					array54[*(&HarmonyPatches.CCYj2ZcM1e)] = (uint)(*(&HarmonyPatches.4n731DL7XV));
					array54[*(&HarmonyPatches.lGRqcZsBuV) + *(&HarmonyPatches.PvM5JrZXlc)] = (uint)(*(&HarmonyPatches.CYmW9Nbkrh));
					array54[*(&HarmonyPatches.y1X0y5urGc)] = (uint)(*(&HarmonyPatches.rabgOJbBuJ));
					uint num147 = (num * array54[*(&HarmonyPatches.oyV5TMe5rO)] ^ (uint)(*(&HarmonyPatches.8ITNhYXWHN))) + array54[*(&HarmonyPatches.7rQJvl7GI0)];
					num2 = ((num147 & (uint)(*(&HarmonyPatches.wZzi39gcgl))) - array54[*(&HarmonyPatches.bzA1ejGN80)] ^ (uint)(*(&HarmonyPatches.vF3hM7iMJr)));
					continue;
				}
				case 93U:
				{
					int[] array55 = new int[10];
					uint[] array56 = new uint[*(&HarmonyPatches.9oQxjpK98w)];
					array56[*(&HarmonyPatches.4kMZqu5nKL)] = (uint)(*(&HarmonyPatches.pIxMOnTvkh));
					array56[*(&HarmonyPatches.oQHq2gEM6a)] = (uint)(*(&HarmonyPatches.62thhKefFF));
					array56[*(&HarmonyPatches.7JYsm11Ei5) + *(&HarmonyPatches.WYYaIocggK)] = (uint)(*(&HarmonyPatches.qsruPxZPoD));
					array56[*(&HarmonyPatches.Jxqejf1YDB)] = (uint)(*(&HarmonyPatches.pAoAEheSZ3));
					array56[*(&HarmonyPatches.r784ZObodz)] = (uint)(*(&HarmonyPatches.clZevir41n));
					array56[*(&HarmonyPatches.wEcffqEqpr)] = (uint)(*(&HarmonyPatches.TG0vWLywFU) + *(&HarmonyPatches.DN5OjDkJPf));
					uint num148 = (num ^ (uint)(*(&HarmonyPatches.zkbvGnfcZs) + *(&HarmonyPatches.Kv8vgVunIk))) - array56[*(&HarmonyPatches.t5ygjiIN6b)];
					uint num149 = num148 ^ (uint)(*(&HarmonyPatches.F4bK1spEpt));
					uint num150 = num149 & (uint)(*(&HarmonyPatches.qWWWKRPKsN));
					num2 = ((num150 + (uint)(*(&HarmonyPatches.T7Bov4v4Mh)) | (uint)(*(&HarmonyPatches.fRf7nPUy4x))) ^ (uint)(*(&HarmonyPatches.pp8Y3XibVR) + *(&HarmonyPatches.T8ftHI3wY7)));
					continue;
				}
				case 94U:
				{
					bool flag3;
					num2 = (((!flag3) ? 765756803U : 44415887U) ^ num * 756969673U);
					continue;
				}
				case 95U:
				{
					bool flag2 = HarmonyPatches.instance == null;
					uint[] array57 = new uint[*(&HarmonyPatches.MUVUR8GIp1)];
					array57[*(&HarmonyPatches.CLKawrQRym)] = (uint)(*(&HarmonyPatches.iLWUWTgHnW));
					array57[*(&HarmonyPatches.ktXjnQKxm3)] = (uint)(*(&HarmonyPatches.u4R9WZBdBJ));
					array57[*(&HarmonyPatches.vVKE4B8B87) + *(&HarmonyPatches.b9fTQSylxg)] = (uint)(*(&HarmonyPatches.hcp51o3W77) + *(&HarmonyPatches.SCFdlPiSol));
					num2 = ((num & array57[*(&HarmonyPatches.SJzobuY8sD)]) - (uint)(*(&HarmonyPatches.kZqfmSpPMQ) + *(&HarmonyPatches.HlDBoZ4BrA)) - array57[*(&HarmonyPatches.tg6MOXnBdH)] ^ (uint)(*(&HarmonyPatches.P5o3W3Wj0S)));
					continue;
				}
				}
				break;
			}
			return;
			IL_24:
			num2 = 3351305250U;
			goto IL_29;
			IL_19FC:
			num2 = 2362318474U;
			goto IL_29;
		}

		// Token: 0x060001CA RID: 458 RVA: 0x00637D64 File Offset: 0x00635F64
		public unsafe HarmonyPatches()
		{
			if ((*(&HarmonyPatches.bOebkNMYmu) ^ *(&HarmonyPatches.bOebkNMYmu)) != 0)
			{
				int[] array = new int[10];
				int num2;
				int num = num2 / num;
				int num3 = num2;
				if (num2 > num2)
				{
					num = -num2;
					num = num3 % 685;
					num2 = (array[num3 + 8 - num] ^ 2);
				}
				num2 = *(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num);
				num = *(ref num3 + (IntPtr)num2);
				array[num3 + 9 - num] = num3 - 8;
				HarmonyPatches.WU3kLcVUpZ = num2;
				num3 = num2 >> 2;
				num2 = 2022880567;
				num2 /= 471;
				num3 &= num2;
				num3 = HarmonyPatches.WU3kLcVUpZ;
				num2 = num * num2;
				num3 = num2 % 78;
				num = (num3 | num2);
				num = num2 + num;
				num2 = num + num2;
				num3 -= num2;
				array[num2 + 8 - num2] = (num3 | 8);
				*(ref num3 + (IntPtr)num2) = num2;
				num3 &= 49000782;
				num2 = (num3 | 906271571);
				if (num3 > num3)
				{
					num &= num2;
					num3 = array[num + 9 - num3] + -1;
					num2 = (num3 ^ 651610679);
					*(ref num + (IntPtr)num2) = num2;
				}
				*(ref num3 + (IntPtr)num2) = num2;
				num3 = -num3;
				num2 = num3 * num2;
				num2 ^= 714231658;
				if (num2 > num2)
				{
					array[num3 + 8 - num3] = (num2 | -4);
					num2 *= num;
					num2 = ~num2;
					num2 = (num3 | num2);
					array[num + 8 - num3] = num - -9;
				}
				num = -num;
				num ^= 1893270700;
				if (num2 > num2)
				{
					if (num2 > num2)
					{
						num ^= num2;
						num = ~num2;
						num2 = num2;
						num &= num2;
						num >>= 3;
						num3 = (num ^ num2);
						num2 &= 1886135491;
						num2 *= 585;
						num3 = ~num3;
					}
					HarmonyPatches.WU3kLcVUpZ = num;
					if (num > num)
					{
						num3 = -num;
						num |= 550665936;
						num /= 688;
					}
					num3 = HarmonyPatches.WU3kLcVUpZ;
					if (num3 > num3)
					{
						num2 ^= 1350293123;
						num2 = HarmonyPatches.WU3kLcVUpZ;
						num = num;
						num2 = num / num2;
						num2 = (num & num2);
						num += 855;
						num2 = num << 5;
					}
					num3 = (num & 109091608);
					array[num + 5 - num] = (num | 6);
					num3 = (int)((short)num);
					HarmonyPatches.WU3kLcVUpZ = num3;
				}
				if (num > num)
				{
					*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num) = num;
					num2 = *(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num2);
					if (num2 > num2)
					{
						num3 /= num2;
					}
					num3 &= 742646549;
					num2 = *(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num);
					num = HarmonyPatches.WU3kLcVUpZ;
					if (num2 > num2)
					{
						num = *(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num3);
						*(ref num3 + (IntPtr)num2) = num2;
						num = (int)((short)num);
						num = (array[num + 7 - num2] ^ -8);
						num2 = 1427618568;
						num2 = 43017492;
						num = -num;
						num = (num2 ^ num);
					}
					if (num2 > num2)
					{
						HarmonyPatches.WU3kLcVUpZ = num;
						num3 = *(ref num + (IntPtr)num2);
					}
					num3 = (int)((byte)num3);
				}
				num3 = ~num3;
				*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num3) = num3;
				num = *(ref num2 + (IntPtr)num);
				num = (num2 & 2021161899);
				num2 = num;
				if (num3 > num3)
				{
					num = num3 % num2;
					if (num2 > num2)
					{
						num3 = num * num2;
						array[num + 9 - num2] = (num | -5);
						num2 = (num3 & num2);
						num3 = (num | num2);
						num2 ^= num;
					}
					num3 = ~num2;
					num2 = *(ref num2 + (IntPtr)num);
					*(ref num2 + (IntPtr)num) = num;
					num2 |= 1845920151;
					if (num3 > num3)
					{
						num = HarmonyPatches.WU3kLcVUpZ;
						*(ref HarmonyPatches.WU3kLcVUpZ + (IntPtr)num) = num;
						num = -num;
						num2 = (num3 | num2);
						num3 = (num ^ 751251513);
					}
				}
				num2 = ~num2;
				array[num + 6 - num3] = num3 - 6;
			}
			base..ctor();
			for (;;)
			{
				IL_31B:
				uint num4 = 1166046045U;
				for (;;)
				{
					uint num5;
					switch ((num5 = (num4 ^ (uint)(*(&HarmonyPatches.x732neJcut)))) % (uint)(*(&HarmonyPatches.lLIk842TqM)))
					{
					case 1U:
					{
						uint[] array2 = new uint[*(&HarmonyPatches.aF1u4VM8Lf)];
						array2[*(&HarmonyPatches.ZZzGjIkMs1)] = (uint)(*(&HarmonyPatches.w1iCPJPmQl));
						array2[*(&HarmonyPatches.ov1G7rGJ8S)] = (uint)(*(&HarmonyPatches.RKQOUMWBAz));
						array2[*(&HarmonyPatches.UqkzZihyeu) + *(&HarmonyPatches.Fksk0nhtJ1)] = (uint)(*(&HarmonyPatches.CaNajmkTsD));
						uint num6 = num5 - (uint)(*(&HarmonyPatches.xNlaR7KCqY));
						uint num7 = num6 & (uint)(*(&HarmonyPatches.KRoNMrbqYq));
						num4 = ((num7 & (uint)(*(&HarmonyPatches.om2Ix3cJPx))) ^ (uint)(*(&HarmonyPatches.8NGb718ST2)));
						continue;
					}
					case 2U:
						goto IL_31B;
					}
					return;
				}
			}
		}

		// Token: 0x0404DAA0 RID: 318112
		public static Harmony instance;

		// Token: 0x0404DAA2 RID: 318114
		public const string id = "com.obs.gorillatag.lol";

		// Token: 0x0404DAA3 RID: 318115 RVA: 0x00142370 File Offset: 0x00140570
		static int Ow2W7v2yaQ;

		// Token: 0x0404DAA4 RID: 318116 RVA: 0x00142378 File Offset: 0x00140578
		static int WU3kLcVUpZ;

		// Token: 0x0404DAA5 RID: 318117 RVA: 0x00142380 File Offset: 0x00140580
		static int BbqwsE907N;

		// Token: 0x0404DAA6 RID: 318118 RVA: 0x00142388 File Offset: 0x00140588
		static int u8PpHuDDMi;

		// Token: 0x0404DAA7 RID: 318119 RVA: 0x00142390 File Offset: 0x00140590
		static int bOebkNMYmu;

		// Token: 0x0404DAA8 RID: 318120 RVA: 0x00142398 File Offset: 0x00140598
		static readonly int KUAfGH2rUb;

		// Token: 0x0404DAA9 RID: 318121 RVA: 0x00025A58 File Offset: 0x00023C58
		static readonly int uq4v03wj4S;

		// Token: 0x0404DAAA RID: 318122 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int 9oQxjpK98w;

		// Token: 0x0404DAAB RID: 318123 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 4kMZqu5nKL;

		// Token: 0x0404DAAC RID: 318124 RVA: 0x001423A0 File Offset: 0x001405A0
		static readonly int pIxMOnTvkh;

		// Token: 0x0404DAAD RID: 318125 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int oQHq2gEM6a;

		// Token: 0x0404DAAE RID: 318126 RVA: 0x001423A8 File Offset: 0x001405A8
		static readonly int 62thhKefFF;

		// Token: 0x0404DAAF RID: 318127 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7JYsm11Ei5;

		// Token: 0x0404DAB0 RID: 318128 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int WYYaIocggK;

		// Token: 0x0404DAB1 RID: 318129 RVA: 0x001423B0 File Offset: 0x001405B0
		static readonly int qsruPxZPoD;

		// Token: 0x0404DAB2 RID: 318130 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Jxqejf1YDB;

		// Token: 0x0404DAB3 RID: 318131 RVA: 0x001423B8 File Offset: 0x001405B8
		static readonly int pAoAEheSZ3;

		// Token: 0x0404DAB4 RID: 318132 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int r784ZObodz;

		// Token: 0x0404DAB5 RID: 318133 RVA: 0x001423C0 File Offset: 0x001405C0
		static readonly int clZevir41n;

		// Token: 0x0404DAB6 RID: 318134 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int wEcffqEqpr;

		// Token: 0x0404DAB7 RID: 318135 RVA: 0x001423C8 File Offset: 0x001405C8
		static readonly int TG0vWLywFU;

		// Token: 0x0404DAB8 RID: 318136 RVA: 0x001423D0 File Offset: 0x001405D0
		static readonly int DN5OjDkJPf;

		// Token: 0x0404DAB9 RID: 318137 RVA: 0x001423D8 File Offset: 0x001405D8
		static readonly int zkbvGnfcZs;

		// Token: 0x0404DABA RID: 318138 RVA: 0x001423E0 File Offset: 0x001405E0
		static readonly int Kv8vgVunIk;

		// Token: 0x0404DABB RID: 318139 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int t5ygjiIN6b;

		// Token: 0x0404DABC RID: 318140 RVA: 0x001423B0 File Offset: 0x001405B0
		static readonly int F4bK1spEpt;

		// Token: 0x0404DABD RID: 318141 RVA: 0x001423B8 File Offset: 0x001405B8
		static readonly int qWWWKRPKsN;

		// Token: 0x0404DABE RID: 318142 RVA: 0x001423C0 File Offset: 0x001405C0
		static readonly int T7Bov4v4Mh;

		// Token: 0x0404DABF RID: 318143 RVA: 0x001423E8 File Offset: 0x001405E8
		static readonly int fRf7nPUy4x;

		// Token: 0x0404DAC0 RID: 318144 RVA: 0x001423F0 File Offset: 0x001405F0
		static readonly int pp8Y3XibVR;

		// Token: 0x0404DAC1 RID: 318145 RVA: 0x001423F8 File Offset: 0x001405F8
		static readonly int T8ftHI3wY7;

		// Token: 0x0404DAC2 RID: 318146 RVA: 0x00142400 File Offset: 0x00140600
		static readonly int 7u2HNY0Yt5;

		// Token: 0x0404DAC3 RID: 318147 RVA: 0x00142408 File Offset: 0x00140608
		static readonly int 7aP5ho9mvX;

		// Token: 0x0404DAC4 RID: 318148 RVA: 0x00142410 File Offset: 0x00140610
		static readonly int VTj4Ngww0f;

		// Token: 0x0404DAC5 RID: 318149 RVA: 0x00142418 File Offset: 0x00140618
		static readonly int VhZ6z5w0Le;

		// Token: 0x0404DAC6 RID: 318150 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int hJsaT3sjLd;

		// Token: 0x0404DAC7 RID: 318151 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int IQBBlnL83q;

		// Token: 0x0404DAC8 RID: 318152 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int mDiOjaBTFm;

		// Token: 0x0404DAC9 RID: 318153 RVA: 0x00142420 File Offset: 0x00140620
		static readonly int 1IbQzMlIkU;

		// Token: 0x0404DACA RID: 318154 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yMlWWFgXVL;

		// Token: 0x0404DACB RID: 318155 RVA: 0x00142428 File Offset: 0x00140628
		static readonly int ux6e2eke03;

		// Token: 0x0404DACC RID: 318156 RVA: 0x00142430 File Offset: 0x00140630
		static readonly int 1ZejlAzvLZ;

		// Token: 0x0404DACD RID: 318157 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int CCYj2ZcM1e;

		// Token: 0x0404DACE RID: 318158 RVA: 0x00142438 File Offset: 0x00140638
		static readonly int 4n731DL7XV;

		// Token: 0x0404DACF RID: 318159 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int lGRqcZsBuV;

		// Token: 0x0404DAD0 RID: 318160 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int PvM5JrZXlc;

		// Token: 0x0404DAD1 RID: 318161 RVA: 0x00142440 File Offset: 0x00140640
		static readonly int CYmW9Nbkrh;

		// Token: 0x0404DAD2 RID: 318162 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int y1X0y5urGc;

		// Token: 0x0404DAD3 RID: 318163 RVA: 0x00142448 File Offset: 0x00140648
		static readonly int rabgOJbBuJ;

		// Token: 0x0404DAD4 RID: 318164 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int oyV5TMe5rO;

		// Token: 0x0404DAD5 RID: 318165 RVA: 0x00142450 File Offset: 0x00140650
		static readonly int 8ITNhYXWHN;

		// Token: 0x0404DAD6 RID: 318166 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 7rQJvl7GI0;

		// Token: 0x0404DAD7 RID: 318167 RVA: 0x00142440 File Offset: 0x00140640
		static readonly int wZzi39gcgl;

		// Token: 0x0404DAD8 RID: 318168 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int bzA1ejGN80;

		// Token: 0x0404DAD9 RID: 318169 RVA: 0x00142458 File Offset: 0x00140658
		static readonly int vF3hM7iMJr;

		// Token: 0x0404DADA RID: 318170 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int OYw0ciSvUh;

		// Token: 0x0404DADB RID: 318171 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 15zfwHrYoM;

		// Token: 0x0404DADC RID: 318172 RVA: 0x00142460 File Offset: 0x00140660
		static readonly int etHSFrfSV6;

		// Token: 0x0404DADD RID: 318173 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bTSzXCCJZ6;

		// Token: 0x0404DADE RID: 318174 RVA: 0x00142468 File Offset: 0x00140668
		static readonly int RU3a8zPYuE;

		// Token: 0x0404DADF RID: 318175 RVA: 0x00142470 File Offset: 0x00140670
		static readonly int PJh7MfQevu;

		// Token: 0x0404DAE0 RID: 318176 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int C9aYGinAIt;

		// Token: 0x0404DAE1 RID: 318177 RVA: 0x00142478 File Offset: 0x00140678
		static readonly int Fh9s4JzqTP;

		// Token: 0x0404DAE2 RID: 318178 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int bHiQqSwUm1;

		// Token: 0x0404DAE3 RID: 318179 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vhXo4R4fUa;

		// Token: 0x0404DAE4 RID: 318180 RVA: 0x00142478 File Offset: 0x00140678
		static readonly int MPPA9rJzCC;

		// Token: 0x0404DAE5 RID: 318181 RVA: 0x00142480 File Offset: 0x00140680
		static readonly int pkLgS4bJry;

		// Token: 0x0404DAE6 RID: 318182 RVA: 0x00142488 File Offset: 0x00140688
		static readonly int vSXQ8hKUyn;

		// Token: 0x0404DAE7 RID: 318183 RVA: 0x00142490 File Offset: 0x00140690
		static readonly int PUW3DM2hQ8;

		// Token: 0x0404DAE8 RID: 318184 RVA: 0x00142498 File Offset: 0x00140698
		static readonly int I7SjMLW1W9;

		// Token: 0x0404DAE9 RID: 318185 RVA: 0x001424A0 File Offset: 0x001406A0
		static readonly int 0vygo418Cc;

		// Token: 0x0404DAEA RID: 318186 RVA: 0x001424A8 File Offset: 0x001406A8
		static readonly int hyAZxVORcG;

		// Token: 0x0404DAEB RID: 318187 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int B32tpyAyEw;

		// Token: 0x0404DAEC RID: 318188 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int KS8ywdgzPJ;

		// Token: 0x0404DAED RID: 318189 RVA: 0x001424B0 File Offset: 0x001406B0
		static readonly int U4eyaT62v1;

		// Token: 0x0404DAEE RID: 318190 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7FYQ762E1z;

		// Token: 0x0404DAEF RID: 318191 RVA: 0x001424B8 File Offset: 0x001406B8
		static readonly int 3D4QSO0MnU;

		// Token: 0x0404DAF0 RID: 318192 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int yYBTvHZESV;

		// Token: 0x0404DAF1 RID: 318193 RVA: 0x001424C0 File Offset: 0x001406C0
		static readonly int 2HCMyE4s0z;

		// Token: 0x0404DAF2 RID: 318194 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int kb8ZPRANgL;

		// Token: 0x0404DAF3 RID: 318195 RVA: 0x001424B8 File Offset: 0x001406B8
		static readonly int ctPbCjDEe0;

		// Token: 0x0404DAF4 RID: 318196 RVA: 0x001424C0 File Offset: 0x001406C0
		static readonly int hyvf6vAsbN;

		// Token: 0x0404DAF5 RID: 318197 RVA: 0x001424C8 File Offset: 0x001406C8
		static readonly int UIVxtXZmEe;

		// Token: 0x0404DAF6 RID: 318198 RVA: 0x001424D0 File Offset: 0x001406D0
		static readonly int HLiG2I2lJP;

		// Token: 0x0404DAF7 RID: 318199 RVA: 0x001424D8 File Offset: 0x001406D8
		static readonly int BzNARwpdcd;

		// Token: 0x0404DAF8 RID: 318200 RVA: 0x001424E0 File Offset: 0x001406E0
		static readonly int QSwS1UYbsp;

		// Token: 0x0404DAF9 RID: 318201 RVA: 0x001424E8 File Offset: 0x001406E8
		static readonly int JbA9sWQomy;

		// Token: 0x0404DAFA RID: 318202 RVA: 0x001424F0 File Offset: 0x001406F0
		static readonly int 3ZiLLe4Uf7;

		// Token: 0x0404DAFB RID: 318203 RVA: 0x001424F8 File Offset: 0x001406F8
		static readonly int r6JkOzYPPi;

		// Token: 0x0404DAFC RID: 318204 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ta3eGjyNR5;

		// Token: 0x0404DAFD RID: 318205 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int fA1ok1tkGW;

		// Token: 0x0404DAFE RID: 318206 RVA: 0x00142500 File Offset: 0x00140700
		static readonly int ZE5v7NSav3;

		// Token: 0x0404DAFF RID: 318207 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7BZDEcfEFl;

		// Token: 0x0404DB00 RID: 318208 RVA: 0x00142508 File Offset: 0x00140708
		static readonly int qrCkbrEeAW;

		// Token: 0x0404DB01 RID: 318209 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int FyI2JpfHg2;

		// Token: 0x0404DB02 RID: 318210 RVA: 0x00142510 File Offset: 0x00140710
		static readonly int RYcY8elxkH;

		// Token: 0x0404DB03 RID: 318211 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int VofeqsBVTQ;

		// Token: 0x0404DB04 RID: 318212 RVA: 0x00142518 File Offset: 0x00140718
		static readonly int IxZYxJ2g4Y;

		// Token: 0x0404DB05 RID: 318213 RVA: 0x00142520 File Offset: 0x00140720
		static readonly int 7XiNURPol7;

		// Token: 0x0404DB06 RID: 318214 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int FR43BbSnMa;

		// Token: 0x0404DB07 RID: 318215 RVA: 0x00142528 File Offset: 0x00140728
		static readonly int oJyPtd9Dkz;

		// Token: 0x0404DB08 RID: 318216 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int lE2LJ7GSKZ;

		// Token: 0x0404DB09 RID: 318217 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int cWtWK03gXW;

		// Token: 0x0404DB0A RID: 318218 RVA: 0x00142530 File Offset: 0x00140730
		static readonly int 0OUeuxjSd0;

		// Token: 0x0404DB0B RID: 318219 RVA: 0x00142538 File Offset: 0x00140738
		static readonly int SMEwVBZstD;

		// Token: 0x0404DB0C RID: 318220 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int UAdw7SacF2;

		// Token: 0x0404DB0D RID: 318221 RVA: 0x00142540 File Offset: 0x00140740
		static readonly int jcpN8WtYbW;

		// Token: 0x0404DB0E RID: 318222 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int YyyTGQR6AI;

		// Token: 0x0404DB0F RID: 318223 RVA: 0x00142548 File Offset: 0x00140748
		static readonly int bLxUCzvhgc;

		// Token: 0x0404DB10 RID: 318224 RVA: 0x00142550 File Offset: 0x00140750
		static readonly int XHNkQzg0y9;

		// Token: 0x0404DB11 RID: 318225 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int SARXpgMJqr;

		// Token: 0x0404DB12 RID: 318226 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Adb6bYpVLI;

		// Token: 0x0404DB13 RID: 318227 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int lL298QkODQ;

		// Token: 0x0404DB14 RID: 318228 RVA: 0x00142558 File Offset: 0x00140758
		static readonly int taIB0a4aof;

		// Token: 0x0404DB15 RID: 318229 RVA: 0x00142560 File Offset: 0x00140760
		static readonly int nl1yb3pQJ1;

		// Token: 0x0404DB16 RID: 318230 RVA: 0x00142568 File Offset: 0x00140768
		static readonly int KLppXHIRYY;

		// Token: 0x0404DB17 RID: 318231 RVA: 0x00142570 File Offset: 0x00140770
		static readonly int 57GZ7jVaGA;

		// Token: 0x0404DB18 RID: 318232 RVA: 0x00142578 File Offset: 0x00140778
		static readonly int eOqpf9TDhF;

		// Token: 0x0404DB19 RID: 318233 RVA: 0x00142580 File Offset: 0x00140780
		static readonly int lTELFhvcns;

		// Token: 0x0404DB1A RID: 318234 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int SmBPkpfb12;

		// Token: 0x0404DB1B RID: 318235 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int hOKIX5fAKX;

		// Token: 0x0404DB1C RID: 318236 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int xFtSxl24TZ;

		// Token: 0x0404DB1D RID: 318237 RVA: 0x00142588 File Offset: 0x00140788
		static readonly int y3xXs1MaFz;

		// Token: 0x0404DB1E RID: 318238 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int e1LphWJ6xK;

		// Token: 0x0404DB1F RID: 318239 RVA: 0x00142590 File Offset: 0x00140790
		static readonly int CvSP4N2tc8;

		// Token: 0x0404DB20 RID: 318240 RVA: 0x00142598 File Offset: 0x00140798
		static readonly int wkIcDobwaf;

		// Token: 0x0404DB21 RID: 318241 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int sE4U353Eva;

		// Token: 0x0404DB22 RID: 318242 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int c6GJXDkhcf;

		// Token: 0x0404DB23 RID: 318243 RVA: 0x001425A0 File Offset: 0x001407A0
		static readonly int 8d8GC3ttl3;

		// Token: 0x0404DB24 RID: 318244 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 5WfRb708W8;

		// Token: 0x0404DB25 RID: 318245 RVA: 0x001425A8 File Offset: 0x001407A8
		static readonly int Ty8Bgzd8FA;

		// Token: 0x0404DB26 RID: 318246 RVA: 0x001425B0 File Offset: 0x001407B0
		static readonly int E3T5hPFxR9;

		// Token: 0x0404DB27 RID: 318247 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int MJc1fFbysZ;

		// Token: 0x0404DB28 RID: 318248 RVA: 0x001425B8 File Offset: 0x001407B8
		static readonly int MmKdLKf7kN;

		// Token: 0x0404DB29 RID: 318249 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int ZuolyBCjuM;

		// Token: 0x0404DB2A RID: 318250 RVA: 0x001425C0 File Offset: 0x001407C0
		static readonly int 1CqWwJWGga;

		// Token: 0x0404DB2B RID: 318251 RVA: 0x00142588 File Offset: 0x00140788
		static readonly int YoQpyctzuX;

		// Token: 0x0404DB2C RID: 318252 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int tINEjbe0Dd;

		// Token: 0x0404DB2D RID: 318253 RVA: 0x001425A0 File Offset: 0x001407A0
		static readonly int C2EghJ5xrB;

		// Token: 0x0404DB2E RID: 318254 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int xZaKyue8xW;

		// Token: 0x0404DB2F RID: 318255 RVA: 0x001425B8 File Offset: 0x001407B8
		static readonly int SNzXctzlxU;

		// Token: 0x0404DB30 RID: 318256 RVA: 0x001425C0 File Offset: 0x001407C0
		static readonly int ofDCXfktIo;

		// Token: 0x0404DB31 RID: 318257 RVA: 0x001425C8 File Offset: 0x001407C8
		static readonly int g5IsjTsCPz;

		// Token: 0x0404DB32 RID: 318258 RVA: 0x001425D0 File Offset: 0x001407D0
		static readonly int 7gDqLzCqDy;

		// Token: 0x0404DB33 RID: 318259 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int UTAWWSWYxT;

		// Token: 0x0404DB34 RID: 318260 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Ju0I0WEGyJ;

		// Token: 0x0404DB35 RID: 318261 RVA: 0x001425D8 File Offset: 0x001407D8
		static readonly int AxW8XIbW1h;

		// Token: 0x0404DB36 RID: 318262 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int c4qUUM5vVR;

		// Token: 0x0404DB37 RID: 318263 RVA: 0x001425E0 File Offset: 0x001407E0
		static readonly int 7UP6pMp40y;

		// Token: 0x0404DB38 RID: 318264 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int v614xg7C9O;

		// Token: 0x0404DB39 RID: 318265 RVA: 0x001425E8 File Offset: 0x001407E8
		static readonly int 09gP0PDfyn;

		// Token: 0x0404DB3A RID: 318266 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int bTuhLqhZSK;

		// Token: 0x0404DB3B RID: 318267 RVA: 0x001425F0 File Offset: 0x001407F0
		static readonly int cggCwgCwgx;

		// Token: 0x0404DB3C RID: 318268 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int P2vHa7x9Ga;

		// Token: 0x0404DB3D RID: 318269 RVA: 0x001425F8 File Offset: 0x001407F8
		static readonly int IJGMXbLUsG;

		// Token: 0x0404DB3E RID: 318270 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 8htzvTcedT;

		// Token: 0x0404DB3F RID: 318271 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int MR8BXihnGO;

		// Token: 0x0404DB40 RID: 318272 RVA: 0x00142600 File Offset: 0x00140800
		static readonly int 3iT2BSaUoU;

		// Token: 0x0404DB41 RID: 318273 RVA: 0x00142608 File Offset: 0x00140808
		static readonly int VsDayrI6WH;

		// Token: 0x0404DB42 RID: 318274 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int eSgxO1LEyz;

		// Token: 0x0404DB43 RID: 318275 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4hNeMaO1xc;

		// Token: 0x0404DB44 RID: 318276 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 2IzI8dOiMp;

		// Token: 0x0404DB45 RID: 318277 RVA: 0x001425F0 File Offset: 0x001407F0
		static readonly int ZkQ9tkBgoK;

		// Token: 0x0404DB46 RID: 318278 RVA: 0x001425F8 File Offset: 0x001407F8
		static readonly int HWfzaxejNX;

		// Token: 0x0404DB47 RID: 318279 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int dRJ4OVdYyu;

		// Token: 0x0404DB48 RID: 318280 RVA: 0x00142610 File Offset: 0x00140810
		static readonly int mm1JZTROum;

		// Token: 0x0404DB49 RID: 318281 RVA: 0x00142618 File Offset: 0x00140818
		static readonly int YsMnUgn9sK;

		// Token: 0x0404DB4A RID: 318282 RVA: 0x00142620 File Offset: 0x00140820
		static readonly int 9oUyMHbWvY;

		// Token: 0x0404DB4B RID: 318283 RVA: 0x00142628 File Offset: 0x00140828
		static readonly int Hnr3hfeWaG;

		// Token: 0x0404DB4C RID: 318284 RVA: 0x00142630 File Offset: 0x00140830
		static readonly int gQzl9uFfjr;

		// Token: 0x0404DB4D RID: 318285 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int rdqov7SC6R;

		// Token: 0x0404DB4E RID: 318286 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 24dWfvBSFz;

		// Token: 0x0404DB4F RID: 318287 RVA: 0x00142638 File Offset: 0x00140838
		static readonly int BRjlosztzc;

		// Token: 0x0404DB50 RID: 318288 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int C5wDqn7CIj;

		// Token: 0x0404DB51 RID: 318289 RVA: 0x00142640 File Offset: 0x00140840
		static readonly int NbZIOlxdGO;

		// Token: 0x0404DB52 RID: 318290 RVA: 0x00142648 File Offset: 0x00140848
		static readonly int swauqa4EAC;

		// Token: 0x0404DB53 RID: 318291 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int IiNdO6IZp1;

		// Token: 0x0404DB54 RID: 318292 RVA: 0x00142650 File Offset: 0x00140850
		static readonly int x8Kfmk1aXC;

		// Token: 0x0404DB55 RID: 318293 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 5WmltQfBXQ;

		// Token: 0x0404DB56 RID: 318294 RVA: 0x00142658 File Offset: 0x00140858
		static readonly int t3CFboO53R;

		// Token: 0x0404DB57 RID: 318295 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int dXxOatl4IF;

		// Token: 0x0404DB58 RID: 318296 RVA: 0x00142660 File Offset: 0x00140860
		static readonly int idq7Gw6lu8;

		// Token: 0x0404DB59 RID: 318297 RVA: 0x00142638 File Offset: 0x00140838
		static readonly int bGCZI46FE7;

		// Token: 0x0404DB5A RID: 318298 RVA: 0x00142668 File Offset: 0x00140868
		static readonly int V5gGjiiXL9;

		// Token: 0x0404DB5B RID: 318299 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int pk3RsPME8p;

		// Token: 0x0404DB5C RID: 318300 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int rmL5zWUYGg;

		// Token: 0x0404DB5D RID: 318301 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xgzKum7kXi;

		// Token: 0x0404DB5E RID: 318302 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int NiavS0Nvr3;

		// Token: 0x0404DB5F RID: 318303 RVA: 0x00142660 File Offset: 0x00140860
		static readonly int s1GZQsukQM;

		// Token: 0x0404DB60 RID: 318304 RVA: 0x00142670 File Offset: 0x00140870
		static readonly int OKRoMIvshG;

		// Token: 0x0404DB61 RID: 318305 RVA: 0x00142678 File Offset: 0x00140878
		static readonly int SlqabIMZn9;

		// Token: 0x0404DB62 RID: 318306 RVA: 0x00142680 File Offset: 0x00140880
		static readonly int JirNx5Za4B;

		// Token: 0x0404DB63 RID: 318307 RVA: 0x00142688 File Offset: 0x00140888
		static readonly int 1WUKTCRvjJ;

		// Token: 0x0404DB64 RID: 318308 RVA: 0x00142690 File Offset: 0x00140890
		static readonly int FeOllGLq7H;

		// Token: 0x0404DB65 RID: 318309 RVA: 0x00142698 File Offset: 0x00140898
		static readonly int gU7RDpdE1Q;

		// Token: 0x0404DB66 RID: 318310 RVA: 0x001426A0 File Offset: 0x001408A0
		static readonly int tUygO6RgGZ;

		// Token: 0x0404DB67 RID: 318311 RVA: 0x001426A8 File Offset: 0x001408A8
		static readonly int 1a0d3pUGmr;

		// Token: 0x0404DB68 RID: 318312 RVA: 0x001426B0 File Offset: 0x001408B0
		static readonly int utdxegYCHo;

		// Token: 0x0404DB69 RID: 318313 RVA: 0x001426B8 File Offset: 0x001408B8
		static readonly int jN4SavprWp;

		// Token: 0x0404DB6A RID: 318314 RVA: 0x001426C0 File Offset: 0x001408C0
		static readonly int yojiPGdeXX;

		// Token: 0x0404DB6B RID: 318315 RVA: 0x001426C8 File Offset: 0x001408C8
		static readonly int UXcJg90BBr;

		// Token: 0x0404DB6C RID: 318316 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int hOYczngiCI;

		// Token: 0x0404DB6D RID: 318317 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 9mt62FJ5hY;

		// Token: 0x0404DB6E RID: 318318 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int C4ptTMvuwb;

		// Token: 0x0404DB6F RID: 318319 RVA: 0x001426D0 File Offset: 0x001408D0
		static readonly int 4oqoHjQHsm;

		// Token: 0x0404DB70 RID: 318320 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int j5bOYrnfRb;

		// Token: 0x0404DB71 RID: 318321 RVA: 0x001426D8 File Offset: 0x001408D8
		static readonly int z5enonjpIm;

		// Token: 0x0404DB72 RID: 318322 RVA: 0x001426E0 File Offset: 0x001408E0
		static readonly int 2vwlOV6EzS;

		// Token: 0x0404DB73 RID: 318323 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int zBM5yHcaVl;

		// Token: 0x0404DB74 RID: 318324 RVA: 0x001426E8 File Offset: 0x001408E8
		static readonly int iQdVl8JC9e;

		// Token: 0x0404DB75 RID: 318325 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Al9FtyJ0AC;

		// Token: 0x0404DB76 RID: 318326 RVA: 0x001426F0 File Offset: 0x001408F0
		static readonly int vip8lytjzh;

		// Token: 0x0404DB77 RID: 318327 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int LITgDmSaAQ;

		// Token: 0x0404DB78 RID: 318328 RVA: 0x001426F8 File Offset: 0x001408F8
		static readonly int L4EVSNCGL9;

		// Token: 0x0404DB79 RID: 318329 RVA: 0x001426D0 File Offset: 0x001408D0
		static readonly int 7laS0Aketx;

		// Token: 0x0404DB7A RID: 318330 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int OkNcT1RcBG;

		// Token: 0x0404DB7B RID: 318331 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gszu01dUqY;

		// Token: 0x0404DB7C RID: 318332 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vnXzkjsBqD;

		// Token: 0x0404DB7D RID: 318333 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int CxrNBlqmCa;

		// Token: 0x0404DB7E RID: 318334 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 6kEEdOvqb9;

		// Token: 0x0404DB7F RID: 318335 RVA: 0x00142700 File Offset: 0x00140900
		static readonly int gPxUClMY1t;

		// Token: 0x0404DB80 RID: 318336 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int JQv8EsAmsP;

		// Token: 0x0404DB81 RID: 318337 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int K1SQcKiSVV;

		// Token: 0x0404DB82 RID: 318338 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int xBjqhw9WLZ;

		// Token: 0x0404DB83 RID: 318339 RVA: 0x00142708 File Offset: 0x00140908
		static readonly int YRvSRpzGAu;

		// Token: 0x0404DB84 RID: 318340 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NJ7Myp7h21;

		// Token: 0x0404DB85 RID: 318341 RVA: 0x00142710 File Offset: 0x00140910
		static readonly int C3Cf6HqEaR;

		// Token: 0x0404DB86 RID: 318342 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int sobT02FA9w;

		// Token: 0x0404DB87 RID: 318343 RVA: 0x00142718 File Offset: 0x00140918
		static readonly int VcSlInEX12;

		// Token: 0x0404DB88 RID: 318344 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int zcdTWfPPVJ;

		// Token: 0x0404DB89 RID: 318345 RVA: 0x00142720 File Offset: 0x00140920
		static readonly int 8upsBjroV6;

		// Token: 0x0404DB8A RID: 318346 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int j7iGgjlbXS;

		// Token: 0x0404DB8B RID: 318347 RVA: 0x00142728 File Offset: 0x00140928
		static readonly int DTMicQKH6V;

		// Token: 0x0404DB8C RID: 318348 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int n0ozxkxjji;

		// Token: 0x0404DB8D RID: 318349 RVA: 0x00142730 File Offset: 0x00140930
		static readonly int 6ZB5S23Xww;

		// Token: 0x0404DB8E RID: 318350 RVA: 0x00142708 File Offset: 0x00140908
		static readonly int 3x1CFphGQv;

		// Token: 0x0404DB8F RID: 318351 RVA: 0x00142710 File Offset: 0x00140910
		static readonly int ZjrASsSsT5;

		// Token: 0x0404DB90 RID: 318352 RVA: 0x00142718 File Offset: 0x00140918
		static readonly int wB2zWnRRQk;

		// Token: 0x0404DB91 RID: 318353 RVA: 0x00142720 File Offset: 0x00140920
		static readonly int WwVKbz9mtH;

		// Token: 0x0404DB92 RID: 318354 RVA: 0x00142728 File Offset: 0x00140928
		static readonly int DqTyJWsBmj;

		// Token: 0x0404DB93 RID: 318355 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int kKE0A25Cpc;

		// Token: 0x0404DB94 RID: 318356 RVA: 0x00142738 File Offset: 0x00140938
		static readonly int XQ0pYmOhjd;

		// Token: 0x0404DB95 RID: 318357 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int tp8L2FrEqA;

		// Token: 0x0404DB96 RID: 318358 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 5QoqAMseJi;

		// Token: 0x0404DB97 RID: 318359 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 366Rtx0nZg;

		// Token: 0x0404DB98 RID: 318360 RVA: 0x00142740 File Offset: 0x00140940
		static readonly int HLcJ04M284;

		// Token: 0x0404DB99 RID: 318361 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int K1WogHlKpM;

		// Token: 0x0404DB9A RID: 318362 RVA: 0x00142748 File Offset: 0x00140948
		static readonly int 4uXAjxsqbF;

		// Token: 0x0404DB9B RID: 318363 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ODoJ3uxf0F;

		// Token: 0x0404DB9C RID: 318364 RVA: 0x00142750 File Offset: 0x00140950
		static readonly int A0fOYCkSvm;

		// Token: 0x0404DB9D RID: 318365 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Lp8NmXxcjC;

		// Token: 0x0404DB9E RID: 318366 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Lfa2pGNMvw;

		// Token: 0x0404DB9F RID: 318367 RVA: 0x00142758 File Offset: 0x00140958
		static readonly int TFUjMDOJlh;

		// Token: 0x0404DBA0 RID: 318368 RVA: 0x00142760 File Offset: 0x00140960
		static readonly int Ma5z3jFahf;

		// Token: 0x0404DBA1 RID: 318369 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 6V6x3eZniR;

		// Token: 0x0404DBA2 RID: 318370 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yXg8SGVYBi;

		// Token: 0x0404DBA3 RID: 318371 RVA: 0x00142750 File Offset: 0x00140950
		static readonly int Io0Bzvjl8G;

		// Token: 0x0404DBA4 RID: 318372 RVA: 0x00142768 File Offset: 0x00140968
		static readonly int BxpQz8Jhqr;

		// Token: 0x0404DBA5 RID: 318373 RVA: 0x00142770 File Offset: 0x00140970
		static readonly int olkTtz47hx;

		// Token: 0x0404DBA6 RID: 318374 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int NrY9XSe57I;

		// Token: 0x0404DBA7 RID: 318375 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 5yobQAsQIU;

		// Token: 0x0404DBA8 RID: 318376 RVA: 0x00142778 File Offset: 0x00140978
		static readonly int 6ysU3hDhSA;

		// Token: 0x0404DBA9 RID: 318377 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 0lDL3TZp2h;

		// Token: 0x0404DBAA RID: 318378 RVA: 0x00142780 File Offset: 0x00140980
		static readonly int dOjhvz6ICs;

		// Token: 0x0404DBAB RID: 318379 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int GoyN1Y8DFz;

		// Token: 0x0404DBAC RID: 318380 RVA: 0x00142788 File Offset: 0x00140988
		static readonly int O7n6SUudi7;

		// Token: 0x0404DBAD RID: 318381 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int lCXl0sOLjD;

		// Token: 0x0404DBAE RID: 318382 RVA: 0x00142790 File Offset: 0x00140990
		static readonly int k5ej3Mw0Ue;

		// Token: 0x0404DBAF RID: 318383 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int UVkDSflmOb;

		// Token: 0x0404DBB0 RID: 318384 RVA: 0x00142798 File Offset: 0x00140998
		static readonly int FdkFHERNWI;

		// Token: 0x0404DBB1 RID: 318385 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int JxeBOTdDDG;

		// Token: 0x0404DBB2 RID: 318386 RVA: 0x00142780 File Offset: 0x00140980
		static readonly int h4JDmPbTTU;

		// Token: 0x0404DBB3 RID: 318387 RVA: 0x00142788 File Offset: 0x00140988
		static readonly int Hm6I8HUYcy;

		// Token: 0x0404DBB4 RID: 318388 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 4jdLVh1jy8;

		// Token: 0x0404DBB5 RID: 318389 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ChjI3LUhd1;

		// Token: 0x0404DBB6 RID: 318390 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int m74CAh1VCH;

		// Token: 0x0404DBB7 RID: 318391 RVA: 0x001427A0 File Offset: 0x001409A0
		static readonly int 8FlOL8a7sF;

		// Token: 0x0404DBB8 RID: 318392 RVA: 0x001427A8 File Offset: 0x001409A8
		static readonly int X2fURkCxOx;

		// Token: 0x0404DBB9 RID: 318393 RVA: 0x001427B0 File Offset: 0x001409B0
		static readonly int wx4kM7obKx;

		// Token: 0x0404DBBA RID: 318394 RVA: 0x001427B8 File Offset: 0x001409B8
		static readonly int pggq976U75;

		// Token: 0x0404DBBB RID: 318395 RVA: 0x001427C0 File Offset: 0x001409C0
		static readonly int uXzYducjua;

		// Token: 0x0404DBBC RID: 318396 RVA: 0x001427C8 File Offset: 0x001409C8
		static readonly int eEHPVLKACO;

		// Token: 0x0404DBBD RID: 318397 RVA: 0x001427D0 File Offset: 0x001409D0
		static readonly int T9w4Z1WyUU;

		// Token: 0x0404DBBE RID: 318398 RVA: 0x001427D8 File Offset: 0x001409D8
		static readonly int ns0SDZ8gHc;

		// Token: 0x0404DBBF RID: 318399 RVA: 0x001427E0 File Offset: 0x001409E0
		static readonly int eEqtSlYRVy;

		// Token: 0x0404DBC0 RID: 318400 RVA: 0x001427E8 File Offset: 0x001409E8
		static readonly int x5Ssmuk48m;

		// Token: 0x0404DBC1 RID: 318401 RVA: 0x001427F0 File Offset: 0x001409F0
		static readonly int XnPaxwNzM6;

		// Token: 0x0404DBC2 RID: 318402 RVA: 0x001427F8 File Offset: 0x001409F8
		static readonly int Mn3ktOTCly;

		// Token: 0x0404DBC3 RID: 318403 RVA: 0x00142800 File Offset: 0x00140A00
		static readonly int dFcghrZHqS;

		// Token: 0x0404DBC4 RID: 318404 RVA: 0x00142808 File Offset: 0x00140A08
		static readonly int yEhfE0zQ6g;

		// Token: 0x0404DBC5 RID: 318405 RVA: 0x00142810 File Offset: 0x00140A10
		static readonly int XjEZlJCs9X;

		// Token: 0x0404DBC6 RID: 318406 RVA: 0x00142818 File Offset: 0x00140A18
		static readonly int bhSKISLs3F;

		// Token: 0x0404DBC7 RID: 318407 RVA: 0x00142820 File Offset: 0x00140A20
		static readonly int WFI3HIGXf2;

		// Token: 0x0404DBC8 RID: 318408 RVA: 0x00142828 File Offset: 0x00140A28
		static readonly int ZCFFb3AD4X;

		// Token: 0x0404DBC9 RID: 318409 RVA: 0x00142830 File Offset: 0x00140A30
		static readonly int prIT0QvXWv;

		// Token: 0x0404DBCA RID: 318410 RVA: 0x00142838 File Offset: 0x00140A38
		static readonly int pGX1JRaLSd;

		// Token: 0x0404DBCB RID: 318411 RVA: 0x00142840 File Offset: 0x00140A40
		static readonly int CoMG7YcMsO;

		// Token: 0x0404DBCC RID: 318412 RVA: 0x00142848 File Offset: 0x00140A48
		static readonly int SIyfZp6zD0;

		// Token: 0x0404DBCD RID: 318413 RVA: 0x00142850 File Offset: 0x00140A50
		static readonly int WtBtNSpO5J;

		// Token: 0x0404DBCE RID: 318414 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int czubUAeCVb;

		// Token: 0x0404DBCF RID: 318415 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int yjoHdhS2be;

		// Token: 0x0404DBD0 RID: 318416 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int UlHbGTnd3p;

		// Token: 0x0404DBD1 RID: 318417 RVA: 0x00142858 File Offset: 0x00140A58
		static readonly int tNQjvdXWKZ;

		// Token: 0x0404DBD2 RID: 318418 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int K4elCxE3Pp;

		// Token: 0x0404DBD3 RID: 318419 RVA: 0x00142860 File Offset: 0x00140A60
		static readonly int Axwbz1rTVB;

		// Token: 0x0404DBD4 RID: 318420 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int WBJqskSFVA;

		// Token: 0x0404DBD5 RID: 318421 RVA: 0x00142868 File Offset: 0x00140A68
		static readonly int J6rCTaHgZT;

		// Token: 0x0404DBD6 RID: 318422 RVA: 0x00142870 File Offset: 0x00140A70
		static readonly int PtNNo5bzu4;

		// Token: 0x0404DBD7 RID: 318423 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int vEBIDJvx2b;

		// Token: 0x0404DBD8 RID: 318424 RVA: 0x00142878 File Offset: 0x00140A78
		static readonly int f9iPgEFtHY;

		// Token: 0x0404DBD9 RID: 318425 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int uK4Cwmy6Bx;

		// Token: 0x0404DBDA RID: 318426 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int IcUbOF5i9K;

		// Token: 0x0404DBDB RID: 318427 RVA: 0x00142880 File Offset: 0x00140A80
		static readonly int pTn7xPL8rk;

		// Token: 0x0404DBDC RID: 318428 RVA: 0x00142858 File Offset: 0x00140A58
		static readonly int zrsVKlK8Wa;

		// Token: 0x0404DBDD RID: 318429 RVA: 0x00142888 File Offset: 0x00140A88
		static readonly int UywFSCoHAa;

		// Token: 0x0404DBDE RID: 318430 RVA: 0x00142890 File Offset: 0x00140A90
		static readonly int Igu6tag6Og;

		// Token: 0x0404DBDF RID: 318431 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int b0Pa7bu9Qn;

		// Token: 0x0404DBE0 RID: 318432 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 56Mj00hipu;

		// Token: 0x0404DBE1 RID: 318433 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kD7QbS7vlt;

		// Token: 0x0404DBE2 RID: 318434 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int EOu08ejVI1;

		// Token: 0x0404DBE3 RID: 318435 RVA: 0x00142898 File Offset: 0x00140A98
		static readonly int So0WfMULG3;

		// Token: 0x0404DBE4 RID: 318436 RVA: 0x001428A0 File Offset: 0x00140AA0
		static readonly int 28Qd5X288o;

		// Token: 0x0404DBE5 RID: 318437 RVA: 0x001428A8 File Offset: 0x00140AA8
		static readonly int d8YgjrMWkV;

		// Token: 0x0404DBE6 RID: 318438 RVA: 0x001428B0 File Offset: 0x00140AB0
		static readonly int QMayc6NlvP;

		// Token: 0x0404DBE7 RID: 318439 RVA: 0x001428B8 File Offset: 0x00140AB8
		static readonly int 8vpr1G7Q4k;

		// Token: 0x0404DBE8 RID: 318440 RVA: 0x001428C0 File Offset: 0x00140AC0
		static readonly int llWdXUQTxx;

		// Token: 0x0404DBE9 RID: 318441 RVA: 0x001428C8 File Offset: 0x00140AC8
		static readonly int A8kunqicB9;

		// Token: 0x0404DBEA RID: 318442 RVA: 0x001428D0 File Offset: 0x00140AD0
		static readonly int KRNtqsSqpd;

		// Token: 0x0404DBEB RID: 318443 RVA: 0x001428D8 File Offset: 0x00140AD8
		static readonly int t5b9tpz6bI;

		// Token: 0x0404DBEC RID: 318444 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int p3x7O9K5EK;

		// Token: 0x0404DBED RID: 318445 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int hfP4aUXmxp;

		// Token: 0x0404DBEE RID: 318446 RVA: 0x001428E0 File Offset: 0x00140AE0
		static readonly int BjoUEFglA7;

		// Token: 0x0404DBEF RID: 318447 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1mB2UQdQeq;

		// Token: 0x0404DBF0 RID: 318448 RVA: 0x001428E8 File Offset: 0x00140AE8
		static readonly int hXmf5OphiZ;

		// Token: 0x0404DBF1 RID: 318449 RVA: 0x001428F0 File Offset: 0x00140AF0
		static readonly int RMIvHGPd3J;

		// Token: 0x0404DBF2 RID: 318450 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int cj4GT5eWkJ;

		// Token: 0x0404DBF3 RID: 318451 RVA: 0x001428F8 File Offset: 0x00140AF8
		static readonly int 0HHGHn6JZz;

		// Token: 0x0404DBF4 RID: 318452 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Z8ClqodPvN;

		// Token: 0x0404DBF5 RID: 318453 RVA: 0x00142900 File Offset: 0x00140B00
		static readonly int BAWVO7cfMA;

		// Token: 0x0404DBF6 RID: 318454 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int tS7ZiKECod;

		// Token: 0x0404DBF7 RID: 318455 RVA: 0x00142908 File Offset: 0x00140B08
		static readonly int JFEDtdhTao;

		// Token: 0x0404DBF8 RID: 318456 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int bPlWI0uw2J;

		// Token: 0x0404DBF9 RID: 318457 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Lb7ZGGBnDg;

		// Token: 0x0404DBFA RID: 318458 RVA: 0x001428F8 File Offset: 0x00140AF8
		static readonly int kblSE56Tlu;

		// Token: 0x0404DBFB RID: 318459 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int aJFhierlRr;

		// Token: 0x0404DBFC RID: 318460 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ZSKeRsIo6m;

		// Token: 0x0404DBFD RID: 318461 RVA: 0x00142908 File Offset: 0x00140B08
		static readonly int c3Q4EAoSSM;

		// Token: 0x0404DBFE RID: 318462 RVA: 0x00142910 File Offset: 0x00140B10
		static readonly int 3bKHsCWZ0l;

		// Token: 0x0404DBFF RID: 318463 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int ZZWVGSRGAW;

		// Token: 0x0404DC00 RID: 318464 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int xRW8Rh2Kdh;

		// Token: 0x0404DC01 RID: 318465 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 0YTFx8HCvP;

		// Token: 0x0404DC02 RID: 318466 RVA: 0x00142918 File Offset: 0x00140B18
		static readonly int VtyVNDh5xw;

		// Token: 0x0404DC03 RID: 318467 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int thS6YmELzL;

		// Token: 0x0404DC04 RID: 318468 RVA: 0x00142920 File Offset: 0x00140B20
		static readonly int JL6TvBGRhI;

		// Token: 0x0404DC05 RID: 318469 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KOUvADdBvO;

		// Token: 0x0404DC06 RID: 318470 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 97XrxSGXqL;

		// Token: 0x0404DC07 RID: 318471 RVA: 0x00142928 File Offset: 0x00140B28
		static readonly int 35MjGKxejL;

		// Token: 0x0404DC08 RID: 318472 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 6QXoleMh6V;

		// Token: 0x0404DC09 RID: 318473 RVA: 0x00142930 File Offset: 0x00140B30
		static readonly int ICakMLxPfc;

		// Token: 0x0404DC0A RID: 318474 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 4slVOPBvoz;

		// Token: 0x0404DC0B RID: 318475 RVA: 0x00142938 File Offset: 0x00140B38
		static readonly int Q9bjStjsFT;

		// Token: 0x0404DC0C RID: 318476 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int FjbVC1fmX4;

		// Token: 0x0404DC0D RID: 318477 RVA: 0x00142940 File Offset: 0x00140B40
		static readonly int Xi8GRNpCaW;

		// Token: 0x0404DC0E RID: 318478 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int cb2GEJk0Sd;

		// Token: 0x0404DC0F RID: 318479 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mEJMXVRQSX;

		// Token: 0x0404DC10 RID: 318480 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int tZXucsAVSE;

		// Token: 0x0404DC11 RID: 318481 RVA: 0x00142930 File Offset: 0x00140B30
		static readonly int DhSs0orUQ3;

		// Token: 0x0404DC12 RID: 318482 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int QpT4SSYwt5;

		// Token: 0x0404DC13 RID: 318483 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 6ZtCnDEIoV;

		// Token: 0x0404DC14 RID: 318484 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int JPhOZFvaWs;

		// Token: 0x0404DC15 RID: 318485 RVA: 0x00142948 File Offset: 0x00140B48
		static readonly int o79ZHEGccJ;

		// Token: 0x0404DC16 RID: 318486 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int UOlWIoxQFw;

		// Token: 0x0404DC17 RID: 318487 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int jiq4tAHEfN;

		// Token: 0x0404DC18 RID: 318488 RVA: 0x00142950 File Offset: 0x00140B50
		static readonly int g7ZAR8ZT5i;

		// Token: 0x0404DC19 RID: 318489 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7lpeB4oLGu;

		// Token: 0x0404DC1A RID: 318490 RVA: 0x00142958 File Offset: 0x00140B58
		static readonly int RfVjIFREqG;

		// Token: 0x0404DC1B RID: 318491 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 6B7PnWzkEJ;

		// Token: 0x0404DC1C RID: 318492 RVA: 0x00142960 File Offset: 0x00140B60
		static readonly int OeUgz83L3y;

		// Token: 0x0404DC1D RID: 318493 RVA: 0x00142950 File Offset: 0x00140B50
		static readonly int W68u5Amz1M;

		// Token: 0x0404DC1E RID: 318494 RVA: 0x00142958 File Offset: 0x00140B58
		static readonly int rVnyl5na0o;

		// Token: 0x0404DC1F RID: 318495 RVA: 0x00142960 File Offset: 0x00140B60
		static readonly int FDG7gwKyuK;

		// Token: 0x0404DC20 RID: 318496 RVA: 0x00142968 File Offset: 0x00140B68
		static readonly int MFL1uADNTn;

		// Token: 0x0404DC21 RID: 318497 RVA: 0x00142970 File Offset: 0x00140B70
		static readonly int u9s2b30g43;

		// Token: 0x0404DC22 RID: 318498 RVA: 0x00142978 File Offset: 0x00140B78
		static readonly int VcUOtSzAOI;

		// Token: 0x0404DC23 RID: 318499 RVA: 0x00142980 File Offset: 0x00140B80
		static readonly int zyFr9lKwDl;

		// Token: 0x0404DC24 RID: 318500 RVA: 0x00142988 File Offset: 0x00140B88
		static readonly int 2aHN4GUNfm;

		// Token: 0x0404DC25 RID: 318501 RVA: 0x00142990 File Offset: 0x00140B90
		static readonly int 6o30zuv6Ic;

		// Token: 0x0404DC26 RID: 318502 RVA: 0x00142998 File Offset: 0x00140B98
		static readonly int KC9Kx63B20;

		// Token: 0x0404DC27 RID: 318503 RVA: 0x001429A0 File Offset: 0x00140BA0
		static readonly int tEcTB4UGUm;

		// Token: 0x0404DC28 RID: 318504 RVA: 0x001429A8 File Offset: 0x00140BA8
		static readonly int 7mflML4O2P;

		// Token: 0x0404DC29 RID: 318505 RVA: 0x001429B0 File Offset: 0x00140BB0
		static readonly int 0Nola0a7a8;

		// Token: 0x0404DC2A RID: 318506 RVA: 0x001429B8 File Offset: 0x00140BB8
		static readonly int MTUp31Ljz4;

		// Token: 0x0404DC2B RID: 318507 RVA: 0x001429C0 File Offset: 0x00140BC0
		static readonly int ZomfeigX7l;

		// Token: 0x0404DC2C RID: 318508 RVA: 0x001429C8 File Offset: 0x00140BC8
		static readonly int BoJm9fa12K;

		// Token: 0x0404DC2D RID: 318509 RVA: 0x001429D0 File Offset: 0x00140BD0
		static readonly int eWqVaoRzsU;

		// Token: 0x0404DC2E RID: 318510 RVA: 0x001429D8 File Offset: 0x00140BD8
		static readonly int 9UZ70MkIG2;

		// Token: 0x0404DC2F RID: 318511 RVA: 0x001429E0 File Offset: 0x00140BE0
		static readonly int TD9y6hKrpX;

		// Token: 0x0404DC30 RID: 318512 RVA: 0x001429E8 File Offset: 0x00140BE8
		static readonly int bUqoaC7QF0;

		// Token: 0x0404DC31 RID: 318513 RVA: 0x001429F0 File Offset: 0x00140BF0
		static readonly int QqpmmqPLwx;

		// Token: 0x0404DC32 RID: 318514 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 4RuA0bW2Y2;

		// Token: 0x0404DC33 RID: 318515 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int djJU3pouhx;

		// Token: 0x0404DC34 RID: 318516 RVA: 0x001429F8 File Offset: 0x00140BF8
		static readonly int OUCQlmXXMQ;

		// Token: 0x0404DC35 RID: 318517 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int S952cJjqy9;

		// Token: 0x0404DC36 RID: 318518 RVA: 0x00142A00 File Offset: 0x00140C00
		static readonly int pE1NWrhUt6;

		// Token: 0x0404DC37 RID: 318519 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Cen9ikPeZN;

		// Token: 0x0404DC38 RID: 318520 RVA: 0x00142A08 File Offset: 0x00140C08
		static readonly int D9qIkeoQ1t;

		// Token: 0x0404DC39 RID: 318521 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int G76iHKcz34;

		// Token: 0x0404DC3A RID: 318522 RVA: 0x00142A10 File Offset: 0x00140C10
		static readonly int FCnQNxV6U2;

		// Token: 0x0404DC3B RID: 318523 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 4FQk5qYtm2;

		// Token: 0x0404DC3C RID: 318524 RVA: 0x00142A18 File Offset: 0x00140C18
		static readonly int CQdA0EiE1Y;

		// Token: 0x0404DC3D RID: 318525 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int IZkfHAWa5x;

		// Token: 0x0404DC3E RID: 318526 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Is69yArVnb;

		// Token: 0x0404DC3F RID: 318527 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vtNA1zjnZJ;

		// Token: 0x0404DC40 RID: 318528 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int OQE6tfevc4;

		// Token: 0x0404DC41 RID: 318529 RVA: 0x00142A10 File Offset: 0x00140C10
		static readonly int U8yzuUTdLz;

		// Token: 0x0404DC42 RID: 318530 RVA: 0x00142A18 File Offset: 0x00140C18
		static readonly int XNbamZMjnS;

		// Token: 0x0404DC43 RID: 318531 RVA: 0x00142A20 File Offset: 0x00140C20
		static readonly int bsAwi1n9PT;

		// Token: 0x0404DC44 RID: 318532 RVA: 0x00142A28 File Offset: 0x00140C28
		static readonly int f52sHw5XQg;

		// Token: 0x0404DC45 RID: 318533 RVA: 0x00142A30 File Offset: 0x00140C30
		static readonly int fFckvByoTU;

		// Token: 0x0404DC46 RID: 318534 RVA: 0x00142A38 File Offset: 0x00140C38
		static readonly int T5IKdl8BR2;

		// Token: 0x0404DC47 RID: 318535 RVA: 0x00142A40 File Offset: 0x00140C40
		static readonly int rUO1TbUtT0;

		// Token: 0x0404DC48 RID: 318536 RVA: 0x00142A48 File Offset: 0x00140C48
		static readonly int eyTGwVQZAg;

		// Token: 0x0404DC49 RID: 318537 RVA: 0x00142A50 File Offset: 0x00140C50
		static readonly int C9q4AkxrPf;

		// Token: 0x0404DC4A RID: 318538 RVA: 0x00142A58 File Offset: 0x00140C58
		static readonly int y3GXzL1kQU;

		// Token: 0x0404DC4B RID: 318539 RVA: 0x00142A60 File Offset: 0x00140C60
		static readonly int qFVd0elBXH;

		// Token: 0x0404DC4C RID: 318540 RVA: 0x00142A68 File Offset: 0x00140C68
		static readonly int ViBuzrnT1t;

		// Token: 0x0404DC4D RID: 318541 RVA: 0x00142A70 File Offset: 0x00140C70
		static readonly int nmexCks5Rl;

		// Token: 0x0404DC4E RID: 318542 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int dpJqz7oNEf;

		// Token: 0x0404DC4F RID: 318543 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 8wUHKP1ViH;

		// Token: 0x0404DC50 RID: 318544 RVA: 0x00142A78 File Offset: 0x00140C78
		static readonly int hithqDkhaP;

		// Token: 0x0404DC51 RID: 318545 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int wqtwnpZV52;

		// Token: 0x0404DC52 RID: 318546 RVA: 0x00142A80 File Offset: 0x00140C80
		static readonly int DaOVu1SXnw;

		// Token: 0x0404DC53 RID: 318547 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int tWXJD46m9v;

		// Token: 0x0404DC54 RID: 318548 RVA: 0x00142A88 File Offset: 0x00140C88
		static readonly int WGwytSChdf;

		// Token: 0x0404DC55 RID: 318549 RVA: 0x00142A78 File Offset: 0x00140C78
		static readonly int 0fapEGUXwy;

		// Token: 0x0404DC56 RID: 318550 RVA: 0x00142A80 File Offset: 0x00140C80
		static readonly int vN4ogZTkss;

		// Token: 0x0404DC57 RID: 318551 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int swVJf6oalc;

		// Token: 0x0404DC58 RID: 318552 RVA: 0x00142A90 File Offset: 0x00140C90
		static readonly int yu3I6N6rF7;

		// Token: 0x0404DC59 RID: 318553 RVA: 0x00142A98 File Offset: 0x00140C98
		static readonly int kjzLAIMHSU;

		// Token: 0x0404DC5A RID: 318554 RVA: 0x00142AA0 File Offset: 0x00140CA0
		static readonly int 9czuwDKQJH;

		// Token: 0x0404DC5B RID: 318555 RVA: 0x00142AA8 File Offset: 0x00140CA8
		static readonly int b4vT9AUwsS;

		// Token: 0x0404DC5C RID: 318556 RVA: 0x00142AB0 File Offset: 0x00140CB0
		static readonly int clevIJ6KIW;

		// Token: 0x0404DC5D RID: 318557 RVA: 0x00142AB8 File Offset: 0x00140CB8
		static readonly int ugHRdW5IV2;

		// Token: 0x0404DC5E RID: 318558 RVA: 0x00142AC0 File Offset: 0x00140CC0
		static readonly int Dpi7fqxfLA;

		// Token: 0x0404DC5F RID: 318559 RVA: 0x00142AC8 File Offset: 0x00140CC8
		static readonly int yZZ91X7Dmn;

		// Token: 0x0404DC60 RID: 318560 RVA: 0x00142AD0 File Offset: 0x00140CD0
		static readonly int G9IwW5we0n;

		// Token: 0x0404DC61 RID: 318561 RVA: 0x00142AD8 File Offset: 0x00140CD8
		static readonly int ELazPxDgQb;

		// Token: 0x0404DC62 RID: 318562 RVA: 0x00142AE0 File Offset: 0x00140CE0
		static readonly int Wb9HiUHIaF;

		// Token: 0x0404DC63 RID: 318563 RVA: 0x00142AE8 File Offset: 0x00140CE8
		static readonly int Y1gsvDhvlk;

		// Token: 0x0404DC64 RID: 318564 RVA: 0x00142AF0 File Offset: 0x00140CF0
		static readonly int 4Tph6n9ktD;

		// Token: 0x0404DC65 RID: 318565 RVA: 0x00142AF8 File Offset: 0x00140CF8
		static readonly int UaxLQpAAOC;

		// Token: 0x0404DC66 RID: 318566 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int xoDuOMosDM;

		// Token: 0x0404DC67 RID: 318567 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int QS5qgDvbL4;

		// Token: 0x0404DC68 RID: 318568 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int VgYWv8EVbG;

		// Token: 0x0404DC69 RID: 318569 RVA: 0x00142B00 File Offset: 0x00140D00
		static readonly int CggiwQP4Tt;

		// Token: 0x0404DC6A RID: 318570 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8QhhxCeHoN;

		// Token: 0x0404DC6B RID: 318571 RVA: 0x00142B08 File Offset: 0x00140D08
		static readonly int 3jyTrRQr9Q;

		// Token: 0x0404DC6C RID: 318572 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ITQ7JtvX3Q;

		// Token: 0x0404DC6D RID: 318573 RVA: 0x00142B10 File Offset: 0x00140D10
		static readonly int x1Hc6E90it;

		// Token: 0x0404DC6E RID: 318574 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int d6rOMdsM1e;

		// Token: 0x0404DC6F RID: 318575 RVA: 0x00142B18 File Offset: 0x00140D18
		static readonly int 9i5Dlp9jYE;

		// Token: 0x0404DC70 RID: 318576 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int QHNXZCbWXm;

		// Token: 0x0404DC71 RID: 318577 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int RZIQwMmCuq;

		// Token: 0x0404DC72 RID: 318578 RVA: 0x00142B20 File Offset: 0x00140D20
		static readonly int BifZRP6E0Q;

		// Token: 0x0404DC73 RID: 318579 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int EZbdcVsTyJ;

		// Token: 0x0404DC74 RID: 318580 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int BVzPNjZoQZ;

		// Token: 0x0404DC75 RID: 318581 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int D7zsDrmyGK;

		// Token: 0x0404DC76 RID: 318582 RVA: 0x00142B18 File Offset: 0x00140D18
		static readonly int GXfGh18oxb;

		// Token: 0x0404DC77 RID: 318583 RVA: 0x00142B20 File Offset: 0x00140D20
		static readonly int dSNkoptQMr;

		// Token: 0x0404DC78 RID: 318584 RVA: 0x00142B28 File Offset: 0x00140D28
		static readonly int zRybNHktav;

		// Token: 0x0404DC79 RID: 318585 RVA: 0x00142B30 File Offset: 0x00140D30
		static readonly int t4NoDozsrV;

		// Token: 0x0404DC7A RID: 318586 RVA: 0x00142B38 File Offset: 0x00140D38
		static readonly int lv1y5vtODX;

		// Token: 0x0404DC7B RID: 318587 RVA: 0x00142B40 File Offset: 0x00140D40
		static readonly int 8VmZVziD3a;

		// Token: 0x0404DC7C RID: 318588 RVA: 0x00142B48 File Offset: 0x00140D48
		static readonly int ROOBriEjhA;

		// Token: 0x0404DC7D RID: 318589 RVA: 0x00142B50 File Offset: 0x00140D50
		static readonly int zAi0FDZ9fc;

		// Token: 0x0404DC7E RID: 318590 RVA: 0x00142B58 File Offset: 0x00140D58
		static readonly int XWpCxXSySN;

		// Token: 0x0404DC7F RID: 318591 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int FvzRDWh0HX;

		// Token: 0x0404DC80 RID: 318592 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int qJqDh7xvTR;

		// Token: 0x0404DC81 RID: 318593 RVA: 0x00142B60 File Offset: 0x00140D60
		static readonly int aiiaC5jLOT;

		// Token: 0x0404DC82 RID: 318594 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int QPQU5EKRxs;

		// Token: 0x0404DC83 RID: 318595 RVA: 0x00142B68 File Offset: 0x00140D68
		static readonly int gj2IvNpmez;

		// Token: 0x0404DC84 RID: 318596 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int kgeBxgNYOI;

		// Token: 0x0404DC85 RID: 318597 RVA: 0x00142B70 File Offset: 0x00140D70
		static readonly int xVlxHb2WHd;

		// Token: 0x0404DC86 RID: 318598 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int xg8lu1qZpz;

		// Token: 0x0404DC87 RID: 318599 RVA: 0x00142B78 File Offset: 0x00140D78
		static readonly int P7rZttvPgY;

		// Token: 0x0404DC88 RID: 318600 RVA: 0x00142B60 File Offset: 0x00140D60
		static readonly int 0vCp4L7EBU;

		// Token: 0x0404DC89 RID: 318601 RVA: 0x00142B80 File Offset: 0x00140D80
		static readonly int UTeABDi3R6;

		// Token: 0x0404DC8A RID: 318602 RVA: 0x00142B88 File Offset: 0x00140D88
		static readonly int 0ytZ20oMDX;

		// Token: 0x0404DC8B RID: 318603 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int pnztnBdTqj;

		// Token: 0x0404DC8C RID: 318604 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 3lYVe6cqXp;

		// Token: 0x0404DC8D RID: 318605 RVA: 0x00142B78 File Offset: 0x00140D78
		static readonly int L27kiBCnwE;

		// Token: 0x0404DC8E RID: 318606 RVA: 0x00142B90 File Offset: 0x00140D90
		static readonly int gvBoorduWA;

		// Token: 0x0404DC8F RID: 318607 RVA: 0x00142B98 File Offset: 0x00140D98
		static readonly int kOMrCOaX45;

		// Token: 0x0404DC90 RID: 318608 RVA: 0x00142BA0 File Offset: 0x00140DA0
		static readonly int X7yXLxpPLl;

		// Token: 0x0404DC91 RID: 318609 RVA: 0x00142BA8 File Offset: 0x00140DA8
		static readonly int 8zgmCIktrw;

		// Token: 0x0404DC92 RID: 318610 RVA: 0x00142BB0 File Offset: 0x00140DB0
		static readonly int crTWF6pPhT;

		// Token: 0x0404DC93 RID: 318611 RVA: 0x00142BB8 File Offset: 0x00140DB8
		static readonly int los1qi6nc0;

		// Token: 0x0404DC94 RID: 318612 RVA: 0x00142BC0 File Offset: 0x00140DC0
		static readonly int BOjvBusjp4;

		// Token: 0x0404DC95 RID: 318613 RVA: 0x00142BC8 File Offset: 0x00140DC8
		static readonly int oqqIcpobSO;

		// Token: 0x0404DC96 RID: 318614 RVA: 0x00142BD0 File Offset: 0x00140DD0
		static readonly int IZr2AUGo5e;

		// Token: 0x0404DC97 RID: 318615 RVA: 0x00142BD8 File Offset: 0x00140DD8
		static readonly int L7R0vNIiUV;

		// Token: 0x0404DC98 RID: 318616 RVA: 0x00142BE0 File Offset: 0x00140DE0
		static readonly int OFkmp57kYA;

		// Token: 0x0404DC99 RID: 318617 RVA: 0x00142BE8 File Offset: 0x00140DE8
		static readonly int 4eUOsmhrvr;

		// Token: 0x0404DC9A RID: 318618 RVA: 0x00142BF0 File Offset: 0x00140DF0
		static readonly int nDoKtqZ0XP;

		// Token: 0x0404DC9B RID: 318619 RVA: 0x00142BF8 File Offset: 0x00140DF8
		static readonly int hFG7ACyFNE;

		// Token: 0x0404DC9C RID: 318620 RVA: 0x00142C00 File Offset: 0x00140E00
		static readonly int WgQ4jqmCIJ;

		// Token: 0x0404DC9D RID: 318621 RVA: 0x00142C08 File Offset: 0x00140E08
		static readonly int qbxnrLbZ38;

		// Token: 0x0404DC9E RID: 318622 RVA: 0x00142C10 File Offset: 0x00140E10
		static readonly int fHNJdyYXNp;

		// Token: 0x0404DC9F RID: 318623 RVA: 0x00142C18 File Offset: 0x00140E18
		static readonly int xceqVHxtlC;

		// Token: 0x0404DCA0 RID: 318624 RVA: 0x00142C20 File Offset: 0x00140E20
		static readonly int EWrNiFSdPz;

		// Token: 0x0404DCA1 RID: 318625 RVA: 0x00142C28 File Offset: 0x00140E28
		static readonly int kYLOjOSGav;

		// Token: 0x0404DCA2 RID: 318626 RVA: 0x00142C30 File Offset: 0x00140E30
		static readonly int SOycVO7HRj;

		// Token: 0x0404DCA3 RID: 318627 RVA: 0x00142C38 File Offset: 0x00140E38
		static readonly int Xsy03Ja9kY;

		// Token: 0x0404DCA4 RID: 318628 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int g4IYEYQPGH;

		// Token: 0x0404DCA5 RID: 318629 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int zqSzu0hO2T;

		// Token: 0x0404DCA6 RID: 318630 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int HKMqb2kVVZ;

		// Token: 0x0404DCA7 RID: 318631 RVA: 0x00142C40 File Offset: 0x00140E40
		static readonly int ySgCOXGaX7;

		// Token: 0x0404DCA8 RID: 318632 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8sAKurZ8FD;

		// Token: 0x0404DCA9 RID: 318633 RVA: 0x00142C48 File Offset: 0x00140E48
		static readonly int lLHQQVsc7M;

		// Token: 0x0404DCAA RID: 318634 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int y43qTgJQkW;

		// Token: 0x0404DCAB RID: 318635 RVA: 0x00142C50 File Offset: 0x00140E50
		static readonly int tH04VZKB5t;

		// Token: 0x0404DCAC RID: 318636 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int dlPSymKPv3;

		// Token: 0x0404DCAD RID: 318637 RVA: 0x00142C58 File Offset: 0x00140E58
		static readonly int pocLJDyT0N;

		// Token: 0x0404DCAE RID: 318638 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int hIXsTdVM50;

		// Token: 0x0404DCAF RID: 318639 RVA: 0x00142C60 File Offset: 0x00140E60
		static readonly int LqgOsNpl2q;

		// Token: 0x0404DCB0 RID: 318640 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int V4frrFpovS;

		// Token: 0x0404DCB1 RID: 318641 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int l0LsLUNh8U;

		// Token: 0x0404DCB2 RID: 318642 RVA: 0x00142C68 File Offset: 0x00140E68
		static readonly int R8U4s9HOd5;

		// Token: 0x0404DCB3 RID: 318643 RVA: 0x00142C70 File Offset: 0x00140E70
		static readonly int YMbJ1nnqBN;

		// Token: 0x0404DCB4 RID: 318644 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int yqbmPUfyCX;

		// Token: 0x0404DCB5 RID: 318645 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9HmhZXkk8s;

		// Token: 0x0404DCB6 RID: 318646 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7aLz4YZB0i;

		// Token: 0x0404DCB7 RID: 318647 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int rgfvfkhrpX;

		// Token: 0x0404DCB8 RID: 318648 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int eTLF6Qk3ud;

		// Token: 0x0404DCB9 RID: 318649 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int CDrTQXels1;

		// Token: 0x0404DCBA RID: 318650 RVA: 0x00142C60 File Offset: 0x00140E60
		static readonly int 5e7eqdl1Cz;

		// Token: 0x0404DCBB RID: 318651 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 035kNnPG3n;

		// Token: 0x0404DCBC RID: 318652 RVA: 0x00142C78 File Offset: 0x00140E78
		static readonly int xgQWfnzMeH;

		// Token: 0x0404DCBD RID: 318653 RVA: 0x00142C80 File Offset: 0x00140E80
		static readonly int F58xc9VqYc;

		// Token: 0x0404DCBE RID: 318654 RVA: 0x00142C88 File Offset: 0x00140E88
		static readonly int os15nJIGFm;

		// Token: 0x0404DCBF RID: 318655 RVA: 0x00142C90 File Offset: 0x00140E90
		static readonly int IYrEDYNl8C;

		// Token: 0x0404DCC0 RID: 318656 RVA: 0x00142C98 File Offset: 0x00140E98
		static readonly int oZW4t44HIN;

		// Token: 0x0404DCC1 RID: 318657 RVA: 0x00142CA0 File Offset: 0x00140EA0
		static readonly int Sira9FoVtV;

		// Token: 0x0404DCC2 RID: 318658 RVA: 0x00142CA8 File Offset: 0x00140EA8
		static readonly int fsH29rN4uD;

		// Token: 0x0404DCC3 RID: 318659 RVA: 0x00142CB0 File Offset: 0x00140EB0
		static readonly int wurWyPW6Ms;

		// Token: 0x0404DCC4 RID: 318660 RVA: 0x00142CB8 File Offset: 0x00140EB8
		static readonly int PB81UjrQF8;

		// Token: 0x0404DCC5 RID: 318661 RVA: 0x00142CC0 File Offset: 0x00140EC0
		static readonly int u12nh5Re4B;

		// Token: 0x0404DCC6 RID: 318662 RVA: 0x00142CC8 File Offset: 0x00140EC8
		static readonly int q9WEbh0Vmt;

		// Token: 0x0404DCC7 RID: 318663 RVA: 0x00142CD0 File Offset: 0x00140ED0
		static readonly int tsJAGetQia;

		// Token: 0x0404DCC8 RID: 318664 RVA: 0x00142CD8 File Offset: 0x00140ED8
		static readonly int 97yvT52Ey2;

		// Token: 0x0404DCC9 RID: 318665 RVA: 0x00142CE0 File Offset: 0x00140EE0
		static readonly int 72CKBPo4aw;

		// Token: 0x0404DCCA RID: 318666 RVA: 0x00142CE8 File Offset: 0x00140EE8
		static readonly int sWoWPBr1gD;

		// Token: 0x0404DCCB RID: 318667 RVA: 0x00142CF0 File Offset: 0x00140EF0
		static readonly int MB5eCtLkug;

		// Token: 0x0404DCCC RID: 318668 RVA: 0x00142CF8 File Offset: 0x00140EF8
		static readonly int ovgtv1p990;

		// Token: 0x0404DCCD RID: 318669 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 0z0vrmTcgS;

		// Token: 0x0404DCCE RID: 318670 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int NBivq66iHR;

		// Token: 0x0404DCCF RID: 318671 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int EDK3I704kY;

		// Token: 0x0404DCD0 RID: 318672 RVA: 0x00142D00 File Offset: 0x00140F00
		static readonly int Wr2qNWLJwZ;

		// Token: 0x0404DCD1 RID: 318673 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int asEcSnNuDz;

		// Token: 0x0404DCD2 RID: 318674 RVA: 0x00142D08 File Offset: 0x00140F08
		static readonly int 4H2rvwp6nu;

		// Token: 0x0404DCD3 RID: 318675 RVA: 0x00142D10 File Offset: 0x00140F10
		static readonly int wY2I5fJ1iT;

		// Token: 0x0404DCD4 RID: 318676 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int vwvs0V9rle;

		// Token: 0x0404DCD5 RID: 318677 RVA: 0x00142D18 File Offset: 0x00140F18
		static readonly int tF0vdOzK4a;

		// Token: 0x0404DCD6 RID: 318678 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int rPgCmC05gw;

		// Token: 0x0404DCD7 RID: 318679 RVA: 0x00142D20 File Offset: 0x00140F20
		static readonly int eWMtDHWK0a;

		// Token: 0x0404DCD8 RID: 318680 RVA: 0x00142D00 File Offset: 0x00140F00
		static readonly int x7UJBrhGor;

		// Token: 0x0404DCD9 RID: 318681 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int p87HmgQsFy;

		// Token: 0x0404DCDA RID: 318682 RVA: 0x00142D28 File Offset: 0x00140F28
		static readonly int fDLy9X2HrV;

		// Token: 0x0404DCDB RID: 318683 RVA: 0x00142D30 File Offset: 0x00140F30
		static readonly int 2pTemt4WB5;

		// Token: 0x0404DCDC RID: 318684 RVA: 0x00142D20 File Offset: 0x00140F20
		static readonly int etRyHgYEGh;

		// Token: 0x0404DCDD RID: 318685 RVA: 0x00142D38 File Offset: 0x00140F38
		static readonly int 1nEB5uwfJn;

		// Token: 0x0404DCDE RID: 318686 RVA: 0x00142D40 File Offset: 0x00140F40
		static readonly int yaZSz9ocf2;

		// Token: 0x0404DCDF RID: 318687 RVA: 0x00142D48 File Offset: 0x00140F48
		static readonly int l3rJUvwWrd;

		// Token: 0x0404DCE0 RID: 318688 RVA: 0x00142D50 File Offset: 0x00140F50
		static readonly int 8yAJeOkSj2;

		// Token: 0x0404DCE1 RID: 318689 RVA: 0x00142D58 File Offset: 0x00140F58
		static readonly int 7YNXHDU89H;

		// Token: 0x0404DCE2 RID: 318690 RVA: 0x00142D60 File Offset: 0x00140F60
		static readonly int 16jO5865rJ;

		// Token: 0x0404DCE3 RID: 318691 RVA: 0x00142D68 File Offset: 0x00140F68
		static readonly int 8Zyqp9aPyk;

		// Token: 0x0404DCE4 RID: 318692 RVA: 0x00142D70 File Offset: 0x00140F70
		static readonly int ZW3m5NqTBQ;

		// Token: 0x0404DCE5 RID: 318693 RVA: 0x00142D78 File Offset: 0x00140F78
		static readonly int bxWkmCOwNg;

		// Token: 0x0404DCE6 RID: 318694 RVA: 0x00142D80 File Offset: 0x00140F80
		static readonly int SpkZ4hkgsH;

		// Token: 0x0404DCE7 RID: 318695 RVA: 0x00142D88 File Offset: 0x00140F88
		static readonly int nEJYreC6Ss;

		// Token: 0x0404DCE8 RID: 318696 RVA: 0x00142D90 File Offset: 0x00140F90
		static readonly int Rm3asKCNDn;

		// Token: 0x0404DCE9 RID: 318697 RVA: 0x00142D98 File Offset: 0x00140F98
		static readonly int vnBSSuvesX;

		// Token: 0x0404DCEA RID: 318698 RVA: 0x00142DA0 File Offset: 0x00140FA0
		static readonly int mJl4nXn72H;

		// Token: 0x0404DCEB RID: 318699 RVA: 0x00142DA8 File Offset: 0x00140FA8
		static readonly int 9SdfOqvKrt;

		// Token: 0x0404DCEC RID: 318700 RVA: 0x00142DB0 File Offset: 0x00140FB0
		static readonly int eXcFW9C1G7;

		// Token: 0x0404DCED RID: 318701 RVA: 0x00142DB8 File Offset: 0x00140FB8
		static readonly int siN4GIA9wV;

		// Token: 0x0404DCEE RID: 318702 RVA: 0x00142DC0 File Offset: 0x00140FC0
		static readonly int gFU5ncKgDl;

		// Token: 0x0404DCEF RID: 318703 RVA: 0x00142DC8 File Offset: 0x00140FC8
		static readonly int 8lw92Pqghn;

		// Token: 0x0404DCF0 RID: 318704 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Uv15ZbEiZG;

		// Token: 0x0404DCF1 RID: 318705 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int pvXWMZCgb3;

		// Token: 0x0404DCF2 RID: 318706 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int zfye8HvOC0;

		// Token: 0x0404DCF3 RID: 318707 RVA: 0x00142DD0 File Offset: 0x00140FD0
		static readonly int bdbJAuOZgL;

		// Token: 0x0404DCF4 RID: 318708 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YlH75NNawd;

		// Token: 0x0404DCF5 RID: 318709 RVA: 0x00142DD8 File Offset: 0x00140FD8
		static readonly int MJEoyz7W6S;

		// Token: 0x0404DCF6 RID: 318710 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int pzgioMUOWc;

		// Token: 0x0404DCF7 RID: 318711 RVA: 0x00142DE0 File Offset: 0x00140FE0
		static readonly int LnAQeOX1iv;

		// Token: 0x0404DCF8 RID: 318712 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4VcioRZwVK;

		// Token: 0x0404DCF9 RID: 318713 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int x1dOgjEjSt;

		// Token: 0x0404DCFA RID: 318714 RVA: 0x00142DE8 File Offset: 0x00140FE8
		static readonly int 28EURiJyJj;

		// Token: 0x0404DCFB RID: 318715 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int bGxKYUW73W;

		// Token: 0x0404DCFC RID: 318716 RVA: 0x00142DF0 File Offset: 0x00140FF0
		static readonly int xh3LpTKwu5;

		// Token: 0x0404DCFD RID: 318717 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int Jyiz35RIRF;

		// Token: 0x0404DCFE RID: 318718 RVA: 0x00142DF8 File Offset: 0x00140FF8
		static readonly int IknvsqESzL;

		// Token: 0x0404DCFF RID: 318719 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int MGp56VF2p7;

		// Token: 0x0404DD00 RID: 318720 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YXEOanh8Rd;

		// Token: 0x0404DD01 RID: 318721 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int COqyOM4Hc8;

		// Token: 0x0404DD02 RID: 318722 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int P16isDIn2h;

		// Token: 0x0404DD03 RID: 318723 RVA: 0x00142DF0 File Offset: 0x00140FF0
		static readonly int zYdTrvfYVF;

		// Token: 0x0404DD04 RID: 318724 RVA: 0x00142DF8 File Offset: 0x00140FF8
		static readonly int JGBWI7Z1qt;

		// Token: 0x0404DD05 RID: 318725 RVA: 0x00142E00 File Offset: 0x00141000
		static readonly int b7ZqsgagfW;

		// Token: 0x0404DD06 RID: 318726 RVA: 0x00142E08 File Offset: 0x00141008
		static readonly int e4FtnnvXHd;

		// Token: 0x0404DD07 RID: 318727 RVA: 0x00142E10 File Offset: 0x00141010
		static readonly int qfwXzIzjZv;

		// Token: 0x0404DD08 RID: 318728 RVA: 0x00142E18 File Offset: 0x00141018
		static readonly int nR6IG19wkK;

		// Token: 0x0404DD09 RID: 318729 RVA: 0x00142E20 File Offset: 0x00141020
		static readonly int U928kOAStf;

		// Token: 0x0404DD0A RID: 318730 RVA: 0x00142E28 File Offset: 0x00141028
		static readonly int MCtND5LC1k;

		// Token: 0x0404DD0B RID: 318731 RVA: 0x00142E30 File Offset: 0x00141030
		static readonly int q0GutN77nv;

		// Token: 0x0404DD0C RID: 318732 RVA: 0x00142E38 File Offset: 0x00141038
		static readonly int o8w6Irnxwk;

		// Token: 0x0404DD0D RID: 318733 RVA: 0x00142E40 File Offset: 0x00141040
		static readonly int Hh04ikhsFK;

		// Token: 0x0404DD0E RID: 318734 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int p65Aed2HPX;

		// Token: 0x0404DD0F RID: 318735 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int RDp70OQxFV;

		// Token: 0x0404DD10 RID: 318736 RVA: 0x00142E48 File Offset: 0x00141048
		static readonly int SYQRcIAMMI;

		// Token: 0x0404DD11 RID: 318737 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int pP2cFsDwco;

		// Token: 0x0404DD12 RID: 318738 RVA: 0x00142E50 File Offset: 0x00141050
		static readonly int yfhYTE22DU;

		// Token: 0x0404DD13 RID: 318739 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Uumt2RqohV;

		// Token: 0x0404DD14 RID: 318740 RVA: 0x00142E58 File Offset: 0x00141058
		static readonly int dq5GsBKM2H;

		// Token: 0x0404DD15 RID: 318741 RVA: 0x00142E60 File Offset: 0x00141060
		static readonly int KdUbgx017X;

		// Token: 0x0404DD16 RID: 318742 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int QII2y5mIjy;

		// Token: 0x0404DD17 RID: 318743 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int CZOHKIjbqR;

		// Token: 0x0404DD18 RID: 318744 RVA: 0x00142E68 File Offset: 0x00141068
		static readonly int 3pA6J0ZLMF;

		// Token: 0x0404DD19 RID: 318745 RVA: 0x00142E70 File Offset: 0x00141070
		static readonly int ayqKEUhDSx;

		// Token: 0x0404DD1A RID: 318746 RVA: 0x00142E48 File Offset: 0x00141048
		static readonly int ZCnDFvPNQY;

		// Token: 0x0404DD1B RID: 318747 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NZLqdlIMs7;

		// Token: 0x0404DD1C RID: 318748 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int fb5eXOtDCz;

		// Token: 0x0404DD1D RID: 318749 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int lfI311C60Y;

		// Token: 0x0404DD1E RID: 318750 RVA: 0x00142E78 File Offset: 0x00141078
		static readonly int lL4y1Bn9qd;

		// Token: 0x0404DD1F RID: 318751 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int MUVUR8GIp1;

		// Token: 0x0404DD20 RID: 318752 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int CLKawrQRym;

		// Token: 0x0404DD21 RID: 318753 RVA: 0x00142E80 File Offset: 0x00141080
		static readonly int iLWUWTgHnW;

		// Token: 0x0404DD22 RID: 318754 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ktXjnQKxm3;

		// Token: 0x0404DD23 RID: 318755 RVA: 0x00142E88 File Offset: 0x00141088
		static readonly int u4R9WZBdBJ;

		// Token: 0x0404DD24 RID: 318756 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vVKE4B8B87;

		// Token: 0x0404DD25 RID: 318757 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int b9fTQSylxg;

		// Token: 0x0404DD26 RID: 318758 RVA: 0x00142E90 File Offset: 0x00141090
		static readonly int hcp51o3W77;

		// Token: 0x0404DD27 RID: 318759 RVA: 0x00142E98 File Offset: 0x00141098
		static readonly int SCFdlPiSol;

		// Token: 0x0404DD28 RID: 318760 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int SJzobuY8sD;

		// Token: 0x0404DD29 RID: 318761 RVA: 0x00142EA0 File Offset: 0x001410A0
		static readonly int kZqfmSpPMQ;

		// Token: 0x0404DD2A RID: 318762 RVA: 0x00142EA8 File Offset: 0x001410A8
		static readonly int HlDBoZ4BrA;

		// Token: 0x0404DD2B RID: 318763 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int tg6MOXnBdH;

		// Token: 0x0404DD2C RID: 318764 RVA: 0x00142EB0 File Offset: 0x001410B0
		static readonly int P5o3W3Wj0S;

		// Token: 0x0404DD2D RID: 318765 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int kSGYdqGx9C;

		// Token: 0x0404DD2E RID: 318766 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 0XQsUEddRP;

		// Token: 0x0404DD2F RID: 318767 RVA: 0x00142EB8 File Offset: 0x001410B8
		static readonly int powFAL7Jov;

		// Token: 0x0404DD30 RID: 318768 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int CULYaaZish;

		// Token: 0x0404DD31 RID: 318769 RVA: 0x00142EC0 File Offset: 0x001410C0
		static readonly int RzBaR2p6jS;

		// Token: 0x0404DD32 RID: 318770 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Z2Sln6fAXR;

		// Token: 0x0404DD33 RID: 318771 RVA: 0x00142EC8 File Offset: 0x001410C8
		static readonly int s6IOAfL2R3;

		// Token: 0x0404DD34 RID: 318772 RVA: 0x00142ED0 File Offset: 0x001410D0
		static readonly int o4ut80mWyI;

		// Token: 0x0404DD35 RID: 318773 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int gBjWVJCkud;

		// Token: 0x0404DD36 RID: 318774 RVA: 0x00142ED8 File Offset: 0x001410D8
		static readonly int 4YLbyUqwav;

		// Token: 0x0404DD37 RID: 318775 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int qwoqnfHinx;

		// Token: 0x0404DD38 RID: 318776 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int TJMPurXv20;

		// Token: 0x0404DD39 RID: 318777 RVA: 0x00142EE0 File Offset: 0x001410E0
		static readonly int dlHx8PtT5n;

		// Token: 0x0404DD3A RID: 318778 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Jz6CbuX2t0;

		// Token: 0x0404DD3B RID: 318779 RVA: 0x00142EC0 File Offset: 0x001410C0
		static readonly int Bd77KvM5qH;

		// Token: 0x0404DD3C RID: 318780 RVA: 0x00142EE8 File Offset: 0x001410E8
		static readonly int 744jSFp0sX;

		// Token: 0x0404DD3D RID: 318781 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int vyn9ndNKxA;

		// Token: 0x0404DD3E RID: 318782 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TeCCy9oJnM;

		// Token: 0x0404DD3F RID: 318783 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int DxnxqP5WuW;

		// Token: 0x0404DD40 RID: 318784 RVA: 0x00142EF0 File Offset: 0x001410F0
		static readonly int EhKVEN07Tr;

		// Token: 0x0404DD41 RID: 318785 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int hBIpxd12vT;

		// Token: 0x0404DD42 RID: 318786 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int bfMfT7LzTY;

		// Token: 0x0404DD43 RID: 318787 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int h0Zb5wTq7l;

		// Token: 0x0404DD44 RID: 318788 RVA: 0x00142EF8 File Offset: 0x001410F8
		static readonly int Iq06pBp7AN;

		// Token: 0x0404DD45 RID: 318789 RVA: 0x00142F00 File Offset: 0x00141100
		static readonly int XDlb4jUpCG;

		// Token: 0x0404DD46 RID: 318790 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int CAo5JrmquA;

		// Token: 0x0404DD47 RID: 318791 RVA: 0x00142F08 File Offset: 0x00141108
		static readonly int JL4KKupQ0R;

		// Token: 0x0404DD48 RID: 318792 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int SOzFBeP8gW;

		// Token: 0x0404DD49 RID: 318793 RVA: 0x00142F10 File Offset: 0x00141110
		static readonly int coo0iHC4x8;

		// Token: 0x0404DD4A RID: 318794 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Z8N9DLJbQK;

		// Token: 0x0404DD4B RID: 318795 RVA: 0x00142F08 File Offset: 0x00141108
		static readonly int 3DzuyyKi3o;

		// Token: 0x0404DD4C RID: 318796 RVA: 0x00142F10 File Offset: 0x00141110
		static readonly int bnJXifgDlC;

		// Token: 0x0404DD4D RID: 318797 RVA: 0x00142F18 File Offset: 0x00141118
		static readonly int sud22TA0Cz;

		// Token: 0x0404DD4E RID: 318798 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int VyrWdYy4Cu;

		// Token: 0x0404DD4F RID: 318799 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 6dBIgvzzai;

		// Token: 0x0404DD50 RID: 318800 RVA: 0x00142F20 File Offset: 0x00141120
		static readonly int pFzOcIj71e;

		// Token: 0x0404DD51 RID: 318801 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xUgETm6x3J;

		// Token: 0x0404DD52 RID: 318802 RVA: 0x00142F28 File Offset: 0x00141128
		static readonly int qmA0FOtVVG;

		// Token: 0x0404DD53 RID: 318803 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int eLZdKP8c4U;

		// Token: 0x0404DD54 RID: 318804 RVA: 0x00142F30 File Offset: 0x00141130
		static readonly int y1Ch7m76y3;

		// Token: 0x0404DD55 RID: 318805 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int zB6R1DF8JN;

		// Token: 0x0404DD56 RID: 318806 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YOlvAm4C4E;

		// Token: 0x0404DD57 RID: 318807 RVA: 0x00142F38 File Offset: 0x00141138
		static readonly int od3iUyjc3c;

		// Token: 0x0404DD58 RID: 318808 RVA: 0x00142F40 File Offset: 0x00141140
		static readonly int QwgbRcPIlG;

		// Token: 0x0404DD59 RID: 318809 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int K9Tq6kQQhU;

		// Token: 0x0404DD5A RID: 318810 RVA: 0x00142F48 File Offset: 0x00141148
		static readonly int r5CuPVIX6D;

		// Token: 0x0404DD5B RID: 318811 RVA: 0x00142F20 File Offset: 0x00141120
		static readonly int dmFq7mrJeh;

		// Token: 0x0404DD5C RID: 318812 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Wwax4oKMmu;

		// Token: 0x0404DD5D RID: 318813 RVA: 0x00142F50 File Offset: 0x00141150
		static readonly int iS5iuVuwM6;

		// Token: 0x0404DD5E RID: 318814 RVA: 0x00142F58 File Offset: 0x00141158
		static readonly int T1Linh4nsU;

		// Token: 0x0404DD5F RID: 318815 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 2Gw975ePzl;

		// Token: 0x0404DD60 RID: 318816 RVA: 0x00142F48 File Offset: 0x00141148
		static readonly int L6uMeKrg5m;

		// Token: 0x0404DD61 RID: 318817 RVA: 0x00142F60 File Offset: 0x00141160
		static readonly int 157iOfk2JW;

		// Token: 0x0404DD62 RID: 318818 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int thdS2bg5kz;

		// Token: 0x0404DD63 RID: 318819 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 0f7kuXH9Dd;

		// Token: 0x0404DD64 RID: 318820 RVA: 0x00142F68 File Offset: 0x00141168
		static readonly int 0YrGc6IOvc;

		// Token: 0x0404DD65 RID: 318821 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int VmFc1ocbTD;

		// Token: 0x0404DD66 RID: 318822 RVA: 0x00142F70 File Offset: 0x00141170
		static readonly int ov5GvW8Wx0;

		// Token: 0x0404DD67 RID: 318823 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int XkyqgVzX05;

		// Token: 0x0404DD68 RID: 318824 RVA: 0x00142F78 File Offset: 0x00141178
		static readonly int TRJIdOZetG;

		// Token: 0x0404DD69 RID: 318825 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 5pqAzEdlVF;

		// Token: 0x0404DD6A RID: 318826 RVA: 0x00142F80 File Offset: 0x00141180
		static readonly int 8vb5EvxY5g;

		// Token: 0x0404DD6B RID: 318827 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int yFlYuWlxmh;

		// Token: 0x0404DD6C RID: 318828 RVA: 0x00142F88 File Offset: 0x00141188
		static readonly int 6dnq4s4y1c;

		// Token: 0x0404DD6D RID: 318829 RVA: 0x00142F90 File Offset: 0x00141190
		static readonly int 1NCu6hzODs;

		// Token: 0x0404DD6E RID: 318830 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int aBiNS0DRQc;

		// Token: 0x0404DD6F RID: 318831 RVA: 0x00142F98 File Offset: 0x00141198
		static readonly int cq9xJeIvAW;

		// Token: 0x0404DD70 RID: 318832 RVA: 0x00142F68 File Offset: 0x00141168
		static readonly int 19hdolD1bM;

		// Token: 0x0404DD71 RID: 318833 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int hXu4G55aXE;

		// Token: 0x0404DD72 RID: 318834 RVA: 0x00142F78 File Offset: 0x00141178
		static readonly int omhZ9LOOlb;

		// Token: 0x0404DD73 RID: 318835 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YDOq0bdFiq;

		// Token: 0x0404DD74 RID: 318836 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int xMzD4F6ErN;

		// Token: 0x0404DD75 RID: 318837 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jsX6rObIdc;

		// Token: 0x0404DD76 RID: 318838 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int WyP9xdJDDp;

		// Token: 0x0404DD77 RID: 318839 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int c01rRcwee4;

		// Token: 0x0404DD78 RID: 318840 RVA: 0x00142FA0 File Offset: 0x001411A0
		static readonly int PJgX2qqR9m;

		// Token: 0x0404DD79 RID: 318841 RVA: 0x00142FA8 File Offset: 0x001411A8
		static readonly int 9VlGT860Pb;

		// Token: 0x0404DD7A RID: 318842 RVA: 0x00142FB0 File Offset: 0x001411B0
		static readonly int 62BCvt0qpO;

		// Token: 0x0404DD7B RID: 318843 RVA: 0x00142FB8 File Offset: 0x001411B8
		static readonly int c7njMNR1HH;

		// Token: 0x0404DD7C RID: 318844 RVA: 0x00142FC0 File Offset: 0x001411C0
		static readonly int x1DbpGOuXS;

		// Token: 0x0404DD7D RID: 318845 RVA: 0x00142FC8 File Offset: 0x001411C8
		static readonly int f6OC8XIemI;

		// Token: 0x0404DD7E RID: 318846 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int z9muJCrC4G;

		// Token: 0x0404DD7F RID: 318847 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int qEsIoFzjWo;

		// Token: 0x0404DD80 RID: 318848 RVA: 0x00142FD0 File Offset: 0x001411D0
		static readonly int eGTWtgtklz;

		// Token: 0x0404DD81 RID: 318849 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ExP8RxOTSn;

		// Token: 0x0404DD82 RID: 318850 RVA: 0x00142FD8 File Offset: 0x001411D8
		static readonly int YL0QmaNGY3;

		// Token: 0x0404DD83 RID: 318851 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ijH7otqQAn;

		// Token: 0x0404DD84 RID: 318852 RVA: 0x00142FE0 File Offset: 0x001411E0
		static readonly int TGbEB3zu00;

		// Token: 0x0404DD85 RID: 318853 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 0fRtPTPCuT;

		// Token: 0x0404DD86 RID: 318854 RVA: 0x00142FE8 File Offset: 0x001411E8
		static readonly int SnMrRfpSUh;

		// Token: 0x0404DD87 RID: 318855 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int H8SoURuvOs;

		// Token: 0x0404DD88 RID: 318856 RVA: 0x00142FF0 File Offset: 0x001411F0
		static readonly int ldPhCCRXrU;

		// Token: 0x0404DD89 RID: 318857 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int engrUq4txg;

		// Token: 0x0404DD8A RID: 318858 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NhZSt2NmZ8;

		// Token: 0x0404DD8B RID: 318859 RVA: 0x00142FF8 File Offset: 0x001411F8
		static readonly int idxBszXopP;

		// Token: 0x0404DD8C RID: 318860 RVA: 0x00142FD0 File Offset: 0x001411D0
		static readonly int NRk9DdckUn;

		// Token: 0x0404DD8D RID: 318861 RVA: 0x00142FD8 File Offset: 0x001411D8
		static readonly int XA8sfDD6xK;

		// Token: 0x0404DD8E RID: 318862 RVA: 0x00142FE0 File Offset: 0x001411E0
		static readonly int yo8twA0f9f;

		// Token: 0x0404DD8F RID: 318863 RVA: 0x00142FE8 File Offset: 0x001411E8
		static readonly int SPEiS66aPQ;

		// Token: 0x0404DD90 RID: 318864 RVA: 0x00142FF0 File Offset: 0x001411F0
		static readonly int anSvkifEfo;

		// Token: 0x0404DD91 RID: 318865 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int vb1eajT1ND;

		// Token: 0x0404DD92 RID: 318866 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int m6kyVH6Zai;

		// Token: 0x0404DD93 RID: 318867 RVA: 0x00143000 File Offset: 0x00141200
		static readonly int HnrguLWMIN;

		// Token: 0x0404DD94 RID: 318868 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int ev9Vu1YjIt;

		// Token: 0x0404DD95 RID: 318869 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int mFMLndCdad;

		// Token: 0x0404DD96 RID: 318870 RVA: 0x00143008 File Offset: 0x00141208
		static readonly int lFo6hHtUuO;

		// Token: 0x0404DD97 RID: 318871 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int MGs9j17OEe;

		// Token: 0x0404DD98 RID: 318872 RVA: 0x00143010 File Offset: 0x00141210
		static readonly int sXRq6Bbf2R;

		// Token: 0x0404DD99 RID: 318873 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int J2womYGCyn;

		// Token: 0x0404DD9A RID: 318874 RVA: 0x00143018 File Offset: 0x00141218
		static readonly int HEy3gfWNmw;

		// Token: 0x0404DD9B RID: 318875 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int fxZ5uOy7Af;

		// Token: 0x0404DD9C RID: 318876 RVA: 0x00143020 File Offset: 0x00141220
		static readonly int qObdFUUEXK;

		// Token: 0x0404DD9D RID: 318877 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int u5aaXoiXKa;

		// Token: 0x0404DD9E RID: 318878 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int pN3GwVc03X;

		// Token: 0x0404DD9F RID: 318879 RVA: 0x00143028 File Offset: 0x00141228
		static readonly int kIBT63mVyM;

		// Token: 0x0404DDA0 RID: 318880 RVA: 0x00143008 File Offset: 0x00141208
		static readonly int LS0cCjX8iG;

		// Token: 0x0404DDA1 RID: 318881 RVA: 0x00143010 File Offset: 0x00141210
		static readonly int paxk0cUVru;

		// Token: 0x0404DDA2 RID: 318882 RVA: 0x00143018 File Offset: 0x00141218
		static readonly int 1eK9kl4Hee;

		// Token: 0x0404DDA3 RID: 318883 RVA: 0x00143020 File Offset: 0x00141220
		static readonly int BNj8PXXbEM;

		// Token: 0x0404DDA4 RID: 318884 RVA: 0x00143028 File Offset: 0x00141228
		static readonly int 8dSxsJVade;

		// Token: 0x0404DDA5 RID: 318885 RVA: 0x00143030 File Offset: 0x00141230
		static readonly int iRoEUrH01a;

		// Token: 0x0404DDA6 RID: 318886 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int oQeEFc1zVc;

		// Token: 0x0404DDA7 RID: 318887 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int F3RewYLXRa;

		// Token: 0x0404DDA8 RID: 318888 RVA: 0x00143038 File Offset: 0x00141238
		static readonly int QdoA5tifoi;

		// Token: 0x0404DDA9 RID: 318889 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Pgjnhr8NrP;

		// Token: 0x0404DDAA RID: 318890 RVA: 0x00143040 File Offset: 0x00141240
		static readonly int SfFAZpAJS5;

		// Token: 0x0404DDAB RID: 318891 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int fujbJLleIV;

		// Token: 0x0404DDAC RID: 318892 RVA: 0x00143048 File Offset: 0x00141248
		static readonly int 3WLxNiTn6E;

		// Token: 0x0404DDAD RID: 318893 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Z7pBIvYokQ;

		// Token: 0x0404DDAE RID: 318894 RVA: 0x00143040 File Offset: 0x00141240
		static readonly int sZMsCe6IeW;

		// Token: 0x0404DDAF RID: 318895 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int GeFVV5USw0;

		// Token: 0x0404DDB0 RID: 318896 RVA: 0x00143050 File Offset: 0x00141250
		static readonly int VXMOghFhSX;

		// Token: 0x0404DDB1 RID: 318897 RVA: 0x00143058 File Offset: 0x00141258
		static readonly int x732neJcut;

		// Token: 0x0404DDB2 RID: 318898 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int lLIk842TqM;

		// Token: 0x0404DDB3 RID: 318899 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int aF1u4VM8Lf;

		// Token: 0x0404DDB4 RID: 318900 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ZZzGjIkMs1;

		// Token: 0x0404DDB5 RID: 318901 RVA: 0x00143060 File Offset: 0x00141260
		static readonly int w1iCPJPmQl;

		// Token: 0x0404DDB6 RID: 318902 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ov1G7rGJ8S;

		// Token: 0x0404DDB7 RID: 318903 RVA: 0x00143068 File Offset: 0x00141268
		static readonly int RKQOUMWBAz;

		// Token: 0x0404DDB8 RID: 318904 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int UqkzZihyeu;

		// Token: 0x0404DDB9 RID: 318905 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Fksk0nhtJ1;

		// Token: 0x0404DDBA RID: 318906 RVA: 0x00143070 File Offset: 0x00141270
		static readonly int CaNajmkTsD;

		// Token: 0x0404DDBB RID: 318907 RVA: 0x00143060 File Offset: 0x00141260
		static readonly int xNlaR7KCqY;

		// Token: 0x0404DDBC RID: 318908 RVA: 0x00143068 File Offset: 0x00141268
		static readonly int KRoNMrbqYq;

		// Token: 0x0404DDBD RID: 318909 RVA: 0x00143070 File Offset: 0x00141270
		static readonly int om2Ix3cJPx;

		// Token: 0x0404DDBE RID: 318910 RVA: 0x00143078 File Offset: 0x00141278
		static readonly int 8NGb718ST2;
	}
}
