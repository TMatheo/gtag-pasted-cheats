﻿using System;
using HarmonyLib;

namespace CanvasGUI
{
	// Token: 0x02000031 RID: 49
	[HarmonyPatch(typeof(GorillaNot), "DispatchReport")]
	public class NoDispatchReport
	{
		// Token: 0x060001D9 RID: 473 RVA: 0x00645760 File Offset: 0x00643960
		private unsafe static bool Prefix()
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			if ((*(&NoDispatchReport.x9c0pqhMpr) ^ *(&NoDispatchReport.x9c0pqhMpr)) != 0)
			{
				goto IL_24;
			}
			goto IL_A8C;
			uint num2;
			bool result;
			for (;;)
			{
				IL_29:
				uint num;
				switch ((num = (num2 ^ (uint)(*(&NoDispatchReport.woo8Uuj889)))) % (uint)(*(&NoDispatchReport.v6PTG1Y8Kk) + *(&NoDispatchReport.cUFiCZQ4Fe)))
				{
				case 0U:
				{
					int[] array2;
					int[] array = array2;
					int num3 = 0;
					int num4 = array2[0] % 97;
					int num5 = ((217 == 0) ? (num4 - 18) : (num4 + 217)) - 265;
					int num6 = (-111 == 0) ? (num5 - 89) : (num5 + -111);
					array[num3] = (array2[0] ^ num6 ^ (2096771027 ^ num6));
					num2 = 2946818742U;
					continue;
				}
				case 1U:
				{
					int[] array3;
					int num8;
					int num7 = array3[num8 + 6 - num7] + -7;
					num8 -= 537;
					uint[] array4 = new uint[*(&NoDispatchReport.VzJbidvz01)];
					array4[*(&NoDispatchReport.n3rok2poBH)] = (uint)(*(&NoDispatchReport.c8OwivSpty));
					array4[*(&NoDispatchReport.TiySJZ1yy1)] = (uint)(*(&NoDispatchReport.tWLLNttJj7) + *(&NoDispatchReport.1HT5XWkX2w));
					array4[*(&NoDispatchReport.LGGBiFFYfL) + *(&NoDispatchReport.B00KYFxDiz)] = (uint)(*(&NoDispatchReport.CIGv6LP35x));
					array4[*(&NoDispatchReport.ze5BpnQJmI) + *(&NoDispatchReport.nUoY6ARJgS)] = (uint)(*(&NoDispatchReport.jgyDuD9UEW) + *(&NoDispatchReport.zMdrVh5yev));
					uint num9 = num - (uint)(*(&NoDispatchReport.ynaaLserz5));
					uint num10 = num9 - (uint)(*(&NoDispatchReport.4GWmOSp1Rm));
					uint num11 = num10 * array4[*(&NoDispatchReport.n6EPTb16CZ)];
					num2 = ((num11 & (uint)(*(&NoDispatchReport.Fcove5GY2C))) ^ (uint)(*(&NoDispatchReport.iReJcs00dD)));
					continue;
				}
				case 2U:
				{
					int num12 = (int)((short)num12);
					uint[] array5 = new uint[*(&NoDispatchReport.WOLAC7WkCg)];
					array5[*(&NoDispatchReport.QWwuGjzvkH)] = (uint)(*(&NoDispatchReport.JS1zPxS0Ch));
					array5[*(&NoDispatchReport.SurapH1dKs)] = (uint)(*(&NoDispatchReport.TPb7HzVW9z));
					array5[*(&NoDispatchReport.DjECMDWVuO)] = (uint)(*(&NoDispatchReport.pgheOgpVE8));
					uint num13 = num & (uint)(*(&NoDispatchReport.rWl2y313sa)) & (uint)(*(&NoDispatchReport.b61NdtqoOm));
					num2 = (num13 ^ array5[*(&NoDispatchReport.vgs5Dwr7tk)] ^ (uint)(*(&NoDispatchReport.JARAHr8LOS)));
					continue;
				}
				case 3U:
				{
					int num12;
					num12 |= 2062376120;
					uint[] array6 = new uint[*(&NoDispatchReport.vKbl7vBXmn) + *(&NoDispatchReport.LqTp4ErIZz)];
					array6[*(&NoDispatchReport.5U8TCPVfjw)] = (uint)(*(&NoDispatchReport.V4b9Cd981H));
					array6[*(&NoDispatchReport.fdRdx6JN9Y)] = (uint)(*(&NoDispatchReport.V60iQaLHjs));
					array6[*(&NoDispatchReport.ZfyzSQPTma)] = (uint)(*(&NoDispatchReport.FtRRTbDffF) + *(&NoDispatchReport.FHfKbZE2tm));
					array6[*(&NoDispatchReport.S1ZJr9pcLh)] = (uint)(*(&NoDispatchReport.r0kiTmoiOy) + *(&NoDispatchReport.XqmdmR9oY3));
					uint num14 = num + (uint)(*(&NoDispatchReport.LWkAHNUHjU));
					num2 = (((num14 - (uint)(*(&NoDispatchReport.wkT7YPh70y))) * (uint)(*(&NoDispatchReport.ugn4OmP5ga)) & (uint)(*(&NoDispatchReport.9BDSVUPkaG) + *(&NoDispatchReport.Sh84CwWpEX))) ^ (uint)(*(&NoDispatchReport.uCxjJpspvf)));
					continue;
				}
				case 4U:
				{
					uint[] array7 = new uint[*(&NoDispatchReport.Prku3mNoKe)];
					array7[*(&NoDispatchReport.pmaIdw3kSW)] = (uint)(*(&NoDispatchReport.qX0oIpQ78U));
					array7[*(&NoDispatchReport.bWS3XZEYWT)] = (uint)(*(&NoDispatchReport.a6RL7n9dST));
					array7[*(&NoDispatchReport.C9ETC216lO)] = (uint)(*(&NoDispatchReport.WPqzCTUguE));
					array7[*(&NoDispatchReport.rfO86tFoqf) + *(&NoDispatchReport.pwooRcS81f)] = (uint)(*(&NoDispatchReport.iIxH6KQbIo));
					num2 = (((num & array7[*(&NoDispatchReport.TdsOmhuFXS)]) + (uint)(*(&NoDispatchReport.wMQFijkChj)) & array7[*(&NoDispatchReport.BVpPfisGBv) + *(&NoDispatchReport.dogCMMDaBu)]) - (uint)(*(&NoDispatchReport.rNkisW2riX)) ^ (uint)(*(&NoDispatchReport.jN3im7xdsD)));
					continue;
				}
				case 5U:
				{
					int num8;
					int num12 = num8;
					num2 = 3301338553U;
					continue;
				}
				case 6U:
				{
					int[] array3;
					int num8;
					int num7;
					array3[num7 + 6 - num8] = (num8 | 7);
					uint[] array8 = new uint[*(&NoDispatchReport.0FSd61y6zv)];
					array8[*(&NoDispatchReport.Fpq53fmVvM)] = (uint)(*(&NoDispatchReport.nwXg9Qsv1m));
					array8[*(&NoDispatchReport.1BbeMBsuA7)] = (uint)(*(&NoDispatchReport.FpZu6wMBer));
					array8[*(&NoDispatchReport.D2JSvEsvdp)] = (uint)(*(&NoDispatchReport.ICEM4ENLt1));
					array8[*(&NoDispatchReport.x1UyH8WnkM)] = (uint)(*(&NoDispatchReport.ErRJj91ItI));
					uint num15 = (num - (uint)(*(&NoDispatchReport.T6QUyCkN02))) * (uint)(*(&NoDispatchReport.iASm4LhVLx));
					num2 = (num15 * array8[*(&NoDispatchReport.rELRlbv5n4)] - (uint)(*(&NoDispatchReport.MFbki0kA9F)) ^ (uint)(*(&NoDispatchReport.XJxsoDYoOX)));
					continue;
				}
				case 7U:
					num2 = 2948688522U;
					continue;
				case 8U:
				{
					int num8;
					int num12;
					int num7 = num12 * num8;
					num7 = num8 >> 5;
					num12 = ~num7;
					uint num16 = num * (uint)(*(&NoDispatchReport.iNUCqF4GZ2));
					uint num17 = num16 * (uint)(*(&NoDispatchReport.9RrT8hQ57O)) | (uint)(*(&NoDispatchReport.PSu06WrsWA));
					num2 = (num17 + (uint)(*(&NoDispatchReport.Q1gJmwSCFl)) ^ (uint)(*(&NoDispatchReport.6oFKQrxU4N)));
					continue;
				}
				case 9U:
				{
					int num12;
					int num8 = num12 & 388771401;
					num12 = 813567743;
					uint[] array9 = new uint[*(&NoDispatchReport.7XSvQSJsfY)];
					array9[*(&NoDispatchReport.irv0nvt2SQ)] = (uint)(*(&NoDispatchReport.TZI7xNvDdR));
					array9[*(&NoDispatchReport.OWU4849xOl)] = (uint)(*(&NoDispatchReport.pOZ8j1ENh8));
					array9[*(&NoDispatchReport.tO5jyhPU7C)] = (uint)(*(&NoDispatchReport.hGPOJLW11t));
					array9[*(&NoDispatchReport.v6oqlFAJY6)] = (uint)(*(&NoDispatchReport.Jifeh9bvFb));
					array9[*(&NoDispatchReport.oozLEj9LyY)] = (uint)(*(&NoDispatchReport.eMVyNxkO8t) + *(&NoDispatchReport.gF6B38kuqK));
					uint num18 = num - array9[*(&NoDispatchReport.tlwaEGGcmC)];
					uint num19 = num18 - array9[*(&NoDispatchReport.FzVAc6MrRt)];
					uint num20 = num19 | array9[*(&NoDispatchReport.YMwW4jsySF)];
					uint num21 = num20 * (uint)(*(&NoDispatchReport.8Peoo2a4tG));
					num2 = ((num21 & (uint)(*(&NoDispatchReport.qIm6oru6j6))) ^ (uint)(*(&NoDispatchReport.v2c6vgyafe)));
					continue;
				}
				case 10U:
				{
					int num7;
					int num8 = -num7;
					uint num22 = num - (uint)(*(&NoDispatchReport.On91fTTOOi));
					num2 = (((num22 & (uint)(*(&NoDispatchReport.E0WVaSKuL3) + *(&NoDispatchReport.ImsyADF4ZN))) - (uint)(*(&NoDispatchReport.5Kz7TbvHvT)) | (uint)(*(&NoDispatchReport.NuT7vifcS0))) - (uint)(*(&NoDispatchReport.wcLOul5K0b)) ^ (uint)(*(&NoDispatchReport.OZyBm4AZB9) + *(&NoDispatchReport.hC81pXSuDb)));
					continue;
				}
				case 11U:
				{
					int num12 = -num12;
					uint num23 = num | (uint)(*(&NoDispatchReport.34CXmoARoL));
					uint num24 = num23 - (uint)(*(&NoDispatchReport.MGzjVF30Ie));
					num2 = ((num24 & (uint)(*(&NoDispatchReport.OBPXVfMBC1))) ^ (uint)(*(&NoDispatchReport.mayKzhwUCz)));
					continue;
				}
				case 12U:
				{
					int num8;
					int num7 = num8 / 464;
					num2 = (((num8 > num8) ? 2968823405U : 2488595712U) ^ num * 3731715720U);
					continue;
				}
				case 13U:
				{
					int num12;
					int num8 = num12 ^ num8;
					num12 = num8 % 457;
					uint num25 = num | (uint)(*(&NoDispatchReport.OwKWUFoDGT));
					uint num26 = num25 - (uint)(*(&NoDispatchReport.eywDP9rZLw));
					uint num27 = (num26 + (uint)(*(&NoDispatchReport.FcpoqgUeHP)) ^ (uint)(*(&NoDispatchReport.Y2WDoyBb4H))) - (uint)(*(&NoDispatchReport.v6sGZlCxHx));
					num2 = (num27 - (uint)(*(&NoDispatchReport.zuNOUvGfqx)) ^ (uint)(*(&NoDispatchReport.uJ505mcsYb) + *(&NoDispatchReport.8PeDBJtiOE)));
					continue;
				}
				case 14U:
				{
					int num7;
					int num12 = num7 << 1;
					num2 = 2782080820U;
					continue;
				}
				case 15U:
				{
					int[] array3 = new int[10];
					int num12;
					num2 = (((num12 <= num12) ? 4064807717U : 2649882627U) ^ num * 943067366U);
					continue;
				}
				case 16U:
				{
					int num7;
					num7 <<= 3;
					int[] array3;
					int num8;
					int num12;
					num7 = array3[num12 + 6 - num8] + 2;
					uint[] array10 = new uint[*(&NoDispatchReport.j0tvVB7gJ3)];
					array10[*(&NoDispatchReport.F4WE7cd1XY)] = (uint)(*(&NoDispatchReport.kmGRBCOnCo));
					array10[*(&NoDispatchReport.6lpbchpebM)] = (uint)(*(&NoDispatchReport.jP1nB2NVVY));
					array10[*(&NoDispatchReport.J7W1x7ubtT)] = (uint)(*(&NoDispatchReport.wUde7dO5lZ));
					array10[*(&NoDispatchReport.w8ZLzVvcQI)] = (uint)(*(&NoDispatchReport.z3Soe8Oxnf));
					uint num28 = num - array10[*(&NoDispatchReport.wOuIZPvWqh)];
					uint num29 = (num28 ^ array10[*(&NoDispatchReport.nRt5lKhKCc)]) * (uint)(*(&NoDispatchReport.MSKld3Bz98));
					num2 = ((num29 & (uint)(*(&NoDispatchReport.PbRGniORwk))) ^ (uint)(*(&NoDispatchReport.jYwsehKWCU)));
					continue;
				}
				case 17U:
				{
					int num7;
					int num12;
					int[] array11;
					array11[num7 + 7 - num12] = num7 - 5;
					uint num30 = ((num & (uint)(*(&NoDispatchReport.MdnUxspUAe))) + (uint)(*(&NoDispatchReport.0BHcNLoqyB))) * (uint)(*(&NoDispatchReport.M4JHQbo0Gw));
					num2 = (((num30 | (uint)(*(&NoDispatchReport.uea6aR3XHU))) & (uint)(*(&NoDispatchReport.HX6PuI2yw5) + *(&NoDispatchReport.CSWMFRUfEW)) & (uint)(*(&NoDispatchReport.EyNNtWkLC6) + *(&NoDispatchReport.SRie4z74XH))) ^ (uint)(*(&NoDispatchReport.i0DKtcHN0I)));
					continue;
				}
				case 18U:
				{
					int num12;
					int num7 = num12 ^ 910272627;
					uint[] array12 = new uint[*(&NoDispatchReport.inmjbc8kNs)];
					array12[*(&NoDispatchReport.fkQTFy5SU1)] = (uint)(*(&NoDispatchReport.iFaTSteUiW));
					array12[*(&NoDispatchReport.SKHZ3kxPkJ)] = (uint)(*(&NoDispatchReport.5ZMTd7wov1));
					array12[*(&NoDispatchReport.bAaM2cMSRr) + *(&NoDispatchReport.8nC0ZUc0af)] = (uint)(*(&NoDispatchReport.BqrL5J2HzV) + *(&NoDispatchReport.7zjr4Ru5ga));
					array12[*(&NoDispatchReport.Ye83LRXV4J) + *(&NoDispatchReport.e5OQ0vTPQt)] = (uint)(*(&NoDispatchReport.kEd5uJEU6H));
					array12[*(&NoDispatchReport.khUAGhsy9n)] = (uint)(*(&NoDispatchReport.vhNp1ClT1J));
					uint num31 = ((num ^ array12[*(&NoDispatchReport.8fox0TACIC)]) + (uint)(*(&NoDispatchReport.NCZwi6kNJS) + *(&NoDispatchReport.CfPm7C1xEs)) + array12[*(&NoDispatchReport.iudxJF2gKx) + *(&NoDispatchReport.gpp7atHaG4)]) * array12[*(&NoDispatchReport.bXKiGcPCzx) + *(&NoDispatchReport.bM8adcjmnd)];
					num2 = (num31 + (uint)(*(&NoDispatchReport.DEDWwX0RMO)) ^ (uint)(*(&NoDispatchReport.5bqJQKk4rq)));
					continue;
				}
				case 19U:
				{
					int num7;
					*(ref NoDispatchReport.IXWAZobc6A + (IntPtr)num7) = num7;
					int num12;
					num12 |= 1192814583;
					num2 = ((((num & (uint)(*(&NoDispatchReport.N6xYrmxM3f))) ^ (uint)(*(&NoDispatchReport.CIByZHLNoZ))) | (uint)(*(&NoDispatchReport.63niJIh7zi))) - (uint)(*(&NoDispatchReport.Eu8Rng9if0)) ^ (uint)(*(&NoDispatchReport.Y2xsI6NXH2)));
					continue;
				}
				case 21U:
				{
					int num8;
					int num12 = num8;
					int num7;
					num7 &= num12;
					uint[] array13 = new uint[*(&NoDispatchReport.T5hGp4Li6I)];
					array13[*(&NoDispatchReport.pv5D3MJd4s)] = (uint)(*(&NoDispatchReport.1VbdtFlV4B) + *(&NoDispatchReport.bbNXouvYJ7));
					array13[*(&NoDispatchReport.Kpjw2i1nny)] = (uint)(*(&NoDispatchReport.VgJzu7dEXj));
					array13[*(&NoDispatchReport.Szo4qNhhYI) + *(&NoDispatchReport.avU7hLvplK)] = (uint)(*(&NoDispatchReport.N8sFp5SYnq));
					uint num32 = num ^ array13[*(&NoDispatchReport.RrBjpVBpFo)];
					num2 = (((num32 | (uint)(*(&NoDispatchReport.AUOfXkMMRi))) & array13[*(&NoDispatchReport.MycMVTHjOv)]) ^ (uint)(*(&NoDispatchReport.4I3s1suuRM)));
					continue;
				}
				case 22U:
				{
					int num7;
					int num8 = num7 - 513;
					int num12 = NoDispatchReport.IXWAZobc6A;
					uint[] array14 = new uint[*(&NoDispatchReport.ehWUanoIs3) + *(&NoDispatchReport.rfvHWlA2Lx)];
					array14[*(&NoDispatchReport.JTYqyjQJML)] = (uint)(*(&NoDispatchReport.CiRmSMxlaR));
					array14[*(&NoDispatchReport.7UAfuceWrZ)] = (uint)(*(&NoDispatchReport.I1Xb4LJpf0));
					array14[*(&NoDispatchReport.Xf5g0JNIyJ)] = (uint)(*(&NoDispatchReport.yZb3zzS36V));
					array14[*(&NoDispatchReport.F3cxDKK0rH) + *(&NoDispatchReport.DHFk4cYdol)] = (uint)(*(&NoDispatchReport.OVihksZdlF));
					uint num33 = num + (uint)(*(&NoDispatchReport.2QtJueCHdq) + *(&NoDispatchReport.8XbrGrU19W));
					uint num34 = num33 + array14[*(&NoDispatchReport.ayOVHuU4MV)];
					num2 = ((num34 & (uint)(*(&NoDispatchReport.uqOmOxX5za))) + array14[*(&NoDispatchReport.aRA8m141b3)] ^ (uint)(*(&NoDispatchReport.XiePoDBYCA) + *(&NoDispatchReport.JI5H5RJycS)));
					continue;
				}
				case 23U:
				{
					int num8;
					num8 ^= 708377498;
					uint[] array15 = new uint[*(&NoDispatchReport.u9hLvKWQmj)];
					array15[*(&NoDispatchReport.6N4C1TTeqO)] = (uint)(*(&NoDispatchReport.y0NftetCgG) + *(&NoDispatchReport.ecOHctrs74));
					array15[*(&NoDispatchReport.b6gvu0JAoE)] = (uint)(*(&NoDispatchReport.b5hlW3vBbQ) + *(&NoDispatchReport.aTtgFe8xkI));
					array15[*(&NoDispatchReport.lkgvx2Ucv2)] = (uint)(*(&NoDispatchReport.VtXboi5nvi));
					uint num35 = num ^ (uint)(*(&NoDispatchReport.8pQreHM9qQ));
					num2 = ((num35 - (uint)(*(&NoDispatchReport.2VZgc0Yvxd)) | array15[*(&NoDispatchReport.jTQj5r6S2g)]) ^ (uint)(*(&NoDispatchReport.jUCCK5UzRq)));
					continue;
				}
				case 24U:
				{
					int num12 = -num12;
					int num8;
					*(ref num8 + (IntPtr)num12) = num12;
					uint[] array16 = new uint[*(&NoDispatchReport.3EHtRjNiEF)];
					array16[*(&NoDispatchReport.2tnefTNvE7)] = (uint)(*(&NoDispatchReport.zH8MjxfzP7));
					array16[*(&NoDispatchReport.brgwpPY9fp)] = (uint)(*(&NoDispatchReport.kIz9gGAQxB) + *(&NoDispatchReport.i0AnvwF4Ke));
					array16[*(&NoDispatchReport.DYTHoKM1zP)] = (uint)(*(&NoDispatchReport.5OQYWrR9pc));
					array16[*(&NoDispatchReport.xPCNYkq3B2) + *(&NoDispatchReport.KdzAmMzsUV)] = (uint)(*(&NoDispatchReport.4IbhFUkmQD));
					array16[*(&NoDispatchReport.eGPrryVFsD)] = (uint)(*(&NoDispatchReport.eT06FbZPwK));
					array16[*(&NoDispatchReport.2joTioyeIE) + *(&NoDispatchReport.AEn7XDOHTx)] = (uint)(*(&NoDispatchReport.0t9Q1kSeco));
					uint num36 = num + array16[*(&NoDispatchReport.5U0FK5b5JC)];
					uint num37 = num36 + array16[*(&NoDispatchReport.917nDap3iB)];
					uint num38 = num37 - (uint)(*(&NoDispatchReport.MS58UIjYc7));
					num2 = ((num38 + array16[*(&NoDispatchReport.WTBdJpOhwc)]) * (uint)(*(&NoDispatchReport.mT7Qy8wVNb)) - array16[*(&NoDispatchReport.5Y6bbnZ1vC) + *(&NoDispatchReport.VCdMqqzdeX)] ^ (uint)(*(&NoDispatchReport.MHGGY3UoKV)));
					continue;
				}
				case 25U:
				{
					int[] array3;
					int num8;
					int num7;
					array3[num8 + 6 - num8] = num7 - -7;
					uint num39 = num | (uint)(*(&NoDispatchReport.NLdeecP2gF));
					uint num40 = num39 * (uint)(*(&NoDispatchReport.KzrNEsoyHL));
					uint num41 = num40 & (uint)(*(&NoDispatchReport.rKYWH4HtJt) + *(&NoDispatchReport.0VIxIo1ADz));
					uint num42 = num41 | (uint)(*(&NoDispatchReport.06iTvgBDla));
					uint num43 = num42 & (uint)(*(&NoDispatchReport.bQIktCwHXj));
					num2 = ((num43 & (uint)(*(&NoDispatchReport.UgsxPyq3EZ))) ^ (uint)(*(&NoDispatchReport.0nuSVvlFkl)));
					continue;
				}
				case 26U:
				{
					int num8;
					num2 = (((num8 <= num8) ? 3805909136U : 2159900534U) ^ num * 682467686U);
					continue;
				}
				case 27U:
				{
					int num12;
					int num7 = num12 & 2114707635;
					uint[] array17 = new uint[*(&NoDispatchReport.1Dh1H1iKGu)];
					array17[*(&NoDispatchReport.0hpa0cbkIS)] = (uint)(*(&NoDispatchReport.MR9PDVb5xk));
					array17[*(&NoDispatchReport.lAc8hB5xnm)] = (uint)(*(&NoDispatchReport.W5RHLBmDS9));
					array17[*(&NoDispatchReport.RPsL1jERxv)] = (uint)(*(&NoDispatchReport.ZmXgJ0Eq2y));
					array17[*(&NoDispatchReport.go6f5QA1EC)] = (uint)(*(&NoDispatchReport.tXnxTWRRH7));
					uint num44 = num * array17[*(&NoDispatchReport.7n92Mtiu8U)];
					uint num45 = num44 - array17[*(&NoDispatchReport.65LecmSNPk)];
					num2 = ((num45 & array17[*(&NoDispatchReport.jMNvCB9jNx) + *(&NoDispatchReport.jwj413pESM)]) ^ array17[*(&NoDispatchReport.sP3tFxMJVr)] ^ (uint)(*(&NoDispatchReport.DECgYvZNzL)));
					continue;
				}
				case 28U:
				{
					int num7;
					int num12;
					num7 ^= num12;
					int num8 = num12;
					int[] array3;
					array3[num12 + 9 - num12] = (num8 | 2);
					uint num46 = num * (uint)(*(&NoDispatchReport.bDuLSeEIpg));
					uint num47 = num46 & (uint)(*(&NoDispatchReport.N6XrSMAmSD));
					uint num48 = (num47 ^ (uint)(*(&NoDispatchReport.5QYb2xgbG5))) * (uint)(*(&NoDispatchReport.toxphLqGyI));
					num2 = (num48 - (uint)(*(&NoDispatchReport.dGlQXnAEaS) + *(&NoDispatchReport.hhE9YKpTSe)) - (uint)(*(&NoDispatchReport.8mCtwiJrKG)) ^ (uint)(*(&NoDispatchReport.f3yJjzoIEP) + *(&NoDispatchReport.wcBxYLkxRW)));
					continue;
				}
				case 29U:
				{
					int num12;
					NoDispatchReport.IXWAZobc6A = num12;
					num2 = (((num12 <= num12) ? 1120901404U : 1449452546U) ^ num * 1349121746U);
					continue;
				}
				case 30U:
				{
					int num49;
					num2 = (((num49 == 416) ? 2940023642U : 4275028638U) ^ num * 3987726709U);
					continue;
				}
				case 31U:
					goto IL_24;
				case 32U:
				{
					int num7;
					int num12 = ~num7;
					uint[] array18 = new uint[*(&NoDispatchReport.W0b4OlPVOR)];
					array18[*(&NoDispatchReport.Tqu8EwdHqE)] = (uint)(*(&NoDispatchReport.ZjnmdSKayU));
					array18[*(&NoDispatchReport.9wOlV1jaG4)] = (uint)(*(&NoDispatchReport.Dg6rQCidXb) + *(&NoDispatchReport.sbdBuxNzb5));
					array18[*(&NoDispatchReport.ayh4RhcJmN) + *(&NoDispatchReport.NDAwB3n6Wa)] = (uint)(*(&NoDispatchReport.urCWliSN1i));
					array18[*(&NoDispatchReport.ot8KdO9BZt)] = (uint)(*(&NoDispatchReport.kY1KOpbr91));
					uint num50 = num & array18[*(&NoDispatchReport.JRdALtwKTt)];
					uint num51 = num50 + (uint)(*(&NoDispatchReport.PORDidEzTx));
					num2 = (num51 - (uint)(*(&NoDispatchReport.3lgm0Vz1I6)) + array18[*(&NoDispatchReport.GkNAZXQ89t) + *(&NoDispatchReport.byspeVGymv)] ^ (uint)(*(&NoDispatchReport.klYM7hu0Jz)));
					continue;
				}
				case 33U:
				{
					int num8;
					num8 >>= 2;
					uint[] array19 = new uint[*(&NoDispatchReport.z0rXVUrOd7)];
					array19[*(&NoDispatchReport.Jfwn1XTyws)] = (uint)(*(&NoDispatchReport.m8zk19fzKT));
					array19[*(&NoDispatchReport.2p57nMWqAb)] = (uint)(*(&NoDispatchReport.qlxOFapDS3));
					array19[*(&NoDispatchReport.1wI8D1AGfW)] = (uint)(*(&NoDispatchReport.y1EKEekz9o));
					array19[*(&NoDispatchReport.AnxUCAKlfb)] = (uint)(*(&NoDispatchReport.UcgQcGg63w) + *(&NoDispatchReport.MPLomyhmJl));
					array19[*(&NoDispatchReport.z0Do2N8x5C) + *(&NoDispatchReport.qZlDBWVxs8)] = (uint)(*(&NoDispatchReport.7n5NbvcJsO));
					uint num52 = num | (uint)(*(&NoDispatchReport.dhb3leY2XO));
					uint num53 = num52 * (uint)(*(&NoDispatchReport.HtA0FwnHmP));
					uint num54 = num53 - (uint)(*(&NoDispatchReport.dt4KoM40MH)) + (uint)(*(&NoDispatchReport.vyFrjJ7sbh));
					num2 = (num54 * (uint)(*(&NoDispatchReport.8cae1NmFIp) + *(&NoDispatchReport.HUhcvunQPZ)) ^ (uint)(*(&NoDispatchReport.khqQcSoTR6)));
					continue;
				}
				case 34U:
				{
					int num12;
					num12 <<= 7;
					uint num55 = num + (uint)(*(&NoDispatchReport.PWDBXxfCD6));
					uint num56 = num55 + (uint)(*(&NoDispatchReport.I9xTPYibdX) + *(&NoDispatchReport.hD15bZIlmm)) ^ (uint)(*(&NoDispatchReport.QrJkN3gzv2));
					uint num57 = num56 ^ (uint)(*(&NoDispatchReport.bLaNhnwept));
					num2 = (num57 - (uint)(*(&NoDispatchReport.VeVMuLeHj8)) ^ (uint)(*(&NoDispatchReport.o4Zapa0MFW)));
					continue;
				}
				case 35U:
				{
					int num8;
					int[] array11;
					int num12 = array11[num8 + 5 - num8] + -5;
					int num7 = num12 & num8;
					num7 *= 55;
					uint num58 = num | (uint)(*(&NoDispatchReport.8YkJUuhAlD));
					num2 = ((num58 & (uint)(*(&NoDispatchReport.96gugMht2c))) - (uint)(*(&NoDispatchReport.Pj0Jp7NeJp)) ^ (uint)(*(&NoDispatchReport.mky5H36zkR)));
					continue;
				}
				case 36U:
				{
					int[] array2;
					result = (array2[0] != 0);
					num2 = 3779888340U;
					continue;
				}
				case 37U:
				{
					int num12;
					num2 = (((num12 <= num12) ? 496199970U : 1903790168U) ^ num * 1213745397U);
					continue;
				}
				case 38U:
				{
					int num7;
					int num12;
					int num8 = num7 % num12;
					uint[] array20 = new uint[*(&NoDispatchReport.y5pERASZTa)];
					array20[*(&NoDispatchReport.jzsh9bRn6y)] = (uint)(*(&NoDispatchReport.frcC7bwJCi));
					array20[*(&NoDispatchReport.jTxM0MocLu)] = (uint)(*(&NoDispatchReport.bO6zzuzJQA));
					array20[*(&NoDispatchReport.BAWcaHdnH0)] = (uint)(*(&NoDispatchReport.OIWv0QBgqx));
					uint num59 = num | (uint)(*(&NoDispatchReport.xycMXQumMM));
					uint num60 = num59 - (uint)(*(&NoDispatchReport.ln3Bgi6Uvs));
					num2 = ((num60 | array20[*(&NoDispatchReport.sAVUfS1L9j)]) ^ (uint)(*(&NoDispatchReport.tTccNMiKFJ)));
					continue;
				}
				case 39U:
				{
					int num8;
					int num12;
					int num7 = *(ref num12 + (IntPtr)num8);
					uint num61 = num + (uint)(*(&NoDispatchReport.1spl6VmnYy));
					num2 = ((num61 & (uint)(*(&NoDispatchReport.mn63RvV60B))) * (uint)(*(&NoDispatchReport.YZPxNhvAhG)) ^ (uint)(*(&NoDispatchReport.wjZS1mzuQY)));
					continue;
				}
				case 40U:
					goto IL_A8C;
				case 41U:
				{
					int num12;
					int num7 = *(ref num7 + (IntPtr)num12);
					int num8 = num7 - 889;
					num12 -= 20;
					uint[] array21 = new uint[*(&NoDispatchReport.OIfRsTlfXL)];
					array21[*(&NoDispatchReport.OOJqsYz3Tm)] = (uint)(*(&NoDispatchReport.H3E457uHVr));
					array21[*(&NoDispatchReport.vgpVEdbdPR)] = (uint)(*(&NoDispatchReport.XzR0wvWOCu));
					array21[*(&NoDispatchReport.fq62HVElWv) + *(&NoDispatchReport.jdJqZsjxlO)] = (uint)(*(&NoDispatchReport.6VoBPSmOHJ) + *(&NoDispatchReport.kgEkLFkxOt));
					array21[*(&NoDispatchReport.Z0Gds3pkaE) + *(&NoDispatchReport.MjmyxJB5mz)] = (uint)(*(&NoDispatchReport.szeNKCZjeU));
					array21[*(&NoDispatchReport.Hvi2zGOKSV)] = (uint)(*(&NoDispatchReport.mCxC7B4QxB));
					array21[*(&NoDispatchReport.DpKYBjV3Tp) + *(&NoDispatchReport.eGGG6aAt9q)] = (uint)(*(&NoDispatchReport.51mRNqCcPJ));
					uint num62 = (num & (uint)(*(&NoDispatchReport.IIwcQclK1P))) - (uint)(*(&NoDispatchReport.vV1n1f5qFh) + *(&NoDispatchReport.AKRGGMC3LV)) + array21[*(&NoDispatchReport.h3nJhVUn0e)];
					uint num63 = num62 | array21[*(&NoDispatchReport.y02t5j98Zr)];
					num2 = ((num63 | (uint)(*(&NoDispatchReport.uVWsI71pVE))) * (uint)(*(&NoDispatchReport.Zs8fs1rrGf)) ^ (uint)(*(&NoDispatchReport.KS0lsKRiKh)));
					continue;
				}
				case 42U:
				{
					int num49 = 416;
					uint num64 = num + (uint)(*(&NoDispatchReport.e7sbgYkCvk)) + (uint)(*(&NoDispatchReport.bC0NASzgSY));
					uint num65 = num64 + (uint)(*(&NoDispatchReport.F2uDRBs8mn));
					num2 = (num65 - (uint)(*(&NoDispatchReport.GpIP5nlcpn)) ^ (uint)(*(&NoDispatchReport.PalwF6jWqt)));
					continue;
				}
				case 43U:
				{
					int[] array2 = new int[15];
					uint[] array22 = new uint[*(&NoDispatchReport.TZCi6JyQsP)];
					array22[*(&NoDispatchReport.0ddS7ML98K)] = (uint)(*(&NoDispatchReport.v92yRSV2DU));
					array22[*(&NoDispatchReport.sFYIk8f6Sf)] = (uint)(*(&NoDispatchReport.PvpwKpomKs) + *(&NoDispatchReport.FJ0RhTgNRo));
					array22[*(&NoDispatchReport.x5NXhuEUs8)] = (uint)(*(&NoDispatchReport.qPqc4AUFol));
					uint num66 = num - array22[*(&NoDispatchReport.ntsUOiPHlQ)];
					uint num67 = num66 & (uint)(*(&NoDispatchReport.cSoorUiRPa));
					num2 = (num67 ^ (uint)(*(&NoDispatchReport.lU4MC0cXWh)) ^ (uint)(*(&NoDispatchReport.9ajqBEN2I9)));
					continue;
				}
				case 44U:
				{
					int num8 = NoDispatchReport.IXWAZobc6A;
					uint[] array23 = new uint[*(&NoDispatchReport.udWWYPcdFU) + *(&NoDispatchReport.XLuZmIuiqM)];
					array23[*(&NoDispatchReport.PO0WSkNkjP)] = (uint)(*(&NoDispatchReport.iXyIQweKuX) + *(&NoDispatchReport.Tz7vNv4qiI));
					array23[*(&NoDispatchReport.6Pns8gnAEy)] = (uint)(*(&NoDispatchReport.C230vAWlJz));
					array23[*(&NoDispatchReport.nkxS2aRFIg)] = (uint)(*(&NoDispatchReport.qgCbSStGJt));
					array23[*(&NoDispatchReport.JeF6Va5G9N)] = (uint)(*(&NoDispatchReport.YShseVcUzi));
					array23[*(&NoDispatchReport.Oi2hHfzcid)] = (uint)(*(&NoDispatchReport.RQbZqJf07c));
					array23[*(&NoDispatchReport.eKF5IX9U66)] = (uint)(*(&NoDispatchReport.0YQlflmhzz));
					num2 = (((num - array23[*(&NoDispatchReport.lcig5H1ICV)] - (uint)(*(&NoDispatchReport.0mXXDEc6Yu)) | (uint)(*(&NoDispatchReport.gfglm2904F)) | (uint)(*(&NoDispatchReport.g7BI1Cmj9B) + *(&NoDispatchReport.g0SkFOB3ha))) - (uint)(*(&NoDispatchReport.IpJFSF673D))) * array23[*(&NoDispatchReport.HAO6y3lPgB)] ^ (uint)(*(&NoDispatchReport.b27XNpN5fY)));
					continue;
				}
				case 45U:
				{
					int num8;
					int num7 = num8 * 967;
					int num12;
					int[] array11;
					array11[num7 + 7 - num12] = num7 - 4;
					uint num68 = (num + (uint)(*(&NoDispatchReport.WSB1abXuq3)) & (uint)(*(&NoDispatchReport.4JZHlAl0uO))) ^ (uint)(*(&NoDispatchReport.Xtfz85YOs1));
					num2 = ((num68 | (uint)(*(&NoDispatchReport.dw7McMErNL))) ^ (uint)(*(&NoDispatchReport.FOLhAa0oQb)));
					continue;
				}
				case 46U:
				{
					int num12;
					int num7 = *(ref num7 + (IntPtr)num12);
					uint num69 = (num | (uint)(*(&NoDispatchReport.XR6L0yIdpI))) * (uint)(*(&NoDispatchReport.u7bZsEo1kL) + *(&NoDispatchReport.QcpC6e8w7H)) & (uint)(*(&NoDispatchReport.1oJVAwt5k4));
					uint num70 = num69 - (uint)(*(&NoDispatchReport.DKWZQfQxSd));
					num2 = (num70 + (uint)(*(&NoDispatchReport.nZZRz5l3OW)) - (uint)(*(&NoDispatchReport.0VfiRFyFY6)) ^ (uint)(*(&NoDispatchReport.VsRqIGFQva)));
					continue;
				}
				case 47U:
				{
					int[] array2;
					array2[0] = 2096771027;
					uint num71 = num ^ (uint)(*(&NoDispatchReport.zoDmyIqO3W));
					num2 = ((num71 + (uint)(*(&NoDispatchReport.fKAx1yvGhJ))) * (uint)(*(&NoDispatchReport.qAhoMQu7ZO)) ^ (uint)(*(&NoDispatchReport.Ykr84DJ8uj)));
					continue;
				}
				case 48U:
				{
					int[] array11 = new int[10];
					num2 = ((num * (uint)(*(&NoDispatchReport.6aKFrxPbNM)) & (uint)(*(&NoDispatchReport.9e9agAYu9U)) & (uint)(*(&NoDispatchReport.Vl14kciG55)) & (uint)(*(&NoDispatchReport.dp2eCVwKlT) + *(&NoDispatchReport.m6v8l8UoBB))) ^ (uint)(*(&NoDispatchReport.Ag4vIVjPeP)));
					continue;
				}
				case 49U:
				{
					int num12;
					int num8 = (int)((ushort)num12);
					uint[] array24 = new uint[*(&NoDispatchReport.pUveA9U08x)];
					array24[*(&NoDispatchReport.JJ0R8pYrvx)] = (uint)(*(&NoDispatchReport.K4GKrhTWWh) + *(&NoDispatchReport.gjeHyOhwi6));
					array24[*(&NoDispatchReport.WFUFWZevDf)] = (uint)(*(&NoDispatchReport.gnDefvNlxc));
					array24[*(&NoDispatchReport.p7ebRkpsdu) + *(&NoDispatchReport.HmIzaEkBxR)] = (uint)(*(&NoDispatchReport.DiT1A2gAlC));
					uint num72 = num + (uint)(*(&NoDispatchReport.A58FQZl2yw));
					uint num73 = num72 * array24[*(&NoDispatchReport.uvSTX4fODa)];
					num2 = (num73 * array24[*(&NoDispatchReport.LMxfZHonbY) + *(&NoDispatchReport.DpHatLnCiB)] ^ (uint)(*(&NoDispatchReport.drNBhRQ9dF)));
					continue;
				}
				case 50U:
				{
					int num8;
					int num12 = num8 ^ num12;
					int num7;
					num2 = (((num7 <= num7) ? 1232725327U : 1579054258U) ^ num * 1616154726U);
					continue;
				}
				case 51U:
				{
					int num8;
					int[] array11;
					int num7 = array11[num8 + 6 - num7] ^ -8;
					num2 = 2561212919U;
					continue;
				}
				case 52U:
				{
					int num12;
					int num8 = num12;
					uint num74 = num - (uint)(*(&NoDispatchReport.MEddkLh5Bj));
					uint num75 = num74 + (uint)(*(&NoDispatchReport.eoSwEG1WAE));
					uint num76 = num75 + (uint)(*(&NoDispatchReport.2S24hcfv97));
					num2 = (num76 ^ (uint)(*(&NoDispatchReport.pSfy1VOf5h)) ^ (uint)(*(&NoDispatchReport.UwqgAfADhm)));
					continue;
				}
				case 53U:
				{
					int num7;
					num2 = (((num7 > num7) ? 1730648453U : 527099023U) ^ num * 3704624564U);
					continue;
				}
				case 54U:
				{
					int num7 = -num7;
					uint num77 = num - (uint)(*(&NoDispatchReport.LfoYMFRGiG)) & (uint)(*(&NoDispatchReport.UL14whQXd3));
					num2 = (num77 * (uint)(*(&NoDispatchReport.kLyONZAza4)) ^ (uint)(*(&NoDispatchReport.ay0XwgJYAa)));
					continue;
				}
				case 55U:
				{
					int num7;
					int num8 = num7 ^ 354565892;
					num2 = 2275294045U;
					continue;
				}
				case 56U:
					num2 = 3757367963U;
					continue;
				case 57U:
				{
					int num8;
					int num7 = (int)((byte)num8);
					uint[] array25 = new uint[*(&NoDispatchReport.bg66aOv9tW) + *(&NoDispatchReport.Qpk5pdjrEE)];
					array25[*(&NoDispatchReport.khVGZiRdni)] = (uint)(*(&NoDispatchReport.CGqPdqIfKT) + *(&NoDispatchReport.FlRmysj1CK));
					array25[*(&NoDispatchReport.erkKw4K0g2)] = (uint)(*(&NoDispatchReport.7SWLUJ9Uc9));
					array25[*(&NoDispatchReport.UDhu89QtRr)] = (uint)(*(&NoDispatchReport.9aacDVgfci));
					uint num78 = num | (uint)(*(&NoDispatchReport.fR8RWxOGSp));
					num2 = ((num78 + array25[*(&NoDispatchReport.tOZC0aKzLx)] & (uint)(*(&NoDispatchReport.oajz2g13H9))) ^ (uint)(*(&NoDispatchReport.nd23dDFPYL)));
					continue;
				}
				case 58U:
				{
					int num8 = num8;
					uint[] array26 = new uint[*(&NoDispatchReport.KGj6J3uNrF)];
					array26[*(&NoDispatchReport.sGHEecOyNV)] = (uint)(*(&NoDispatchReport.ObaUt2afnp));
					array26[*(&NoDispatchReport.0c4EYFPgCc)] = (uint)(*(&NoDispatchReport.j31JCyBzOY));
					array26[*(&NoDispatchReport.e5g68spPMR)] = (uint)(*(&NoDispatchReport.dOjCPQMDqY));
					array26[*(&NoDispatchReport.NswvwUkRS5)] = (uint)(*(&NoDispatchReport.0kRPL558Fp));
					array26[*(&NoDispatchReport.Z9Tu9UUy4v) + *(&NoDispatchReport.m8IzKvIvJo)] = (uint)(*(&NoDispatchReport.IY6Ra27U1U) + *(&NoDispatchReport.VO7B9NYBwc));
					array26[*(&NoDispatchReport.AvXgT2cbFZ)] = (uint)(*(&NoDispatchReport.wKybhBDCTH));
					uint num79 = (num & array26[*(&NoDispatchReport.WA7kaYBH06)]) ^ array26[*(&NoDispatchReport.XH9qoWBa7i)];
					uint num80 = num79 + (uint)(*(&NoDispatchReport.afObhKZfe8));
					uint num81 = (num80 & array26[*(&NoDispatchReport.KVroFAyxG5)]) - (uint)(*(&NoDispatchReport.1UlICpLHxK));
					num2 = ((num81 & (uint)(*(&NoDispatchReport.9mEvr1vfCP))) ^ (uint)(*(&NoDispatchReport.8fn2vBZUln)));
					continue;
				}
				case 59U:
				{
					int num8;
					int num12;
					int num7 = num12 & num8;
					uint[] array27 = new uint[*(&NoDispatchReport.gXyTK1D2dy)];
					array27[*(&NoDispatchReport.eT3Uwot4Zi)] = (uint)(*(&NoDispatchReport.fgOCsflOVl));
					array27[*(&NoDispatchReport.8VayjIEf9r)] = (uint)(*(&NoDispatchReport.wwoPvdiqAt));
					array27[*(&NoDispatchReport.cpYs09Jwlo)] = (uint)(*(&NoDispatchReport.Qyh20I2Evo) + *(&NoDispatchReport.jO5rwt28QO));
					array27[*(&NoDispatchReport.64NlIS6s8j)] = (uint)(*(&NoDispatchReport.9S4Ua7OvZm));
					uint num82 = num | array27[*(&NoDispatchReport.le5VKOtq6G)];
					uint num83 = (num82 - array27[*(&NoDispatchReport.HKfWrWl6th)]) * (uint)(*(&NoDispatchReport.MKGLpQTkQy));
					num2 = ((num83 & (uint)(*(&NoDispatchReport.fGjomc81b4))) ^ (uint)(*(&NoDispatchReport.jQv1cyxhnE)));
					continue;
				}
				case 60U:
					num2 = 2217296381U;
					continue;
				case 61U:
				{
					int num8 = -num8;
					uint num84 = (num | (uint)(*(&NoDispatchReport.YSJgDzVqVj) + *(&NoDispatchReport.gS8LDQk0rN)) | (uint)(*(&NoDispatchReport.ywOWTFxh3I))) - (uint)(*(&NoDispatchReport.DAYOsY8F2y)) + (uint)(*(&NoDispatchReport.VDk9Zd4R3e));
					num2 = (num84 * (uint)(*(&NoDispatchReport.58sSplDxN7)) ^ (uint)(*(&NoDispatchReport.CxxNfg3tco) + *(&NoDispatchReport.Rf821vLP6z)));
					continue;
				}
				}
				break;
			}
			return result;
			IL_24:
			num2 = 3302783332U;
			goto IL_29;
			IL_A8C:
			num2 = 4141894115U;
			goto IL_29;
		}

		// Token: 0x060001DA RID: 474 RVA: 0x00647040 File Offset: 0x00645240
		public unsafe NoDispatchReport()
		{
			if ((*(&NoDispatchReport.J9VGJEEXf0) ^ *(&NoDispatchReport.J9VGJEEXf0)) != 0)
			{
				int[] array = new int[10];
				int num;
				int num2;
				num %= num2;
				int num3;
				num = num3 / num2;
				*(ref num3 + (IntPtr)num2) = num2;
				array[num2 + 9 - num2] = (num2 | 9);
				num3 = -num;
				int num4;
				array[num + 9 - num2] = num4 - 2;
				array[num4 + 8 - num] = num3 - -10;
				int num5 = num4 + 273;
				num = (num5 & num2);
				num = -num5;
				num5 = num + num2;
				num2 = num + 713;
				NoDispatchReport.IXWAZobc6A = num2;
				array[num4 + 9 - num5] = num4 - 5;
				num5 = (num2 | 1431088482);
				num2 = 287148029;
				num5 += num2;
				num4 = -num2;
				array[num5 + 5 - num4] = num3 - 2;
				num3 |= 1188627899;
				if (num5 > num5)
				{
					num = num4 + num2;
					if (num > num)
					{
						num3 = (int)((ushort)num4);
						num2 = num5 >> 5;
					}
					num2 = (int)((ushort)num4);
					num = *(ref num4 + (IntPtr)num2);
					num5 = (int)((byte)num4);
					num4 = ~num;
				}
				num2 = num5 * 173;
				num4 = num5 + num2;
				num5 = num3 * 203;
				num3 = -num4;
				array[num3 + 9 - num4] = num4 - -4;
				num4 = ~num2;
				array[num4 + 5 - num5] = (num2 | 4);
				num4 = (array[num3 + 9 - num4] ^ 1);
				num2 = num5 % 547;
				num5 = num;
				num5 = num4;
				num = num4 * 860;
				num4 = num * 60;
				if (num > num)
				{
					num3 = 464852256;
				}
				num3 = num % num2;
				if (num3 > num3)
				{
					num = *(ref NoDispatchReport.IXWAZobc6A + (IntPtr)num3);
					num3 = num4 + num2;
					num3 = (array[num2 + 5 - num4] ^ -1);
					num2 ^= num3;
					array[num + 5 - num2] = num4 - 4;
				}
				num5 = 1996848260;
				num3 = *(ref num4 + (IntPtr)num2);
				if (num > num)
				{
					num = num5 / 490;
					num2 = (int)((short)num5);
					num = -num3;
					num5 = num << 6;
					num5 = (int)((sbyte)num3);
					*(ref NoDispatchReport.IXWAZobc6A + (IntPtr)num2) = num2;
					num4 |= num2;
					NoDispatchReport.IXWAZobc6A = num2;
					num2 = (int)((byte)num);
					if (num2 > num2)
					{
						num4 *= 739;
						array[num3 + 7 - num2] = (num5 | -4);
						NoDispatchReport.IXWAZobc6A = num5;
						num3 = -num;
						num5 = (int)((sbyte)num4);
						num5 = num3 % 117;
						num5 = 1919117714;
						num3 = (num5 ^ 95108555);
						num2 = (int)((byte)num2);
					}
				}
				num5 = (int)((sbyte)num3);
				num2 /= 611;
				num = num5;
				num3 = (array[num5 + 9 - num3] ^ -6);
				num2 = (num | num2);
			}
			base..ctor();
			for (;;)
			{
				IL_24E:
				uint num6 = 1074085852U;
				for (;;)
				{
					uint num7;
					switch ((num7 = (num6 ^ (uint)(*(&NoDispatchReport.poxM1YNFry) + *(&NoDispatchReport.Mq5jXyHYai)))) % (uint)(*(&NoDispatchReport.Xtyp84dC2y)))
					{
					case 0U:
						goto IL_24E;
					case 1U:
					{
						uint num8 = num7 ^ (uint)(*(&NoDispatchReport.oxW7dCNVxx));
						uint num9 = (num8 ^ (uint)(*(&NoDispatchReport.CoQkCrpIkG))) * (uint)(*(&NoDispatchReport.6vhML6zIN6)) ^ (uint)(*(&NoDispatchReport.5LM2JYU8FV));
						uint num10 = num9 & (uint)(*(&NoDispatchReport.lvlmftdNmQ));
						num6 = ((num10 & (uint)(*(&NoDispatchReport.PUbw13PKvh) + *(&NoDispatchReport.MFH011bXan))) ^ (uint)(*(&NoDispatchReport.XqDPeKK5qc)));
						continue;
					}
					}
					return;
				}
			}
		}

		// Token: 0x0404ED89 RID: 322953 RVA: 0x00147188 File Offset: 0x00145388
		static int x9c0pqhMpr;

		// Token: 0x0404ED8A RID: 322954 RVA: 0x00147190 File Offset: 0x00145390
		static int IXWAZobc6A;

		// Token: 0x0404ED8B RID: 322955 RVA: 0x00147198 File Offset: 0x00145398
		static int J9VGJEEXf0;

		// Token: 0x0404ED8C RID: 322956 RVA: 0x001471A0 File Offset: 0x001453A0
		static readonly int woo8Uuj889;

		// Token: 0x0404ED8D RID: 322957 RVA: 0x00015250 File Offset: 0x00013450
		static readonly int v6PTG1Y8Kk;

		// Token: 0x0404ED8E RID: 322958 RVA: 0x00003368 File Offset: 0x00001568
		static readonly int cUFiCZQ4Fe;

		// Token: 0x0404ED8F RID: 322959 RVA: 0x001471A8 File Offset: 0x001453A8
		static readonly int 6aKFrxPbNM;

		// Token: 0x0404ED90 RID: 322960 RVA: 0x001471B0 File Offset: 0x001453B0
		static readonly int 9e9agAYu9U;

		// Token: 0x0404ED91 RID: 322961 RVA: 0x001471B8 File Offset: 0x001453B8
		static readonly int Vl14kciG55;

		// Token: 0x0404ED92 RID: 322962 RVA: 0x001471C0 File Offset: 0x001453C0
		static readonly int dp2eCVwKlT;

		// Token: 0x0404ED93 RID: 322963 RVA: 0x001471C8 File Offset: 0x001453C8
		static readonly int m6v8l8UoBB;

		// Token: 0x0404ED94 RID: 322964 RVA: 0x001471D0 File Offset: 0x001453D0
		static readonly int Ag4vIVjPeP;

		// Token: 0x0404ED95 RID: 322965 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int OIfRsTlfXL;

		// Token: 0x0404ED96 RID: 322966 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int OOJqsYz3Tm;

		// Token: 0x0404ED97 RID: 322967 RVA: 0x001471D8 File Offset: 0x001453D8
		static readonly int H3E457uHVr;

		// Token: 0x0404ED98 RID: 322968 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vgpVEdbdPR;

		// Token: 0x0404ED99 RID: 322969 RVA: 0x001471E0 File Offset: 0x001453E0
		static readonly int XzR0wvWOCu;

		// Token: 0x0404ED9A RID: 322970 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int fq62HVElWv;

		// Token: 0x0404ED9B RID: 322971 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jdJqZsjxlO;

		// Token: 0x0404ED9C RID: 322972 RVA: 0x001471E8 File Offset: 0x001453E8
		static readonly int 6VoBPSmOHJ;

		// Token: 0x0404ED9D RID: 322973 RVA: 0x001471F0 File Offset: 0x001453F0
		static readonly int kgEkLFkxOt;

		// Token: 0x0404ED9E RID: 322974 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Z0Gds3pkaE;

		// Token: 0x0404ED9F RID: 322975 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int MjmyxJB5mz;

		// Token: 0x0404EDA0 RID: 322976 RVA: 0x001471F8 File Offset: 0x001453F8
		static readonly int szeNKCZjeU;

		// Token: 0x0404EDA1 RID: 322977 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int Hvi2zGOKSV;

		// Token: 0x0404EDA2 RID: 322978 RVA: 0x00147200 File Offset: 0x00145400
		static readonly int mCxC7B4QxB;

		// Token: 0x0404EDA3 RID: 322979 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DpKYBjV3Tp;

		// Token: 0x0404EDA4 RID: 322980 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int eGGG6aAt9q;

		// Token: 0x0404EDA5 RID: 322981 RVA: 0x00147208 File Offset: 0x00145408
		static readonly int 51mRNqCcPJ;

		// Token: 0x0404EDA6 RID: 322982 RVA: 0x001471D8 File Offset: 0x001453D8
		static readonly int IIwcQclK1P;

		// Token: 0x0404EDA7 RID: 322983 RVA: 0x00147210 File Offset: 0x00145410
		static readonly int vV1n1f5qFh;

		// Token: 0x0404EDA8 RID: 322984 RVA: 0x00147218 File Offset: 0x00145418
		static readonly int AKRGGMC3LV;

		// Token: 0x0404EDA9 RID: 322985 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int h3nJhVUn0e;

		// Token: 0x0404EDAA RID: 322986 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int y02t5j98Zr;

		// Token: 0x0404EDAB RID: 322987 RVA: 0x00147200 File Offset: 0x00145400
		static readonly int uVWsI71pVE;

		// Token: 0x0404EDAC RID: 322988 RVA: 0x00147208 File Offset: 0x00145408
		static readonly int Zs8fs1rrGf;

		// Token: 0x0404EDAD RID: 322989 RVA: 0x00147220 File Offset: 0x00145420
		static readonly int KS0lsKRiKh;

		// Token: 0x0404EDAE RID: 322990 RVA: 0x00147228 File Offset: 0x00145428
		static readonly int MEddkLh5Bj;

		// Token: 0x0404EDAF RID: 322991 RVA: 0x00147230 File Offset: 0x00145430
		static readonly int eoSwEG1WAE;

		// Token: 0x0404EDB0 RID: 322992 RVA: 0x00147238 File Offset: 0x00145438
		static readonly int 2S24hcfv97;

		// Token: 0x0404EDB1 RID: 322993 RVA: 0x00147240 File Offset: 0x00145440
		static readonly int pSfy1VOf5h;

		// Token: 0x0404EDB2 RID: 322994 RVA: 0x00147248 File Offset: 0x00145448
		static readonly int UwqgAfADhm;

		// Token: 0x0404EDB3 RID: 322995 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int T5hGp4Li6I;

		// Token: 0x0404EDB4 RID: 322996 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int pv5D3MJd4s;

		// Token: 0x0404EDB5 RID: 322997 RVA: 0x00147250 File Offset: 0x00145450
		static readonly int 1VbdtFlV4B;

		// Token: 0x0404EDB6 RID: 322998 RVA: 0x00147258 File Offset: 0x00145458
		static readonly int bbNXouvYJ7;

		// Token: 0x0404EDB7 RID: 322999 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Kpjw2i1nny;

		// Token: 0x0404EDB8 RID: 323000 RVA: 0x00147260 File Offset: 0x00145460
		static readonly int VgJzu7dEXj;

		// Token: 0x0404EDB9 RID: 323001 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Szo4qNhhYI;

		// Token: 0x0404EDBA RID: 323002 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int avU7hLvplK;

		// Token: 0x0404EDBB RID: 323003 RVA: 0x00147268 File Offset: 0x00145468
		static readonly int N8sFp5SYnq;

		// Token: 0x0404EDBC RID: 323004 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int RrBjpVBpFo;

		// Token: 0x0404EDBD RID: 323005 RVA: 0x00147260 File Offset: 0x00145460
		static readonly int AUOfXkMMRi;

		// Token: 0x0404EDBE RID: 323006 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int MycMVTHjOv;

		// Token: 0x0404EDBF RID: 323007 RVA: 0x00147270 File Offset: 0x00145470
		static readonly int 4I3s1suuRM;

		// Token: 0x0404EDC0 RID: 323008 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int KGj6J3uNrF;

		// Token: 0x0404EDC1 RID: 323009 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sGHEecOyNV;

		// Token: 0x0404EDC2 RID: 323010 RVA: 0x00147278 File Offset: 0x00145478
		static readonly int ObaUt2afnp;

		// Token: 0x0404EDC3 RID: 323011 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 0c4EYFPgCc;

		// Token: 0x0404EDC4 RID: 323012 RVA: 0x00147280 File Offset: 0x00145480
		static readonly int j31JCyBzOY;

		// Token: 0x0404EDC5 RID: 323013 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int e5g68spPMR;

		// Token: 0x0404EDC6 RID: 323014 RVA: 0x00147288 File Offset: 0x00145488
		static readonly int dOjCPQMDqY;

		// Token: 0x0404EDC7 RID: 323015 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int NswvwUkRS5;

		// Token: 0x0404EDC8 RID: 323016 RVA: 0x00147290 File Offset: 0x00145490
		static readonly int 0kRPL558Fp;

		// Token: 0x0404EDC9 RID: 323017 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Z9Tu9UUy4v;

		// Token: 0x0404EDCA RID: 323018 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int m8IzKvIvJo;

		// Token: 0x0404EDCB RID: 323019 RVA: 0x00147298 File Offset: 0x00145498
		static readonly int IY6Ra27U1U;

		// Token: 0x0404EDCC RID: 323020 RVA: 0x001472A0 File Offset: 0x001454A0
		static readonly int VO7B9NYBwc;

		// Token: 0x0404EDCD RID: 323021 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int AvXgT2cbFZ;

		// Token: 0x0404EDCE RID: 323022 RVA: 0x001472A8 File Offset: 0x001454A8
		static readonly int wKybhBDCTH;

		// Token: 0x0404EDCF RID: 323023 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int WA7kaYBH06;

		// Token: 0x0404EDD0 RID: 323024 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int XH9qoWBa7i;

		// Token: 0x0404EDD1 RID: 323025 RVA: 0x00147288 File Offset: 0x00145488
		static readonly int afObhKZfe8;

		// Token: 0x0404EDD2 RID: 323026 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int KVroFAyxG5;

		// Token: 0x0404EDD3 RID: 323027 RVA: 0x001472B0 File Offset: 0x001454B0
		static readonly int 1UlICpLHxK;

		// Token: 0x0404EDD4 RID: 323028 RVA: 0x001472A8 File Offset: 0x001454A8
		static readonly int 9mEvr1vfCP;

		// Token: 0x0404EDD5 RID: 323029 RVA: 0x001472B8 File Offset: 0x001454B8
		static readonly int 8fn2vBZUln;

		// Token: 0x0404EDD6 RID: 323030 RVA: 0x001472C0 File Offset: 0x001454C0
		static readonly int iNUCqF4GZ2;

		// Token: 0x0404EDD7 RID: 323031 RVA: 0x001472C8 File Offset: 0x001454C8
		static readonly int 9RrT8hQ57O;

		// Token: 0x0404EDD8 RID: 323032 RVA: 0x001472D0 File Offset: 0x001454D0
		static readonly int PSu06WrsWA;

		// Token: 0x0404EDD9 RID: 323033 RVA: 0x001472D8 File Offset: 0x001454D8
		static readonly int Q1gJmwSCFl;

		// Token: 0x0404EDDA RID: 323034 RVA: 0x001472E0 File Offset: 0x001454E0
		static readonly int 6oFKQrxU4N;

		// Token: 0x0404EDDB RID: 323035 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int udWWYPcdFU;

		// Token: 0x0404EDDC RID: 323036 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int XLuZmIuiqM;

		// Token: 0x0404EDDD RID: 323037 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int PO0WSkNkjP;

		// Token: 0x0404EDDE RID: 323038 RVA: 0x001472E8 File Offset: 0x001454E8
		static readonly int iXyIQweKuX;

		// Token: 0x0404EDDF RID: 323039 RVA: 0x001472F0 File Offset: 0x001454F0
		static readonly int Tz7vNv4qiI;

		// Token: 0x0404EDE0 RID: 323040 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6Pns8gnAEy;

		// Token: 0x0404EDE1 RID: 323041 RVA: 0x001472F8 File Offset: 0x001454F8
		static readonly int C230vAWlJz;

		// Token: 0x0404EDE2 RID: 323042 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int nkxS2aRFIg;

		// Token: 0x0404EDE3 RID: 323043 RVA: 0x00147300 File Offset: 0x00145500
		static readonly int qgCbSStGJt;

		// Token: 0x0404EDE4 RID: 323044 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int JeF6Va5G9N;

		// Token: 0x0404EDE5 RID: 323045 RVA: 0x00147308 File Offset: 0x00145508
		static readonly int YShseVcUzi;

		// Token: 0x0404EDE6 RID: 323046 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int Oi2hHfzcid;

		// Token: 0x0404EDE7 RID: 323047 RVA: 0x00147310 File Offset: 0x00145510
		static readonly int RQbZqJf07c;

		// Token: 0x0404EDE8 RID: 323048 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int eKF5IX9U66;

		// Token: 0x0404EDE9 RID: 323049 RVA: 0x00147318 File Offset: 0x00145518
		static readonly int 0YQlflmhzz;

		// Token: 0x0404EDEA RID: 323050 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int lcig5H1ICV;

		// Token: 0x0404EDEB RID: 323051 RVA: 0x001472F8 File Offset: 0x001454F8
		static readonly int 0mXXDEc6Yu;

		// Token: 0x0404EDEC RID: 323052 RVA: 0x00147300 File Offset: 0x00145500
		static readonly int gfglm2904F;

		// Token: 0x0404EDED RID: 323053 RVA: 0x00147320 File Offset: 0x00145520
		static readonly int g7BI1Cmj9B;

		// Token: 0x0404EDEE RID: 323054 RVA: 0x00147328 File Offset: 0x00145528
		static readonly int g0SkFOB3ha;

		// Token: 0x0404EDEF RID: 323055 RVA: 0x00147310 File Offset: 0x00145510
		static readonly int IpJFSF673D;

		// Token: 0x0404EDF0 RID: 323056 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int HAO6y3lPgB;

		// Token: 0x0404EDF1 RID: 323057 RVA: 0x00147330 File Offset: 0x00145530
		static readonly int b27XNpN5fY;

		// Token: 0x0404EDF2 RID: 323058 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 0FSd61y6zv;

		// Token: 0x0404EDF3 RID: 323059 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Fpq53fmVvM;

		// Token: 0x0404EDF4 RID: 323060 RVA: 0x00147338 File Offset: 0x00145538
		static readonly int nwXg9Qsv1m;

		// Token: 0x0404EDF5 RID: 323061 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1BbeMBsuA7;

		// Token: 0x0404EDF6 RID: 323062 RVA: 0x00147340 File Offset: 0x00145540
		static readonly int FpZu6wMBer;

		// Token: 0x0404EDF7 RID: 323063 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int D2JSvEsvdp;

		// Token: 0x0404EDF8 RID: 323064 RVA: 0x00147348 File Offset: 0x00145548
		static readonly int ICEM4ENLt1;

		// Token: 0x0404EDF9 RID: 323065 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int x1UyH8WnkM;

		// Token: 0x0404EDFA RID: 323066 RVA: 0x00147350 File Offset: 0x00145550
		static readonly int ErRJj91ItI;

		// Token: 0x0404EDFB RID: 323067 RVA: 0x00147338 File Offset: 0x00145538
		static readonly int T6QUyCkN02;

		// Token: 0x0404EDFC RID: 323068 RVA: 0x00147340 File Offset: 0x00145540
		static readonly int iASm4LhVLx;

		// Token: 0x0404EDFD RID: 323069 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int rELRlbv5n4;

		// Token: 0x0404EDFE RID: 323070 RVA: 0x00147350 File Offset: 0x00145550
		static readonly int MFbki0kA9F;

		// Token: 0x0404EDFF RID: 323071 RVA: 0x00147358 File Offset: 0x00145558
		static readonly int XJxsoDYoOX;

		// Token: 0x0404EE00 RID: 323072 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bg66aOv9tW;

		// Token: 0x0404EE01 RID: 323073 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Qpk5pdjrEE;

		// Token: 0x0404EE02 RID: 323074 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int khVGZiRdni;

		// Token: 0x0404EE03 RID: 323075 RVA: 0x00147360 File Offset: 0x00145560
		static readonly int CGqPdqIfKT;

		// Token: 0x0404EE04 RID: 323076 RVA: 0x00147368 File Offset: 0x00145568
		static readonly int FlRmysj1CK;

		// Token: 0x0404EE05 RID: 323077 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int erkKw4K0g2;

		// Token: 0x0404EE06 RID: 323078 RVA: 0x00147370 File Offset: 0x00145570
		static readonly int 7SWLUJ9Uc9;

		// Token: 0x0404EE07 RID: 323079 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int UDhu89QtRr;

		// Token: 0x0404EE08 RID: 323080 RVA: 0x00147378 File Offset: 0x00145578
		static readonly int 9aacDVgfci;

		// Token: 0x0404EE09 RID: 323081 RVA: 0x00147380 File Offset: 0x00145580
		static readonly int fR8RWxOGSp;

		// Token: 0x0404EE0A RID: 323082 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int tOZC0aKzLx;

		// Token: 0x0404EE0B RID: 323083 RVA: 0x00147378 File Offset: 0x00145578
		static readonly int oajz2g13H9;

		// Token: 0x0404EE0C RID: 323084 RVA: 0x00147388 File Offset: 0x00145588
		static readonly int nd23dDFPYL;

		// Token: 0x0404EE0D RID: 323085 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int vKbl7vBXmn;

		// Token: 0x0404EE0E RID: 323086 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int LqTp4ErIZz;

		// Token: 0x0404EE0F RID: 323087 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 5U8TCPVfjw;

		// Token: 0x0404EE10 RID: 323088 RVA: 0x00147390 File Offset: 0x00145590
		static readonly int V4b9Cd981H;

		// Token: 0x0404EE11 RID: 323089 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int fdRdx6JN9Y;

		// Token: 0x0404EE12 RID: 323090 RVA: 0x00147398 File Offset: 0x00145598
		static readonly int V60iQaLHjs;

		// Token: 0x0404EE13 RID: 323091 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ZfyzSQPTma;

		// Token: 0x0404EE14 RID: 323092 RVA: 0x001473A0 File Offset: 0x001455A0
		static readonly int FtRRTbDffF;

		// Token: 0x0404EE15 RID: 323093 RVA: 0x001473A8 File Offset: 0x001455A8
		static readonly int FHfKbZE2tm;

		// Token: 0x0404EE16 RID: 323094 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int S1ZJr9pcLh;

		// Token: 0x0404EE17 RID: 323095 RVA: 0x001473B0 File Offset: 0x001455B0
		static readonly int r0kiTmoiOy;

		// Token: 0x0404EE18 RID: 323096 RVA: 0x001473B8 File Offset: 0x001455B8
		static readonly int XqmdmR9oY3;

		// Token: 0x0404EE19 RID: 323097 RVA: 0x00147390 File Offset: 0x00145590
		static readonly int LWkAHNUHjU;

		// Token: 0x0404EE1A RID: 323098 RVA: 0x00147398 File Offset: 0x00145598
		static readonly int wkT7YPh70y;

		// Token: 0x0404EE1B RID: 323099 RVA: 0x001473C0 File Offset: 0x001455C0
		static readonly int ugn4OmP5ga;

		// Token: 0x0404EE1C RID: 323100 RVA: 0x001473C8 File Offset: 0x001455C8
		static readonly int 9BDSVUPkaG;

		// Token: 0x0404EE1D RID: 323101 RVA: 0x001473D0 File Offset: 0x001455D0
		static readonly int Sh84CwWpEX;

		// Token: 0x0404EE1E RID: 323102 RVA: 0x001473D8 File Offset: 0x001455D8
		static readonly int uCxjJpspvf;

		// Token: 0x0404EE1F RID: 323103 RVA: 0x001473E0 File Offset: 0x001455E0
		static readonly int 8YkJUuhAlD;

		// Token: 0x0404EE20 RID: 323104 RVA: 0x001473E8 File Offset: 0x001455E8
		static readonly int 96gugMht2c;

		// Token: 0x0404EE21 RID: 323105 RVA: 0x001473F0 File Offset: 0x001455F0
		static readonly int Pj0Jp7NeJp;

		// Token: 0x0404EE22 RID: 323106 RVA: 0x001473F8 File Offset: 0x001455F8
		static readonly int mky5H36zkR;

		// Token: 0x0404EE23 RID: 323107 RVA: 0x00147400 File Offset: 0x00145600
		static readonly int PWDBXxfCD6;

		// Token: 0x0404EE24 RID: 323108 RVA: 0x00147408 File Offset: 0x00145608
		static readonly int I9xTPYibdX;

		// Token: 0x0404EE25 RID: 323109 RVA: 0x00147410 File Offset: 0x00145610
		static readonly int hD15bZIlmm;

		// Token: 0x0404EE26 RID: 323110 RVA: 0x00147418 File Offset: 0x00145618
		static readonly int QrJkN3gzv2;

		// Token: 0x0404EE27 RID: 323111 RVA: 0x00147420 File Offset: 0x00145620
		static readonly int bLaNhnwept;

		// Token: 0x0404EE28 RID: 323112 RVA: 0x00147428 File Offset: 0x00145628
		static readonly int VeVMuLeHj8;

		// Token: 0x0404EE29 RID: 323113 RVA: 0x00147430 File Offset: 0x00145630
		static readonly int o4Zapa0MFW;

		// Token: 0x0404EE2A RID: 323114 RVA: 0x00147438 File Offset: 0x00145638
		static readonly int 1spl6VmnYy;

		// Token: 0x0404EE2B RID: 323115 RVA: 0x00147440 File Offset: 0x00145640
		static readonly int mn63RvV60B;

		// Token: 0x0404EE2C RID: 323116 RVA: 0x00147448 File Offset: 0x00145648
		static readonly int YZPxNhvAhG;

		// Token: 0x0404EE2D RID: 323117 RVA: 0x00147450 File Offset: 0x00145650
		static readonly int wjZS1mzuQY;

		// Token: 0x0404EE2E RID: 323118 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int j0tvVB7gJ3;

		// Token: 0x0404EE2F RID: 323119 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int F4WE7cd1XY;

		// Token: 0x0404EE30 RID: 323120 RVA: 0x00147458 File Offset: 0x00145658
		static readonly int kmGRBCOnCo;

		// Token: 0x0404EE31 RID: 323121 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6lpbchpebM;

		// Token: 0x0404EE32 RID: 323122 RVA: 0x00147460 File Offset: 0x00145660
		static readonly int jP1nB2NVVY;

		// Token: 0x0404EE33 RID: 323123 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int J7W1x7ubtT;

		// Token: 0x0404EE34 RID: 323124 RVA: 0x00147468 File Offset: 0x00145668
		static readonly int wUde7dO5lZ;

		// Token: 0x0404EE35 RID: 323125 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int w8ZLzVvcQI;

		// Token: 0x0404EE36 RID: 323126 RVA: 0x00147470 File Offset: 0x00145670
		static readonly int z3Soe8Oxnf;

		// Token: 0x0404EE37 RID: 323127 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int wOuIZPvWqh;

		// Token: 0x0404EE38 RID: 323128 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int nRt5lKhKCc;

		// Token: 0x0404EE39 RID: 323129 RVA: 0x00147468 File Offset: 0x00145668
		static readonly int MSKld3Bz98;

		// Token: 0x0404EE3A RID: 323130 RVA: 0x00147470 File Offset: 0x00145670
		static readonly int PbRGniORwk;

		// Token: 0x0404EE3B RID: 323131 RVA: 0x00147478 File Offset: 0x00145678
		static readonly int jYwsehKWCU;

		// Token: 0x0404EE3C RID: 323132 RVA: 0x00147480 File Offset: 0x00145680
		static readonly int bDuLSeEIpg;

		// Token: 0x0404EE3D RID: 323133 RVA: 0x00147488 File Offset: 0x00145688
		static readonly int N6XrSMAmSD;

		// Token: 0x0404EE3E RID: 323134 RVA: 0x00147490 File Offset: 0x00145690
		static readonly int 5QYb2xgbG5;

		// Token: 0x0404EE3F RID: 323135 RVA: 0x00147498 File Offset: 0x00145698
		static readonly int toxphLqGyI;

		// Token: 0x0404EE40 RID: 323136 RVA: 0x001474A0 File Offset: 0x001456A0
		static readonly int dGlQXnAEaS;

		// Token: 0x0404EE41 RID: 323137 RVA: 0x001474A8 File Offset: 0x001456A8
		static readonly int hhE9YKpTSe;

		// Token: 0x0404EE42 RID: 323138 RVA: 0x001474B0 File Offset: 0x001456B0
		static readonly int 8mCtwiJrKG;

		// Token: 0x0404EE43 RID: 323139 RVA: 0x001474B8 File Offset: 0x001456B8
		static readonly int f3yJjzoIEP;

		// Token: 0x0404EE44 RID: 323140 RVA: 0x001474C0 File Offset: 0x001456C0
		static readonly int wcBxYLkxRW;

		// Token: 0x0404EE45 RID: 323141 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int gXyTK1D2dy;

		// Token: 0x0404EE46 RID: 323142 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int eT3Uwot4Zi;

		// Token: 0x0404EE47 RID: 323143 RVA: 0x001474C8 File Offset: 0x001456C8
		static readonly int fgOCsflOVl;

		// Token: 0x0404EE48 RID: 323144 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8VayjIEf9r;

		// Token: 0x0404EE49 RID: 323145 RVA: 0x001474D0 File Offset: 0x001456D0
		static readonly int wwoPvdiqAt;

		// Token: 0x0404EE4A RID: 323146 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int cpYs09Jwlo;

		// Token: 0x0404EE4B RID: 323147 RVA: 0x001474D8 File Offset: 0x001456D8
		static readonly int Qyh20I2Evo;

		// Token: 0x0404EE4C RID: 323148 RVA: 0x001474E0 File Offset: 0x001456E0
		static readonly int jO5rwt28QO;

		// Token: 0x0404EE4D RID: 323149 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 64NlIS6s8j;

		// Token: 0x0404EE4E RID: 323150 RVA: 0x001474E8 File Offset: 0x001456E8
		static readonly int 9S4Ua7OvZm;

		// Token: 0x0404EE4F RID: 323151 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int le5VKOtq6G;

		// Token: 0x0404EE50 RID: 323152 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int HKfWrWl6th;

		// Token: 0x0404EE51 RID: 323153 RVA: 0x001474F0 File Offset: 0x001456F0
		static readonly int MKGLpQTkQy;

		// Token: 0x0404EE52 RID: 323154 RVA: 0x001474E8 File Offset: 0x001456E8
		static readonly int fGjomc81b4;

		// Token: 0x0404EE53 RID: 323155 RVA: 0x001474F8 File Offset: 0x001456F8
		static readonly int jQv1cyxhnE;

		// Token: 0x0404EE54 RID: 323156 RVA: 0x00147500 File Offset: 0x00145700
		static readonly int WSB1abXuq3;

		// Token: 0x0404EE55 RID: 323157 RVA: 0x00147508 File Offset: 0x00145708
		static readonly int 4JZHlAl0uO;

		// Token: 0x0404EE56 RID: 323158 RVA: 0x00147510 File Offset: 0x00145710
		static readonly int Xtfz85YOs1;

		// Token: 0x0404EE57 RID: 323159 RVA: 0x00147518 File Offset: 0x00145718
		static readonly int dw7McMErNL;

		// Token: 0x0404EE58 RID: 323160 RVA: 0x00147520 File Offset: 0x00145720
		static readonly int FOLhAa0oQb;

		// Token: 0x0404EE59 RID: 323161 RVA: 0x00147528 File Offset: 0x00145728
		static readonly int N6xYrmxM3f;

		// Token: 0x0404EE5A RID: 323162 RVA: 0x00147530 File Offset: 0x00145730
		static readonly int CIByZHLNoZ;

		// Token: 0x0404EE5B RID: 323163 RVA: 0x00147538 File Offset: 0x00145738
		static readonly int 63niJIh7zi;

		// Token: 0x0404EE5C RID: 323164 RVA: 0x00147540 File Offset: 0x00145740
		static readonly int Eu8Rng9if0;

		// Token: 0x0404EE5D RID: 323165 RVA: 0x00147548 File Offset: 0x00145748
		static readonly int Y2xsI6NXH2;

		// Token: 0x0404EE5E RID: 323166 RVA: 0x00147550 File Offset: 0x00145750
		static readonly int On91fTTOOi;

		// Token: 0x0404EE5F RID: 323167 RVA: 0x00147558 File Offset: 0x00145758
		static readonly int E0WVaSKuL3;

		// Token: 0x0404EE60 RID: 323168 RVA: 0x00147560 File Offset: 0x00145760
		static readonly int ImsyADF4ZN;

		// Token: 0x0404EE61 RID: 323169 RVA: 0x00147568 File Offset: 0x00145768
		static readonly int 5Kz7TbvHvT;

		// Token: 0x0404EE62 RID: 323170 RVA: 0x00147570 File Offset: 0x00145770
		static readonly int NuT7vifcS0;

		// Token: 0x0404EE63 RID: 323171 RVA: 0x00147578 File Offset: 0x00145778
		static readonly int wcLOul5K0b;

		// Token: 0x0404EE64 RID: 323172 RVA: 0x00147580 File Offset: 0x00145780
		static readonly int OZyBm4AZB9;

		// Token: 0x0404EE65 RID: 323173 RVA: 0x00147588 File Offset: 0x00145788
		static readonly int hC81pXSuDb;

		// Token: 0x0404EE66 RID: 323174 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int inmjbc8kNs;

		// Token: 0x0404EE67 RID: 323175 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int fkQTFy5SU1;

		// Token: 0x0404EE68 RID: 323176 RVA: 0x00147590 File Offset: 0x00145790
		static readonly int iFaTSteUiW;

		// Token: 0x0404EE69 RID: 323177 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int SKHZ3kxPkJ;

		// Token: 0x0404EE6A RID: 323178 RVA: 0x00147598 File Offset: 0x00145798
		static readonly int 5ZMTd7wov1;

		// Token: 0x0404EE6B RID: 323179 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bAaM2cMSRr;

		// Token: 0x0404EE6C RID: 323180 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8nC0ZUc0af;

		// Token: 0x0404EE6D RID: 323181 RVA: 0x001475A0 File Offset: 0x001457A0
		static readonly int BqrL5J2HzV;

		// Token: 0x0404EE6E RID: 323182 RVA: 0x001475A8 File Offset: 0x001457A8
		static readonly int 7zjr4Ru5ga;

		// Token: 0x0404EE6F RID: 323183 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Ye83LRXV4J;

		// Token: 0x0404EE70 RID: 323184 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int e5OQ0vTPQt;

		// Token: 0x0404EE71 RID: 323185 RVA: 0x001475B0 File Offset: 0x001457B0
		static readonly int kEd5uJEU6H;

		// Token: 0x0404EE72 RID: 323186 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int khUAGhsy9n;

		// Token: 0x0404EE73 RID: 323187 RVA: 0x001475B8 File Offset: 0x001457B8
		static readonly int vhNp1ClT1J;

		// Token: 0x0404EE74 RID: 323188 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 8fox0TACIC;

		// Token: 0x0404EE75 RID: 323189 RVA: 0x001475C0 File Offset: 0x001457C0
		static readonly int NCZwi6kNJS;

		// Token: 0x0404EE76 RID: 323190 RVA: 0x001475C8 File Offset: 0x001457C8
		static readonly int CfPm7C1xEs;

		// Token: 0x0404EE77 RID: 323191 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int iudxJF2gKx;

		// Token: 0x0404EE78 RID: 323192 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gpp7atHaG4;

		// Token: 0x0404EE79 RID: 323193 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bXKiGcPCzx;

		// Token: 0x0404EE7A RID: 323194 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int bM8adcjmnd;

		// Token: 0x0404EE7B RID: 323195 RVA: 0x001475B8 File Offset: 0x001457B8
		static readonly int DEDWwX0RMO;

		// Token: 0x0404EE7C RID: 323196 RVA: 0x001475D0 File Offset: 0x001457D0
		static readonly int 5bqJQKk4rq;

		// Token: 0x0404EE7D RID: 323197 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int z0rXVUrOd7;

		// Token: 0x0404EE7E RID: 323198 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Jfwn1XTyws;

		// Token: 0x0404EE7F RID: 323199 RVA: 0x001475D8 File Offset: 0x001457D8
		static readonly int m8zk19fzKT;

		// Token: 0x0404EE80 RID: 323200 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2p57nMWqAb;

		// Token: 0x0404EE81 RID: 323201 RVA: 0x001475E0 File Offset: 0x001457E0
		static readonly int qlxOFapDS3;

		// Token: 0x0404EE82 RID: 323202 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 1wI8D1AGfW;

		// Token: 0x0404EE83 RID: 323203 RVA: 0x001475E8 File Offset: 0x001457E8
		static readonly int y1EKEekz9o;

		// Token: 0x0404EE84 RID: 323204 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int AnxUCAKlfb;

		// Token: 0x0404EE85 RID: 323205 RVA: 0x001475F0 File Offset: 0x001457F0
		static readonly int UcgQcGg63w;

		// Token: 0x0404EE86 RID: 323206 RVA: 0x001475F8 File Offset: 0x001457F8
		static readonly int MPLomyhmJl;

		// Token: 0x0404EE87 RID: 323207 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int z0Do2N8x5C;

		// Token: 0x0404EE88 RID: 323208 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int qZlDBWVxs8;

		// Token: 0x0404EE89 RID: 323209 RVA: 0x00147600 File Offset: 0x00145800
		static readonly int 7n5NbvcJsO;

		// Token: 0x0404EE8A RID: 323210 RVA: 0x001475D8 File Offset: 0x001457D8
		static readonly int dhb3leY2XO;

		// Token: 0x0404EE8B RID: 323211 RVA: 0x001475E0 File Offset: 0x001457E0
		static readonly int HtA0FwnHmP;

		// Token: 0x0404EE8C RID: 323212 RVA: 0x001475E8 File Offset: 0x001457E8
		static readonly int dt4KoM40MH;

		// Token: 0x0404EE8D RID: 323213 RVA: 0x00147608 File Offset: 0x00145808
		static readonly int vyFrjJ7sbh;

		// Token: 0x0404EE8E RID: 323214 RVA: 0x00147610 File Offset: 0x00145810
		static readonly int 8cae1NmFIp;

		// Token: 0x0404EE8F RID: 323215 RVA: 0x00147618 File Offset: 0x00145818
		static readonly int HUhcvunQPZ;

		// Token: 0x0404EE90 RID: 323216 RVA: 0x00147620 File Offset: 0x00145820
		static readonly int khqQcSoTR6;

		// Token: 0x0404EE91 RID: 323217 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int y5pERASZTa;

		// Token: 0x0404EE92 RID: 323218 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int jzsh9bRn6y;

		// Token: 0x0404EE93 RID: 323219 RVA: 0x00147628 File Offset: 0x00145828
		static readonly int frcC7bwJCi;

		// Token: 0x0404EE94 RID: 323220 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jTxM0MocLu;

		// Token: 0x0404EE95 RID: 323221 RVA: 0x00147630 File Offset: 0x00145830
		static readonly int bO6zzuzJQA;

		// Token: 0x0404EE96 RID: 323222 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int BAWcaHdnH0;

		// Token: 0x0404EE97 RID: 323223 RVA: 0x00147638 File Offset: 0x00145838
		static readonly int OIWv0QBgqx;

		// Token: 0x0404EE98 RID: 323224 RVA: 0x00147628 File Offset: 0x00145828
		static readonly int xycMXQumMM;

		// Token: 0x0404EE99 RID: 323225 RVA: 0x00147630 File Offset: 0x00145830
		static readonly int ln3Bgi6Uvs;

		// Token: 0x0404EE9A RID: 323226 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int sAVUfS1L9j;

		// Token: 0x0404EE9B RID: 323227 RVA: 0x00147640 File Offset: 0x00145840
		static readonly int tTccNMiKFJ;

		// Token: 0x0404EE9C RID: 323228 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int W0b4OlPVOR;

		// Token: 0x0404EE9D RID: 323229 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Tqu8EwdHqE;

		// Token: 0x0404EE9E RID: 323230 RVA: 0x00147648 File Offset: 0x00145848
		static readonly int ZjnmdSKayU;

		// Token: 0x0404EE9F RID: 323231 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9wOlV1jaG4;

		// Token: 0x0404EEA0 RID: 323232 RVA: 0x00147650 File Offset: 0x00145850
		static readonly int Dg6rQCidXb;

		// Token: 0x0404EEA1 RID: 323233 RVA: 0x00147658 File Offset: 0x00145858
		static readonly int sbdBuxNzb5;

		// Token: 0x0404EEA2 RID: 323234 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ayh4RhcJmN;

		// Token: 0x0404EEA3 RID: 323235 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NDAwB3n6Wa;

		// Token: 0x0404EEA4 RID: 323236 RVA: 0x00147660 File Offset: 0x00145860
		static readonly int urCWliSN1i;

		// Token: 0x0404EEA5 RID: 323237 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ot8KdO9BZt;

		// Token: 0x0404EEA6 RID: 323238 RVA: 0x00147668 File Offset: 0x00145868
		static readonly int kY1KOpbr91;

		// Token: 0x0404EEA7 RID: 323239 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int JRdALtwKTt;

		// Token: 0x0404EEA8 RID: 323240 RVA: 0x00147670 File Offset: 0x00145870
		static readonly int PORDidEzTx;

		// Token: 0x0404EEA9 RID: 323241 RVA: 0x00147660 File Offset: 0x00145860
		static readonly int 3lgm0Vz1I6;

		// Token: 0x0404EEAA RID: 323242 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int GkNAZXQ89t;

		// Token: 0x0404EEAB RID: 323243 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int byspeVGymv;

		// Token: 0x0404EEAC RID: 323244 RVA: 0x00147678 File Offset: 0x00145878
		static readonly int klYM7hu0Jz;

		// Token: 0x0404EEAD RID: 323245 RVA: 0x00147680 File Offset: 0x00145880
		static readonly int 34CXmoARoL;

		// Token: 0x0404EEAE RID: 323246 RVA: 0x00147688 File Offset: 0x00145888
		static readonly int MGzjVF30Ie;

		// Token: 0x0404EEAF RID: 323247 RVA: 0x00147690 File Offset: 0x00145890
		static readonly int OBPXVfMBC1;

		// Token: 0x0404EEB0 RID: 323248 RVA: 0x00147698 File Offset: 0x00145898
		static readonly int mayKzhwUCz;

		// Token: 0x0404EEB1 RID: 323249 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int VzJbidvz01;

		// Token: 0x0404EEB2 RID: 323250 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int n3rok2poBH;

		// Token: 0x0404EEB3 RID: 323251 RVA: 0x001476A0 File Offset: 0x001458A0
		static readonly int c8OwivSpty;

		// Token: 0x0404EEB4 RID: 323252 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TiySJZ1yy1;

		// Token: 0x0404EEB5 RID: 323253 RVA: 0x001476A8 File Offset: 0x001458A8
		static readonly int tWLLNttJj7;

		// Token: 0x0404EEB6 RID: 323254 RVA: 0x001476B0 File Offset: 0x001458B0
		static readonly int 1HT5XWkX2w;

		// Token: 0x0404EEB7 RID: 323255 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int LGGBiFFYfL;

		// Token: 0x0404EEB8 RID: 323256 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int B00KYFxDiz;

		// Token: 0x0404EEB9 RID: 323257 RVA: 0x001476B8 File Offset: 0x001458B8
		static readonly int CIGv6LP35x;

		// Token: 0x0404EEBA RID: 323258 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ze5BpnQJmI;

		// Token: 0x0404EEBB RID: 323259 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int nUoY6ARJgS;

		// Token: 0x0404EEBC RID: 323260 RVA: 0x001476C0 File Offset: 0x001458C0
		static readonly int jgyDuD9UEW;

		// Token: 0x0404EEBD RID: 323261 RVA: 0x001476C8 File Offset: 0x001458C8
		static readonly int zMdrVh5yev;

		// Token: 0x0404EEBE RID: 323262 RVA: 0x001476A0 File Offset: 0x001458A0
		static readonly int ynaaLserz5;

		// Token: 0x0404EEBF RID: 323263 RVA: 0x001476D0 File Offset: 0x001458D0
		static readonly int 4GWmOSp1Rm;

		// Token: 0x0404EEC0 RID: 323264 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int n6EPTb16CZ;

		// Token: 0x0404EEC1 RID: 323265 RVA: 0x001476D8 File Offset: 0x001458D8
		static readonly int Fcove5GY2C;

		// Token: 0x0404EEC2 RID: 323266 RVA: 0x001476E0 File Offset: 0x001458E0
		static readonly int iReJcs00dD;

		// Token: 0x0404EEC3 RID: 323267 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 1Dh1H1iKGu;

		// Token: 0x0404EEC4 RID: 323268 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 0hpa0cbkIS;

		// Token: 0x0404EEC5 RID: 323269 RVA: 0x001476E8 File Offset: 0x001458E8
		static readonly int MR9PDVb5xk;

		// Token: 0x0404EEC6 RID: 323270 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lAc8hB5xnm;

		// Token: 0x0404EEC7 RID: 323271 RVA: 0x001476F0 File Offset: 0x001458F0
		static readonly int W5RHLBmDS9;

		// Token: 0x0404EEC8 RID: 323272 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int RPsL1jERxv;

		// Token: 0x0404EEC9 RID: 323273 RVA: 0x001476F8 File Offset: 0x001458F8
		static readonly int ZmXgJ0Eq2y;

		// Token: 0x0404EECA RID: 323274 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int go6f5QA1EC;

		// Token: 0x0404EECB RID: 323275 RVA: 0x00147700 File Offset: 0x00145900
		static readonly int tXnxTWRRH7;

		// Token: 0x0404EECC RID: 323276 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 7n92Mtiu8U;

		// Token: 0x0404EECD RID: 323277 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 65LecmSNPk;

		// Token: 0x0404EECE RID: 323278 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jMNvCB9jNx;

		// Token: 0x0404EECF RID: 323279 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jwj413pESM;

		// Token: 0x0404EED0 RID: 323280 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int sP3tFxMJVr;

		// Token: 0x0404EED1 RID: 323281 RVA: 0x00147708 File Offset: 0x00145908
		static readonly int DECgYvZNzL;

		// Token: 0x0404EED2 RID: 323282 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int u9hLvKWQmj;

		// Token: 0x0404EED3 RID: 323283 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 6N4C1TTeqO;

		// Token: 0x0404EED4 RID: 323284 RVA: 0x00147710 File Offset: 0x00145910
		static readonly int y0NftetCgG;

		// Token: 0x0404EED5 RID: 323285 RVA: 0x00147718 File Offset: 0x00145918
		static readonly int ecOHctrs74;

		// Token: 0x0404EED6 RID: 323286 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int b6gvu0JAoE;

		// Token: 0x0404EED7 RID: 323287 RVA: 0x00147720 File Offset: 0x00145920
		static readonly int b5hlW3vBbQ;

		// Token: 0x0404EED8 RID: 323288 RVA: 0x00147728 File Offset: 0x00145928
		static readonly int aTtgFe8xkI;

		// Token: 0x0404EED9 RID: 323289 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int lkgvx2Ucv2;

		// Token: 0x0404EEDA RID: 323290 RVA: 0x00147730 File Offset: 0x00145930
		static readonly int VtXboi5nvi;

		// Token: 0x0404EEDB RID: 323291 RVA: 0x00147738 File Offset: 0x00145938
		static readonly int 8pQreHM9qQ;

		// Token: 0x0404EEDC RID: 323292 RVA: 0x00147740 File Offset: 0x00145940
		static readonly int 2VZgc0Yvxd;

		// Token: 0x0404EEDD RID: 323293 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int jTQj5r6S2g;

		// Token: 0x0404EEDE RID: 323294 RVA: 0x00147748 File Offset: 0x00145948
		static readonly int jUCCK5UzRq;

		// Token: 0x0404EEDF RID: 323295 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int pUveA9U08x;

		// Token: 0x0404EEE0 RID: 323296 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int JJ0R8pYrvx;

		// Token: 0x0404EEE1 RID: 323297 RVA: 0x00147750 File Offset: 0x00145950
		static readonly int K4GKrhTWWh;

		// Token: 0x0404EEE2 RID: 323298 RVA: 0x00147758 File Offset: 0x00145958
		static readonly int gjeHyOhwi6;

		// Token: 0x0404EEE3 RID: 323299 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int WFUFWZevDf;

		// Token: 0x0404EEE4 RID: 323300 RVA: 0x00147760 File Offset: 0x00145960
		static readonly int gnDefvNlxc;

		// Token: 0x0404EEE5 RID: 323301 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int p7ebRkpsdu;

		// Token: 0x0404EEE6 RID: 323302 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int HmIzaEkBxR;

		// Token: 0x0404EEE7 RID: 323303 RVA: 0x00147768 File Offset: 0x00145968
		static readonly int DiT1A2gAlC;

		// Token: 0x0404EEE8 RID: 323304 RVA: 0x00147770 File Offset: 0x00145970
		static readonly int A58FQZl2yw;

		// Token: 0x0404EEE9 RID: 323305 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int uvSTX4fODa;

		// Token: 0x0404EEEA RID: 323306 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int LMxfZHonbY;

		// Token: 0x0404EEEB RID: 323307 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int DpHatLnCiB;

		// Token: 0x0404EEEC RID: 323308 RVA: 0x00147778 File Offset: 0x00145978
		static readonly int drNBhRQ9dF;

		// Token: 0x0404EEED RID: 323309 RVA: 0x00147780 File Offset: 0x00145980
		static readonly int XR6L0yIdpI;

		// Token: 0x0404EEEE RID: 323310 RVA: 0x00147788 File Offset: 0x00145988
		static readonly int u7bZsEo1kL;

		// Token: 0x0404EEEF RID: 323311 RVA: 0x00147790 File Offset: 0x00145990
		static readonly int QcpC6e8w7H;

		// Token: 0x0404EEF0 RID: 323312 RVA: 0x00147798 File Offset: 0x00145998
		static readonly int 1oJVAwt5k4;

		// Token: 0x0404EEF1 RID: 323313 RVA: 0x001477A0 File Offset: 0x001459A0
		static readonly int DKWZQfQxSd;

		// Token: 0x0404EEF2 RID: 323314 RVA: 0x001477A8 File Offset: 0x001459A8
		static readonly int nZZRz5l3OW;

		// Token: 0x0404EEF3 RID: 323315 RVA: 0x001477B0 File Offset: 0x001459B0
		static readonly int 0VfiRFyFY6;

		// Token: 0x0404EEF4 RID: 323316 RVA: 0x001477B8 File Offset: 0x001459B8
		static readonly int VsRqIGFQva;

		// Token: 0x0404EEF5 RID: 323317 RVA: 0x001477C0 File Offset: 0x001459C0
		static readonly int NLdeecP2gF;

		// Token: 0x0404EEF6 RID: 323318 RVA: 0x001477C8 File Offset: 0x001459C8
		static readonly int KzrNEsoyHL;

		// Token: 0x0404EEF7 RID: 323319 RVA: 0x001477D0 File Offset: 0x001459D0
		static readonly int rKYWH4HtJt;

		// Token: 0x0404EEF8 RID: 323320 RVA: 0x001477D8 File Offset: 0x001459D8
		static readonly int 0VIxIo1ADz;

		// Token: 0x0404EEF9 RID: 323321 RVA: 0x001477E0 File Offset: 0x001459E0
		static readonly int 06iTvgBDla;

		// Token: 0x0404EEFA RID: 323322 RVA: 0x001477E8 File Offset: 0x001459E8
		static readonly int bQIktCwHXj;

		// Token: 0x0404EEFB RID: 323323 RVA: 0x001477F0 File Offset: 0x001459F0
		static readonly int UgsxPyq3EZ;

		// Token: 0x0404EEFC RID: 323324 RVA: 0x001477F8 File Offset: 0x001459F8
		static readonly int 0nuSVvlFkl;

		// Token: 0x0404EEFD RID: 323325 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int 3EHtRjNiEF;

		// Token: 0x0404EEFE RID: 323326 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 2tnefTNvE7;

		// Token: 0x0404EEFF RID: 323327 RVA: 0x00147800 File Offset: 0x00145A00
		static readonly int zH8MjxfzP7;

		// Token: 0x0404EF00 RID: 323328 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int brgwpPY9fp;

		// Token: 0x0404EF01 RID: 323329 RVA: 0x00147808 File Offset: 0x00145A08
		static readonly int kIz9gGAQxB;

		// Token: 0x0404EF02 RID: 323330 RVA: 0x00147810 File Offset: 0x00145A10
		static readonly int i0AnvwF4Ke;

		// Token: 0x0404EF03 RID: 323331 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DYTHoKM1zP;

		// Token: 0x0404EF04 RID: 323332 RVA: 0x00147818 File Offset: 0x00145A18
		static readonly int 5OQYWrR9pc;

		// Token: 0x0404EF05 RID: 323333 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int xPCNYkq3B2;

		// Token: 0x0404EF06 RID: 323334 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KdzAmMzsUV;

		// Token: 0x0404EF07 RID: 323335 RVA: 0x00147820 File Offset: 0x00145A20
		static readonly int 4IbhFUkmQD;

		// Token: 0x0404EF08 RID: 323336 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int eGPrryVFsD;

		// Token: 0x0404EF09 RID: 323337 RVA: 0x00147828 File Offset: 0x00145A28
		static readonly int eT06FbZPwK;

		// Token: 0x0404EF0A RID: 323338 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 2joTioyeIE;

		// Token: 0x0404EF0B RID: 323339 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int AEn7XDOHTx;

		// Token: 0x0404EF0C RID: 323340 RVA: 0x00147830 File Offset: 0x00145A30
		static readonly int 0t9Q1kSeco;

		// Token: 0x0404EF0D RID: 323341 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 5U0FK5b5JC;

		// Token: 0x0404EF0E RID: 323342 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 917nDap3iB;

		// Token: 0x0404EF0F RID: 323343 RVA: 0x00147818 File Offset: 0x00145A18
		static readonly int MS58UIjYc7;

		// Token: 0x0404EF10 RID: 323344 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int WTBdJpOhwc;

		// Token: 0x0404EF11 RID: 323345 RVA: 0x00147828 File Offset: 0x00145A28
		static readonly int mT7Qy8wVNb;

		// Token: 0x0404EF12 RID: 323346 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 5Y6bbnZ1vC;

		// Token: 0x0404EF13 RID: 323347 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int VCdMqqzdeX;

		// Token: 0x0404EF14 RID: 323348 RVA: 0x00147838 File Offset: 0x00145A38
		static readonly int MHGGY3UoKV;

		// Token: 0x0404EF15 RID: 323349 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int WOLAC7WkCg;

		// Token: 0x0404EF16 RID: 323350 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int QWwuGjzvkH;

		// Token: 0x0404EF17 RID: 323351 RVA: 0x00147840 File Offset: 0x00145A40
		static readonly int JS1zPxS0Ch;

		// Token: 0x0404EF18 RID: 323352 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int SurapH1dKs;

		// Token: 0x0404EF19 RID: 323353 RVA: 0x00147848 File Offset: 0x00145A48
		static readonly int TPb7HzVW9z;

		// Token: 0x0404EF1A RID: 323354 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DjECMDWVuO;

		// Token: 0x0404EF1B RID: 323355 RVA: 0x00147850 File Offset: 0x00145A50
		static readonly int pgheOgpVE8;

		// Token: 0x0404EF1C RID: 323356 RVA: 0x00147840 File Offset: 0x00145A40
		static readonly int rWl2y313sa;

		// Token: 0x0404EF1D RID: 323357 RVA: 0x00147848 File Offset: 0x00145A48
		static readonly int b61NdtqoOm;

		// Token: 0x0404EF1E RID: 323358 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int vgs5Dwr7tk;

		// Token: 0x0404EF1F RID: 323359 RVA: 0x00147858 File Offset: 0x00145A58
		static readonly int JARAHr8LOS;

		// Token: 0x0404EF20 RID: 323360 RVA: 0x00147860 File Offset: 0x00145A60
		static readonly int MdnUxspUAe;

		// Token: 0x0404EF21 RID: 323361 RVA: 0x00147868 File Offset: 0x00145A68
		static readonly int 0BHcNLoqyB;

		// Token: 0x0404EF22 RID: 323362 RVA: 0x00147870 File Offset: 0x00145A70
		static readonly int M4JHQbo0Gw;

		// Token: 0x0404EF23 RID: 323363 RVA: 0x00147878 File Offset: 0x00145A78
		static readonly int uea6aR3XHU;

		// Token: 0x0404EF24 RID: 323364 RVA: 0x00147880 File Offset: 0x00145A80
		static readonly int HX6PuI2yw5;

		// Token: 0x0404EF25 RID: 323365 RVA: 0x00147888 File Offset: 0x00145A88
		static readonly int CSWMFRUfEW;

		// Token: 0x0404EF26 RID: 323366 RVA: 0x00147890 File Offset: 0x00145A90
		static readonly int EyNNtWkLC6;

		// Token: 0x0404EF27 RID: 323367 RVA: 0x00147898 File Offset: 0x00145A98
		static readonly int SRie4z74XH;

		// Token: 0x0404EF28 RID: 323368 RVA: 0x001478A0 File Offset: 0x00145AA0
		static readonly int i0DKtcHN0I;

		// Token: 0x0404EF29 RID: 323369 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 7XSvQSJsfY;

		// Token: 0x0404EF2A RID: 323370 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int irv0nvt2SQ;

		// Token: 0x0404EF2B RID: 323371 RVA: 0x001478A8 File Offset: 0x00145AA8
		static readonly int TZI7xNvDdR;

		// Token: 0x0404EF2C RID: 323372 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int OWU4849xOl;

		// Token: 0x0404EF2D RID: 323373 RVA: 0x001478B0 File Offset: 0x00145AB0
		static readonly int pOZ8j1ENh8;

		// Token: 0x0404EF2E RID: 323374 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int tO5jyhPU7C;

		// Token: 0x0404EF2F RID: 323375 RVA: 0x001478B8 File Offset: 0x00145AB8
		static readonly int hGPOJLW11t;

		// Token: 0x0404EF30 RID: 323376 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int v6oqlFAJY6;

		// Token: 0x0404EF31 RID: 323377 RVA: 0x001478C0 File Offset: 0x00145AC0
		static readonly int Jifeh9bvFb;

		// Token: 0x0404EF32 RID: 323378 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int oozLEj9LyY;

		// Token: 0x0404EF33 RID: 323379 RVA: 0x001478C8 File Offset: 0x00145AC8
		static readonly int eMVyNxkO8t;

		// Token: 0x0404EF34 RID: 323380 RVA: 0x001478D0 File Offset: 0x00145AD0
		static readonly int gF6B38kuqK;

		// Token: 0x0404EF35 RID: 323381 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int tlwaEGGcmC;

		// Token: 0x0404EF36 RID: 323382 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int FzVAc6MrRt;

		// Token: 0x0404EF37 RID: 323383 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int YMwW4jsySF;

		// Token: 0x0404EF38 RID: 323384 RVA: 0x001478C0 File Offset: 0x00145AC0
		static readonly int 8Peoo2a4tG;

		// Token: 0x0404EF39 RID: 323385 RVA: 0x001478D8 File Offset: 0x00145AD8
		static readonly int qIm6oru6j6;

		// Token: 0x0404EF3A RID: 323386 RVA: 0x001478E0 File Offset: 0x00145AE0
		static readonly int v2c6vgyafe;

		// Token: 0x0404EF3B RID: 323387 RVA: 0x001478E8 File Offset: 0x00145AE8
		static readonly int YSJgDzVqVj;

		// Token: 0x0404EF3C RID: 323388 RVA: 0x001478F0 File Offset: 0x00145AF0
		static readonly int gS8LDQk0rN;

		// Token: 0x0404EF3D RID: 323389 RVA: 0x001478F8 File Offset: 0x00145AF8
		static readonly int ywOWTFxh3I;

		// Token: 0x0404EF3E RID: 323390 RVA: 0x00147900 File Offset: 0x00145B00
		static readonly int DAYOsY8F2y;

		// Token: 0x0404EF3F RID: 323391 RVA: 0x00147908 File Offset: 0x00145B08
		static readonly int VDk9Zd4R3e;

		// Token: 0x0404EF40 RID: 323392 RVA: 0x00147910 File Offset: 0x00145B10
		static readonly int 58sSplDxN7;

		// Token: 0x0404EF41 RID: 323393 RVA: 0x00147918 File Offset: 0x00145B18
		static readonly int CxxNfg3tco;

		// Token: 0x0404EF42 RID: 323394 RVA: 0x00147920 File Offset: 0x00145B20
		static readonly int Rf821vLP6z;

		// Token: 0x0404EF43 RID: 323395 RVA: 0x00147928 File Offset: 0x00145B28
		static readonly int LfoYMFRGiG;

		// Token: 0x0404EF44 RID: 323396 RVA: 0x00147930 File Offset: 0x00145B30
		static readonly int UL14whQXd3;

		// Token: 0x0404EF45 RID: 323397 RVA: 0x00147938 File Offset: 0x00145B38
		static readonly int kLyONZAza4;

		// Token: 0x0404EF46 RID: 323398 RVA: 0x00147940 File Offset: 0x00145B40
		static readonly int ay0XwgJYAa;

		// Token: 0x0404EF47 RID: 323399 RVA: 0x00147948 File Offset: 0x00145B48
		static readonly int OwKWUFoDGT;

		// Token: 0x0404EF48 RID: 323400 RVA: 0x00147950 File Offset: 0x00145B50
		static readonly int eywDP9rZLw;

		// Token: 0x0404EF49 RID: 323401 RVA: 0x00147958 File Offset: 0x00145B58
		static readonly int FcpoqgUeHP;

		// Token: 0x0404EF4A RID: 323402 RVA: 0x00147960 File Offset: 0x00145B60
		static readonly int Y2WDoyBb4H;

		// Token: 0x0404EF4B RID: 323403 RVA: 0x00147968 File Offset: 0x00145B68
		static readonly int v6sGZlCxHx;

		// Token: 0x0404EF4C RID: 323404 RVA: 0x00147970 File Offset: 0x00145B70
		static readonly int zuNOUvGfqx;

		// Token: 0x0404EF4D RID: 323405 RVA: 0x00147978 File Offset: 0x00145B78
		static readonly int uJ505mcsYb;

		// Token: 0x0404EF4E RID: 323406 RVA: 0x00147980 File Offset: 0x00145B80
		static readonly int 8PeDBJtiOE;

		// Token: 0x0404EF4F RID: 323407 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ehWUanoIs3;

		// Token: 0x0404EF50 RID: 323408 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int rfvHWlA2Lx;

		// Token: 0x0404EF51 RID: 323409 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int JTYqyjQJML;

		// Token: 0x0404EF52 RID: 323410 RVA: 0x00147988 File Offset: 0x00145B88
		static readonly int CiRmSMxlaR;

		// Token: 0x0404EF53 RID: 323411 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7UAfuceWrZ;

		// Token: 0x0404EF54 RID: 323412 RVA: 0x00147990 File Offset: 0x00145B90
		static readonly int I1Xb4LJpf0;

		// Token: 0x0404EF55 RID: 323413 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Xf5g0JNIyJ;

		// Token: 0x0404EF56 RID: 323414 RVA: 0x00147998 File Offset: 0x00145B98
		static readonly int yZb3zzS36V;

		// Token: 0x0404EF57 RID: 323415 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int F3cxDKK0rH;

		// Token: 0x0404EF58 RID: 323416 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DHFk4cYdol;

		// Token: 0x0404EF59 RID: 323417 RVA: 0x001479A0 File Offset: 0x00145BA0
		static readonly int OVihksZdlF;

		// Token: 0x0404EF5A RID: 323418 RVA: 0x001479A8 File Offset: 0x00145BA8
		static readonly int 2QtJueCHdq;

		// Token: 0x0404EF5B RID: 323419 RVA: 0x001479B0 File Offset: 0x00145BB0
		static readonly int 8XbrGrU19W;

		// Token: 0x0404EF5C RID: 323420 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ayOVHuU4MV;

		// Token: 0x0404EF5D RID: 323421 RVA: 0x00147998 File Offset: 0x00145B98
		static readonly int uqOmOxX5za;

		// Token: 0x0404EF5E RID: 323422 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int aRA8m141b3;

		// Token: 0x0404EF5F RID: 323423 RVA: 0x001479B8 File Offset: 0x00145BB8
		static readonly int XiePoDBYCA;

		// Token: 0x0404EF60 RID: 323424 RVA: 0x001479C0 File Offset: 0x00145BC0
		static readonly int JI5H5RJycS;

		// Token: 0x0404EF61 RID: 323425 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int TZCi6JyQsP;

		// Token: 0x0404EF62 RID: 323426 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 0ddS7ML98K;

		// Token: 0x0404EF63 RID: 323427 RVA: 0x001479C8 File Offset: 0x00145BC8
		static readonly int v92yRSV2DU;

		// Token: 0x0404EF64 RID: 323428 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int sFYIk8f6Sf;

		// Token: 0x0404EF65 RID: 323429 RVA: 0x001479D0 File Offset: 0x00145BD0
		static readonly int PvpwKpomKs;

		// Token: 0x0404EF66 RID: 323430 RVA: 0x001479D8 File Offset: 0x00145BD8
		static readonly int FJ0RhTgNRo;

		// Token: 0x0404EF67 RID: 323431 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int x5NXhuEUs8;

		// Token: 0x0404EF68 RID: 323432 RVA: 0x001479E0 File Offset: 0x00145BE0
		static readonly int qPqc4AUFol;

		// Token: 0x0404EF69 RID: 323433 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ntsUOiPHlQ;

		// Token: 0x0404EF6A RID: 323434 RVA: 0x001479E8 File Offset: 0x00145BE8
		static readonly int cSoorUiRPa;

		// Token: 0x0404EF6B RID: 323435 RVA: 0x001479E0 File Offset: 0x00145BE0
		static readonly int lU4MC0cXWh;

		// Token: 0x0404EF6C RID: 323436 RVA: 0x001479F0 File Offset: 0x00145BF0
		static readonly int 9ajqBEN2I9;

		// Token: 0x0404EF6D RID: 323437 RVA: 0x001479F8 File Offset: 0x00145BF8
		static readonly int e7sbgYkCvk;

		// Token: 0x0404EF6E RID: 323438 RVA: 0x00147A00 File Offset: 0x00145C00
		static readonly int bC0NASzgSY;

		// Token: 0x0404EF6F RID: 323439 RVA: 0x00147A08 File Offset: 0x00145C08
		static readonly int F2uDRBs8mn;

		// Token: 0x0404EF70 RID: 323440 RVA: 0x00147A10 File Offset: 0x00145C10
		static readonly int GpIP5nlcpn;

		// Token: 0x0404EF71 RID: 323441 RVA: 0x00147A18 File Offset: 0x00145C18
		static readonly int PalwF6jWqt;

		// Token: 0x0404EF72 RID: 323442 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int Prku3mNoKe;

		// Token: 0x0404EF73 RID: 323443 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int pmaIdw3kSW;

		// Token: 0x0404EF74 RID: 323444 RVA: 0x00147A20 File Offset: 0x00145C20
		static readonly int qX0oIpQ78U;

		// Token: 0x0404EF75 RID: 323445 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bWS3XZEYWT;

		// Token: 0x0404EF76 RID: 323446 RVA: 0x00147A28 File Offset: 0x00145C28
		static readonly int a6RL7n9dST;

		// Token: 0x0404EF77 RID: 323447 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int C9ETC216lO;

		// Token: 0x0404EF78 RID: 323448 RVA: 0x00147A30 File Offset: 0x00145C30
		static readonly int WPqzCTUguE;

		// Token: 0x0404EF79 RID: 323449 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int rfO86tFoqf;

		// Token: 0x0404EF7A RID: 323450 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int pwooRcS81f;

		// Token: 0x0404EF7B RID: 323451 RVA: 0x00147A38 File Offset: 0x00145C38
		static readonly int iIxH6KQbIo;

		// Token: 0x0404EF7C RID: 323452 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int TdsOmhuFXS;

		// Token: 0x0404EF7D RID: 323453 RVA: 0x00147A28 File Offset: 0x00145C28
		static readonly int wMQFijkChj;

		// Token: 0x0404EF7E RID: 323454 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int BVpPfisGBv;

		// Token: 0x0404EF7F RID: 323455 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int dogCMMDaBu;

		// Token: 0x0404EF80 RID: 323456 RVA: 0x00147A38 File Offset: 0x00145C38
		static readonly int rNkisW2riX;

		// Token: 0x0404EF81 RID: 323457 RVA: 0x00147A40 File Offset: 0x00145C40
		static readonly int jN3im7xdsD;

		// Token: 0x0404EF82 RID: 323458 RVA: 0x00147A48 File Offset: 0x00145C48
		static readonly int zoDmyIqO3W;

		// Token: 0x0404EF83 RID: 323459 RVA: 0x00147A50 File Offset: 0x00145C50
		static readonly int fKAx1yvGhJ;

		// Token: 0x0404EF84 RID: 323460 RVA: 0x00147A58 File Offset: 0x00145C58
		static readonly int qAhoMQu7ZO;

		// Token: 0x0404EF85 RID: 323461 RVA: 0x00147A60 File Offset: 0x00145C60
		static readonly int Ykr84DJ8uj;

		// Token: 0x0404EF86 RID: 323462 RVA: 0x00147A68 File Offset: 0x00145C68
		static readonly int poxM1YNFry;

		// Token: 0x0404EF87 RID: 323463 RVA: 0x00147A70 File Offset: 0x00145C70
		static readonly int Mq5jXyHYai;

		// Token: 0x0404EF88 RID: 323464 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Xtyp84dC2y;

		// Token: 0x0404EF89 RID: 323465 RVA: 0x00147A78 File Offset: 0x00145C78
		static readonly int oxW7dCNVxx;

		// Token: 0x0404EF8A RID: 323466 RVA: 0x00147A80 File Offset: 0x00145C80
		static readonly int CoQkCrpIkG;

		// Token: 0x0404EF8B RID: 323467 RVA: 0x00147A88 File Offset: 0x00145C88
		static readonly int 6vhML6zIN6;

		// Token: 0x0404EF8C RID: 323468 RVA: 0x00147A90 File Offset: 0x00145C90
		static readonly int 5LM2JYU8FV;

		// Token: 0x0404EF8D RID: 323469 RVA: 0x00147A98 File Offset: 0x00145C98
		static readonly int lvlmftdNmQ;

		// Token: 0x0404EF8E RID: 323470 RVA: 0x00147AA0 File Offset: 0x00145CA0
		static readonly int PUbw13PKvh;

		// Token: 0x0404EF8F RID: 323471 RVA: 0x00147AA8 File Offset: 0x00145CA8
		static readonly int MFH011bXan;

		// Token: 0x0404EF90 RID: 323472 RVA: 0x00147AB0 File Offset: 0x00145CB0
		static readonly int XqDPeKK5qc;
	}
}
