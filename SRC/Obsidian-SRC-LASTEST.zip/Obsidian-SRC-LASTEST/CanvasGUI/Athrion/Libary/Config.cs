﻿using System;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace Athrion.Libary
{
	// Token: 0x02000006 RID: 6
	public class Config
	{
		// Token: 0x1700000C RID: 12
		// (get) Token: 0x0600002C RID: 44 RVA: 0x00239CB8 File Offset: 0x00237EB8
		// (set) Token: 0x0600002D RID: 45 RVA: 0x00239EEC File Offset: 0x002380EC
		public unsafe Vector3 PointerScale
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.HxNZeVMqK6) ^ *(&Config.HxNZeVMqK6)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = num2 % num;
					int num3;
					int num4;
					if (num2 > num2)
					{
						if (num3 > num3)
						{
							num = 878288653;
							num = -num3;
							num2 = -num;
							num = num2;
							num = num2 * 521;
							num = num4;
							num = num3;
							num2 = num4 + num2;
						}
					}
					num <<= 2;
					num &= num2;
					num3 = array[num4 + 9 - num4] + 5;
					num = (num4 ^ 1577326165);
					num2 = (num | 540227622);
					num3 = (array[num3 + 9 - num] ^ -8);
					num2 = *(ref num + (IntPtr)num2);
					num = num;
					num3 <<= 3;
					num3 = (int)((short)num2);
					if (num > num)
					{
						num3 = (num4 & num2);
						num4 = (num2 ^ 834089523);
						num3 = Config.T7p7bFhSnA;
						num4 = (int)((short)num3);
						num2 = (num4 & 1081423818);
						num4 = num3 + num2;
						num3 /= 646;
					}
					num4 = -num3;
					num4 = num >> 4;
					Config.T7p7bFhSnA = num3;
					num2 = num / 519;
					num = num2 / num;
					num -= 951;
					num = (num3 | 1354813829);
					num2 -= 761;
					Config.T7p7bFhSnA = num2;
					num4 = (num3 & num2);
				}
				return this.<PointerScale>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.KvSsOsAW6B) ^ *(&Config.KvSsOsAW6B)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num3;
					int num = num2 | num3;
					array[num3 + 5 - num2] = (num3 | 7);
					num3 = Config.T7p7bFhSnA;
					int num4;
					if (num3 > num3)
					{
						num4 = num3 % 299;
						*(ref num3 + (IntPtr)num) = num;
					}
					num3 = num4 / 693;
					num2 = num % num3;
					num = num3 + num;
					num4 = (array2[num3 + 9 - num3] ^ 8);
					num = num2 % num3;
					num2 = num3;
					num4 = -num2;
					num2 = num4 / 488;
					num4 = ~num3;
					Config.T7p7bFhSnA = num;
					num3 *= 125;
					num = (int)((short)num2);
					if (num3 > num3)
					{
						num4 = num2 + 178;
						num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
						num %= 854;
						if (num2 > num2)
						{
							num |= 1861299592;
							num2 = -num;
							num2 = num2;
							num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
						}
						num2 = (num | num3);
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
						num2 = num4;
						num3 = (int)((byte)num2);
					}
					num3 = -num;
					num4 = ~num3;
					num3 &= 402631058;
					num3 = num2 + num3;
					num = num3;
					num3 = (num | num3);
					num2 = (int)((ushort)num);
				}
				this.<PointerScale>k__BackingField = value;
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600002E RID: 46 RVA: 0x0023A128 File Offset: 0x00238328
		// (set) Token: 0x0600002F RID: 47 RVA: 0x0023A394 File Offset: 0x00238594
		public unsafe Color32 PointerColorStart
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.p4qrh9FJv6) ^ *(&Config.p4qrh9FJv6)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2 << 7;
					int num3;
					int num4;
					int num5;
					if (num2 > num2)
					{
						num2 = Config.T7p7bFhSnA;
						if (num3 > num3)
						{
							num = num4 + 553;
							num3 = *(ref num2 + (IntPtr)num5);
							num = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
							num4 = (num2 | num5);
							num2 = -num5;
						}
						if (num2 > num2)
						{
							num = ~num5;
							array[num4 + 5 - num5] = (num2 | -6);
							array[num5 + 8 - num3] = (num3 | 1);
							num = (num2 & 877152608);
						}
						num4 = (array[num2 + 8 - num4] ^ 9);
						num3 = ~num4;
						*(ref Config.T7p7bFhSnA + (IntPtr)num5) = num5;
						num4 = Config.T7p7bFhSnA;
						num4 = num5 / num3;
					}
					num4 = num2 / num5;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num3 /= 246;
					num3 = (num4 ^ num5);
					num2 = num5;
					num3 = -num;
					array2[num + 6 - num3] = num2 - 1;
					num2 = num * 687;
					num3 = num5 + 529;
					num5 = 1374045064;
					num3 = num;
					num4 = num3 + 245;
					num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					num3 = num4 * num5;
					num5 -= num3;
					num3 = num5 << 2;
					num5 = Config.T7p7bFhSnA;
					num2 = -num4;
					num2 ^= num5;
				}
				return this.<PointerColorStart>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.w7TvUrPYPD) ^ *(&Config.w7TvUrPYPD)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = num2 + num;
					num2 = Config.T7p7bFhSnA;
					int num3 = -num2;
					num = -num3;
					num3 /= num;
					int num4;
					num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
					*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					num3 = *(ref num + (IntPtr)num3);
					if (num4 > num4)
					{
						num = ~num;
						num3 = 188058979;
						num4 = (num3 | num);
						num2 = (array[num + 8 - num] ^ -7);
						array[num2 + 8 - num3] = num3 - -9;
						num3 = (array[num + 8 - num2] ^ 9);
					}
					if (num4 > num4)
					{
						*(ref num + (IntPtr)num3) = num3;
						num = num2 + num;
						num = num4 * 983;
						array[num3 + 6 - num4] = num4 - -6;
						num2 = num4 / 39;
					}
					*(ref num2 + (IntPtr)num) = num;
					num2 = ~num3;
					num2 = num4 * num;
					array[num + 8 - num2] = (num3 | -8);
					num += 106;
					num3 = ~num;
					num2 = num3 * 937;
					num4 -= num;
					*(ref num4 + (IntPtr)num) = num;
					num3 = num2;
					num3 = ~num;
					num2 = (int)((sbyte)num4);
					num -= 420;
					*(ref num3 + (IntPtr)num) = num;
					num = num4 / 482;
					num2 = num4 / 260;
					num = num;
					num3 <<= 1;
					num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					num2 = num4 * 701;
					num2 = num + num3;
					num3 = (num | 257671303);
					num3 = num4 * 102;
					num2 = array[num3 + 5 - num2] + 0;
					num4 = num2;
					if (num2 > num2)
					{
						num2 = (num & num3);
						num2 = -num2;
						if (num > num)
						{
							num3 = -num4;
							num2 = -num4;
							num2 = 1579431228;
							num2 = num4 / 392;
							num3 = -num3;
							num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
							num = ~num3;
						}
						*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					}
				}
				this.<PointerColorStart>k__BackingField = value;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000030 RID: 48 RVA: 0x0023A720 File Offset: 0x00238920
		// (set) Token: 0x06000031 RID: 49 RVA: 0x0023ABB8 File Offset: 0x00238DB8
		public unsafe Color32 PointerColorEnd
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.MT8pyVefLv) ^ *(&Config.MT8pyVefLv)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = -num2;
					int num3;
					num = (array[num3 + 7 - num2] ^ -2);
					if (num > num)
					{
						num = (num3 | 491596708);
						*(ref num3 + (IntPtr)num) = num;
						num2 = *(ref num2 + (IntPtr)num);
						num2 = Config.T7p7bFhSnA;
						if (num2 > num2)
						{
							num2 = (int)((ushort)num2);
						}
					}
					num2 = ~num3;
					num = num2;
					if (num2 > num2)
					{
						num3 = num % num2;
						num3 %= num;
						if (num > num)
						{
							num = (int)((byte)num);
							num = num2 % 358;
						}
						num2 = (num ^ 1711552648);
						if (num > num)
						{
							num2 /= num;
							num = num3 % num;
							array2[num + 8 - num] = num3 - -5;
							*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
							Config.T7p7bFhSnA = num2;
							num3 = ~num;
							num3 *= num;
							num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
							num3 = (int)((byte)num2);
							array[num + 9 - num] = num - -4;
						}
						num2 = num3 % num;
					}
					num3 = num2;
					if (num3 > num3)
					{
						Config.T7p7bFhSnA = num;
						num = (num2 & 1213115560);
						num2 = (num3 & num);
						if (num2 > num2)
						{
							num2 = (num3 | 437033877);
							array[num + 8 - num2] = (num3 | 2);
							num3 = (int)((short)num);
							num &= num2;
						}
						num2 -= 988;
					}
					num = num2;
					num2 -= 543;
					if (num2 > num2)
					{
						num = array2[num + 8 - num3] + -10;
					}
					num2 = num3 - 285;
					num3 = ~num3;
					num = (array[num + 7 - num2] ^ -1);
					num2 = num2;
					if (num3 > num3)
					{
						num2 = 248784873;
						num = 1780227343;
						num = (array[num2 + 5 - num3] ^ 6);
						*(ref num + (IntPtr)num2) = num2;
						num3 = 4663280;
						num2 = num * 168;
					}
					Config.T7p7bFhSnA = num2;
					num3 = num % 767;
					*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					num3 = num2 - num;
					num &= num2;
					num2 = (int)((short)num);
					num = num3 % 212;
					num = (array2[num + 7 - num2] ^ -1);
					num = ~num3;
					num2 = (array[num3 + 5 - num3] ^ 4);
					num2 = (array[num3 + 7 - num2] ^ 0);
					num2 -= num;
					num3 = (int)((ushort)num3);
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
					num += 154;
					num &= num2;
					num = (num3 ^ num);
					num2 = num % 803;
				}
				return this.<PointerColorEnd>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.UztIRZQ8ab) ^ *(&Config.UztIRZQ8ab)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					array[num + 8 - num2] = (num | -2);
					int num3 = num2 | num;
					num2 &= 1863261773;
					if (num3 > num3)
					{
						num2 = (num & num2);
						num2 = num3 / 944;
						*(ref num2 + (IntPtr)num) = num;
						num3 = num * 228;
						num = num3 % num2;
						num = num3 % num2;
					}
					num3 = num2 - num;
					if (num > num)
					{
						num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
						if (num > num)
						{
							array[num3 + 6 - num3] = num - -5;
							num2 &= 856744914;
							num = -num2;
							num2 = num;
						}
						num = (int)((ushort)num);
						if (num > num)
						{
							num2 = (int)((sbyte)num2);
						}
						if (num2 > num2)
						{
							num2 &= 683992514;
							num2 = num3 - num2;
							num3 = num / num2;
							num = array[num + 5 - num2] + -6;
							num2 = num3 % 405;
							num = (int)((byte)num);
							num = (num3 ^ 719833709);
							num = ~num3;
						}
						num3 = num / num2;
						num3 = num3;
						num2 = num3 >> 1;
						num2 = num3 + num2;
						num2 &= 814500428;
					}
					*(ref num2 + (IntPtr)num) = num;
					num = num3 * 680;
					if (num2 > num2)
					{
						if (num2 > num2)
						{
						}
						num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
						num = (array[num2 + 6 - num] ^ 5);
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
						num = num3 % 298;
						num = *(ref num + (IntPtr)num2);
						num2 = num3;
						num = Config.T7p7bFhSnA;
					}
					if (num3 > num3)
					{
						num = num3 % 195;
						num3 = num2;
					}
					num3 = ~num3;
					num = num3 / 334;
					num3 = Config.T7p7bFhSnA;
					if (num > num)
					{
						num = num2 / num;
						if (num > num)
						{
							num = (num2 ^ num);
						}
						if (num3 > num3)
						{
							num3 = *(ref num + (IntPtr)num2);
							num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
							num2 %= num;
							num3 = Config.T7p7bFhSnA;
							num3 = (array[num + 8 - num] ^ -6);
							num2 = ~num2;
						}
						num3 = -num3;
						num2 = Config.T7p7bFhSnA;
						num2 = num - 245;
						array[num3 + 9 - num2] = num - -3;
						num3 = *(ref num2 + (IntPtr)num);
						num2 = num2;
					}
					num3 = num / num2;
					num3 = (num2 ^ num);
					if (num > num)
					{
						num2 = num3;
						array[num + 6 - num3] = num3 - -7;
						num = Config.T7p7bFhSnA;
						num2 |= num;
					}
					num2 = (num3 ^ num2);
					num3 = num + num2;
					if (num2 > num2)
					{
						array[num2 + 9 - num] = (num | -3);
						num2 = ~num;
						num3 |= 785058830;
						num = ~num;
						num2 &= 1691815809;
						num = array[num2 + 5 - num3] + 4;
						*(ref num + (IntPtr)num2) = num2;
						num2 = ~num3;
						num = *(ref num2 + (IntPtr)num);
					}
					num3 = -num;
					num = -num2;
					*(ref num2 + (IntPtr)num) = num;
					array[num2 + 5 - num2] = (num2 | -10);
				}
				this.<PointerColorEnd>k__BackingField = value;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000032 RID: 50 RVA: 0x0023B138 File Offset: 0x00239338
		// (set) Token: 0x06000033 RID: 51 RVA: 0x0023B60C File Offset: 0x0023980C
		public unsafe Color32 TriggeredPointerColorStart
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.9YgrONchXh) ^ *(&Config.9YgrONchXh)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = array[num2 + 7 - num3] ^ 5;
					int num4 = num3;
					num2 |= 1203251065;
					num2 = -num;
					num4 = (num3 & 158205399);
					num4 = num2 / num3;
					if (num4 > num4)
					{
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
						if (num2 > num2)
						{
							*(ref num2 + (IntPtr)num3) = num3;
						}
						num4 = -num4;
						if (num > num)
						{
							num = num3;
							num = num3 / num;
							num = num2 - num3;
						}
						num = num4 >> 6;
						num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
						num2 = (num & 804958898);
					}
					num2 = Config.T7p7bFhSnA;
					num ^= num3;
					if (num2 > num2)
					{
						num4 = (array[num3 + 5 - num2] ^ 5);
						num = -num2;
						num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
						if (num4 > num4)
						{
							num4 |= num3;
						}
						if (num4 > num4)
						{
							num = 1874788507;
							num4 = (num ^ 1347666284);
							num = Config.T7p7bFhSnA;
							num4 = num2 + 871;
							num2 = (int)((ushort)num3);
							num4 = -num2;
							num4 = (num3 | 1411681938);
							num3 = num4 * 8;
						}
						num4 = num3;
						num2 = (int)((byte)num4);
					}
					num4 = ~num3;
					if (num > num)
					{
						num2 = num / 568;
						num3 = num2;
						num3 *= 655;
						num4 = (num3 ^ num);
						num2 = (num3 & 1378853266);
					}
					num = num3 - 917;
					num2 = num - 969;
					num2 = (num3 | num);
					num2 = num >> 4;
					num2 = num3;
					num3 |= 1654863638;
					num3 = (num ^ 212142520);
					*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
					if (num2 > num2)
					{
						num3 = num;
						num = num4 - num3;
						num = (num4 ^ 2143335704);
						num3 = (int)((sbyte)num2);
					}
					num2 |= 670558949;
					num3 >>= 5;
					num2 = (num4 & num3);
					num2 = num >> 4;
					num = ~num4;
					num3 = num2;
					num4 += 906;
					num = num4 >> 4;
					if (num3 > num3)
					{
						num3 |= num;
						num4 = (num3 | 1752577650);
						*(ref num4 + (IntPtr)num3) = num3;
						num4 = num2 << 2;
						num4 = num >> 7;
						num3 = 842559668;
						num4 = num3;
						num2 = (num4 | 55363850);
						num |= num3;
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
					}
					num2 += num3;
					Config.T7p7bFhSnA = num;
					array[num + 7 - num2] = (num | 8);
					if (num > num)
					{
						num4 += num3;
					}
					num3 = -num4;
					num4 = num2;
					*(ref num2 + (IntPtr)num3) = num3;
					num2 = num3 / num;
					num3 = -num3;
					num2 = num3 + 316;
					num3 = num2 + 237;
				}
				return this.<TriggeredPointerColorStart>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.dmG3zV6B2L) ^ *(&Config.dmG3zV6B2L)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num = -num;
					int num2;
					int num3;
					num = (num2 ^ num3);
					int num4;
					array[num2 + 8 - num] = (num4 | -10);
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
					if (num3 > num3)
					{
						num3 = (int)((short)num3);
						if (num > num)
						{
							num3 = (int)((ushort)num4);
							num3 = (int)((byte)num4);
							num = num4 * num3;
							num2 = ~num4;
						}
						if (num2 > num2)
						{
							num = (int)((ushort)num2);
						}
					}
					num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
					num *= num3;
					num = num3 >> 5;
					num ^= num3;
					num4 = num3;
					if (num > num)
					{
						if (num2 > num2)
						{
							num = (num2 ^ 1199166488);
							num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
						}
						num4 &= 117434179;
						num2 = num3 * num4;
						*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
						if (num3 > num3)
						{
							num = 975736203;
							num2 = num3 % num4;
							num = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
							num4 = Config.T7p7bFhSnA;
							num2 = num3 * num4;
							num4 = num3 - 349;
						}
						num2 = Config.T7p7bFhSnA;
						num %= num3;
						num4 = num2 + num3;
						num = num4 / 165;
						num2 = num;
					}
					num3 = Config.T7p7bFhSnA;
					num3 = (array[num3 + 9 - num3] ^ -5);
					num2 = num % num3;
					if (num3 > num3)
					{
						num3 = (int)((byte)num3);
					}
					num3 = Config.T7p7bFhSnA;
					num4 |= num3;
					num = (num4 | num3);
					num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
					if (num2 > num2)
					{
						if (num > num)
						{
							num = Config.T7p7bFhSnA;
							num3 = num2 % 806;
							num2 = num >> 7;
							num -= num3;
							*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
							num2 = -num2;
							num = (int)((short)num4);
							num2 = num3;
						}
						array[num2 + 5 - num] = (num3 | 8);
						num4 = -num4;
						num = ~num4;
						if (num3 > num3)
						{
							num2 |= num3;
							num3 = (num | num3);
							num2 = array[num + 5 - num4] + 7;
							num3 = (num4 & num3);
							num2 = num / num3;
							array[num + 6 - num2] = num4 - -7;
						}
						num = num3 % 371;
						num4 ^= num3;
						num4 = num3 + num4;
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
					}
					array[num4 + 8 - num3] = num - 3;
					num3 = num + 407;
					num2 = num3 - num4;
				}
				this.<TriggeredPointerColorStart>k__BackingField = value;
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000034 RID: 52 RVA: 0x0023BA70 File Offset: 0x00239C70
		// (set) Token: 0x06000035 RID: 53 RVA: 0x0023C174 File Offset: 0x0023A374
		public unsafe Color32 TriggeredPointerColorEnd
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.ek79l6OKe5) ^ *(&Config.ek79l6OKe5)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2;
					int num4;
					int num3 = array2[num4 + 9 - num4] + 7;
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					if (num > num)
					{
						num = (array2[num4 + 5 - num3] ^ 9);
						num2 = array2[num4 + 5 - num3] + -5;
						num2 -= 410;
						if (num2 > num2)
						{
							num4 = -num;
							num3 = -num3;
							num = (num2 & num);
							num = num2;
							num2 = num4 >> 1;
							num2 = Config.T7p7bFhSnA;
							num4 = num3 << 5;
						}
						*(ref num4 + (IntPtr)num) = num;
						num3 = (num | num2);
						if (num > num)
						{
							*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
							num <<= 1;
						}
					}
					num = num3 * num;
					if (num > num)
					{
						array2[num2 + 6 - num4] = (num | 1);
						num4 = -num2;
						num2 = *(ref num2 + (IntPtr)num);
						num2 = num;
						if (num2 > num2)
						{
							num3 = ~num3;
						}
						num4 = -num3;
						num2 = ~num2;
					}
					num4 = Config.T7p7bFhSnA;
					num2 = num;
					num2 ^= 1254697522;
					num3 = *(ref num3 + (IntPtr)num);
					num3 = (num4 ^ num);
					num4 = num3 - num;
					num2 = num4 - num;
					num2 = (num4 | 856461665);
					if (num3 > num3)
					{
						num3 = (int)((ushort)num3);
						num3 = num4;
						num4 = (num2 & num);
						num3 = Config.T7p7bFhSnA;
					}
					num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
					Config.T7p7bFhSnA = num2;
					*(ref num2 + (IntPtr)num) = num;
					num4 = (num ^ num2);
					num = num4 * num;
					if (num3 > num3)
					{
						num = num2;
						num2 = 1582630899;
						if (num > num)
						{
							num = *(ref num + (IntPtr)num2);
						}
						array2[num + 5 - num4] = num - 9;
					}
					num3 |= num;
					num3 = num * num2;
					num2 *= 87;
					num4 = num3 / num;
					if (num2 > num2)
					{
						num3 = num4 % num;
						num3 = num % num2;
						num = ~num;
						num4 = (num3 ^ 1900720401);
						num4 = ~num3;
						num2 = num;
						*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					}
					if (num3 > num3)
					{
						if (num4 > num4)
						{
							num4 += num;
							Config.T7p7bFhSnA = num;
							num3 = (num4 ^ num);
							num3 = *(ref num + (IntPtr)num2);
							num = (array2[num3 + 8 - num2] ^ 1);
						}
						*(ref num + (IntPtr)num2) = num2;
						num4 = num4;
						num4 = 1504738446;
						num2 = num2;
						num2 = *(ref num2 + (IntPtr)num);
					}
					num3 = num2 * 748;
					num4 = num / 242;
					num = -num3;
					if (num2 > num2)
					{
						num2 = (num4 | num);
						if (num3 > num3)
						{
							array2[num2 + 9 - num] = num4 - 0;
							num3 = ~num4;
							array2[num3 + 7 - num4] = num2 - 6;
							num = (num4 | num);
							num = num2 % 932;
							num2 = 166002234;
							num3 = Config.T7p7bFhSnA;
							*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
						}
						*(ref num4 + (IntPtr)num) = num;
						num3 = num << 6;
						num2 = Config.T7p7bFhSnA;
						num2 -= num;
						num3 = num4 + num;
						num3 = ~num4;
					}
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					if (num3 > num3)
					{
						if (num3 > num3)
						{
							num2 = num3 << 7;
							num2 -= 429;
							num3 = -num3;
							num4 = (num3 & num);
							array[num + 8 - num] = (num | -8);
							num |= 1345350729;
						}
						num = (int)((sbyte)num2);
						if (num4 > num4)
						{
						}
						if (num > num)
						{
							num4 = -num;
							array2[num4 + 7 - num3] = (num4 | 4);
							num = (num2 | num);
							num3 = (int)((sbyte)num);
							num4 = -num4;
							num3 = num;
							array[num2 + 5 - num3] = (num3 | -5);
							Config.T7p7bFhSnA = num4;
							Config.T7p7bFhSnA = num;
						}
					}
					num3 = -num4;
					num4 = (int)((byte)num3);
					num2 <<= 3;
					num = ~num3;
				}
				return this.<TriggeredPointerColorEnd>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.aR7yEyxQak) ^ *(&Config.aR7yEyxQak)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					*(ref num + (IntPtr)num2) = num2;
					int num3 = -num3;
					int num4 = num3 & 1538467796;
					num = ~num4;
					num = num3 + 175;
					num2 = (int)((sbyte)num);
					num4 = num3;
					if (num4 > num4)
					{
						num2 %= 960;
						num = 1622120443;
						num2 -= num3;
						if (num3 > num3)
						{
							num3 -= num2;
							num = num2 << 6;
							num2 = (num3 ^ num2);
							num3 *= num2;
							num4 = num % 300;
							*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
							num3 = num - 481;
							num2 = 83950225;
							num = (num3 & 2052125356);
						}
						num3 = (num & 449286584);
						num4 = -num;
						*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
						num2 = ~num3;
						num = num2 + num3;
					}
					if (num3 > num3)
					{
						num4 = 1807862159;
					}
					num = -num4;
					num2 = (int)((sbyte)num);
					num4 = (num2 & 142737798);
					if (num3 > num3)
					{
						Config.T7p7bFhSnA = num;
						num3 = ~num3;
						num3 = num2;
					}
					num2 = num3 * 337;
					num4 = ~num2;
					num2 = num3;
					num2 ^= 1656396019;
					num = num4 + 920;
					num4 = -num2;
					array2[num3 + 9 - num3] = (num4 | -8);
					if (num > num)
					{
						num2 = 1186258364;
						num2 = -num2;
						if (num > num)
						{
							num2 = num;
							num3 = (array2[num3 + 5 - num] ^ -9);
							num3 = 675973223;
							num3 = num2 - 276;
						}
						num4 = (int)((short)num);
						num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
						num4 = (array2[num + 9 - num3] ^ -2);
						num4 = num;
						num2 = ~num3;
						array[num4 + 8 - num] = (num3 | 2);
						num2 = 379317475;
					}
					num3 = num4 * num2;
					num = num2 * 601;
					num4 = Config.T7p7bFhSnA;
					num4 = num2 - num3;
					if (num3 > num3)
					{
						array[num2 + 7 - num3] = (num | -1);
						num3 = (num | 1561797088);
						num4 = (num | 1757025495);
						num -= 139;
						num3 = num4 / num2;
						num4 = (num2 & 1743783145);
						num4 = (int)((short)num3);
					}
				}
				this.<TriggeredPointerColorEnd>k__BackingField = value;
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000036 RID: 54 RVA: 0x0023C558 File Offset: 0x0023A758
		// (set) Token: 0x06000037 RID: 55 RVA: 0x0023CB70 File Offset: 0x0023AD70
		public unsafe float LineWidth
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.27InSsszT5) ^ *(&Config.27InSsszT5)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					int num3;
					if (num > num)
					{
						num2 = num * num2;
						num3 <<= 4;
						if (num2 > num2)
						{
							num2 = num3 - 409;
						}
						num3 = (array2[num2 + 9 - num3] ^ 6);
						num = num2 / 413;
						num = num2 << 2;
						array[num + 6 - num2] = (num3 | 7);
						num2 = num << 4;
						num = (num3 | num2);
					}
					array[num + 7 - num2] = (num2 | -6);
					num2 = array2[num3 + 6 - num3] + -8;
					num3 += num2;
					if (num3 > num3)
					{
						if (num > num)
						{
							Config.T7p7bFhSnA = num2;
						}
						num3 ^= num2;
						num2 = (num ^ num2);
						num2 = (int)((byte)num3);
						num2 = 1036663745;
						num3 = num2 * 824;
						num = (num2 & num3);
						array[num + 9 - num] = num2 - -9;
						if (num2 > num2)
						{
							array[num + 9 - num3] = num2 - -10;
							Config.T7p7bFhSnA = num2;
							*(ref num2 + (IntPtr)num3) = num3;
							num3 = ~num3;
							num3 += 962;
						}
					}
					array2[num + 6 - num] = num - 2;
					array2[num3 + 6 - num] = (num3 | 9);
					num %= 457;
					if (num > num)
					{
						num3 = ~num3;
						num = (num3 & 261290361);
						array[num + 5 - num3] = (num3 | -1);
						num3 = ~num2;
						num = (int)((sbyte)num2);
						num2 <<= 6;
						num = num3 / 950;
						if (num2 > num2)
						{
							num3 = Config.T7p7bFhSnA;
							num3 = 1029372181;
							num2 = num >> 6;
							Config.T7p7bFhSnA = num;
							num2 = (int)((short)num3);
						}
						num2 = num3 % 638;
						if (num > num)
						{
							num3 = (int)((byte)num);
							num2 = num2;
							num ^= 2013207577;
							num = (num2 & 1229678786);
							array[num + 7 - num2] = num2 - -10;
						}
					}
					num2 = num;
					num = num2 / num3;
					if (num3 > num3)
					{
						num = (int)((byte)num);
						if (num3 > num3)
						{
							*(ref num + (IntPtr)num2) = num2;
							num3 -= 454;
							num = -num;
							num = Config.T7p7bFhSnA;
							num = num3 - num2;
							num3 = (array[num + 5 - num] ^ -7);
						}
					}
					if (num > num)
					{
						num3 = num % 17;
						num = num3 * 909;
						array[num + 8 - num] = (num2 | 2);
					}
					num2 = (int)((sbyte)num);
					num = Config.T7p7bFhSnA;
					num2 = num2;
					num2 = ~num;
					num2 = array2[num + 5 - num] + -9;
					num2 = num3;
					num3 = num % 518;
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					num2 = num3 % num2;
					num2 <<= 6;
					num = num2 * num3;
					if (num2 > num2)
					{
						num = num2 - 394;
						num2 = -num2;
						num2 += 163;
						num2 = num - 859;
						num2 = (int)((ushort)num2);
						array[num + 9 - num2] = (num | -6);
						num2 = num3 - 950;
						num2 += num3;
						num |= num2;
					}
					array[num + 9 - num3] = (num2 | 2);
					num = num2 << 6;
					num = ~num2;
					num2 >>= 6;
					num3 = num2;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num *= 53;
					num = num2;
				}
				return this.<LineWidth>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.cOFP7YagGS) ^ *(&Config.cOFP7YagGS)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					int num3;
					int num4;
					if (num > num)
					{
						if (num2 > num2)
						{
							num2 = num3 << 2;
							num4 = (int)((short)num2);
							num2 = (num4 ^ num2);
							num4 = num2 * 241;
							*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
							num3 = num2 >> 2;
						}
						if (num > num)
						{
							num &= num4;
							num3 = (int)((byte)num3);
							num = (int)((short)num3);
							num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
							num4 = (num3 | 1070037285);
							*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
						}
					}
					num2 = (int)((byte)num);
					num = ~num2;
					num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					array2[num + 8 - num3] = num4 - 0;
					if (num > num)
					{
						num = num2 / num4;
						num3 = num % num4;
						num4 %= num2;
						Config.T7p7bFhSnA = num;
						num += 682;
						num2 = num4;
						Config.T7p7bFhSnA = num3;
					}
					if (num2 > num2)
					{
						num2 = (num3 & 1990178338);
						num3 = 1741080529;
						num = (num4 ^ 1229184126);
						if (num2 > num2)
						{
							num3 = num4 / 943;
							num2 = (num4 & 1856120978);
							num4 = num4;
							num4 = ~num3;
							array2[num + 9 - num4] = (num3 | 7);
							num %= 898;
							num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
							num4 += num2;
							num3 = num2 - num4;
						}
						num = (int)((ushort)num);
						if (num3 > num3)
						{
							num3 = num4;
							num = (num4 & num2);
							num4 = num % 698;
						}
						*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
						num3 = (array[num4 + 9 - num] ^ -9);
						num4 = Config.T7p7bFhSnA;
					}
					*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					num2 = -num2;
					num = (num3 & num4);
					if (num3 > num3)
					{
						num2 = num3 - 61;
						num = num3 << 5;
					}
					num3 = (int)((byte)num2);
					num3 = num2 - num4;
					if (num2 > num2)
					{
						num = num4;
						num = num4 * num2;
						num2 = *(ref num + (IntPtr)num4);
						num3 = -num;
						num3 = ~num3;
						if (num > num)
						{
							num2 = -num4;
							num2 = (num3 | num4);
							num3 = num2;
							num4 |= 1535154574;
						}
						num4 = (num3 ^ num4);
					}
					num4 = (int)((ushort)num);
					num4 = num2;
					*(ref num2 + (IntPtr)num4) = num4;
					Config.T7p7bFhSnA = num4;
					num &= num4;
					num4 = -num2;
					num3 = num4;
					num2 = num4 % num2;
					num4 = num;
					num4 = num2 + num4;
					if (num3 > num3)
					{
						num4 ^= 1724096080;
						num = num3 * 594;
						num4 = (num3 & 1003158967);
					}
					num3 = -num;
					num2 = ~num;
					if (num2 > num2)
					{
						num4 *= num2;
						if (num3 > num3)
						{
							num4 = *(ref num2 + (IntPtr)num4);
							num2 = num3 - 500;
							num = 2066507981;
							num2 |= 524084356;
							num3 = num2 / 960;
						}
						if (num2 > num2)
						{
							array[num2 + 7 - num3] = num3 - -2;
						}
						*(ref num4 + (IntPtr)num2) = num2;
					}
					num3 = (array2[num4 + 6 - num2] ^ -8);
					*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
					num2 = num2;
					array[num3 + 9 - num3] = num2 - 8;
					num = (num4 ^ 1264551842);
					num = *(ref num2 + (IntPtr)num4);
				}
				this.<LineWidth>k__BackingField = value;
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000038 RID: 56 RVA: 0x0023D130 File Offset: 0x0023B330
		// (set) Token: 0x06000039 RID: 57 RVA: 0x0023D584 File Offset: 0x0023B784
		public unsafe Color32 LineColorStart
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.9SDbGLoSzB) ^ *(&Config.9SDbGLoSzB)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = *(ref num2 + (IntPtr)num);
					int num4;
					int num3 = (int)((short)num4);
					num4 = num2 >> 6;
					array[num2 + 6 - num3] = (num | 0);
					num3 |= num;
					int num5 = num4;
					num3 = num << 3;
					num = num4;
					if (num2 > num2)
					{
						num5 = num3 + num;
						num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
						num3 = num5 - num;
						num3 = (num & 1596184037);
						num4 = num / 86;
						num4 = (int)((ushort)num5);
					}
					*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
					num5 = num4 << 5;
					Config.T7p7bFhSnA = num2;
					num2 = (array[num + 6 - num3] ^ 4);
					num4 = (num5 ^ num);
					if (num5 > num5)
					{
						num2 = num3 % num;
						num3 = (int)((short)num3);
						num3 = num4 / 509;
						array[num4 + 6 - num] = (num | 3);
						if (num > num)
						{
							num5 = 1255514788;
							num = num4;
							*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
							*(ref num4 + (IntPtr)num) = num;
							Config.T7p7bFhSnA = num4;
							num2 = array2[num5 + 7 - num5] + 8;
							*(ref num4 + (IntPtr)num) = num;
							num = num4;
							num = num3 / 889;
						}
						num4 = num2 + 976;
						if (num5 > num5)
						{
							num3 = Config.T7p7bFhSnA;
						}
					}
					num2 = ~num5;
					if (num2 > num2)
					{
						num = (int)((short)num4);
						num2 = num / num4;
						if (num2 > num2)
						{
							num4 = num5;
						}
					}
					num2 = num;
					num5 = num * 96;
					Config.T7p7bFhSnA = num;
					if (num2 > num2)
					{
						num5 = num5;
						num3 = (num4 & 1818555643);
						num4 = (int)((byte)num3);
						if (num5 > num5)
						{
							num3 = num2 + num;
						}
						*(ref num5 + (IntPtr)num) = num;
						num2 = (array2[num5 + 7 - num] ^ 9);
						num3 = array[num + 8 - num3] + -6;
					}
					num5 = array2[num4 + 5 - num4] + 7;
					if (num2 > num2)
					{
						Config.T7p7bFhSnA = num5;
						if (num2 > num2)
						{
							num4 = num + num4;
							array2[num4 + 9 - num3] = (num4 | 9);
							num3 = (num2 & 1688233280);
						}
						num3 = num - num4;
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
						num = num5 * num;
						num4 = array2[num3 + 5 - num2] + -10;
					}
					if (num4 > num4)
					{
						num5 %= num;
					}
				}
				return this.<LineColorStart>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.iqkRShbTq2) ^ *(&Config.iqkRShbTq2)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					int num4;
					int num3;
					int num5;
					if (num > num)
					{
						if (num2 > num2)
						{
							num3 = num4 / 190;
							num2 = num3 + 3;
							num2 = (int)((byte)num4);
							num3 = num;
							num = 682670617;
							num2 = (num5 | num);
							num5 = num2 / num;
							num3 = num2 << 3;
							num2 = num;
						}
						num3 = Config.T7p7bFhSnA;
					}
					num5 ^= 97894341;
					num2 = num3;
					num3 = -num2;
					num4 = ~num2;
					num5 = num;
					num = *(ref num4 + (IntPtr)num);
					if (num4 > num4)
					{
						num5 = 2095887283;
						num5 = num << 3;
						num += num3;
						num2 &= num;
						num2 = ~num2;
						if (num5 > num5)
						{
							num4 = Config.T7p7bFhSnA;
							num5 = num * num3;
							array2[num + 6 - num4] = (num5 | 5);
						}
					}
					Config.T7p7bFhSnA = num4;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num4 = ~num4;
					num2 = (num3 ^ 1127358552);
					*(ref num + (IntPtr)num3) = num3;
					if (num5 > num5)
					{
						*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
						*(ref num4 + (IntPtr)num) = num;
						if (num > num)
						{
							num3 = (array2[num + 9 - num3] ^ 5);
							num5 = (num2 | 2016837130);
						}
					}
					num4 = (array[num3 + 5 - num3] ^ 4);
					if (num > num)
					{
						num3 = num4 - 494;
					}
					num3 = (int)((sbyte)num3);
					num5 = (num2 ^ 1889652500);
					if (num4 > num4)
					{
						array2[num2 + 8 - num5] = num - 2;
						if (num5 > num5)
						{
							num2 = num + num3;
							array2[num2 + 5 - num] = num5 - -1;
							num = num5 - num;
							*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
							num = (int)((byte)num);
						}
					}
					num4 = num / 564;
					num4 ^= 1982672721;
					num5 = (num4 & num);
					num2 = (int)((ushort)num);
					num3 = (int)((byte)num4);
					num4 = (num2 | num);
					num2 = num3 + 124;
					num3 = array[num2 + 9 - num3] + 7;
					num3 = (int)((byte)num);
					num4 = num3 * 698;
					num3 = (int)((short)num2);
					num5 = (int)((short)num);
					num5 = num3 / 557;
					num3 = num2 * 760;
				}
				this.<LineColorStart>k__BackingField = value;
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x0600003A RID: 58 RVA: 0x0023D974 File Offset: 0x0023BB74
		// (set) Token: 0x0600003B RID: 59 RVA: 0x0023DBC8 File Offset: 0x0023BDC8
		public unsafe Color32 LineColorEnd
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.NY0idLLs0p) ^ *(&Config.NY0idLLs0p)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2 | 835939015;
					int num3;
					int num4;
					num = num3 % num4;
					num4 = 2132926778;
					num = num3 % num4;
					num = num4 % 161;
					Config.T7p7bFhSnA = num;
					num2 = num;
					num2 = (array2[num3 + 5 - num] ^ 2);
					num4 = (array[num + 5 - num2] ^ 8);
					num4 = num2;
					array[num4 + 5 - num4] = (num4 | -7);
					num2 = num3 >> 6;
					if (num4 > num4)
					{
						array2[num3 + 7 - num3] = num - -2;
					}
					num4 += 970;
					num4 = num;
					if (num > num)
					{
						num3 = num4 % num3;
						if (num2 > num2)
						{
							num4 ^= num3;
							num4 = *(ref num4 + (IntPtr)num3);
							num3 = *(ref num + (IntPtr)num3);
						}
						num4 = (int)((short)num4);
						num = (array2[num2 + 8 - num3] ^ -3);
					}
					num >>= 4;
					array[num3 + 6 - num] = num4 - -5;
					if (num2 > num2)
					{
						num2 -= num3;
						num2 = (num4 ^ 840840779);
						num3 = num4;
						num3 = Config.T7p7bFhSnA;
						num = (num4 | 1276695283);
					}
					num2 <<= 6;
				}
				return this.<LineColorEnd>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.XQJIlk4rhG) ^ *(&Config.XQJIlk4rhG)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2 + 462;
					int num3;
					num = (num3 & 1637951589);
					int num4;
					num2 = num4 % 789;
					int num5;
					num5 /= 145;
					num = ~num5;
					num3 = num5;
					num4 >>= 1;
					num3 = num5 * 766;
					if (num5 > num5)
					{
						num3 = (num5 | num2);
					}
					num5 = num * num2;
					num5 = num;
					num = (num5 | num2);
					num2 ^= 78752333;
					num5 %= 489;
					num2 = (num5 ^ 912907525);
					array[num + 9 - num] = (num4 | 0);
					num3 = num5 % num2;
					array2[num4 + 5 - num] = num - 3;
					num = *(ref num3 + (IntPtr)num2);
					num = 1028286288;
					num4 = num2 + num4;
					num = -num2;
					if (num > num)
					{
						num5 = num2;
						if (num5 > num5)
						{
							num = num2 + 521;
							*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
							Config.T7p7bFhSnA = num2;
							num2 = *(ref num4 + (IntPtr)num2);
							num2 = -num5;
							num2 = 475491344;
						}
						num5 = Config.T7p7bFhSnA;
						array[num2 + 8 - num4] = (num4 | -3);
						num5 = Config.T7p7bFhSnA;
						num5 = (num4 & 617904526);
						num5 = num2 * 383;
						num4 = num5 % num2;
					}
					if (num5 > num5)
					{
						num5 = *(ref num + (IntPtr)num2);
						num5 = num3 - num2;
					}
					num5 = num3;
				}
				this.<LineColorEnd>k__BackingField = value;
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x0600003C RID: 60 RVA: 0x0023DE58 File Offset: 0x0023C058
		// (set) Token: 0x0600003D RID: 61 RVA: 0x0023E1B0 File Offset: 0x0023C3B0
		public unsafe Color32 TriggeredLineColorStart
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.EaASXvox6a) ^ *(&Config.EaASXvox6a)) != 0)
				{
					int[] array = new int[10];
					int num;
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					int num2 = num | 1305961921;
					num2 &= 257243416;
					int num3;
					num3 &= num;
					Config.T7p7bFhSnA = num;
					if (num > num)
					{
						if (num2 > num2)
						{
							num = (array[num3 + 5 - num3] ^ 0);
							*(ref num3 + (IntPtr)num) = num;
							num2 = (num3 ^ num);
							num3 += num;
							num2 = num;
							array[num3 + 9 - num3] = num - 4;
							num2 = num2;
							num = num3;
							num2 = ~num3;
						}
						num2 = num3;
						num3 = (num & 1318610539);
						if (num3 > num3)
						{
							*(ref num3 + (IntPtr)num) = num;
							num ^= num3;
							Config.T7p7bFhSnA = num;
							*(ref num + (IntPtr)num3) = num3;
							num2 = num >> 7;
							num3 = num - 321;
							array[num + 7 - num] = (num | -8);
							*(ref num3 + (IntPtr)num) = num;
						}
						array[num + 8 - num2] = (num | 1);
						num3 = (num ^ num3);
						num2 = 1375169261;
						if (num2 > num2)
						{
							num2 = ~num3;
							num3 = ~num2;
							num = Config.T7p7bFhSnA;
							num3 = -num2;
							num2 = -num;
							num3 = num2 + num3;
							num2 = ~num;
						}
					}
					num = (num3 & 2035175755);
					num2 -= num3;
					num = num3 / 923;
					num = 1777169027;
					num2 = (num3 & num);
					num = *(ref num + (IntPtr)num3);
					num -= num3;
					num3 = num2 << 5;
					array[num + 7 - num3] = num3 - 8;
					num2 = ~num2;
					num3 = (array[num3 + 8 - num] ^ -8);
					num3 *= 113;
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					num /= 667;
					Config.T7p7bFhSnA = num3;
					num2 = ~num;
				}
				return this.<TriggeredLineColorStart>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.7GzOEkce74) ^ *(&Config.7GzOEkce74)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = num2 + num3;
					int num4 = num2 << 5;
					num4 = num - num2;
					num3 = num4 << 3;
					int num5;
					num2 = num5 - 478;
					num5 = *(ref num4 + (IntPtr)num2);
					Config.T7p7bFhSnA = num3;
					array[num + 7 - num2] = (num | 5);
					num = ~num;
					num3 = ~num4;
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					num4 = ~num4;
					num = *(ref num4 + (IntPtr)num2);
					if (num4 > num4)
					{
						num5 = num / 756;
						num3 = num5 + 659;
						num3 &= 636208335;
						num5 = num % num2;
						*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
						num = -num4;
					}
					num5 = array[num3 + 5 - num] + 5;
					array[num4 + 6 - num5] = num2 - 9;
					num5 = *(ref num5 + (IntPtr)num2);
					num5 = (num ^ 1713588700);
					if (num > num)
					{
						if (num4 > num4)
						{
							num2 = num3 - 265;
							num2 *= 46;
							num5 = num3 >> 1;
							num5 = (int)((byte)num2);
							num5 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
							array[num3 + 8 - num5] = num2 - 8;
							num = (num4 ^ 1682881941);
							num3 = num5 + 277;
							num2 = ~num;
						}
					}
					num3 = -num5;
					num2 = (num3 | 1323474414);
					num3 = (num4 ^ num2);
					num2 = (num3 & 2102558679);
					*(ref num2 + (IntPtr)num3) = num3;
					*(ref num3 + (IntPtr)num2) = num2;
					num = (array[num + 7 - num2] ^ -8);
					array[num2 + 6 - num] = (num5 | -4);
					if (num5 > num5)
					{
						num4 = Config.T7p7bFhSnA;
					}
					num3 = num % num2;
					num4 = num3 % num2;
					num2 |= 1443496297;
					num2 = num / num2;
					num5 = num2 + num3;
					num = (num5 | num2);
					if (num3 > num3)
					{
						if (num3 > num3)
						{
							num5 &= num2;
							num5 = num3 * num2;
							num = num3 % 815;
						}
						num2 = num5 - 397;
						if (num3 > num3)
						{
							num = num5;
							num2 = (int)((sbyte)num);
							num2 = num3 % 333;
							num3 = num;
						}
						array[num2 + 7 - num4] = (num2 | -10);
						num = (int)((byte)num);
						num = num2 / num3;
						if (num2 > num2)
						{
							num3 += 471;
						}
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
						num = 218431624;
					}
					num2 = (int)((short)num3);
					num = Config.T7p7bFhSnA;
					num3 = (num5 | 1427174380);
					if (num3 > num3)
					{
						if (num2 > num2)
						{
							num5 = num;
							num = num5 + 50;
							num = num2 + num3;
							num = ~num;
							array[num2 + 5 - num4] = (num2 | 9);
							num2 = (array[num2 + 5 - num2] ^ 0);
							num3 ^= 1792730257;
							num = (int)((short)num2);
							num = *(ref num3 + (IntPtr)num2);
							num2 = num5 % 88;
						}
						num = ~num2;
						if (num5 > num5)
						{
							num5 ^= 548647221;
							num5 = -num2;
						}
						num4 -= num2;
						num2 = (int)((short)num3);
						if (num > num)
						{
							num4 = num + num2;
							Config.T7p7bFhSnA = num2;
							num4 = num2;
							num5 += 616;
							num5 = -num;
							num3 = num4 >> 7;
							*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
							num4 = num % num2;
						}
						num2 = num4 + 444;
						array[num3 + 9 - num2] = num5 - 4;
					}
					num3 = num + num2;
					num = num;
					num2 = num3 - 680;
				}
				this.<TriggeredLineColorStart>k__BackingField = value;
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x0600003E RID: 62 RVA: 0x0023E7D0 File Offset: 0x0023C9D0
		// (set) Token: 0x0600003F RID: 63 RVA: 0x0023EBC4 File Offset: 0x0023CDC4
		public unsafe Color32 TriggeredLineColorEnd
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.A5bKnRgcqs) ^ *(&Config.A5bKnRgcqs)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = (int)((byte)num2);
					int num3;
					int num4;
					if (num2 > num2)
					{
						num3 %= 131;
						num3 = num4;
						num2 = (num4 ^ num2);
					}
					num3 >>= 1;
					num2 = num3 + 290;
					num4 = ~num;
					*(ref num4 + (IntPtr)num2) = num2;
					num = *(ref num4 + (IntPtr)num2);
					num += 265;
					num = num3 * num4;
					num2 = (num & 791721532);
					num2 = array2[num4 + 6 - num4] + -9;
					num3 ^= 1983070153;
					num4 = ~num;
					num = *(ref num2 + (IntPtr)num4);
					num = (int)((ushort)num);
					num = Config.T7p7bFhSnA;
					num = num3 % num4;
					num4 = (num2 & num4);
					num2 = num4 / 143;
					if (num2 > num2)
					{
						array[num4 + 5 - num4] = (num3 | 1);
						num3 = *(ref num3 + (IntPtr)num4);
						num = (int)((short)num2);
						if (num3 > num3)
						{
							num4 = (num ^ num4);
							num2 = (int)((byte)num);
						}
						num = num;
						num = num3 << 6;
						num = num2 * 938;
					}
					num = num2 * 532;
					num4 = (num2 ^ num4);
					num3 = -num4;
					num = num3 + 402;
					num4 = (num ^ num4);
					num4 = -num;
					if (num3 > num3)
					{
						if (num3 > num3)
						{
							num4 = -num2;
							num4 = ~num3;
							num = 1842284914;
							num4 = num2 * 346;
							num2 |= num4;
							num3 = ~num;
							num4 &= 1690098606;
							num2 ^= 1467369758;
						}
						num4 = num2 - 452;
						num4 = num % num4;
						*(ref num4 + (IntPtr)num2) = num2;
						num3 = num4;
						num3 = 104721557;
						num = *(ref num3 + (IntPtr)num4);
						if (num4 > num4)
						{
							num2 = num4;
							num2 = num3 - num4;
							num2 = num4;
							num4 = *(ref num + (IntPtr)num4);
						}
						num = (array2[num2 + 7 - num4] ^ -5);
						if (num3 > num3)
						{
							num = num3 / num4;
							num2 = (int)((sbyte)num4);
							num4 = num;
							num2 = num4 - num2;
							num2 = (int)((ushort)num);
						}
					}
					num4 = *(ref num2 + (IntPtr)num4);
					num3 = num4 << 5;
					num = num4 / num2;
					*(ref num2 + (IntPtr)num4) = num4;
				}
				return this.<TriggeredLineColorEnd>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.nuwjxxYhKs) ^ *(&Config.nuwjxxYhKs)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					int num3;
					array[num + 6 - num2] = (num3 | 8);
					int num4 = num * num4;
					if (num4 > num4)
					{
						array[num + 5 - num3] = (num4 | 1);
					}
					num = ~num3;
					num4 = (num3 | 700826030);
					num4 = num * num4;
					if (num3 > num3)
					{
						num4 |= num;
						if (num4 > num4)
						{
							num = (int)((short)num2);
							num4 = (int)((sbyte)num2);
							num = array[num4 + 5 - num4] + 3;
							num2 = (int)((sbyte)num2);
							num3 = num4 + 513;
							array[num2 + 5 - num] = (num4 | 1);
						}
						num2 = num3 + num4;
					}
					array[num4 + 9 - num2] = num - 6;
					if (num4 > num4)
					{
						num4 %= num;
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
					}
					num4 = num * 260;
					num2 = Config.T7p7bFhSnA;
					num = (array[num2 + 8 - num3] ^ -1);
					if (num2 > num2)
					{
						num2 = num / num4;
						num2 = num + num4;
						num2 = (num3 | 10668987);
						if (num2 > num2)
						{
							num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
							num3 ^= 1081819657;
							num2 |= 1411431868;
							num3 = ~num3;
							num2 *= 727;
							num4 = (array[num + 5 - num4] ^ -10);
							array[num4 + 6 - num3] = num - 6;
							num = -num4;
							num2 = (num & 316895085);
						}
					}
					if (num > num)
					{
						num2 = num4 / num;
						num2 -= 744;
					}
					num2 = (int)((ushort)num);
					num3 = num - 216;
					if (num > num)
					{
						num = num4 % num;
						num3 = -num4;
						if (num3 > num3)
						{
							num = num2 - num4;
							num4 = (num & 900578445);
							num = num2 + 616;
							num4 = num3 / 441;
						}
						num2 = (int)((sbyte)num2);
						num = ~num4;
						num4 = Config.T7p7bFhSnA;
						num = Config.T7p7bFhSnA;
						num3 -= 841;
						num = -num2;
					}
					num = (num2 ^ 227046641);
					num3 = num4;
					num4 = (num2 & num4);
					num4 |= 666580442;
					if (num2 > num2)
					{
						num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
						num3 = Config.T7p7bFhSnA;
						num = ~num2;
						num = Config.T7p7bFhSnA;
						num3 = 403673645;
					}
					num4 = num / num4;
					num2 = array[num + 8 - num2] + 2;
					num2 = (num ^ num4);
					num = num4 * 812;
				}
				this.<TriggeredLineColorEnd>k__BackingField = value;
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000040 RID: 64 RVA: 0x0023F02C File Offset: 0x0023D22C
		// (set) Token: 0x06000041 RID: 65 RVA: 0x0023F3A4 File Offset: 0x0023D5A4
		public unsafe bool EnableAnimations
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.hXvasRa5DA) ^ *(&Config.hXvasRa5DA)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = -num2;
					num2 = Config.T7p7bFhSnA;
					int num3;
					num = ~num3;
					int num4;
					num = (num4 & num2);
					num3 = (num2 | 1399086545);
					array[num4 + 7 - num4] = num - -9;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num = num4 << 4;
					num2 <<= 5;
					if (num2 > num2)
					{
						num3 = -num;
						if (num > num)
						{
							num4 = 335892594;
							num = (num2 ^ num);
							num4 = num / num2;
							num2 = ~num4;
						}
					}
					num = num4 + 187;
					num2 = num;
					if (num2 > num2)
					{
						if (num3 > num3)
						{
							num = *(ref num3 + (IntPtr)num2);
						}
						num4 = -num2;
						if (num3 > num3)
						{
							array[num2 + 6 - num4] = num3 - -3;
							*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
							num3 = num2;
							num = num2 * 489;
						}
						num4 = num3 % num2;
					}
					num = num2 >> 5;
					Config.T7p7bFhSnA = num3;
					num = num4 - 852;
					if (num2 > num2)
					{
						num3 = array[num2 + 7 - num2] + 0;
						if (num3 > num3)
						{
							num2 = num4 + 269;
							num4 = array[num4 + 8 - num4] + 6;
							*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
						}
						num4 = *(ref num4 + (IntPtr)num2);
						num = num4 + 876;
						num = num4 << 2;
						num2 = num2;
						num >>= 7;
						num2 = (int)((byte)num2);
					}
					num = num2;
					*(ref num2 + (IntPtr)num) = num;
					num3 = num2 % 174;
					num3 = num - 935;
					if (num > num)
					{
						*(ref num + (IntPtr)num2) = num2;
						num = ~num4;
						array[num + 8 - num2] = num4 - -10;
						num = num4 << 6;
					}
					num3 = num4 * num2;
					if (num3 > num3)
					{
						array[num2 + 8 - num4] = (num2 | 3);
						num3 = num + 613;
						num %= num2;
					}
				}
				return this.<EnableAnimations>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.IZtmGJ80pG) ^ *(&Config.IZtmGJ80pG)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					int num3;
					array[num + 7 - num2] = (num3 | -5);
					int num4;
					*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
					int num5;
					num5 >>= 5;
					*(ref num3 + (IntPtr)num) = num;
					num = num4 >> 3;
					num5 = (num & num5);
					*(ref num5 + (IntPtr)num) = num;
					if (num2 > num2)
					{
						*(ref num5 + (IntPtr)num) = num;
						num = num3 + 337;
						num5 = num + 880;
					}
					if (num > num)
					{
						num3 = *(ref num + (IntPtr)num5);
						array[num5 + 8 - num] = num4 - 1;
					}
					if (num3 > num3)
					{
						array2[num2 + 5 - num5] = (num | -9);
						num3 = (num5 | num);
						num2 = num4 >> 2;
						if (num3 > num3)
						{
							num3 = num4 + 364;
							num2 = ~num3;
							num = num5;
							num5 = array2[num3 + 5 - num5] + 6;
						}
						num4 = ~num4;
						num3 = num + 594;
					}
					num5 = num / num5;
					if (num2 > num2)
					{
						if (num2 > num2)
						{
							num4 = -num2;
							num = 1218859152;
							num3 = num2 * num;
							array[num3 + 9 - num5] = (num4 | 1);
							num5 = *(ref num2 + (IntPtr)num);
							num3 |= num;
							num = num4;
							num3 = num2 * num;
							num5 = num / 871;
						}
						if (num3 > num3)
						{
							num = num5;
						}
						num = (num2 | num);
					}
					if (num3 > num3)
					{
						num4 *= num;
						if (num4 > num4)
						{
							Config.T7p7bFhSnA = num4;
							num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
							num5 = (int)((sbyte)num3);
							num3 = num5 * 454;
							num = *(ref num2 + (IntPtr)num);
							num3 = (int)((short)num);
							num5 = num4 % 213;
						}
						num2 = num;
						num4 = num5 / num;
						array[num + 9 - num] = (num | -8);
					}
					array[num3 + 5 - num2] = num3 - 0;
					num4 = Config.T7p7bFhSnA;
					num3 = array[num3 + 7 - num5] + -3;
					num2 = (int)((sbyte)num2);
					num4 = (int)((byte)num);
					num = Config.T7p7bFhSnA;
					num3 = (num5 ^ 2076716968);
					if (num > num)
					{
						num5 = num3 / num;
						array[num4 + 7 - num2] = num3 - 1;
						num2 = *(ref num2 + (IntPtr)num);
						array2[num5 + 8 - num5] = num5 - -1;
						if (num > num)
						{
							num4 -= num;
							array2[num3 + 6 - num5] = num - -8;
						}
						array[num2 + 6 - num5] = num - -10;
					}
					num5 = num2 + 788;
					num = num4 * num;
					Config.T7p7bFhSnA = num5;
					num = -num2;
					num3 = *(ref num + (IntPtr)num5);
					num4 = (num2 ^ 386975199);
					num = num5 * 295;
					num2 = num;
					array[num5 + 6 - num2] = (num3 | -5);
					num3 = num + num5;
					if (num4 > num4)
					{
						if (num5 > num5)
						{
							num3 = (num5 ^ 1494220097);
							array[num5 + 5 - num3] = (num5 | -8);
							num2 = ~num;
							num5 = (array2[num + 9 - num2] ^ -5);
							num = ~num2;
							num5 = num4 * 786;
						}
						num4 |= num;
						if (num5 > num5)
						{
							*(ref num5 + (IntPtr)num) = num;
							num4 = ~num3;
							array2[num4 + 7 - num2] = num2 - -3;
							num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
						}
						num2 = num;
					}
				}
				this.<EnableAnimations>k__BackingField = value;
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x06000042 RID: 66 RVA: 0x0023F9C0 File Offset: 0x0023DBC0
		// (set) Token: 0x06000043 RID: 67 RVA: 0x0023FD90 File Offset: 0x0023DF90
		public unsafe float PulseSpeed
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.OLHOwMTPaR) ^ *(&Config.OLHOwMTPaR)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					Config.T7p7bFhSnA = num;
					int num2;
					int num3;
					int num4;
					if (num2 > num2)
					{
						num3 = Config.T7p7bFhSnA;
						num4 = num2 * num3;
					}
					num3 = Config.T7p7bFhSnA;
					num2 = (int)((byte)num4);
					num = num4 >> 4;
					num4 = num3 % 473;
					num3 >>= 3;
					if (num4 > num4)
					{
						if (num3 > num3)
						{
							num4 = num3 + 95;
							num3 = *(ref num3 + (IntPtr)num2);
							num = 277089049;
							num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
						}
						num &= 2041829858;
						num3 = num3;
						num4 = -num4;
						*(ref num2 + (IntPtr)num3) = num3;
					}
					num2 = array[num4 + 6 - num4] + -9;
					num2 = array2[num2 + 9 - num3] + -7;
					num3 = (num2 & 1416367629);
					num2 = (num | num2);
					num = (num2 & num3);
					num4 = num3 << 1;
					if (num > num)
					{
						array[num4 + 7 - num2] = num2 - 6;
						num3 = num4 % 8;
						Config.T7p7bFhSnA = num;
						Config.T7p7bFhSnA = num2;
					}
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num = num2 % 143;
					num = (int)((byte)num);
					num2 = num4 - 711;
					num = -num3;
					num3 = (array[num4 + 8 - num] ^ 2);
					num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
					num2 = num4 - num2;
					array[num3 + 7 - num2] = num4 - 0;
					if (num4 > num4)
					{
						num2 = num3 + 120;
						num2 = num3 % num2;
						num4 = array2[num3 + 6 - num3] + -2;
						num4 = -num;
						num &= 184374049;
						num4 = -num3;
						if (num > num)
						{
							*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
							num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
							num4 = (int)((short)num);
							num4 = num3 + num2;
							num2 = num3 / num2;
							num2 = num3 - num2;
							num4 = num4;
							*(ref num3 + (IntPtr)num2) = num2;
						}
						if (num2 > num2)
						{
							num2 = *(ref num2 + (IntPtr)num3);
							num = -num3;
						}
						num2 = num;
					}
					num2 = (array[num + 8 - num2] ^ 1);
					Config.T7p7bFhSnA = num3;
				}
				return this.<PulseSpeed>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.M4TPWmJBcV) ^ *(&Config.M4TPWmJBcV)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = (int)((short)num2);
					int num3;
					if (num > num)
					{
						num3 = num2 << 4;
						*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
						if (num3 > num3)
						{
							num2 = -num2;
							num >>= 1;
							*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
							num3 = num - num2;
							num2 = (num3 ^ 2107400431);
							num = ~num3;
							num2 += num3;
							num2 = num * num2;
						}
						num2 = -num;
						num2 = num - num2;
						*(ref num3 + (IntPtr)num2) = num2;
					}
					num2 = -num3;
					if (num > num)
					{
						num = (num2 & num3);
						num2 >>= 3;
						if (num > num)
						{
							num3 = num / num2;
							num2 = num3 >> 5;
							num2 = num3 / 383;
							num = (num3 & 1217463909);
							num3 = num3;
							num2 = *(ref num3 + (IntPtr)num2);
							num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
							num = (int)((short)num3);
						}
						*(ref num + (IntPtr)num2) = num2;
						num = array2[num2 + 8 - num2] + 0;
						num2 = -num3;
						*(ref num2 + (IntPtr)num3) = num3;
						Config.T7p7bFhSnA = num2;
						num3 = (num2 ^ 522603121);
						num += 435;
					}
					Config.T7p7bFhSnA = num;
					num3 = num2 * 602;
					if (num2 > num2)
					{
						num2 = num3;
						if (num > num)
						{
							num2 = Config.T7p7bFhSnA;
						}
						if (num3 > num3)
						{
							num = num2 + num3;
							num2 = num3 % 548;
						}
						num2 *= 275;
						num2 = (num | num2);
						num2 = num3 + 870;
						num3 = (num ^ num2);
						num &= 1124054048;
						num |= num2;
					}
					num2 = num3;
					array2[num + 7 - num3] = num3 - 0;
					num3 = -num3;
					if (num3 > num3)
					{
						num3 = (num | num2);
						num3 = Config.T7p7bFhSnA;
						*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					}
					num3 = num2 % num3;
					if (num2 > num2)
					{
						if (num2 > num2)
						{
							num3 = num;
						}
						if (num2 > num2)
						{
							num2 = num;
							array2[num2 + 5 - num] = (num3 | -8);
							num3 = array[num + 8 - num3] + -4;
							Config.T7p7bFhSnA = num;
						}
						num = num2 - 39;
						num3 = (num ^ num2);
						num2 = num2;
						num3 = num2 / num3;
						*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
						num3 = Config.T7p7bFhSnA;
						num2 = num;
						num3 = array[num3 + 6 - num] + -2;
					}
					if (num > num)
					{
						num2 = num3 * 941;
						num3 = (num2 & num3);
					}
					if (num2 > num2)
					{
						num = (int)((byte)num);
						if (num2 > num2)
						{
							num3 /= num2;
						}
					}
					num = num2;
					num3 = num2 + 446;
					num = num2 >> 4;
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
					if (num2 > num2)
					{
						num3 = num2;
						num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
						num3 = (int)((ushort)num);
						num3 = (int)((byte)num3);
						num3 = ~num3;
						num3 -= num2;
					}
					num = (array2[num + 5 - num3] ^ -2);
					if (num3 > num3)
					{
						num2 = (num3 ^ num2);
					}
				}
				this.<PulseSpeed>k__BackingField = value;
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000044 RID: 68 RVA: 0x0024030C File Offset: 0x0023E50C
		// (set) Token: 0x06000045 RID: 69 RVA: 0x00240848 File Offset: 0x0023EA48
		public unsafe float PulseAmplitude
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.0lYpkNBJdo) ^ *(&Config.0lYpkNBJdo)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = array[num2 + 8 - num3] ^ 7;
					num3 = num;
					num *= 496;
					if (num2 > num2)
					{
						num3 = num3;
						array[num2 + 9 - num3] = num2 - 1;
						num = array[num3 + 9 - num2] + -4;
						num = (array[num + 7 - num2] ^ 6);
						num3 = num << 3;
						if (num > num)
						{
							*(ref num + (IntPtr)num3) = num3;
							num3 = (num2 ^ 731467332);
							num3 = num3;
							num = num3;
							Config.T7p7bFhSnA = num3;
							num3 >>= 4;
							num2 = num * 134;
							num2 = -num2;
							num = num;
							num3 = Config.T7p7bFhSnA;
						}
						num3 = (num2 & num);
						num3 = num2 + num;
					}
					num2 = (array[num3 + 6 - num] ^ 5);
					num3 /= 420;
					if (num2 > num2)
					{
						num2 = array[num2 + 8 - num] + -8;
					}
					num ^= num3;
					if (num > num)
					{
						Config.T7p7bFhSnA = num2;
						num3 /= num;
						num -= num3;
						num3 -= num;
						num2 = (num3 & num);
						Config.T7p7bFhSnA = num;
						num = 450833718;
					}
					if (num > num)
					{
						num = num2;
						if (num > num)
						{
							*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
							num3 = (array[num + 6 - num] ^ 5);
							num = num2;
							array[num + 7 - num] = num3 - 2;
							num3 = num2 + num;
							*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
						}
					}
					num <<= 5;
					num2 = num3 % 276;
					num = num2 * num;
					*(ref num2 + (IntPtr)num) = num;
					num3 -= 662;
					if (num3 > num3)
					{
						num2 = num - num3;
						if (num3 > num3)
						{
							num3 = num + num3;
							num2 = (int)((short)num3);
							num2 = *(ref num3 + (IntPtr)num);
							num3 = ~num3;
						}
						num3 = -num3;
					}
					num2 = num - num3;
					num2 = num % num3;
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					num2 = num % num3;
					if (num2 > num2)
					{
						num2 = -num3;
					}
					if (num3 > num3)
					{
						if (num3 > num3)
						{
							num = num3 * 820;
						}
						num2 = num3;
						*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
						num3 = num3;
						num2 = num;
						num = *(ref num + (IntPtr)num3);
					}
					num3 = (num2 | num);
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
					array[num3 + 5 - num3] = num2 - -5;
					num = ~num2;
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					if (num > num)
					{
						if (num > num)
						{
							*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
							num = (array[num2 + 5 - num3] ^ 8);
							num3 = -num2;
							num3 = ~num3;
							num3 = (int)((sbyte)num3);
							num2 = (int)((short)num3);
							num += num3;
							num = num2 << 2;
							num2 = (num3 ^ 595371206);
						}
					}
					num = num2 >> 7;
					num = (int)((byte)num2);
				}
				return this.<PulseAmplitude>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.yi2EdWQhnf) ^ *(&Config.yi2EdWQhnf)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = num2 & 986015332;
					int num4;
					int num3 = num4;
					int num5 = num2 >> 4;
					*(ref Config.T7p7bFhSnA + (IntPtr)num5) = num5;
					*(ref Config.T7p7bFhSnA + (IntPtr)num5) = num5;
					num = num3 - 201;
					num5 = num4;
					num ^= num4;
					num = (int)((sbyte)num4);
					if (num > num)
					{
						num2 = num5 * num4;
						num2 = (array[num + 9 - num3] ^ 6);
						num *= 921;
						num = (int)((byte)num);
					}
					num5 = ~num3;
					num5 = -num2;
					array[num3 + 9 - num3] = num3 - -5;
					num2 = (array[num5 + 9 - num2] ^ 0);
					num = (num5 ^ 76034081);
					num3 = ~num4;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num5 = num4 % num3;
					if (num2 > num2)
					{
						num2 = num4 / 594;
						num5 = num2 + num4;
						if (num5 > num5)
						{
							num5 = num >> 5;
							array[num4 + 6 - num2] = num5 - -3;
							num2 = num5 % 283;
							num = num5;
							num4 = num5 * num4;
							num2 = (num | num4);
							num5 = num4;
							num5 %= 786;
							num = num4 / num3;
							num5 = 258555407;
						}
					}
					num4 = num4;
					num5 = num3 + 615;
					num3 += num4;
					num2 = num4;
					num2 = (num4 ^ num3);
					num3 = (num4 & num3);
					num5 = num3 % 918;
					num2 = num4;
					if (num3 > num3)
					{
						num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
						Config.T7p7bFhSnA = num3;
						num3 = num >> 3;
						*(ref Config.T7p7bFhSnA + (IntPtr)num5) = num5;
						num2 = (int)((short)num2);
					}
					if (num5 > num5)
					{
						num5 = (num3 & 140640233);
						num3 = num4 + 619;
						num2 %= 234;
						array[num4 + 5 - num5] = (num4 | 3);
						num4 = num3;
						num3 = num5;
					}
					num4 = (num ^ num4);
					num3 = (array[num2 + 7 - num3] ^ -3);
					num5 = (int)((short)num);
					num2 = num5 << 5;
					num5 = num - 436;
				}
				this.<PulseAmplitude>k__BackingField = value;
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000046 RID: 70 RVA: 0x00240C08 File Offset: 0x0023EE08
		// (set) Token: 0x06000047 RID: 71 RVA: 0x00241048 File Offset: 0x0023F248
		public unsafe bool EnableParticles
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.7KevxNFeQe) ^ *(&Config.7KevxNFeQe)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					int num3;
					int num4;
					if (num > num)
					{
						num2 = (array[num2 + 5 - num2] ^ -2);
						num = (array[num2 + 8 - num2] ^ -8);
						if (num3 > num3)
						{
							num4 = num3 - num4;
							num3 = num4;
							array[num + 7 - num3] = (num4 | -7);
							num = (num2 & num4);
						}
						num3 *= num4;
						*(ref num + (IntPtr)num4) = num4;
						if (num3 > num3)
						{
							num3 *= 998;
						}
					}
					array[num4 + 7 - num4] = num4 - -6;
					if (num4 > num4)
					{
						num2 |= 1742124263;
						num = ~num3;
						num4 = -num4;
						num4 = (num3 | num4);
						Config.T7p7bFhSnA = num;
						num2 = num4 * num3;
						num2 = num4;
						num2 = num4;
						num2 = ~num3;
					}
					if (num2 > num2)
					{
						num2 = ~num4;
						*(ref num + (IntPtr)num4) = num4;
						num2 = ~num4;
					}
					if (num > num)
					{
						num = (int)((sbyte)num4);
						num2 = *(ref num2 + (IntPtr)num4);
						array[num3 + 6 - num4] = num3 - 6;
						num2 = num4 + num3;
					}
					num = num3 * 632;
					array[num3 + 6 - num] = num4 - -7;
					num = num2 * num4;
					num4 = num3 % num4;
					*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					num4 = num2;
					num4 ^= num3;
					num2 = ~num;
					num *= num4;
					num4 = (int)((byte)num2);
					num4 %= num3;
					num4 ^= 1766862048;
					num4 = *(ref num2 + (IntPtr)num4);
					num3 ^= 347109946;
					num3 = num4;
					if (num3 > num3)
					{
						num = num4;
						num3 = ~num2;
						num4 <<= 5;
						num2 -= 657;
						num2 = (int)((ushort)num4);
						num3 = num + num4;
						if (num2 > num2)
						{
							num = num3 - num4;
							num4 = ~num2;
							num = (num4 & num3);
							num4 = num3;
							array[num4 + 8 - num2] = (num | 1);
							num4 = num3 + 114;
							num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
						}
						num4 = (num2 & num4);
						*(ref num2 + (IntPtr)num4) = num4;
					}
					num = num3 >> 1;
					num4 |= 1974735216;
					num2 = -num3;
					num2 = num4 << 6;
					num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					num -= 663;
					num4 = num % 842;
				}
				return this.<EnableParticles>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.97XTPnxboj) ^ *(&Config.97XTPnxboj)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = num2 / num3;
					num2 &= num3;
					int num5;
					int num4;
					if (num > num)
					{
						num4 = -num5;
						num = num2 - num3;
						num3 = num4 - 66;
						num2 &= 1351625949;
						num += 491;
						num4 = num3 / num2;
					}
					num5 = (num2 ^ 326968596);
					num = (int)((short)num5);
					num = num2;
					num3 = (int)((byte)num2);
					num2 = (num | 565709315);
					num2 = (int)((sbyte)num5);
					num5 = (array[num + 8 - num3] ^ 1);
					num = 63930715;
					if (num5 > num5)
					{
						num4 = -num4;
						num = num2 / 315;
					}
					num5 = num + 416;
					num3 = -num3;
					num2 = num5 % num2;
					num = num5 * num2;
					num3 = -num4;
					array[num3 + 9 - num4] = (num2 | 5);
					num3 = num / 253;
				}
				this.<EnableParticles>k__BackingField = value;
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000048 RID: 72 RVA: 0x002411F4 File Offset: 0x0023F3F4
		// (set) Token: 0x06000049 RID: 73 RVA: 0x00241614 File Offset: 0x0023F814
		public unsafe float ParticleStartSize
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.LKwvcoCPwA) ^ *(&Config.LKwvcoCPwA)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2 ^ num;
					int num3;
					num = *(ref num3 + (IntPtr)num);
					num = 494683951;
					if (num > num)
					{
						if (num > num)
						{
							num3 = num2;
							num2 = -num;
							num3 = (num & 1891822094);
							num2 = ~num;
							num3 = -num;
						}
						num3 = num2 >> 1;
						num3 = num;
						num3 = num2 * num;
						num = num;
						num3 = (array[num2 + 5 - num] ^ -1);
					}
					num2 = *(ref num2 + (IntPtr)num);
					if (num3 > num3)
					{
						num2 /= num;
						num2 = (num3 & num);
						num -= num3;
						num = num;
						num3 = (int)((byte)num3);
						num3 *= 734;
						if (num2 > num2)
						{
							num = (num2 | 1891115052);
						}
						num = num2 / num;
						num = num3 % 961;
						num3 = (array2[num + 7 - num3] ^ -1);
					}
					array[num3 + 7 - num3] = num3 - 3;
					if (num > num)
					{
						num3 %= 130;
						*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
						num2 = num;
						*(ref num3 + (IntPtr)num) = num;
						if (num > num)
						{
							num2 <<= 1;
							num2 &= 727464671;
							num = (int)((short)num2);
							num = num2 * 850;
							num3 = num - 429;
							num2 = -num;
							num3 = array[num3 + 6 - num3] + -4;
							num3 = num2 % 85;
							num = num2 - num;
							num2 = (num ^ num3);
						}
						Config.T7p7bFhSnA = num3;
						*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					}
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					num3 -= 780;
					num3 = num2 * num;
					num3 = (num ^ 370662289);
					num = -num2;
					num2 = ~num;
					num2 = (num3 | 1294109656);
					num3 = -num3;
					array2[num + 6 - num3] = (num2 | -3);
					num2 = num / 933;
					array2[num3 + 6 - num] = (num2 | -3);
					num3 = num2 + num;
					num3 = -num;
					num3 = (num2 ^ 278459133);
					num3 /= 96;
					num += 611;
					array[num3 + 5 - num] = (num | -6);
					num3 = (int)((short)num3);
					num = (int)((short)num3);
					num *= num3;
				}
				return this.<ParticleStartSize>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.VmX6YpGm1W) ^ *(&Config.VmX6YpGm1W)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = *(ref num2 + (IntPtr)num3);
					int num4;
					num2 = num4 - 101;
					num2 -= num3;
					int num5 = num4 ^ num3;
					num3 = num4;
					num3 = num4 % num3;
					num4 = num5 / 844;
					num5 = num5;
					num = num2 * 698;
					num5 = 1500846551;
					num5 = (num3 & 957926267);
					num3 = (num2 ^ num3);
					num5 = (num2 ^ num3);
					if (num4 > num4)
					{
						num = num4;
					}
					*(ref num + (IntPtr)num3) = num3;
					num5 = num5;
					num2 = num5 % num3;
					num5 = num3;
					*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
					num5 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
					num2 = num3;
				}
				this.<ParticleStartSize>k__BackingField = value;
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x0600004A RID: 74 RVA: 0x0024175C File Offset: 0x0023F95C
		// (set) Token: 0x0600004B RID: 75 RVA: 0x00241E7C File Offset: 0x0024007C
		public unsafe float ParticleStartSpeed
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.Hg38p1Kiyz) ^ *(&Config.Hg38p1Kiyz)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					array[num + 5 - num2] = (num2 | -2);
					int num3 = array[num + 5 - num3] + -6;
					int num4 = num << 6;
					int num5;
					if (num > num)
					{
						if (num5 > num5)
						{
							num5 = num3 + num5;
							num = 908710535;
							num = array[num4 + 7 - num2] + 1;
							num2 = (int)((sbyte)num4);
							num5 = ~num3;
							array[num2 + 9 - num] = num - -7;
							num3 = -num3;
						}
						num2 = (int)((ushort)num2);
						*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
						num4 = Config.T7p7bFhSnA;
						num5 = num4 + 600;
						if (num4 > num4)
						{
							num5 = (num4 | num5);
							num -= 898;
							num = num2 % 422;
						}
						num = (num4 & 866967817);
						num5 = num2 / 112;
						num += num5;
						num = array2[num3 + 8 - num3] + -3;
					}
					array2[num5 + 7 - num5] = (num2 | 6);
					num4 = Config.T7p7bFhSnA;
					num4 = num5;
					if (num > num)
					{
						num = (num3 & 1437013825);
						num2 ^= num5;
						if (num4 > num4)
						{
							num5 = (num3 ^ num5);
							num3 = num4 * num5;
							num3 = (int)((sbyte)num4);
							num4 = Config.T7p7bFhSnA;
							num2 |= 415498203;
							num = num4 - 64;
						}
						num5 = (int)((byte)num);
					}
					num4 ^= num5;
					if (num3 > num3)
					{
						num4 %= 991;
						num = num2 + num5;
						num3 = (int)((byte)num2);
						num5 *= num3;
						array2[num3 + 8 - num3] = (num3 | 5);
					}
					if (num2 > num2)
					{
						*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
						num = array2[num + 5 - num] + 7;
						num = num5;
						num2 = (num ^ 142989185);
						num2 = num4 + 810;
						if (num3 > num3)
						{
							num = num2 - num5;
						}
						*(ref num4 + (IntPtr)num5) = num5;
					}
					num5 -= 825;
					num4 = *(ref num2 + (IntPtr)num5);
					num = (int)((sbyte)num);
					num += 778;
					num5 = Config.T7p7bFhSnA;
					num2 = num5;
					num2 = (array[num4 + 6 - num] ^ 5);
					num3 = (num4 ^ num5);
					num3 = *(ref num3 + (IntPtr)num5);
					num5 = num3;
					num = num2 + num5;
					if (num3 > num3)
					{
						num5 = (num4 | 677909894);
						num3 = (num4 & 689611138);
						num &= 1479180989;
						num = ~num;
						num >>= 6;
						num5 = (num4 | 221621144);
					}
					num4 = (num3 | 1286336525);
					num4 |= 1542487381;
					num2 = num3 * num5;
					if (num2 > num2)
					{
						num4 = num5;
					}
					num4 = num5;
					num5 = (num3 | num5);
					num2 = -num2;
					num4 = num3 - num5;
					num = (int)((short)num5);
					num /= 980;
					num4 = (int)((short)num5);
					if (num2 > num2)
					{
						num = (num5 ^ 609927144);
						num2 = -num2;
						num5 = num + 885;
						num4 = num2 >> 2;
						if (num3 > num3)
						{
							num = num5 * 193;
							*(ref num3 + (IntPtr)num5) = num5;
							num3 = *(ref num5 + (IntPtr)num3);
							array[num2 + 5 - num5] = num2 - -5;
							num5 ^= 824551150;
							num5 = 223381100;
							num4 = (num5 & num3);
							num4 = Config.T7p7bFhSnA;
							num4 = 1912682756;
						}
						num2 = *(ref num4 + (IntPtr)num5);
						num3 = (num5 | num3);
						if (num5 > num5)
						{
							num3 = (num4 & num5);
							Config.T7p7bFhSnA = num;
							num3 /= 276;
							Config.T7p7bFhSnA = num2;
							num2 = num5 << 6;
							*(ref num4 + (IntPtr)num5) = num5;
							num2 = (num3 ^ 890300071);
						}
						*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
						num3 = ~num4;
					}
					Config.T7p7bFhSnA = num5;
					num = Config.T7p7bFhSnA;
					num2 = (int)((byte)num5);
					num4 = array2[num5 + 7 - num2] + -3;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num3 = num2 / 426;
					if (num4 > num4)
					{
						num4 = num2 + num5;
						num = num5 + 327;
						num4 = num5;
						num = (int)((ushort)num2);
					}
				}
				return this.<ParticleStartSpeed>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.iy2EUwYsSJ) ^ *(&Config.iy2EUwYsSJ)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					*(ref num + (IntPtr)num2) = num2;
					int num3;
					num3 ^= 24217941;
					num %= 64;
					int num4 = num ^ num2;
					num3 /= num;
					num2 = num3;
					num2 = (int)((short)num3);
					num4 |= 41891118;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num3 = Config.T7p7bFhSnA;
					array[num3 + 8 - num3] = num4 - -6;
					num2 = num3;
					num = array[num4 + 9 - num] + -6;
					if (num4 > num4)
					{
						Config.T7p7bFhSnA = num3;
						num2 = (num | num2);
					}
					num = num3 % num;
					num4 = array[num + 7 - num3] + 5;
					num4 -= 820;
					num2 = (int)((byte)num2);
					num = num4 / num;
					num4 = num2 + 344;
					if (num > num)
					{
						if (num3 > num3)
						{
							num -= 798;
							num4 = (array[num4 + 5 - num] ^ 0);
							num4 += 10;
							num = num4 << 7;
							*(ref num4 + (IntPtr)num) = num;
						}
						num4 = num * num2;
						num = (array[num4 + 5 - num4] ^ 8);
						num4 = (int)((sbyte)num3);
						num2 = ~num3;
						num3 = array[num3 + 8 - num4] + 1;
						if (num3 > num3)
						{
							num4 = -num3;
						}
						num = num2;
						num = ~num3;
						num3 = Config.T7p7bFhSnA;
					}
					array[num3 + 6 - num] = num4 - -9;
					if (num4 > num4)
					{
						num = *(ref num2 + (IntPtr)num);
						*(ref num4 + (IntPtr)num) = num;
						*(ref num3 + (IntPtr)num) = num;
						if (num > num)
						{
							*(ref num + (IntPtr)num2) = num2;
							num2 >>= 5;
							num %= 551;
							num3 = -num4;
							num = num4 % 989;
						}
						num = -num4;
						num4 = num2 / num;
						if (num2 > num2)
						{
							num = (num4 | num);
							num = Config.T7p7bFhSnA;
							num3 = num << 4;
							num2 = Config.T7p7bFhSnA;
							num2 = num / 207;
						}
						num = ~num2;
					}
					num3 = array[num3 + 8 - num4] + -10;
					num4 *= num;
					num3 = (num2 ^ 388086633);
					if (num > num)
					{
						num3 = Config.T7p7bFhSnA;
						num = *(ref num3 + (IntPtr)num);
					}
					num3 = (num2 | num);
					num = num3 - num;
					num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
				}
				this.<ParticleStartSpeed>k__BackingField = value;
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x0600004C RID: 76 RVA: 0x002422A0 File Offset: 0x002404A0
		// (set) Token: 0x0600004D RID: 77 RVA: 0x00242488 File Offset: 0x00240688
		public unsafe int ParticleMaxCount
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.L0rPIWjb5k) ^ *(&Config.L0rPIWjb5k)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num = 2088564934;
					int num2;
					int num3;
					int num5;
					int num4;
					if (num2 > num2)
					{
						num = ~num3;
						num = num3;
						num4 = num5 - num4;
					}
					num = num5 + 265;
					num3 = array[num5 + 9 - num3] + 3;
					num4 = (array2[num4 + 9 - num4] ^ 7);
					num4 = -num5;
					*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					num2 = num4 / 830;
					num = num3 % num4;
					num2 = num - num4;
					num4 = num5 * num4;
					*(ref Config.T7p7bFhSnA + (IntPtr)num5) = num5;
					num2 = (int)((sbyte)num5);
					array[num4 + 5 - num4] = (num4 | -8);
					*(ref num + (IntPtr)num4) = num4;
					*(ref num2 + (IntPtr)num4) = num4;
					num = num4 << 3;
					if (num2 > num2)
					{
						num2 = ~num;
						num5 = num4;
						num3 = num4 - num;
						num3 = (int)((byte)num);
					}
					num5 = (num | num4);
					array[num + 7 - num3] = num3 - -5;
					num5 |= 1866934058;
				}
				return this.<ParticleMaxCount>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.hKkSboRxGl) ^ *(&Config.hKkSboRxGl)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = *(ref num2 + (IntPtr)num);
					int num3;
					array2[num3 + 7 - num] = (num | 4);
					if (num2 > num2)
					{
						if (num2 > num2)
						{
							num = array[num3 + 6 - num3] + -9;
							num2 = (num ^ 32904803);
							num3 = -num;
							num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
							num3 = num2 >> 6;
							num2 = 1481126511;
						}
						num = (int)((ushort)num2);
						if (num3 > num3)
						{
							num2 = num * num3;
							num2 = Config.T7p7bFhSnA;
						}
						num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					}
					if (num > num)
					{
						num2 = (int)((ushort)num2);
						if (num3 > num3)
						{
							num = ~num2;
							num3 = (int)((sbyte)num2);
							num = ~num2;
							num2 = num / num3;
						}
						num = num3 % num;
						num2 ^= 2066556712;
						num2 = (num3 & 1963475993);
						num3 = num2 + num;
						num3 = ~num2;
						num = num2;
						num3 = ~num2;
						num2 = ~num;
					}
					num = (int)((short)num);
					num3 = num << 4;
					num = (num2 | 244004772);
					num3 = num % num3;
					num3 |= num;
					num = num2 / 661;
					num = num2 / 845;
					if (num3 > num3)
					{
						num3 = (num2 & 1992734106);
						num -= num3;
						num3 = num;
						num2 = -num;
						if (num > num)
						{
							Config.T7p7bFhSnA = num2;
							num3 *= num;
						}
						array[num3 + 8 - num3] = (num2 | -6);
						num *= 90;
					}
					if (num3 > num3)
					{
						num3 = (int)((short)num3);
						num3 = num2 - 547;
						*(ref num + (IntPtr)num3) = num3;
					}
					num3 = num2 / num;
					Config.T7p7bFhSnA = num2;
					num3 = num2;
					num3 = ~num;
					array[num3 + 7 - num2] = num2 - -9;
					num3 = (num2 | num);
					num3 = -num3;
					*(ref num2 + (IntPtr)num) = num;
					num3 = num2 >> 5;
					num2 = num3 / num;
					if (num3 > num3)
					{
						num = *(ref num3 + (IntPtr)num);
						num = num2 - num;
						num2 ^= 492406734;
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
						num3 = num;
					}
					num3 = num - 795;
					num2 -= 585;
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
				}
				this.<ParticleMaxCount>k__BackingField = value;
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x0600004E RID: 78 RVA: 0x00242880 File Offset: 0x00240A80
		// (set) Token: 0x0600004F RID: 79 RVA: 0x00242D80 File Offset: 0x00240F80
		public unsafe float ParticleEmissionRate
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.eda7bguSll) ^ *(&Config.eda7bguSll)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = array[num2 + 8 - num3] ^ 2;
					num = Config.T7p7bFhSnA;
					Config.T7p7bFhSnA = num2;
					num2 %= 238;
					num2 ^= 886690360;
					*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					num2 = (num ^ 1867013996);
					array[num + 8 - num] = num3 - -2;
					num3 = -num3;
					int num4;
					num3 = (num2 ^ num4);
					*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
					if (num > num)
					{
						num3 = num - 382;
						num4 = *(ref num4 + (IntPtr)num3);
					}
					num2 = ~num4;
					num = (num3 & num4);
					num2 = ~num2;
					num3 = (num | 313481540);
					Config.T7p7bFhSnA = num3;
					array[num2 + 6 - num4] = num3 - -9;
					num3 = num4;
					num4 = num3;
					if (num > num)
					{
						num2 = (num3 & num4);
						Config.T7p7bFhSnA = num;
						num = num;
						num3 <<= 2;
						num2 = (num4 | num3);
						Config.T7p7bFhSnA = num3;
						if (num4 > num4)
						{
							num = *(ref num3 + (IntPtr)num4);
							num3 = num2;
							num = array[num2 + 7 - num4] + -10;
						}
					}
					if (num3 > num3)
					{
						num4 *= 100;
					}
					num3 = (int)((ushort)num2);
					if (num4 > num4)
					{
						num = *(ref num3 + (IntPtr)num4);
						num4 = (num3 & 384428157);
						num3 &= 1568058527;
						if (num > num)
						{
							num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
							num = num4;
							num3 = (num4 | 470886037);
							num2 = ~num2;
							num = *(ref num3 + (IntPtr)num4);
							num2 = num3 * num4;
							num3 = Config.T7p7bFhSnA;
						}
						num4 = num4;
					}
					num3 = (int)((sbyte)num4);
					num4 = (num2 & num4);
					if (num > num)
					{
						num4 = num2;
						if (num3 > num3)
						{
							num = (num4 & 1515825937);
							num = *(ref num3 + (IntPtr)num4);
							num3 = (num2 & num4);
							num3 = *(ref num3 + (IntPtr)num4);
							num = (num4 | num3);
							num3 = -num2;
							num2 = (int)((sbyte)num4);
							num = num2 * num4;
							num4 = num3;
						}
						if (num3 > num3)
						{
							num = num4;
							num2 = -num4;
							num3 = num / num4;
							num2 = (num4 ^ 1141619132);
							num2 = (num4 | num3);
							num3 /= num4;
							num2 = num3 * num4;
							num <<= 5;
							num4 = (int)((sbyte)num4);
							num3 = array[num3 + 8 - num2] + -5;
						}
						array[num + 8 - num4] = num - -1;
						num2 = num4;
					}
					num = (num4 | num3);
					if (num > num)
					{
						num4 = num * num4;
						num2 = 896366928;
						num2 = array[num3 + 5 - num] + 9;
					}
					num3 &= 1883843107;
					num4 /= num3;
					num4 = (array[num4 + 7 - num4] ^ 0);
					num2 = (int)((byte)num3);
					num = (array[num4 + 6 - num] ^ 7);
				}
				return this.<ParticleEmissionRate>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.RXTsLRzn0S) ^ *(&Config.RXTsLRzn0S)) != 0)
				{
					int[] array = new int[10];
					int num = (int)((sbyte)num);
					int num2;
					num2 >>= 6;
					int num3;
					array[num2 + 9 - num] = (num3 | 0);
					Config.T7p7bFhSnA = num3;
					num = (num2 ^ num);
					num = (num2 | num);
					num2 = ~num3;
					num = *(ref num + (IntPtr)num2);
					num = (array[num3 + 5 - num3] ^ 4);
					num3 = (int)((short)num2);
					if (num > num)
					{
						num3 = -num;
						num %= 964;
						num3 = (num2 | num);
					}
					num2 = array[num3 + 6 - num] + 5;
					*(ref num2 + (IntPtr)num) = num;
					Config.T7p7bFhSnA = num3;
					num3 &= 1651462461;
					num2 = num3 << 1;
					if (num2 > num2)
					{
						if (num2 > num2)
						{
							num = Config.T7p7bFhSnA;
							num = (int)((ushort)num);
							num3 ^= num2;
							num3 = num2 / num;
							*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
							num2 = -num2;
						}
						num2 = num3 % num2;
						num2 = ~num2;
						num3 = (int)((short)num2);
						num3 = (num | 1902023770);
					}
					num -= 276;
					array[num3 + 8 - num] = (num | 9);
					num = (num3 & num2);
					num = num;
					num2 = *(ref num + (IntPtr)num2);
					array[num + 7 - num2] = num2 - 9;
					num = *(ref num3 + (IntPtr)num2);
					if (num2 > num2)
					{
						num3 = (int)((byte)num3);
						if (num2 > num2)
						{
							*(ref num + (IntPtr)num2) = num2;
							num3 |= 788130432;
							num = num2;
							array[num + 5 - num2] = (num2 | 3);
							num2 = num;
							*(ref num3 + (IntPtr)num2) = num2;
							num -= num2;
							num2 = num3;
							num2 = -num;
							num3 |= num2;
						}
						if (num > num)
						{
							num2 = (num | num2);
							num2 = num - 974;
						}
						num3 *= 188;
						num2 = num3 / 100;
					}
				}
				this.<ParticleEmissionRate>k__BackingField = value;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000050 RID: 80 RVA: 0x002430DC File Offset: 0x002412DC
		// (set) Token: 0x06000051 RID: 81 RVA: 0x0024363C File Offset: 0x0024183C
		public unsafe bool EnableBoxESP
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.RsmOSYOknq) ^ *(&Config.RsmOSYOknq)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = num2 & 303777219;
					int num3;
					num2 = num3 - num2;
					num3 = -num2;
					num = (num2 & num);
					num = (int)((sbyte)num2);
					*(ref num3 + (IntPtr)num2) = num2;
					int num4;
					num2 = num4 * num2;
					num3 ^= 1829486489;
					num2 >>= 3;
					num = -num2;
					array[num + 9 - num2] = (num4 | 8);
					num = Config.T7p7bFhSnA;
					num3 = num % 206;
					if (num4 > num4)
					{
						num3 = (num4 | 1811351407);
						num3 -= num2;
						num2 *= 767;
						num2 |= 837853941;
						num3 = num2 >> 6;
						if (num3 > num3)
						{
							num4 = num + num2;
							num = (num3 | num2);
							num = (int)((ushort)num3);
							array[num3 + 6 - num] = num4 - 7;
							num3 = array[num + 8 - num4] + -7;
						}
						if (num > num)
						{
						}
						num = num2;
						num3 = num2;
					}
					num2 = num3 >> 4;
					num2 = -num3;
					num3 = (num & num2);
					num2 = num3 / num2;
					num2 &= num;
					num2 -= 647;
					num3 = array[num4 + 7 - num3] + -1;
					num4 = num2;
					num2 = -num2;
					num3 /= 398;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num3 = num2 - num;
					num4 = num2;
					num = num3 / num2;
					num3 = Config.T7p7bFhSnA;
					num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
					if (num3 > num3)
					{
						num3 = num2 >> 2;
						num = (array[num2 + 7 - num2] ^ 8);
						num4 = num4;
						if (num4 > num4)
						{
							Config.T7p7bFhSnA = num3;
							num4 = num3 * 39;
							num3 = Config.T7p7bFhSnA;
							num2 = (num3 | num2);
							num3 = num - 565;
							num = -num;
							array[num4 + 6 - num4] = (num3 | 8);
							num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
						}
						num = num3 / num2;
						if (num > num)
						{
							num4 = (num3 ^ 48161403);
							*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
							num3 &= num2;
							num4 = num2 - 369;
							num2 = *(ref num4 + (IntPtr)num2);
							num2 = num3 % 478;
							num2 = array[num4 + 6 - num2] + -3;
						}
						if (num > num)
						{
							num >>= 3;
							num = Config.T7p7bFhSnA;
							num4 = num + num2;
							num3 = ~num4;
							num2 = (num & num2);
							num4 = (int)((ushort)num2);
							array[num2 + 8 - num2] = num - 5;
						}
						array[num2 + 9 - num2] = num3 - -7;
					}
					array[num4 + 7 - num2] = (num4 | -5);
					num3 = (int)((byte)num4);
					num3 = *(ref num4 + (IntPtr)num2);
					*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					num = (num4 ^ num2);
					num = num4 * num2;
					num2 = num << 3;
					num4 = ~num2;
					num2 = (num | 405059687);
					num2 -= 5;
					*(ref num3 + (IntPtr)num2) = num2;
					num2 = (num3 ^ 1662025889);
				}
				return this.<EnableBoxESP>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.fkmrprauxl) ^ *(&Config.fkmrprauxl)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num3;
					int num2;
					int num4;
					if (num > num)
					{
						num2 = -num3;
						*(ref num2 + (IntPtr)num4) = num4;
						num2 = num % num4;
						Config.T7p7bFhSnA = num4;
						Config.T7p7bFhSnA = num;
						num2 = num3 / 503;
					}
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					num2 += num4;
					num4 = num % num4;
					num3 = Config.T7p7bFhSnA;
					num4 = Config.T7p7bFhSnA;
					num = num4 % num3;
					num4 = num / num4;
					*(ref num2 + (IntPtr)num4) = num4;
					num3 = ~num2;
					num = -num4;
					num = (num2 & 1876422460);
					num3 = num4 - num3;
					num3 = num4;
					if (num4 > num4)
					{
						num3 |= 1564022413;
						num3 = (int)((ushort)num);
						Config.T7p7bFhSnA = num;
						num3 = num4 % 946;
						if (num > num)
						{
							num2 = num4 * 592;
							num2 %= num4;
						}
						num2 = num3 / 861;
						num4 = num3;
						num4 = *(ref num3 + (IntPtr)num4);
						num2 = num3 >> 7;
					}
					num4 = num * num4;
					num2 = num4 - 389;
					num2 = num4 / num3;
					*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
					num2 = -num2;
					num3 = num - 785;
					*(ref num3 + (IntPtr)num4) = num4;
					num ^= 1696463072;
					num2 = num3 - num4;
					if (num3 > num3)
					{
						num3 = (array[num + 6 - num3] ^ 5);
						num3 &= num4;
						Config.T7p7bFhSnA = num2;
						*(ref num4 + (IntPtr)num3) = num3;
					}
					num = *(ref num2 + (IntPtr)num4);
					num2 |= num4;
					num2 = num3 - 630;
					if (num2 > num2)
					{
						*(ref num4 + (IntPtr)num3) = num3;
					}
					num3 = num2 + 106;
					num = *(ref num3 + (IntPtr)num4);
					num3 = num4 + num3;
					num2 = num3 / num4;
					num = (int)((short)num);
					num4 = -num;
					num = (array[num3 + 6 - num3] ^ -8);
					if (num4 > num4)
					{
						if (num > num)
						{
							num4 = -num4;
							num2 = num2;
							num ^= 2100890240;
							num3 = (num4 & 285750826);
							num3 = (num ^ 1373197610);
							*(ref num2 + (IntPtr)num4) = num4;
						}
						num4 = num;
						num = num4;
					}
					if (num2 > num2)
					{
						if (num > num)
						{
							num3 = (num4 ^ num3);
							num = num3 * 776;
							num = num4;
							Config.T7p7bFhSnA = num;
							num = num3 % num4;
							num4 = num3;
							num3 = num2 + 282;
						}
						if (num3 > num3)
						{
							num2 = (int)((short)num4);
							num4 ^= num3;
							num = num2 >> 2;
							num2 = (num4 ^ 2034274646);
							num2 = (int)((short)num);
							num2 = (int)((short)num3);
							num = num2 + 989;
						}
						num2 ^= num4;
						if (num > num)
						{
							num = -num4;
							num -= num4;
							array[num + 9 - num2] = num - 2;
							Config.T7p7bFhSnA = num4;
							*(ref num2 + (IntPtr)num4) = num4;
							num3 = 1772668842;
							*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
						}
						num2 = -num2;
						num4 = (array[num3 + 6 - num4] ^ 5);
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
						num4 = num << 2;
					}
					num3 = -num2;
					num2 = num3 * 644;
					if (num3 > num3)
					{
						array[num4 + 7 - num2] = (num | 0);
						num2 *= num4;
						num3 = Config.T7p7bFhSnA;
						if (num > num)
						{
							num4 = num3;
							num4 = num2;
							num4 = num >> 3;
							num4 = (array[num4 + 6 - num4] ^ -10);
							num2 = ~num;
							num2 = num3 * num4;
							num = -num;
							num3 = array[num2 + 6 - num] + 8;
						}
						num = num4;
						num3 = (num4 & num3);
						if (num4 > num4)
						{
							array[num2 + 7 - num4] = num - -9;
						}
						num2 = ~num;
						num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
						if (num > num)
						{
							num4 = *(ref num3 + (IntPtr)num4);
							num3 = Config.T7p7bFhSnA;
							num = num2 + num4;
							num4 = (num2 & num4);
							num ^= 1412200446;
							num2 = (int)((short)num2);
							num = ~num3;
							num = (num2 | num4);
							num = num3;
							num2 = (num4 & num3);
						}
					}
					num2 = Config.T7p7bFhSnA;
					num3 = num2 - 654;
					num = -num4;
					num4 = num >> 6;
				}
				this.<EnableBoxESP>k__BackingField = value;
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000052 RID: 82 RVA: 0x00243DA0 File Offset: 0x00241FA0
		// (set) Token: 0x06000053 RID: 83 RVA: 0x002443E8 File Offset: 0x002425E8
		public unsafe float BoxESPWidth
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.mR0UTJ02GJ) ^ *(&Config.mR0UTJ02GJ)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2 ^ 1738067690;
					int num3;
					num2 = num3 - num;
					int num4 = num2 / num;
					num = num4 * num;
					num -= 235;
					num4 = num;
					num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
					num4 = num4;
					if (num > num)
					{
						if (num > num)
						{
							num = num3;
						}
						num = Config.T7p7bFhSnA;
						*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					}
					num2 = -num4;
					num %= 747;
					num3 ^= 1523839844;
					num2 = num - num3;
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					if (num > num)
					{
						*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
						num2 /= num;
						num3 = Config.T7p7bFhSnA;
						*(ref num3 + (IntPtr)num) = num;
						array2[num4 + 9 - num4] = num3 - 2;
						num3 += num;
					}
					num = *(ref num3 + (IntPtr)num);
					num3 = num2 + 178;
					num4 = num >> 5;
					num = Config.T7p7bFhSnA;
					if (num > num)
					{
						num2 = num3 >> 1;
						array2[num2 + 7 - num2] = (num3 | 9);
						num4 = num3;
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
						if (num2 > num2)
						{
							num4 = num3;
							num3 = ~num;
							num = num3;
							num |= 124197385;
							num2 = num * num3;
							num4 = (int)((byte)num3);
							num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
							num2 = *(ref num + (IntPtr)num3);
							num = num3 / num;
						}
					}
					num4 = (int)((sbyte)num4);
					num4 = num3 % 464;
					if (num2 > num2)
					{
						num3 /= num;
						num3 = num4 / num;
						num3 = *(ref num2 + (IntPtr)num);
						num4 = num3 - num;
						num2 = ~num3;
						if (num3 > num3)
						{
							num4 = num3 + num;
						}
						num = (array2[num4 + 6 - num2] ^ -6);
						num2 |= num;
					}
					num2 = (num3 ^ num);
					num3 = num - num3;
					num3 = -num2;
					array2[num3 + 5 - num] = num2 - -10;
					num2 /= num;
					num2 = num;
					num4 <<= 2;
					num = *(ref num4 + (IntPtr)num);
					num2 = -num4;
					num3 *= 854;
					if (num4 > num4)
					{
						if (num > num)
						{
							num2 = num;
							num4 += 198;
							num2 = num2;
							num = num2;
							num = num4 % num;
							num = array[num3 + 7 - num3] + -9;
						}
					}
					if (num2 > num2)
					{
						if (num4 > num4)
						{
							num3 = Config.T7p7bFhSnA;
							num4 = num3;
							num3 <<= 6;
							Config.T7p7bFhSnA = num2;
							num3 = num << 4;
							num = (num3 ^ num);
							num2 = (num | 862416582);
							num4 = num2 >> 3;
						}
						num2 = num3 * 299;
						num3 = num;
						num3 = num3;
						num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
						num2 *= num;
						*(ref num2 + (IntPtr)num) = num;
						num3 = ~num;
					}
					num3 ^= 696017727;
					num4 = array2[num3 + 9 - num] + 9;
					num4 = num * num3;
					num4 = (num3 ^ 339055941);
					if (num3 > num3)
					{
						if (num > num)
						{
							num = (num2 | 786681537);
							num = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
							num2 = Config.T7p7bFhSnA;
							num4 = -num4;
							num2 = num3 / 12;
							num4 = -num;
						}
						array2[num3 + 7 - num3] = (num2 | -8);
					}
					num = (num3 ^ num);
					array2[num3 + 6 - num3] = num2 - -5;
					num2 = num * 173;
					Config.T7p7bFhSnA = num;
					num4 = num3 * num;
					num3 = -num2;
				}
				return this.<BoxESPWidth>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.yo7yTv1MoD) ^ *(&Config.yo7yTv1MoD)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num3;
					int num2;
					if (num > num)
					{
						num2 = ~num3;
					}
					int num4;
					int num5;
					if (num2 > num2)
					{
						num3 = ~num4;
						num = (int)((ushort)num4);
						num = Config.T7p7bFhSnA;
						if (num2 > num2)
						{
							Config.T7p7bFhSnA = num5;
							array2[num4 + 6 - num] = num4 - -6;
							num3 = num5 + num;
							num5 *= num;
							num4 = num;
							*(ref num2 + (IntPtr)num) = num;
						}
						array[num4 + 7 - num2] = num - -5;
					}
					num5 ^= num;
					num3 = (int)((ushort)num);
					num = ~num3;
					num2 = 63581499;
					num5 = num4 >> 7;
					num3 = num << 4;
					num4 = (num3 & 391972139);
					num5 = num + 512;
					array[num4 + 9 - num5] = (num5 | 2);
					num2 = num * 622;
					num4 *= 450;
					num5 = num;
					num = num2 >> 5;
					num4 = num2 - num;
					num3 = -num3;
					num4 = num2 - num;
					num3 = -num2;
					array2[num3 + 8 - num3] = (num | 0);
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num2 = num;
					if (num5 > num5)
					{
						if (num2 > num2)
						{
							num5 = array[num5 + 6 - num5] + -3;
							num = (int)((ushort)num5);
							num2 = (int)((ushort)num3);
							num |= 1782022691;
							num5 = (num3 ^ num);
						}
						num = array[num3 + 9 - num2] + 9;
						if (num3 > num3)
						{
							num = (num5 ^ num);
							num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num5);
							*(ref num5 + (IntPtr)num) = num;
						}
						num3 = num4 % 153;
						array[num2 + 9 - num] = num - 4;
						num4 = num5;
						num2 = 2010016655;
						num3 = Config.T7p7bFhSnA;
						num2 ^= 867320541;
					}
					num5 |= num;
					num = -num4;
					num4 = num2 * num;
					if (num > num)
					{
						num = *(ref num4 + (IntPtr)num);
						num = num2 << 1;
					}
					num3 = -num2;
					if (num4 > num4)
					{
						*(ref Config.T7p7bFhSnA + (IntPtr)num5) = num5;
						num2 = num;
						num = num3;
						num3 = array2[num3 + 7 - num] + -6;
						num2 = num5 % num;
						num5 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
						num4 = ~num2;
					}
					Config.T7p7bFhSnA = num2;
					num4 = num - num3;
					num5 = num;
					num5 = (num3 ^ 756912166);
					num ^= num3;
					*(ref num4 + (IntPtr)num) = num;
					num5 = ~num3;
					num2 = num2;
					num2 += 216;
					num4 = ~num;
				}
				this.<BoxESPWidth>k__BackingField = value;
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000054 RID: 84 RVA: 0x00244874 File Offset: 0x00242A74
		// (set) Token: 0x06000055 RID: 85 RVA: 0x00244B20 File Offset: 0x00242D20
		public unsafe float BoxESPHeight
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.SKo5GqvmCd) ^ *(&Config.SKo5GqvmCd)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					array2[num + 9 - num] = (num | -2);
					int num2 = Config.T7p7bFhSnA;
					int num3 = num;
					num2 = ~num3;
					*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
					num3 *= 870;
					num = num2;
					num2 = (num3 | 1771548484);
					num3 = num - 245;
					array[num + 6 - num2] = (num3 | -10);
					if (num2 > num2)
					{
						num3 = *(ref num2 + (IntPtr)num);
						num = num3;
						num2 /= num;
						num3 = (num ^ num2);
						num3 = (num2 | num);
					}
					array2[num3 + 8 - num3] = (num | 2);
					num3 = num2;
					num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
					num %= num2;
					num3 = -num;
					num3 = (num2 & 1943876255);
					num2 = num;
					num3 = 1295893904;
					num += 265;
					num2 = (int)((ushort)num);
					if (num3 > num3)
					{
						num3 = num2;
						num3 = num2 * num;
						num = num2 - 725;
						num2 = -num;
						num2 = num3 - 691;
					}
					*(ref num3 + (IntPtr)num2) = num2;
					num = (int)((ushort)num2);
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					if (num3 > num3)
					{
						num &= 791783646;
						num3 = array[num2 + 6 - num3] + 7;
						num2 -= 814;
					}
					array2[num + 7 - num3] = (num3 | -9);
					num3 = num2;
					*(ref num + (IntPtr)num2) = num2;
				}
				return this.<BoxESPHeight>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.0EzOpA2S4I) ^ *(&Config.0EzOpA2S4I)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = ~num2;
					int num3;
					array[num3 + 9 - num] = num - 8;
					*(ref num + (IntPtr)num3) = num3;
					num3 += num2;
					num = (array[num + 8 - num] ^ 5);
					num2 = num3 - 737;
					if (num > num)
					{
						num2 = num3 - 530;
						num = Config.T7p7bFhSnA;
						num2 = (int)((byte)num);
						num3 = (int)((ushort)num3);
						num3 = (array[num2 + 5 - num] ^ -5);
						num = (num3 | num2);
						num = (num2 | 1792474438);
						if (num2 > num2)
						{
							num = num3;
							num = (array[num + 6 - num2] ^ -1);
						}
					}
					Config.T7p7bFhSnA = num3;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num3 = 1563353204;
					num = (array[num + 9 - num] ^ -3);
					if (num3 > num3)
					{
						Config.T7p7bFhSnA = num2;
						if (num > num)
						{
							Config.T7p7bFhSnA = num;
							num2 >>= 1;
							num2 = (int)((short)num);
							Config.T7p7bFhSnA = num2;
						}
						if (num2 > num2)
						{
							num3 = num * 203;
						}
						num2 = -num2;
						if (num > num)
						{
							num2 = (int)((sbyte)num);
						}
					}
					num = -num2;
					num3 = num3;
					num3 = -num3;
					num = num3 * num2;
					num3 += num2;
					num2 = num3;
					if (num2 > num2)
					{
						num3 ^= 2000129642;
						num2 = (num & num3);
						if (num3 > num3)
						{
							num2 = num3 % num2;
							num = -num3;
							num3 = num3;
							num2 = -num3;
						}
					}
					num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					num = num2 * 489;
					num3 |= num2;
					num2 = ~num;
					num3 = -num2;
					num2 = num % 70;
					num2 >>= 1;
					num2 = num;
					num2 = num2;
					num = num2 + num3;
					num = -num;
					if (num3 > num3)
					{
						if (num3 > num3)
						{
							num2 |= num3;
							array[num2 + 7 - num3] = (num2 | -5);
							num3 ^= num2;
							num3 = num2;
							array[num2 + 8 - num2] = num3 - 9;
						}
						array[num2 + 7 - num] = num2 - 1;
					}
					num3 = ~num;
					num = num2 + num3;
					num3 = (int)((sbyte)num);
					num = -num2;
					num3 = num * num3;
					num2 = (num3 & 120789744);
					num2 = *(ref num2 + (IntPtr)num3);
					if (num > num)
					{
						array[num3 + 6 - num3] = num2 - -4;
						if (num2 > num2)
						{
							array[num + 5 - num3] = num - -10;
							num = Config.T7p7bFhSnA;
							*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
							num = num3 % num2;
							*(ref num + (IntPtr)num3) = num3;
							num3 = num;
						}
						num = (int)((byte)num);
					}
					num3 = (num ^ 1859132955);
					array[num2 + 9 - num2] = num3 - 6;
					num3 = *(ref num + (IntPtr)num3);
					num %= 181;
					num = (array[num3 + 9 - num2] ^ 0);
				}
				this.<BoxESPHeight>k__BackingField = value;
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000056 RID: 86 RVA: 0x00245070 File Offset: 0x00243270
		// (set) Token: 0x06000057 RID: 87 RVA: 0x00245568 File Offset: 0x00243768
		public unsafe Color32 BoxESPColor
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.hWdd10myY4) ^ *(&Config.hWdd10myY4)) != 0)
				{
					int[] array = new int[10];
					int num;
					int num2;
					if (num > num)
					{
						num = num2 - 795;
					}
					int num4;
					int num3 = array[num4 + 7 - num] + -6;
					if (num4 > num4)
					{
						*(ref num2 + (IntPtr)num4) = num4;
						num2 = *(ref num3 + (IntPtr)num2);
					}
					num4 = (int)((short)num4);
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					if (num > num)
					{
						Config.T7p7bFhSnA = num2;
					}
					int num5;
					if (num3 > num3)
					{
						Config.T7p7bFhSnA = num3;
						num3 = num5;
						num2 %= num4;
						num4 = num5;
						if (num3 > num3)
						{
							num4 -= 780;
							array[num4 + 7 - num] = num2 - 9;
							num = -num4;
							num2 = (int)((byte)num4);
						}
						num3 = (array[num5 + 6 - num4] ^ -8);
					}
					num5 = (int)((byte)num);
					num5 = ~num4;
					num5 = num3 / 876;
					num2 = 1981840544;
					num3 = -num3;
					num = num4 / num2;
					if (num5 > num5)
					{
						if (num3 > num3)
						{
							num2 = num * 325;
							*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
							num = num5 + 618;
							num4 = num2;
							Config.T7p7bFhSnA = num;
							num4 -= 505;
						}
						num3 = num5 - 215;
						num4 = num2;
						num = *(ref num + (IntPtr)num2);
					}
					if (num3 > num3)
					{
						num4 = (num5 & num2);
						num4 >>= 1;
						*(ref Config.T7p7bFhSnA + (IntPtr)num5) = num5;
						num4 = num4;
						num5 = num3;
						num2 = (num5 | 528478966);
						num2 += num4;
						num3 = (int)((byte)num3);
						num = 474136694;
					}
					num2 = 1870122153;
					num5 = num3;
					num2 = num4;
					num = num4 / num2;
					num2 = array[num3 + 8 - num4] + 0;
					num2 = -num;
					num = num2 / num4;
					num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
					num5 = num3 * num2;
					num5 = num3 + 945;
					num = (int)((sbyte)num);
					if (num2 > num2)
					{
						num = num;
						num2 = (int)((short)num5);
						num2 = (num3 | num2);
						num4 = -num5;
					}
					num5 = num3 % 277;
					if (num5 > num5)
					{
						if (num5 > num5)
						{
							array[num3 + 7 - num4] = (num3 | -1);
							num2 = num;
						}
					}
					num = Config.T7p7bFhSnA;
					num4 = (int)((sbyte)num2);
					num = num2 % 463;
					if (num3 > num3)
					{
						num4 = num5 / num2;
						num4 = Config.T7p7bFhSnA;
					}
					num = num2;
					if (num3 > num3)
					{
						num4 = (int)((ushort)num);
						num3 |= num2;
						num4 = num << 7;
						num5 = *(ref num + (IntPtr)num2);
						num2 = (int)((ushort)num2);
						num4 = num / num2;
						num2 = num5 * 24;
					}
					num4 = num2 % num4;
					num = (int)((byte)num3);
					num = (num2 | 1026239960);
					num4 = Config.T7p7bFhSnA;
					num2 = ~num2;
					num = (int)((sbyte)num);
				}
				return this.<BoxESPColor>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.0OFuTcm4Om) ^ *(&Config.0OFuTcm4Om)) != 0)
				{
					int[] array = new int[10];
					int num;
					num *= 705;
					int num2;
					num = (int)((ushort)num2);
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num);
					num2 = (int)((sbyte)num);
					int num3;
					num2 = num3 - 177;
					num3 = num / 919;
					if (num3 > num3)
					{
						if (num > num)
						{
							num2 = (num & 297451722);
							num3 = num / 609;
							num2 = num % num3;
							num3 = num2;
							num = num;
							num3 %= 627;
							num2 += num3;
							num2 |= num3;
							num = (int)((byte)num2);
						}
						num3 = (num ^ num3);
						array[num2 + 5 - num3] = num2 - 6;
						num2 = (num3 & num2);
						if (num2 > num2)
						{
							*(ref num + (IntPtr)num3) = num3;
						}
						if (num2 > num2)
						{
							num = (num3 | num2);
							num3 = (num ^ 629800453);
							num3 = num2;
							num2 = num3 / 898;
							num2 = num3;
						}
					}
					num3 = (num2 ^ 1700042108);
					num = array[num3 + 9 - num] + 4;
					num3 = (num2 | num3);
					num += num3;
					num3 = num2 << 1;
					*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					num2 = num3;
					num3 = (int)((byte)num3);
					num = -num3;
					num |= 275606070;
					num3 = num2 / 514;
					num2 = (num & num3);
					if (num > num)
					{
						if (num > num)
						{
							num *= 404;
							*(ref num3 + (IntPtr)num2) = num2;
							num3 = (int)((short)num2);
							num = -num;
							num2 = num;
						}
						num2 = num * num3;
						num2 = (int)((ushort)num3);
						num /= num3;
						num = (int)((byte)num);
						if (num3 > num3)
						{
							num = *(ref num3 + (IntPtr)num2);
							num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
							num = num3;
							num2 = -num3;
							num2 = num3 - num2;
						}
					}
					num3 ^= 301798676;
					num3 = num % num3;
					*(ref num3 + (IntPtr)num2) = num2;
					if (num2 > num2)
					{
						if (num > num)
						{
							num3 = (num2 & num3);
							num = num3 + num2;
							num2 = num % num3;
							num3 = num2 / 308;
						}
						num -= num3;
						num3 = ~num2;
						*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
						num = Config.T7p7bFhSnA;
						num = -num2;
						num3 = 987849121;
						num3 &= 1355080184;
						if (num > num)
						{
							num += 394;
							num2 = (num | num3);
							array[num3 + 8 - num] = (num2 | 8);
							num2 = num3;
							num &= num3;
						}
						num = num3;
					}
					num3 = (num2 & 1989569163);
					num /= num3;
					num3 = *(ref num2 + (IntPtr)num3);
					num3 = num2 + num3;
					num = (num2 | 852894001);
				}
				this.<BoxESPColor>k__BackingField = value;
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x06000058 RID: 88 RVA: 0x00245A04 File Offset: 0x00243C04
		// (set) Token: 0x06000059 RID: 89 RVA: 0x00245EC8 File Offset: 0x002440C8
		public unsafe Color32 BoxESPOuterColor
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.YOzmTuysIT) ^ *(&Config.YOzmTuysIT)) != 0)
				{
					int[] array = new int[10];
					int num = Config.T7p7bFhSnA;
					num >>= 1;
					int num2;
					num2 /= 207;
					int num3;
					array[num + 7 - num2] = (num3 | 0);
					if (num > num)
					{
						num3 = (num | 876305454);
						array[num2 + 5 - num3] = num3 - 5;
						*(ref num + (IntPtr)num2) = num2;
						num3 += num2;
						num2 = num3 % 645;
						if (num3 > num3)
						{
							num2 -= num;
							num3 = (num2 | num);
							num2 |= num;
							*(ref num3 + (IntPtr)num2) = num2;
							*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
						}
					}
					num2 = (int)((short)num);
					num3 = (int)((sbyte)num2);
					num += num2;
					num = (array[num + 8 - num2] ^ -6);
					num = num3 - 673;
					num3 |= 1997452530;
					num >>= 2;
					num = ~num;
					num3 = array[num2 + 9 - num3] + 3;
					num2 = num >> 4;
					array[num2 + 5 - num] = (num3 | -8);
					if (num > num)
					{
						num |= num2;
						num *= 688;
					}
					array[num + 8 - num3] = num - 7;
					if (num2 > num2)
					{
						num2 = (array[num + 5 - num3] ^ -3);
						num2 <<= 7;
						num2 = num % 705;
						num3 = (num2 & num);
						num3 = ~num2;
						num = 507263823;
						num2 = num;
					}
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					num2 = num / num2;
					num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					num2 += num;
					if (num > num)
					{
						Config.T7p7bFhSnA = num2;
						num3 = *(ref num + (IntPtr)num2);
						if (num2 > num2)
						{
							num2 = num3 / 823;
							num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
							num = (num2 & 1260671770);
							num = num3 - num2;
							num3 = (num2 & num);
							num3 = (int)((short)num2);
						}
					}
					num = Config.T7p7bFhSnA;
					num = (array[num + 5 - num3] ^ 9);
					num3 = ~num;
					num = array[num3 + 8 - num2] + 2;
					num3 = num2 / num;
					if (num3 > num3)
					{
						num = ~num;
						num3 = num * num2;
						num = num2 % num;
						num2 = (num ^ 60481104);
						array[num3 + 9 - num2] = num - -3;
						if (num > num)
						{
							num3 = (int)((sbyte)num);
							num = Config.T7p7bFhSnA;
							array[num + 5 - num2] = (num | 1);
							num3 ^= 1593839907;
						}
						num = num3 + 502;
						Config.T7p7bFhSnA = num2;
						array[num3 + 5 - num2] = num2 - -7;
						num3 = num % 970;
					}
				}
				return this.<BoxESPOuterColor>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.3iRfg5qKEP) ^ *(&Config.3iRfg5qKEP)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = num2 >> 1;
					int num3;
					int num4;
					if (num3 > num3)
					{
						num4 = *(ref num2 + (IntPtr)num4);
					}
					*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
					*(ref num4 + (IntPtr)num2) = num2;
					num3 = (array2[num3 + 8 - num4] ^ -1);
					num4 = num2;
					if (num3 > num3)
					{
						array[num3 + 7 - num] = num3 - 3;
						num3 = num2 + num4;
						if (num4 > num4)
						{
							num2 = *(ref num3 + (IntPtr)num2);
							num = num2 / 326;
							num = num3 + num2;
						}
						num = (num3 ^ num2);
						num4 = array[num3 + 9 - num2] + -8;
						num3 = (array[num3 + 7 - num3] ^ -5);
						Config.T7p7bFhSnA = num3;
						num4 = (num2 & num4);
					}
					num = num2;
					num = (int)((ushort)num2);
					num3 = -num2;
					num2 = num4 / num2;
					num2 = 544837128;
					num = num2;
					array[num + 5 - num3] = (num | -6);
					num3 = ~num3;
					num %= 426;
					num4 = (num2 | 1127026156);
					num = ~num4;
					if (num4 > num4)
					{
						num &= 1366718435;
						array[num + 8 - num2] = num3 - -6;
					}
					if (num2 > num2)
					{
						num3 = *(ref num2 + (IntPtr)num4);
						num3 = num2;
						if (num4 > num4)
						{
							num = num4 * num2;
							num = num2 - 237;
							num2 >>= 4;
							num = num4;
						}
						num4 = num2 % num4;
						num4 = array2[num3 + 8 - num3] + -7;
						num4 = ~num4;
						num2 = num4;
						num2 <<= 6;
						num2 = num;
					}
					num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num4);
					num2 = 670862696;
					num4 = Config.T7p7bFhSnA;
					num = num4 - 149;
					Config.T7p7bFhSnA = num;
					array[num4 + 8 - num2] = (num2 | 7);
					num = num2;
					num3 = num3;
					num2 = ~num;
					*(ref num3 + (IntPtr)num2) = num2;
					num = (num3 ^ 791210062);
					num = (int)((byte)num2);
					num2 = -num2;
					num4 = -num3;
					num2 = num;
					num = num3 + 138;
					if (num > num)
					{
						num4 = (num3 | 234123668);
						num4 = num3 << 5;
						num3 = *(ref num3 + (IntPtr)num2);
						if (num2 > num2)
						{
							num3 = (num4 & 820813596);
							num = num4 << 3;
							num = num4 % 589;
							num3 = num2;
							num3 %= num2;
							num2 = *(ref num + (IntPtr)num2);
							array[num2 + 6 - num2] = (num | 9);
							num3 = num2 - num4;
							num4 = num - num2;
						}
						num2 /= 750;
						num2 = num4;
						if (num4 > num4)
						{
							num3 = num2 + num4;
							num3 = array2[num2 + 7 - num4] + 5;
							array[num + 5 - num] = (num2 | 0);
							num = 939746423;
							num2 = (num & 201117133);
							num3 = (num & 119200277);
							num3 = -num4;
							num3 >>= 5;
						}
						if (num3 > num3)
						{
							num = *(ref num2 + (IntPtr)num4);
							num3 = 725723497;
						}
						*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
						num4 = num;
					}
					num3 = num - num2;
					num2 = (int)((short)num3);
					num = ~num;
				}
				this.<BoxESPOuterColor>k__BackingField = value;
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x0600005A RID: 90 RVA: 0x00246480 File Offset: 0x00244680
		// (set) Token: 0x0600005B RID: 91 RVA: 0x00246764 File Offset: 0x00244964
		public unsafe int LineCurve
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.D6NInm8F5M) ^ *(&Config.D6NInm8F5M)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = num2 << 4;
					int num4;
					int num3 = num - num4;
					num2 += num4;
					num4 = num2 << 6;
					num3 |= num4;
					num2 = (int)((sbyte)num2);
					num4 = -num4;
					Config.T7p7bFhSnA = num2;
					if (num4 > num4)
					{
						if (num > num)
						{
							num3 = num4 * 982;
							num4 /= 635;
							num = num4 << 7;
							num2 = -num;
							num3 = num2 / num4;
							num3 = -num3;
							num2 >>= 4;
							array[num3 + 9 - num] = num2 - -1;
							num4 = (num3 ^ 98038246);
						}
						num3 ^= 935751141;
						num = num;
						num2 = num2;
						if (num > num)
						{
							num4 = num2 % num4;
						}
						num3 = -num2;
						num3 = num - num4;
					}
					num = num2 - 441;
					num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
					if (num3 > num3)
					{
						num2 = (int)((byte)num);
						num3 = ~num;
						num3 = num >> 2;
						num2 |= 138200782;
					}
					num3 = num4 / 191;
					num3 = num2 - 455;
					num4 = (num3 ^ num4);
					Config.T7p7bFhSnA = num;
					array[num3 + 9 - num3] = (num2 | -6);
					num = (int)((short)num2);
					num3 = *(ref Config.T7p7bFhSnA + (IntPtr)num3);
					num2 = (int)((byte)num3);
					num2 = (array[num4 + 5 - num3] ^ 6);
					num4 = (num2 & num4);
					if (num3 > num3)
					{
						num = num3 << 6;
					}
					num4 = num2 << 3;
					array[num4 + 7 - num4] = num2 - 5;
					num4 = num2;
				}
				return this.<LineCurve>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.X7ESuSh0KH) ^ *(&Config.X7ESuSh0KH)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num;
					int num2;
					int num3;
					int num4;
					if (num > num)
					{
						num2 = ~num;
						num3 /= 286;
						num2 = -num;
						num4 = *(ref Config.T7p7bFhSnA + (IntPtr)num);
					}
					num4 = Config.T7p7bFhSnA;
					num3 = (int)((byte)num2);
					num2 &= num4;
					num4 = (int)((ushort)num4);
					num = (num4 & 491988357);
					num = num4 % num2;
					num3 = (array2[num2 + 9 - num2] ^ -4);
					array[num2 + 5 - num3] = (num4 | 0);
					num2 = num3;
					num2 = num % 398;
					Config.T7p7bFhSnA = num4;
					num = -num3;
					num2 = num4;
					num = Config.T7p7bFhSnA;
					array2[num3 + 8 - num2] = num2 - 7;
					array2[num + 5 - num4] = num4 - -8;
					if (num > num)
					{
						num4 = (array2[num4 + 7 - num2] ^ -10);
						num4 = 2145940089;
						num4 = num3 * 830;
						num4 = (num & 469531179);
						num2 = ~num3;
						num3 = num * num2;
						num = -num;
						num4 = 243473066;
					}
					num3 = num / 660;
					num4 = num3;
					num2 = num3;
					num = num2;
					num2 = ~num3;
					array[num2 + 9 - num2] = num3 - -4;
					if (num > num)
					{
						num4 <<= 4;
						array2[num2 + 7 - num3] = num4 - 2;
						if (num2 > num2)
						{
							num3 = num >> 7;
							num = (int)((byte)num3);
							num4 = Config.T7p7bFhSnA;
							array[num3 + 8 - num3] = (num4 | 3);
							num = (int)((byte)num4);
							num = num3 / 925;
						}
						num4 = (num3 ^ 1445696631);
						if (num2 > num2)
						{
							num = num2;
							*(ref Config.T7p7bFhSnA + (IntPtr)num3) = num3;
							num2 -= num4;
							num4 = num2 >> 5;
						}
						num = num2 / 316;
						if (num > num)
						{
							num4 = (array[num4 + 8 - num3] ^ -1);
							num = (num3 ^ num2);
							num4 = -num3;
							array[num4 + 8 - num2] = num2 - -3;
						}
					}
					num3 = (int)((ushort)num2);
					num4 = num2 + num4;
					num2 = *(ref num4 + (IntPtr)num2);
					num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					*(ref num2 + (IntPtr)num4) = num4;
					num2 = num4;
					num2 = *(ref num4 + (IntPtr)num2);
					num2 = (num3 & num2);
				}
				this.<LineCurve>k__BackingField = value;
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x0600005C RID: 92 RVA: 0x00246B80 File Offset: 0x00244D80
		// (set) Token: 0x0600005D RID: 93 RVA: 0x00246D90 File Offset: 0x00244F90
		public unsafe float WaveFrequency
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.B3pFBR6jNX) ^ *(&Config.B3pFBR6jNX)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num3;
					int num = num2 ^ num3;
					num >>= 4;
					num = num3 * num2;
					int num4 = (int)((byte)num);
					num4 += 254;
					num3 &= 414010890;
					*(ref num4 + (IntPtr)num2) = num2;
					num = *(ref num2 + (IntPtr)num3);
					if (num3 > num3)
					{
						array[num3 + 5 - num4] = (num4 | -3);
						num4 = num2;
						array[num + 8 - num] = num4 - 6;
						num4 = array[num3 + 5 - num4] + -1;
						num = -num4;
						num = ~num3;
					}
					num = num3 % num2;
					num3 += 509;
					num2 = num4 % 665;
					num4 = (num ^ num2);
					num3 = (int)((ushort)num3);
					num2 = num4;
					num = (num2 | num3);
					num = num4 << 5;
					if (num2 > num2)
					{
						num2 = num3 % 789;
						*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
						num2 = num - num2;
						num3 = num3;
						num2 = -num2;
					}
					if (num3 > num3)
					{
						num3 = (num4 | 625766687);
					}
					num <<= 6;
					num = (num2 ^ 206516296);
				}
				return this.<WaveFrequency>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.wb09jbAr9q) ^ *(&Config.wb09jbAr9q)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = array2[num2 + 5 - num] ^ 9;
					int num3 = -num;
					num /= num2;
					num2 = num2;
					int num4;
					if (num4 > num4)
					{
						num2 = Config.T7p7bFhSnA;
						num2 = num + num2;
						num = (int)((byte)num3);
						num3 = -num2;
					}
					num = ~num2;
					*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
					num += num2;
					num = num4 >> 1;
					num = num4 - num2;
					num4 = Config.T7p7bFhSnA;
					if (num4 > num4)
					{
						num4 = num2;
						num4 = Config.T7p7bFhSnA;
						array2[num3 + 9 - num] = num - 8;
						num2 = num;
					}
					num4 |= 520371225;
					num = num4 - 435;
					num3 = ~num2;
					num3 = num2 * num4;
					num4 = 979972106;
					if (num4 > num4)
					{
						*(ref num2 + (IntPtr)num4) = num4;
						if (num3 > num3)
						{
							num3 = 1030290050;
							num3 = num * 88;
							num2 = (num | num2);
							num2 = num3;
							*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
							num3 = ~num;
							num2 = num4;
							num = (array2[num2 + 6 - num3] ^ -7);
							num2 = num4 - num2;
						}
						num = num3 - num2;
						array[num4 + 5 - num4] = num2 - -2;
						num4 = num2 / num4;
						num3 = (num | 408035735);
						num2 = array[num3 + 9 - num2] + 5;
						Config.T7p7bFhSnA = num2;
						num4 = num - num2;
						num = (int)((byte)num);
					}
					num = num2 * 502;
					num4 = num % 320;
					num3 = (num4 | num2);
					Config.T7p7bFhSnA = num;
					num4 = (num3 | num2);
					num = (num4 ^ num2);
					num = ~num2;
					num = (int)((short)num4);
					*(ref num4 + (IntPtr)num2) = num2;
					num = Config.T7p7bFhSnA;
				}
				this.<WaveFrequency>k__BackingField = value;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x0600005E RID: 94 RVA: 0x002470D0 File Offset: 0x002452D0
		// (set) Token: 0x0600005F RID: 95 RVA: 0x00247598 File Offset: 0x00245798
		public unsafe float WaveAmplitude
		{
			[CompilerGenerated]
			get
			{
				if ((*(&Config.vtx555e9vN) ^ *(&Config.vtx555e9vN)) != 0)
				{
					int[] array = new int[10];
					int[] array2 = new int[10];
					int num2;
					int num = *(ref num2 + (IntPtr)num);
					num2 *= 750;
					Config.T7p7bFhSnA = num2;
					int num3;
					if (num2 > num2)
					{
						num = num2 % num;
						num3 = 1485393883;
						num3 = num << 6;
						num = (num3 & num2);
					}
					num = num;
					*(ref num2 + (IntPtr)num) = num;
					if (num3 > num3)
					{
						num3 = num;
						num2 = (int)((ushort)num);
						*(ref Config.T7p7bFhSnA + (IntPtr)num) = num;
						num2 = num3 << 5;
						num2 -= 635;
						num3 = num - num2;
						if (num2 > num2)
						{
							num3 = num;
							num2 = -num2;
							Config.T7p7bFhSnA = num3;
							*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
							num = num;
							num = num2 * num;
							num3 = (num2 ^ 812436004);
							num2 = (int)((ushort)num);
						}
						if (num > num)
						{
							num2 /= 693;
							num = num2;
						}
						num3 = num;
					}
					if (num3 > num3)
					{
						num2 = array2[num2 + 5 - num3] + 1;
						num3 = (array2[num3 + 6 - num2] ^ 1);
						num = 2061749536;
						num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
						num = ~num2;
						num2 = (num ^ num2);
						num = (array[num3 + 8 - num] ^ 6);
					}
					num = ~num2;
					num3 %= num2;
					num2 |= 250686660;
					num3 = num2;
					num = (num2 & 925190844);
					num2 /= num;
					num = *(ref Config.T7p7bFhSnA + (IntPtr)num2);
					*(ref num2 + (IntPtr)num) = num;
					num3 = num >> 6;
					num = num3;
					num = num3 / num2;
					num2 = num3 * 339;
					num3 = (num2 | 1936575215);
					num3 = *(ref num + (IntPtr)num2);
					num = -num;
					if (num3 > num3)
					{
						num = (num3 & num2);
						num *= 860;
						num2 = num * 722;
						num3 = (num ^ 1290810848);
					}
					num |= num2;
					num = num2;
					num2 = (num3 | 316862357);
					num = 865001341;
					num3 += num2;
					num2 %= 274;
					num2 = (num ^ num2);
					num2 = -num2;
					num = num3 % num2;
					num3 += 393;
					if (num2 > num2)
					{
						num = num2 / 958;
						num <<= 6;
						if (num3 > num3)
						{
							num += 892;
							num3 = 338452174;
							num2 = Config.T7p7bFhSnA;
							num = (array2[num2 + 6 - num3] ^ -9);
							num3 %= num2;
							num2 = num >> 2;
						}
						num3 = (num2 | 869745398);
						*(ref num + (IntPtr)num2) = num2;
						num2 = -num2;
						num3 = num3;
						num = num2;
					}
					num = (num2 ^ num);
					num3 = num2 << 5;
				}
				return this.<WaveAmplitude>k__BackingField;
			}
			[CompilerGenerated]
			set
			{
				if ((*(&Config.Y0A6NJRIHW) ^ *(&Config.Y0A6NJRIHW)) != 0)
				{
					int[] array = new int[10];
					int num2;
					int num = num2 ^ num;
					int num3;
					num = num3 + 250;
					num3 = (num2 | num);
					int num4;
					num3 = (array[num + 7 - num4] ^ -7);
					int num5 = num2;
					num3 = ~num3;
					if (num3 > num3)
					{
						num3 = num5 / num2;
						num5 = num4 << 6;
						num3 |= num2;
						num = (int)((sbyte)num3);
					}
					num4 = -num5;
					num |= num2;
					num3 = (int)((short)num4);
					num4 += 840;
					num5 = array[num3 + 5 - num2] + -5;
					num2 = num;
					num5 = (num3 ^ 1927241453);
					*(ref Config.T7p7bFhSnA + (IntPtr)num5) = num5;
					num5 = ~num2;
					num = (int)((ushort)num2);
					num = Config.T7p7bFhSnA;
					num3 = (int)((short)num3);
					num3 = (num5 | 972734243);
					num2 = num3 + num2;
					num *= num2;
					num2 /= num;
					num = num3 / num2;
					num2 = (num4 & num2);
					if (num3 > num3)
					{
						num2 = -num;
						num5 = Config.T7p7bFhSnA;
						num5 *= 948;
						num5 = num3 - num2;
						num5 = array[num + 6 - num3] + 5;
						num3 = -num2;
						num5 = -num4;
						array[num4 + 5 - num5] = (num2 | -3);
						num4 = num5 % 774;
						num2 = ~num4;
					}
					if (num3 > num3)
					{
						array[num5 + 7 - num5] = (num4 | -4);
						num5 = (array[num4 + 9 - num4] ^ -7);
						num4 = Config.T7p7bFhSnA;
						num = -num4;
						num5 = (int)((sbyte)num2);
						num4 = (num2 & num);
						Config.T7p7bFhSnA = num2;
						num5 = *(ref Config.T7p7bFhSnA + (IntPtr)num5);
					}
					num2 = num5 - num2;
					num5 = num2;
					num = (int)((short)num4);
					num4 = num2;
					num2 = (int)((sbyte)num5);
					num2 = (num3 & 1605979991);
				}
				this.<WaveAmplitude>k__BackingField = value;
			}
		}

		// Token: 0x06000060 RID: 96 RVA: 0x002478C8 File Offset: 0x00245AC8
		public unsafe Config()
		{
			int num = 21;
			if ((*(&Config.qZ1ha5GFsS) ^ *(&Config.qZ1ha5GFsS)) != 0)
			{
				int[] array = new int[10];
				int[] array2 = new int[10];
				int num3;
				int num2 = num3 | 1192447007;
				int num4;
				int num5;
				if (num4 > num4)
				{
					num5 = num3 * 499;
				}
				if (num4 > num4)
				{
					num4 = ~num4;
					num3 = -num3;
					if (num5 > num5)
					{
						*(ref num5 + (IntPtr)num4) = num4;
						num4 = num2 * 40;
						num2 = ~num3;
						num2 = ~num5;
						num5 = (int)((ushort)num5);
						num5 = num4 / num5;
					}
					num4 = num3 + num5;
					num5 = num3 << 3;
					num3 = ~num3;
					num2 = (array[num5 + 8 - num5] ^ -4);
					num5 = (int)((byte)num2);
				}
				*(ref num5 + (IntPtr)num4) = num4;
				num2 = *(ref Config.T7p7bFhSnA + (IntPtr)num5);
				num2 = num5;
				num3 = -num5;
				if (num4 > num4)
				{
					num4 = -num4;
					if (num4 > num4)
					{
						num2 = num3 >> 5;
					}
					num5 = num2 << 4;
					num2 = num2;
					num2 = Config.T7p7bFhSnA;
					num3 = num3;
					num2 = num3;
					num3 = -num4;
					num4 |= 1709087822;
				}
				num3 = array2[num4 + 8 - num3] + -2;
				num5 = num4 / 401;
				num4 = num5 % num4;
				num4 += num5;
				num2 = num4 * 825;
				num4 = num5 + num4;
				num3 = (int)((ushort)num4);
				num4 = (num5 & 1939995715);
				*(ref num3 + (IntPtr)num5) = num5;
				if (num2 > num2)
				{
					num5 = -num5;
					num2 = num5 * 647;
					num3 = num4 - 444;
					num3 = num4 % 709;
				}
				array[num2 + 7 - num3] = (num5 | -7);
				num5 = num4 + 257;
				num3 = num2 * num5;
				num3 ^= num5;
				num3 = ~num2;
				num3 = ~num2;
				num5 -= 44;
				num3 = (num2 ^ 1964931028);
				num2 = num5 / 692;
				if (num2 > num2)
				{
					num3 = (int)((byte)num4);
					if (num5 > num5)
					{
						*(ref Config.T7p7bFhSnA + (IntPtr)num2) = num2;
					}
					if (num5 > num5)
					{
						num2 = *(ref num2 + (IntPtr)num5);
						num4 = (num5 ^ num4);
						num2 = (array2[num3 + 9 - num5] ^ 2);
						*(ref Config.T7p7bFhSnA + (IntPtr)num4) = num4;
						num3 = num5;
						num3 ^= num5;
					}
					*(ref num5 + (IntPtr)num4) = num4;
					num2 = num4 % 824;
					*(ref num3 + (IntPtr)num5) = num5;
				}
				num4 = (int)((short)num3);
				if (num2 > num2)
				{
					num5 = -num5;
					*(ref num2 + (IntPtr)num5) = num5;
				}
				num4 = num2;
				if (num4 > num4)
				{
					array2[num2 + 9 - num3] = num5 - -10;
					num2 = (int)((ushort)num2);
					num5 = ~num3;
					Config.T7p7bFhSnA = num2;
					array[num2 + 6 - num4] = num5 - 1;
					num2 = num4 + num5;
					num3 = (num4 | num5);
					num3 = array2[num3 + 9 - num5] + 5;
					num2 = (num4 | 2106679645);
				}
				num5 = (num4 ^ num5);
				num2 = num5 % num4;
				num2 = num3 % num5;
				num4 = ~num5;
				num3 = num2 + 731;
				num2 = ~num4;
				num5 = ~num5;
			}
			float[] array3 = new float[num];
			int num6 = 616;
			if (num6 == 616)
			{
				array3[0] = 2.7559395E-31f;
				array3[1] = 2.7559395E-31f;
				array3[2] = 2.7559395E-31f;
				array3[3] = 2.2047516E-30f;
				array3[4] = 5.032394E+30f;
				array3[5] = 2.1868214E-29f;
				array3[6] = 8.819006E-30f;
				array3[7] = 1.5658332E-30f;
				array3[8] = 1.7594275E+31f;
				array3[9] = 7.829166E-31f;
				array3[10] = 1.0064788E+31f;
				array3[11] = 4.3985687E+30f;
				array3[12] = 1.7638012E-29f;
				float[] array4 = array3;
				int num7 = 0;
				float num8 = array3[0];
				float num9 = num8;
				int num10 = (int)((int)((404 == 0) ? (num9 - (float)76) : (num9 + (float)404)) << 6);
				num8 = array3[0];
				int num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array4[num7] = num11;
				float[] array5 = array3;
				int num12 = 1;
				num8 = array3[1];
				float num13 = num8;
				float num15;
				int num14 = (int)((-185 == 0) ? (num15 = num13 - (float)47) : (num15 = num13 + (float)-185));
				num10 = ((317 == 0) ? (num14 - 95) : ((int)(num15 + (float)317))) << 1;
				num8 = array3[1];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array5[num12] = num11;
				float[] array6 = array3;
				int num16 = 2;
				num8 = array3[2];
				float num17 = num8 % (float)71;
				int num18 = (int)((-500 == 0) ? (num17 - (float)81) : (num17 + (float)-500));
				num10 = ((420 == 0) ? (num18 - 86) : (num18 + 420)) * 429;
				num8 = array3[2];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array6[num16] = num11;
				float[] array7 = array3;
				int num19 = 3;
				num8 = array3[3];
				float num20 = num8;
				num10 = ((int)((494 == 0) ? (num20 - (float)64) : (num20 + (float)494)) + -78 >> 3) * 143;
				num8 = array3[3];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array7[num19] = num11;
				float[] array8 = array3;
				int num21 = 4;
				num8 = array3[4];
				num10 = (int)((num8 % (float)95 & (float)-497) * (float)-3 - (float)297);
				num8 = array3[4];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array8[num21] = num11;
				float[] array9 = array3;
				int num22 = 5;
				num8 = array3[5];
				float num23 = -num8 - (float)-132 & (float)-89;
				num10 = (int)((((-474 == 0) ? (num23 - (float)96) : (num23 + (float)-474)) + (float)218) * (float)-342);
				num8 = array3[5];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array9[num22] = num11;
				float[] array10 = array3;
				int num24 = 6;
				num8 = array3[6];
				num10 = (int)(-(int)(-(num8 * (float)81 * (float)-1) | (float)338));
				num8 = array3[6];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array10[num24] = num11;
				float[] array11 = array3;
				int num25 = 7;
				num8 = array3[7];
				num10 = (int)((num8 ^ (float)-137 ^ (float)-316) + (float)-238);
				num8 = array3[7];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array11[num25] = num11;
				float[] array12 = array3;
				int num26 = 8;
				num8 = array3[8];
				num10 = (int)(((int)(~(int)(num8 - (float)330)) << 1) % (float)37 - (float)266);
				num8 = array3[8];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array12[num26] = num11;
				float[] array13 = array3;
				int num27 = 9;
				num8 = array3[9];
				num10 = (((int)num8 >> 7) % 42 | -35);
				num8 = array3[9];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array13[num27] = num11;
				float[] array14 = array3;
				int num28 = 10;
				num8 = array3[10];
				float num29 = (num8 | (float)-55) + (float)95;
				num10 = (int)((171 == 0) ? (num29 - (float)92) : (num29 + (float)171));
				num8 = array3[10];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array14[num28] = num11;
				float[] array15 = array3;
				int num30 = 11;
				num8 = array3[11];
				num10 = (-((int)num8 + 108 - 174) >> 4) + -446;
				num8 = array3[11];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array15[num30] = num11;
				float[] array16 = array3;
				int num31 = 12;
				num8 = array3[12];
				num10 = (int)((num8 >> 4) - (float)-493 - (float)-183);
				num8 = array3[12];
				num11 = (int)(num8 ^ (float)num10 ^ (float)(855511595 ^ num10));
				array16[num31] = num11;
			}
			int[] array17 = new int[51];
			int num32 = 148;
			if (num32 == 148)
			{
				array17[0] = 1619013255;
				array17[1] = 1619013240;
				array17[2] = 1619013347;
				array17[3] = 1619013240;
				array17[4] = 1619013255;
				array17[5] = 1619013199;
				array17[6] = 1619013240;
				array17[7] = 1619013240;
				array17[8] = 1619013240;
				array17[9] = 1619013347;
				array17[10] = 1619013301;
				array17[11] = 1619013240;
				array17[12] = 1619013240;
				array17[13] = 1619013137;
				array17[14] = 1619013255;
				array17[15] = 1619013240;
				array17[16] = 1619013255;
				array17[17] = 1619013240;
				array17[18] = 1619013137;
				array17[19] = 1619013240;
				array17[20] = 1619013255;
				array17[21] = 1619013171;
				array17[22] = 1619013240;
				array17[23] = 1619013240;
				array17[24] = 1619013240;
				array17[25] = 1619013347;
				array17[26] = 1619013301;
				array17[27] = 1619013240;
				array17[28] = 1619013240;
				array17[29] = 1619013137;
				array17[30] = 1619013255;
				array17[31] = 1619013240;
				array17[32] = 1619013254;
				array17[33] = 1619013254;
				array17[34] = 1619013199;
				array17[35] = 1619013254;
				array17[36] = 1619013255;
				array17[37] = 1619013240;
				array17[38] = 1619013347;
				array17[39] = 1619013240;
				array17[40] = 1619013240;
				array17[41] = 1619013137;
				array17[42] = 1619013255;
				array17[43] = 1619013240;
				array17[44] = 1619012975;
				int[] array18 = array17;
				int num33 = 0;
				int num34 = ~(array17[0] - -403) + -270;
				int num35 = ((-212 == 0) ? (num34 - 78) : (num34 + -212)) + -45;
				array18[num33] = (array17[0] ^ num35 ^ (1619013255 ^ num35));
				int[] array19 = array17;
				int num36 = 1;
				num35 = (array17[1] % 16 & -355) + -267;
				array19[num36] = (array17[1] ^ num35 ^ (1619013255 ^ num35));
				int[] array20 = array17;
				int num37 = 2;
				int num38 = array17[2] >> 1;
				num35 = ((-7 == 0) ? (num38 - 37) : (num38 + -7)) % 86;
				array20[num37] = (array17[2] ^ num35 ^ (1619013255 ^ num35));
				int[] array21 = array17;
				int num39 = 3;
				int num40 = ~array17[3];
				num35 = ~(((170 == 0) ? (num40 - 55) : (num40 + 170)) ^ -155);
				array21[num39] = (array17[3] ^ num35 ^ (1619013255 ^ num35));
				int[] array22 = array17;
				int num41 = 4;
				int num42 = array17[4];
				num35 = (-((-293 == 0) ? (num42 - 75) : (num42 + -293)) - 332 << 4) % 89;
				array22[num41] = (array17[4] ^ num35 ^ (1619013255 ^ num35));
				int[] array23 = array17;
				int num43 = 5;
				int num44 = array17[5];
				int num45 = ((445 == 0) ? (num44 - 9) : (num44 + 445)) + 52;
				num35 = ((-109 == 0) ? (num45 - 95) : (num45 + -109));
				array23[num43] = (array17[5] ^ num35 ^ (1619013255 ^ num35));
				int[] array24 = array17;
				int num46 = 6;
				num35 = -(array17[6] * -293) << 5 >> 2;
				array24[num46] = (array17[6] ^ num35 ^ (1619013255 ^ num35));
				int[] array25 = array17;
				int num47 = 7;
				num35 = ((array17[7] >> 6) * 238 % 63 >> 3) - 7;
				array25[num47] = (array17[7] ^ num35 ^ (1619013255 ^ num35));
				int[] array26 = array17;
				int num48 = 8;
				num35 = -((array17[8] | 129) - 9);
				array26[num48] = (array17[8] ^ num35 ^ (1619013255 ^ num35));
				int[] array27 = array17;
				int num49 = 9;
				int num50 = array17[9];
				num35 = (((68 == 0) ? (num50 - 70) : (num50 + 68)) + -445 >> 3) * 303;
				array27[num49] = (array17[9] ^ num35 ^ (1619013255 ^ num35));
				int[] array28 = array17;
				int num51 = 10;
				int num52 = -array17[10] * 318;
				num35 = ((163 == 0) ? (num52 - 80) : (num52 + 163));
				array28[num51] = (array17[10] ^ num35 ^ (1619013255 ^ num35));
				int[] array29 = array17;
				int num53 = 11;
				int num54 = array17[11];
				int num55 = ((-99 == 0) ? (num54 - 7) : (num54 + -99)) ^ -416;
				num35 = ((184 == 0) ? (num55 - 88) : (num55 + 184));
				array29[num53] = (array17[11] ^ num35 ^ (1619013255 ^ num35));
				int[] array30 = array17;
				int num56 = 12;
				num35 = (array17[12] >> 2) - -49 - -295;
				array30[num56] = (array17[12] ^ num35 ^ (1619013255 ^ num35));
				int[] array31 = array17;
				int num57 = 13;
				int num58 = (array17[13] * 262 % 37 ^ -460) - 93;
				num35 = ((179 == 0) ? (num58 - 27) : (num58 + 179));
				array31[num57] = (array17[13] ^ num35 ^ (1619013255 ^ num35));
				int[] array32 = array17;
				int num59 = 14;
				num35 = array17[14] << 7 << 3;
				array32[num59] = (array17[14] ^ num35 ^ (1619013255 ^ num35));
				int[] array33 = array17;
				int num60 = 15;
				num35 = ~(-(array17[15] * -498 >> 5)) - 377;
				array33[num60] = (array17[15] ^ num35 ^ (1619013255 ^ num35));
				int[] array34 = array17;
				int num61 = 16;
				num35 = ~((array17[16] | -210) << 2 | -92) % 12;
				array34[num61] = (array17[16] ^ num35 ^ (1619013255 ^ num35));
				int[] array35 = array17;
				int num62 = 17;
				num35 = (array17[17] + 78) % 53 * 324 % 13 << 1;
				array35[num62] = (array17[17] ^ num35 ^ (1619013255 ^ num35));
				int[] array36 = array17;
				int num63 = 18;
				int num64 = array17[18] >> 7;
				int num66;
				int num65 = (-298 == 0) ? (num66 = num64 - 4) : (num66 = num64 + -298);
				int num67 = (-367 == 0) ? (num65 - 83) : (num66 + -367);
				num35 = ((-65 == 0) ? (num67 - 10) : (num67 + -65)) % 42;
				array36[num63] = (array17[18] ^ num35 ^ (1619013255 ^ num35));
				int[] array37 = array17;
				int num68 = 19;
				int num69 = array17[19];
				int num70 = ((301 == 0) ? (num69 - 81) : (num69 + 301)) * -2;
				num35 = (~((-179 == 0) ? (num70 - 40) : (num70 + -179)) & 433) + -122;
				array37[num68] = (array17[19] ^ num35 ^ (1619013255 ^ num35));
				int[] array38 = array17;
				int num71 = 20;
				int num72 = array17[20];
				num35 = (((-238 == 0) ? (num72 - 32) : (num72 + -238)) & -306) % 57;
				array38[num71] = (array17[20] ^ num35 ^ (1619013255 ^ num35));
				int[] array39 = array17;
				int num73 = 21;
				num35 = -(~(array17[21] % 12));
				array39[num73] = (array17[21] ^ num35 ^ (1619013255 ^ num35));
				int[] array40 = array17;
				int num74 = 22;
				int num75 = array17[22] - 109;
				int num77;
				int num76 = (269 == 0) ? (num77 = num75 - 20) : (num77 = num75 + 269);
				int num79;
				int num78 = (-391 == 0) ? (num79 = num76 - 30) : (num79 = num77 + -391);
				num35 = (((-235 == 0) ? (num78 - 90) : (num79 + -235)) & 472) % 75;
				array40[num74] = (array17[22] ^ num35 ^ (1619013255 ^ num35));
				int[] array41 = array17;
				int num80 = 23;
				num35 = ((((array17[23] + -210) % 35 & -163) - -306) % 47 ^ 142);
				array41[num80] = (array17[23] ^ num35 ^ (1619013255 ^ num35));
				int[] array42 = array17;
				int num81 = 24;
				int num82 = array17[24];
				num35 = ((-35 == 0) ? (num82 - 71) : (num82 + -35)) - 409 << 1;
				array42[num81] = (array17[24] ^ num35 ^ (1619013255 ^ num35));
				int[] array43 = array17;
				int num83 = 25;
				int num84 = (array17[25] * -152 - -213 | 335) >> 4;
				num35 = ((359 == 0) ? (num84 - 68) : (num84 + 359));
				array43[num83] = (array17[25] ^ num35 ^ (1619013255 ^ num35));
				int[] array44 = array17;
				int num85 = 26;
				num35 = ((array17[26] % 44 ^ 131) | -316) * 356;
				array44[num85] = (array17[26] ^ num35 ^ (1619013255 ^ num35));
				int[] array45 = array17;
				int num86 = 27;
				int num87 = -array17[27] << 1 & 145;
				num35 = ((225 == 0) ? (num87 - 2) : (num87 + 225));
				array45[num86] = (array17[27] ^ num35 ^ (1619013255 ^ num35));
				int[] array46 = array17;
				int num88 = 28;
				int num89 = array17[28];
				int num90 = ~(((197 == 0) ? (num89 - 18) : (num89 + 197)) >> 2);
				num35 = ((119 == 0) ? (num90 - 89) : (num90 + 119));
				array46[num88] = (array17[28] ^ num35 ^ (1619013255 ^ num35));
				int[] array47 = array17;
				int num91 = 29;
				num35 = (array17[29] * 488 >> 1) % 33;
				array47[num91] = (array17[29] ^ num35 ^ (1619013255 ^ num35));
				int[] array48 = array17;
				int num92 = 30;
				int num93 = (array17[30] & 126) + 336;
				num35 = ((-192 == 0) ? (num93 - 41) : (num93 + -192));
				array48[num92] = (array17[30] ^ num35 ^ (1619013255 ^ num35));
				int[] array49 = array17;
				int num94 = 31;
				int num95 = ~(-array17[31] * 415);
				num35 = ((6 == 0) ? (num95 - 19) : (num95 + 6)) % 23;
				array49[num94] = (array17[31] ^ num35 ^ (1619013255 ^ num35));
				int[] array50 = array17;
				int num96 = 32;
				num35 = ~(~(-(array17[32] % 76 >> 3) ^ 54));
				array50[num96] = (array17[32] ^ num35 ^ (1619013255 ^ num35));
				int[] array51 = array17;
				int num97 = 33;
				int num98 = array17[33] + 198;
				num35 = -(((31 == 0) ? (num98 - 86) : (num98 + 31)) << 2) + 76;
				array51[num97] = (array17[33] ^ num35 ^ (1619013255 ^ num35));
				int[] array52 = array17;
				int num99 = 34;
				int num100 = (array17[34] ^ -303) + 454;
				num35 = ((-177 == 0) ? (num100 - 93) : (num100 + -177)) % 87;
				array52[num99] = (array17[34] ^ num35 ^ (1619013255 ^ num35));
				int[] array53 = array17;
				int num101 = 35;
				num35 = ((array17[35] + -75) % 25 & -375) % 27;
				array53[num101] = (array17[35] ^ num35 ^ (1619013255 ^ num35));
				int[] array54 = array17;
				int num102 = 36;
				num35 = ((array17[36] % 1 << 3) * -43 ^ 429) * 464;
				array54[num102] = (array17[36] ^ num35 ^ (1619013255 ^ num35));
				int[] array55 = array17;
				int num103 = 37;
				int num104 = array17[37];
				num35 = (((-26 == 0) ? (num104 - 66) : (num104 + -26)) & 27) * 310;
				array55[num103] = (array17[37] ^ num35 ^ (1619013255 ^ num35));
				int[] array56 = array17;
				int num105 = 38;
				num35 = (~(array17[38] | 443) & -344 & -345);
				array56[num105] = (array17[38] ^ num35 ^ (1619013255 ^ num35));
				int[] array57 = array17;
				int num106 = 39;
				num35 = ~((array17[39] - 274) % 23);
				array57[num106] = (array17[39] ^ num35 ^ (1619013255 ^ num35));
				int[] array58 = array17;
				int num107 = 40;
				num35 = (array17[40] | 295) * 376;
				array58[num107] = (array17[40] ^ num35 ^ (1619013255 ^ num35));
				int[] array59 = array17;
				int num108 = 41;
				int num109 = ~array17[41];
				num35 = ((((77 == 0) ? (num109 - 76) : (num109 + 77)) % 78 & 173) % 4 & -66);
				array59[num108] = (array17[41] ^ num35 ^ (1619013255 ^ num35));
				int[] array60 = array17;
				int num110 = 42;
				int num111 = array17[42];
				num35 = ((((237 == 0) ? (num111 - 88) : (num111 + 237)) | 50) & -284);
				array60[num110] = (array17[42] ^ num35 ^ (1619013255 ^ num35));
				int[] array61 = array17;
				int num112 = 43;
				num35 = (~array17[43] % 23 + 188 | -202);
				array61[num112] = (array17[43] ^ num35 ^ (1619013255 ^ num35));
				int[] array62 = array17;
				int num113 = 44;
				num35 = (~((array17[44] % 1 ^ 111) << 5) << 7) + -179;
				array62[num113] = (array17[44] ^ num35 ^ (1619013255 ^ num35));
			}
			this.<PointerScale>k__BackingField = new Vector3(array3[0], array3[1], array3[2]);
			this.<PointerColorStart>k__BackingField = new Color32((byte)array17[0], (byte)array17[1], (byte)array17[2], (byte)array17[3]);
			this.<PointerColorEnd>k__BackingField = new Color32((byte)array17[4], (byte)array17[5], (byte)array17[6], (byte)array17[7]);
			this.<TriggeredPointerColorStart>k__BackingField = new Color32((byte)array17[8], (byte)array17[9], (byte)array17[10], (byte)array17[11]);
			this.<TriggeredPointerColorEnd>k__BackingField = new Color32((byte)array17[12], (byte)array17[13], (byte)array17[14], (byte)array17[15]);
			this.<LineWidth>k__BackingField = array3[3];
			this.<LineColorStart>k__BackingField = new Color32((byte)array17[16], (byte)array17[17], (byte)array17[18], (byte)array17[19]);
			this.<LineColorEnd>k__BackingField = new Color32((byte)array17[20], (byte)array17[21], (byte)array17[22], (byte)array17[23]);
			this.<TriggeredLineColorStart>k__BackingField = new Color32((byte)array17[24], (byte)array17[25], (byte)array17[26], (byte)array17[27]);
			this.<TriggeredLineColorEnd>k__BackingField = new Color32((byte)array17[28], (byte)array17[29], (byte)array17[30], (byte)array17[31]);
			this.<EnableAnimations>k__BackingField = (array17[32] != 0);
			this.<PulseSpeed>k__BackingField = array3[4];
			this.<PulseAmplitude>k__BackingField = array3[5];
			this.<EnableParticles>k__BackingField = (array17[33] != 0);
			this.<ParticleStartSize>k__BackingField = array3[6];
			this.<ParticleStartSpeed>k__BackingField = array3[7];
			this.<ParticleMaxCount>k__BackingField = array17[34];
			this.<ParticleEmissionRate>k__BackingField = array3[8];
			this.<EnableBoxESP>k__BackingField = (array17[35] != 0);
			this.<BoxESPWidth>k__BackingField = array3[9];
			this.<BoxESPHeight>k__BackingField = array3[10];
			this.<BoxESPColor>k__BackingField = new Color32((byte)array17[36], (byte)array17[37], (byte)array17[38], (byte)array17[39]);
			this.<BoxESPOuterColor>k__BackingField = new Color32((byte)array17[40], (byte)array17[41], (byte)array17[42], (byte)array17[43]);
			this.<LineCurve>k__BackingField = array17[44];
			this.<WaveFrequency>k__BackingField = array3[11];
			this.<WaveAmplitude>k__BackingField = array3[12];
			base..ctor();
		}

		// Token: 0x04004B26 RID: 19238 RVA: 0x00015B88 File Offset: 0x00013D88
		static int HxNZeVMqK6;

		// Token: 0x04004B27 RID: 19239 RVA: 0x00015B90 File Offset: 0x00013D90
		static int T7p7bFhSnA;

		// Token: 0x04004B28 RID: 19240 RVA: 0x00015B98 File Offset: 0x00013D98
		static int KvSsOsAW6B;

		// Token: 0x04004B29 RID: 19241 RVA: 0x00015BA0 File Offset: 0x00013DA0
		static int p4qrh9FJv6;

		// Token: 0x04004B2A RID: 19242 RVA: 0x00015BA8 File Offset: 0x00013DA8
		static int w7TvUrPYPD;

		// Token: 0x04004B2B RID: 19243 RVA: 0x00015BB0 File Offset: 0x00013DB0
		static int MT8pyVefLv;

		// Token: 0x04004B2C RID: 19244 RVA: 0x00015BB8 File Offset: 0x00013DB8
		static int UztIRZQ8ab;

		// Token: 0x04004B2D RID: 19245 RVA: 0x00015BC0 File Offset: 0x00013DC0
		static int 9YgrONchXh;

		// Token: 0x04004B2E RID: 19246 RVA: 0x00015BC8 File Offset: 0x00013DC8
		static int dmG3zV6B2L;

		// Token: 0x04004B2F RID: 19247 RVA: 0x00015BD0 File Offset: 0x00013DD0
		static int ek79l6OKe5;

		// Token: 0x04004B30 RID: 19248 RVA: 0x00015BD8 File Offset: 0x00013DD8
		static int aR7yEyxQak;

		// Token: 0x04004B31 RID: 19249 RVA: 0x00015BE0 File Offset: 0x00013DE0
		static int 27InSsszT5;

		// Token: 0x04004B32 RID: 19250 RVA: 0x00015BE8 File Offset: 0x00013DE8
		static int cOFP7YagGS;

		// Token: 0x04004B33 RID: 19251 RVA: 0x00015BF0 File Offset: 0x00013DF0
		static int 9SDbGLoSzB;

		// Token: 0x04004B34 RID: 19252 RVA: 0x00015BF8 File Offset: 0x00013DF8
		static int iqkRShbTq2;

		// Token: 0x04004B35 RID: 19253 RVA: 0x00015C00 File Offset: 0x00013E00
		static int NY0idLLs0p;

		// Token: 0x04004B36 RID: 19254 RVA: 0x00015C08 File Offset: 0x00013E08
		static int XQJIlk4rhG;

		// Token: 0x04004B37 RID: 19255 RVA: 0x00015C10 File Offset: 0x00013E10
		static int EaASXvox6a;

		// Token: 0x04004B38 RID: 19256 RVA: 0x00015C18 File Offset: 0x00013E18
		static int 7GzOEkce74;

		// Token: 0x04004B39 RID: 19257 RVA: 0x00015C20 File Offset: 0x00013E20
		static int A5bKnRgcqs;

		// Token: 0x04004B3A RID: 19258 RVA: 0x00015C28 File Offset: 0x00013E28
		static int nuwjxxYhKs;

		// Token: 0x04004B3B RID: 19259 RVA: 0x00015C30 File Offset: 0x00013E30
		static int hXvasRa5DA;

		// Token: 0x04004B3C RID: 19260 RVA: 0x00015C38 File Offset: 0x00013E38
		static int IZtmGJ80pG;

		// Token: 0x04004B3D RID: 19261 RVA: 0x00015C40 File Offset: 0x00013E40
		static int OLHOwMTPaR;

		// Token: 0x04004B3E RID: 19262 RVA: 0x00015C48 File Offset: 0x00013E48
		static int M4TPWmJBcV;

		// Token: 0x04004B3F RID: 19263 RVA: 0x00015C50 File Offset: 0x00013E50
		static int 0lYpkNBJdo;

		// Token: 0x04004B40 RID: 19264 RVA: 0x00015C58 File Offset: 0x00013E58
		static int yi2EdWQhnf;

		// Token: 0x04004B41 RID: 19265 RVA: 0x00015C60 File Offset: 0x00013E60
		static int 7KevxNFeQe;

		// Token: 0x04004B42 RID: 19266 RVA: 0x00015C68 File Offset: 0x00013E68
		static int 97XTPnxboj;

		// Token: 0x04004B43 RID: 19267 RVA: 0x00015C70 File Offset: 0x00013E70
		static int LKwvcoCPwA;

		// Token: 0x04004B44 RID: 19268 RVA: 0x00015C78 File Offset: 0x00013E78
		static int VmX6YpGm1W;

		// Token: 0x04004B45 RID: 19269 RVA: 0x00015C80 File Offset: 0x00013E80
		static int Hg38p1Kiyz;

		// Token: 0x04004B46 RID: 19270 RVA: 0x00015C88 File Offset: 0x00013E88
		static int iy2EUwYsSJ;

		// Token: 0x04004B47 RID: 19271 RVA: 0x00015C90 File Offset: 0x00013E90
		static int L0rPIWjb5k;

		// Token: 0x04004B48 RID: 19272 RVA: 0x00015C98 File Offset: 0x00013E98
		static int hKkSboRxGl;

		// Token: 0x04004B49 RID: 19273 RVA: 0x00015CA0 File Offset: 0x00013EA0
		static int eda7bguSll;

		// Token: 0x04004B4A RID: 19274 RVA: 0x00015CA8 File Offset: 0x00013EA8
		static int RXTsLRzn0S;

		// Token: 0x04004B4B RID: 19275 RVA: 0x00015CB0 File Offset: 0x00013EB0
		static int RsmOSYOknq;

		// Token: 0x04004B4C RID: 19276 RVA: 0x00015CB8 File Offset: 0x00013EB8
		static int fkmrprauxl;

		// Token: 0x04004B4D RID: 19277 RVA: 0x00015CC0 File Offset: 0x00013EC0
		static int mR0UTJ02GJ;

		// Token: 0x04004B4E RID: 19278 RVA: 0x00015CC8 File Offset: 0x00013EC8
		static int yo7yTv1MoD;

		// Token: 0x04004B4F RID: 19279 RVA: 0x00015CD0 File Offset: 0x00013ED0
		static int SKo5GqvmCd;

		// Token: 0x04004B50 RID: 19280 RVA: 0x00015CD8 File Offset: 0x00013ED8
		static int 0EzOpA2S4I;

		// Token: 0x04004B51 RID: 19281 RVA: 0x00015CE0 File Offset: 0x00013EE0
		static int hWdd10myY4;

		// Token: 0x04004B52 RID: 19282 RVA: 0x00015CE8 File Offset: 0x00013EE8
		static int 0OFuTcm4Om;

		// Token: 0x04004B53 RID: 19283 RVA: 0x00015CF0 File Offset: 0x00013EF0
		static int YOzmTuysIT;

		// Token: 0x04004B54 RID: 19284 RVA: 0x00015CF8 File Offset: 0x00013EF8
		static int 3iRfg5qKEP;

		// Token: 0x04004B55 RID: 19285 RVA: 0x00015D00 File Offset: 0x00013F00
		static int D6NInm8F5M;

		// Token: 0x04004B56 RID: 19286 RVA: 0x00015D08 File Offset: 0x00013F08
		static int X7ESuSh0KH;

		// Token: 0x04004B57 RID: 19287 RVA: 0x00015D10 File Offset: 0x00013F10
		static int B3pFBR6jNX;

		// Token: 0x04004B58 RID: 19288 RVA: 0x00015D18 File Offset: 0x00013F18
		static int wb09jbAr9q;

		// Token: 0x04004B59 RID: 19289 RVA: 0x00015D20 File Offset: 0x00013F20
		static int vtx555e9vN;

		// Token: 0x04004B5A RID: 19290 RVA: 0x00015D28 File Offset: 0x00013F28
		static int Y0A6NJRIHW;

		// Token: 0x04004B5B RID: 19291 RVA: 0x00015D30 File Offset: 0x00013F30
		static int qZ1ha5GFsS;
	}
}
