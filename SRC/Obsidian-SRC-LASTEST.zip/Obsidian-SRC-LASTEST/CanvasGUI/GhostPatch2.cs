﻿using System;
using HarmonyLib;

namespace CanvasGUI
{
	// Token: 0x02000034 RID: 52
	[HarmonyPatch(typeof(VRRigJobManager), "DeregisterVRRig")]
	public static class GhostPatch2
	{
		// Token: 0x060001DF RID: 479 RVA: 0x0064C7E8 File Offset: 0x0064A9E8
		public unsafe static bool Prefix(VRRigJobManager __instance, VRRig rig)
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			if ((*(&GhostPatch2.ER4FyMrT0I) ^ *(&GhostPatch2.ER4FyMrT0I)) != 0)
			{
				goto IL_24;
			}
			goto IL_B24;
			uint num2;
			int[] array5;
			bool result;
			for (;;)
			{
				IL_29:
				uint num;
				switch ((num = (num2 ^ (uint)(*(&GhostPatch2.ny2kMbehXr)))) % (uint)(*(&GhostPatch2.J8kTXAxbQs)))
				{
				case 0U:
				{
					int num3;
					int num4;
					*(ref num3 + (IntPtr)num4) = num4;
					int num5 = num3 - num4;
					int num6 = (int)((short)num6);
					int num7;
					num7 -= 379;
					uint num8 = num - (uint)(*(&GhostPatch2.WL0u38Dbcq));
					uint num9 = num8 & (uint)(*(&GhostPatch2.nB3wgHcMCb));
					num2 = (num9 + (uint)(*(&GhostPatch2.bKddWsHp4G)) ^ (uint)(*(&GhostPatch2.Aq6AI449Sz)));
					continue;
				}
				case 1U:
					num2 = 3959316149U;
					continue;
				case 2U:
				{
					uint[] array = new uint[*(&GhostPatch2.rKx6piN11x)];
					array[*(&GhostPatch2.sZA8twcfzn)] = (uint)(*(&GhostPatch2.S5O6lmw7rE));
					array[*(&GhostPatch2.xb4eiq9Yoa)] = (uint)(*(&GhostPatch2.TvF8WzUGd7));
					array[*(&GhostPatch2.UTkdfw51VD)] = (uint)(*(&GhostPatch2.wQKw9RffZC));
					array[*(&GhostPatch2.wE0YTgzQjv)] = (uint)(*(&GhostPatch2.Spdtud0a9v));
					array[*(&GhostPatch2.uICloDlT8E) + *(&GhostPatch2.TyqaKPcLK8)] = (uint)(*(&GhostPatch2.7pRjvHwaBf));
					array[*(&GhostPatch2.aEgoSoCPuP)] = (uint)(*(&GhostPatch2.4fSfbd8Djf) + *(&GhostPatch2.BpQAyF0c0g));
					uint num10 = (num | (uint)(*(&GhostPatch2.RLScoPSCIf))) - (uint)(*(&GhostPatch2.NNb4DbXwHR));
					uint num11 = num10 * array[*(&GhostPatch2.Is1gevyfzM)];
					num2 = ((num11 | array[*(&GhostPatch2.yjZN8tNz0M)]) ^ array[*(&GhostPatch2.L55DRxNW6X) + *(&GhostPatch2.sDUiXiTw83)] ^ (uint)(*(&GhostPatch2.awN5rnyN5U)) ^ (uint)(*(&GhostPatch2.Oh65GNxyOr) + *(&GhostPatch2.hcjcevO0za)));
					continue;
				}
				case 3U:
				{
					int num7;
					int num3 = -num7;
					uint[] array2 = new uint[*(&GhostPatch2.af2RWoB0tL) + *(&GhostPatch2.KzjbhLrWYL)];
					array2[*(&GhostPatch2.1YgWp6F3nm)] = (uint)(*(&GhostPatch2.Md3NB6RMHs));
					array2[*(&GhostPatch2.qQ5t5KHed6)] = (uint)(*(&GhostPatch2.NhlH7B8glZ));
					array2[*(&GhostPatch2.iHMH8r5Vak)] = (uint)(*(&GhostPatch2.4ePpekdxaf) + *(&GhostPatch2.zkarYo1wQ9));
					array2[*(&GhostPatch2.7uksJjExuO)] = (uint)(*(&GhostPatch2.OvE2CsS5nW) + *(&GhostPatch2.hLGGj8rftT));
					array2[*(&GhostPatch2.zJEanJ4hg5)] = (uint)(*(&GhostPatch2.gqDLQDghop));
					num2 = (num + array2[*(&GhostPatch2.W6J3cwoeIL)] - (uint)(*(&GhostPatch2.1iDaZFqoP3)) + (uint)(*(&GhostPatch2.yvZr00I5zf)) - (uint)(*(&GhostPatch2.bJ0E72AL70)) ^ (uint)(*(&GhostPatch2.fZYUD7nmvK)) ^ (uint)(*(&GhostPatch2.W2Sv0khbDl)));
					continue;
				}
				case 4U:
					num2 = 4033515734U;
					continue;
				case 5U:
				{
					int num5;
					int num3 = num5 / num3;
					uint num12 = num - (uint)(*(&GhostPatch2.hoZ9Fs0muS)) + (uint)(*(&GhostPatch2.gAWPGBRkg2));
					uint num13 = num12 + (uint)(*(&GhostPatch2.VfkboOkzFY));
					num2 = (((num13 | (uint)(*(&GhostPatch2.CwduXoM34b))) & (uint)(*(&GhostPatch2.JaAGpd5tCV))) ^ (uint)(*(&GhostPatch2.TNjjVCD7U1)));
					continue;
				}
				case 6U:
				{
					int num3;
					int num7;
					num7 -= num3;
					uint[] array3 = new uint[*(&GhostPatch2.QQlp3PIzsY)];
					array3[*(&GhostPatch2.CW42JVoXPU)] = (uint)(*(&GhostPatch2.pKJTJ2dTao));
					array3[*(&GhostPatch2.tfinfhS3Ka)] = (uint)(*(&GhostPatch2.wRtIKNRpTM));
					array3[*(&GhostPatch2.Sb2I4GHRgB) + *(&GhostPatch2.vyZDpgxQWl)] = (uint)(*(&GhostPatch2.CvMziXbBJ5));
					array3[*(&GhostPatch2.kyANWRnasZ)] = (uint)(*(&GhostPatch2.ZAXJo71pcn) + *(&GhostPatch2.aASrJhPCjg));
					array3[*(&GhostPatch2.oFHka7yLrY) + *(&GhostPatch2.3Xi7MCXCKl)] = (uint)(*(&GhostPatch2.fwigfkgSDy));
					uint num14 = num + array3[*(&GhostPatch2.Ck0LuT3xtr)];
					uint num15 = num14 + (uint)(*(&GhostPatch2.Ip7EuDcUfH));
					uint num16 = num15 - (uint)(*(&GhostPatch2.KM27B2hlFz));
					uint num17 = num16 - array3[*(&GhostPatch2.agI3WSgWM2)];
					num2 = ((num17 | (uint)(*(&GhostPatch2.IkScdzyewc))) ^ (uint)(*(&GhostPatch2.HLx5ozs2K2)));
					continue;
				}
				case 7U:
				{
					int[] array4 = array5;
					int num18 = 1;
					int num19 = array5[1];
					int num21;
					int num20 = (-21 == 0) ? (num21 = num19 - 18) : (num21 = num19 + -21);
					int num22 = ((-489 == 0) ? (num20 - 46) : (num21 + -489)) * 430;
					array4[num18] = (array5[1] ^ num22 ^ (594188411 ^ num22));
					int[] array6 = array5;
					int num23 = 2;
					int num24 = array5[2];
					num22 = (((43 == 0) ? (num24 - 7) : (num24 + 43)) | 442) - 242;
					array6[num23] = (array5[2] ^ num22 ^ (594188411 ^ num22));
					int[] array7 = array5;
					int num25 = 3;
					num22 = (array5[3] * -140 % 88 & -430);
					array7[num25] = (array5[3] ^ num22 ^ (594188411 ^ num22));
					num2 = 2592347881U;
					continue;
				}
				case 8U:
					num2 = 2960095678U;
					continue;
				case 9U:
				{
					int num3;
					int num7;
					int num4 = *(ref num7 + (IntPtr)num3);
					int num6 = *(ref GhostPatch2.QDtKOfSgLg + (IntPtr)num3);
					num6 = GhostPatch2.QDtKOfSgLg;
					num4 = ~num6;
					uint num26 = num - (uint)(*(&GhostPatch2.bOAFh3i2Dj) + *(&GhostPatch2.ys6s3Ckqg6)) & (uint)(*(&GhostPatch2.Rp3rUjjqlD));
					num2 = ((num26 & (uint)(*(&GhostPatch2.dQA8nx14A6))) ^ (uint)(*(&GhostPatch2.4SpQYRlHXv)));
					continue;
				}
				case 10U:
				{
					int num6;
					int num7 = ~num6;
					uint num27 = num & (uint)(*(&GhostPatch2.ZWnu3C3lNV));
					num2 = (num27 + (uint)(*(&GhostPatch2.BYqe48VQEa)) - (uint)(*(&GhostPatch2.1Dws9SeI4u)) ^ (uint)(*(&GhostPatch2.c9V9yfSC0u) + *(&GhostPatch2.xtOIfl82F1)));
					continue;
				}
				case 11U:
				{
					int[] array8 = new int[10];
					int[] array9 = new int[10];
					uint num28 = num - (uint)(*(&GhostPatch2.h7eSOkc5He));
					uint num29 = (num28 - (uint)(*(&GhostPatch2.Zjqv342NQK)) & (uint)(*(&GhostPatch2.SYvKJZPfw3)) & (uint)(*(&GhostPatch2.GMGHYqUjVm))) ^ (uint)(*(&GhostPatch2.8ja2SjSzad));
					num2 = ((num29 & (uint)(*(&GhostPatch2.IjLGaJLTIy))) ^ (uint)(*(&GhostPatch2.V7INYMciWM)));
					continue;
				}
				case 12U:
				{
					int num4 = (int)((sbyte)num4);
					int num3;
					int num7 = num4 ^ num3;
					int num6 = num4;
					num6 = *(ref GhostPatch2.QDtKOfSgLg + (IntPtr)num6);
					num3 |= 997374745;
					num2 = (((num & (uint)(*(&GhostPatch2.3CVupCw7sw))) + (uint)(*(&GhostPatch2.3IB1GMfQP9)) & (uint)(*(&GhostPatch2.81IuhUAYRN))) ^ (uint)(*(&GhostPatch2.15xuwqUbdh)) ^ (uint)(*(&GhostPatch2.9pWAzw1BCR)));
					continue;
				}
				case 13U:
				{
					int num7 = 788664229;
					uint[] array10 = new uint[*(&GhostPatch2.DrRXFltctO)];
					array10[*(&GhostPatch2.xQKecBBgas)] = (uint)(*(&GhostPatch2.tz6MNOc7lV));
					array10[*(&GhostPatch2.IcjxeUHTvt)] = (uint)(*(&GhostPatch2.UuEh2YKUSD));
					array10[*(&GhostPatch2.2P8WlOvEJ0) + *(&GhostPatch2.Iw0XFVrWAH)] = (uint)(*(&GhostPatch2.4suqY8uZUy));
					array10[*(&GhostPatch2.EIoic3dNLQ)] = (uint)(*(&GhostPatch2.jCJ5lh3qbg) + *(&GhostPatch2.rxUKIKeS8n));
					array10[*(&GhostPatch2.dVtVv9HS5M) + *(&GhostPatch2.2dKti1jzE0)] = (uint)(*(&GhostPatch2.ED8xGRydaS));
					uint num30 = num - (uint)(*(&GhostPatch2.YLPiwNTxJl));
					uint num31 = num30 ^ (uint)(*(&GhostPatch2.ZlvPoNmkmQ));
					uint num32 = num31 ^ (uint)(*(&GhostPatch2.kpNHiZX5Oe));
					num2 = (num32 - (uint)(*(&GhostPatch2.Lo2nxqOm6U)) + array10[*(&GhostPatch2.ivpdadSsJ3)] ^ (uint)(*(&GhostPatch2.oN0Jrt7H9X)));
					continue;
				}
				case 14U:
				{
					int num3;
					num2 = (((num3 > num3) ? 1625350932U : 1278161311U) ^ num * 2933886641U);
					continue;
				}
				case 15U:
				{
					int num4;
					int num6;
					int[] array9;
					array9[num6 + 9 - num4] = (num4 | 7);
					uint[] array11 = new uint[*(&GhostPatch2.NPF9FNpq4g)];
					array11[*(&GhostPatch2.l1s6DQbD4x)] = (uint)(*(&GhostPatch2.wmvQtrT58j));
					array11[*(&GhostPatch2.iNDmK5k5vQ)] = (uint)(*(&GhostPatch2.cx1p3SrRyk));
					array11[*(&GhostPatch2.CGiOLlezQX)] = (uint)(*(&GhostPatch2.3urU8XyFvI) + *(&GhostPatch2.qgRoU9uFWa));
					array11[*(&GhostPatch2.ACHXhcoyaj) + *(&GhostPatch2.aupXWsFhrg)] = (uint)(*(&GhostPatch2.elgp4gy43M));
					uint num33 = num + (uint)(*(&GhostPatch2.0ZczX1mUwg)) | (uint)(*(&GhostPatch2.s9pLr503Rm));
					uint num34 = num33 ^ array11[*(&GhostPatch2.3NX06YfbdB)];
					num2 = ((num34 & (uint)(*(&GhostPatch2.nu5OtBSz9e) + *(&GhostPatch2.FvuLxe6V79))) ^ (uint)(*(&GhostPatch2.p5nQTnBm39)));
					continue;
				}
				case 16U:
				{
					int num7;
					int num4 = -num7;
					uint[] array12 = new uint[*(&GhostPatch2.Lc0Grj1UXK)];
					array12[*(&GhostPatch2.TvZxdX5za5)] = (uint)(*(&GhostPatch2.zeFBDMk20U));
					array12[*(&GhostPatch2.Hltl3o3WgT)] = (uint)(*(&GhostPatch2.8WJtWZ3nFT));
					array12[*(&GhostPatch2.ADYhCrXzDf)] = (uint)(*(&GhostPatch2.99eDDsCx3y));
					array12[*(&GhostPatch2.ejTH7cUVoo)] = (uint)(*(&GhostPatch2.T6wgTDMMjM));
					array12[*(&GhostPatch2.QETBU82Fqo) + *(&GhostPatch2.WFtQybuRjk)] = (uint)(*(&GhostPatch2.WBKYMCN7tA));
					uint num35 = (num | array12[*(&GhostPatch2.f0OrhaPSw8)]) * array12[*(&GhostPatch2.kPp9RNNfs2)] | (uint)(*(&GhostPatch2.T5m8zP34yS));
					num2 = (((num35 ^ array12[*(&GhostPatch2.v4WqJg1BsX)]) | (uint)(*(&GhostPatch2.LcekAHWKH8))) ^ (uint)(*(&GhostPatch2.yrP0qkNP1S)));
					continue;
				}
				case 17U:
				{
					int num4;
					int num7 = num4 % 885;
					int num3;
					num7 = (num3 & num4);
					uint[] array13 = new uint[*(&GhostPatch2.z7dPOVLvXZ) + *(&GhostPatch2.zGe81Ug9VA)];
					array13[*(&GhostPatch2.bwnT3adrRG)] = (uint)(*(&GhostPatch2.kg4wdd4qoV));
					array13[*(&GhostPatch2.gJ9Csmj5gc)] = (uint)(*(&GhostPatch2.mz4R8CUKVx));
					array13[*(&GhostPatch2.1edRzSLrfY)] = (uint)(*(&GhostPatch2.azU9eRxkkR));
					array13[*(&GhostPatch2.0hLzevmnya)] = (uint)(*(&GhostPatch2.ItU1dCqsNZ));
					array13[*(&GhostPatch2.b1aICwe4xq)] = (uint)(*(&GhostPatch2.PujE6UTowE));
					uint num36 = num & array13[*(&GhostPatch2.qh3EPqedgb)];
					uint num37 = num36 * (uint)(*(&GhostPatch2.kEWLz9HCws));
					num2 = ((num37 - (uint)(*(&GhostPatch2.Rr0HLYKQ4J)) ^ array13[*(&GhostPatch2.tC5Jt38V2W)]) + (uint)(*(&GhostPatch2.RAYVGKXYO7)) ^ (uint)(*(&GhostPatch2.MQ1Ex9rw31)));
					continue;
				}
				case 18U:
				{
					int num6 = num6;
					uint[] array14 = new uint[*(&GhostPatch2.nsomtrr9ch)];
					array14[*(&GhostPatch2.FfqYXZWEo2)] = (uint)(*(&GhostPatch2.NfKoJj1FNW));
					array14[*(&GhostPatch2.UiIWNwvwlW)] = (uint)(*(&GhostPatch2.PnJOF1M4Xb));
					array14[*(&GhostPatch2.OdxKXHi9dJ)] = (uint)(*(&GhostPatch2.0mwGMgXTLl));
					array14[*(&GhostPatch2.nkcSmjW5jR)] = (uint)(*(&GhostPatch2.X6svI1v78F) + *(&GhostPatch2.NvSbfn1DBi));
					array14[*(&GhostPatch2.e2tvxnAfiy)] = (uint)(*(&GhostPatch2.vmaLw33A8U));
					array14[*(&GhostPatch2.vZVFX1RBw8) + *(&GhostPatch2.sS4AxfN68e)] = (uint)(*(&GhostPatch2.1PYKTkVHpm));
					uint num38 = num & array14[*(&GhostPatch2.t1FqwEhnX5)];
					uint num39 = num38 * (uint)(*(&GhostPatch2.V9skFcsZXR)) * array14[*(&GhostPatch2.p7BddgBKwx)];
					uint num40 = (num39 | array14[*(&GhostPatch2.gKWKO0NNOt)]) - array14[*(&GhostPatch2.8kiCJ2gyE0) + *(&GhostPatch2.26tY6wzlNQ)];
					num2 = (num40 - array14[*(&GhostPatch2.DW0kZLmiVP)] ^ (uint)(*(&GhostPatch2.OfKoSFY9Ul)));
					continue;
				}
				case 19U:
				{
					uint[] array15 = new uint[*(&GhostPatch2.eDfkjuSaEP)];
					array15[*(&GhostPatch2.jATSRoe3qY)] = (uint)(*(&GhostPatch2.WRMFOpiq4T) + *(&GhostPatch2.yA0PEYz6EN));
					array15[*(&GhostPatch2.VX68yIhYgE)] = (uint)(*(&GhostPatch2.zG3EMM1aV4));
					array15[*(&GhostPatch2.MmguaiKEN3)] = (uint)(*(&GhostPatch2.yizdD8VNQG));
					array15[*(&GhostPatch2.HKJ0esHwC1)] = (uint)(*(&GhostPatch2.hZkKBt1MhQ));
					array15[*(&GhostPatch2.8cKnPQRZBO) + *(&GhostPatch2.1nKPwBcqPs)] = (uint)(*(&GhostPatch2.bXCWVZ7obT));
					uint num41 = (num + (uint)(*(&GhostPatch2.GIpAIoAfkN))) * array15[*(&GhostPatch2.brvx93PVXA)];
					uint num42 = (num41 & array15[*(&GhostPatch2.QL6zykaxS0)]) - array15[*(&GhostPatch2.Tm8rHt8JHH)];
					num2 = (num42 ^ array15[*(&GhostPatch2.B6FCRulOWc)] ^ (uint)(*(&GhostPatch2.JlRaD5M0Lh)));
					continue;
				}
				case 20U:
				{
					uint[] array16 = new uint[*(&GhostPatch2.0SSIhBvXDM)];
					array16[*(&GhostPatch2.dKaetxHnWK)] = (uint)(*(&GhostPatch2.ktwEBcoUTl));
					array16[*(&GhostPatch2.UUG4VOzzC1)] = (uint)(*(&GhostPatch2.DVS691GDWt));
					array16[*(&GhostPatch2.7toRIGfNGF)] = (uint)(*(&GhostPatch2.XbEb1JDgJf));
					uint num43 = (num & array16[*(&GhostPatch2.8RleGPb0FJ)]) - array16[*(&GhostPatch2.Vk7jokpyvO)];
					num2 = (num43 + array16[*(&GhostPatch2.slt6emQ0E0)] ^ (uint)(*(&GhostPatch2.xk41uqIJK3)));
					continue;
				}
				case 21U:
				{
					int num5;
					int num7;
					int[] array9;
					array9[num5 + 8 - num5] = (num7 | 5);
					uint[] array17 = new uint[*(&GhostPatch2.YKYA6k2C7l)];
					array17[*(&GhostPatch2.4ZNbjyA2DP)] = (uint)(*(&GhostPatch2.q3ght1AHNy) + *(&GhostPatch2.NXswIszBNY));
					array17[*(&GhostPatch2.nFYsvUQZ72)] = (uint)(*(&GhostPatch2.LEgRDen1QF));
					array17[*(&GhostPatch2.kvzJYgrbS0)] = (uint)(*(&GhostPatch2.88pplleywY));
					array17[*(&GhostPatch2.kkJUnI0atn)] = (uint)(*(&GhostPatch2.F8uHx2PPTO));
					array17[*(&GhostPatch2.nzGG4MZ1pb) + *(&GhostPatch2.AzF2fAlegP)] = (uint)(*(&GhostPatch2.qQrpvAOh1t) + *(&GhostPatch2.WPehuudDaa));
					array17[*(&GhostPatch2.s8vSnQ21lx)] = (uint)(*(&GhostPatch2.QusEhXHbU3));
					uint num44 = (num ^ array17[*(&GhostPatch2.72A6EuUhIv)]) * array17[*(&GhostPatch2.ghEFgrfZCf)];
					uint num45 = (num44 & array17[*(&GhostPatch2.HW5Eclga9W)]) | (uint)(*(&GhostPatch2.mCsgc08yN2));
					uint num46 = num45 * array17[*(&GhostPatch2.6Ut0Qtqnh0) + *(&GhostPatch2.2rZzwl66dc)];
					num2 = ((num46 & (uint)(*(&GhostPatch2.N3hvIezhmq))) ^ (uint)(*(&GhostPatch2.tqMJjwnFxt) + *(&GhostPatch2.532Je4m3u1)));
					continue;
				}
				case 22U:
				{
					int[] array18 = array5;
					int num47 = 0;
					int num48 = array5[0] - -292;
					int num50;
					int num49 = (37 == 0) ? (num50 = num48 - 25) : (num50 = num48 + 37);
					int num22 = (((27 == 0) ? (num49 - 2) : (num50 + 27)) - 233) * 28;
					array18[num47] = (array5[0] ^ num22 ^ (594188411 ^ num22));
					num2 = 3886535921U;
					continue;
				}
				case 23U:
				{
					int num7;
					int num3 = (int)((ushort)num7);
					uint[] array19 = new uint[*(&GhostPatch2.FDxz2e4Yxe) + *(&GhostPatch2.Q5wgtrGMIm)];
					array19[*(&GhostPatch2.ndbmHlnXDT)] = (uint)(*(&GhostPatch2.u42pxvrAEU));
					array19[*(&GhostPatch2.aqOa9aU0Gq)] = (uint)(*(&GhostPatch2.H81hhlmKsR));
					array19[*(&GhostPatch2.1hVetVCGs8)] = (uint)(*(&GhostPatch2.AFIyM6OAnq));
					array19[*(&GhostPatch2.QwQXLwCVIL)] = (uint)(*(&GhostPatch2.IgSxc3Vuro));
					array19[*(&GhostPatch2.XOHIpBzDUk) + *(&GhostPatch2.XlhBAEQ8S7)] = (uint)(*(&GhostPatch2.Sr7hzexUVT));
					array19[*(&GhostPatch2.keT8SCpIrJ)] = (uint)(*(&GhostPatch2.69Aiyh8QxY) + *(&GhostPatch2.mXbtWqQjSK));
					uint num51 = num & (uint)(*(&GhostPatch2.OesB92Sjt7));
					uint num52 = num51 | array19[*(&GhostPatch2.YHQJATrYtS)];
					uint num53 = num52 * (uint)(*(&GhostPatch2.ghh6qMCjmm)) + (uint)(*(&GhostPatch2.wFzg5bQ9j5)) | array19[*(&GhostPatch2.OZgz9eHStD)];
					num2 = (num53 * (uint)(*(&GhostPatch2.8109or7wUw)) ^ (uint)(*(&GhostPatch2.0s6HLTRtNi) + *(&GhostPatch2.CszxDHAr6L)));
					continue;
				}
				case 24U:
				{
					int num3;
					num2 = ((num3 > num3) ? 3214593798U : 3775145923U);
					continue;
				}
				case 25U:
				{
					int num6;
					int num3 = num6 ^ 1046081409;
					int num7;
					num6 = (num7 ^ 1456627054);
					int num4;
					int num5 = *(ref num4 + (IntPtr)num3);
					int[] array8;
					array8[num3 + 7 - num7] = num3 - -5;
					num2 = (((num7 <= num7) ? 1801371956U : 1776313543U) ^ num * 2084740827U);
					continue;
				}
				case 26U:
				{
					int num3;
					num3 |= 867453846;
					uint[] array20 = new uint[*(&GhostPatch2.hRLqLGLmAS)];
					array20[*(&GhostPatch2.f6rWQ5snIB)] = (uint)(*(&GhostPatch2.9VINeSDJHk));
					array20[*(&GhostPatch2.EDYu0CaV1N)] = (uint)(*(&GhostPatch2.qZsQ78p39R));
					array20[*(&GhostPatch2.TYnOdMJ8M2)] = (uint)(*(&GhostPatch2.DBeZNci7gO));
					array20[*(&GhostPatch2.fWw5Vkm1Qf)] = (uint)(*(&GhostPatch2.mJK0RpaJQo));
					uint num54 = num & (uint)(*(&GhostPatch2.3bJ8Jp4SCe));
					num2 = ((num54 - array20[*(&GhostPatch2.asXvv6ms23)] | array20[*(&GhostPatch2.jRsqP41oIh)]) * array20[*(&GhostPatch2.CYq1VDNxvq)] ^ (uint)(*(&GhostPatch2.pUzvF4vYEU)));
					continue;
				}
				case 27U:
				{
					int num7;
					int num5 = num7 << 1;
					int num3;
					int num4;
					int num6;
					int[] array8;
					array8[num4 + 6 - num6] = (num3 | -6);
					num7 = num5 / num3;
					uint[] array21 = new uint[*(&GhostPatch2.pz9vStZV8j)];
					array21[*(&GhostPatch2.3ndYoFrwGY)] = (uint)(*(&GhostPatch2.J6FUBp4wiv));
					array21[*(&GhostPatch2.78zzWQ3hGT)] = (uint)(*(&GhostPatch2.lHrhJtk9Br) + *(&GhostPatch2.IXMyxstotm));
					array21[*(&GhostPatch2.ynxNl4xoCX)] = (uint)(*(&GhostPatch2.MJpwxCPiLS));
					array21[*(&GhostPatch2.F5u0mkwBCn)] = (uint)(*(&GhostPatch2.hOxee8Td6O));
					array21[*(&GhostPatch2.567oe8rZAu)] = (uint)(*(&GhostPatch2.cLdbg327kB));
					uint num55 = num + array21[*(&GhostPatch2.IwmY08VLSy)] & (uint)(*(&GhostPatch2.tvl6XI8GVn) + *(&GhostPatch2.2WARKVvW7k));
					num2 = ((num55 * array21[*(&GhostPatch2.FW35GJUixg) + *(&GhostPatch2.ngHMBqjgEY)] ^ array21[*(&GhostPatch2.5vl6IwvUNe)]) * (uint)(*(&GhostPatch2.M9NrsW2q0O)) ^ (uint)(*(&GhostPatch2.yZSyAWOyPe)));
					continue;
				}
				case 28U:
				{
					uint[] array22 = new uint[*(&GhostPatch2.Lqug6qwFUl)];
					array22[*(&GhostPatch2.7doZ60fZzj)] = (uint)(*(&GhostPatch2.7RI9dlJjg9));
					array22[*(&GhostPatch2.C00M0jwN7h)] = (uint)(*(&GhostPatch2.8bE7WUUXqO));
					array22[*(&GhostPatch2.MRSdw3iuCU)] = (uint)(*(&GhostPatch2.gMjUiHncjX));
					array22[*(&GhostPatch2.DScRkfNKmJ) + *(&GhostPatch2.Qw3RxuhWZ6)] = (uint)(*(&GhostPatch2.ACLmBw2uZP));
					array22[*(&GhostPatch2.q1xTL4zA3Q) + *(&GhostPatch2.qXH3DuTRgx)] = (uint)(*(&GhostPatch2.jRDnWBG0Qy));
					array22[*(&GhostPatch2.mcvXcZ8kG3)] = (uint)(*(&GhostPatch2.5gdIPn4SiQ));
					uint num56 = num - array22[*(&GhostPatch2.dlNlqZyK6J)];
					uint num57 = num56 - (uint)(*(&GhostPatch2.x9uEnNmuao));
					num2 = ((((num57 * array22[*(&GhostPatch2.wsLm2Cx4Xs)] & (uint)(*(&GhostPatch2.HySAVBOJrC) + *(&GhostPatch2.lxn6G6wYeB))) ^ (uint)(*(&GhostPatch2.BK13euZlto))) | array22[*(&GhostPatch2.l3wNC9rutm) + *(&GhostPatch2.9cDYD8FOg6)]) ^ (uint)(*(&GhostPatch2.PZaWr66Yfk)));
					continue;
				}
				case 29U:
				{
					int num3;
					int num4 = num3;
					int num6;
					int[] array8;
					num4 = (array8[num4 + 7 - num6] ^ 7);
					uint num58 = num - (uint)(*(&GhostPatch2.6nWEC28J9u));
					uint num59 = num58 ^ (uint)(*(&GhostPatch2.cdSjtsmeDz));
					uint num60 = num59 - (uint)(*(&GhostPatch2.ZPo4ho55tb));
					uint num61 = num60 + (uint)(*(&GhostPatch2.4bZIaZcQiy));
					uint num62 = num61 * (uint)(*(&GhostPatch2.3YcPqXpbPE));
					num2 = ((num62 | (uint)(*(&GhostPatch2.xaju6r9chY))) ^ (uint)(*(&GhostPatch2.6DZizAEJIT)));
					continue;
				}
				case 30U:
					array5[2] = 2001564911;
					num2 = (((num ^ (uint)(*(&GhostPatch2.7pVZrMthUJ) + *(&GhostPatch2.zciA5aionO))) & (uint)(*(&GhostPatch2.Ol3xE5yh2q))) + (uint)(*(&GhostPatch2.hGgei90pEL)) ^ (uint)(*(&GhostPatch2.d5FXQjuNMj)));
					continue;
				case 31U:
				{
					int num4;
					int num6;
					int[] array8;
					array8[num6 + 7 - num4] = num4 - 5;
					uint[] array23 = new uint[*(&GhostPatch2.wRs3RmhEsb) + *(&GhostPatch2.gGIn8j3ZeL)];
					array23[*(&GhostPatch2.EDzmsOtMPg)] = (uint)(*(&GhostPatch2.jnLTF12ZL0));
					array23[*(&GhostPatch2.SuvU5BDJ6E)] = (uint)(*(&GhostPatch2.5SY9ytcFLC) + *(&GhostPatch2.3UyL234yhH));
					array23[*(&GhostPatch2.reNn3URfrq)] = (uint)(*(&GhostPatch2.KjPKlQPMfV) + *(&GhostPatch2.YxNI775kcC));
					array23[*(&GhostPatch2.GOlzXbFuFd)] = (uint)(*(&GhostPatch2.c7Xe2UEokl));
					array23[*(&GhostPatch2.nrSLs3QFq5) + *(&GhostPatch2.ZrCpk57axK)] = (uint)(*(&GhostPatch2.LfGB3batQn));
					array23[*(&GhostPatch2.2R90YZ6ZGd)] = (uint)(*(&GhostPatch2.K9DKEu4r46));
					uint num63 = num - array23[*(&GhostPatch2.Wo0aZIkRSQ)];
					uint num64 = num63 + (uint)(*(&GhostPatch2.dhyDDHrMRK));
					uint num65 = num64 & (uint)(*(&GhostPatch2.9hTU9Lb66I));
					uint num66 = num65 - array23[*(&GhostPatch2.hsyUQOajbP)] ^ array23[*(&GhostPatch2.yoHz9nLAG6) + *(&GhostPatch2.Dsat6yUgaN)];
					num2 = (num66 * (uint)(*(&GhostPatch2.roUJtvsdwy)) ^ (uint)(*(&GhostPatch2.rIvCWVZdUW)));
					continue;
				}
				case 32U:
				{
					int num7;
					num2 = (((num7 <= num7) ? 2319189571U : 3650209566U) ^ num * 3908334809U);
					continue;
				}
				case 33U:
					goto IL_24;
				case 34U:
				{
					int num3 = GhostPatch2.QDtKOfSgLg;
					int num6;
					int num7;
					int[] array9;
					num3 = array9[num7 + 9 - num6] + 5;
					num6 = (num7 | 949166444);
					uint num67 = num * (uint)(*(&GhostPatch2.Yv7eh6rcRQ));
					uint num68 = (num67 | (uint)(*(&GhostPatch2.ijK3ba15Gq) + *(&GhostPatch2.nIpMJWQqhg))) ^ (uint)(*(&GhostPatch2.mRlysT9Xtx));
					num2 = ((num68 | (uint)(*(&GhostPatch2.q3AnaWTqca))) ^ (uint)(*(&GhostPatch2.wK57GQGvVK) + *(&GhostPatch2.pA5unQ8VKH)));
					continue;
				}
				case 35U:
				{
					int num7;
					int num5 = (int)((short)num7);
					uint num69 = (num + (uint)(*(&GhostPatch2.vOSjoUu6wT))) * (uint)(*(&GhostPatch2.X9VTUnSZdo));
					uint num70 = num69 - (uint)(*(&GhostPatch2.y3q0jgcw6w)) + (uint)(*(&GhostPatch2.h7Fts8roCY) + *(&GhostPatch2.m64g0zD9eW));
					num2 = (num70 + (uint)(*(&GhostPatch2.DzVkq2ib9I)) ^ (uint)(*(&GhostPatch2.17A9wZ4mkW)));
					continue;
				}
				case 36U:
				{
					int num4 = 1942519791;
					num2 = 4097242734U;
					continue;
				}
				case 37U:
					num2 = 2550243781U;
					continue;
				case 38U:
				{
					uint num71 = num + (uint)(*(&GhostPatch2.Ft0in4O02O));
					num2 = ((num71 - (uint)(*(&GhostPatch2.eeowFgcZoq) + *(&GhostPatch2.NXEKAQBD5h)) & (uint)(*(&GhostPatch2.rPzJqG2XeQ)) & (uint)(*(&GhostPatch2.Eb19DiDDsh))) ^ (uint)(*(&GhostPatch2.okDP8sopiW)));
					continue;
				}
				case 39U:
				{
					int num5;
					int num6 = num5 / 957;
					uint[] array24 = new uint[*(&GhostPatch2.zzolt16PDv)];
					array24[*(&GhostPatch2.XP24O4Bg5Y)] = (uint)(*(&GhostPatch2.kCID3WyfHC) + *(&GhostPatch2.SRJks2QALf));
					array24[*(&GhostPatch2.rg31H717u0)] = (uint)(*(&GhostPatch2.oDVqJwrkrW) + *(&GhostPatch2.CbIBcGGSMV));
					array24[*(&GhostPatch2.oBVZrDIQ65) + *(&GhostPatch2.f0vQXP5da5)] = (uint)(*(&GhostPatch2.LpSydQY2ZB));
					array24[*(&GhostPatch2.1jvYLns58F)] = (uint)(*(&GhostPatch2.naow1Mq1nN));
					array24[*(&GhostPatch2.Kn1QK9sh6a) + *(&GhostPatch2.pQ04E5EWEu)] = (uint)(*(&GhostPatch2.hAeURuAg6Q));
					array24[*(&GhostPatch2.kgOM1OrfNM) + *(&GhostPatch2.4K9iaXkus6)] = (uint)(*(&GhostPatch2.HTw2pJJh8a));
					uint num72 = num | (uint)(*(&GhostPatch2.9MkpzIBoCz));
					uint num73 = ((num72 ^ array24[*(&GhostPatch2.NiI20WA544)]) | (uint)(*(&GhostPatch2.KQyAIRtWgr))) ^ (uint)(*(&GhostPatch2.FKgxNskTsR));
					num2 = (num73 + array24[*(&GhostPatch2.V5r2siK4CT)] + array24[*(&GhostPatch2.JNnEQtYkgi)] ^ (uint)(*(&GhostPatch2.ZpHVuDCVpI)));
					continue;
				}
				case 40U:
				{
					int num6;
					int num7 = num6 + 628;
					uint num74 = num ^ (uint)(*(&GhostPatch2.0VbnjRCWJC)) ^ (uint)(*(&GhostPatch2.A2rjrLpQZu));
					uint num75 = num74 - (uint)(*(&GhostPatch2.8ALIammNXX));
					num2 = (num75 + (uint)(*(&GhostPatch2.uRcVlIRCwB)) ^ (uint)(*(&GhostPatch2.G2TYCBcpHD) + *(&GhostPatch2.WEXqxzKSN7)));
					continue;
				}
				case 41U:
				{
					int num5;
					int num6 = -num5;
					uint[] array25 = new uint[*(&GhostPatch2.YMPigRzXAe) + *(&GhostPatch2.dGlP9OBLkj)];
					array25[*(&GhostPatch2.bIAHBOx3Ap)] = (uint)(*(&GhostPatch2.DJX0zYEqOc));
					array25[*(&GhostPatch2.p1rUybuoDq)] = (uint)(*(&GhostPatch2.P1KucPLIhS));
					array25[*(&GhostPatch2.e5WUbUtual)] = (uint)(*(&GhostPatch2.JU6I4kaqSk));
					uint num76 = num ^ (uint)(*(&GhostPatch2.eJ0UZL8mYj));
					uint num77 = num76 & (uint)(*(&GhostPatch2.M5J67tfW2d));
					num2 = (num77 + (uint)(*(&GhostPatch2.r9Obg55C02)) ^ (uint)(*(&GhostPatch2.zez6yVFB5P) + *(&GhostPatch2.WGW0YNKAKK)));
					continue;
				}
				case 42U:
				{
					int num7;
					int[] array9;
					int num6 = array9[num7 + 5 - num7] ^ 4;
					uint[] array26 = new uint[*(&GhostPatch2.VA3LwSm4Xc)];
					array26[*(&GhostPatch2.6Z4Jk7cHn5)] = (uint)(*(&GhostPatch2.EQk4Ci4SQ1));
					array26[*(&GhostPatch2.F4iM1AhMTJ)] = (uint)(*(&GhostPatch2.qRKRNdAjMG) + *(&GhostPatch2.kkbENEZ9IN));
					array26[*(&GhostPatch2.XUngXB0sRk)] = (uint)(*(&GhostPatch2.ZQxeOwGSqj) + *(&GhostPatch2.iUFKQedd8w));
					array26[*(&GhostPatch2.kiDFvWnn4L)] = (uint)(*(&GhostPatch2.mRRmrUw6za));
					array26[*(&GhostPatch2.8HSjpCOdP2)] = (uint)(*(&GhostPatch2.iXtf90Mst2));
					array26[*(&GhostPatch2.JcXf7QDdd6)] = (uint)(*(&GhostPatch2.rgniycPeas));
					uint num78 = num * (uint)(*(&GhostPatch2.HKYCnOiwm0));
					uint num79 = num78 - array26[*(&GhostPatch2.HEN7RftxlY)];
					num2 = ((((num79 & array26[*(&GhostPatch2.9vASKBuLqg) + *(&GhostPatch2.lrRAv8EV1s)]) * array26[*(&GhostPatch2.sR0nzmSqRS) + *(&GhostPatch2.tc2BsVJG1m)] ^ (uint)(*(&GhostPatch2.eXFFPZxMLS))) & array26[*(&GhostPatch2.bY53qs4Xci)]) ^ (uint)(*(&GhostPatch2.sD4XxIyQRZ)));
					continue;
				}
				case 43U:
				{
					int num4;
					int num7 = (int)((ushort)num4);
					uint num80 = num ^ (uint)(*(&GhostPatch2.PW5O6BwZNJ));
					uint num81 = num80 | (uint)(*(&GhostPatch2.8eppne2oMt));
					uint num82 = num81 - (uint)(*(&GhostPatch2.aAtK1084Zp));
					uint num83 = num82 * (uint)(*(&GhostPatch2.TfS6zbeUy5) + *(&GhostPatch2.4kOXZcYu4U));
					uint num84 = num83 & (uint)(*(&GhostPatch2.HZ7Z3PmvXF));
					num2 = (num84 ^ (uint)(*(&GhostPatch2.C19i0cLs0M)) ^ (uint)(*(&GhostPatch2.Ai0Qy0vWuZ)));
					continue;
				}
				case 44U:
					goto IL_B24;
				case 45U:
				{
					int num3;
					int num7 = num3 | 1935475728;
					num7 = (num3 ^ 856971948);
					int num4;
					int[] array8;
					array8[num4 + 5 - num3] = num3 - -2;
					uint[] array27 = new uint[*(&GhostPatch2.hUdeNp290u)];
					array27[*(&GhostPatch2.VLwUr0aC8s)] = (uint)(*(&GhostPatch2.2tx0dEpf9j));
					array27[*(&GhostPatch2.TmKa009AXU)] = (uint)(*(&GhostPatch2.OXUWnn44J0));
					array27[*(&GhostPatch2.JKQIaxhnBJ) + *(&GhostPatch2.AW9RatBWe0)] = (uint)(*(&GhostPatch2.1apodeZaMz));
					array27[*(&GhostPatch2.JvWJZJVB9C)] = (uint)(*(&GhostPatch2.TV8NT2XC63));
					array27[*(&GhostPatch2.liZS8sfmo5)] = (uint)(*(&GhostPatch2.YGaLAPA01R));
					array27[*(&GhostPatch2.YAXbhfbbUl)] = (uint)(*(&GhostPatch2.GWeSOlVELq) + *(&GhostPatch2.nsWDnM5xNE));
					uint num85 = (num + (uint)(*(&GhostPatch2.1hLpflL8vc))) * array27[*(&GhostPatch2.RERCzCmH7Z)];
					uint num86 = num85 ^ (uint)(*(&GhostPatch2.45pKnpoTxU));
					num2 = (((num86 ^ (uint)(*(&GhostPatch2.koNQujLywm) + *(&GhostPatch2.aXSsZjaTOl))) | (uint)(*(&GhostPatch2.kxzyJ51AB0)) | array27[*(&GhostPatch2.71Kb1m0BSP) + *(&GhostPatch2.1xUU9gn6vE)]) ^ (uint)(*(&GhostPatch2.OUFMuwyZGy)));
					continue;
				}
				case 46U:
				{
					int num5;
					int num3 = num5 ^ 508054848;
					uint[] array28 = new uint[*(&GhostPatch2.OD6iSXn3LJ) + *(&GhostPatch2.UsNKteozEF)];
					array28[*(&GhostPatch2.TCLy2fnXIJ)] = (uint)(*(&GhostPatch2.tSYdrAHvIK));
					array28[*(&GhostPatch2.2uYUvjRIID)] = (uint)(*(&GhostPatch2.OaPzDM2Iqx));
					array28[*(&GhostPatch2.tQuCaCTtct)] = (uint)(*(&GhostPatch2.X2r3Mjn0DS));
					array28[*(&GhostPatch2.NfOF4TDiaf)] = (uint)(*(&GhostPatch2.I9EUbm9W3s));
					uint num87 = num + (uint)(*(&GhostPatch2.PhpZpVsVme)) | (uint)(*(&GhostPatch2.iBFXkOBpHH));
					uint num88 = num87 + array28[*(&GhostPatch2.9vT7lXyWck) + *(&GhostPatch2.jQ7UDp0zZi)];
					num2 = (num88 * (uint)(*(&GhostPatch2.kr567G4ruN) + *(&GhostPatch2.kUPvteOryS)) ^ (uint)(*(&GhostPatch2.hW3C5RDvT4)));
					continue;
				}
				case 47U:
				{
					int num3;
					int num4;
					int num7 = *(ref num3 + (IntPtr)num4);
					int num6;
					num7 = *(ref GhostPatch2.QDtKOfSgLg + (IntPtr)num6);
					num2 = (((num7 <= num7) ? 3811388232U : 4025928001U) ^ num * 302461577U);
					continue;
				}
				case 48U:
				{
					result = (((__instance == calli(GorillaTagger(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array5[0] ^ array5[1]) - array5[2]]).offlineVRRig) ? 1 : 0) == array5[3]);
					uint num89 = num ^ (uint)(*(&GhostPatch2.OMNu4ysEqQ));
					uint num90 = num89 - (uint)(*(&GhostPatch2.5FOQ9TF4hD));
					num2 = (num90 * (uint)(*(&GhostPatch2.9MazqrVinL) + *(&GhostPatch2.gH8k3ytVId)) ^ (uint)(*(&GhostPatch2.ChiGgEXBbt)));
					continue;
				}
				case 49U:
				{
					int num3;
					int num7;
					int num5 = num7 | num3;
					uint[] array29 = new uint[*(&GhostPatch2.biL6t3EaJz) + *(&GhostPatch2.DFmNgX0BsW)];
					array29[*(&GhostPatch2.ylUSOO6ngk)] = (uint)(*(&GhostPatch2.jBLVS4Ygs0));
					array29[*(&GhostPatch2.BFp035ICQx)] = (uint)(*(&GhostPatch2.nLy310O3se) + *(&GhostPatch2.7a3iQC4R5l));
					array29[*(&GhostPatch2.9TT1Vt5dYS) + *(&GhostPatch2.G4Xs7XMRec)] = (uint)(*(&GhostPatch2.qeyO3kLHk1));
					array29[*(&GhostPatch2.A1HpxT26iH) + *(&GhostPatch2.4veZYCDKk2)] = (uint)(*(&GhostPatch2.zmwd5efF8u));
					array29[*(&GhostPatch2.hy2hSPws5n) + *(&GhostPatch2.fPtWh4AYz0)] = (uint)(*(&GhostPatch2.hAgrBXEotS));
					uint num91 = (num & (uint)(*(&GhostPatch2.yx8xjG27HJ))) - (uint)(*(&GhostPatch2.PVP6Xj3Z5A) + *(&GhostPatch2.eGPHNgSLf4)) + (uint)(*(&GhostPatch2.KI8mzrR6xb));
					uint num92 = num91 ^ (uint)(*(&GhostPatch2.BCQqkMvjUc));
					num2 = (num92 + array29[*(&GhostPatch2.eossxsh1jC) + *(&GhostPatch2.xrcN8GWmHp)] ^ (uint)(*(&GhostPatch2.S6me8czjgB)));
					continue;
				}
				case 50U:
				{
					int num3;
					num2 = (((num3 > num3) ? 2911720798U : 3731969657U) ^ num * 3435060252U);
					continue;
				}
				case 51U:
				{
					int num3;
					int num5;
					int num6 = num5 * num3;
					uint[] array30 = new uint[*(&GhostPatch2.0XjoZvtHb7)];
					array30[*(&GhostPatch2.9AnSsz9uqF)] = (uint)(*(&GhostPatch2.GowV07xt5E) + *(&GhostPatch2.sHmjdLLBDp));
					array30[*(&GhostPatch2.uKRL3okia2)] = (uint)(*(&GhostPatch2.tNa4QLkOyc));
					array30[*(&GhostPatch2.79MXP2YDyh)] = (uint)(*(&GhostPatch2.n8qBV6XlbM));
					num2 = ((num - array30[*(&GhostPatch2.XPSDUeqrTS)] & array30[*(&GhostPatch2.k7Mlru836B)]) ^ (uint)(*(&GhostPatch2.Pgt3OuhYjU)) ^ (uint)(*(&GhostPatch2.y9xmFrrIDu)));
					continue;
				}
				case 52U:
				{
					int num6;
					int num3 = (int)((ushort)num6);
					int num5;
					num2 = (((num5 > num5) ? 827200749U : 1661676469U) ^ num * 671716685U);
					continue;
				}
				case 53U:
				{
					int num4;
					*(ref GhostPatch2.QDtKOfSgLg + (IntPtr)num4) = num4;
					num2 = 2809491471U;
					continue;
				}
				case 54U:
				{
					array5[0] = 584669189;
					array5[1] = 1996403902;
					uint num93 = num ^ (uint)(*(&GhostPatch2.lnaCarBZ3H)) ^ (uint)(*(&GhostPatch2.OCp2CiGd0f));
					num2 = (num93 ^ (uint)(*(&GhostPatch2.pLEwYMdagF)) ^ (uint)(*(&GhostPatch2.CSOIAVBA7V)));
					continue;
				}
				case 55U:
				{
					int num5;
					int num7 = num5 + 798;
					uint num94 = (num & (uint)(*(&GhostPatch2.gOiXsiJNb6))) * (uint)(*(&GhostPatch2.AwKZaQTeBA));
					uint num95 = num94 * (uint)(*(&GhostPatch2.BvB76dK0Wu));
					num2 = ((num95 ^ (uint)(*(&GhostPatch2.MLbB0DcBni) + *(&GhostPatch2.BJ6S6aFbog))) - (uint)(*(&GhostPatch2.pMv20uMlaO) + *(&GhostPatch2.XS0rtzUIjX)) ^ (uint)(*(&GhostPatch2.xS0c91ytAg)));
					continue;
				}
				case 56U:
				{
					int num3;
					int num7;
					num7 += num3;
					int num4;
					num4 &= 699861089;
					int num6;
					*(ref num6 + (IntPtr)num3) = num3;
					num2 = ((num | (uint)(*(&GhostPatch2.XtMzE9aiLF))) ^ (uint)(*(&GhostPatch2.01kYLsSOiH)) ^ (uint)(*(&GhostPatch2.F61QtXVS38)) ^ (uint)(*(&GhostPatch2.6dk31oGBnu)));
					continue;
				}
				case 57U:
				{
					int num3;
					int num5;
					int num7 = num5 | num3;
					int num4 = num3 / num4;
					uint num96 = num + (uint)(*(&GhostPatch2.Aaz9FzSFYc));
					uint num97 = num96 + (uint)(*(&GhostPatch2.34INiJU8GO) + *(&GhostPatch2.5rOSP56YWl));
					num2 = ((num97 + (uint)(*(&GhostPatch2.Y0MENQyUE4) + *(&GhostPatch2.cnFT4x9hdN))) * (uint)(*(&GhostPatch2.AbXFbSMhuJ)) ^ (uint)(*(&GhostPatch2.24sxDDrE9R)));
					continue;
				}
				case 59U:
				{
					array5[3] = 594188411;
					uint[] array31 = new uint[*(&GhostPatch2.wXWtHVwhUv)];
					array31[*(&GhostPatch2.YLpnlt6Eb5)] = (uint)(*(&GhostPatch2.k2jcuTfghe));
					array31[*(&GhostPatch2.LkUS4KuxWN)] = (uint)(*(&GhostPatch2.NSVTxRPcvg));
					array31[*(&GhostPatch2.nqwR83x48y)] = (uint)(*(&GhostPatch2.0P9zky0Xsb) + *(&GhostPatch2.9JrOsRhQod));
					array31[*(&GhostPatch2.DCuA1fxDTA) + *(&GhostPatch2.WzyiW7Tfs9)] = (uint)(*(&GhostPatch2.a2tThd9ijq));
					uint num98 = num | array31[*(&GhostPatch2.WhPfuxe88F)] | array31[*(&GhostPatch2.AxDsFJUI1u)];
					num2 = (((num98 ^ (uint)(*(&GhostPatch2.8ChpCLSbdX) + *(&GhostPatch2.fPemozkTyj))) | array31[*(&GhostPatch2.cUhn8nyBOY)]) ^ (uint)(*(&GhostPatch2.J0qysUAjcj)));
					continue;
				}
				case 60U:
				{
					int num5;
					int num7 = ~num5;
					GhostPatch2.QDtKOfSgLg = num5;
					uint[] array32 = new uint[*(&GhostPatch2.IAhWPuhl2b)];
					array32[*(&GhostPatch2.zYpFs4eevL)] = (uint)(*(&GhostPatch2.S0wuEzM3ZV));
					array32[*(&GhostPatch2.kOiCTJ3o05)] = (uint)(*(&GhostPatch2.6U1lg5he0a));
					array32[*(&GhostPatch2.hjMJjRNxRZ)] = (uint)(*(&GhostPatch2.hnLg0kzmwj) + *(&GhostPatch2.B0n0O88LOJ));
					array32[*(&GhostPatch2.SsC8yBCYdB) + *(&GhostPatch2.5GWbXSIUu5)] = (uint)(*(&GhostPatch2.F5sRZq5V4l));
					uint num99 = num & array32[*(&GhostPatch2.TCjIHzkNsz)];
					uint num100 = num99 & array32[*(&GhostPatch2.iaIvo4dMc6)];
					uint num101 = num100 + array32[*(&GhostPatch2.znbSDX9viH)];
					num2 = (num101 ^ array32[*(&GhostPatch2.Fqe2r3hOUi)] ^ (uint)(*(&GhostPatch2.r4m4Xow7me) + *(&GhostPatch2.Nt28vpkQFu)));
					continue;
				}
				case 61U:
				{
					int num3;
					int num7 = num3;
					int num4 = num3 | 1012469271;
					int num5;
					num2 = (((num5 > num5) ? 353499281U : 736859567U) ^ num * 480308184U);
					continue;
				}
				case 62U:
					num2 = 3487278165U;
					continue;
				case 63U:
				{
					int num3;
					int num4;
					int num5 = num4 & num3;
					uint[] array33 = new uint[*(&GhostPatch2.ab07vYr9Wn)];
					array33[*(&GhostPatch2.9AamJKHZcK)] = (uint)(*(&GhostPatch2.ufhRW8Nvb6) + *(&GhostPatch2.Z8Xf3wr8Js));
					array33[*(&GhostPatch2.fyckrgC6TT)] = (uint)(*(&GhostPatch2.nyXpp53jlx) + *(&GhostPatch2.K6iaOBm4sW));
					array33[*(&GhostPatch2.dIQup6C7jz)] = (uint)(*(&GhostPatch2.6RcISkksz8) + *(&GhostPatch2.3HXVhjQCWq));
					array33[*(&GhostPatch2.4HO6zfinAt) + *(&GhostPatch2.26Aw13dZHo)] = (uint)(*(&GhostPatch2.a3EtdWu4MF));
					array33[*(&GhostPatch2.qAk24zCfSw)] = (uint)(*(&GhostPatch2.B7sGG6Hleo) + *(&GhostPatch2.F04sQBCedd));
					array33[*(&GhostPatch2.vna4C1VH1C)] = (uint)(*(&GhostPatch2.08HVmdK8ng));
					uint num102 = num * (uint)(*(&GhostPatch2.PIaiA0G2m3)) - (uint)(*(&GhostPatch2.wiByBYhyDP) + *(&GhostPatch2.k9ucxGsiFw)) & array33[*(&GhostPatch2.0E17OmN13M) + *(&GhostPatch2.vcf7PS6SUO)];
					uint num103 = num102 & (uint)(*(&GhostPatch2.6W4Y5QY8v3));
					uint num104 = num103 * array33[*(&GhostPatch2.HhxzDsrEkY)];
					num2 = (num104 * (uint)(*(&GhostPatch2.Kp41dIdwMf)) ^ (uint)(*(&GhostPatch2.KZN10dJdB8)));
					continue;
				}
				case 64U:
				{
					int num3;
					int num4;
					int num7 = num4 / num3;
					int[] array8;
					int num6 = array8[num3 + 8 - num4] + 1;
					uint[] array34 = new uint[*(&GhostPatch2.PFzyHwUSu8)];
					array34[*(&GhostPatch2.U1RAGhr8EF)] = (uint)(*(&GhostPatch2.LqqkC89nTC));
					array34[*(&GhostPatch2.7cS0xYbM01)] = (uint)(*(&GhostPatch2.diJBmCBpJ0));
					array34[*(&GhostPatch2.knCSkiZOwJ)] = (uint)(*(&GhostPatch2.wq9sA1jbMs) + *(&GhostPatch2.GeHNlmho89));
					uint num105 = (num & array34[*(&GhostPatch2.7TdccUZAPP)]) + array34[*(&GhostPatch2.9MarEwibBu)];
					num2 = (num105 + (uint)(*(&GhostPatch2.djdbuFfyq7)) ^ (uint)(*(&GhostPatch2.BuQwLdNhQp)));
					continue;
				}
				case 65U:
				{
					int num5;
					int num6;
					int[] array8;
					array8[num6 + 8 - num5] = num5 - 5;
					uint num106 = ((num | (uint)(*(&GhostPatch2.beLS9uHBvw))) & (uint)(*(&GhostPatch2.DkOGucVnsc) + *(&GhostPatch2.NOBjHp8P9J))) | (uint)(*(&GhostPatch2.X7fU9S8m7V));
					num2 = ((num106 | (uint)(*(&GhostPatch2.JE9iHFvyAL) + *(&GhostPatch2.4Vns3NcmLU))) + (uint)(*(&GhostPatch2.w1BmZFE3Hb)) ^ (uint)(*(&GhostPatch2.dtpWTJPcbC) + *(&GhostPatch2.3JPyOBUxbv)));
					continue;
				}
				case 66U:
				{
					int num4 = -num4;
					uint num107 = num ^ (uint)(*(&GhostPatch2.ak6maVk4vk));
					uint num108 = num107 & (uint)(*(&GhostPatch2.hvqc2CDrqZ)) & (uint)(*(&GhostPatch2.qTZUmHznNY));
					num2 = (num108 + (uint)(*(&GhostPatch2.UmCCU1Csjd)) ^ (uint)(*(&GhostPatch2.5XQQMCCvPd)));
					continue;
				}
				case 67U:
				{
					int num3;
					int num6 = num3 << 2;
					int num4 = num6 % num3;
					uint[] array35 = new uint[*(&GhostPatch2.2L4VhPoeF8)];
					array35[*(&GhostPatch2.nE5YmvgFHc)] = (uint)(*(&GhostPatch2.M8VY2GMkK8) + *(&GhostPatch2.bNzHX3hfcy));
					array35[*(&GhostPatch2.3j7t4kopnN)] = (uint)(*(&GhostPatch2.LjiFJ40fca));
					array35[*(&GhostPatch2.DETGhaOyAt) + *(&GhostPatch2.NAmSinAleS)] = (uint)(*(&GhostPatch2.bh67x1pu7d));
					uint num109 = num + (uint)(*(&GhostPatch2.CBCCvyP0Md));
					uint num110 = num109 & array35[*(&GhostPatch2.V0o39L7Pgg)];
					num2 = ((num110 | array35[*(&GhostPatch2.3OBK8gHWTp)]) ^ (uint)(*(&GhostPatch2.ue0hqL7khu)));
					continue;
				}
				case 68U:
				{
					int num4;
					int num6 = (int)((byte)num4);
					int num3;
					num2 = (((num3 > num3) ? 741063944U : 1268374200U) ^ num * 3403782803U);
					continue;
				}
				case 69U:
					num2 = 2176975086U;
					continue;
				case 70U:
					num2 = 2487511878U;
					continue;
				case 71U:
				{
					int num6;
					int num3 = (int)((sbyte)num6);
					int num7;
					int num4 = num7 & 2000715534;
					int num5;
					num7 = num5 / 623;
					uint[] array36 = new uint[*(&GhostPatch2.vqMmiOi6Sj) + *(&GhostPatch2.GzTMi1hche)];
					array36[*(&GhostPatch2.UAxK2qyVHo)] = (uint)(*(&GhostPatch2.gyP4icAAfB));
					array36[*(&GhostPatch2.KcS6bjV4w3)] = (uint)(*(&GhostPatch2.fjyKxv3Ct2));
					array36[*(&GhostPatch2.aMynDRjZoG)] = (uint)(*(&GhostPatch2.0g6fU1s0sS));
					uint num111 = num & array36[*(&GhostPatch2.U3jOJ7AEGw)];
					uint num112 = num111 * (uint)(*(&GhostPatch2.i8Qml7np3J));
					num2 = (num112 ^ (uint)(*(&GhostPatch2.A6PqC9mS06) + *(&GhostPatch2.DDUbignkeF)) ^ (uint)(*(&GhostPatch2.RfS2h2PT4W)));
					continue;
				}
				case 72U:
				{
					int num3;
					int num4 = num3 + 469;
					int num6;
					num2 = (((num6 <= num6) ? 3219116675U : 2737199730U) ^ num * 3565967200U);
					continue;
				}
				case 73U:
				{
					int num5;
					int num3 = num5 & num3;
					uint num113 = (num + (uint)(*(&GhostPatch2.kS1oLt832k))) * (uint)(*(&GhostPatch2.HZETvgBArP)) | (uint)(*(&GhostPatch2.eAahQAaMdF));
					num2 = ((num113 & (uint)(*(&GhostPatch2.GtdO2zrh4q))) ^ (uint)(*(&GhostPatch2.LSair63zc2)));
					continue;
				}
				case 74U:
				{
					int num5;
					int num3 = num5 / 960;
					int num4;
					num5 = num4 % num3;
					uint[] array37 = new uint[*(&GhostPatch2.vs0CZfaPyG) + *(&GhostPatch2.KZWunUjDrd)];
					array37[*(&GhostPatch2.zIboJiCNtV)] = (uint)(*(&GhostPatch2.28UiRE0axc));
					array37[*(&GhostPatch2.qGxAf2k21o)] = (uint)(*(&GhostPatch2.2v1CLnQM21));
					array37[*(&GhostPatch2.dNfdOMExci) + *(&GhostPatch2.dJQOxsUbJR)] = (uint)(*(&GhostPatch2.7JWFcGGSWn));
					array37[*(&GhostPatch2.xoh69clUwT) + *(&GhostPatch2.xwZSLtfmOd)] = (uint)(*(&GhostPatch2.TzDl3T1aAH) + *(&GhostPatch2.FwazuzmTPV));
					array37[*(&GhostPatch2.H9o0dLuD3t) + *(&GhostPatch2.kdD3U7l5Dq)] = (uint)(*(&GhostPatch2.lKUoNBVkhW));
					array37[*(&GhostPatch2.GLX3VTLNIs)] = (uint)(*(&GhostPatch2.jxgQgltgew));
					uint num114 = num & array37[*(&GhostPatch2.NqQjt6pAmb)];
					uint num115 = (num114 & array37[*(&GhostPatch2.zJghmYGJiB)]) * array37[*(&GhostPatch2.wXxVGynDHl)];
					uint num116 = num115 + array37[*(&GhostPatch2.SzGuIa5yKZ)] & (uint)(*(&GhostPatch2.nKkq2ZQ9nH));
					num2 = (num116 + (uint)(*(&GhostPatch2.fj8dA035c4) + *(&GhostPatch2.Sm2AJADvYM)) ^ (uint)(*(&GhostPatch2.dR9JXlxGcr)));
					continue;
				}
				case 75U:
					num2 = 2739909749U;
					continue;
				case 76U:
				{
					int num3;
					int num6 = ~num3;
					uint[] array38 = new uint[*(&GhostPatch2.9MG65ja8Oc)];
					array38[*(&GhostPatch2.BmA7qlt8n7)] = (uint)(*(&GhostPatch2.P8dzlWvFF0));
					array38[*(&GhostPatch2.Y0RlR0P4pz)] = (uint)(*(&GhostPatch2.uoU3NmfN7r) + *(&GhostPatch2.WaWWWAtRUi));
					array38[*(&GhostPatch2.xV2XELUYqz) + *(&GhostPatch2.VzSxNknkl8)] = (uint)(*(&GhostPatch2.1iHYe7e5PQ));
					array38[*(&GhostPatch2.H8jGCZv6zC)] = (uint)(*(&GhostPatch2.SGhIVgHiIv));
					array38[*(&GhostPatch2.XJpWrPNe3G)] = (uint)(*(&GhostPatch2.rZJZsXPMuy));
					uint num117 = num - (uint)(*(&GhostPatch2.yquiquA9C7)) | (uint)(*(&GhostPatch2.05wd38SNZw));
					uint num118 = num117 - (uint)(*(&GhostPatch2.LQDtV36HZ8));
					num2 = ((num118 * array38[*(&GhostPatch2.R5yU6qYHp6)] | (uint)(*(&GhostPatch2.OOc5Pwmqgt) + *(&GhostPatch2.EBw8minBMw))) ^ (uint)(*(&GhostPatch2.x3jEq4HbgM) + *(&GhostPatch2.kLhci7yHdj)));
					continue;
				}
				}
				break;
			}
			return result;
			IL_24:
			num2 = 2525728634U;
			goto IL_29;
			IL_B24:
			array5 = new int[15];
			int num119 = 496;
			num2 = ((num119 == 496) ? 4226899993U : 2592347881U);
			goto IL_29;
		}

		// Token: 0x0404F648 RID: 325192 RVA: 0x001495F0 File Offset: 0x001477F0
		static int ER4FyMrT0I;

		// Token: 0x0404F649 RID: 325193 RVA: 0x001495F8 File Offset: 0x001477F8
		static int QDtKOfSgLg;

		// Token: 0x0404F64A RID: 325194 RVA: 0x00149600 File Offset: 0x00147800
		static readonly int ny2kMbehXr;

		// Token: 0x0404F64B RID: 325195 RVA: 0x00046B90 File Offset: 0x00044D90
		static readonly int J8kTXAxbQs;

		// Token: 0x0404F64C RID: 325196 RVA: 0x00149608 File Offset: 0x00147808
		static readonly int h7eSOkc5He;

		// Token: 0x0404F64D RID: 325197 RVA: 0x00149610 File Offset: 0x00147810
		static readonly int Zjqv342NQK;

		// Token: 0x0404F64E RID: 325198 RVA: 0x00149618 File Offset: 0x00147818
		static readonly int SYvKJZPfw3;

		// Token: 0x0404F64F RID: 325199 RVA: 0x00149620 File Offset: 0x00147820
		static readonly int GMGHYqUjVm;

		// Token: 0x0404F650 RID: 325200 RVA: 0x00149628 File Offset: 0x00147828
		static readonly int 8ja2SjSzad;

		// Token: 0x0404F651 RID: 325201 RVA: 0x00149630 File Offset: 0x00147830
		static readonly int IjLGaJLTIy;

		// Token: 0x0404F652 RID: 325202 RVA: 0x00149638 File Offset: 0x00147838
		static readonly int V7INYMciWM;

		// Token: 0x0404F653 RID: 325203 RVA: 0x00149640 File Offset: 0x00147840
		static readonly int kS1oLt832k;

		// Token: 0x0404F654 RID: 325204 RVA: 0x00149648 File Offset: 0x00147848
		static readonly int HZETvgBArP;

		// Token: 0x0404F655 RID: 325205 RVA: 0x00149650 File Offset: 0x00147850
		static readonly int eAahQAaMdF;

		// Token: 0x0404F656 RID: 325206 RVA: 0x00149658 File Offset: 0x00147858
		static readonly int GtdO2zrh4q;

		// Token: 0x0404F657 RID: 325207 RVA: 0x00149660 File Offset: 0x00147860
		static readonly int LSair63zc2;

		// Token: 0x0404F658 RID: 325208 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int Lc0Grj1UXK;

		// Token: 0x0404F659 RID: 325209 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int TvZxdX5za5;

		// Token: 0x0404F65A RID: 325210 RVA: 0x00149668 File Offset: 0x00147868
		static readonly int zeFBDMk20U;

		// Token: 0x0404F65B RID: 325211 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Hltl3o3WgT;

		// Token: 0x0404F65C RID: 325212 RVA: 0x00149670 File Offset: 0x00147870
		static readonly int 8WJtWZ3nFT;

		// Token: 0x0404F65D RID: 325213 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ADYhCrXzDf;

		// Token: 0x0404F65E RID: 325214 RVA: 0x00149678 File Offset: 0x00147878
		static readonly int 99eDDsCx3y;

		// Token: 0x0404F65F RID: 325215 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ejTH7cUVoo;

		// Token: 0x0404F660 RID: 325216 RVA: 0x00149680 File Offset: 0x00147880
		static readonly int T6wgTDMMjM;

		// Token: 0x0404F661 RID: 325217 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int QETBU82Fqo;

		// Token: 0x0404F662 RID: 325218 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int WFtQybuRjk;

		// Token: 0x0404F663 RID: 325219 RVA: 0x00149688 File Offset: 0x00147888
		static readonly int WBKYMCN7tA;

		// Token: 0x0404F664 RID: 325220 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int f0OrhaPSw8;

		// Token: 0x0404F665 RID: 325221 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kPp9RNNfs2;

		// Token: 0x0404F666 RID: 325222 RVA: 0x00149678 File Offset: 0x00147878
		static readonly int T5m8zP34yS;

		// Token: 0x0404F667 RID: 325223 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int v4WqJg1BsX;

		// Token: 0x0404F668 RID: 325224 RVA: 0x00149688 File Offset: 0x00147888
		static readonly int LcekAHWKH8;

		// Token: 0x0404F669 RID: 325225 RVA: 0x00149690 File Offset: 0x00147890
		static readonly int yrP0qkNP1S;

		// Token: 0x0404F66A RID: 325226 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int hUdeNp290u;

		// Token: 0x0404F66B RID: 325227 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int VLwUr0aC8s;

		// Token: 0x0404F66C RID: 325228 RVA: 0x00149698 File Offset: 0x00147898
		static readonly int 2tx0dEpf9j;

		// Token: 0x0404F66D RID: 325229 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TmKa009AXU;

		// Token: 0x0404F66E RID: 325230 RVA: 0x001496A0 File Offset: 0x001478A0
		static readonly int OXUWnn44J0;

		// Token: 0x0404F66F RID: 325231 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int JKQIaxhnBJ;

		// Token: 0x0404F670 RID: 325232 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int AW9RatBWe0;

		// Token: 0x0404F671 RID: 325233 RVA: 0x001496A8 File Offset: 0x001478A8
		static readonly int 1apodeZaMz;

		// Token: 0x0404F672 RID: 325234 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int JvWJZJVB9C;

		// Token: 0x0404F673 RID: 325235 RVA: 0x001496B0 File Offset: 0x001478B0
		static readonly int TV8NT2XC63;

		// Token: 0x0404F674 RID: 325236 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int liZS8sfmo5;

		// Token: 0x0404F675 RID: 325237 RVA: 0x001496B8 File Offset: 0x001478B8
		static readonly int YGaLAPA01R;

		// Token: 0x0404F676 RID: 325238 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int YAXbhfbbUl;

		// Token: 0x0404F677 RID: 325239 RVA: 0x001496C0 File Offset: 0x001478C0
		static readonly int GWeSOlVELq;

		// Token: 0x0404F678 RID: 325240 RVA: 0x001496C8 File Offset: 0x001478C8
		static readonly int nsWDnM5xNE;

		// Token: 0x0404F679 RID: 325241 RVA: 0x00149698 File Offset: 0x00147898
		static readonly int 1hLpflL8vc;

		// Token: 0x0404F67A RID: 325242 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int RERCzCmH7Z;

		// Token: 0x0404F67B RID: 325243 RVA: 0x001496A8 File Offset: 0x001478A8
		static readonly int 45pKnpoTxU;

		// Token: 0x0404F67C RID: 325244 RVA: 0x001496D0 File Offset: 0x001478D0
		static readonly int koNQujLywm;

		// Token: 0x0404F67D RID: 325245 RVA: 0x001496D8 File Offset: 0x001478D8
		static readonly int aXSsZjaTOl;

		// Token: 0x0404F67E RID: 325246 RVA: 0x001496B8 File Offset: 0x001478B8
		static readonly int kxzyJ51AB0;

		// Token: 0x0404F67F RID: 325247 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 71Kb1m0BSP;

		// Token: 0x0404F680 RID: 325248 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1xUU9gn6vE;

		// Token: 0x0404F681 RID: 325249 RVA: 0x001496E0 File Offset: 0x001478E0
		static readonly int OUFMuwyZGy;

		// Token: 0x0404F682 RID: 325250 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int rKx6piN11x;

		// Token: 0x0404F683 RID: 325251 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sZA8twcfzn;

		// Token: 0x0404F684 RID: 325252 RVA: 0x001496E8 File Offset: 0x001478E8
		static readonly int S5O6lmw7rE;

		// Token: 0x0404F685 RID: 325253 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xb4eiq9Yoa;

		// Token: 0x0404F686 RID: 325254 RVA: 0x001496F0 File Offset: 0x001478F0
		static readonly int TvF8WzUGd7;

		// Token: 0x0404F687 RID: 325255 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int UTkdfw51VD;

		// Token: 0x0404F688 RID: 325256 RVA: 0x001496F8 File Offset: 0x001478F8
		static readonly int wQKw9RffZC;

		// Token: 0x0404F689 RID: 325257 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int wE0YTgzQjv;

		// Token: 0x0404F68A RID: 325258 RVA: 0x00149700 File Offset: 0x00147900
		static readonly int Spdtud0a9v;

		// Token: 0x0404F68B RID: 325259 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int uICloDlT8E;

		// Token: 0x0404F68C RID: 325260 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TyqaKPcLK8;

		// Token: 0x0404F68D RID: 325261 RVA: 0x00149708 File Offset: 0x00147908
		static readonly int 7pRjvHwaBf;

		// Token: 0x0404F68E RID: 325262 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int aEgoSoCPuP;

		// Token: 0x0404F68F RID: 325263 RVA: 0x00149710 File Offset: 0x00147910
		static readonly int 4fSfbd8Djf;

		// Token: 0x0404F690 RID: 325264 RVA: 0x00149718 File Offset: 0x00147918
		static readonly int BpQAyF0c0g;

		// Token: 0x0404F691 RID: 325265 RVA: 0x001496E8 File Offset: 0x001478E8
		static readonly int RLScoPSCIf;

		// Token: 0x0404F692 RID: 325266 RVA: 0x001496F0 File Offset: 0x001478F0
		static readonly int NNb4DbXwHR;

		// Token: 0x0404F693 RID: 325267 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Is1gevyfzM;

		// Token: 0x0404F694 RID: 325268 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int yjZN8tNz0M;

		// Token: 0x0404F695 RID: 325269 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int L55DRxNW6X;

		// Token: 0x0404F696 RID: 325270 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int sDUiXiTw83;

		// Token: 0x0404F697 RID: 325271 RVA: 0x00149720 File Offset: 0x00147920
		static readonly int awN5rnyN5U;

		// Token: 0x0404F698 RID: 325272 RVA: 0x00149728 File Offset: 0x00147928
		static readonly int Oh65GNxyOr;

		// Token: 0x0404F699 RID: 325273 RVA: 0x00149730 File Offset: 0x00147930
		static readonly int hcjcevO0za;

		// Token: 0x0404F69A RID: 325274 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int ab07vYr9Wn;

		// Token: 0x0404F69B RID: 325275 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 9AamJKHZcK;

		// Token: 0x0404F69C RID: 325276 RVA: 0x00149738 File Offset: 0x00147938
		static readonly int ufhRW8Nvb6;

		// Token: 0x0404F69D RID: 325277 RVA: 0x00149740 File Offset: 0x00147940
		static readonly int Z8Xf3wr8Js;

		// Token: 0x0404F69E RID: 325278 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int fyckrgC6TT;

		// Token: 0x0404F69F RID: 325279 RVA: 0x00149748 File Offset: 0x00147948
		static readonly int nyXpp53jlx;

		// Token: 0x0404F6A0 RID: 325280 RVA: 0x00149750 File Offset: 0x00147950
		static readonly int K6iaOBm4sW;

		// Token: 0x0404F6A1 RID: 325281 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int dIQup6C7jz;

		// Token: 0x0404F6A2 RID: 325282 RVA: 0x00149758 File Offset: 0x00147958
		static readonly int 6RcISkksz8;

		// Token: 0x0404F6A3 RID: 325283 RVA: 0x00149760 File Offset: 0x00147960
		static readonly int 3HXVhjQCWq;

		// Token: 0x0404F6A4 RID: 325284 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4HO6zfinAt;

		// Token: 0x0404F6A5 RID: 325285 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 26Aw13dZHo;

		// Token: 0x0404F6A6 RID: 325286 RVA: 0x00149768 File Offset: 0x00147968
		static readonly int a3EtdWu4MF;

		// Token: 0x0404F6A7 RID: 325287 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int qAk24zCfSw;

		// Token: 0x0404F6A8 RID: 325288 RVA: 0x00149770 File Offset: 0x00147970
		static readonly int B7sGG6Hleo;

		// Token: 0x0404F6A9 RID: 325289 RVA: 0x00149778 File Offset: 0x00147978
		static readonly int F04sQBCedd;

		// Token: 0x0404F6AA RID: 325290 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int vna4C1VH1C;

		// Token: 0x0404F6AB RID: 325291 RVA: 0x00149780 File Offset: 0x00147980
		static readonly int 08HVmdK8ng;

		// Token: 0x0404F6AC RID: 325292 RVA: 0x00149788 File Offset: 0x00147988
		static readonly int PIaiA0G2m3;

		// Token: 0x0404F6AD RID: 325293 RVA: 0x00149790 File Offset: 0x00147990
		static readonly int wiByBYhyDP;

		// Token: 0x0404F6AE RID: 325294 RVA: 0x00149798 File Offset: 0x00147998
		static readonly int k9ucxGsiFw;

		// Token: 0x0404F6AF RID: 325295 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 0E17OmN13M;

		// Token: 0x0404F6B0 RID: 325296 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vcf7PS6SUO;

		// Token: 0x0404F6B1 RID: 325297 RVA: 0x00149768 File Offset: 0x00147968
		static readonly int 6W4Y5QY8v3;

		// Token: 0x0404F6B2 RID: 325298 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int HhxzDsrEkY;

		// Token: 0x0404F6B3 RID: 325299 RVA: 0x00149780 File Offset: 0x00147980
		static readonly int Kp41dIdwMf;

		// Token: 0x0404F6B4 RID: 325300 RVA: 0x001497A0 File Offset: 0x001479A0
		static readonly int KZN10dJdB8;

		// Token: 0x0404F6B5 RID: 325301 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int NPF9FNpq4g;

		// Token: 0x0404F6B6 RID: 325302 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int l1s6DQbD4x;

		// Token: 0x0404F6B7 RID: 325303 RVA: 0x001497A8 File Offset: 0x001479A8
		static readonly int wmvQtrT58j;

		// Token: 0x0404F6B8 RID: 325304 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int iNDmK5k5vQ;

		// Token: 0x0404F6B9 RID: 325305 RVA: 0x001497B0 File Offset: 0x001479B0
		static readonly int cx1p3SrRyk;

		// Token: 0x0404F6BA RID: 325306 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int CGiOLlezQX;

		// Token: 0x0404F6BB RID: 325307 RVA: 0x001497B8 File Offset: 0x001479B8
		static readonly int 3urU8XyFvI;

		// Token: 0x0404F6BC RID: 325308 RVA: 0x001497C0 File Offset: 0x001479C0
		static readonly int qgRoU9uFWa;

		// Token: 0x0404F6BD RID: 325309 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ACHXhcoyaj;

		// Token: 0x0404F6BE RID: 325310 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int aupXWsFhrg;

		// Token: 0x0404F6BF RID: 325311 RVA: 0x001497C8 File Offset: 0x001479C8
		static readonly int elgp4gy43M;

		// Token: 0x0404F6C0 RID: 325312 RVA: 0x001497A8 File Offset: 0x001479A8
		static readonly int 0ZczX1mUwg;

		// Token: 0x0404F6C1 RID: 325313 RVA: 0x001497B0 File Offset: 0x001479B0
		static readonly int s9pLr503Rm;

		// Token: 0x0404F6C2 RID: 325314 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 3NX06YfbdB;

		// Token: 0x0404F6C3 RID: 325315 RVA: 0x001497D0 File Offset: 0x001479D0
		static readonly int nu5OtBSz9e;

		// Token: 0x0404F6C4 RID: 325316 RVA: 0x001497D8 File Offset: 0x001479D8
		static readonly int FvuLxe6V79;

		// Token: 0x0404F6C5 RID: 325317 RVA: 0x001497E0 File Offset: 0x001479E0
		static readonly int p5nQTnBm39;

		// Token: 0x0404F6C6 RID: 325318 RVA: 0x001497E8 File Offset: 0x001479E8
		static readonly int WL0u38Dbcq;

		// Token: 0x0404F6C7 RID: 325319 RVA: 0x001497F0 File Offset: 0x001479F0
		static readonly int nB3wgHcMCb;

		// Token: 0x0404F6C8 RID: 325320 RVA: 0x001497F8 File Offset: 0x001479F8
		static readonly int bKddWsHp4G;

		// Token: 0x0404F6C9 RID: 325321 RVA: 0x00149800 File Offset: 0x00147A00
		static readonly int Aq6AI449Sz;

		// Token: 0x0404F6CA RID: 325322 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int af2RWoB0tL;

		// Token: 0x0404F6CB RID: 325323 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int KzjbhLrWYL;

		// Token: 0x0404F6CC RID: 325324 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 1YgWp6F3nm;

		// Token: 0x0404F6CD RID: 325325 RVA: 0x00149808 File Offset: 0x00147A08
		static readonly int Md3NB6RMHs;

		// Token: 0x0404F6CE RID: 325326 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int qQ5t5KHed6;

		// Token: 0x0404F6CF RID: 325327 RVA: 0x00149810 File Offset: 0x00147A10
		static readonly int NhlH7B8glZ;

		// Token: 0x0404F6D0 RID: 325328 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int iHMH8r5Vak;

		// Token: 0x0404F6D1 RID: 325329 RVA: 0x00149818 File Offset: 0x00147A18
		static readonly int 4ePpekdxaf;

		// Token: 0x0404F6D2 RID: 325330 RVA: 0x00149820 File Offset: 0x00147A20
		static readonly int zkarYo1wQ9;

		// Token: 0x0404F6D3 RID: 325331 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 7uksJjExuO;

		// Token: 0x0404F6D4 RID: 325332 RVA: 0x00149828 File Offset: 0x00147A28
		static readonly int OvE2CsS5nW;

		// Token: 0x0404F6D5 RID: 325333 RVA: 0x00149830 File Offset: 0x00147A30
		static readonly int hLGGj8rftT;

		// Token: 0x0404F6D6 RID: 325334 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int zJEanJ4hg5;

		// Token: 0x0404F6D7 RID: 325335 RVA: 0x00149838 File Offset: 0x00147A38
		static readonly int gqDLQDghop;

		// Token: 0x0404F6D8 RID: 325336 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int W6J3cwoeIL;

		// Token: 0x0404F6D9 RID: 325337 RVA: 0x00149810 File Offset: 0x00147A10
		static readonly int 1iDaZFqoP3;

		// Token: 0x0404F6DA RID: 325338 RVA: 0x00149840 File Offset: 0x00147A40
		static readonly int yvZr00I5zf;

		// Token: 0x0404F6DB RID: 325339 RVA: 0x00149848 File Offset: 0x00147A48
		static readonly int bJ0E72AL70;

		// Token: 0x0404F6DC RID: 325340 RVA: 0x00149838 File Offset: 0x00147A38
		static readonly int fZYUD7nmvK;

		// Token: 0x0404F6DD RID: 325341 RVA: 0x00149850 File Offset: 0x00147A50
		static readonly int W2Sv0khbDl;

		// Token: 0x0404F6DE RID: 325342 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int nsomtrr9ch;

		// Token: 0x0404F6DF RID: 325343 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int FfqYXZWEo2;

		// Token: 0x0404F6E0 RID: 325344 RVA: 0x00149858 File Offset: 0x00147A58
		static readonly int NfKoJj1FNW;

		// Token: 0x0404F6E1 RID: 325345 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int UiIWNwvwlW;

		// Token: 0x0404F6E2 RID: 325346 RVA: 0x00149860 File Offset: 0x00147A60
		static readonly int PnJOF1M4Xb;

		// Token: 0x0404F6E3 RID: 325347 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int OdxKXHi9dJ;

		// Token: 0x0404F6E4 RID: 325348 RVA: 0x00149868 File Offset: 0x00147A68
		static readonly int 0mwGMgXTLl;

		// Token: 0x0404F6E5 RID: 325349 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int nkcSmjW5jR;

		// Token: 0x0404F6E6 RID: 325350 RVA: 0x00149870 File Offset: 0x00147A70
		static readonly int X6svI1v78F;

		// Token: 0x0404F6E7 RID: 325351 RVA: 0x00149878 File Offset: 0x00147A78
		static readonly int NvSbfn1DBi;

		// Token: 0x0404F6E8 RID: 325352 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int e2tvxnAfiy;

		// Token: 0x0404F6E9 RID: 325353 RVA: 0x00149880 File Offset: 0x00147A80
		static readonly int vmaLw33A8U;

		// Token: 0x0404F6EA RID: 325354 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vZVFX1RBw8;

		// Token: 0x0404F6EB RID: 325355 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int sS4AxfN68e;

		// Token: 0x0404F6EC RID: 325356 RVA: 0x00149888 File Offset: 0x00147A88
		static readonly int 1PYKTkVHpm;

		// Token: 0x0404F6ED RID: 325357 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int t1FqwEhnX5;

		// Token: 0x0404F6EE RID: 325358 RVA: 0x00149860 File Offset: 0x00147A60
		static readonly int V9skFcsZXR;

		// Token: 0x0404F6EF RID: 325359 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int p7BddgBKwx;

		// Token: 0x0404F6F0 RID: 325360 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int gKWKO0NNOt;

		// Token: 0x0404F6F1 RID: 325361 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 8kiCJ2gyE0;

		// Token: 0x0404F6F2 RID: 325362 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 26tY6wzlNQ;

		// Token: 0x0404F6F3 RID: 325363 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int DW0kZLmiVP;

		// Token: 0x0404F6F4 RID: 325364 RVA: 0x00149890 File Offset: 0x00147A90
		static readonly int OfKoSFY9Ul;

		// Token: 0x0404F6F5 RID: 325365 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 9MG65ja8Oc;

		// Token: 0x0404F6F6 RID: 325366 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int BmA7qlt8n7;

		// Token: 0x0404F6F7 RID: 325367 RVA: 0x00149898 File Offset: 0x00147A98
		static readonly int P8dzlWvFF0;

		// Token: 0x0404F6F8 RID: 325368 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Y0RlR0P4pz;

		// Token: 0x0404F6F9 RID: 325369 RVA: 0x001498A0 File Offset: 0x00147AA0
		static readonly int uoU3NmfN7r;

		// Token: 0x0404F6FA RID: 325370 RVA: 0x001498A8 File Offset: 0x00147AA8
		static readonly int WaWWWAtRUi;

		// Token: 0x0404F6FB RID: 325371 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xV2XELUYqz;

		// Token: 0x0404F6FC RID: 325372 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int VzSxNknkl8;

		// Token: 0x0404F6FD RID: 325373 RVA: 0x001498B0 File Offset: 0x00147AB0
		static readonly int 1iHYe7e5PQ;

		// Token: 0x0404F6FE RID: 325374 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int H8jGCZv6zC;

		// Token: 0x0404F6FF RID: 325375 RVA: 0x001498B8 File Offset: 0x00147AB8
		static readonly int SGhIVgHiIv;

		// Token: 0x0404F700 RID: 325376 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int XJpWrPNe3G;

		// Token: 0x0404F701 RID: 325377 RVA: 0x001498C0 File Offset: 0x00147AC0
		static readonly int rZJZsXPMuy;

		// Token: 0x0404F702 RID: 325378 RVA: 0x00149898 File Offset: 0x00147A98
		static readonly int yquiquA9C7;

		// Token: 0x0404F703 RID: 325379 RVA: 0x001498C8 File Offset: 0x00147AC8
		static readonly int 05wd38SNZw;

		// Token: 0x0404F704 RID: 325380 RVA: 0x001498B0 File Offset: 0x00147AB0
		static readonly int LQDtV36HZ8;

		// Token: 0x0404F705 RID: 325381 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int R5yU6qYHp6;

		// Token: 0x0404F706 RID: 325382 RVA: 0x001498D0 File Offset: 0x00147AD0
		static readonly int OOc5Pwmqgt;

		// Token: 0x0404F707 RID: 325383 RVA: 0x001498D8 File Offset: 0x00147AD8
		static readonly int EBw8minBMw;

		// Token: 0x0404F708 RID: 325384 RVA: 0x001498E0 File Offset: 0x00147AE0
		static readonly int x3jEq4HbgM;

		// Token: 0x0404F709 RID: 325385 RVA: 0x001498E8 File Offset: 0x00147AE8
		static readonly int kLhci7yHdj;

		// Token: 0x0404F70A RID: 325386 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int QQlp3PIzsY;

		// Token: 0x0404F70B RID: 325387 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int CW42JVoXPU;

		// Token: 0x0404F70C RID: 325388 RVA: 0x001498F0 File Offset: 0x00147AF0
		static readonly int pKJTJ2dTao;

		// Token: 0x0404F70D RID: 325389 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int tfinfhS3Ka;

		// Token: 0x0404F70E RID: 325390 RVA: 0x001498F8 File Offset: 0x00147AF8
		static readonly int wRtIKNRpTM;

		// Token: 0x0404F70F RID: 325391 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Sb2I4GHRgB;

		// Token: 0x0404F710 RID: 325392 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vyZDpgxQWl;

		// Token: 0x0404F711 RID: 325393 RVA: 0x00149900 File Offset: 0x00147B00
		static readonly int CvMziXbBJ5;

		// Token: 0x0404F712 RID: 325394 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int kyANWRnasZ;

		// Token: 0x0404F713 RID: 325395 RVA: 0x00149908 File Offset: 0x00147B08
		static readonly int ZAXJo71pcn;

		// Token: 0x0404F714 RID: 325396 RVA: 0x00149910 File Offset: 0x00147B10
		static readonly int aASrJhPCjg;

		// Token: 0x0404F715 RID: 325397 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int oFHka7yLrY;

		// Token: 0x0404F716 RID: 325398 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 3Xi7MCXCKl;

		// Token: 0x0404F717 RID: 325399 RVA: 0x00149918 File Offset: 0x00147B18
		static readonly int fwigfkgSDy;

		// Token: 0x0404F718 RID: 325400 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Ck0LuT3xtr;

		// Token: 0x0404F719 RID: 325401 RVA: 0x001498F8 File Offset: 0x00147AF8
		static readonly int Ip7EuDcUfH;

		// Token: 0x0404F71A RID: 325402 RVA: 0x00149900 File Offset: 0x00147B00
		static readonly int KM27B2hlFz;

		// Token: 0x0404F71B RID: 325403 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int agI3WSgWM2;

		// Token: 0x0404F71C RID: 325404 RVA: 0x00149918 File Offset: 0x00147B18
		static readonly int IkScdzyewc;

		// Token: 0x0404F71D RID: 325405 RVA: 0x00149920 File Offset: 0x00147B20
		static readonly int HLx5ozs2K2;

		// Token: 0x0404F71E RID: 325406 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int wRs3RmhEsb;

		// Token: 0x0404F71F RID: 325407 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int gGIn8j3ZeL;

		// Token: 0x0404F720 RID: 325408 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int EDzmsOtMPg;

		// Token: 0x0404F721 RID: 325409 RVA: 0x00149928 File Offset: 0x00147B28
		static readonly int jnLTF12ZL0;

		// Token: 0x0404F722 RID: 325410 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int SuvU5BDJ6E;

		// Token: 0x0404F723 RID: 325411 RVA: 0x00149930 File Offset: 0x00147B30
		static readonly int 5SY9ytcFLC;

		// Token: 0x0404F724 RID: 325412 RVA: 0x00149938 File Offset: 0x00147B38
		static readonly int 3UyL234yhH;

		// Token: 0x0404F725 RID: 325413 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int reNn3URfrq;

		// Token: 0x0404F726 RID: 325414 RVA: 0x00149940 File Offset: 0x00147B40
		static readonly int KjPKlQPMfV;

		// Token: 0x0404F727 RID: 325415 RVA: 0x00149948 File Offset: 0x00147B48
		static readonly int YxNI775kcC;

		// Token: 0x0404F728 RID: 325416 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int GOlzXbFuFd;

		// Token: 0x0404F729 RID: 325417 RVA: 0x00149950 File Offset: 0x00147B50
		static readonly int c7Xe2UEokl;

		// Token: 0x0404F72A RID: 325418 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int nrSLs3QFq5;

		// Token: 0x0404F72B RID: 325419 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ZrCpk57axK;

		// Token: 0x0404F72C RID: 325420 RVA: 0x00149958 File Offset: 0x00147B58
		static readonly int LfGB3batQn;

		// Token: 0x0404F72D RID: 325421 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 2R90YZ6ZGd;

		// Token: 0x0404F72E RID: 325422 RVA: 0x00149960 File Offset: 0x00147B60
		static readonly int K9DKEu4r46;

		// Token: 0x0404F72F RID: 325423 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Wo0aZIkRSQ;

		// Token: 0x0404F730 RID: 325424 RVA: 0x00149968 File Offset: 0x00147B68
		static readonly int dhyDDHrMRK;

		// Token: 0x0404F731 RID: 325425 RVA: 0x00149970 File Offset: 0x00147B70
		static readonly int 9hTU9Lb66I;

		// Token: 0x0404F732 RID: 325426 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int hsyUQOajbP;

		// Token: 0x0404F733 RID: 325427 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int yoHz9nLAG6;

		// Token: 0x0404F734 RID: 325428 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Dsat6yUgaN;

		// Token: 0x0404F735 RID: 325429 RVA: 0x00149960 File Offset: 0x00147B60
		static readonly int roUJtvsdwy;

		// Token: 0x0404F736 RID: 325430 RVA: 0x00149978 File Offset: 0x00147B78
		static readonly int rIvCWVZdUW;

		// Token: 0x0404F737 RID: 325431 RVA: 0x00149980 File Offset: 0x00147B80
		static readonly int Aaz9FzSFYc;

		// Token: 0x0404F738 RID: 325432 RVA: 0x00149988 File Offset: 0x00147B88
		static readonly int 34INiJU8GO;

		// Token: 0x0404F739 RID: 325433 RVA: 0x00149990 File Offset: 0x00147B90
		static readonly int 5rOSP56YWl;

		// Token: 0x0404F73A RID: 325434 RVA: 0x00149998 File Offset: 0x00147B98
		static readonly int Y0MENQyUE4;

		// Token: 0x0404F73B RID: 325435 RVA: 0x001499A0 File Offset: 0x00147BA0
		static readonly int cnFT4x9hdN;

		// Token: 0x0404F73C RID: 325436 RVA: 0x001499A8 File Offset: 0x00147BA8
		static readonly int AbXFbSMhuJ;

		// Token: 0x0404F73D RID: 325437 RVA: 0x001499B0 File Offset: 0x00147BB0
		static readonly int 24sxDDrE9R;

		// Token: 0x0404F73E RID: 325438 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int VA3LwSm4Xc;

		// Token: 0x0404F73F RID: 325439 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 6Z4Jk7cHn5;

		// Token: 0x0404F740 RID: 325440 RVA: 0x001499B8 File Offset: 0x00147BB8
		static readonly int EQk4Ci4SQ1;

		// Token: 0x0404F741 RID: 325441 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int F4iM1AhMTJ;

		// Token: 0x0404F742 RID: 325442 RVA: 0x001499C0 File Offset: 0x00147BC0
		static readonly int qRKRNdAjMG;

		// Token: 0x0404F743 RID: 325443 RVA: 0x001499C8 File Offset: 0x00147BC8
		static readonly int kkbENEZ9IN;

		// Token: 0x0404F744 RID: 325444 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int XUngXB0sRk;

		// Token: 0x0404F745 RID: 325445 RVA: 0x001499D0 File Offset: 0x00147BD0
		static readonly int ZQxeOwGSqj;

		// Token: 0x0404F746 RID: 325446 RVA: 0x001499D8 File Offset: 0x00147BD8
		static readonly int iUFKQedd8w;

		// Token: 0x0404F747 RID: 325447 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int kiDFvWnn4L;

		// Token: 0x0404F748 RID: 325448 RVA: 0x001499E0 File Offset: 0x00147BE0
		static readonly int mRRmrUw6za;

		// Token: 0x0404F749 RID: 325449 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 8HSjpCOdP2;

		// Token: 0x0404F74A RID: 325450 RVA: 0x001499E8 File Offset: 0x00147BE8
		static readonly int iXtf90Mst2;

		// Token: 0x0404F74B RID: 325451 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int JcXf7QDdd6;

		// Token: 0x0404F74C RID: 325452 RVA: 0x001499F0 File Offset: 0x00147BF0
		static readonly int rgniycPeas;

		// Token: 0x0404F74D RID: 325453 RVA: 0x001499B8 File Offset: 0x00147BB8
		static readonly int HKYCnOiwm0;

		// Token: 0x0404F74E RID: 325454 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int HEN7RftxlY;

		// Token: 0x0404F74F RID: 325455 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9vASKBuLqg;

		// Token: 0x0404F750 RID: 325456 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lrRAv8EV1s;

		// Token: 0x0404F751 RID: 325457 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int sR0nzmSqRS;

		// Token: 0x0404F752 RID: 325458 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int tc2BsVJG1m;

		// Token: 0x0404F753 RID: 325459 RVA: 0x001499E8 File Offset: 0x00147BE8
		static readonly int eXFFPZxMLS;

		// Token: 0x0404F754 RID: 325460 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int bY53qs4Xci;

		// Token: 0x0404F755 RID: 325461 RVA: 0x001499F8 File Offset: 0x00147BF8
		static readonly int sD4XxIyQRZ;

		// Token: 0x0404F756 RID: 325462 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int z7dPOVLvXZ;

		// Token: 0x0404F757 RID: 325463 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int zGe81Ug9VA;

		// Token: 0x0404F758 RID: 325464 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int bwnT3adrRG;

		// Token: 0x0404F759 RID: 325465 RVA: 0x00149A00 File Offset: 0x00147C00
		static readonly int kg4wdd4qoV;

		// Token: 0x0404F75A RID: 325466 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gJ9Csmj5gc;

		// Token: 0x0404F75B RID: 325467 RVA: 0x00149A08 File Offset: 0x00147C08
		static readonly int mz4R8CUKVx;

		// Token: 0x0404F75C RID: 325468 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 1edRzSLrfY;

		// Token: 0x0404F75D RID: 325469 RVA: 0x00149A10 File Offset: 0x00147C10
		static readonly int azU9eRxkkR;

		// Token: 0x0404F75E RID: 325470 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 0hLzevmnya;

		// Token: 0x0404F75F RID: 325471 RVA: 0x00149A18 File Offset: 0x00147C18
		static readonly int ItU1dCqsNZ;

		// Token: 0x0404F760 RID: 325472 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int b1aICwe4xq;

		// Token: 0x0404F761 RID: 325473 RVA: 0x00149A20 File Offset: 0x00147C20
		static readonly int PujE6UTowE;

		// Token: 0x0404F762 RID: 325474 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int qh3EPqedgb;

		// Token: 0x0404F763 RID: 325475 RVA: 0x00149A08 File Offset: 0x00147C08
		static readonly int kEWLz9HCws;

		// Token: 0x0404F764 RID: 325476 RVA: 0x00149A10 File Offset: 0x00147C10
		static readonly int Rr0HLYKQ4J;

		// Token: 0x0404F765 RID: 325477 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int tC5Jt38V2W;

		// Token: 0x0404F766 RID: 325478 RVA: 0x00149A20 File Offset: 0x00147C20
		static readonly int RAYVGKXYO7;

		// Token: 0x0404F767 RID: 325479 RVA: 0x00149A28 File Offset: 0x00147C28
		static readonly int MQ1Ex9rw31;

		// Token: 0x0404F768 RID: 325480 RVA: 0x00149A30 File Offset: 0x00147C30
		static readonly int gOiXsiJNb6;

		// Token: 0x0404F769 RID: 325481 RVA: 0x00149A38 File Offset: 0x00147C38
		static readonly int AwKZaQTeBA;

		// Token: 0x0404F76A RID: 325482 RVA: 0x00149A40 File Offset: 0x00147C40
		static readonly int BvB76dK0Wu;

		// Token: 0x0404F76B RID: 325483 RVA: 0x00149A48 File Offset: 0x00147C48
		static readonly int MLbB0DcBni;

		// Token: 0x0404F76C RID: 325484 RVA: 0x00149A50 File Offset: 0x00147C50
		static readonly int BJ6S6aFbog;

		// Token: 0x0404F76D RID: 325485 RVA: 0x00149A58 File Offset: 0x00147C58
		static readonly int pMv20uMlaO;

		// Token: 0x0404F76E RID: 325486 RVA: 0x00149A60 File Offset: 0x00147C60
		static readonly int XS0rtzUIjX;

		// Token: 0x0404F76F RID: 325487 RVA: 0x00149A68 File Offset: 0x00147C68
		static readonly int xS0c91ytAg;

		// Token: 0x0404F770 RID: 325488 RVA: 0x00149A70 File Offset: 0x00147C70
		static readonly int XtMzE9aiLF;

		// Token: 0x0404F771 RID: 325489 RVA: 0x00149A78 File Offset: 0x00147C78
		static readonly int 01kYLsSOiH;

		// Token: 0x0404F772 RID: 325490 RVA: 0x00149A80 File Offset: 0x00147C80
		static readonly int F61QtXVS38;

		// Token: 0x0404F773 RID: 325491 RVA: 0x00149A88 File Offset: 0x00147C88
		static readonly int 6dk31oGBnu;

		// Token: 0x0404F774 RID: 325492 RVA: 0x00149A90 File Offset: 0x00147C90
		static readonly int Yv7eh6rcRQ;

		// Token: 0x0404F775 RID: 325493 RVA: 0x00149A98 File Offset: 0x00147C98
		static readonly int ijK3ba15Gq;

		// Token: 0x0404F776 RID: 325494 RVA: 0x00149AA0 File Offset: 0x00147CA0
		static readonly int nIpMJWQqhg;

		// Token: 0x0404F777 RID: 325495 RVA: 0x00149AA8 File Offset: 0x00147CA8
		static readonly int mRlysT9Xtx;

		// Token: 0x0404F778 RID: 325496 RVA: 0x00149AB0 File Offset: 0x00147CB0
		static readonly int q3AnaWTqca;

		// Token: 0x0404F779 RID: 325497 RVA: 0x00149AB8 File Offset: 0x00147CB8
		static readonly int wK57GQGvVK;

		// Token: 0x0404F77A RID: 325498 RVA: 0x00149AC0 File Offset: 0x00147CC0
		static readonly int pA5unQ8VKH;

		// Token: 0x0404F77B RID: 325499 RVA: 0x00149AC8 File Offset: 0x00147CC8
		static readonly int beLS9uHBvw;

		// Token: 0x0404F77C RID: 325500 RVA: 0x00149AD0 File Offset: 0x00147CD0
		static readonly int DkOGucVnsc;

		// Token: 0x0404F77D RID: 325501 RVA: 0x00149AD8 File Offset: 0x00147CD8
		static readonly int NOBjHp8P9J;

		// Token: 0x0404F77E RID: 325502 RVA: 0x00149AE0 File Offset: 0x00147CE0
		static readonly int X7fU9S8m7V;

		// Token: 0x0404F77F RID: 325503 RVA: 0x00149AE8 File Offset: 0x00147CE8
		static readonly int JE9iHFvyAL;

		// Token: 0x0404F780 RID: 325504 RVA: 0x00149AF0 File Offset: 0x00147CF0
		static readonly int 4Vns3NcmLU;

		// Token: 0x0404F781 RID: 325505 RVA: 0x00149AF8 File Offset: 0x00147CF8
		static readonly int w1BmZFE3Hb;

		// Token: 0x0404F782 RID: 325506 RVA: 0x00149B00 File Offset: 0x00147D00
		static readonly int dtpWTJPcbC;

		// Token: 0x0404F783 RID: 325507 RVA: 0x00149B08 File Offset: 0x00147D08
		static readonly int 3JPyOBUxbv;

		// Token: 0x0404F784 RID: 325508 RVA: 0x00149B10 File Offset: 0x00147D10
		static readonly int 0VbnjRCWJC;

		// Token: 0x0404F785 RID: 325509 RVA: 0x00149B18 File Offset: 0x00147D18
		static readonly int A2rjrLpQZu;

		// Token: 0x0404F786 RID: 325510 RVA: 0x00149B20 File Offset: 0x00147D20
		static readonly int 8ALIammNXX;

		// Token: 0x0404F787 RID: 325511 RVA: 0x00149B28 File Offset: 0x00147D28
		static readonly int uRcVlIRCwB;

		// Token: 0x0404F788 RID: 325512 RVA: 0x00149B30 File Offset: 0x00147D30
		static readonly int G2TYCBcpHD;

		// Token: 0x0404F789 RID: 325513 RVA: 0x00149B38 File Offset: 0x00147D38
		static readonly int WEXqxzKSN7;

		// Token: 0x0404F78A RID: 325514 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int pz9vStZV8j;

		// Token: 0x0404F78B RID: 325515 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 3ndYoFrwGY;

		// Token: 0x0404F78C RID: 325516 RVA: 0x00149B40 File Offset: 0x00147D40
		static readonly int J6FUBp4wiv;

		// Token: 0x0404F78D RID: 325517 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 78zzWQ3hGT;

		// Token: 0x0404F78E RID: 325518 RVA: 0x00149B48 File Offset: 0x00147D48
		static readonly int lHrhJtk9Br;

		// Token: 0x0404F78F RID: 325519 RVA: 0x00149B50 File Offset: 0x00147D50
		static readonly int IXMyxstotm;

		// Token: 0x0404F790 RID: 325520 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ynxNl4xoCX;

		// Token: 0x0404F791 RID: 325521 RVA: 0x00149B58 File Offset: 0x00147D58
		static readonly int MJpwxCPiLS;

		// Token: 0x0404F792 RID: 325522 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int F5u0mkwBCn;

		// Token: 0x0404F793 RID: 325523 RVA: 0x00149B60 File Offset: 0x00147D60
		static readonly int hOxee8Td6O;

		// Token: 0x0404F794 RID: 325524 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 567oe8rZAu;

		// Token: 0x0404F795 RID: 325525 RVA: 0x00149B68 File Offset: 0x00147D68
		static readonly int cLdbg327kB;

		// Token: 0x0404F796 RID: 325526 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int IwmY08VLSy;

		// Token: 0x0404F797 RID: 325527 RVA: 0x00149B70 File Offset: 0x00147D70
		static readonly int tvl6XI8GVn;

		// Token: 0x0404F798 RID: 325528 RVA: 0x00149B78 File Offset: 0x00147D78
		static readonly int 2WARKVvW7k;

		// Token: 0x0404F799 RID: 325529 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int FW35GJUixg;

		// Token: 0x0404F79A RID: 325530 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ngHMBqjgEY;

		// Token: 0x0404F79B RID: 325531 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 5vl6IwvUNe;

		// Token: 0x0404F79C RID: 325532 RVA: 0x00149B68 File Offset: 0x00147D68
		static readonly int M9NrsW2q0O;

		// Token: 0x0404F79D RID: 325533 RVA: 0x00149B80 File Offset: 0x00147D80
		static readonly int yZSyAWOyPe;

		// Token: 0x0404F79E RID: 325534 RVA: 0x00149B88 File Offset: 0x00147D88
		static readonly int vOSjoUu6wT;

		// Token: 0x0404F79F RID: 325535 RVA: 0x00149B90 File Offset: 0x00147D90
		static readonly int X9VTUnSZdo;

		// Token: 0x0404F7A0 RID: 325536 RVA: 0x00149B98 File Offset: 0x00147D98
		static readonly int y3q0jgcw6w;

		// Token: 0x0404F7A1 RID: 325537 RVA: 0x00149BA0 File Offset: 0x00147DA0
		static readonly int h7Fts8roCY;

		// Token: 0x0404F7A2 RID: 325538 RVA: 0x00149BA8 File Offset: 0x00147DA8
		static readonly int m64g0zD9eW;

		// Token: 0x0404F7A3 RID: 325539 RVA: 0x00149BB0 File Offset: 0x00147DB0
		static readonly int DzVkq2ib9I;

		// Token: 0x0404F7A4 RID: 325540 RVA: 0x00149BB8 File Offset: 0x00147DB8
		static readonly int 17A9wZ4mkW;

		// Token: 0x0404F7A5 RID: 325541 RVA: 0x00149BC0 File Offset: 0x00147DC0
		static readonly int 6nWEC28J9u;

		// Token: 0x0404F7A6 RID: 325542 RVA: 0x00149BC8 File Offset: 0x00147DC8
		static readonly int cdSjtsmeDz;

		// Token: 0x0404F7A7 RID: 325543 RVA: 0x00149BD0 File Offset: 0x00147DD0
		static readonly int ZPo4ho55tb;

		// Token: 0x0404F7A8 RID: 325544 RVA: 0x00149BD8 File Offset: 0x00147DD8
		static readonly int 4bZIaZcQiy;

		// Token: 0x0404F7A9 RID: 325545 RVA: 0x00149BE0 File Offset: 0x00147DE0
		static readonly int 3YcPqXpbPE;

		// Token: 0x0404F7AA RID: 325546 RVA: 0x00149BE8 File Offset: 0x00147DE8
		static readonly int xaju6r9chY;

		// Token: 0x0404F7AB RID: 325547 RVA: 0x00149BF0 File Offset: 0x00147DF0
		static readonly int 6DZizAEJIT;

		// Token: 0x0404F7AC RID: 325548 RVA: 0x00149BF8 File Offset: 0x00147DF8
		static readonly int PW5O6BwZNJ;

		// Token: 0x0404F7AD RID: 325549 RVA: 0x00149C00 File Offset: 0x00147E00
		static readonly int 8eppne2oMt;

		// Token: 0x0404F7AE RID: 325550 RVA: 0x00149C08 File Offset: 0x00147E08
		static readonly int aAtK1084Zp;

		// Token: 0x0404F7AF RID: 325551 RVA: 0x00149C10 File Offset: 0x00147E10
		static readonly int TfS6zbeUy5;

		// Token: 0x0404F7B0 RID: 325552 RVA: 0x00149C18 File Offset: 0x00147E18
		static readonly int 4kOXZcYu4U;

		// Token: 0x0404F7B1 RID: 325553 RVA: 0x00149C20 File Offset: 0x00147E20
		static readonly int HZ7Z3PmvXF;

		// Token: 0x0404F7B2 RID: 325554 RVA: 0x00149C28 File Offset: 0x00147E28
		static readonly int C19i0cLs0M;

		// Token: 0x0404F7B3 RID: 325555 RVA: 0x00149C30 File Offset: 0x00147E30
		static readonly int Ai0Qy0vWuZ;

		// Token: 0x0404F7B4 RID: 325556 RVA: 0x00149C38 File Offset: 0x00147E38
		static readonly int bOAFh3i2Dj;

		// Token: 0x0404F7B5 RID: 325557 RVA: 0x00149C40 File Offset: 0x00147E40
		static readonly int ys6s3Ckqg6;

		// Token: 0x0404F7B6 RID: 325558 RVA: 0x00149C48 File Offset: 0x00147E48
		static readonly int Rp3rUjjqlD;

		// Token: 0x0404F7B7 RID: 325559 RVA: 0x00149C50 File Offset: 0x00147E50
		static readonly int dQA8nx14A6;

		// Token: 0x0404F7B8 RID: 325560 RVA: 0x00149C58 File Offset: 0x00147E58
		static readonly int 4SpQYRlHXv;

		// Token: 0x0404F7B9 RID: 325561 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int PFzyHwUSu8;

		// Token: 0x0404F7BA RID: 325562 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int U1RAGhr8EF;

		// Token: 0x0404F7BB RID: 325563 RVA: 0x00149C60 File Offset: 0x00147E60
		static readonly int LqqkC89nTC;

		// Token: 0x0404F7BC RID: 325564 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7cS0xYbM01;

		// Token: 0x0404F7BD RID: 325565 RVA: 0x00149C68 File Offset: 0x00147E68
		static readonly int diJBmCBpJ0;

		// Token: 0x0404F7BE RID: 325566 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int knCSkiZOwJ;

		// Token: 0x0404F7BF RID: 325567 RVA: 0x00149C70 File Offset: 0x00147E70
		static readonly int wq9sA1jbMs;

		// Token: 0x0404F7C0 RID: 325568 RVA: 0x00149C78 File Offset: 0x00147E78
		static readonly int GeHNlmho89;

		// Token: 0x0404F7C1 RID: 325569 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 7TdccUZAPP;

		// Token: 0x0404F7C2 RID: 325570 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9MarEwibBu;

		// Token: 0x0404F7C3 RID: 325571 RVA: 0x00149C80 File Offset: 0x00147E80
		static readonly int djdbuFfyq7;

		// Token: 0x0404F7C4 RID: 325572 RVA: 0x00149C88 File Offset: 0x00147E88
		static readonly int BuQwLdNhQp;

		// Token: 0x0404F7C5 RID: 325573 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int biL6t3EaJz;

		// Token: 0x0404F7C6 RID: 325574 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DFmNgX0BsW;

		// Token: 0x0404F7C7 RID: 325575 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ylUSOO6ngk;

		// Token: 0x0404F7C8 RID: 325576 RVA: 0x00149C90 File Offset: 0x00147E90
		static readonly int jBLVS4Ygs0;

		// Token: 0x0404F7C9 RID: 325577 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int BFp035ICQx;

		// Token: 0x0404F7CA RID: 325578 RVA: 0x00149C98 File Offset: 0x00147E98
		static readonly int nLy310O3se;

		// Token: 0x0404F7CB RID: 325579 RVA: 0x00149CA0 File Offset: 0x00147EA0
		static readonly int 7a3iQC4R5l;

		// Token: 0x0404F7CC RID: 325580 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9TT1Vt5dYS;

		// Token: 0x0404F7CD RID: 325581 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int G4Xs7XMRec;

		// Token: 0x0404F7CE RID: 325582 RVA: 0x00149CA8 File Offset: 0x00147EA8
		static readonly int qeyO3kLHk1;

		// Token: 0x0404F7CF RID: 325583 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int A1HpxT26iH;

		// Token: 0x0404F7D0 RID: 325584 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4veZYCDKk2;

		// Token: 0x0404F7D1 RID: 325585 RVA: 0x00149CB0 File Offset: 0x00147EB0
		static readonly int zmwd5efF8u;

		// Token: 0x0404F7D2 RID: 325586 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int hy2hSPws5n;

		// Token: 0x0404F7D3 RID: 325587 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int fPtWh4AYz0;

		// Token: 0x0404F7D4 RID: 325588 RVA: 0x00149CB8 File Offset: 0x00147EB8
		static readonly int hAgrBXEotS;

		// Token: 0x0404F7D5 RID: 325589 RVA: 0x00149C90 File Offset: 0x00147E90
		static readonly int yx8xjG27HJ;

		// Token: 0x0404F7D6 RID: 325590 RVA: 0x00149CC0 File Offset: 0x00147EC0
		static readonly int PVP6Xj3Z5A;

		// Token: 0x0404F7D7 RID: 325591 RVA: 0x00149CC8 File Offset: 0x00147EC8
		static readonly int eGPHNgSLf4;

		// Token: 0x0404F7D8 RID: 325592 RVA: 0x00149CA8 File Offset: 0x00147EA8
		static readonly int KI8mzrR6xb;

		// Token: 0x0404F7D9 RID: 325593 RVA: 0x00149CB0 File Offset: 0x00147EB0
		static readonly int BCQqkMvjUc;

		// Token: 0x0404F7DA RID: 325594 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int eossxsh1jC;

		// Token: 0x0404F7DB RID: 325595 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int xrcN8GWmHp;

		// Token: 0x0404F7DC RID: 325596 RVA: 0x00149CD0 File Offset: 0x00147ED0
		static readonly int S6me8czjgB;

		// Token: 0x0404F7DD RID: 325597 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int vs0CZfaPyG;

		// Token: 0x0404F7DE RID: 325598 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KZWunUjDrd;

		// Token: 0x0404F7DF RID: 325599 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int zIboJiCNtV;

		// Token: 0x0404F7E0 RID: 325600 RVA: 0x00149CD8 File Offset: 0x00147ED8
		static readonly int 28UiRE0axc;

		// Token: 0x0404F7E1 RID: 325601 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int qGxAf2k21o;

		// Token: 0x0404F7E2 RID: 325602 RVA: 0x00149CE0 File Offset: 0x00147EE0
		static readonly int 2v1CLnQM21;

		// Token: 0x0404F7E3 RID: 325603 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int dNfdOMExci;

		// Token: 0x0404F7E4 RID: 325604 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int dJQOxsUbJR;

		// Token: 0x0404F7E5 RID: 325605 RVA: 0x00149CE8 File Offset: 0x00147EE8
		static readonly int 7JWFcGGSWn;

		// Token: 0x0404F7E6 RID: 325606 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int xoh69clUwT;

		// Token: 0x0404F7E7 RID: 325607 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xwZSLtfmOd;

		// Token: 0x0404F7E8 RID: 325608 RVA: 0x00149CF0 File Offset: 0x00147EF0
		static readonly int TzDl3T1aAH;

		// Token: 0x0404F7E9 RID: 325609 RVA: 0x00149CF8 File Offset: 0x00147EF8
		static readonly int FwazuzmTPV;

		// Token: 0x0404F7EA RID: 325610 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int H9o0dLuD3t;

		// Token: 0x0404F7EB RID: 325611 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int kdD3U7l5Dq;

		// Token: 0x0404F7EC RID: 325612 RVA: 0x00149D00 File Offset: 0x00147F00
		static readonly int lKUoNBVkhW;

		// Token: 0x0404F7ED RID: 325613 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int GLX3VTLNIs;

		// Token: 0x0404F7EE RID: 325614 RVA: 0x00149D08 File Offset: 0x00147F08
		static readonly int jxgQgltgew;

		// Token: 0x0404F7EF RID: 325615 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int NqQjt6pAmb;

		// Token: 0x0404F7F0 RID: 325616 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int zJghmYGJiB;

		// Token: 0x0404F7F1 RID: 325617 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int wXxVGynDHl;

		// Token: 0x0404F7F2 RID: 325618 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int SzGuIa5yKZ;

		// Token: 0x0404F7F3 RID: 325619 RVA: 0x00149D00 File Offset: 0x00147F00
		static readonly int nKkq2ZQ9nH;

		// Token: 0x0404F7F4 RID: 325620 RVA: 0x00149D10 File Offset: 0x00147F10
		static readonly int fj8dA035c4;

		// Token: 0x0404F7F5 RID: 325621 RVA: 0x00149D18 File Offset: 0x00147F18
		static readonly int Sm2AJADvYM;

		// Token: 0x0404F7F6 RID: 325622 RVA: 0x00149D20 File Offset: 0x00147F20
		static readonly int dR9JXlxGcr;

		// Token: 0x0404F7F7 RID: 325623 RVA: 0x00149D28 File Offset: 0x00147F28
		static readonly int hoZ9Fs0muS;

		// Token: 0x0404F7F8 RID: 325624 RVA: 0x00149D30 File Offset: 0x00147F30
		static readonly int gAWPGBRkg2;

		// Token: 0x0404F7F9 RID: 325625 RVA: 0x00149D38 File Offset: 0x00147F38
		static readonly int VfkboOkzFY;

		// Token: 0x0404F7FA RID: 325626 RVA: 0x00149D40 File Offset: 0x00147F40
		static readonly int CwduXoM34b;

		// Token: 0x0404F7FB RID: 325627 RVA: 0x00149D48 File Offset: 0x00147F48
		static readonly int JaAGpd5tCV;

		// Token: 0x0404F7FC RID: 325628 RVA: 0x00149D50 File Offset: 0x00147F50
		static readonly int TNjjVCD7U1;

		// Token: 0x0404F7FD RID: 325629 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int IAhWPuhl2b;

		// Token: 0x0404F7FE RID: 325630 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int zYpFs4eevL;

		// Token: 0x0404F7FF RID: 325631 RVA: 0x00149D58 File Offset: 0x00147F58
		static readonly int S0wuEzM3ZV;

		// Token: 0x0404F800 RID: 325632 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kOiCTJ3o05;

		// Token: 0x0404F801 RID: 325633 RVA: 0x00149D60 File Offset: 0x00147F60
		static readonly int 6U1lg5he0a;

		// Token: 0x0404F802 RID: 325634 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int hjMJjRNxRZ;

		// Token: 0x0404F803 RID: 325635 RVA: 0x00149D68 File Offset: 0x00147F68
		static readonly int hnLg0kzmwj;

		// Token: 0x0404F804 RID: 325636 RVA: 0x00149D70 File Offset: 0x00147F70
		static readonly int B0n0O88LOJ;

		// Token: 0x0404F805 RID: 325637 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int SsC8yBCYdB;

		// Token: 0x0404F806 RID: 325638 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 5GWbXSIUu5;

		// Token: 0x0404F807 RID: 325639 RVA: 0x00149D78 File Offset: 0x00147F78
		static readonly int F5sRZq5V4l;

		// Token: 0x0404F808 RID: 325640 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int TCjIHzkNsz;

		// Token: 0x0404F809 RID: 325641 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int iaIvo4dMc6;

		// Token: 0x0404F80A RID: 325642 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int znbSDX9viH;

		// Token: 0x0404F80B RID: 325643 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Fqe2r3hOUi;

		// Token: 0x0404F80C RID: 325644 RVA: 0x00149D80 File Offset: 0x00147F80
		static readonly int r4m4Xow7me;

		// Token: 0x0404F80D RID: 325645 RVA: 0x00149D88 File Offset: 0x00147F88
		static readonly int Nt28vpkQFu;

		// Token: 0x0404F80E RID: 325646 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int zzolt16PDv;

		// Token: 0x0404F80F RID: 325647 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int XP24O4Bg5Y;

		// Token: 0x0404F810 RID: 325648 RVA: 0x00149D90 File Offset: 0x00147F90
		static readonly int kCID3WyfHC;

		// Token: 0x0404F811 RID: 325649 RVA: 0x00149D98 File Offset: 0x00147F98
		static readonly int SRJks2QALf;

		// Token: 0x0404F812 RID: 325650 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int rg31H717u0;

		// Token: 0x0404F813 RID: 325651 RVA: 0x00149DA0 File Offset: 0x00147FA0
		static readonly int oDVqJwrkrW;

		// Token: 0x0404F814 RID: 325652 RVA: 0x00149DA8 File Offset: 0x00147FA8
		static readonly int CbIBcGGSMV;

		// Token: 0x0404F815 RID: 325653 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int oBVZrDIQ65;

		// Token: 0x0404F816 RID: 325654 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int f0vQXP5da5;

		// Token: 0x0404F817 RID: 325655 RVA: 0x00149DB0 File Offset: 0x00147FB0
		static readonly int LpSydQY2ZB;

		// Token: 0x0404F818 RID: 325656 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 1jvYLns58F;

		// Token: 0x0404F819 RID: 325657 RVA: 0x00149DB8 File Offset: 0x00147FB8
		static readonly int naow1Mq1nN;

		// Token: 0x0404F81A RID: 325658 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Kn1QK9sh6a;

		// Token: 0x0404F81B RID: 325659 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int pQ04E5EWEu;

		// Token: 0x0404F81C RID: 325660 RVA: 0x00149DC0 File Offset: 0x00147FC0
		static readonly int hAeURuAg6Q;

		// Token: 0x0404F81D RID: 325661 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int kgOM1OrfNM;

		// Token: 0x0404F81E RID: 325662 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 4K9iaXkus6;

		// Token: 0x0404F81F RID: 325663 RVA: 0x00149DC8 File Offset: 0x00147FC8
		static readonly int HTw2pJJh8a;

		// Token: 0x0404F820 RID: 325664 RVA: 0x00149DD0 File Offset: 0x00147FD0
		static readonly int 9MkpzIBoCz;

		// Token: 0x0404F821 RID: 325665 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NiI20WA544;

		// Token: 0x0404F822 RID: 325666 RVA: 0x00149DB0 File Offset: 0x00147FB0
		static readonly int KQyAIRtWgr;

		// Token: 0x0404F823 RID: 325667 RVA: 0x00149DB8 File Offset: 0x00147FB8
		static readonly int FKgxNskTsR;

		// Token: 0x0404F824 RID: 325668 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int V5r2siK4CT;

		// Token: 0x0404F825 RID: 325669 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int JNnEQtYkgi;

		// Token: 0x0404F826 RID: 325670 RVA: 0x00149DD8 File Offset: 0x00147FD8
		static readonly int ZpHVuDCVpI;

		// Token: 0x0404F827 RID: 325671 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vqMmiOi6Sj;

		// Token: 0x0404F828 RID: 325672 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int GzTMi1hche;

		// Token: 0x0404F829 RID: 325673 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int UAxK2qyVHo;

		// Token: 0x0404F82A RID: 325674 RVA: 0x00149DE0 File Offset: 0x00147FE0
		static readonly int gyP4icAAfB;

		// Token: 0x0404F82B RID: 325675 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KcS6bjV4w3;

		// Token: 0x0404F82C RID: 325676 RVA: 0x00149DE8 File Offset: 0x00147FE8
		static readonly int fjyKxv3Ct2;

		// Token: 0x0404F82D RID: 325677 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int aMynDRjZoG;

		// Token: 0x0404F82E RID: 325678 RVA: 0x00149DF0 File Offset: 0x00147FF0
		static readonly int 0g6fU1s0sS;

		// Token: 0x0404F82F RID: 325679 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int U3jOJ7AEGw;

		// Token: 0x0404F830 RID: 325680 RVA: 0x00149DE8 File Offset: 0x00147FE8
		static readonly int i8Qml7np3J;

		// Token: 0x0404F831 RID: 325681 RVA: 0x00149DF8 File Offset: 0x00147FF8
		static readonly int A6PqC9mS06;

		// Token: 0x0404F832 RID: 325682 RVA: 0x00149E00 File Offset: 0x00148000
		static readonly int DDUbignkeF;

		// Token: 0x0404F833 RID: 325683 RVA: 0x00149E08 File Offset: 0x00148008
		static readonly int RfS2h2PT4W;

		// Token: 0x0404F834 RID: 325684 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int OD6iSXn3LJ;

		// Token: 0x0404F835 RID: 325685 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int UsNKteozEF;

		// Token: 0x0404F836 RID: 325686 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int TCLy2fnXIJ;

		// Token: 0x0404F837 RID: 325687 RVA: 0x00149E10 File Offset: 0x00148010
		static readonly int tSYdrAHvIK;

		// Token: 0x0404F838 RID: 325688 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2uYUvjRIID;

		// Token: 0x0404F839 RID: 325689 RVA: 0x00149E18 File Offset: 0x00148018
		static readonly int OaPzDM2Iqx;

		// Token: 0x0404F83A RID: 325690 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int tQuCaCTtct;

		// Token: 0x0404F83B RID: 325691 RVA: 0x00149E20 File Offset: 0x00148020
		static readonly int X2r3Mjn0DS;

		// Token: 0x0404F83C RID: 325692 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int NfOF4TDiaf;

		// Token: 0x0404F83D RID: 325693 RVA: 0x00149E28 File Offset: 0x00148028
		static readonly int I9EUbm9W3s;

		// Token: 0x0404F83E RID: 325694 RVA: 0x00149E10 File Offset: 0x00148010
		static readonly int PhpZpVsVme;

		// Token: 0x0404F83F RID: 325695 RVA: 0x00149E18 File Offset: 0x00148018
		static readonly int iBFXkOBpHH;

		// Token: 0x0404F840 RID: 325696 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9vT7lXyWck;

		// Token: 0x0404F841 RID: 325697 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jQ7UDp0zZi;

		// Token: 0x0404F842 RID: 325698 RVA: 0x00149E30 File Offset: 0x00148030
		static readonly int kr567G4ruN;

		// Token: 0x0404F843 RID: 325699 RVA: 0x00149E38 File Offset: 0x00148038
		static readonly int kUPvteOryS;

		// Token: 0x0404F844 RID: 325700 RVA: 0x00149E40 File Offset: 0x00148040
		static readonly int hW3C5RDvT4;

		// Token: 0x0404F845 RID: 325701 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YMPigRzXAe;

		// Token: 0x0404F846 RID: 325702 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int dGlP9OBLkj;

		// Token: 0x0404F847 RID: 325703 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int bIAHBOx3Ap;

		// Token: 0x0404F848 RID: 325704 RVA: 0x00149E48 File Offset: 0x00148048
		static readonly int DJX0zYEqOc;

		// Token: 0x0404F849 RID: 325705 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int p1rUybuoDq;

		// Token: 0x0404F84A RID: 325706 RVA: 0x00149E50 File Offset: 0x00148050
		static readonly int P1KucPLIhS;

		// Token: 0x0404F84B RID: 325707 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int e5WUbUtual;

		// Token: 0x0404F84C RID: 325708 RVA: 0x00149E58 File Offset: 0x00148058
		static readonly int JU6I4kaqSk;

		// Token: 0x0404F84D RID: 325709 RVA: 0x00149E48 File Offset: 0x00148048
		static readonly int eJ0UZL8mYj;

		// Token: 0x0404F84E RID: 325710 RVA: 0x00149E50 File Offset: 0x00148050
		static readonly int M5J67tfW2d;

		// Token: 0x0404F84F RID: 325711 RVA: 0x00149E58 File Offset: 0x00148058
		static readonly int r9Obg55C02;

		// Token: 0x0404F850 RID: 325712 RVA: 0x00149E60 File Offset: 0x00148060
		static readonly int zez6yVFB5P;

		// Token: 0x0404F851 RID: 325713 RVA: 0x00149E68 File Offset: 0x00148068
		static readonly int WGW0YNKAKK;

		// Token: 0x0404F852 RID: 325714 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int FDxz2e4Yxe;

		// Token: 0x0404F853 RID: 325715 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int Q5wgtrGMIm;

		// Token: 0x0404F854 RID: 325716 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ndbmHlnXDT;

		// Token: 0x0404F855 RID: 325717 RVA: 0x00149E70 File Offset: 0x00148070
		static readonly int u42pxvrAEU;

		// Token: 0x0404F856 RID: 325718 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int aqOa9aU0Gq;

		// Token: 0x0404F857 RID: 325719 RVA: 0x00149E78 File Offset: 0x00148078
		static readonly int H81hhlmKsR;

		// Token: 0x0404F858 RID: 325720 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 1hVetVCGs8;

		// Token: 0x0404F859 RID: 325721 RVA: 0x00149E80 File Offset: 0x00148080
		static readonly int AFIyM6OAnq;

		// Token: 0x0404F85A RID: 325722 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int QwQXLwCVIL;

		// Token: 0x0404F85B RID: 325723 RVA: 0x00149E88 File Offset: 0x00148088
		static readonly int IgSxc3Vuro;

		// Token: 0x0404F85C RID: 325724 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int XOHIpBzDUk;

		// Token: 0x0404F85D RID: 325725 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int XlhBAEQ8S7;

		// Token: 0x0404F85E RID: 325726 RVA: 0x00149E90 File Offset: 0x00148090
		static readonly int Sr7hzexUVT;

		// Token: 0x0404F85F RID: 325727 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int keT8SCpIrJ;

		// Token: 0x0404F860 RID: 325728 RVA: 0x00149E98 File Offset: 0x00148098
		static readonly int 69Aiyh8QxY;

		// Token: 0x0404F861 RID: 325729 RVA: 0x00149EA0 File Offset: 0x001480A0
		static readonly int mXbtWqQjSK;

		// Token: 0x0404F862 RID: 325730 RVA: 0x00149E70 File Offset: 0x00148070
		static readonly int OesB92Sjt7;

		// Token: 0x0404F863 RID: 325731 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YHQJATrYtS;

		// Token: 0x0404F864 RID: 325732 RVA: 0x00149E80 File Offset: 0x00148080
		static readonly int ghh6qMCjmm;

		// Token: 0x0404F865 RID: 325733 RVA: 0x00149E88 File Offset: 0x00148088
		static readonly int wFzg5bQ9j5;

		// Token: 0x0404F866 RID: 325734 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int OZgz9eHStD;

		// Token: 0x0404F867 RID: 325735 RVA: 0x00149EA8 File Offset: 0x001480A8
		static readonly int 8109or7wUw;

		// Token: 0x0404F868 RID: 325736 RVA: 0x00149EB0 File Offset: 0x001480B0
		static readonly int 0s6HLTRtNi;

		// Token: 0x0404F869 RID: 325737 RVA: 0x00149EB8 File Offset: 0x001480B8
		static readonly int CszxDHAr6L;

		// Token: 0x0404F86A RID: 325738 RVA: 0x00149EC0 File Offset: 0x001480C0
		static readonly int Ft0in4O02O;

		// Token: 0x0404F86B RID: 325739 RVA: 0x00149EC8 File Offset: 0x001480C8
		static readonly int eeowFgcZoq;

		// Token: 0x0404F86C RID: 325740 RVA: 0x00149ED0 File Offset: 0x001480D0
		static readonly int NXEKAQBD5h;

		// Token: 0x0404F86D RID: 325741 RVA: 0x00149ED8 File Offset: 0x001480D8
		static readonly int rPzJqG2XeQ;

		// Token: 0x0404F86E RID: 325742 RVA: 0x00149EE0 File Offset: 0x001480E0
		static readonly int Eb19DiDDsh;

		// Token: 0x0404F86F RID: 325743 RVA: 0x00149EE8 File Offset: 0x001480E8
		static readonly int okDP8sopiW;

		// Token: 0x0404F870 RID: 325744 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 2L4VhPoeF8;

		// Token: 0x0404F871 RID: 325745 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int nE5YmvgFHc;

		// Token: 0x0404F872 RID: 325746 RVA: 0x00149EF0 File Offset: 0x001480F0
		static readonly int M8VY2GMkK8;

		// Token: 0x0404F873 RID: 325747 RVA: 0x00149EF8 File Offset: 0x001480F8
		static readonly int bNzHX3hfcy;

		// Token: 0x0404F874 RID: 325748 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 3j7t4kopnN;

		// Token: 0x0404F875 RID: 325749 RVA: 0x00149F00 File Offset: 0x00148100
		static readonly int LjiFJ40fca;

		// Token: 0x0404F876 RID: 325750 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int DETGhaOyAt;

		// Token: 0x0404F877 RID: 325751 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NAmSinAleS;

		// Token: 0x0404F878 RID: 325752 RVA: 0x00149F08 File Offset: 0x00148108
		static readonly int bh67x1pu7d;

		// Token: 0x0404F879 RID: 325753 RVA: 0x00149F10 File Offset: 0x00148110
		static readonly int CBCCvyP0Md;

		// Token: 0x0404F87A RID: 325754 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int V0o39L7Pgg;

		// Token: 0x0404F87B RID: 325755 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 3OBK8gHWTp;

		// Token: 0x0404F87C RID: 325756 RVA: 0x00149F18 File Offset: 0x00148118
		static readonly int ue0hqL7khu;

		// Token: 0x0404F87D RID: 325757 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int YKYA6k2C7l;

		// Token: 0x0404F87E RID: 325758 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 4ZNbjyA2DP;

		// Token: 0x0404F87F RID: 325759 RVA: 0x00149F20 File Offset: 0x00148120
		static readonly int q3ght1AHNy;

		// Token: 0x0404F880 RID: 325760 RVA: 0x00149F28 File Offset: 0x00148128
		static readonly int NXswIszBNY;

		// Token: 0x0404F881 RID: 325761 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int nFYsvUQZ72;

		// Token: 0x0404F882 RID: 325762 RVA: 0x00149F30 File Offset: 0x00148130
		static readonly int LEgRDen1QF;

		// Token: 0x0404F883 RID: 325763 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int kvzJYgrbS0;

		// Token: 0x0404F884 RID: 325764 RVA: 0x00149F38 File Offset: 0x00148138
		static readonly int 88pplleywY;

		// Token: 0x0404F885 RID: 325765 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int kkJUnI0atn;

		// Token: 0x0404F886 RID: 325766 RVA: 0x00149F40 File Offset: 0x00148140
		static readonly int F8uHx2PPTO;

		// Token: 0x0404F887 RID: 325767 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int nzGG4MZ1pb;

		// Token: 0x0404F888 RID: 325768 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int AzF2fAlegP;

		// Token: 0x0404F889 RID: 325769 RVA: 0x00149F48 File Offset: 0x00148148
		static readonly int qQrpvAOh1t;

		// Token: 0x0404F88A RID: 325770 RVA: 0x00149F50 File Offset: 0x00148150
		static readonly int WPehuudDaa;

		// Token: 0x0404F88B RID: 325771 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int s8vSnQ21lx;

		// Token: 0x0404F88C RID: 325772 RVA: 0x00149F58 File Offset: 0x00148158
		static readonly int QusEhXHbU3;

		// Token: 0x0404F88D RID: 325773 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 72A6EuUhIv;

		// Token: 0x0404F88E RID: 325774 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ghEFgrfZCf;

		// Token: 0x0404F88F RID: 325775 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int HW5Eclga9W;

		// Token: 0x0404F890 RID: 325776 RVA: 0x00149F40 File Offset: 0x00148140
		static readonly int mCsgc08yN2;

		// Token: 0x0404F891 RID: 325777 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 6Ut0Qtqnh0;

		// Token: 0x0404F892 RID: 325778 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 2rZzwl66dc;

		// Token: 0x0404F893 RID: 325779 RVA: 0x00149F58 File Offset: 0x00148158
		static readonly int N3hvIezhmq;

		// Token: 0x0404F894 RID: 325780 RVA: 0x00149F60 File Offset: 0x00148160
		static readonly int tqMJjwnFxt;

		// Token: 0x0404F895 RID: 325781 RVA: 0x00149F68 File Offset: 0x00148168
		static readonly int 532Je4m3u1;

		// Token: 0x0404F896 RID: 325782 RVA: 0x00149F70 File Offset: 0x00148170
		static readonly int 3CVupCw7sw;

		// Token: 0x0404F897 RID: 325783 RVA: 0x00149F78 File Offset: 0x00148178
		static readonly int 3IB1GMfQP9;

		// Token: 0x0404F898 RID: 325784 RVA: 0x00149F80 File Offset: 0x00148180
		static readonly int 81IuhUAYRN;

		// Token: 0x0404F899 RID: 325785 RVA: 0x00149F88 File Offset: 0x00148188
		static readonly int 15xuwqUbdh;

		// Token: 0x0404F89A RID: 325786 RVA: 0x00149F90 File Offset: 0x00148190
		static readonly int 9pWAzw1BCR;

		// Token: 0x0404F89B RID: 325787 RVA: 0x00149F98 File Offset: 0x00148198
		static readonly int ZWnu3C3lNV;

		// Token: 0x0404F89C RID: 325788 RVA: 0x00149FA0 File Offset: 0x001481A0
		static readonly int BYqe48VQEa;

		// Token: 0x0404F89D RID: 325789 RVA: 0x00149FA8 File Offset: 0x001481A8
		static readonly int 1Dws9SeI4u;

		// Token: 0x0404F89E RID: 325790 RVA: 0x00149FB0 File Offset: 0x001481B0
		static readonly int c9V9yfSC0u;

		// Token: 0x0404F89F RID: 325791 RVA: 0x00149FB8 File Offset: 0x001481B8
		static readonly int xtOIfl82F1;

		// Token: 0x0404F8A0 RID: 325792 RVA: 0x00149FC0 File Offset: 0x001481C0
		static readonly int ak6maVk4vk;

		// Token: 0x0404F8A1 RID: 325793 RVA: 0x00149FC8 File Offset: 0x001481C8
		static readonly int hvqc2CDrqZ;

		// Token: 0x0404F8A2 RID: 325794 RVA: 0x00149FD0 File Offset: 0x001481D0
		static readonly int qTZUmHznNY;

		// Token: 0x0404F8A3 RID: 325795 RVA: 0x00149FD8 File Offset: 0x001481D8
		static readonly int UmCCU1Csjd;

		// Token: 0x0404F8A4 RID: 325796 RVA: 0x00149FE0 File Offset: 0x001481E0
		static readonly int 5XQQMCCvPd;

		// Token: 0x0404F8A5 RID: 325797 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int hRLqLGLmAS;

		// Token: 0x0404F8A6 RID: 325798 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int f6rWQ5snIB;

		// Token: 0x0404F8A7 RID: 325799 RVA: 0x00149FE8 File Offset: 0x001481E8
		static readonly int 9VINeSDJHk;

		// Token: 0x0404F8A8 RID: 325800 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int EDYu0CaV1N;

		// Token: 0x0404F8A9 RID: 325801 RVA: 0x00149FF0 File Offset: 0x001481F0
		static readonly int qZsQ78p39R;

		// Token: 0x0404F8AA RID: 325802 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int TYnOdMJ8M2;

		// Token: 0x0404F8AB RID: 325803 RVA: 0x00149FF8 File Offset: 0x001481F8
		static readonly int DBeZNci7gO;

		// Token: 0x0404F8AC RID: 325804 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int fWw5Vkm1Qf;

		// Token: 0x0404F8AD RID: 325805 RVA: 0x0014A000 File Offset: 0x00148200
		static readonly int mJK0RpaJQo;

		// Token: 0x0404F8AE RID: 325806 RVA: 0x00149FE8 File Offset: 0x001481E8
		static readonly int 3bJ8Jp4SCe;

		// Token: 0x0404F8AF RID: 325807 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int asXvv6ms23;

		// Token: 0x0404F8B0 RID: 325808 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int jRsqP41oIh;

		// Token: 0x0404F8B1 RID: 325809 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int CYq1VDNxvq;

		// Token: 0x0404F8B2 RID: 325810 RVA: 0x0014A008 File Offset: 0x00148208
		static readonly int pUzvF4vYEU;

		// Token: 0x0404F8B3 RID: 325811 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int DrRXFltctO;

		// Token: 0x0404F8B4 RID: 325812 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int xQKecBBgas;

		// Token: 0x0404F8B5 RID: 325813 RVA: 0x0014A010 File Offset: 0x00148210
		static readonly int tz6MNOc7lV;

		// Token: 0x0404F8B6 RID: 325814 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int IcjxeUHTvt;

		// Token: 0x0404F8B7 RID: 325815 RVA: 0x0014A018 File Offset: 0x00148218
		static readonly int UuEh2YKUSD;

		// Token: 0x0404F8B8 RID: 325816 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2P8WlOvEJ0;

		// Token: 0x0404F8B9 RID: 325817 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Iw0XFVrWAH;

		// Token: 0x0404F8BA RID: 325818 RVA: 0x0014A020 File Offset: 0x00148220
		static readonly int 4suqY8uZUy;

		// Token: 0x0404F8BB RID: 325819 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int EIoic3dNLQ;

		// Token: 0x0404F8BC RID: 325820 RVA: 0x0014A028 File Offset: 0x00148228
		static readonly int jCJ5lh3qbg;

		// Token: 0x0404F8BD RID: 325821 RVA: 0x0014A030 File Offset: 0x00148230
		static readonly int rxUKIKeS8n;

		// Token: 0x0404F8BE RID: 325822 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int dVtVv9HS5M;

		// Token: 0x0404F8BF RID: 325823 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2dKti1jzE0;

		// Token: 0x0404F8C0 RID: 325824 RVA: 0x0014A038 File Offset: 0x00148238
		static readonly int ED8xGRydaS;

		// Token: 0x0404F8C1 RID: 325825 RVA: 0x0014A010 File Offset: 0x00148210
		static readonly int YLPiwNTxJl;

		// Token: 0x0404F8C2 RID: 325826 RVA: 0x0014A018 File Offset: 0x00148218
		static readonly int ZlvPoNmkmQ;

		// Token: 0x0404F8C3 RID: 325827 RVA: 0x0014A020 File Offset: 0x00148220
		static readonly int kpNHiZX5Oe;

		// Token: 0x0404F8C4 RID: 325828 RVA: 0x0014A040 File Offset: 0x00148240
		static readonly int Lo2nxqOm6U;

		// Token: 0x0404F8C5 RID: 325829 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int ivpdadSsJ3;

		// Token: 0x0404F8C6 RID: 325830 RVA: 0x0014A048 File Offset: 0x00148248
		static readonly int oN0Jrt7H9X;

		// Token: 0x0404F8C7 RID: 325831 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 0XjoZvtHb7;

		// Token: 0x0404F8C8 RID: 325832 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 9AnSsz9uqF;

		// Token: 0x0404F8C9 RID: 325833 RVA: 0x0014A050 File Offset: 0x00148250
		static readonly int GowV07xt5E;

		// Token: 0x0404F8CA RID: 325834 RVA: 0x0014A058 File Offset: 0x00148258
		static readonly int sHmjdLLBDp;

		// Token: 0x0404F8CB RID: 325835 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int uKRL3okia2;

		// Token: 0x0404F8CC RID: 325836 RVA: 0x0014A060 File Offset: 0x00148260
		static readonly int tNa4QLkOyc;

		// Token: 0x0404F8CD RID: 325837 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 79MXP2YDyh;

		// Token: 0x0404F8CE RID: 325838 RVA: 0x0014A068 File Offset: 0x00148268
		static readonly int n8qBV6XlbM;

		// Token: 0x0404F8CF RID: 325839 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int XPSDUeqrTS;

		// Token: 0x0404F8D0 RID: 325840 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int k7Mlru836B;

		// Token: 0x0404F8D1 RID: 325841 RVA: 0x0014A068 File Offset: 0x00148268
		static readonly int Pgt3OuhYjU;

		// Token: 0x0404F8D2 RID: 325842 RVA: 0x0014A070 File Offset: 0x00148270
		static readonly int y9xmFrrIDu;

		// Token: 0x0404F8D3 RID: 325843 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int Lqug6qwFUl;

		// Token: 0x0404F8D4 RID: 325844 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 7doZ60fZzj;

		// Token: 0x0404F8D5 RID: 325845 RVA: 0x0014A078 File Offset: 0x00148278
		static readonly int 7RI9dlJjg9;

		// Token: 0x0404F8D6 RID: 325846 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int C00M0jwN7h;

		// Token: 0x0404F8D7 RID: 325847 RVA: 0x0014A080 File Offset: 0x00148280
		static readonly int 8bE7WUUXqO;

		// Token: 0x0404F8D8 RID: 325848 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int MRSdw3iuCU;

		// Token: 0x0404F8D9 RID: 325849 RVA: 0x0014A088 File Offset: 0x00148288
		static readonly int gMjUiHncjX;

		// Token: 0x0404F8DA RID: 325850 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DScRkfNKmJ;

		// Token: 0x0404F8DB RID: 325851 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Qw3RxuhWZ6;

		// Token: 0x0404F8DC RID: 325852 RVA: 0x0014A090 File Offset: 0x00148290
		static readonly int ACLmBw2uZP;

		// Token: 0x0404F8DD RID: 325853 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int q1xTL4zA3Q;

		// Token: 0x0404F8DE RID: 325854 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int qXH3DuTRgx;

		// Token: 0x0404F8DF RID: 325855 RVA: 0x0014A098 File Offset: 0x00148298
		static readonly int jRDnWBG0Qy;

		// Token: 0x0404F8E0 RID: 325856 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int mcvXcZ8kG3;

		// Token: 0x0404F8E1 RID: 325857 RVA: 0x0014A0A0 File Offset: 0x001482A0
		static readonly int 5gdIPn4SiQ;

		// Token: 0x0404F8E2 RID: 325858 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int dlNlqZyK6J;

		// Token: 0x0404F8E3 RID: 325859 RVA: 0x0014A080 File Offset: 0x00148280
		static readonly int x9uEnNmuao;

		// Token: 0x0404F8E4 RID: 325860 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int wsLm2Cx4Xs;

		// Token: 0x0404F8E5 RID: 325861 RVA: 0x0014A0A8 File Offset: 0x001482A8
		static readonly int HySAVBOJrC;

		// Token: 0x0404F8E6 RID: 325862 RVA: 0x0014A0B0 File Offset: 0x001482B0
		static readonly int lxn6G6wYeB;

		// Token: 0x0404F8E7 RID: 325863 RVA: 0x0014A098 File Offset: 0x00148298
		static readonly int BK13euZlto;

		// Token: 0x0404F8E8 RID: 325864 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int l3wNC9rutm;

		// Token: 0x0404F8E9 RID: 325865 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9cDYD8FOg6;

		// Token: 0x0404F8EA RID: 325866 RVA: 0x0014A0B8 File Offset: 0x001482B8
		static readonly int PZaWr66Yfk;

		// Token: 0x0404F8EB RID: 325867 RVA: 0x0014A0C0 File Offset: 0x001482C0
		static readonly int lnaCarBZ3H;

		// Token: 0x0404F8EC RID: 325868 RVA: 0x0014A0C8 File Offset: 0x001482C8
		static readonly int OCp2CiGd0f;

		// Token: 0x0404F8ED RID: 325869 RVA: 0x0014A0D0 File Offset: 0x001482D0
		static readonly int pLEwYMdagF;

		// Token: 0x0404F8EE RID: 325870 RVA: 0x0014A0D8 File Offset: 0x001482D8
		static readonly int CSOIAVBA7V;

		// Token: 0x0404F8EF RID: 325871 RVA: 0x0014A0E0 File Offset: 0x001482E0
		static readonly int 7pVZrMthUJ;

		// Token: 0x0404F8F0 RID: 325872 RVA: 0x0014A0E8 File Offset: 0x001482E8
		static readonly int zciA5aionO;

		// Token: 0x0404F8F1 RID: 325873 RVA: 0x0014A0F0 File Offset: 0x001482F0
		static readonly int Ol3xE5yh2q;

		// Token: 0x0404F8F2 RID: 325874 RVA: 0x0014A0F8 File Offset: 0x001482F8
		static readonly int hGgei90pEL;

		// Token: 0x0404F8F3 RID: 325875 RVA: 0x0014A100 File Offset: 0x00148300
		static readonly int d5FXQjuNMj;

		// Token: 0x0404F8F4 RID: 325876 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int wXWtHVwhUv;

		// Token: 0x0404F8F5 RID: 325877 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int YLpnlt6Eb5;

		// Token: 0x0404F8F6 RID: 325878 RVA: 0x0014A108 File Offset: 0x00148308
		static readonly int k2jcuTfghe;

		// Token: 0x0404F8F7 RID: 325879 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int LkUS4KuxWN;

		// Token: 0x0404F8F8 RID: 325880 RVA: 0x0014A110 File Offset: 0x00148310
		static readonly int NSVTxRPcvg;

		// Token: 0x0404F8F9 RID: 325881 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int nqwR83x48y;

		// Token: 0x0404F8FA RID: 325882 RVA: 0x0014A118 File Offset: 0x00148318
		static readonly int 0P9zky0Xsb;

		// Token: 0x0404F8FB RID: 325883 RVA: 0x0014A120 File Offset: 0x00148320
		static readonly int 9JrOsRhQod;

		// Token: 0x0404F8FC RID: 325884 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DCuA1fxDTA;

		// Token: 0x0404F8FD RID: 325885 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int WzyiW7Tfs9;

		// Token: 0x0404F8FE RID: 325886 RVA: 0x0014A128 File Offset: 0x00148328
		static readonly int a2tThd9ijq;

		// Token: 0x0404F8FF RID: 325887 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int WhPfuxe88F;

		// Token: 0x0404F900 RID: 325888 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int AxDsFJUI1u;

		// Token: 0x0404F901 RID: 325889 RVA: 0x0014A130 File Offset: 0x00148330
		static readonly int 8ChpCLSbdX;

		// Token: 0x0404F902 RID: 325890 RVA: 0x0014A138 File Offset: 0x00148338
		static readonly int fPemozkTyj;

		// Token: 0x0404F903 RID: 325891 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int cUhn8nyBOY;

		// Token: 0x0404F904 RID: 325892 RVA: 0x0014A140 File Offset: 0x00148340
		static readonly int J0qysUAjcj;

		// Token: 0x0404F905 RID: 325893 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int eDfkjuSaEP;

		// Token: 0x0404F906 RID: 325894 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int jATSRoe3qY;

		// Token: 0x0404F907 RID: 325895 RVA: 0x0014A148 File Offset: 0x00148348
		static readonly int WRMFOpiq4T;

		// Token: 0x0404F908 RID: 325896 RVA: 0x0014A150 File Offset: 0x00148350
		static readonly int yA0PEYz6EN;

		// Token: 0x0404F909 RID: 325897 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int VX68yIhYgE;

		// Token: 0x0404F90A RID: 325898 RVA: 0x0014A158 File Offset: 0x00148358
		static readonly int zG3EMM1aV4;

		// Token: 0x0404F90B RID: 325899 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int MmguaiKEN3;

		// Token: 0x0404F90C RID: 325900 RVA: 0x0014A160 File Offset: 0x00148360
		static readonly int yizdD8VNQG;

		// Token: 0x0404F90D RID: 325901 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int HKJ0esHwC1;

		// Token: 0x0404F90E RID: 325902 RVA: 0x0014A168 File Offset: 0x00148368
		static readonly int hZkKBt1MhQ;

		// Token: 0x0404F90F RID: 325903 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8cKnPQRZBO;

		// Token: 0x0404F910 RID: 325904 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 1nKPwBcqPs;

		// Token: 0x0404F911 RID: 325905 RVA: 0x0014A170 File Offset: 0x00148370
		static readonly int bXCWVZ7obT;

		// Token: 0x0404F912 RID: 325906 RVA: 0x0014A178 File Offset: 0x00148378
		static readonly int GIpAIoAfkN;

		// Token: 0x0404F913 RID: 325907 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int brvx93PVXA;

		// Token: 0x0404F914 RID: 325908 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int QL6zykaxS0;

		// Token: 0x0404F915 RID: 325909 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Tm8rHt8JHH;

		// Token: 0x0404F916 RID: 325910 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int B6FCRulOWc;

		// Token: 0x0404F917 RID: 325911 RVA: 0x0014A180 File Offset: 0x00148380
		static readonly int JlRaD5M0Lh;

		// Token: 0x0404F918 RID: 325912 RVA: 0x0014A188 File Offset: 0x00148388
		static readonly int OMNu4ysEqQ;

		// Token: 0x0404F919 RID: 325913 RVA: 0x0014A190 File Offset: 0x00148390
		static readonly int 5FOQ9TF4hD;

		// Token: 0x0404F91A RID: 325914 RVA: 0x0014A198 File Offset: 0x00148398
		static readonly int 9MazqrVinL;

		// Token: 0x0404F91B RID: 325915 RVA: 0x0014A1A0 File Offset: 0x001483A0
		static readonly int gH8k3ytVId;

		// Token: 0x0404F91C RID: 325916 RVA: 0x0014A1A8 File Offset: 0x001483A8
		static readonly int ChiGgEXBbt;

		// Token: 0x0404F91D RID: 325917 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 0SSIhBvXDM;

		// Token: 0x0404F91E RID: 325918 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int dKaetxHnWK;

		// Token: 0x0404F91F RID: 325919 RVA: 0x0014A1B0 File Offset: 0x001483B0
		static readonly int ktwEBcoUTl;

		// Token: 0x0404F920 RID: 325920 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int UUG4VOzzC1;

		// Token: 0x0404F921 RID: 325921 RVA: 0x0014A1B8 File Offset: 0x001483B8
		static readonly int DVS691GDWt;

		// Token: 0x0404F922 RID: 325922 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 7toRIGfNGF;

		// Token: 0x0404F923 RID: 325923 RVA: 0x0014A1C0 File Offset: 0x001483C0
		static readonly int XbEb1JDgJf;

		// Token: 0x0404F924 RID: 325924 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 8RleGPb0FJ;

		// Token: 0x0404F925 RID: 325925 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Vk7jokpyvO;

		// Token: 0x0404F926 RID: 325926 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int slt6emQ0E0;

		// Token: 0x0404F927 RID: 325927 RVA: 0x0014A1C8 File Offset: 0x001483C8
		static readonly int xk41uqIJK3;
	}
}
