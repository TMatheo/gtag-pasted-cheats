﻿using System;
using Photon.Realtime;
using UMWixflZOX;

namespace CanvasGUI
{
	// Token: 0x02000035 RID: 53
	public class JoinPatch
	{
		// Token: 0x060001E0 RID: 480 RVA: 0x0064EB94 File Offset: 0x0064CD94
		private unsafe static void Prefix(Player newPlayer)
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			if ((*(&JoinPatch.6YYSXgncU2) ^ *(&JoinPatch.6YYSXgncU2)) != 0)
			{
				goto IL_24;
			}
			goto IL_15E6;
			uint num2;
			for (;;)
			{
				IL_29:
				uint num;
				switch ((num = (num2 ^ (uint)(*(&JoinPatch.ppI6uxdexR)))) % (uint)(*(&JoinPatch.dOu4wXhoAe)))
				{
				case 0U:
				{
					int num4;
					int num3 = -num4;
					num4 = num3 % 857;
					uint[] array = new uint[*(&JoinPatch.GKBUOrPfiO)];
					array[*(&JoinPatch.10Hjerj01Q)] = (uint)(*(&JoinPatch.9hItkxWNzz) + *(&JoinPatch.6YUWpJttXW));
					array[*(&JoinPatch.GYN0oh1njl)] = (uint)(*(&JoinPatch.16VQujBRub));
					array[*(&JoinPatch.UCptSdgu3U) + *(&JoinPatch.8zceJlTRFC)] = (uint)(*(&JoinPatch.6tnO79CDmG));
					uint num5 = num & (uint)(*(&JoinPatch.Ic96CEseiK) + *(&JoinPatch.BGtPmCe0GJ)) & (uint)(*(&JoinPatch.PuLrelYbvS) + *(&JoinPatch.acIwMg0fcF));
					num2 = ((num5 | array[*(&JoinPatch.2yt4B09Yl5)]) ^ (uint)(*(&JoinPatch.fL7d0YQRca)));
					continue;
				}
				case 1U:
				{
					int[] array3;
					int[] array2 = array3;
					int num6 = 3;
					int num7 = ((array3[3] - 230) % 12 + -303 + 91) % 89 * -351;
					array2[num6] = (array3[3] ^ num7 ^ (2010600231 ^ num7));
					uint num8 = (num ^ (uint)(*(&JoinPatch.7zkOmHScgV)) ^ (uint)(*(&JoinPatch.NIJXIFwdyl))) * (uint)(*(&JoinPatch.VNlOuPaQNf));
					num2 = ((num8 & (uint)(*(&JoinPatch.yg1wZrd8vu))) ^ (uint)(*(&JoinPatch.AAFPWJjDRS)));
					continue;
				}
				case 2U:
				{
					int num9;
					num2 = (((num9 > num9) ? 1343711812U : 187299395U) ^ num * 1995926189U);
					continue;
				}
				case 3U:
				{
					int num10;
					int num4 = num10;
					uint num11 = num + (uint)(*(&JoinPatch.rXyYknfeI5) + *(&JoinPatch.JIhrg6YCVb));
					uint num12 = num11 - (uint)(*(&JoinPatch.Z44CnLOwCg));
					uint num13 = num12 - (uint)(*(&JoinPatch.Y3gCQ6KsDC) + *(&JoinPatch.JNH0TcOAy5));
					uint num14 = num13 - (uint)(*(&JoinPatch.8GtGlxdvuY));
					uint num15 = num14 ^ (uint)(*(&JoinPatch.YsbmhPleak));
					num2 = ((num15 & (uint)(*(&JoinPatch.wq8SRMwDtL))) ^ (uint)(*(&JoinPatch.7O7GhRJabc)));
					continue;
				}
				case 4U:
				{
					int num10;
					num2 = (((num10 > num10) ? 2879612743U : 4136893242U) ^ num * 96717931U);
					continue;
				}
				case 5U:
					goto IL_15E6;
				case 6U:
				{
					int num16;
					int num4 = num16;
					int num10 = (int)((byte)num10);
					uint[] array4 = new uint[*(&JoinPatch.vuUEMN2dRJ) + *(&JoinPatch.85dQW58NoL)];
					array4[*(&JoinPatch.Cet0pGNpU8)] = (uint)(*(&JoinPatch.KoODZvYwdF));
					array4[*(&JoinPatch.mNpffUoqcC)] = (uint)(*(&JoinPatch.CF2eOQBeYF));
					array4[*(&JoinPatch.AMIS8UrZ0l)] = (uint)(*(&JoinPatch.gLtjiyzOUV));
					array4[*(&JoinPatch.bgNS6EvtzJ) + *(&JoinPatch.t4XXEZEWgL)] = (uint)(*(&JoinPatch.nOz1f0WT6Z));
					array4[*(&JoinPatch.axKDne90W3) + *(&JoinPatch.j7kr1myVfI)] = (uint)(*(&JoinPatch.tdrIrNqWwG));
					uint num17 = (num | array4[*(&JoinPatch.sbwZs6uUtj)]) - array4[*(&JoinPatch.aO9mmpnH93)];
					uint num18 = num17 & (uint)(*(&JoinPatch.CAyxp6FBVa));
					num2 = (num18 - array4[*(&JoinPatch.xnEQLHKK95)] ^ array4[*(&JoinPatch.1dl5sfdFgC)] ^ (uint)(*(&JoinPatch.jiW2Esm9uv) + *(&JoinPatch.0s9TwxKtbe)));
					continue;
				}
				case 7U:
				{
					int num4;
					int num3 = num4 - num3;
					uint[] array5 = new uint[*(&JoinPatch.sg4CRVW5nJ) + *(&JoinPatch.Lj9zPLjKiP)];
					array5[*(&JoinPatch.SXhUnyN6rT)] = (uint)(*(&JoinPatch.tsnxXsj1NJ));
					array5[*(&JoinPatch.4LKm7oovSf)] = (uint)(*(&JoinPatch.psJVJU8jZd));
					array5[*(&JoinPatch.IaOTZc6Lbh) + *(&JoinPatch.lr6YVGN4W9)] = (uint)(*(&JoinPatch.JbnMnBjRoC));
					array5[*(&JoinPatch.uAcuBd70Nf) + *(&JoinPatch.sdTv37vuAC)] = (uint)(*(&JoinPatch.HDMaTqxBpY));
					array5[*(&JoinPatch.3ohZwlPMX1) + *(&JoinPatch.JWr1QqH2Sq)] = (uint)(*(&JoinPatch.PyRl5rxCaU));
					array5[*(&JoinPatch.q5LylE548R)] = (uint)(*(&JoinPatch.sjXI3uVVJn));
					uint num19 = (num | (uint)(*(&JoinPatch.i4t9IEW5eF))) & (uint)(*(&JoinPatch.xNvCKNL3QM));
					uint num20 = (num19 * array5[*(&JoinPatch.uN3B7qbJrK) + *(&JoinPatch.Vc2xwvMLpg)] & array5[*(&JoinPatch.rAZ3eexU7p)]) ^ (uint)(*(&JoinPatch.icE62UBrBc));
					num2 = (num20 + array5[*(&JoinPatch.mMNTtVU8QY)] ^ (uint)(*(&JoinPatch.BANteuy9hd)));
					continue;
				}
				case 8U:
				{
					int num4;
					int num3;
					int[] array6;
					array6[num3 + 6 - num3] = (num4 | 3);
					uint[] array7 = new uint[*(&JoinPatch.kSkh8dEKFz)];
					array7[*(&JoinPatch.QLc8eUcWe0)] = (uint)(*(&JoinPatch.7NiZidtEAa));
					array7[*(&JoinPatch.NKCf9borQh)] = (uint)(*(&JoinPatch.Qz7QXqUOmA));
					array7[*(&JoinPatch.WaF0pWtK8e)] = (uint)(*(&JoinPatch.uAKplGI69C));
					uint num21 = num & array7[*(&JoinPatch.pvG7kIPRB1)];
					uint num22 = num21 * array7[*(&JoinPatch.JfbAExELzm)];
					num2 = (num22 ^ (uint)(*(&JoinPatch.rdsvwQpSpR)) ^ (uint)(*(&JoinPatch.hYOkUkTIQh)));
					continue;
				}
				case 9U:
				{
					int num3;
					int num10;
					int num9 = num10 * num3;
					num9 = 5710042;
					uint[] array8 = new uint[*(&JoinPatch.3JR5VpjetK)];
					array8[*(&JoinPatch.EKQXJOeJii)] = (uint)(*(&JoinPatch.eReZoXIYHy));
					array8[*(&JoinPatch.C7oZlDD0VD)] = (uint)(*(&JoinPatch.x76iFEWTqs));
					array8[*(&JoinPatch.y8UfGlo1Q7)] = (uint)(*(&JoinPatch.hLX4IHg1wG));
					uint num23 = (num ^ array8[*(&JoinPatch.LnxevgV6Uj)]) | array8[*(&JoinPatch.BzsY9DmJSA)];
					num2 = (num23 * (uint)(*(&JoinPatch.ZLjYgmkBZ7)) ^ (uint)(*(&JoinPatch.ifgkhLK0uk)));
					continue;
				}
				case 10U:
				{
					int num10;
					int num3 = *(ref num10 + (IntPtr)num3);
					uint num24 = num | (uint)(*(&JoinPatch.v7r08DXPjZ));
					num2 = (((num24 ^ (uint)(*(&JoinPatch.oe2RI8tu3m))) | (uint)(*(&JoinPatch.iJTVJWDwWL) + *(&JoinPatch.zL23YXfiBE))) * (uint)(*(&JoinPatch.shtkx78TZU)) ^ (uint)(*(&JoinPatch.Dn7tzloVqm)));
					continue;
				}
				case 11U:
				{
					int num4;
					int num10 = -num4;
					int num3;
					num4 = (int)((byte)num3);
					uint[] array9 = new uint[*(&JoinPatch.lOIOHbIKaN) + *(&JoinPatch.WnpqKisPHu)];
					array9[*(&JoinPatch.AxY5q1BHRv)] = (uint)(*(&JoinPatch.m5YWGqUpD5));
					array9[*(&JoinPatch.EhnP9c8OdP)] = (uint)(*(&JoinPatch.MrXnRyzNhP));
					array9[*(&JoinPatch.aB2olaOSje)] = (uint)(*(&JoinPatch.NCLMqdJJ5N));
					uint num25 = num | array9[*(&JoinPatch.2wnBj4iuFR)];
					uint num26 = num25 & (uint)(*(&JoinPatch.0HHxfCo8oj));
					num2 = ((num26 | (uint)(*(&JoinPatch.Npo8BJgL7y))) ^ (uint)(*(&JoinPatch.oqRUXnX0Fq)));
					continue;
				}
				case 12U:
				{
					int num9;
					num2 = (((num9 > num9) ? 465041289U : 1316255624U) ^ num * 1167203884U);
					continue;
				}
				case 13U:
					goto IL_24;
				case 14U:
				{
					int num10 = num10;
					uint[] array10 = new uint[*(&JoinPatch.Hhp0aQTiQC)];
					array10[*(&JoinPatch.TQImS1mbHG)] = (uint)(*(&JoinPatch.LNC78UZDUe) + *(&JoinPatch.RjjUEkifUN));
					array10[*(&JoinPatch.z1JIi7rl6O)] = (uint)(*(&JoinPatch.nldGt4er2F));
					array10[*(&JoinPatch.0QOvuuryhs) + *(&JoinPatch.SGG3RUD4ZB)] = (uint)(*(&JoinPatch.nyHG1qFclK));
					array10[*(&JoinPatch.F0nOWimXXx)] = (uint)(*(&JoinPatch.P2DN5gejzY));
					array10[*(&JoinPatch.0kS1bCJI4D)] = (uint)(*(&JoinPatch.oONXmcc1hs));
					num2 = (((num | array10[*(&JoinPatch.sqglvuu3KU)]) + array10[*(&JoinPatch.MgnMTfiwwU)] ^ array10[*(&JoinPatch.ZedUIBpqld)] ^ (uint)(*(&JoinPatch.DmCGqKDqFr))) * (uint)(*(&JoinPatch.RQ7j1IlADG)) ^ (uint)(*(&JoinPatch.3qEMTNMMdt)));
					continue;
				}
				case 15U:
				{
					int num4 = (int)((ushort)num4);
					uint[] array11 = new uint[*(&JoinPatch.hdOa7lGOph)];
					array11[*(&JoinPatch.xQdloE2Ber)] = (uint)(*(&JoinPatch.192r4D4yNJ));
					array11[*(&JoinPatch.Gtr3W0K71Q)] = (uint)(*(&JoinPatch.XEmqrHrMHk));
					array11[*(&JoinPatch.vJQXDhkhg4) + *(&JoinPatch.qRAfaEikOy)] = (uint)(*(&JoinPatch.34KNUwXM9w));
					array11[*(&JoinPatch.VsrnY7cUzz)] = (uint)(*(&JoinPatch.Qna7jFDHPn));
					num2 = (((num & array11[*(&JoinPatch.jH7Tr19DCQ)]) | array11[*(&JoinPatch.KYiuj8kXHd)]) - (uint)(*(&JoinPatch.lNuZhPdNnP)) - (uint)(*(&JoinPatch.sP6VNNuX6h)) ^ (uint)(*(&JoinPatch.8ZSio1FqYl) + *(&JoinPatch.eqAwCVWivb)));
					continue;
				}
				case 16U:
					num2 = 1581100942U;
					continue;
				case 17U:
				{
					int num16;
					int num9 = -num16;
					uint[] array12 = new uint[*(&JoinPatch.F50d6rWyl6)];
					array12[*(&JoinPatch.hWcjMoRE2M)] = (uint)(*(&JoinPatch.XSG8rJtydY));
					array12[*(&JoinPatch.84uYzEB5rR)] = (uint)(*(&JoinPatch.UxNFCEqTkG));
					array12[*(&JoinPatch.N2L69xz1wx)] = (uint)(*(&JoinPatch.7iVM7mmDtH));
					array12[*(&JoinPatch.mVXk1kEA6m)] = (uint)(*(&JoinPatch.caNWLFtxZC));
					array12[*(&JoinPatch.PKI3TwcAHa)] = (uint)(*(&JoinPatch.bmkce1fkEZ));
					uint num27 = num | array12[*(&JoinPatch.sy5KUhU8B1)] | array12[*(&JoinPatch.2zoq2cNdQF)];
					uint num28 = num27 | array12[*(&JoinPatch.HD3fK0zu2T)];
					num2 = (num28 * array12[*(&JoinPatch.kJs9UaO8jw) + *(&JoinPatch.be9Phm83kB)] - (uint)(*(&JoinPatch.oBT9Ro5Z9e)) ^ (uint)(*(&JoinPatch.rjFrRtGoVb)));
					continue;
				}
				case 18U:
				{
					int[] array3;
					bool flag = ((newPlayer == JoinPatch.a) ? 1 : 0) == array3[0];
					uint[] array13 = new uint[*(&JoinPatch.osv9SQKCry)];
					array13[*(&JoinPatch.eAoI1eACif)] = (uint)(*(&JoinPatch.7aAU4REUpH));
					array13[*(&JoinPatch.ChS75jnd8e)] = (uint)(*(&JoinPatch.gptdeAgn62));
					array13[*(&JoinPatch.gEkgEOsaEB)] = (uint)(*(&JoinPatch.L0Wkv7rqMS));
					uint num29 = num + (uint)(*(&JoinPatch.0hEE8Rqg03));
					uint num30 = num29 & array13[*(&JoinPatch.vaYwk86w2r)];
					num2 = ((num30 | array13[*(&JoinPatch.0MY7SqSJsh)]) ^ (uint)(*(&JoinPatch.TzboB99ghw)));
					continue;
				}
				case 19U:
				{
					int num16;
					int num4 = *(ref JoinPatch.5bfRou6prb + (IntPtr)num16);
					uint[] array14 = new uint[*(&JoinPatch.AGvODf0eyl)];
					array14[*(&JoinPatch.qoI1dIha0M)] = (uint)(*(&JoinPatch.hirAmAO3cj));
					array14[*(&JoinPatch.WkO8tEbvm1)] = (uint)(*(&JoinPatch.thSCZ7SdE5));
					array14[*(&JoinPatch.TdgzrcZvlC) + *(&JoinPatch.R6BOPGaKHZ)] = (uint)(*(&JoinPatch.rvy9cAPokp));
					array14[*(&JoinPatch.svzhQ2DYRR) + *(&JoinPatch.ppKjkwfExT)] = (uint)(*(&JoinPatch.hHVoOhpgWq));
					array14[*(&JoinPatch.MuK6UgHe7W)] = (uint)(*(&JoinPatch.CB3zuBlOZq) + *(&JoinPatch.eL1RIkZKTs));
					array14[*(&JoinPatch.NhBkF4fOOD) + *(&JoinPatch.pBGaRfOf4M)] = (uint)(*(&JoinPatch.6aHqLA33xt));
					uint num31 = num * (uint)(*(&JoinPatch.G6KOJf9Suz));
					uint num32 = num31 - array14[*(&JoinPatch.gX9VBdFaAm)];
					uint num33 = num32 - array14[*(&JoinPatch.W4PGwwZVYF)];
					uint num34 = num33 - (uint)(*(&JoinPatch.Blae7s11Rv));
					uint num35 = num34 - array14[*(&JoinPatch.f5vFqjawps)];
					num2 = ((num35 | (uint)(*(&JoinPatch.4d3LXMrDcW))) ^ (uint)(*(&JoinPatch.Fo4ox46eYS)));
					continue;
				}
				case 20U:
				{
					int[] array3;
					array3[7] = 203272002;
					uint[] array15 = new uint[*(&JoinPatch.QVw6zlaSpx) + *(&JoinPatch.kokREGXCag)];
					array15[*(&JoinPatch.wNzHcbgScC)] = (uint)(*(&JoinPatch.CIPFNkdLQi));
					array15[*(&JoinPatch.PIBNs308mA)] = (uint)(*(&JoinPatch.5xoncCgpdX));
					array15[*(&JoinPatch.FH0mubYfDd) + *(&JoinPatch.mMv1QoLmYi)] = (uint)(*(&JoinPatch.khpbHOdmmK));
					array15[*(&JoinPatch.Exr2dHRYcQ)] = (uint)(*(&JoinPatch.eV4IXtCwXy));
					array15[*(&JoinPatch.03R4xhcYfg)] = (uint)(*(&JoinPatch.8w22Zye2YI));
					uint num36 = (num & (uint)(*(&JoinPatch.WxKHEPmgDX))) + array15[*(&JoinPatch.MqPyULgwF6)];
					uint num37 = num36 ^ (uint)(*(&JoinPatch.p335SsdCtj));
					uint num38 = num37 * array15[*(&JoinPatch.OJYObDtJ0i) + *(&JoinPatch.45UHTRhDiN)];
					num2 = (num38 + (uint)(*(&JoinPatch.Srwccd3OyV)) ^ (uint)(*(&JoinPatch.vkweJCSAWQ)));
					continue;
				}
				case 21U:
				{
					int num16;
					int num10 = (int)((short)num16);
					int num4 = num16;
					uint num39 = num + (uint)(*(&JoinPatch.T6UyflRfbB)) ^ (uint)(*(&JoinPatch.RgKUiqoDjd));
					num2 = ((num39 & (uint)(*(&JoinPatch.LY2NIVeWRl))) ^ (uint)(*(&JoinPatch.XZdnfPnZ3k)));
					continue;
				}
				case 22U:
				{
					int num3;
					int num9 = num3;
					num9 = (num3 ^ 1388300477);
					num2 = 1670444412U;
					continue;
				}
				case 23U:
				{
					int num10;
					int num16;
					int[] array6;
					int num9 = array6[num16 + 6 - num10] ^ 0;
					uint[] array16 = new uint[*(&JoinPatch.0f9J5ZECEc)];
					array16[*(&JoinPatch.TwjTagnxzh)] = (uint)(*(&JoinPatch.8vQNhRlXwY));
					array16[*(&JoinPatch.QVNFXHKb8Q)] = (uint)(*(&JoinPatch.LnYKSebaTk));
					array16[*(&JoinPatch.TvmvhEOwmo)] = (uint)(*(&JoinPatch.yrPpM7je6S));
					uint num40 = num - array16[*(&JoinPatch.WMziWVWG5C)];
					num2 = ((num40 & array16[*(&JoinPatch.zLDMFftbhS)]) * array16[*(&JoinPatch.3YyTcdXt8U)] ^ (uint)(*(&JoinPatch.47eBOH6DZM)));
					continue;
				}
				case 24U:
				{
					int num9;
					int num16 = ~num9;
					uint[] array17 = new uint[*(&JoinPatch.YkAiPIb7GQ) + *(&JoinPatch.juU6r5DGpK)];
					array17[*(&JoinPatch.G4N0n2DhzS)] = (uint)(*(&JoinPatch.DOK8EkYU89));
					array17[*(&JoinPatch.3hQBBmEg5j)] = (uint)(*(&JoinPatch.MgusedXK4W));
					array17[*(&JoinPatch.F4HxMUkW1H)] = (uint)(*(&JoinPatch.htIpQjoLyB));
					array17[*(&JoinPatch.xhmPGgebdl)] = (uint)(*(&JoinPatch.NNZl49Zcyr));
					uint num41 = num - array17[*(&JoinPatch.CsoyCcYEc5)];
					uint num42 = num41 ^ (uint)(*(&JoinPatch.yLV3jiR2rq));
					uint num43 = num42 + array17[*(&JoinPatch.zJ2Q3TTguQ)];
					num2 = (num43 * (uint)(*(&JoinPatch.JMXH8E2yNn)) ^ (uint)(*(&JoinPatch.Ia8iwC2fCW)));
					continue;
				}
				case 25U:
				{
					int num10;
					int num16 = (int)((byte)num10);
					int num3;
					num16 = (num3 & 2101547931);
					uint[] array18 = new uint[*(&JoinPatch.HcJHVPjJky)];
					array18[*(&JoinPatch.B6GWULDULU)] = (uint)(*(&JoinPatch.c7mtTuQ0pe));
					array18[*(&JoinPatch.d65SePUlah)] = (uint)(*(&JoinPatch.rfr0PkR2PJ) + *(&JoinPatch.g866EK0Zxk));
					array18[*(&JoinPatch.9seGVFBy1F)] = (uint)(*(&JoinPatch.1c4on7Pves));
					array18[*(&JoinPatch.cXkf7e99NU)] = (uint)(*(&JoinPatch.Y5yzh8BleK));
					array18[*(&JoinPatch.jdAKSDESTH)] = (uint)(*(&JoinPatch.5E5EIlH8I1));
					array18[*(&JoinPatch.GClhr5oFGo)] = (uint)(*(&JoinPatch.5nRTJ9XaN4) + *(&JoinPatch.aqpFZT9tr5));
					uint num44 = num & (uint)(*(&JoinPatch.1CdnDh1cdW));
					num2 = ((((num44 & array18[*(&JoinPatch.Z9MoMSxl4I)]) - array18[*(&JoinPatch.NruObaWgIX)] & (uint)(*(&JoinPatch.64XKx3JnPm))) * (uint)(*(&JoinPatch.I471eaeA3H)) | array18[*(&JoinPatch.gYzjrKRPMn)]) ^ (uint)(*(&JoinPatch.KVUGaelB1S)));
					continue;
				}
				case 26U:
				{
					int num3;
					int num16;
					num16 |= num3;
					uint num45 = num + (uint)(*(&JoinPatch.pQsQuj77CG)) + (uint)(*(&JoinPatch.L8YBQbAQqo)) + (uint)(*(&JoinPatch.lAz0wOep6y));
					num2 = (num45 + (uint)(*(&JoinPatch.PiDCZlFdKb)) ^ (uint)(*(&JoinPatch.2CVethx6MZ)));
					continue;
				}
				case 27U:
				{
					uint num46 = num & (uint)(*(&JoinPatch.IKWSATt3tA));
					uint num47 = (num46 + (uint)(*(&JoinPatch.6VnB1hFycn))) * (uint)(*(&JoinPatch.l4albxk1b9) + *(&JoinPatch.zcJk8VBhjY));
					num2 = (num47 ^ (uint)(*(&JoinPatch.aYgMryrTO2)) ^ (uint)(*(&JoinPatch.ZwjOqOtu0M)));
					continue;
				}
				case 28U:
				{
					int[] array3;
					array3[3] = 92313165;
					uint[] array19 = new uint[*(&JoinPatch.LtmY8WBwCD) + *(&JoinPatch.1GQFCYyn9x)];
					array19[*(&JoinPatch.8qlX4ynLRI)] = (uint)(*(&JoinPatch.Ire4E8AZv5));
					array19[*(&JoinPatch.I6f4q3aHkB)] = (uint)(*(&JoinPatch.LTfaHfIPeJ));
					array19[*(&JoinPatch.tze34KlVAD)] = (uint)(*(&JoinPatch.XZ2DpBLrqA));
					array19[*(&JoinPatch.YfkP7yLEwj)] = (uint)(*(&JoinPatch.0v5mMSbl9g));
					array19[*(&JoinPatch.REHhovbbuG)] = (uint)(*(&JoinPatch.UaidvNPO5G));
					uint num48 = num - array19[*(&JoinPatch.8hjaNmeP0X)];
					uint num49 = num48 + array19[*(&JoinPatch.jjsKsTYDlM)];
					uint num50 = num49 | array19[*(&JoinPatch.WtTqPZMb08)];
					num2 = (num50 + array19[*(&JoinPatch.CMp2hufqTC)] - array19[*(&JoinPatch.QLkXgusYub)] ^ (uint)(*(&JoinPatch.zMnttPO2Lx)));
					continue;
				}
				case 29U:
				{
					int num4;
					*(ref JoinPatch.5bfRou6prb + (IntPtr)num4) = num4;
					int num16;
					int num3 = num16 << 3;
					num2 = 1978138868U;
					continue;
				}
				case 30U:
				{
					int num10;
					int num9 = num10 + 910;
					uint num51 = num ^ (uint)(*(&JoinPatch.fdIECiY3FK));
					uint num52 = num51 - (uint)(*(&JoinPatch.cAfS0OQLLd));
					uint num53 = num52 * (uint)(*(&JoinPatch.eLaNEIeSI4)) | (uint)(*(&JoinPatch.VuoBgGaS0f));
					uint num54 = num53 - (uint)(*(&JoinPatch.Tt3jS0Nqch));
					num2 = ((num54 | (uint)(*(&JoinPatch.h8h89TC593))) ^ (uint)(*(&JoinPatch.EGuKzsVevu)));
					continue;
				}
				case 31U:
				{
					int[] array3;
					int[] array20 = array3;
					int num55 = 9;
					int num56 = (array3[9] >> 2) % 62;
					int num7 = (175 == 0) ? (num56 - 6) : (num56 + 175);
					array20[num55] = (array3[9] ^ num7 ^ (2010600231 ^ num7));
					num2 = 84200467U;
					continue;
				}
				case 32U:
				{
					int num4;
					JoinPatch.5bfRou6prb = num4;
					uint num57 = num + (uint)(*(&JoinPatch.jBKxG2751f) + *(&JoinPatch.ER65vNpWL1));
					uint num58 = num57 | (uint)(*(&JoinPatch.V3SBWmr0Lz));
					uint num59 = num58 - (uint)(*(&JoinPatch.xsznIKABCe)) | (uint)(*(&JoinPatch.4I1EtNQfbL) + *(&JoinPatch.rr5gnqsJae));
					num2 = ((num59 & (uint)(*(&JoinPatch.LHuBsVcTxl))) ^ (uint)(*(&JoinPatch.MoUq7NCORJ) + *(&JoinPatch.VMYAIFxS9b)) ^ (uint)(*(&JoinPatch.b0khTwX0WY)));
					continue;
				}
				case 33U:
				{
					int[] array3;
					array3[8] = 936073421;
					array3[9] = 1240710095;
					array3[10] = 255709226;
					uint num60 = num | (uint)(*(&JoinPatch.bW6hBuivmB));
					uint num61 = num60 + (uint)(*(&JoinPatch.KZdfRgX6v8));
					num2 = ((num61 & (uint)(*(&JoinPatch.JfUfwTIz8R))) ^ (uint)(*(&JoinPatch.9hqRw5vPas) + *(&JoinPatch.4ImxKWGQNm)));
					continue;
				}
				case 34U:
				{
					int num3;
					num2 = (((num3 <= num3) ? 422562792U : 134377884U) ^ num * 2733419239U);
					continue;
				}
				case 35U:
				{
					int[] array3;
					array3[4] = 1367175684;
					array3[5] = 2010600061;
					array3[6] = 1275175748;
					uint[] array21 = new uint[*(&JoinPatch.ZCZ2UW4zn8)];
					array21[*(&JoinPatch.xrtj5KJ5Kf)] = (uint)(*(&JoinPatch.ryrYJ0j6JS));
					array21[*(&JoinPatch.gmfgmOwsDJ)] = (uint)(*(&JoinPatch.03uwoIdExi));
					array21[*(&JoinPatch.GSspGlVAsd)] = (uint)(*(&JoinPatch.x8pVcKLM6r));
					num2 = ((num - array21[*(&JoinPatch.Ya2BpxD4uB)] | (uint)(*(&JoinPatch.XeIkLN40ZA))) + array21[*(&JoinPatch.2wAjV2NZUd) + *(&JoinPatch.6QHGKparAS)] ^ (uint)(*(&JoinPatch.ibPrGSzFJO)));
					continue;
				}
				case 36U:
				{
					int num3;
					int num9;
					int num10 = num9 % num3;
					num2 = 1212384111U;
					continue;
				}
				case 37U:
				{
					int num4;
					num2 = (((num4 > num4) ? 2390366047U : 3910628800U) ^ num * 414460429U);
					continue;
				}
				case 38U:
				{
					int num16;
					int num10 = num16 | 1955985706;
					*(ref JoinPatch.5bfRou6prb + (IntPtr)num10) = num10;
					int num4;
					int num3;
					int num9;
					int[] array6;
					array6[num9 + 8 - num3] = (num4 | -3);
					uint[] array22 = new uint[*(&JoinPatch.Psgr6sc84E)];
					array22[*(&JoinPatch.eWjwrADZ8J)] = (uint)(*(&JoinPatch.6UgXBgSH1y));
					array22[*(&JoinPatch.2wZruqo2by)] = (uint)(*(&JoinPatch.JlGUdM5u3h));
					array22[*(&JoinPatch.Hu1ko5LJqa)] = (uint)(*(&JoinPatch.ZUHGMr71CA));
					array22[*(&JoinPatch.VL8K9UNL4y)] = (uint)(*(&JoinPatch.kiOUqH5yDy));
					array22[*(&JoinPatch.feMBYyeAIv)] = (uint)(*(&JoinPatch.PEs3L6wrlT) + *(&JoinPatch.s9P1z1GwaE));
					array22[*(&JoinPatch.wIxNe186vL)] = (uint)(*(&JoinPatch.0NDIjfzVJt) + *(&JoinPatch.VONtFfOVLh));
					uint num62 = num ^ array22[*(&JoinPatch.srjE8GQeYU)];
					uint num63 = num62 - (uint)(*(&JoinPatch.8z5Zdf6GRT) + *(&JoinPatch.Bunqti5DI9));
					uint num64 = (num63 & (uint)(*(&JoinPatch.mnvOdIn8Kd))) - (uint)(*(&JoinPatch.OV7zvfSyPk));
					uint num65 = num64 ^ array22[*(&JoinPatch.jID1f7E2VZ) + *(&JoinPatch.LNWYrUEq5V)];
					num2 = ((num65 | (uint)(*(&JoinPatch.176yEqwy5N))) ^ (uint)(*(&JoinPatch.PGyhaek3tg)));
					continue;
				}
				case 39U:
				{
					int[] array23 = new int[10];
					uint[] array24 = new uint[*(&JoinPatch.GBEdKOvT2v)];
					array24[*(&JoinPatch.fJDGGCsBBh)] = (uint)(*(&JoinPatch.jXrqKjTlt9));
					array24[*(&JoinPatch.bFTOpQv72Y)] = (uint)(*(&JoinPatch.4UzaVJSwOI));
					array24[*(&JoinPatch.5pX9ztUYSl) + *(&JoinPatch.4Kj3Uazybz)] = (uint)(*(&JoinPatch.RvJmnOhRUA));
					uint num66 = num * array24[*(&JoinPatch.QhWlDvrUZ6)] ^ array24[*(&JoinPatch.6XoRduu6F5)];
					num2 = (num66 ^ array24[*(&JoinPatch.UdVZ1KgvVk)] ^ (uint)(*(&JoinPatch.LCDRUXx8zj)));
					continue;
				}
				case 40U:
				{
					int num3;
					int num9 = -num3;
					uint[] array25 = new uint[*(&JoinPatch.tfZe33G2J3) + *(&JoinPatch.dlLZqxL7u3)];
					array25[*(&JoinPatch.O68yv3UX6F)] = (uint)(*(&JoinPatch.6wHgLyE0f7));
					array25[*(&JoinPatch.EnlcHk0nkh)] = (uint)(*(&JoinPatch.M0O6Uxgkt9) + *(&JoinPatch.jt5D7rdpN1));
					array25[*(&JoinPatch.tUbwylUgrK) + *(&JoinPatch.DqwZ3GhKLY)] = (uint)(*(&JoinPatch.SdHgXVsifa));
					array25[*(&JoinPatch.GLZsy1YbHt)] = (uint)(*(&JoinPatch.cA3j626gK0) + *(&JoinPatch.JTdyjPN5Zd));
					num2 = ((num * (uint)(*(&JoinPatch.3wBRD2QDlB) + *(&JoinPatch.rFCc5Rkije)) | array25[*(&JoinPatch.YLXoQwrlJi)]) * array25[*(&JoinPatch.odCn0q8mfE)] + (uint)(*(&JoinPatch.m25IJDQB2R)) ^ (uint)(*(&JoinPatch.ppV4FrYXAQ)));
					continue;
				}
				case 41U:
				{
					int num3 = 59094631;
					uint[] array26 = new uint[*(&JoinPatch.s2ctKdMCCf)];
					array26[*(&JoinPatch.giPDNNXO3m)] = (uint)(*(&JoinPatch.FRmjkC353u));
					array26[*(&JoinPatch.mRqWph5wBO)] = (uint)(*(&JoinPatch.moQtW1hfAd));
					array26[*(&JoinPatch.0e0NHbP3IH) + *(&JoinPatch.kQJR2O13Yp)] = (uint)(*(&JoinPatch.RkMp9aA2Mt));
					array26[*(&JoinPatch.fY4Z4HbcON)] = (uint)(*(&JoinPatch.RCn3nWf80H));
					array26[*(&JoinPatch.9nHVLPSKNr)] = (uint)(*(&JoinPatch.bXqZmMVtXv));
					uint num67 = num * (uint)(*(&JoinPatch.xYoKXO6SBn)) & (uint)(*(&JoinPatch.5BCFt1RiNo));
					uint num68 = num67 | (uint)(*(&JoinPatch.zQOhw4WORb));
					num2 = (num68 + array26[*(&JoinPatch.AvkFUk9687)] ^ array26[*(&JoinPatch.S9IkwZVlqu) + *(&JoinPatch.5wfs5hKHXc)] ^ (uint)(*(&JoinPatch.2sAkmJa6uI)));
					continue;
				}
				case 42U:
				{
					int[] array3;
					int[] array27 = array3;
					int num69 = 2;
					int num7 = -array3[2] >> 6;
					array27[num69] = (array3[2] ^ num7 ^ (2010600231 ^ num7));
					uint[] array28 = new uint[*(&JoinPatch.5aCdOBAZvb)];
					array28[*(&JoinPatch.rHISY1RSp4)] = (uint)(*(&JoinPatch.xS5L4CrCPV));
					array28[*(&JoinPatch.SGEWJ71g3G)] = (uint)(*(&JoinPatch.uMyaMCvL5T));
					array28[*(&JoinPatch.vMd3Qmf0jL)] = (uint)(*(&JoinPatch.T7JZIlDwIa));
					array28[*(&JoinPatch.9uYiJkdf91)] = (uint)(*(&JoinPatch.RfH6kGmLGg));
					uint num70 = (num ^ array28[*(&JoinPatch.cB7sxxDZRl)]) + (uint)(*(&JoinPatch.98DeUAy4tp));
					uint num71 = num70 - (uint)(*(&JoinPatch.JA1r4x0NyC));
					num2 = (num71 + (uint)(*(&JoinPatch.82ql88xpvW) + *(&JoinPatch.gENY2Scmlk)) ^ (uint)(*(&JoinPatch.SsbaXcJQy9)));
					continue;
				}
				case 43U:
				{
					int num4;
					int num9 = num4 << 2;
					uint[] array29 = new uint[*(&JoinPatch.VJasgoFGPP)];
					array29[*(&JoinPatch.ROtM1IhqQz)] = (uint)(*(&JoinPatch.tOXnp1cUo3));
					array29[*(&JoinPatch.G0DpmvY02H)] = (uint)(*(&JoinPatch.hTSphJizww));
					array29[*(&JoinPatch.mMk3HHvxCo) + *(&JoinPatch.LucWIbLEjF)] = (uint)(*(&JoinPatch.urxISa6sFf));
					array29[*(&JoinPatch.Tmi1R4QJif)] = (uint)(*(&JoinPatch.9lxN5w06gG));
					array29[*(&JoinPatch.8dQqC4Zbkr) + *(&JoinPatch.KDrhVjMkEO)] = (uint)(*(&JoinPatch.LBgDGI3jNg));
					num2 = (((num * (uint)(*(&JoinPatch.jAL9h0W1yW)) & (uint)(*(&JoinPatch.eyj1V63Q2W))) + (uint)(*(&JoinPatch.jQ1S567Mk3))) * array29[*(&JoinPatch.BzOEHK1s9e)] - array29[*(&JoinPatch.MUvrtWcpsK)] ^ (uint)(*(&JoinPatch.Pnq07TI3Dk)));
					continue;
				}
				case 44U:
				{
					int num10;
					num2 = (((num10 <= num10) ? 2663003859U : 3935256705U) ^ num * 234788482U);
					continue;
				}
				case 45U:
				{
					int num9;
					int num4 = num9;
					uint[] array30 = new uint[*(&JoinPatch.3HLCm3X65b)];
					array30[*(&JoinPatch.ueJN4fwGJI)] = (uint)(*(&JoinPatch.KyEioiOVbH));
					array30[*(&JoinPatch.gBKijfBLr0)] = (uint)(*(&JoinPatch.7YDyog09z9));
					array30[*(&JoinPatch.8szYTECmXE) + *(&JoinPatch.oBex5sTloY)] = (uint)(*(&JoinPatch.dkZTLvvQ4H));
					array30[*(&JoinPatch.rOgbJyMwPe)] = (uint)(*(&JoinPatch.cYxmL53P26) + *(&JoinPatch.NPVafXTgMh));
					array30[*(&JoinPatch.SwsQWZfCnH)] = (uint)(*(&JoinPatch.ggWJ5FxwHQ));
					array30[*(&JoinPatch.2gX74c3G6v)] = (uint)(*(&JoinPatch.fpksMqqhPw));
					uint num72 = num ^ array30[*(&JoinPatch.a1lvaq2Lea)];
					uint num73 = (num72 & array30[*(&JoinPatch.kgY6owZuV4)]) ^ (uint)(*(&JoinPatch.gZG2m06n7P));
					uint num74 = num73 * (uint)(*(&JoinPatch.ZPgV0A4lhO) + *(&JoinPatch.jrlfL8QoDa));
					uint num75 = num74 & (uint)(*(&JoinPatch.R5LVPAutJj));
					num2 = ((num75 | array30[*(&JoinPatch.tPOOAUADGn)]) ^ (uint)(*(&JoinPatch.1xMHUzxkrn)));
					continue;
				}
				case 46U:
				{
					int num3;
					int num10 = num3;
					num2 = 1828459301U;
					continue;
				}
				case 47U:
				{
					int num3;
					int num16;
					int num4 = num16 % num3;
					int num10 = num10;
					int num9 = num16 ^ 264704175;
					uint[] array31 = new uint[*(&JoinPatch.XwZxh4bMhV)];
					array31[*(&JoinPatch.NNajfM5Luq)] = (uint)(*(&JoinPatch.KxyBuCPKT1));
					array31[*(&JoinPatch.1MlfJM9eBu)] = (uint)(*(&JoinPatch.Z3JCXRQaRz));
					array31[*(&JoinPatch.ZKyFQk7XCf) + *(&JoinPatch.pR2peBl5aT)] = (uint)(*(&JoinPatch.MaKAQRovod));
					array31[*(&JoinPatch.vz3dbqXgOj)] = (uint)(*(&JoinPatch.OlcfEIAdiW));
					array31[*(&JoinPatch.qU98n9Axz8)] = (uint)(*(&JoinPatch.6LtitzYYNy));
					array31[*(&JoinPatch.nEq1Ek8o5H)] = (uint)(*(&JoinPatch.QKNRxbz50c) + *(&JoinPatch.pjqQmD13wP));
					uint num76 = num * array31[*(&JoinPatch.tmPusloI3C)];
					num2 = ((num76 - (uint)(*(&JoinPatch.AV2rsv8bvS)) + array31[*(&JoinPatch.AdivIEYaOA) + *(&JoinPatch.sE2qYo5cjM)] + array31[*(&JoinPatch.wqBxcTr9i1) + *(&JoinPatch.FaIdOPEemo)] + array31[*(&JoinPatch.NN43T5dMTD)] & (uint)(*(&JoinPatch.0f2jfUcuSy))) ^ (uint)(*(&JoinPatch.WY2W5S6YbI)));
					continue;
				}
				case 48U:
				{
					int num9;
					num2 = (((num9 <= num9) ? 3353759796U : 3542739178U) ^ num * 772556787U);
					continue;
				}
				case 49U:
				{
					int num16;
					num2 = (((num16 <= num16) ? 1163172341U : 1107909462U) ^ num * 3735480159U);
					continue;
				}
				case 50U:
				{
					int num16;
					int num3 = ~num16;
					uint num77 = num - (uint)(*(&JoinPatch.2eNRoG5Xqn));
					uint num78 = num77 - (uint)(*(&JoinPatch.yLeW9MHoAa)) ^ (uint)(*(&JoinPatch.XXxRmJ0xa1));
					num2 = ((num78 - (uint)(*(&JoinPatch.oy27qtbXU5) + *(&JoinPatch.OJeT9dL4UK)) | (uint)(*(&JoinPatch.ft0pTfr6oe))) ^ (uint)(*(&JoinPatch.PH6y8AShqQ)));
					continue;
				}
				case 51U:
				{
					int[] array3;
					array3[14] = 1846861386;
					int[] array32 = array3;
					int num79 = 0;
					int num7 = array3[0] + -431 ^ 260;
					array32[num79] = (array3[0] ^ num7 ^ (2010600231 ^ num7));
					int[] array33 = array3;
					int num80 = 1;
					num7 = ((array3[1] << 7) + 200) * 104;
					array33[num80] = (array3[1] ^ num7 ^ (2010600231 ^ num7));
					uint[] array34 = new uint[*(&JoinPatch.ZFCwkO0L37)];
					array34[*(&JoinPatch.FUZQYx0uGw)] = (uint)(*(&JoinPatch.1m24OZCdWt));
					array34[*(&JoinPatch.sKU13lBiTT)] = (uint)(*(&JoinPatch.HbtGzKc1G6));
					array34[*(&JoinPatch.V55ccxNHiL)] = (uint)(*(&JoinPatch.MWzJO59iXw));
					uint num81 = num | (uint)(*(&JoinPatch.vSaxoZ2wFE));
					uint num82 = num81 ^ array34[*(&JoinPatch.6LWaYxO2ZF)];
					num2 = (num82 * (uint)(*(&JoinPatch.Y4AIHumj13)) ^ (uint)(*(&JoinPatch.K4dTKDeIxD)));
					continue;
				}
				case 52U:
				{
					int[] array3;
					int[] array35 = array3;
					int num83 = 13;
					int num7 = (array3[13] % 57 + -1) % 10 % 34 << 5;
					array35[num83] = (array3[13] ^ num7 ^ (2010600231 ^ num7));
					int[] array36 = array3;
					int num84 = 14;
					num7 = -(array3[14] * 349) % 96 + 331 >> 6;
					array36[num84] = (array3[14] ^ num7 ^ (2010600231 ^ num7));
					uint[] array37 = new uint[*(&JoinPatch.l8XEiusgKG)];
					array37[*(&JoinPatch.6kFmsymUQR)] = (uint)(*(&JoinPatch.T5yBGeJ6Uo));
					array37[*(&JoinPatch.7F8lHRVOug)] = (uint)(*(&JoinPatch.xHoTOCB52K));
					array37[*(&JoinPatch.7JHbwqKV7E)] = (uint)(*(&JoinPatch.kwLfI1lefa) + *(&JoinPatch.cYjteMRexD));
					array37[*(&JoinPatch.cNDKrx7hza)] = (uint)(*(&JoinPatch.H9Qq5B5IKW));
					array37[*(&JoinPatch.bhacrjkX7j) + *(&JoinPatch.Ypi4lXsByU)] = (uint)(*(&JoinPatch.3EoESdI3yc));
					array37[*(&JoinPatch.QIUam4wkcI) + *(&JoinPatch.NkjPBbbVEi)] = (uint)(*(&JoinPatch.S3UzcX3WJO));
					uint num85 = num & (uint)(*(&JoinPatch.bqieTQVHRr));
					uint num86 = num85 ^ array37[*(&JoinPatch.kHiqHTeZC1)];
					uint num87 = num86 * (uint)(*(&JoinPatch.BwyQKWye8P) + *(&JoinPatch.BabOrgBF6v)) & array37[*(&JoinPatch.GUEX7KVnsJ)];
					uint num88 = num87 & array37[*(&JoinPatch.2dTSMp2SU6)];
					num2 = ((num88 | array37[*(&JoinPatch.c0JCpJqU9k) + *(&JoinPatch.RYcRurrbS9)]) ^ (uint)(*(&JoinPatch.BKvyWhGIBC)));
					continue;
				}
				case 53U:
				{
					int num9;
					int num16;
					int[] array6;
					array6[num9 + 6 - num16] = num16 - -6;
					num2 = (((num + (uint)(*(&JoinPatch.Kp4CWNDYmP) + *(&JoinPatch.S8Cf2fPOeN)) ^ (uint)(*(&JoinPatch.gqs139IHiI))) & (uint)(*(&JoinPatch.SllO3683w5))) ^ (uint)(*(&JoinPatch.A2Yn8rmzBj) + *(&JoinPatch.bJ2xue7DIX)));
					continue;
				}
				case 54U:
				{
					int num3;
					int num10 = (int)((sbyte)num3);
					int num9;
					int num16;
					int[] array6;
					array6[num16 + 7 - num3] = (num9 | 4);
					num10 = (num3 ^ num9);
					int num4;
					num10 = num4;
					num4 = num16 + 800;
					num2 = ((num & (uint)(*(&JoinPatch.xHTBB6swFo)) & (uint)(*(&JoinPatch.47YRhqSwhu))) - (uint)(*(&JoinPatch.S8AxvIVTL7) + *(&JoinPatch.xOxTKfGusu)) ^ (uint)(*(&JoinPatch.PjDsh4nsnf) + *(&JoinPatch.02QD5yGfP3)));
					continue;
				}
				case 55U:
				{
					int num10;
					num2 = ((num10 > num10) ? 1809329631U : 1798779824U);
					continue;
				}
				case 56U:
				{
					int[] array3;
					calli(System.Void(System.String), calli(System.String(System.String,System.String,System.String), calli(System.Object(System.Int32), lDwvHqL9gN.JDHAGENDM[array3[1]], Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array3[2] ^ array3[3]) - array3[4]]), newPlayer.NickName, calli(System.Object(System.Int32), lDwvHqL9gN.JDHAGENDM[array3[5]], Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array3[6] ^ array3[7]) - array3[8]]), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array3[9] ^ array3[10]) - array3[11]]), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array3[12] ^ array3[13]) - array3[14]]);
					JoinPatch.a = newPlayer;
					uint num89 = num | (uint)(*(&JoinPatch.hLkKPuck9w));
					uint num90 = num89 + (uint)(*(&JoinPatch.A5yeboJHvS));
					uint num91 = num90 | (uint)(*(&JoinPatch.9hySk69uul));
					num2 = ((num91 & (uint)(*(&JoinPatch.8aOFKpmNrh) + *(&JoinPatch.OsK5hXA6MX))) ^ (uint)(*(&JoinPatch.02uPx9XRkT)));
					continue;
				}
				case 57U:
				{
					uint num92 = (num ^ (uint)(*(&JoinPatch.JskDbDWXNd))) - (uint)(*(&JoinPatch.qabD7orlHw));
					uint num93 = num92 - (uint)(*(&JoinPatch.jyw86tpXPN));
					num2 = (num93 * (uint)(*(&JoinPatch.gCXyGXl9gE)) ^ (uint)(*(&JoinPatch.AVFLKBzqrq)));
					continue;
				}
				case 58U:
				{
					int num9;
					int num4 = num9 - 403;
					int num16;
					int num10 = (int)((sbyte)num16);
					uint num94 = num ^ (uint)(*(&JoinPatch.cZ7onbvfTD));
					uint num95 = num94 * (uint)(*(&JoinPatch.0ujOJSIbzY));
					uint num96 = num95 | (uint)(*(&JoinPatch.AZCjbKvVEP));
					num2 = (num96 + (uint)(*(&JoinPatch.GLC8HWsTo0)) ^ (uint)(*(&JoinPatch.bQupUNos7P)));
					continue;
				}
				case 59U:
				{
					int num3 = 1607629270;
					num2 = 1898492487U;
					continue;
				}
				case 60U:
				{
					int num3 = num3;
					int num4;
					int num10;
					int[] array23;
					num3 = array23[num10 + 7 - num4] + 8;
					int num9 = JoinPatch.5bfRou6prb;
					uint[] array38 = new uint[*(&JoinPatch.CLyb1Fzmx3) + *(&JoinPatch.XRG3lovs4C)];
					array38[*(&JoinPatch.o0pgr6y6EU)] = (uint)(*(&JoinPatch.GSEmcIQeNY));
					array38[*(&JoinPatch.g8owNcJ4v0)] = (uint)(*(&JoinPatch.7O269MfRt4) + *(&JoinPatch.Q2icxFNebc));
					array38[*(&JoinPatch.XRfgfqL3TO)] = (uint)(*(&JoinPatch.x4LNW1ZHmQ) + *(&JoinPatch.m8uSHnaL8I));
					array38[*(&JoinPatch.PocScqsWbT)] = (uint)(*(&JoinPatch.Am8eHWrUF5));
					num2 = (((num & (uint)(*(&JoinPatch.pG1KzZhNY1))) - (uint)(*(&JoinPatch.P94L9Ib2vq) + *(&JoinPatch.JDqTQAAPLv)) + array38[*(&JoinPatch.6GGDcJwScD) + *(&JoinPatch.Jf7jDAswf8)] | (uint)(*(&JoinPatch.4yiZwmZi4z))) ^ (uint)(*(&JoinPatch.YRCn5J31t0)));
					continue;
				}
				case 61U:
				{
					int[] array3 = new int[19];
					int num97 = 201;
					num2 = (((num97 != 201) ? 2312115614U : 2411084593U) ^ num * 3928000998U);
					continue;
				}
				case 62U:
				{
					int num3;
					int num10 = num3 - 625;
					uint num98 = num + (uint)(*(&JoinPatch.9l2Xjcl83v));
					uint num99 = num98 & (uint)(*(&JoinPatch.dKsy4AZthL));
					num2 = ((num99 & (uint)(*(&JoinPatch.XuWCHMOIDw))) ^ (uint)(*(&JoinPatch.tJ1ZEHpVAV) + *(&JoinPatch.V9ao125Izy)));
					continue;
				}
				case 63U:
				{
					int num4;
					int num16;
					int[] array23;
					array23[num16 + 9 - num16] = num4 - 4;
					uint num100 = num * (uint)(*(&JoinPatch.X9lxypb2df));
					uint num101 = (num100 | (uint)(*(&JoinPatch.ESAO1n4Wlo))) + (uint)(*(&JoinPatch.VhGOvjoUGP));
					num2 = (((num101 ^ (uint)(*(&JoinPatch.bicgaP7QNu))) | (uint)(*(&JoinPatch.KN9pXjBGnG))) ^ (uint)(*(&JoinPatch.mbUiD03XBP)));
					continue;
				}
				case 64U:
				{
					int num3;
					int num4 = (int)((sbyte)num3);
					uint[] array39 = new uint[*(&JoinPatch.EERrQjdggJ)];
					array39[*(&JoinPatch.b2qFCIg3c9)] = (uint)(*(&JoinPatch.apnejXhzxc));
					array39[*(&JoinPatch.71NWmN8PSR)] = (uint)(*(&JoinPatch.pEe4pB99JK));
					array39[*(&JoinPatch.qTtdTZaxH3) + *(&JoinPatch.CntDLjpUcz)] = (uint)(*(&JoinPatch.KQkKUVLtzi));
					array39[*(&JoinPatch.XipnvnHtCN)] = (uint)(*(&JoinPatch.wLIZPBVasF));
					array39[*(&JoinPatch.VpgU9atjI8)] = (uint)(*(&JoinPatch.Nr8jge7FRi));
					array39[*(&JoinPatch.c5RPC9IL4T)] = (uint)(*(&JoinPatch.9uAtMrBVnV));
					uint num102 = num * (uint)(*(&JoinPatch.4ilE9ENj3v));
					uint num103 = num102 & array39[*(&JoinPatch.DPJKnaXRRA)] & array39[*(&JoinPatch.Rhoy8drOWy)] & (uint)(*(&JoinPatch.cmc5n3TNP7));
					uint num104 = num103 * (uint)(*(&JoinPatch.wjSJQtl0Gw));
					num2 = ((num104 | (uint)(*(&JoinPatch.TuDmEW3wFg))) ^ (uint)(*(&JoinPatch.X8METaxNgt)));
					continue;
				}
				case 65U:
				{
					int[] array3;
					int[] array40 = array3;
					int num105 = 10;
					int num7 = ((array3[10] >> 1) + 62) % 7;
					array40[num105] = (array3[10] ^ num7 ^ (2010600231 ^ num7));
					int[] array41 = array3;
					int num106 = 11;
					int num107 = array3[11];
					num7 = (((-123 == 0) ? (num107 - 96) : (num107 + -123)) << 3 & -10) + -189;
					array41[num106] = (array3[11] ^ num7 ^ (2010600231 ^ num7));
					num2 = 64361760U;
					continue;
				}
				case 66U:
				{
					int num3;
					int num16;
					int num9 = *(ref num16 + (IntPtr)num3);
					num2 = (((num - (uint)(*(&JoinPatch.atMX2Uh64D))) * (uint)(*(&JoinPatch.rHL16dUWY5)) - (uint)(*(&JoinPatch.urxYYOSVHc)) & (uint)(*(&JoinPatch.MmSjEDFDPe))) + (uint)(*(&JoinPatch.UF5EdWkbqk)) ^ (uint)(*(&JoinPatch.uPxWft6x9n)));
					continue;
				}
				case 67U:
				{
					int num10;
					num2 = (((num10 > num10) ? 1920268194U : 889514172U) ^ num * 1852089845U);
					continue;
				}
				case 68U:
				{
					int[] array3;
					int[] array42 = array3;
					int num108 = 8;
					int num109 = array3[8] - -27;
					int num7 = (((61 == 0) ? (num109 - 48) : (num109 + 61)) + -500 >> 2) + -330 >> 7;
					array42[num108] = (array3[8] ^ num7 ^ (2010600231 ^ num7));
					num2 = 455511019U;
					continue;
				}
				case 69U:
				{
					int num9 = -num9;
					int[] array23;
					int num3 = array23[num9 + 7 - num9] ^ 0;
					uint[] array43 = new uint[*(&JoinPatch.sI1jymnDjr)];
					array43[*(&JoinPatch.NI6nZ7XfG2)] = (uint)(*(&JoinPatch.7mHkH2rC78) + *(&JoinPatch.jpBVjuhPfz));
					array43[*(&JoinPatch.zTJQHwA0mR)] = (uint)(*(&JoinPatch.ta7gOFARc6));
					array43[*(&JoinPatch.4lGlIiHlEo)] = (uint)(*(&JoinPatch.aI9QCnc1dV));
					array43[*(&JoinPatch.11ZqOIseGe)] = (uint)(*(&JoinPatch.tQwi4ONiIi) + *(&JoinPatch.oZw70laqek));
					array43[*(&JoinPatch.mJyGEDMZXA)] = (uint)(*(&JoinPatch.zmek4KVaVy));
					uint num110 = (num ^ (uint)(*(&JoinPatch.Z4s4qbFczm) + *(&JoinPatch.rCAf1kcqe1))) + array43[*(&JoinPatch.CyLIsC5MCq)];
					uint num111 = num110 * array43[*(&JoinPatch.Q9UpLsb3am) + *(&JoinPatch.8tkuSxl8sU)] | (uint)(*(&JoinPatch.sp6ewltkLn));
					num2 = (num111 + (uint)(*(&JoinPatch.g3ZIVrrVUI)) ^ (uint)(*(&JoinPatch.JiP12SOaz5)));
					continue;
				}
				case 70U:
				{
					int[] array3;
					array3[0] = 2010600231;
					array3[1] = 2010600062;
					uint num112 = num | (uint)(*(&JoinPatch.fClKpU6lGs));
					uint num113 = num112 * (uint)(*(&JoinPatch.Y8IA7nCm7k));
					num2 = ((num113 | (uint)(*(&JoinPatch.DrFCwOsly5))) * (uint)(*(&JoinPatch.48qjrdaMIv)) ^ (uint)(*(&JoinPatch.b93yqBMFNg) + *(&JoinPatch.8MtGmy7jYb)));
					continue;
				}
				case 71U:
				{
					uint[] array44 = new uint[*(&JoinPatch.YGKf1XWWLC) + *(&JoinPatch.RlrUx0FItM)];
					array44[*(&JoinPatch.3GiNTJztyg)] = (uint)(*(&JoinPatch.l8tDpI9VrR));
					array44[*(&JoinPatch.TiBbBKQsjk)] = (uint)(*(&JoinPatch.nRj2fRh6Lr));
					array44[*(&JoinPatch.inhobT1oop)] = (uint)(*(&JoinPatch.1ubc2UFHLI));
					array44[*(&JoinPatch.3GKO2TY0hX)] = (uint)(*(&JoinPatch.kCKAtqBXAs));
					array44[*(&JoinPatch.TlD3s30HAL)] = (uint)(*(&JoinPatch.MavDxbcTvH));
					uint num114 = ((num | array44[*(&JoinPatch.4BHQFyjbsL)]) + array44[*(&JoinPatch.TsHdzSDRf8)]) * array44[*(&JoinPatch.dQ0WLKRGMR)] - (uint)(*(&JoinPatch.Osl2xRewx4));
					num2 = (num114 ^ (uint)(*(&JoinPatch.TZYy1dTROf)) ^ (uint)(*(&JoinPatch.XLxwonKuF4)));
					continue;
				}
				case 72U:
				{
					int num3;
					int num9 = num3 ^ 888681254;
					uint[] array45 = new uint[*(&JoinPatch.y7VqJvS04N)];
					array45[*(&JoinPatch.5xzkXWMqBN)] = (uint)(*(&JoinPatch.DeT6bM8suk) + *(&JoinPatch.et4rtjm1yO));
					array45[*(&JoinPatch.BLBv7QRJxc)] = (uint)(*(&JoinPatch.gpcirUoYO7));
					array45[*(&JoinPatch.wjFUtM2H1x)] = (uint)(*(&JoinPatch.uU2xL1ch9K));
					array45[*(&JoinPatch.5z4SDzQWAZ) + *(&JoinPatch.5On0bbFrCv)] = (uint)(*(&JoinPatch.YJS9rLxpWz));
					uint num115 = (num | array45[*(&JoinPatch.1GZDB7oxQ4)]) * array45[*(&JoinPatch.5gHc2grBVt)] + (uint)(*(&JoinPatch.vveNwwh4k2));
					num2 = ((num115 | (uint)(*(&JoinPatch.Bl9Lhyyjze))) ^ (uint)(*(&JoinPatch.wSaIz1BzHL) + *(&JoinPatch.dwTnDFmLRP)));
					continue;
				}
				case 73U:
				{
					int num4;
					int num3;
					int[] array23;
					int num16 = array23[num3 + 6 - num4] ^ -2;
					uint num116 = num + (uint)(*(&JoinPatch.b6ds8lDz3j) + *(&JoinPatch.90swGFUbYl));
					num2 = ((num116 + (uint)(*(&JoinPatch.FQojLJZFle)) ^ (uint)(*(&JoinPatch.XSuQMjZrJu) + *(&JoinPatch.o2cvJSzdux))) - (uint)(*(&JoinPatch.8wBOzLS3gz)) ^ (uint)(*(&JoinPatch.M7NZMqGbkg) + *(&JoinPatch.pmRo6Nx3a3)));
					continue;
				}
				case 74U:
				{
					int[] array6 = new int[10];
					uint[] array46 = new uint[*(&JoinPatch.8lvOWvpFz8)];
					array46[*(&JoinPatch.bgo2iCcwMq)] = (uint)(*(&JoinPatch.IvCxXizAEX));
					array46[*(&JoinPatch.IdIq4E44k9)] = (uint)(*(&JoinPatch.IYpzz6k2Vu) + *(&JoinPatch.5vcTVMi80x));
					array46[*(&JoinPatch.5oAbz8X77e)] = (uint)(*(&JoinPatch.IhMNiuGN8a));
					array46[*(&JoinPatch.87oUcXBzVs) + *(&JoinPatch.g5DxDdXN91)] = (uint)(*(&JoinPatch.in51lXiOuk));
					array46[*(&JoinPatch.GUAaz7Ap9c) + *(&JoinPatch.6imO8NeYJF)] = (uint)(*(&JoinPatch.X2OG1UCwtE));
					uint num117 = (num | array46[*(&JoinPatch.yxEumL5n7G)]) + array46[*(&JoinPatch.crOg4ABq3Y)];
					num2 = ((num117 - (uint)(*(&JoinPatch.3JFoNNF3ie)) ^ (uint)(*(&JoinPatch.5N64oJe1mw))) * array46[*(&JoinPatch.S0aDnposL1)] ^ (uint)(*(&JoinPatch.TV3VLorZhY)));
					continue;
				}
				case 75U:
				{
					uint num118 = (num & (uint)(*(&JoinPatch.shvI130Y4s) + *(&JoinPatch.J1TLvmyO4e))) | (uint)(*(&JoinPatch.pdoDhZKUe1));
					num2 = (num118 * (uint)(*(&JoinPatch.bxeYimaOPF)) * (uint)(*(&JoinPatch.Oe4eeRGxwJ)) ^ (uint)(*(&JoinPatch.OnkiqO2slc)));
					continue;
				}
				case 76U:
				{
					bool flag;
					num2 = ((flag ? 848891998U : 664234350U) ^ num * 509102639U);
					continue;
				}
				case 77U:
				{
					int num4;
					num2 = (((num4 > num4) ? 3326252825U : 3085672614U) ^ num * 195987943U);
					continue;
				}
				case 78U:
					num2 = 1675626465U;
					continue;
				case 79U:
				{
					int num9;
					num9 %= 902;
					uint[] array47 = new uint[*(&JoinPatch.lZkH0pJEGC) + *(&JoinPatch.jhDwft5SQ1)];
					array47[*(&JoinPatch.emqqH58uYV)] = (uint)(*(&JoinPatch.YlezJz9521) + *(&JoinPatch.uill5SydiL));
					array47[*(&JoinPatch.3yPYY8t3A4)] = (uint)(*(&JoinPatch.rZqvn8DOmp));
					array47[*(&JoinPatch.uAaYG6AFvy)] = (uint)(*(&JoinPatch.HeMMcjWGaL));
					array47[*(&JoinPatch.FF47KV1077)] = (uint)(*(&JoinPatch.Pk02b3Y0Sc) + *(&JoinPatch.7oILxMNeSD));
					array47[*(&JoinPatch.m6xbkoFcNu) + *(&JoinPatch.EKHyjgoTui)] = (uint)(*(&JoinPatch.Lfy8Na6tK8));
					array47[*(&JoinPatch.IXi3USxYSx)] = (uint)(*(&JoinPatch.y5nhXxhUmQ));
					uint num119 = num ^ array47[*(&JoinPatch.i3tt1GIyOJ)];
					num2 = (((num119 ^ array47[*(&JoinPatch.rWSOmqmNdQ)] ^ (uint)(*(&JoinPatch.tPB7uQ1QkZ)) ^ array47[*(&JoinPatch.3mG3aOnyBO)] ^ (uint)(*(&JoinPatch.J8KIFbnY4q))) | (uint)(*(&JoinPatch.LT0WgS2w9l))) ^ (uint)(*(&JoinPatch.O1NyQFPYyX)));
					continue;
				}
				case 80U:
				{
					int num3;
					int num9;
					int num10 = num9 + num3;
					uint num120 = num - (uint)(*(&JoinPatch.EunvRB9iHa));
					uint num121 = num120 ^ (uint)(*(&JoinPatch.am24slMPwy));
					num2 = (((num121 ^ (uint)(*(&JoinPatch.KP7HJEYy8N))) | (uint)(*(&JoinPatch.uL6ZRHTLgD))) ^ (uint)(*(&JoinPatch.rNrfxnO3zy) + *(&JoinPatch.SUG4VyxglN)) ^ (uint)(*(&JoinPatch.mKk3qPpcnl)) ^ (uint)(*(&JoinPatch.RAttH6ibTf)));
					continue;
				}
				case 81U:
				{
					int num3;
					int num10;
					int num16 = *(ref num10 + (IntPtr)num3);
					uint[] array48 = new uint[*(&JoinPatch.2UkQW0HovX) + *(&JoinPatch.jvhhgNQ1Jx)];
					array48[*(&JoinPatch.a1igFj8i7m)] = (uint)(*(&JoinPatch.8Y0h2kMOWF));
					array48[*(&JoinPatch.agWA2GLdDY)] = (uint)(*(&JoinPatch.3jw7sAvELw));
					array48[*(&JoinPatch.2iqIYL4Ap5)] = (uint)(*(&JoinPatch.BBfEX4fin8));
					uint num122 = num * array48[*(&JoinPatch.YeejtZl3z1)];
					num2 = (num122 + (uint)(*(&JoinPatch.zIDjN1zNmr)) ^ array48[*(&JoinPatch.MLyIX1Dsky)] ^ (uint)(*(&JoinPatch.eNaNYXDHY9)));
					continue;
				}
				case 82U:
				{
					int[] array3;
					array3[11] = 823736489;
					uint num123 = num + (uint)(*(&JoinPatch.pVOXH6Bbvs));
					uint num124 = num123 + (uint)(*(&JoinPatch.lsxUCnsMtV));
					uint num125 = num124 * (uint)(*(&JoinPatch.vHfDEB2hUZ));
					num2 = (num125 + (uint)(*(&JoinPatch.M1mVlnSTKz)) ^ (uint)(*(&JoinPatch.3UesHLURvh)));
					continue;
				}
				case 83U:
				{
					int num4;
					int num16;
					int[] array23;
					array23[num16 + 8 - num16] = (num4 | 5);
					num2 = 810639964U;
					continue;
				}
				case 84U:
				{
					int num4 = ~num4;
					uint num126 = num + (uint)(*(&JoinPatch.L5xfOPO0QX) + *(&JoinPatch.Nd5GBTTStw));
					uint num127 = num126 + (uint)(*(&JoinPatch.VEsM0YTsKP));
					uint num128 = num127 + (uint)(*(&JoinPatch.RGSOkxWWLy) + *(&JoinPatch.2yFnI2EUmh));
					uint num129 = num128 ^ (uint)(*(&JoinPatch.jmYCcHNlo0) + *(&JoinPatch.6fpAFHKqfO));
					uint num130 = num129 - (uint)(*(&JoinPatch.76H44h8ED7));
					num2 = (num130 - (uint)(*(&JoinPatch.T9GnporQwd)) ^ (uint)(*(&JoinPatch.kvrV2XIEhB)));
					continue;
				}
				case 85U:
				{
					int[] array3;
					int[] array49 = array3;
					int num131 = 4;
					int num7 = (((array3[4] & -440) ^ 425) & -255) | -37;
					array49[num131] = (array3[4] ^ num7 ^ (2010600231 ^ num7));
					int[] array50 = array3;
					int num132 = 5;
					num7 = (array3[5] + 421) % 81 * 467;
					array50[num132] = (array3[5] ^ num7 ^ (2010600231 ^ num7));
					uint[] array51 = new uint[*(&JoinPatch.pqbMntOVeX)];
					array51[*(&JoinPatch.qCOBhqQW8b)] = (uint)(*(&JoinPatch.lxsDlVHV1k));
					array51[*(&JoinPatch.qX85zIEpIp)] = (uint)(*(&JoinPatch.cIeYE8vEsq) + *(&JoinPatch.3MFzr28XkS));
					array51[*(&JoinPatch.m2d3qTDTLY) + *(&JoinPatch.lkOS9cST9n)] = (uint)(*(&JoinPatch.kCmLreRJN7));
					array51[*(&JoinPatch.KrF0Djokrv)] = (uint)(*(&JoinPatch.4b3UES7x0O));
					array51[*(&JoinPatch.joY6sjQSMM)] = (uint)(*(&JoinPatch.B3FNO4fYOZ) + *(&JoinPatch.ysmOsIISHY));
					array51[*(&JoinPatch.geT9XgTIHd)] = (uint)(*(&JoinPatch.TWYftBWpFJ));
					uint num133 = num | (uint)(*(&JoinPatch.xjiaa1CJOk));
					uint num134 = num133 * (uint)(*(&JoinPatch.a7KyqhkGzr) + *(&JoinPatch.lXQuFbTHfr));
					uint num135 = (num134 ^ (uint)(*(&JoinPatch.vdM7l652jg))) * (uint)(*(&JoinPatch.eJ4hDWLkyL)) | (uint)(*(&JoinPatch.bPzXiaTxV8));
					num2 = ((num135 & array51[*(&JoinPatch.h4ogy7uNMt) + *(&JoinPatch.mrhTNcdsrs)]) ^ (uint)(*(&JoinPatch.QtSTQgnyZL) + *(&JoinPatch.nHhk8jeXtF)));
					continue;
				}
				case 86U:
					num2 = 344995822U;
					continue;
				case 87U:
				{
					int[] array3;
					array3[12] = 317357337;
					uint num136 = ((num * (uint)(*(&JoinPatch.n4g11h0LTF)) ^ (uint)(*(&JoinPatch.DeGVftGbtY))) | (uint)(*(&JoinPatch.VZC4banx53))) & (uint)(*(&JoinPatch.rlvxwRVueD)) & (uint)(*(&JoinPatch.xG9EvZNIMX));
					num2 = (num136 * (uint)(*(&JoinPatch.E3hWLN2maa) + *(&JoinPatch.4DPZYbsTiN)) ^ (uint)(*(&JoinPatch.YV6plOZ7JC)));
					continue;
				}
				case 88U:
				{
					int[] array3;
					array3[13] = 187298466;
					uint num137 = (num | (uint)(*(&JoinPatch.MekiyxEZli) + *(&JoinPatch.ZsUEJu0kqT))) & (uint)(*(&JoinPatch.r4k98s61v6));
					uint num138 = (num137 | (uint)(*(&JoinPatch.x4dYNZcrlk))) + (uint)(*(&JoinPatch.XTrAypB2g1));
					num2 = ((num138 | (uint)(*(&JoinPatch.YzRzVS4kjF) + *(&JoinPatch.1MnpueP50t))) ^ (uint)(*(&JoinPatch.RJ9F5XMkLT) + *(&JoinPatch.rEV3i8nnD5)) ^ (uint)(*(&JoinPatch.e1HftLpCPT)));
					continue;
				}
				case 89U:
				{
					int num4;
					*(ref JoinPatch.5bfRou6prb + (IntPtr)num4) = num4;
					uint[] array52 = new uint[*(&JoinPatch.NO4ennEn7i)];
					array52[*(&JoinPatch.25K0piztsq)] = (uint)(*(&JoinPatch.fy9FE2YR7y));
					array52[*(&JoinPatch.gTiIyZHzVn)] = (uint)(*(&JoinPatch.jRbbmwYOCt));
					array52[*(&JoinPatch.4W6o6YPyau)] = (uint)(*(&JoinPatch.PxpJCiXCCP));
					array52[*(&JoinPatch.aAXEHNXhdR)] = (uint)(*(&JoinPatch.dKPO4JX3LZ));
					array52[*(&JoinPatch.JSYkYwlSZD)] = (uint)(*(&JoinPatch.YWLwS481hs));
					array52[*(&JoinPatch.BsVIRFibP2)] = (uint)(*(&JoinPatch.Kd0nGHlwqU));
					uint num139 = num + (uint)(*(&JoinPatch.mFIZ3H8c5A)) + array52[*(&JoinPatch.KgVdYb7PTS)];
					uint num140 = (num139 ^ (uint)(*(&JoinPatch.OKCg25fiqL))) - array52[*(&JoinPatch.SMKMG6j5PJ) + *(&JoinPatch.GFgPsoHXPo)];
					num2 = ((num140 * array52[*(&JoinPatch.KVdXGbClh8)] | array52[*(&JoinPatch.mawtr8VJWb)]) ^ (uint)(*(&JoinPatch.2BAKMIoxxN)));
					continue;
				}
				case 90U:
				{
					int[] array3;
					int[] array53 = array3;
					int num141 = 12;
					int num142 = (array3[12] ^ 297) % 8 - 110;
					int num7 = ((305 == 0) ? (num142 - 70) : (num142 + 305)) % 44;
					array53[num141] = (array3[12] ^ num7 ^ (2010600231 ^ num7));
					num2 = 1537005514U;
					continue;
				}
				case 91U:
				{
					int num16;
					num2 = (((num16 > num16) ? 1874584968U : 1305965767U) ^ num * 1695417026U);
					continue;
				}
				case 93U:
				{
					int num9;
					int num16 = num9 & 551334186;
					num2 = 505351443U;
					continue;
				}
				case 94U:
				{
					int num4;
					int num9 = num4 << 4;
					uint[] array54 = new uint[*(&JoinPatch.ka058ivIeg)];
					array54[*(&JoinPatch.0fpeAjii74)] = (uint)(*(&JoinPatch.xTLxRyVh7A));
					array54[*(&JoinPatch.9EuKcZp6k7)] = (uint)(*(&JoinPatch.iUQw81tXVW));
					array54[*(&JoinPatch.uXahVQOCoK)] = (uint)(*(&JoinPatch.NOKdgvufBl) + *(&JoinPatch.3l8AWdDYzZ));
					uint num143 = num & array54[*(&JoinPatch.F7LkPlnNzL)];
					num2 = ((num143 ^ array54[*(&JoinPatch.KnRZuUJwPM)]) * array54[*(&JoinPatch.HNVudJZaK1)] ^ (uint)(*(&JoinPatch.N0NOFPCkN5)));
					continue;
				}
				case 95U:
				{
					int[] array3;
					int[] array55 = array3;
					int num144 = 6;
					int num7 = ~(-(array3[6] << 3)) + 163;
					array55[num144] = (array3[6] ^ num7 ^ (2010600231 ^ num7));
					int[] array56 = array3;
					int num145 = 7;
					int num146 = array3[7];
					int num147 = ((-310 == 0) ? (num146 - 91) : (num146 + -310)) - 194;
					int num148 = (((-95 == 0) ? (num147 - 97) : (num147 + -95)) & 59) % 80;
					num7 = ((462 == 0) ? (num148 - 27) : (num148 + 462));
					array56[num145] = (array3[7] ^ num7 ^ (2010600231 ^ num7));
					num2 = 62698916U;
					continue;
				}
				case 96U:
				{
					int num9;
					int num10 = num9 + 257;
					uint[] array57 = new uint[*(&JoinPatch.DyMPGuE22S) + *(&JoinPatch.mdW3NkvuWH)];
					array57[*(&JoinPatch.W1yZ9SvV29)] = (uint)(*(&JoinPatch.LOkhnXGlPw) + *(&JoinPatch.O93q9vfTkp));
					array57[*(&JoinPatch.TfBqBL9wQy)] = (uint)(*(&JoinPatch.9tA2GX2yQ0));
					array57[*(&JoinPatch.dKek3W8IaN)] = (uint)(*(&JoinPatch.wbuMqqN3fc));
					array57[*(&JoinPatch.YUVbwf9Bjl) + *(&JoinPatch.2rDuLJBaxo)] = (uint)(*(&JoinPatch.N0VCCh8xMa));
					array57[*(&JoinPatch.K9SxbJzDyY)] = (uint)(*(&JoinPatch.X7izVFXABh) + *(&JoinPatch.pwG1Ph9SYO));
					array57[*(&JoinPatch.gLzIa3YPSC)] = (uint)(*(&JoinPatch.U7mYRQRfr7));
					uint num149 = (num | array57[*(&JoinPatch.K8wpvY2bi4)]) * array57[*(&JoinPatch.Jgoj1LIaZb)] ^ array57[*(&JoinPatch.qIr8MrJsk9)];
					uint num150 = num149 * (uint)(*(&JoinPatch.PdlbEiZJXC));
					uint num151 = num150 & array57[*(&JoinPatch.B6rY3xTDhF) + *(&JoinPatch.I1GPQBRycD)];
					num2 = (num151 ^ (uint)(*(&JoinPatch.OK0ioq4MeT)) ^ (uint)(*(&JoinPatch.w8CWataSFY)));
					continue;
				}
				case 97U:
				{
					int num9;
					JoinPatch.5bfRou6prb = num9;
					int num10;
					int num3 = -num10;
					num2 = 686352498U;
					continue;
				}
				case 98U:
				{
					int num4 = JoinPatch.5bfRou6prb;
					num2 = 1178490755U;
					continue;
				}
				case 99U:
				{
					int num10;
					num2 = (((num10 > num10) ? 1363600767U : 972516995U) ^ num * 1257233510U);
					continue;
				}
				case 100U:
				{
					int[] array3;
					array3[2] = 590002034;
					num2 = (((num - (uint)(*(&JoinPatch.mUxKxZSjSd) + *(&JoinPatch.NzdLJEyQWu)) ^ (uint)(*(&JoinPatch.BmXS6rOj63))) | (uint)(*(&JoinPatch.f0yrIGMsAQ))) - (uint)(*(&JoinPatch.snxtSJth7i)) ^ (uint)(*(&JoinPatch.9qNnZ97eOG)));
					continue;
				}
				case 101U:
					num2 = 2042820090U;
					continue;
				}
				break;
			}
			return;
			IL_24:
			num2 = 825462744U;
			goto IL_29;
			IL_15E6:
			num2 = 120272729U;
			goto IL_29;
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x00651898 File Offset: 0x0064FA98
		public unsafe JoinPatch()
		{
			if ((*(&JoinPatch.DhZyIJWVB8) ^ *(&JoinPatch.DhZyIJWVB8)) != 0)
			{
				int[] array = new int[10];
				int num;
				int num2;
				int num3;
				int num4;
				int num5;
				if (num > num)
				{
					if (num2 > num2)
					{
						num3 = num2 >> 5;
						num = 400016528;
						num2 = (int)((byte)num3);
						num2 = num;
						num4 = JoinPatch.5bfRou6prb;
						num5 = num4 << 5;
						num4 = num2;
						num2 = array[num3 + 7 - num5] + -10;
						num = (num2 ^ 767588270);
						num5 = (num ^ num4);
					}
					num2 = num * num4;
					num2 = num4 + num3;
					num2 >>= 4;
					*(ref num2 + (IntPtr)num4) = num4;
					num3 = num4 * num3;
					*(ref num3 + (IntPtr)num4) = num4;
					if (num5 > num5)
					{
						num4 -= num3;
						num2 = (num & 1533801542);
						num3 = num - num4;
						num3 = num5 % 841;
					}
				}
				num5 = (num3 | 966068181);
				num2 = (num4 ^ num3);
				num = array[num2 + 9 - num] + 7;
				num = num4 + 497;
				num4 = (num2 | num4);
				if (num > num)
				{
					num2 = num4;
					num3 = JoinPatch.5bfRou6prb;
					if (num > num)
					{
						num5 -= num4;
						num2 = num + 182;
						num2 = (num ^ 87176507);
						num3 = (num ^ num4);
						num3 = (array[num5 + 5 - num2] ^ -8);
						JoinPatch.5bfRou6prb = num5;
						*(ref JoinPatch.5bfRou6prb + (IntPtr)num3) = num3;
						num5 = num4 / num3;
					}
					if (num2 > num2)
					{
						num2 = -num5;
						*(ref num3 + (IntPtr)num4) = num4;
						num3 = num5 / num4;
						num2 = array[num4 + 6 - num] + -4;
						num2 = num5 - num4;
					}
					num5 = num3 - 434;
					num4 |= 1762392588;
					num5 = (num4 ^ 49045966);
					*(ref JoinPatch.5bfRou6prb + (IntPtr)num3) = num3;
					num = -num2;
				}
				num5 += 354;
				num = num5 - num4;
				num5 = JoinPatch.5bfRou6prb;
				num5 = -num3;
				if (num5 > num5)
				{
					array[num + 9 - num] = (num4 | 0);
					num5 = num2 >> 1;
					num2 = JoinPatch.5bfRou6prb;
				}
				*(ref JoinPatch.5bfRou6prb + (IntPtr)num) = num;
				num4 = *(ref JoinPatch.5bfRou6prb + (IntPtr)num4);
				num5 = (num4 ^ num3);
				num5 = num4 << 3;
				num3 = (num4 ^ num3);
				num5 = JoinPatch.5bfRou6prb;
				num3 = ~num5;
				num = *(ref JoinPatch.5bfRou6prb + (IntPtr)num5);
			}
			base..ctor();
		}

		// Token: 0x0404F928 RID: 325928
		private static Player a;

		// Token: 0x0404F929 RID: 325929 RVA: 0x0014A1D0 File Offset: 0x001483D0
		static int 6YYSXgncU2;

		// Token: 0x0404F92A RID: 325930 RVA: 0x0014A1D8 File Offset: 0x001483D8
		static int 5bfRou6prb;

		// Token: 0x0404F92B RID: 325931 RVA: 0x0014A1E0 File Offset: 0x001483E0
		static int DhZyIJWVB8;

		// Token: 0x0404F92C RID: 325932 RVA: 0x0014A1E8 File Offset: 0x001483E8
		static readonly int ppI6uxdexR;

		// Token: 0x0404F92D RID: 325933 RVA: 0x0007CCD8 File Offset: 0x0007AED8
		static readonly int dOu4wXhoAe;

		// Token: 0x0404F92E RID: 325934 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 8lvOWvpFz8;

		// Token: 0x0404F92F RID: 325935 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int bgo2iCcwMq;

		// Token: 0x0404F930 RID: 325936 RVA: 0x0014A1F0 File Offset: 0x001483F0
		static readonly int IvCxXizAEX;

		// Token: 0x0404F931 RID: 325937 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int IdIq4E44k9;

		// Token: 0x0404F932 RID: 325938 RVA: 0x0014A1F8 File Offset: 0x001483F8
		static readonly int IYpzz6k2Vu;

		// Token: 0x0404F933 RID: 325939 RVA: 0x0014A200 File Offset: 0x00148400
		static readonly int 5vcTVMi80x;

		// Token: 0x0404F934 RID: 325940 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 5oAbz8X77e;

		// Token: 0x0404F935 RID: 325941 RVA: 0x0014A208 File Offset: 0x00148408
		static readonly int IhMNiuGN8a;

		// Token: 0x0404F936 RID: 325942 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 87oUcXBzVs;

		// Token: 0x0404F937 RID: 325943 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int g5DxDdXN91;

		// Token: 0x0404F938 RID: 325944 RVA: 0x0014A210 File Offset: 0x00148410
		static readonly int in51lXiOuk;

		// Token: 0x0404F939 RID: 325945 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int GUAaz7Ap9c;

		// Token: 0x0404F93A RID: 325946 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6imO8NeYJF;

		// Token: 0x0404F93B RID: 325947 RVA: 0x0014A218 File Offset: 0x00148418
		static readonly int X2OG1UCwtE;

		// Token: 0x0404F93C RID: 325948 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int yxEumL5n7G;

		// Token: 0x0404F93D RID: 325949 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int crOg4ABq3Y;

		// Token: 0x0404F93E RID: 325950 RVA: 0x0014A208 File Offset: 0x00148408
		static readonly int 3JFoNNF3ie;

		// Token: 0x0404F93F RID: 325951 RVA: 0x0014A210 File Offset: 0x00148410
		static readonly int 5N64oJe1mw;

		// Token: 0x0404F940 RID: 325952 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int S0aDnposL1;

		// Token: 0x0404F941 RID: 325953 RVA: 0x0014A220 File Offset: 0x00148420
		static readonly int TV3VLorZhY;

		// Token: 0x0404F942 RID: 325954 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int GBEdKOvT2v;

		// Token: 0x0404F943 RID: 325955 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int fJDGGCsBBh;

		// Token: 0x0404F944 RID: 325956 RVA: 0x0014A228 File Offset: 0x00148428
		static readonly int jXrqKjTlt9;

		// Token: 0x0404F945 RID: 325957 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bFTOpQv72Y;

		// Token: 0x0404F946 RID: 325958 RVA: 0x0014A230 File Offset: 0x00148430
		static readonly int 4UzaVJSwOI;

		// Token: 0x0404F947 RID: 325959 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 5pX9ztUYSl;

		// Token: 0x0404F948 RID: 325960 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4Kj3Uazybz;

		// Token: 0x0404F949 RID: 325961 RVA: 0x0014A238 File Offset: 0x00148438
		static readonly int RvJmnOhRUA;

		// Token: 0x0404F94A RID: 325962 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int QhWlDvrUZ6;

		// Token: 0x0404F94B RID: 325963 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6XoRduu6F5;

		// Token: 0x0404F94C RID: 325964 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int UdVZ1KgvVk;

		// Token: 0x0404F94D RID: 325965 RVA: 0x0014A240 File Offset: 0x00148440
		static readonly int LCDRUXx8zj;

		// Token: 0x0404F94E RID: 325966 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int tfZe33G2J3;

		// Token: 0x0404F94F RID: 325967 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int dlLZqxL7u3;

		// Token: 0x0404F950 RID: 325968 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int O68yv3UX6F;

		// Token: 0x0404F951 RID: 325969 RVA: 0x0014A248 File Offset: 0x00148448
		static readonly int 6wHgLyE0f7;

		// Token: 0x0404F952 RID: 325970 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int EnlcHk0nkh;

		// Token: 0x0404F953 RID: 325971 RVA: 0x0014A250 File Offset: 0x00148450
		static readonly int M0O6Uxgkt9;

		// Token: 0x0404F954 RID: 325972 RVA: 0x0014A258 File Offset: 0x00148458
		static readonly int jt5D7rdpN1;

		// Token: 0x0404F955 RID: 325973 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int tUbwylUgrK;

		// Token: 0x0404F956 RID: 325974 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int DqwZ3GhKLY;

		// Token: 0x0404F957 RID: 325975 RVA: 0x0014A260 File Offset: 0x00148460
		static readonly int SdHgXVsifa;

		// Token: 0x0404F958 RID: 325976 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int GLZsy1YbHt;

		// Token: 0x0404F959 RID: 325977 RVA: 0x0014A268 File Offset: 0x00148468
		static readonly int cA3j626gK0;

		// Token: 0x0404F95A RID: 325978 RVA: 0x0014A270 File Offset: 0x00148470
		static readonly int JTdyjPN5Zd;

		// Token: 0x0404F95B RID: 325979 RVA: 0x0014A278 File Offset: 0x00148478
		static readonly int 3wBRD2QDlB;

		// Token: 0x0404F95C RID: 325980 RVA: 0x0014A280 File Offset: 0x00148480
		static readonly int rFCc5Rkije;

		// Token: 0x0404F95D RID: 325981 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YLXoQwrlJi;

		// Token: 0x0404F95E RID: 325982 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int odCn0q8mfE;

		// Token: 0x0404F95F RID: 325983 RVA: 0x0014A288 File Offset: 0x00148488
		static readonly int m25IJDQB2R;

		// Token: 0x0404F960 RID: 325984 RVA: 0x0014A290 File Offset: 0x00148490
		static readonly int ppV4FrYXAQ;

		// Token: 0x0404F961 RID: 325985 RVA: 0x0014A298 File Offset: 0x00148498
		static readonly int Kp4CWNDYmP;

		// Token: 0x0404F962 RID: 325986 RVA: 0x0014A2A0 File Offset: 0x001484A0
		static readonly int S8Cf2fPOeN;

		// Token: 0x0404F963 RID: 325987 RVA: 0x0014A2A8 File Offset: 0x001484A8
		static readonly int gqs139IHiI;

		// Token: 0x0404F964 RID: 325988 RVA: 0x0014A2B0 File Offset: 0x001484B0
		static readonly int SllO3683w5;

		// Token: 0x0404F965 RID: 325989 RVA: 0x0014A2B8 File Offset: 0x001484B8
		static readonly int A2Yn8rmzBj;

		// Token: 0x0404F966 RID: 325990 RVA: 0x0014A2C0 File Offset: 0x001484C0
		static readonly int bJ2xue7DIX;

		// Token: 0x0404F967 RID: 325991 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int F50d6rWyl6;

		// Token: 0x0404F968 RID: 325992 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int hWcjMoRE2M;

		// Token: 0x0404F969 RID: 325993 RVA: 0x0014A2C8 File Offset: 0x001484C8
		static readonly int XSG8rJtydY;

		// Token: 0x0404F96A RID: 325994 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 84uYzEB5rR;

		// Token: 0x0404F96B RID: 325995 RVA: 0x0014A2D0 File Offset: 0x001484D0
		static readonly int UxNFCEqTkG;

		// Token: 0x0404F96C RID: 325996 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int N2L69xz1wx;

		// Token: 0x0404F96D RID: 325997 RVA: 0x0014A2D8 File Offset: 0x001484D8
		static readonly int 7iVM7mmDtH;

		// Token: 0x0404F96E RID: 325998 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int mVXk1kEA6m;

		// Token: 0x0404F96F RID: 325999 RVA: 0x0014A2E0 File Offset: 0x001484E0
		static readonly int caNWLFtxZC;

		// Token: 0x0404F970 RID: 326000 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int PKI3TwcAHa;

		// Token: 0x0404F971 RID: 326001 RVA: 0x0014A2E8 File Offset: 0x001484E8
		static readonly int bmkce1fkEZ;

		// Token: 0x0404F972 RID: 326002 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sy5KUhU8B1;

		// Token: 0x0404F973 RID: 326003 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2zoq2cNdQF;

		// Token: 0x0404F974 RID: 326004 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int HD3fK0zu2T;

		// Token: 0x0404F975 RID: 326005 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kJs9UaO8jw;

		// Token: 0x0404F976 RID: 326006 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int be9Phm83kB;

		// Token: 0x0404F977 RID: 326007 RVA: 0x0014A2E8 File Offset: 0x001484E8
		static readonly int oBT9Ro5Z9e;

		// Token: 0x0404F978 RID: 326008 RVA: 0x0014A2F0 File Offset: 0x001484F0
		static readonly int rjFrRtGoVb;

		// Token: 0x0404F979 RID: 326009 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int NO4ennEn7i;

		// Token: 0x0404F97A RID: 326010 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 25K0piztsq;

		// Token: 0x0404F97B RID: 326011 RVA: 0x0014A2F8 File Offset: 0x001484F8
		static readonly int fy9FE2YR7y;

		// Token: 0x0404F97C RID: 326012 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gTiIyZHzVn;

		// Token: 0x0404F97D RID: 326013 RVA: 0x0014A300 File Offset: 0x00148500
		static readonly int jRbbmwYOCt;

		// Token: 0x0404F97E RID: 326014 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 4W6o6YPyau;

		// Token: 0x0404F97F RID: 326015 RVA: 0x0014A308 File Offset: 0x00148508
		static readonly int PxpJCiXCCP;

		// Token: 0x0404F980 RID: 326016 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int aAXEHNXhdR;

		// Token: 0x0404F981 RID: 326017 RVA: 0x0014A310 File Offset: 0x00148510
		static readonly int dKPO4JX3LZ;

		// Token: 0x0404F982 RID: 326018 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int JSYkYwlSZD;

		// Token: 0x0404F983 RID: 326019 RVA: 0x0014A318 File Offset: 0x00148518
		static readonly int YWLwS481hs;

		// Token: 0x0404F984 RID: 326020 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int BsVIRFibP2;

		// Token: 0x0404F985 RID: 326021 RVA: 0x0014A320 File Offset: 0x00148520
		static readonly int Kd0nGHlwqU;

		// Token: 0x0404F986 RID: 326022 RVA: 0x0014A2F8 File Offset: 0x001484F8
		static readonly int mFIZ3H8c5A;

		// Token: 0x0404F987 RID: 326023 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KgVdYb7PTS;

		// Token: 0x0404F988 RID: 326024 RVA: 0x0014A308 File Offset: 0x00148508
		static readonly int OKCg25fiqL;

		// Token: 0x0404F989 RID: 326025 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int SMKMG6j5PJ;

		// Token: 0x0404F98A RID: 326026 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int GFgPsoHXPo;

		// Token: 0x0404F98B RID: 326027 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int KVdXGbClh8;

		// Token: 0x0404F98C RID: 326028 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int mawtr8VJWb;

		// Token: 0x0404F98D RID: 326029 RVA: 0x0014A328 File Offset: 0x00148528
		static readonly int 2BAKMIoxxN;

		// Token: 0x0404F98E RID: 326030 RVA: 0x0014A330 File Offset: 0x00148530
		static readonly int xHTBB6swFo;

		// Token: 0x0404F98F RID: 326031 RVA: 0x0014A338 File Offset: 0x00148538
		static readonly int 47YRhqSwhu;

		// Token: 0x0404F990 RID: 326032 RVA: 0x0014A340 File Offset: 0x00148540
		static readonly int S8AxvIVTL7;

		// Token: 0x0404F991 RID: 326033 RVA: 0x0014A348 File Offset: 0x00148548
		static readonly int xOxTKfGusu;

		// Token: 0x0404F992 RID: 326034 RVA: 0x0014A350 File Offset: 0x00148550
		static readonly int PjDsh4nsnf;

		// Token: 0x0404F993 RID: 326035 RVA: 0x0014A358 File Offset: 0x00148558
		static readonly int 02QD5yGfP3;

		// Token: 0x0404F994 RID: 326036 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int lZkH0pJEGC;

		// Token: 0x0404F995 RID: 326037 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jhDwft5SQ1;

		// Token: 0x0404F996 RID: 326038 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int emqqH58uYV;

		// Token: 0x0404F997 RID: 326039 RVA: 0x0014A360 File Offset: 0x00148560
		static readonly int YlezJz9521;

		// Token: 0x0404F998 RID: 326040 RVA: 0x0014A368 File Offset: 0x00148568
		static readonly int uill5SydiL;

		// Token: 0x0404F999 RID: 326041 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 3yPYY8t3A4;

		// Token: 0x0404F99A RID: 326042 RVA: 0x0014A370 File Offset: 0x00148570
		static readonly int rZqvn8DOmp;

		// Token: 0x0404F99B RID: 326043 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int uAaYG6AFvy;

		// Token: 0x0404F99C RID: 326044 RVA: 0x0014A378 File Offset: 0x00148578
		static readonly int HeMMcjWGaL;

		// Token: 0x0404F99D RID: 326045 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int FF47KV1077;

		// Token: 0x0404F99E RID: 326046 RVA: 0x0014A380 File Offset: 0x00148580
		static readonly int Pk02b3Y0Sc;

		// Token: 0x0404F99F RID: 326047 RVA: 0x0014A388 File Offset: 0x00148588
		static readonly int 7oILxMNeSD;

		// Token: 0x0404F9A0 RID: 326048 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int m6xbkoFcNu;

		// Token: 0x0404F9A1 RID: 326049 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int EKHyjgoTui;

		// Token: 0x0404F9A2 RID: 326050 RVA: 0x0014A390 File Offset: 0x00148590
		static readonly int Lfy8Na6tK8;

		// Token: 0x0404F9A3 RID: 326051 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int IXi3USxYSx;

		// Token: 0x0404F9A4 RID: 326052 RVA: 0x0014A398 File Offset: 0x00148598
		static readonly int y5nhXxhUmQ;

		// Token: 0x0404F9A5 RID: 326053 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int i3tt1GIyOJ;

		// Token: 0x0404F9A6 RID: 326054 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int rWSOmqmNdQ;

		// Token: 0x0404F9A7 RID: 326055 RVA: 0x0014A378 File Offset: 0x00148578
		static readonly int tPB7uQ1QkZ;

		// Token: 0x0404F9A8 RID: 326056 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 3mG3aOnyBO;

		// Token: 0x0404F9A9 RID: 326057 RVA: 0x0014A390 File Offset: 0x00148590
		static readonly int J8KIFbnY4q;

		// Token: 0x0404F9AA RID: 326058 RVA: 0x0014A398 File Offset: 0x00148598
		static readonly int LT0WgS2w9l;

		// Token: 0x0404F9AB RID: 326059 RVA: 0x0014A3A0 File Offset: 0x001485A0
		static readonly int O1NyQFPYyX;

		// Token: 0x0404F9AC RID: 326060 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int DyMPGuE22S;

		// Token: 0x0404F9AD RID: 326061 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int mdW3NkvuWH;

		// Token: 0x0404F9AE RID: 326062 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int W1yZ9SvV29;

		// Token: 0x0404F9AF RID: 326063 RVA: 0x0014A3A8 File Offset: 0x001485A8
		static readonly int LOkhnXGlPw;

		// Token: 0x0404F9B0 RID: 326064 RVA: 0x0014A3B0 File Offset: 0x001485B0
		static readonly int O93q9vfTkp;

		// Token: 0x0404F9B1 RID: 326065 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TfBqBL9wQy;

		// Token: 0x0404F9B2 RID: 326066 RVA: 0x0014A3B8 File Offset: 0x001485B8
		static readonly int 9tA2GX2yQ0;

		// Token: 0x0404F9B3 RID: 326067 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int dKek3W8IaN;

		// Token: 0x0404F9B4 RID: 326068 RVA: 0x0014A3C0 File Offset: 0x001485C0
		static readonly int wbuMqqN3fc;

		// Token: 0x0404F9B5 RID: 326069 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int YUVbwf9Bjl;

		// Token: 0x0404F9B6 RID: 326070 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2rDuLJBaxo;

		// Token: 0x0404F9B7 RID: 326071 RVA: 0x0014A3C8 File Offset: 0x001485C8
		static readonly int N0VCCh8xMa;

		// Token: 0x0404F9B8 RID: 326072 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int K9SxbJzDyY;

		// Token: 0x0404F9B9 RID: 326073 RVA: 0x0014A3D0 File Offset: 0x001485D0
		static readonly int X7izVFXABh;

		// Token: 0x0404F9BA RID: 326074 RVA: 0x0014A3D8 File Offset: 0x001485D8
		static readonly int pwG1Ph9SYO;

		// Token: 0x0404F9BB RID: 326075 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int gLzIa3YPSC;

		// Token: 0x0404F9BC RID: 326076 RVA: 0x0014A3E0 File Offset: 0x001485E0
		static readonly int U7mYRQRfr7;

		// Token: 0x0404F9BD RID: 326077 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int K8wpvY2bi4;

		// Token: 0x0404F9BE RID: 326078 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Jgoj1LIaZb;

		// Token: 0x0404F9BF RID: 326079 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int qIr8MrJsk9;

		// Token: 0x0404F9C0 RID: 326080 RVA: 0x0014A3C8 File Offset: 0x001485C8
		static readonly int PdlbEiZJXC;

		// Token: 0x0404F9C1 RID: 326081 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int B6rY3xTDhF;

		// Token: 0x0404F9C2 RID: 326082 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int I1GPQBRycD;

		// Token: 0x0404F9C3 RID: 326083 RVA: 0x0014A3E0 File Offset: 0x001485E0
		static readonly int OK0ioq4MeT;

		// Token: 0x0404F9C4 RID: 326084 RVA: 0x0014A3E8 File Offset: 0x001485E8
		static readonly int w8CWataSFY;

		// Token: 0x0404F9C5 RID: 326085 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int YGKf1XWWLC;

		// Token: 0x0404F9C6 RID: 326086 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int RlrUx0FItM;

		// Token: 0x0404F9C7 RID: 326087 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 3GiNTJztyg;

		// Token: 0x0404F9C8 RID: 326088 RVA: 0x0014A3F0 File Offset: 0x001485F0
		static readonly int l8tDpI9VrR;

		// Token: 0x0404F9C9 RID: 326089 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TiBbBKQsjk;

		// Token: 0x0404F9CA RID: 326090 RVA: 0x0014A3F8 File Offset: 0x001485F8
		static readonly int nRj2fRh6Lr;

		// Token: 0x0404F9CB RID: 326091 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int inhobT1oop;

		// Token: 0x0404F9CC RID: 326092 RVA: 0x0014A400 File Offset: 0x00148600
		static readonly int 1ubc2UFHLI;

		// Token: 0x0404F9CD RID: 326093 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 3GKO2TY0hX;

		// Token: 0x0404F9CE RID: 326094 RVA: 0x0014A408 File Offset: 0x00148608
		static readonly int kCKAtqBXAs;

		// Token: 0x0404F9CF RID: 326095 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int TlD3s30HAL;

		// Token: 0x0404F9D0 RID: 326096 RVA: 0x0014A410 File Offset: 0x00148610
		static readonly int MavDxbcTvH;

		// Token: 0x0404F9D1 RID: 326097 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 4BHQFyjbsL;

		// Token: 0x0404F9D2 RID: 326098 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TsHdzSDRf8;

		// Token: 0x0404F9D3 RID: 326099 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int dQ0WLKRGMR;

		// Token: 0x0404F9D4 RID: 326100 RVA: 0x0014A408 File Offset: 0x00148608
		static readonly int Osl2xRewx4;

		// Token: 0x0404F9D5 RID: 326101 RVA: 0x0014A410 File Offset: 0x00148610
		static readonly int TZYy1dTROf;

		// Token: 0x0404F9D6 RID: 326102 RVA: 0x0014A418 File Offset: 0x00148618
		static readonly int XLxwonKuF4;

		// Token: 0x0404F9D7 RID: 326103 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int hdOa7lGOph;

		// Token: 0x0404F9D8 RID: 326104 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int xQdloE2Ber;

		// Token: 0x0404F9D9 RID: 326105 RVA: 0x0014A420 File Offset: 0x00148620
		static readonly int 192r4D4yNJ;

		// Token: 0x0404F9DA RID: 326106 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Gtr3W0K71Q;

		// Token: 0x0404F9DB RID: 326107 RVA: 0x0014A428 File Offset: 0x00148628
		static readonly int XEmqrHrMHk;

		// Token: 0x0404F9DC RID: 326108 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vJQXDhkhg4;

		// Token: 0x0404F9DD RID: 326109 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int qRAfaEikOy;

		// Token: 0x0404F9DE RID: 326110 RVA: 0x0014A430 File Offset: 0x00148630
		static readonly int 34KNUwXM9w;

		// Token: 0x0404F9DF RID: 326111 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int VsrnY7cUzz;

		// Token: 0x0404F9E0 RID: 326112 RVA: 0x0014A438 File Offset: 0x00148638
		static readonly int Qna7jFDHPn;

		// Token: 0x0404F9E1 RID: 326113 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int jH7Tr19DCQ;

		// Token: 0x0404F9E2 RID: 326114 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KYiuj8kXHd;

		// Token: 0x0404F9E3 RID: 326115 RVA: 0x0014A430 File Offset: 0x00148630
		static readonly int lNuZhPdNnP;

		// Token: 0x0404F9E4 RID: 326116 RVA: 0x0014A438 File Offset: 0x00148638
		static readonly int sP6VNNuX6h;

		// Token: 0x0404F9E5 RID: 326117 RVA: 0x0014A440 File Offset: 0x00148640
		static readonly int 8ZSio1FqYl;

		// Token: 0x0404F9E6 RID: 326118 RVA: 0x0014A448 File Offset: 0x00148648
		static readonly int eqAwCVWivb;

		// Token: 0x0404F9E7 RID: 326119 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int XwZxh4bMhV;

		// Token: 0x0404F9E8 RID: 326120 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int NNajfM5Luq;

		// Token: 0x0404F9E9 RID: 326121 RVA: 0x0014A450 File Offset: 0x00148650
		static readonly int KxyBuCPKT1;

		// Token: 0x0404F9EA RID: 326122 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1MlfJM9eBu;

		// Token: 0x0404F9EB RID: 326123 RVA: 0x0014A458 File Offset: 0x00148658
		static readonly int Z3JCXRQaRz;

		// Token: 0x0404F9EC RID: 326124 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ZKyFQk7XCf;

		// Token: 0x0404F9ED RID: 326125 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int pR2peBl5aT;

		// Token: 0x0404F9EE RID: 326126 RVA: 0x0014A460 File Offset: 0x00148660
		static readonly int MaKAQRovod;

		// Token: 0x0404F9EF RID: 326127 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int vz3dbqXgOj;

		// Token: 0x0404F9F0 RID: 326128 RVA: 0x0014A468 File Offset: 0x00148668
		static readonly int OlcfEIAdiW;

		// Token: 0x0404F9F1 RID: 326129 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int qU98n9Axz8;

		// Token: 0x0404F9F2 RID: 326130 RVA: 0x0014A470 File Offset: 0x00148670
		static readonly int 6LtitzYYNy;

		// Token: 0x0404F9F3 RID: 326131 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int nEq1Ek8o5H;

		// Token: 0x0404F9F4 RID: 326132 RVA: 0x0014A478 File Offset: 0x00148678
		static readonly int QKNRxbz50c;

		// Token: 0x0404F9F5 RID: 326133 RVA: 0x0014A480 File Offset: 0x00148680
		static readonly int pjqQmD13wP;

		// Token: 0x0404F9F6 RID: 326134 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int tmPusloI3C;

		// Token: 0x0404F9F7 RID: 326135 RVA: 0x0014A458 File Offset: 0x00148658
		static readonly int AV2rsv8bvS;

		// Token: 0x0404F9F8 RID: 326136 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int AdivIEYaOA;

		// Token: 0x0404F9F9 RID: 326137 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int sE2qYo5cjM;

		// Token: 0x0404F9FA RID: 326138 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int wqBxcTr9i1;

		// Token: 0x0404F9FB RID: 326139 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int FaIdOPEemo;

		// Token: 0x0404F9FC RID: 326140 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int NN43T5dMTD;

		// Token: 0x0404F9FD RID: 326141 RVA: 0x0014A488 File Offset: 0x00148688
		static readonly int 0f2jfUcuSy;

		// Token: 0x0404F9FE RID: 326142 RVA: 0x0014A490 File Offset: 0x00148690
		static readonly int WY2W5S6YbI;

		// Token: 0x0404F9FF RID: 326143 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ka058ivIeg;

		// Token: 0x0404FA00 RID: 326144 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 0fpeAjii74;

		// Token: 0x0404FA01 RID: 326145 RVA: 0x0014A498 File Offset: 0x00148698
		static readonly int xTLxRyVh7A;

		// Token: 0x0404FA02 RID: 326146 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9EuKcZp6k7;

		// Token: 0x0404FA03 RID: 326147 RVA: 0x0014A4A0 File Offset: 0x001486A0
		static readonly int iUQw81tXVW;

		// Token: 0x0404FA04 RID: 326148 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int uXahVQOCoK;

		// Token: 0x0404FA05 RID: 326149 RVA: 0x0014A4A8 File Offset: 0x001486A8
		static readonly int NOKdgvufBl;

		// Token: 0x0404FA06 RID: 326150 RVA: 0x0014A4B0 File Offset: 0x001486B0
		static readonly int 3l8AWdDYzZ;

		// Token: 0x0404FA07 RID: 326151 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int F7LkPlnNzL;

		// Token: 0x0404FA08 RID: 326152 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KnRZuUJwPM;

		// Token: 0x0404FA09 RID: 326153 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int HNVudJZaK1;

		// Token: 0x0404FA0A RID: 326154 RVA: 0x0014A4B8 File Offset: 0x001486B8
		static readonly int N0NOFPCkN5;

		// Token: 0x0404FA0B RID: 326155 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int Hhp0aQTiQC;

		// Token: 0x0404FA0C RID: 326156 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int TQImS1mbHG;

		// Token: 0x0404FA0D RID: 326157 RVA: 0x0014A4C0 File Offset: 0x001486C0
		static readonly int LNC78UZDUe;

		// Token: 0x0404FA0E RID: 326158 RVA: 0x0014A4C8 File Offset: 0x001486C8
		static readonly int RjjUEkifUN;

		// Token: 0x0404FA0F RID: 326159 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int z1JIi7rl6O;

		// Token: 0x0404FA10 RID: 326160 RVA: 0x0014A4D0 File Offset: 0x001486D0
		static readonly int nldGt4er2F;

		// Token: 0x0404FA11 RID: 326161 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 0QOvuuryhs;

		// Token: 0x0404FA12 RID: 326162 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int SGG3RUD4ZB;

		// Token: 0x0404FA13 RID: 326163 RVA: 0x0014A4D8 File Offset: 0x001486D8
		static readonly int nyHG1qFclK;

		// Token: 0x0404FA14 RID: 326164 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int F0nOWimXXx;

		// Token: 0x0404FA15 RID: 326165 RVA: 0x0014A4E0 File Offset: 0x001486E0
		static readonly int P2DN5gejzY;

		// Token: 0x0404FA16 RID: 326166 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 0kS1bCJI4D;

		// Token: 0x0404FA17 RID: 326167 RVA: 0x0014A4E8 File Offset: 0x001486E8
		static readonly int oONXmcc1hs;

		// Token: 0x0404FA18 RID: 326168 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sqglvuu3KU;

		// Token: 0x0404FA19 RID: 326169 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int MgnMTfiwwU;

		// Token: 0x0404FA1A RID: 326170 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ZedUIBpqld;

		// Token: 0x0404FA1B RID: 326171 RVA: 0x0014A4E0 File Offset: 0x001486E0
		static readonly int DmCGqKDqFr;

		// Token: 0x0404FA1C RID: 326172 RVA: 0x0014A4E8 File Offset: 0x001486E8
		static readonly int RQ7j1IlADG;

		// Token: 0x0404FA1D RID: 326173 RVA: 0x0014A4F0 File Offset: 0x001486F0
		static readonly int 3qEMTNMMdt;

		// Token: 0x0404FA1E RID: 326174 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int EERrQjdggJ;

		// Token: 0x0404FA1F RID: 326175 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int b2qFCIg3c9;

		// Token: 0x0404FA20 RID: 326176 RVA: 0x0014A4F8 File Offset: 0x001486F8
		static readonly int apnejXhzxc;

		// Token: 0x0404FA21 RID: 326177 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 71NWmN8PSR;

		// Token: 0x0404FA22 RID: 326178 RVA: 0x0014A500 File Offset: 0x00148700
		static readonly int pEe4pB99JK;

		// Token: 0x0404FA23 RID: 326179 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int qTtdTZaxH3;

		// Token: 0x0404FA24 RID: 326180 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int CntDLjpUcz;

		// Token: 0x0404FA25 RID: 326181 RVA: 0x0014A508 File Offset: 0x00148708
		static readonly int KQkKUVLtzi;

		// Token: 0x0404FA26 RID: 326182 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int XipnvnHtCN;

		// Token: 0x0404FA27 RID: 326183 RVA: 0x0014A510 File Offset: 0x00148710
		static readonly int wLIZPBVasF;

		// Token: 0x0404FA28 RID: 326184 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int VpgU9atjI8;

		// Token: 0x0404FA29 RID: 326185 RVA: 0x0014A518 File Offset: 0x00148718
		static readonly int Nr8jge7FRi;

		// Token: 0x0404FA2A RID: 326186 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int c5RPC9IL4T;

		// Token: 0x0404FA2B RID: 326187 RVA: 0x0014A520 File Offset: 0x00148720
		static readonly int 9uAtMrBVnV;

		// Token: 0x0404FA2C RID: 326188 RVA: 0x0014A4F8 File Offset: 0x001486F8
		static readonly int 4ilE9ENj3v;

		// Token: 0x0404FA2D RID: 326189 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int DPJKnaXRRA;

		// Token: 0x0404FA2E RID: 326190 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Rhoy8drOWy;

		// Token: 0x0404FA2F RID: 326191 RVA: 0x0014A510 File Offset: 0x00148710
		static readonly int cmc5n3TNP7;

		// Token: 0x0404FA30 RID: 326192 RVA: 0x0014A518 File Offset: 0x00148718
		static readonly int wjSJQtl0Gw;

		// Token: 0x0404FA31 RID: 326193 RVA: 0x0014A520 File Offset: 0x00148720
		static readonly int TuDmEW3wFg;

		// Token: 0x0404FA32 RID: 326194 RVA: 0x0014A528 File Offset: 0x00148728
		static readonly int X8METaxNgt;

		// Token: 0x0404FA33 RID: 326195 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int GKBUOrPfiO;

		// Token: 0x0404FA34 RID: 326196 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 10Hjerj01Q;

		// Token: 0x0404FA35 RID: 326197 RVA: 0x0014A530 File Offset: 0x00148730
		static readonly int 9hItkxWNzz;

		// Token: 0x0404FA36 RID: 326198 RVA: 0x0014A538 File Offset: 0x00148738
		static readonly int 6YUWpJttXW;

		// Token: 0x0404FA37 RID: 326199 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int GYN0oh1njl;

		// Token: 0x0404FA38 RID: 326200 RVA: 0x0014A540 File Offset: 0x00148740
		static readonly int 16VQujBRub;

		// Token: 0x0404FA39 RID: 326201 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int UCptSdgu3U;

		// Token: 0x0404FA3A RID: 326202 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8zceJlTRFC;

		// Token: 0x0404FA3B RID: 326203 RVA: 0x0014A548 File Offset: 0x00148748
		static readonly int 6tnO79CDmG;

		// Token: 0x0404FA3C RID: 326204 RVA: 0x0014A550 File Offset: 0x00148750
		static readonly int Ic96CEseiK;

		// Token: 0x0404FA3D RID: 326205 RVA: 0x0014A558 File Offset: 0x00148758
		static readonly int BGtPmCe0GJ;

		// Token: 0x0404FA3E RID: 326206 RVA: 0x0014A560 File Offset: 0x00148760
		static readonly int PuLrelYbvS;

		// Token: 0x0404FA3F RID: 326207 RVA: 0x0014A568 File Offset: 0x00148768
		static readonly int acIwMg0fcF;

		// Token: 0x0404FA40 RID: 326208 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 2yt4B09Yl5;

		// Token: 0x0404FA41 RID: 326209 RVA: 0x0014A570 File Offset: 0x00148770
		static readonly int fL7d0YQRca;

		// Token: 0x0404FA42 RID: 326210 RVA: 0x0014A578 File Offset: 0x00148778
		static readonly int pQsQuj77CG;

		// Token: 0x0404FA43 RID: 326211 RVA: 0x0014A580 File Offset: 0x00148780
		static readonly int L8YBQbAQqo;

		// Token: 0x0404FA44 RID: 326212 RVA: 0x0014A588 File Offset: 0x00148788
		static readonly int lAz0wOep6y;

		// Token: 0x0404FA45 RID: 326213 RVA: 0x0014A590 File Offset: 0x00148790
		static readonly int PiDCZlFdKb;

		// Token: 0x0404FA46 RID: 326214 RVA: 0x0014A598 File Offset: 0x00148798
		static readonly int 2CVethx6MZ;

		// Token: 0x0404FA47 RID: 326215 RVA: 0x0014A5A0 File Offset: 0x001487A0
		static readonly int X9lxypb2df;

		// Token: 0x0404FA48 RID: 326216 RVA: 0x0014A5A8 File Offset: 0x001487A8
		static readonly int ESAO1n4Wlo;

		// Token: 0x0404FA49 RID: 326217 RVA: 0x0014A5B0 File Offset: 0x001487B0
		static readonly int VhGOvjoUGP;

		// Token: 0x0404FA4A RID: 326218 RVA: 0x0014A5B8 File Offset: 0x001487B8
		static readonly int bicgaP7QNu;

		// Token: 0x0404FA4B RID: 326219 RVA: 0x0014A5C0 File Offset: 0x001487C0
		static readonly int KN9pXjBGnG;

		// Token: 0x0404FA4C RID: 326220 RVA: 0x0014A5C8 File Offset: 0x001487C8
		static readonly int mbUiD03XBP;

		// Token: 0x0404FA4D RID: 326221 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int AGvODf0eyl;

		// Token: 0x0404FA4E RID: 326222 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int qoI1dIha0M;

		// Token: 0x0404FA4F RID: 326223 RVA: 0x0014A5D0 File Offset: 0x001487D0
		static readonly int hirAmAO3cj;

		// Token: 0x0404FA50 RID: 326224 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int WkO8tEbvm1;

		// Token: 0x0404FA51 RID: 326225 RVA: 0x0014A5D8 File Offset: 0x001487D8
		static readonly int thSCZ7SdE5;

		// Token: 0x0404FA52 RID: 326226 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TdgzrcZvlC;

		// Token: 0x0404FA53 RID: 326227 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int R6BOPGaKHZ;

		// Token: 0x0404FA54 RID: 326228 RVA: 0x0014A5E0 File Offset: 0x001487E0
		static readonly int rvy9cAPokp;

		// Token: 0x0404FA55 RID: 326229 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int svzhQ2DYRR;

		// Token: 0x0404FA56 RID: 326230 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ppKjkwfExT;

		// Token: 0x0404FA57 RID: 326231 RVA: 0x0014A5E8 File Offset: 0x001487E8
		static readonly int hHVoOhpgWq;

		// Token: 0x0404FA58 RID: 326232 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int MuK6UgHe7W;

		// Token: 0x0404FA59 RID: 326233 RVA: 0x0014A5F0 File Offset: 0x001487F0
		static readonly int CB3zuBlOZq;

		// Token: 0x0404FA5A RID: 326234 RVA: 0x0014A5F8 File Offset: 0x001487F8
		static readonly int eL1RIkZKTs;

		// Token: 0x0404FA5B RID: 326235 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int NhBkF4fOOD;

		// Token: 0x0404FA5C RID: 326236 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int pBGaRfOf4M;

		// Token: 0x0404FA5D RID: 326237 RVA: 0x0014A600 File Offset: 0x00148800
		static readonly int 6aHqLA33xt;

		// Token: 0x0404FA5E RID: 326238 RVA: 0x0014A5D0 File Offset: 0x001487D0
		static readonly int G6KOJf9Suz;

		// Token: 0x0404FA5F RID: 326239 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gX9VBdFaAm;

		// Token: 0x0404FA60 RID: 326240 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int W4PGwwZVYF;

		// Token: 0x0404FA61 RID: 326241 RVA: 0x0014A5E8 File Offset: 0x001487E8
		static readonly int Blae7s11Rv;

		// Token: 0x0404FA62 RID: 326242 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int f5vFqjawps;

		// Token: 0x0404FA63 RID: 326243 RVA: 0x0014A600 File Offset: 0x00148800
		static readonly int 4d3LXMrDcW;

		// Token: 0x0404FA64 RID: 326244 RVA: 0x0014A608 File Offset: 0x00148808
		static readonly int Fo4ox46eYS;

		// Token: 0x0404FA65 RID: 326245 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int lOIOHbIKaN;

		// Token: 0x0404FA66 RID: 326246 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int WnpqKisPHu;

		// Token: 0x0404FA67 RID: 326247 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int AxY5q1BHRv;

		// Token: 0x0404FA68 RID: 326248 RVA: 0x0014A610 File Offset: 0x00148810
		static readonly int m5YWGqUpD5;

		// Token: 0x0404FA69 RID: 326249 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int EhnP9c8OdP;

		// Token: 0x0404FA6A RID: 326250 RVA: 0x0014A618 File Offset: 0x00148818
		static readonly int MrXnRyzNhP;

		// Token: 0x0404FA6B RID: 326251 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int aB2olaOSje;

		// Token: 0x0404FA6C RID: 326252 RVA: 0x0014A620 File Offset: 0x00148820
		static readonly int NCLMqdJJ5N;

		// Token: 0x0404FA6D RID: 326253 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 2wnBj4iuFR;

		// Token: 0x0404FA6E RID: 326254 RVA: 0x0014A618 File Offset: 0x00148818
		static readonly int 0HHxfCo8oj;

		// Token: 0x0404FA6F RID: 326255 RVA: 0x0014A620 File Offset: 0x00148820
		static readonly int Npo8BJgL7y;

		// Token: 0x0404FA70 RID: 326256 RVA: 0x0014A628 File Offset: 0x00148828
		static readonly int oqRUXnX0Fq;

		// Token: 0x0404FA71 RID: 326257 RVA: 0x0014A630 File Offset: 0x00148830
		static readonly int 2eNRoG5Xqn;

		// Token: 0x0404FA72 RID: 326258 RVA: 0x0014A638 File Offset: 0x00148838
		static readonly int yLeW9MHoAa;

		// Token: 0x0404FA73 RID: 326259 RVA: 0x0014A640 File Offset: 0x00148840
		static readonly int XXxRmJ0xa1;

		// Token: 0x0404FA74 RID: 326260 RVA: 0x0014A648 File Offset: 0x00148848
		static readonly int oy27qtbXU5;

		// Token: 0x0404FA75 RID: 326261 RVA: 0x0014A650 File Offset: 0x00148850
		static readonly int OJeT9dL4UK;

		// Token: 0x0404FA76 RID: 326262 RVA: 0x0014A658 File Offset: 0x00148858
		static readonly int ft0pTfr6oe;

		// Token: 0x0404FA77 RID: 326263 RVA: 0x0014A660 File Offset: 0x00148860
		static readonly int PH6y8AShqQ;

		// Token: 0x0404FA78 RID: 326264 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int vuUEMN2dRJ;

		// Token: 0x0404FA79 RID: 326265 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 85dQW58NoL;

		// Token: 0x0404FA7A RID: 326266 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Cet0pGNpU8;

		// Token: 0x0404FA7B RID: 326267 RVA: 0x0014A668 File Offset: 0x00148868
		static readonly int KoODZvYwdF;

		// Token: 0x0404FA7C RID: 326268 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mNpffUoqcC;

		// Token: 0x0404FA7D RID: 326269 RVA: 0x0014A670 File Offset: 0x00148870
		static readonly int CF2eOQBeYF;

		// Token: 0x0404FA7E RID: 326270 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int AMIS8UrZ0l;

		// Token: 0x0404FA7F RID: 326271 RVA: 0x0014A678 File Offset: 0x00148878
		static readonly int gLtjiyzOUV;

		// Token: 0x0404FA80 RID: 326272 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int bgNS6EvtzJ;

		// Token: 0x0404FA81 RID: 326273 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int t4XXEZEWgL;

		// Token: 0x0404FA82 RID: 326274 RVA: 0x0014A680 File Offset: 0x00148880
		static readonly int nOz1f0WT6Z;

		// Token: 0x0404FA83 RID: 326275 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int axKDne90W3;

		// Token: 0x0404FA84 RID: 326276 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int j7kr1myVfI;

		// Token: 0x0404FA85 RID: 326277 RVA: 0x0014A688 File Offset: 0x00148888
		static readonly int tdrIrNqWwG;

		// Token: 0x0404FA86 RID: 326278 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sbwZs6uUtj;

		// Token: 0x0404FA87 RID: 326279 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int aO9mmpnH93;

		// Token: 0x0404FA88 RID: 326280 RVA: 0x0014A678 File Offset: 0x00148878
		static readonly int CAyxp6FBVa;

		// Token: 0x0404FA89 RID: 326281 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int xnEQLHKK95;

		// Token: 0x0404FA8A RID: 326282 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 1dl5sfdFgC;

		// Token: 0x0404FA8B RID: 326283 RVA: 0x0014A690 File Offset: 0x00148890
		static readonly int jiW2Esm9uv;

		// Token: 0x0404FA8C RID: 326284 RVA: 0x0014A698 File Offset: 0x00148898
		static readonly int 0s9TwxKtbe;

		// Token: 0x0404FA8D RID: 326285 RVA: 0x0014A6A0 File Offset: 0x001488A0
		static readonly int fdIECiY3FK;

		// Token: 0x0404FA8E RID: 326286 RVA: 0x0014A6A8 File Offset: 0x001488A8
		static readonly int cAfS0OQLLd;

		// Token: 0x0404FA8F RID: 326287 RVA: 0x0014A6B0 File Offset: 0x001488B0
		static readonly int eLaNEIeSI4;

		// Token: 0x0404FA90 RID: 326288 RVA: 0x0014A6B8 File Offset: 0x001488B8
		static readonly int VuoBgGaS0f;

		// Token: 0x0404FA91 RID: 326289 RVA: 0x0014A6C0 File Offset: 0x001488C0
		static readonly int Tt3jS0Nqch;

		// Token: 0x0404FA92 RID: 326290 RVA: 0x0014A6C8 File Offset: 0x001488C8
		static readonly int h8h89TC593;

		// Token: 0x0404FA93 RID: 326291 RVA: 0x0014A6D0 File Offset: 0x001488D0
		static readonly int EGuKzsVevu;

		// Token: 0x0404FA94 RID: 326292 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int y7VqJvS04N;

		// Token: 0x0404FA95 RID: 326293 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 5xzkXWMqBN;

		// Token: 0x0404FA96 RID: 326294 RVA: 0x0014A6D8 File Offset: 0x001488D8
		static readonly int DeT6bM8suk;

		// Token: 0x0404FA97 RID: 326295 RVA: 0x0014A6E0 File Offset: 0x001488E0
		static readonly int et4rtjm1yO;

		// Token: 0x0404FA98 RID: 326296 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int BLBv7QRJxc;

		// Token: 0x0404FA99 RID: 326297 RVA: 0x0014A6E8 File Offset: 0x001488E8
		static readonly int gpcirUoYO7;

		// Token: 0x0404FA9A RID: 326298 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int wjFUtM2H1x;

		// Token: 0x0404FA9B RID: 326299 RVA: 0x0014A6F0 File Offset: 0x001488F0
		static readonly int uU2xL1ch9K;

		// Token: 0x0404FA9C RID: 326300 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 5z4SDzQWAZ;

		// Token: 0x0404FA9D RID: 326301 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 5On0bbFrCv;

		// Token: 0x0404FA9E RID: 326302 RVA: 0x0014A6F8 File Offset: 0x001488F8
		static readonly int YJS9rLxpWz;

		// Token: 0x0404FA9F RID: 326303 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 1GZDB7oxQ4;

		// Token: 0x0404FAA0 RID: 326304 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 5gHc2grBVt;

		// Token: 0x0404FAA1 RID: 326305 RVA: 0x0014A6F0 File Offset: 0x001488F0
		static readonly int vveNwwh4k2;

		// Token: 0x0404FAA2 RID: 326306 RVA: 0x0014A6F8 File Offset: 0x001488F8
		static readonly int Bl9Lhyyjze;

		// Token: 0x0404FAA3 RID: 326307 RVA: 0x0014A700 File Offset: 0x00148900
		static readonly int wSaIz1BzHL;

		// Token: 0x0404FAA4 RID: 326308 RVA: 0x0014A708 File Offset: 0x00148908
		static readonly int dwTnDFmLRP;

		// Token: 0x0404FAA5 RID: 326309 RVA: 0x0014A710 File Offset: 0x00148910
		static readonly int atMX2Uh64D;

		// Token: 0x0404FAA6 RID: 326310 RVA: 0x0014A718 File Offset: 0x00148918
		static readonly int rHL16dUWY5;

		// Token: 0x0404FAA7 RID: 326311 RVA: 0x0014A720 File Offset: 0x00148920
		static readonly int urxYYOSVHc;

		// Token: 0x0404FAA8 RID: 326312 RVA: 0x0014A728 File Offset: 0x00148928
		static readonly int MmSjEDFDPe;

		// Token: 0x0404FAA9 RID: 326313 RVA: 0x0014A730 File Offset: 0x00148930
		static readonly int UF5EdWkbqk;

		// Token: 0x0404FAAA RID: 326314 RVA: 0x0014A738 File Offset: 0x00148938
		static readonly int uPxWft6x9n;

		// Token: 0x0404FAAB RID: 326315 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int CLyb1Fzmx3;

		// Token: 0x0404FAAC RID: 326316 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int XRG3lovs4C;

		// Token: 0x0404FAAD RID: 326317 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int o0pgr6y6EU;

		// Token: 0x0404FAAE RID: 326318 RVA: 0x0014A740 File Offset: 0x00148940
		static readonly int GSEmcIQeNY;

		// Token: 0x0404FAAF RID: 326319 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int g8owNcJ4v0;

		// Token: 0x0404FAB0 RID: 326320 RVA: 0x0014A748 File Offset: 0x00148948
		static readonly int 7O269MfRt4;

		// Token: 0x0404FAB1 RID: 326321 RVA: 0x0014A750 File Offset: 0x00148950
		static readonly int Q2icxFNebc;

		// Token: 0x0404FAB2 RID: 326322 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int XRfgfqL3TO;

		// Token: 0x0404FAB3 RID: 326323 RVA: 0x0014A758 File Offset: 0x00148958
		static readonly int x4LNW1ZHmQ;

		// Token: 0x0404FAB4 RID: 326324 RVA: 0x0014A760 File Offset: 0x00148960
		static readonly int m8uSHnaL8I;

		// Token: 0x0404FAB5 RID: 326325 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int PocScqsWbT;

		// Token: 0x0404FAB6 RID: 326326 RVA: 0x0014A768 File Offset: 0x00148968
		static readonly int Am8eHWrUF5;

		// Token: 0x0404FAB7 RID: 326327 RVA: 0x0014A740 File Offset: 0x00148940
		static readonly int pG1KzZhNY1;

		// Token: 0x0404FAB8 RID: 326328 RVA: 0x0014A770 File Offset: 0x00148970
		static readonly int P94L9Ib2vq;

		// Token: 0x0404FAB9 RID: 326329 RVA: 0x0014A778 File Offset: 0x00148978
		static readonly int JDqTQAAPLv;

		// Token: 0x0404FABA RID: 326330 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6GGDcJwScD;

		// Token: 0x0404FABB RID: 326331 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Jf7jDAswf8;

		// Token: 0x0404FABC RID: 326332 RVA: 0x0014A768 File Offset: 0x00148968
		static readonly int 4yiZwmZi4z;

		// Token: 0x0404FABD RID: 326333 RVA: 0x0014A780 File Offset: 0x00148980
		static readonly int YRCn5J31t0;

		// Token: 0x0404FABE RID: 326334 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int VJasgoFGPP;

		// Token: 0x0404FABF RID: 326335 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ROtM1IhqQz;

		// Token: 0x0404FAC0 RID: 326336 RVA: 0x0014A788 File Offset: 0x00148988
		static readonly int tOXnp1cUo3;

		// Token: 0x0404FAC1 RID: 326337 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int G0DpmvY02H;

		// Token: 0x0404FAC2 RID: 326338 RVA: 0x0014A790 File Offset: 0x00148990
		static readonly int hTSphJizww;

		// Token: 0x0404FAC3 RID: 326339 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mMk3HHvxCo;

		// Token: 0x0404FAC4 RID: 326340 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int LucWIbLEjF;

		// Token: 0x0404FAC5 RID: 326341 RVA: 0x0014A798 File Offset: 0x00148998
		static readonly int urxISa6sFf;

		// Token: 0x0404FAC6 RID: 326342 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Tmi1R4QJif;

		// Token: 0x0404FAC7 RID: 326343 RVA: 0x0014A7A0 File Offset: 0x001489A0
		static readonly int 9lxN5w06gG;

		// Token: 0x0404FAC8 RID: 326344 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 8dQqC4Zbkr;

		// Token: 0x0404FAC9 RID: 326345 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int KDrhVjMkEO;

		// Token: 0x0404FACA RID: 326346 RVA: 0x0014A7A8 File Offset: 0x001489A8
		static readonly int LBgDGI3jNg;

		// Token: 0x0404FACB RID: 326347 RVA: 0x0014A788 File Offset: 0x00148988
		static readonly int jAL9h0W1yW;

		// Token: 0x0404FACC RID: 326348 RVA: 0x0014A790 File Offset: 0x00148990
		static readonly int eyj1V63Q2W;

		// Token: 0x0404FACD RID: 326349 RVA: 0x0014A798 File Offset: 0x00148998
		static readonly int jQ1S567Mk3;

		// Token: 0x0404FACE RID: 326350 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int BzOEHK1s9e;

		// Token: 0x0404FACF RID: 326351 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int MUvrtWcpsK;

		// Token: 0x0404FAD0 RID: 326352 RVA: 0x0014A7B0 File Offset: 0x001489B0
		static readonly int Pnq07TI3Dk;

		// Token: 0x0404FAD1 RID: 326353 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 3JR5VpjetK;

		// Token: 0x0404FAD2 RID: 326354 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int EKQXJOeJii;

		// Token: 0x0404FAD3 RID: 326355 RVA: 0x0014A7B8 File Offset: 0x001489B8
		static readonly int eReZoXIYHy;

		// Token: 0x0404FAD4 RID: 326356 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int C7oZlDD0VD;

		// Token: 0x0404FAD5 RID: 326357 RVA: 0x0014A7C0 File Offset: 0x001489C0
		static readonly int x76iFEWTqs;

		// Token: 0x0404FAD6 RID: 326358 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int y8UfGlo1Q7;

		// Token: 0x0404FAD7 RID: 326359 RVA: 0x0014A7C8 File Offset: 0x001489C8
		static readonly int hLX4IHg1wG;

		// Token: 0x0404FAD8 RID: 326360 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int LnxevgV6Uj;

		// Token: 0x0404FAD9 RID: 326361 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int BzsY9DmJSA;

		// Token: 0x0404FADA RID: 326362 RVA: 0x0014A7C8 File Offset: 0x001489C8
		static readonly int ZLjYgmkBZ7;

		// Token: 0x0404FADB RID: 326363 RVA: 0x0014A7D0 File Offset: 0x001489D0
		static readonly int ifgkhLK0uk;

		// Token: 0x0404FADC RID: 326364 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int Psgr6sc84E;

		// Token: 0x0404FADD RID: 326365 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int eWjwrADZ8J;

		// Token: 0x0404FADE RID: 326366 RVA: 0x0014A7D8 File Offset: 0x001489D8
		static readonly int 6UgXBgSH1y;

		// Token: 0x0404FADF RID: 326367 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2wZruqo2by;

		// Token: 0x0404FAE0 RID: 326368 RVA: 0x0014A7E0 File Offset: 0x001489E0
		static readonly int JlGUdM5u3h;

		// Token: 0x0404FAE1 RID: 326369 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Hu1ko5LJqa;

		// Token: 0x0404FAE2 RID: 326370 RVA: 0x0014A7E8 File Offset: 0x001489E8
		static readonly int ZUHGMr71CA;

		// Token: 0x0404FAE3 RID: 326371 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int VL8K9UNL4y;

		// Token: 0x0404FAE4 RID: 326372 RVA: 0x0014A7F0 File Offset: 0x001489F0
		static readonly int kiOUqH5yDy;

		// Token: 0x0404FAE5 RID: 326373 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int feMBYyeAIv;

		// Token: 0x0404FAE6 RID: 326374 RVA: 0x0014A7F8 File Offset: 0x001489F8
		static readonly int PEs3L6wrlT;

		// Token: 0x0404FAE7 RID: 326375 RVA: 0x0014A800 File Offset: 0x00148A00
		static readonly int s9P1z1GwaE;

		// Token: 0x0404FAE8 RID: 326376 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int wIxNe186vL;

		// Token: 0x0404FAE9 RID: 326377 RVA: 0x0014A808 File Offset: 0x00148A08
		static readonly int 0NDIjfzVJt;

		// Token: 0x0404FAEA RID: 326378 RVA: 0x0014A810 File Offset: 0x00148A10
		static readonly int VONtFfOVLh;

		// Token: 0x0404FAEB RID: 326379 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int srjE8GQeYU;

		// Token: 0x0404FAEC RID: 326380 RVA: 0x0014A818 File Offset: 0x00148A18
		static readonly int 8z5Zdf6GRT;

		// Token: 0x0404FAED RID: 326381 RVA: 0x0014A820 File Offset: 0x00148A20
		static readonly int Bunqti5DI9;

		// Token: 0x0404FAEE RID: 326382 RVA: 0x0014A7E8 File Offset: 0x001489E8
		static readonly int mnvOdIn8Kd;

		// Token: 0x0404FAEF RID: 326383 RVA: 0x0014A7F0 File Offset: 0x001489F0
		static readonly int OV7zvfSyPk;

		// Token: 0x0404FAF0 RID: 326384 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int jID1f7E2VZ;

		// Token: 0x0404FAF1 RID: 326385 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int LNWYrUEq5V;

		// Token: 0x0404FAF2 RID: 326386 RVA: 0x0014A828 File Offset: 0x00148A28
		static readonly int 176yEqwy5N;

		// Token: 0x0404FAF3 RID: 326387 RVA: 0x0014A830 File Offset: 0x00148A30
		static readonly int PGyhaek3tg;

		// Token: 0x0404FAF4 RID: 326388 RVA: 0x0014A838 File Offset: 0x00148A38
		static readonly int EunvRB9iHa;

		// Token: 0x0404FAF5 RID: 326389 RVA: 0x0014A840 File Offset: 0x00148A40
		static readonly int am24slMPwy;

		// Token: 0x0404FAF6 RID: 326390 RVA: 0x0014A848 File Offset: 0x00148A48
		static readonly int KP7HJEYy8N;

		// Token: 0x0404FAF7 RID: 326391 RVA: 0x0014A850 File Offset: 0x00148A50
		static readonly int uL6ZRHTLgD;

		// Token: 0x0404FAF8 RID: 326392 RVA: 0x0014A858 File Offset: 0x00148A58
		static readonly int rNrfxnO3zy;

		// Token: 0x0404FAF9 RID: 326393 RVA: 0x0014A860 File Offset: 0x00148A60
		static readonly int SUG4VyxglN;

		// Token: 0x0404FAFA RID: 326394 RVA: 0x0014A868 File Offset: 0x00148A68
		static readonly int mKk3qPpcnl;

		// Token: 0x0404FAFB RID: 326395 RVA: 0x0014A870 File Offset: 0x00148A70
		static readonly int RAttH6ibTf;

		// Token: 0x0404FAFC RID: 326396 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 0f9J5ZECEc;

		// Token: 0x0404FAFD RID: 326397 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int TwjTagnxzh;

		// Token: 0x0404FAFE RID: 326398 RVA: 0x0014A878 File Offset: 0x00148A78
		static readonly int 8vQNhRlXwY;

		// Token: 0x0404FAFF RID: 326399 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int QVNFXHKb8Q;

		// Token: 0x0404FB00 RID: 326400 RVA: 0x0014A880 File Offset: 0x00148A80
		static readonly int LnYKSebaTk;

		// Token: 0x0404FB01 RID: 326401 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int TvmvhEOwmo;

		// Token: 0x0404FB02 RID: 326402 RVA: 0x0014A888 File Offset: 0x00148A88
		static readonly int yrPpM7je6S;

		// Token: 0x0404FB03 RID: 326403 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int WMziWVWG5C;

		// Token: 0x0404FB04 RID: 326404 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int zLDMFftbhS;

		// Token: 0x0404FB05 RID: 326405 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 3YyTcdXt8U;

		// Token: 0x0404FB06 RID: 326406 RVA: 0x0014A890 File Offset: 0x00148A90
		static readonly int 47eBOH6DZM;

		// Token: 0x0404FB07 RID: 326407 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int sI1jymnDjr;

		// Token: 0x0404FB08 RID: 326408 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int NI6nZ7XfG2;

		// Token: 0x0404FB09 RID: 326409 RVA: 0x0014A898 File Offset: 0x00148A98
		static readonly int 7mHkH2rC78;

		// Token: 0x0404FB0A RID: 326410 RVA: 0x0014A8A0 File Offset: 0x00148AA0
		static readonly int jpBVjuhPfz;

		// Token: 0x0404FB0B RID: 326411 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int zTJQHwA0mR;

		// Token: 0x0404FB0C RID: 326412 RVA: 0x0014A8A8 File Offset: 0x00148AA8
		static readonly int ta7gOFARc6;

		// Token: 0x0404FB0D RID: 326413 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 4lGlIiHlEo;

		// Token: 0x0404FB0E RID: 326414 RVA: 0x0014A8B0 File Offset: 0x00148AB0
		static readonly int aI9QCnc1dV;

		// Token: 0x0404FB0F RID: 326415 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 11ZqOIseGe;

		// Token: 0x0404FB10 RID: 326416 RVA: 0x0014A8B8 File Offset: 0x00148AB8
		static readonly int tQwi4ONiIi;

		// Token: 0x0404FB11 RID: 326417 RVA: 0x0014A8C0 File Offset: 0x00148AC0
		static readonly int oZw70laqek;

		// Token: 0x0404FB12 RID: 326418 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int mJyGEDMZXA;

		// Token: 0x0404FB13 RID: 326419 RVA: 0x0014A8C8 File Offset: 0x00148AC8
		static readonly int zmek4KVaVy;

		// Token: 0x0404FB14 RID: 326420 RVA: 0x0014A8D0 File Offset: 0x00148AD0
		static readonly int Z4s4qbFczm;

		// Token: 0x0404FB15 RID: 326421 RVA: 0x0014A8D8 File Offset: 0x00148AD8
		static readonly int rCAf1kcqe1;

		// Token: 0x0404FB16 RID: 326422 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int CyLIsC5MCq;

		// Token: 0x0404FB17 RID: 326423 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Q9UpLsb3am;

		// Token: 0x0404FB18 RID: 326424 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8tkuSxl8sU;

		// Token: 0x0404FB19 RID: 326425 RVA: 0x0014A8E0 File Offset: 0x00148AE0
		static readonly int sp6ewltkLn;

		// Token: 0x0404FB1A RID: 326426 RVA: 0x0014A8C8 File Offset: 0x00148AC8
		static readonly int g3ZIVrrVUI;

		// Token: 0x0404FB1B RID: 326427 RVA: 0x0014A8E8 File Offset: 0x00148AE8
		static readonly int JiP12SOaz5;

		// Token: 0x0404FB1C RID: 326428 RVA: 0x0014A8F0 File Offset: 0x00148AF0
		static readonly int b6ds8lDz3j;

		// Token: 0x0404FB1D RID: 326429 RVA: 0x0014A8F8 File Offset: 0x00148AF8
		static readonly int 90swGFUbYl;

		// Token: 0x0404FB1E RID: 326430 RVA: 0x0014A900 File Offset: 0x00148B00
		static readonly int FQojLJZFle;

		// Token: 0x0404FB1F RID: 326431 RVA: 0x0014A908 File Offset: 0x00148B08
		static readonly int XSuQMjZrJu;

		// Token: 0x0404FB20 RID: 326432 RVA: 0x0014A910 File Offset: 0x00148B10
		static readonly int o2cvJSzdux;

		// Token: 0x0404FB21 RID: 326433 RVA: 0x0014A918 File Offset: 0x00148B18
		static readonly int 8wBOzLS3gz;

		// Token: 0x0404FB22 RID: 326434 RVA: 0x0014A920 File Offset: 0x00148B20
		static readonly int M7NZMqGbkg;

		// Token: 0x0404FB23 RID: 326435 RVA: 0x0014A928 File Offset: 0x00148B28
		static readonly int pmRo6Nx3a3;

		// Token: 0x0404FB24 RID: 326436 RVA: 0x0014A930 File Offset: 0x00148B30
		static readonly int T6UyflRfbB;

		// Token: 0x0404FB25 RID: 326437 RVA: 0x0014A938 File Offset: 0x00148B38
		static readonly int RgKUiqoDjd;

		// Token: 0x0404FB26 RID: 326438 RVA: 0x0014A940 File Offset: 0x00148B40
		static readonly int LY2NIVeWRl;

		// Token: 0x0404FB27 RID: 326439 RVA: 0x0014A948 File Offset: 0x00148B48
		static readonly int XZdnfPnZ3k;

		// Token: 0x0404FB28 RID: 326440 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int YkAiPIb7GQ;

		// Token: 0x0404FB29 RID: 326441 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int juU6r5DGpK;

		// Token: 0x0404FB2A RID: 326442 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int G4N0n2DhzS;

		// Token: 0x0404FB2B RID: 326443 RVA: 0x0014A950 File Offset: 0x00148B50
		static readonly int DOK8EkYU89;

		// Token: 0x0404FB2C RID: 326444 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 3hQBBmEg5j;

		// Token: 0x0404FB2D RID: 326445 RVA: 0x0014A958 File Offset: 0x00148B58
		static readonly int MgusedXK4W;

		// Token: 0x0404FB2E RID: 326446 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int F4HxMUkW1H;

		// Token: 0x0404FB2F RID: 326447 RVA: 0x0014A960 File Offset: 0x00148B60
		static readonly int htIpQjoLyB;

		// Token: 0x0404FB30 RID: 326448 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int xhmPGgebdl;

		// Token: 0x0404FB31 RID: 326449 RVA: 0x0014A968 File Offset: 0x00148B68
		static readonly int NNZl49Zcyr;

		// Token: 0x0404FB32 RID: 326450 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int CsoyCcYEc5;

		// Token: 0x0404FB33 RID: 326451 RVA: 0x0014A958 File Offset: 0x00148B58
		static readonly int yLV3jiR2rq;

		// Token: 0x0404FB34 RID: 326452 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int zJ2Q3TTguQ;

		// Token: 0x0404FB35 RID: 326453 RVA: 0x0014A968 File Offset: 0x00148B68
		static readonly int JMXH8E2yNn;

		// Token: 0x0404FB36 RID: 326454 RVA: 0x0014A970 File Offset: 0x00148B70
		static readonly int Ia8iwC2fCW;

		// Token: 0x0404FB37 RID: 326455 RVA: 0x0014A978 File Offset: 0x00148B78
		static readonly int shvI130Y4s;

		// Token: 0x0404FB38 RID: 326456 RVA: 0x0014A980 File Offset: 0x00148B80
		static readonly int J1TLvmyO4e;

		// Token: 0x0404FB39 RID: 326457 RVA: 0x0014A988 File Offset: 0x00148B88
		static readonly int pdoDhZKUe1;

		// Token: 0x0404FB3A RID: 326458 RVA: 0x0014A990 File Offset: 0x00148B90
		static readonly int bxeYimaOPF;

		// Token: 0x0404FB3B RID: 326459 RVA: 0x0014A998 File Offset: 0x00148B98
		static readonly int Oe4eeRGxwJ;

		// Token: 0x0404FB3C RID: 326460 RVA: 0x0014A9A0 File Offset: 0x00148BA0
		static readonly int OnkiqO2slc;

		// Token: 0x0404FB3D RID: 326461 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int sg4CRVW5nJ;

		// Token: 0x0404FB3E RID: 326462 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Lj9zPLjKiP;

		// Token: 0x0404FB3F RID: 326463 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int SXhUnyN6rT;

		// Token: 0x0404FB40 RID: 326464 RVA: 0x0014A9A8 File Offset: 0x00148BA8
		static readonly int tsnxXsj1NJ;

		// Token: 0x0404FB41 RID: 326465 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4LKm7oovSf;

		// Token: 0x0404FB42 RID: 326466 RVA: 0x0014A9B0 File Offset: 0x00148BB0
		static readonly int psJVJU8jZd;

		// Token: 0x0404FB43 RID: 326467 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int IaOTZc6Lbh;

		// Token: 0x0404FB44 RID: 326468 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lr6YVGN4W9;

		// Token: 0x0404FB45 RID: 326469 RVA: 0x0014A9B8 File Offset: 0x00148BB8
		static readonly int JbnMnBjRoC;

		// Token: 0x0404FB46 RID: 326470 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int uAcuBd70Nf;

		// Token: 0x0404FB47 RID: 326471 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int sdTv37vuAC;

		// Token: 0x0404FB48 RID: 326472 RVA: 0x0014A9C0 File Offset: 0x00148BC0
		static readonly int HDMaTqxBpY;

		// Token: 0x0404FB49 RID: 326473 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 3ohZwlPMX1;

		// Token: 0x0404FB4A RID: 326474 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int JWr1QqH2Sq;

		// Token: 0x0404FB4B RID: 326475 RVA: 0x0014A9C8 File Offset: 0x00148BC8
		static readonly int PyRl5rxCaU;

		// Token: 0x0404FB4C RID: 326476 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int q5LylE548R;

		// Token: 0x0404FB4D RID: 326477 RVA: 0x0014A9D0 File Offset: 0x00148BD0
		static readonly int sjXI3uVVJn;

		// Token: 0x0404FB4E RID: 326478 RVA: 0x0014A9A8 File Offset: 0x00148BA8
		static readonly int i4t9IEW5eF;

		// Token: 0x0404FB4F RID: 326479 RVA: 0x0014A9B0 File Offset: 0x00148BB0
		static readonly int xNvCKNL3QM;

		// Token: 0x0404FB50 RID: 326480 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int uN3B7qbJrK;

		// Token: 0x0404FB51 RID: 326481 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Vc2xwvMLpg;

		// Token: 0x0404FB52 RID: 326482 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int rAZ3eexU7p;

		// Token: 0x0404FB53 RID: 326483 RVA: 0x0014A9C8 File Offset: 0x00148BC8
		static readonly int icE62UBrBc;

		// Token: 0x0404FB54 RID: 326484 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int mMNTtVU8QY;

		// Token: 0x0404FB55 RID: 326485 RVA: 0x0014A9D8 File Offset: 0x00148BD8
		static readonly int BANteuy9hd;

		// Token: 0x0404FB56 RID: 326486 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int 3HLCm3X65b;

		// Token: 0x0404FB57 RID: 326487 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ueJN4fwGJI;

		// Token: 0x0404FB58 RID: 326488 RVA: 0x0014A9E0 File Offset: 0x00148BE0
		static readonly int KyEioiOVbH;

		// Token: 0x0404FB59 RID: 326489 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gBKijfBLr0;

		// Token: 0x0404FB5A RID: 326490 RVA: 0x0014A9E8 File Offset: 0x00148BE8
		static readonly int 7YDyog09z9;

		// Token: 0x0404FB5B RID: 326491 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8szYTECmXE;

		// Token: 0x0404FB5C RID: 326492 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int oBex5sTloY;

		// Token: 0x0404FB5D RID: 326493 RVA: 0x0014A9F0 File Offset: 0x00148BF0
		static readonly int dkZTLvvQ4H;

		// Token: 0x0404FB5E RID: 326494 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int rOgbJyMwPe;

		// Token: 0x0404FB5F RID: 326495 RVA: 0x0014A9F8 File Offset: 0x00148BF8
		static readonly int cYxmL53P26;

		// Token: 0x0404FB60 RID: 326496 RVA: 0x0014AA00 File Offset: 0x00148C00
		static readonly int NPVafXTgMh;

		// Token: 0x0404FB61 RID: 326497 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int SwsQWZfCnH;

		// Token: 0x0404FB62 RID: 326498 RVA: 0x0014AA08 File Offset: 0x00148C08
		static readonly int ggWJ5FxwHQ;

		// Token: 0x0404FB63 RID: 326499 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 2gX74c3G6v;

		// Token: 0x0404FB64 RID: 326500 RVA: 0x0014AA10 File Offset: 0x00148C10
		static readonly int fpksMqqhPw;

		// Token: 0x0404FB65 RID: 326501 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int a1lvaq2Lea;

		// Token: 0x0404FB66 RID: 326502 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kgY6owZuV4;

		// Token: 0x0404FB67 RID: 326503 RVA: 0x0014A9F0 File Offset: 0x00148BF0
		static readonly int gZG2m06n7P;

		// Token: 0x0404FB68 RID: 326504 RVA: 0x0014AA18 File Offset: 0x00148C18
		static readonly int ZPgV0A4lhO;

		// Token: 0x0404FB69 RID: 326505 RVA: 0x0014AA20 File Offset: 0x00148C20
		static readonly int jrlfL8QoDa;

		// Token: 0x0404FB6A RID: 326506 RVA: 0x0014AA08 File Offset: 0x00148C08
		static readonly int R5LVPAutJj;

		// Token: 0x0404FB6B RID: 326507 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int tPOOAUADGn;

		// Token: 0x0404FB6C RID: 326508 RVA: 0x0014AA28 File Offset: 0x00148C28
		static readonly int 1xMHUzxkrn;

		// Token: 0x0404FB6D RID: 326509 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int kSkh8dEKFz;

		// Token: 0x0404FB6E RID: 326510 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int QLc8eUcWe0;

		// Token: 0x0404FB6F RID: 326511 RVA: 0x0014AA30 File Offset: 0x00148C30
		static readonly int 7NiZidtEAa;

		// Token: 0x0404FB70 RID: 326512 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NKCf9borQh;

		// Token: 0x0404FB71 RID: 326513 RVA: 0x0014AA38 File Offset: 0x00148C38
		static readonly int Qz7QXqUOmA;

		// Token: 0x0404FB72 RID: 326514 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int WaF0pWtK8e;

		// Token: 0x0404FB73 RID: 326515 RVA: 0x0014AA40 File Offset: 0x00148C40
		static readonly int uAKplGI69C;

		// Token: 0x0404FB74 RID: 326516 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int pvG7kIPRB1;

		// Token: 0x0404FB75 RID: 326517 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int JfbAExELzm;

		// Token: 0x0404FB76 RID: 326518 RVA: 0x0014AA40 File Offset: 0x00148C40
		static readonly int rdsvwQpSpR;

		// Token: 0x0404FB77 RID: 326519 RVA: 0x0014AA48 File Offset: 0x00148C48
		static readonly int hYOkUkTIQh;

		// Token: 0x0404FB78 RID: 326520 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int HcJHVPjJky;

		// Token: 0x0404FB79 RID: 326521 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int B6GWULDULU;

		// Token: 0x0404FB7A RID: 326522 RVA: 0x0014AA50 File Offset: 0x00148C50
		static readonly int c7mtTuQ0pe;

		// Token: 0x0404FB7B RID: 326523 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int d65SePUlah;

		// Token: 0x0404FB7C RID: 326524 RVA: 0x0014AA58 File Offset: 0x00148C58
		static readonly int rfr0PkR2PJ;

		// Token: 0x0404FB7D RID: 326525 RVA: 0x0014AA60 File Offset: 0x00148C60
		static readonly int g866EK0Zxk;

		// Token: 0x0404FB7E RID: 326526 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 9seGVFBy1F;

		// Token: 0x0404FB7F RID: 326527 RVA: 0x0014AA68 File Offset: 0x00148C68
		static readonly int 1c4on7Pves;

		// Token: 0x0404FB80 RID: 326528 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int cXkf7e99NU;

		// Token: 0x0404FB81 RID: 326529 RVA: 0x0014AA70 File Offset: 0x00148C70
		static readonly int Y5yzh8BleK;

		// Token: 0x0404FB82 RID: 326530 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int jdAKSDESTH;

		// Token: 0x0404FB83 RID: 326531 RVA: 0x0014AA78 File Offset: 0x00148C78
		static readonly int 5E5EIlH8I1;

		// Token: 0x0404FB84 RID: 326532 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int GClhr5oFGo;

		// Token: 0x0404FB85 RID: 326533 RVA: 0x0014AA80 File Offset: 0x00148C80
		static readonly int 5nRTJ9XaN4;

		// Token: 0x0404FB86 RID: 326534 RVA: 0x0014AA88 File Offset: 0x00148C88
		static readonly int aqpFZT9tr5;

		// Token: 0x0404FB87 RID: 326535 RVA: 0x0014AA50 File Offset: 0x00148C50
		static readonly int 1CdnDh1cdW;

		// Token: 0x0404FB88 RID: 326536 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Z9MoMSxl4I;

		// Token: 0x0404FB89 RID: 326537 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int NruObaWgIX;

		// Token: 0x0404FB8A RID: 326538 RVA: 0x0014AA70 File Offset: 0x00148C70
		static readonly int 64XKx3JnPm;

		// Token: 0x0404FB8B RID: 326539 RVA: 0x0014AA78 File Offset: 0x00148C78
		static readonly int I471eaeA3H;

		// Token: 0x0404FB8C RID: 326540 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int gYzjrKRPMn;

		// Token: 0x0404FB8D RID: 326541 RVA: 0x0014AA90 File Offset: 0x00148C90
		static readonly int KVUGaelB1S;

		// Token: 0x0404FB8E RID: 326542 RVA: 0x0014AA98 File Offset: 0x00148C98
		static readonly int IKWSATt3tA;

		// Token: 0x0404FB8F RID: 326543 RVA: 0x0014AAA0 File Offset: 0x00148CA0
		static readonly int 6VnB1hFycn;

		// Token: 0x0404FB90 RID: 326544 RVA: 0x0014AAA8 File Offset: 0x00148CA8
		static readonly int l4albxk1b9;

		// Token: 0x0404FB91 RID: 326545 RVA: 0x0014AAB0 File Offset: 0x00148CB0
		static readonly int zcJk8VBhjY;

		// Token: 0x0404FB92 RID: 326546 RVA: 0x0014AAB8 File Offset: 0x00148CB8
		static readonly int aYgMryrTO2;

		// Token: 0x0404FB93 RID: 326547 RVA: 0x0014AAC0 File Offset: 0x00148CC0
		static readonly int ZwjOqOtu0M;

		// Token: 0x0404FB94 RID: 326548 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int s2ctKdMCCf;

		// Token: 0x0404FB95 RID: 326549 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int giPDNNXO3m;

		// Token: 0x0404FB96 RID: 326550 RVA: 0x0014AAC8 File Offset: 0x00148CC8
		static readonly int FRmjkC353u;

		// Token: 0x0404FB97 RID: 326551 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mRqWph5wBO;

		// Token: 0x0404FB98 RID: 326552 RVA: 0x0014AAD0 File Offset: 0x00148CD0
		static readonly int moQtW1hfAd;

		// Token: 0x0404FB99 RID: 326553 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 0e0NHbP3IH;

		// Token: 0x0404FB9A RID: 326554 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kQJR2O13Yp;

		// Token: 0x0404FB9B RID: 326555 RVA: 0x0014AAD8 File Offset: 0x00148CD8
		static readonly int RkMp9aA2Mt;

		// Token: 0x0404FB9C RID: 326556 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int fY4Z4HbcON;

		// Token: 0x0404FB9D RID: 326557 RVA: 0x0014AAE0 File Offset: 0x00148CE0
		static readonly int RCn3nWf80H;

		// Token: 0x0404FB9E RID: 326558 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 9nHVLPSKNr;

		// Token: 0x0404FB9F RID: 326559 RVA: 0x0014AAE8 File Offset: 0x00148CE8
		static readonly int bXqZmMVtXv;

		// Token: 0x0404FBA0 RID: 326560 RVA: 0x0014AAC8 File Offset: 0x00148CC8
		static readonly int xYoKXO6SBn;

		// Token: 0x0404FBA1 RID: 326561 RVA: 0x0014AAD0 File Offset: 0x00148CD0
		static readonly int 5BCFt1RiNo;

		// Token: 0x0404FBA2 RID: 326562 RVA: 0x0014AAD8 File Offset: 0x00148CD8
		static readonly int zQOhw4WORb;

		// Token: 0x0404FBA3 RID: 326563 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int AvkFUk9687;

		// Token: 0x0404FBA4 RID: 326564 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int S9IkwZVlqu;

		// Token: 0x0404FBA5 RID: 326565 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 5wfs5hKHXc;

		// Token: 0x0404FBA6 RID: 326566 RVA: 0x0014AAF0 File Offset: 0x00148CF0
		static readonly int 2sAkmJa6uI;

		// Token: 0x0404FBA7 RID: 326567 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2UkQW0HovX;

		// Token: 0x0404FBA8 RID: 326568 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int jvhhgNQ1Jx;

		// Token: 0x0404FBA9 RID: 326569 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int a1igFj8i7m;

		// Token: 0x0404FBAA RID: 326570 RVA: 0x0014AAF8 File Offset: 0x00148CF8
		static readonly int 8Y0h2kMOWF;

		// Token: 0x0404FBAB RID: 326571 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int agWA2GLdDY;

		// Token: 0x0404FBAC RID: 326572 RVA: 0x0014AB00 File Offset: 0x00148D00
		static readonly int 3jw7sAvELw;

		// Token: 0x0404FBAD RID: 326573 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 2iqIYL4Ap5;

		// Token: 0x0404FBAE RID: 326574 RVA: 0x0014AB08 File Offset: 0x00148D08
		static readonly int BBfEX4fin8;

		// Token: 0x0404FBAF RID: 326575 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int YeejtZl3z1;

		// Token: 0x0404FBB0 RID: 326576 RVA: 0x0014AB00 File Offset: 0x00148D00
		static readonly int zIDjN1zNmr;

		// Token: 0x0404FBB1 RID: 326577 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int MLyIX1Dsky;

		// Token: 0x0404FBB2 RID: 326578 RVA: 0x0014AB10 File Offset: 0x00148D10
		static readonly int eNaNYXDHY9;

		// Token: 0x0404FBB3 RID: 326579 RVA: 0x0014AB18 File Offset: 0x00148D18
		static readonly int jBKxG2751f;

		// Token: 0x0404FBB4 RID: 326580 RVA: 0x0014AB20 File Offset: 0x00148D20
		static readonly int ER65vNpWL1;

		// Token: 0x0404FBB5 RID: 326581 RVA: 0x0014AB28 File Offset: 0x00148D28
		static readonly int V3SBWmr0Lz;

		// Token: 0x0404FBB6 RID: 326582 RVA: 0x0014AB30 File Offset: 0x00148D30
		static readonly int xsznIKABCe;

		// Token: 0x0404FBB7 RID: 326583 RVA: 0x0014AB38 File Offset: 0x00148D38
		static readonly int 4I1EtNQfbL;

		// Token: 0x0404FBB8 RID: 326584 RVA: 0x0014AB40 File Offset: 0x00148D40
		static readonly int rr5gnqsJae;

		// Token: 0x0404FBB9 RID: 326585 RVA: 0x0014AB48 File Offset: 0x00148D48
		static readonly int LHuBsVcTxl;

		// Token: 0x0404FBBA RID: 326586 RVA: 0x0014AB50 File Offset: 0x00148D50
		static readonly int MoUq7NCORJ;

		// Token: 0x0404FBBB RID: 326587 RVA: 0x0014AB58 File Offset: 0x00148D58
		static readonly int VMYAIFxS9b;

		// Token: 0x0404FBBC RID: 326588 RVA: 0x0014AB60 File Offset: 0x00148D60
		static readonly int b0khTwX0WY;

		// Token: 0x0404FBBD RID: 326589 RVA: 0x0014AB68 File Offset: 0x00148D68
		static readonly int v7r08DXPjZ;

		// Token: 0x0404FBBE RID: 326590 RVA: 0x0014AB70 File Offset: 0x00148D70
		static readonly int oe2RI8tu3m;

		// Token: 0x0404FBBF RID: 326591 RVA: 0x0014AB78 File Offset: 0x00148D78
		static readonly int iJTVJWDwWL;

		// Token: 0x0404FBC0 RID: 326592 RVA: 0x0014AB80 File Offset: 0x00148D80
		static readonly int zL23YXfiBE;

		// Token: 0x0404FBC1 RID: 326593 RVA: 0x0014AB88 File Offset: 0x00148D88
		static readonly int shtkx78TZU;

		// Token: 0x0404FBC2 RID: 326594 RVA: 0x0014AB90 File Offset: 0x00148D90
		static readonly int Dn7tzloVqm;

		// Token: 0x0404FBC3 RID: 326595 RVA: 0x0014AB98 File Offset: 0x00148D98
		static readonly int 9l2Xjcl83v;

		// Token: 0x0404FBC4 RID: 326596 RVA: 0x0014ABA0 File Offset: 0x00148DA0
		static readonly int dKsy4AZthL;

		// Token: 0x0404FBC5 RID: 326597 RVA: 0x0014ABA8 File Offset: 0x00148DA8
		static readonly int XuWCHMOIDw;

		// Token: 0x0404FBC6 RID: 326598 RVA: 0x0014ABB0 File Offset: 0x00148DB0
		static readonly int tJ1ZEHpVAV;

		// Token: 0x0404FBC7 RID: 326599 RVA: 0x0014ABB8 File Offset: 0x00148DB8
		static readonly int V9ao125Izy;

		// Token: 0x0404FBC8 RID: 326600 RVA: 0x0014ABC0 File Offset: 0x00148DC0
		static readonly int L5xfOPO0QX;

		// Token: 0x0404FBC9 RID: 326601 RVA: 0x0014ABC8 File Offset: 0x00148DC8
		static readonly int Nd5GBTTStw;

		// Token: 0x0404FBCA RID: 326602 RVA: 0x0014ABD0 File Offset: 0x00148DD0
		static readonly int VEsM0YTsKP;

		// Token: 0x0404FBCB RID: 326603 RVA: 0x0014ABD8 File Offset: 0x00148DD8
		static readonly int RGSOkxWWLy;

		// Token: 0x0404FBCC RID: 326604 RVA: 0x0014ABE0 File Offset: 0x00148DE0
		static readonly int 2yFnI2EUmh;

		// Token: 0x0404FBCD RID: 326605 RVA: 0x0014ABE8 File Offset: 0x00148DE8
		static readonly int jmYCcHNlo0;

		// Token: 0x0404FBCE RID: 326606 RVA: 0x0014ABF0 File Offset: 0x00148DF0
		static readonly int 6fpAFHKqfO;

		// Token: 0x0404FBCF RID: 326607 RVA: 0x0014ABF8 File Offset: 0x00148DF8
		static readonly int 76H44h8ED7;

		// Token: 0x0404FBD0 RID: 326608 RVA: 0x0014AC00 File Offset: 0x00148E00
		static readonly int T9GnporQwd;

		// Token: 0x0404FBD1 RID: 326609 RVA: 0x0014AC08 File Offset: 0x00148E08
		static readonly int kvrV2XIEhB;

		// Token: 0x0404FBD2 RID: 326610 RVA: 0x0014AC10 File Offset: 0x00148E10
		static readonly int rXyYknfeI5;

		// Token: 0x0404FBD3 RID: 326611 RVA: 0x0014AC18 File Offset: 0x00148E18
		static readonly int JIhrg6YCVb;

		// Token: 0x0404FBD4 RID: 326612 RVA: 0x0014AC20 File Offset: 0x00148E20
		static readonly int Z44CnLOwCg;

		// Token: 0x0404FBD5 RID: 326613 RVA: 0x0014AC28 File Offset: 0x00148E28
		static readonly int Y3gCQ6KsDC;

		// Token: 0x0404FBD6 RID: 326614 RVA: 0x0014AC30 File Offset: 0x00148E30
		static readonly int JNH0TcOAy5;

		// Token: 0x0404FBD7 RID: 326615 RVA: 0x0014AC38 File Offset: 0x00148E38
		static readonly int 8GtGlxdvuY;

		// Token: 0x0404FBD8 RID: 326616 RVA: 0x0014AC40 File Offset: 0x00148E40
		static readonly int YsbmhPleak;

		// Token: 0x0404FBD9 RID: 326617 RVA: 0x0014AC48 File Offset: 0x00148E48
		static readonly int wq8SRMwDtL;

		// Token: 0x0404FBDA RID: 326618 RVA: 0x0014AC50 File Offset: 0x00148E50
		static readonly int 7O7GhRJabc;

		// Token: 0x0404FBDB RID: 326619 RVA: 0x0014AC58 File Offset: 0x00148E58
		static readonly int cZ7onbvfTD;

		// Token: 0x0404FBDC RID: 326620 RVA: 0x0014AC60 File Offset: 0x00148E60
		static readonly int 0ujOJSIbzY;

		// Token: 0x0404FBDD RID: 326621 RVA: 0x0014AC68 File Offset: 0x00148E68
		static readonly int AZCjbKvVEP;

		// Token: 0x0404FBDE RID: 326622 RVA: 0x0014AC70 File Offset: 0x00148E70
		static readonly int GLC8HWsTo0;

		// Token: 0x0404FBDF RID: 326623 RVA: 0x0014AC78 File Offset: 0x00148E78
		static readonly int bQupUNos7P;

		// Token: 0x0404FBE0 RID: 326624 RVA: 0x0014AC80 File Offset: 0x00148E80
		static readonly int JskDbDWXNd;

		// Token: 0x0404FBE1 RID: 326625 RVA: 0x0014AC88 File Offset: 0x00148E88
		static readonly int qabD7orlHw;

		// Token: 0x0404FBE2 RID: 326626 RVA: 0x0014AC90 File Offset: 0x00148E90
		static readonly int jyw86tpXPN;

		// Token: 0x0404FBE3 RID: 326627 RVA: 0x0014AC98 File Offset: 0x00148E98
		static readonly int gCXyGXl9gE;

		// Token: 0x0404FBE4 RID: 326628 RVA: 0x0014ACA0 File Offset: 0x00148EA0
		static readonly int AVFLKBzqrq;

		// Token: 0x0404FBE5 RID: 326629 RVA: 0x0014ACA8 File Offset: 0x00148EA8
		static readonly int fClKpU6lGs;

		// Token: 0x0404FBE6 RID: 326630 RVA: 0x0014ACB0 File Offset: 0x00148EB0
		static readonly int Y8IA7nCm7k;

		// Token: 0x0404FBE7 RID: 326631 RVA: 0x0014ACB8 File Offset: 0x00148EB8
		static readonly int DrFCwOsly5;

		// Token: 0x0404FBE8 RID: 326632 RVA: 0x0014ACC0 File Offset: 0x00148EC0
		static readonly int 48qjrdaMIv;

		// Token: 0x0404FBE9 RID: 326633 RVA: 0x0014ACC8 File Offset: 0x00148EC8
		static readonly int b93yqBMFNg;

		// Token: 0x0404FBEA RID: 326634 RVA: 0x0014ACD0 File Offset: 0x00148ED0
		static readonly int 8MtGmy7jYb;

		// Token: 0x0404FBEB RID: 326635 RVA: 0x0014ACD8 File Offset: 0x00148ED8
		static readonly int mUxKxZSjSd;

		// Token: 0x0404FBEC RID: 326636 RVA: 0x0014ACE0 File Offset: 0x00148EE0
		static readonly int NzdLJEyQWu;

		// Token: 0x0404FBED RID: 326637 RVA: 0x0014ACE8 File Offset: 0x00148EE8
		static readonly int BmXS6rOj63;

		// Token: 0x0404FBEE RID: 326638 RVA: 0x0014ACF0 File Offset: 0x00148EF0
		static readonly int f0yrIGMsAQ;

		// Token: 0x0404FBEF RID: 326639 RVA: 0x0014ACF8 File Offset: 0x00148EF8
		static readonly int snxtSJth7i;

		// Token: 0x0404FBF0 RID: 326640 RVA: 0x0014AD00 File Offset: 0x00148F00
		static readonly int 9qNnZ97eOG;

		// Token: 0x0404FBF1 RID: 326641 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int LtmY8WBwCD;

		// Token: 0x0404FBF2 RID: 326642 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1GQFCYyn9x;

		// Token: 0x0404FBF3 RID: 326643 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 8qlX4ynLRI;

		// Token: 0x0404FBF4 RID: 326644 RVA: 0x0014AD08 File Offset: 0x00148F08
		static readonly int Ire4E8AZv5;

		// Token: 0x0404FBF5 RID: 326645 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int I6f4q3aHkB;

		// Token: 0x0404FBF6 RID: 326646 RVA: 0x0014AD10 File Offset: 0x00148F10
		static readonly int LTfaHfIPeJ;

		// Token: 0x0404FBF7 RID: 326647 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int tze34KlVAD;

		// Token: 0x0404FBF8 RID: 326648 RVA: 0x0014AD18 File Offset: 0x00148F18
		static readonly int XZ2DpBLrqA;

		// Token: 0x0404FBF9 RID: 326649 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int YfkP7yLEwj;

		// Token: 0x0404FBFA RID: 326650 RVA: 0x0014AD20 File Offset: 0x00148F20
		static readonly int 0v5mMSbl9g;

		// Token: 0x0404FBFB RID: 326651 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int REHhovbbuG;

		// Token: 0x0404FBFC RID: 326652 RVA: 0x0014AD28 File Offset: 0x00148F28
		static readonly int UaidvNPO5G;

		// Token: 0x0404FBFD RID: 326653 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 8hjaNmeP0X;

		// Token: 0x0404FBFE RID: 326654 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jjsKsTYDlM;

		// Token: 0x0404FBFF RID: 326655 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int WtTqPZMb08;

		// Token: 0x0404FC00 RID: 326656 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int CMp2hufqTC;

		// Token: 0x0404FC01 RID: 326657 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int QLkXgusYub;

		// Token: 0x0404FC02 RID: 326658 RVA: 0x0014AD30 File Offset: 0x00148F30
		static readonly int zMnttPO2Lx;

		// Token: 0x0404FC03 RID: 326659 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ZCZ2UW4zn8;

		// Token: 0x0404FC04 RID: 326660 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int xrtj5KJ5Kf;

		// Token: 0x0404FC05 RID: 326661 RVA: 0x0014AD38 File Offset: 0x00148F38
		static readonly int ryrYJ0j6JS;

		// Token: 0x0404FC06 RID: 326662 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gmfgmOwsDJ;

		// Token: 0x0404FC07 RID: 326663 RVA: 0x0014AD40 File Offset: 0x00148F40
		static readonly int 03uwoIdExi;

		// Token: 0x0404FC08 RID: 326664 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int GSspGlVAsd;

		// Token: 0x0404FC09 RID: 326665 RVA: 0x0014AD48 File Offset: 0x00148F48
		static readonly int x8pVcKLM6r;

		// Token: 0x0404FC0A RID: 326666 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Ya2BpxD4uB;

		// Token: 0x0404FC0B RID: 326667 RVA: 0x0014AD40 File Offset: 0x00148F40
		static readonly int XeIkLN40ZA;

		// Token: 0x0404FC0C RID: 326668 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2wAjV2NZUd;

		// Token: 0x0404FC0D RID: 326669 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6QHGKparAS;

		// Token: 0x0404FC0E RID: 326670 RVA: 0x0014AD50 File Offset: 0x00148F50
		static readonly int ibPrGSzFJO;

		// Token: 0x0404FC0F RID: 326671 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int QVw6zlaSpx;

		// Token: 0x0404FC10 RID: 326672 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kokREGXCag;

		// Token: 0x0404FC11 RID: 326673 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int wNzHcbgScC;

		// Token: 0x0404FC12 RID: 326674 RVA: 0x0014AD58 File Offset: 0x00148F58
		static readonly int CIPFNkdLQi;

		// Token: 0x0404FC13 RID: 326675 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int PIBNs308mA;

		// Token: 0x0404FC14 RID: 326676 RVA: 0x0014AD60 File Offset: 0x00148F60
		static readonly int 5xoncCgpdX;

		// Token: 0x0404FC15 RID: 326677 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int FH0mubYfDd;

		// Token: 0x0404FC16 RID: 326678 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mMv1QoLmYi;

		// Token: 0x0404FC17 RID: 326679 RVA: 0x0014AD68 File Offset: 0x00148F68
		static readonly int khpbHOdmmK;

		// Token: 0x0404FC18 RID: 326680 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Exr2dHRYcQ;

		// Token: 0x0404FC19 RID: 326681 RVA: 0x0014AD70 File Offset: 0x00148F70
		static readonly int eV4IXtCwXy;

		// Token: 0x0404FC1A RID: 326682 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 03R4xhcYfg;

		// Token: 0x0404FC1B RID: 326683 RVA: 0x0014AD78 File Offset: 0x00148F78
		static readonly int 8w22Zye2YI;

		// Token: 0x0404FC1C RID: 326684 RVA: 0x0014AD58 File Offset: 0x00148F58
		static readonly int WxKHEPmgDX;

		// Token: 0x0404FC1D RID: 326685 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int MqPyULgwF6;

		// Token: 0x0404FC1E RID: 326686 RVA: 0x0014AD68 File Offset: 0x00148F68
		static readonly int p335SsdCtj;

		// Token: 0x0404FC1F RID: 326687 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int OJYObDtJ0i;

		// Token: 0x0404FC20 RID: 326688 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 45UHTRhDiN;

		// Token: 0x0404FC21 RID: 326689 RVA: 0x0014AD78 File Offset: 0x00148F78
		static readonly int Srwccd3OyV;

		// Token: 0x0404FC22 RID: 326690 RVA: 0x0014AD80 File Offset: 0x00148F80
		static readonly int vkweJCSAWQ;

		// Token: 0x0404FC23 RID: 326691 RVA: 0x0014AD88 File Offset: 0x00148F88
		static readonly int bW6hBuivmB;

		// Token: 0x0404FC24 RID: 326692 RVA: 0x0014AD90 File Offset: 0x00148F90
		static readonly int KZdfRgX6v8;

		// Token: 0x0404FC25 RID: 326693 RVA: 0x0014AD98 File Offset: 0x00148F98
		static readonly int JfUfwTIz8R;

		// Token: 0x0404FC26 RID: 326694 RVA: 0x0014ADA0 File Offset: 0x00148FA0
		static readonly int 9hqRw5vPas;

		// Token: 0x0404FC27 RID: 326695 RVA: 0x0014ADA8 File Offset: 0x00148FA8
		static readonly int 4ImxKWGQNm;

		// Token: 0x0404FC28 RID: 326696 RVA: 0x0014ADB0 File Offset: 0x00148FB0
		static readonly int pVOXH6Bbvs;

		// Token: 0x0404FC29 RID: 326697 RVA: 0x0014ADB8 File Offset: 0x00148FB8
		static readonly int lsxUCnsMtV;

		// Token: 0x0404FC2A RID: 326698 RVA: 0x0014ADC0 File Offset: 0x00148FC0
		static readonly int vHfDEB2hUZ;

		// Token: 0x0404FC2B RID: 326699 RVA: 0x0014ADC8 File Offset: 0x00148FC8
		static readonly int M1mVlnSTKz;

		// Token: 0x0404FC2C RID: 326700 RVA: 0x0014ADD0 File Offset: 0x00148FD0
		static readonly int 3UesHLURvh;

		// Token: 0x0404FC2D RID: 326701 RVA: 0x0014ADD8 File Offset: 0x00148FD8
		static readonly int n4g11h0LTF;

		// Token: 0x0404FC2E RID: 326702 RVA: 0x0014ADE0 File Offset: 0x00148FE0
		static readonly int DeGVftGbtY;

		// Token: 0x0404FC2F RID: 326703 RVA: 0x0014ADE8 File Offset: 0x00148FE8
		static readonly int VZC4banx53;

		// Token: 0x0404FC30 RID: 326704 RVA: 0x0014ADF0 File Offset: 0x00148FF0
		static readonly int rlvxwRVueD;

		// Token: 0x0404FC31 RID: 326705 RVA: 0x0014ADF8 File Offset: 0x00148FF8
		static readonly int xG9EvZNIMX;

		// Token: 0x0404FC32 RID: 326706 RVA: 0x0014AE00 File Offset: 0x00149000
		static readonly int E3hWLN2maa;

		// Token: 0x0404FC33 RID: 326707 RVA: 0x0014AE08 File Offset: 0x00149008
		static readonly int 4DPZYbsTiN;

		// Token: 0x0404FC34 RID: 326708 RVA: 0x0014AE10 File Offset: 0x00149010
		static readonly int YV6plOZ7JC;

		// Token: 0x0404FC35 RID: 326709 RVA: 0x0014AE18 File Offset: 0x00149018
		static readonly int MekiyxEZli;

		// Token: 0x0404FC36 RID: 326710 RVA: 0x0014AE20 File Offset: 0x00149020
		static readonly int ZsUEJu0kqT;

		// Token: 0x0404FC37 RID: 326711 RVA: 0x0014AE28 File Offset: 0x00149028
		static readonly int r4k98s61v6;

		// Token: 0x0404FC38 RID: 326712 RVA: 0x0014AE30 File Offset: 0x00149030
		static readonly int x4dYNZcrlk;

		// Token: 0x0404FC39 RID: 326713 RVA: 0x0014AE38 File Offset: 0x00149038
		static readonly int XTrAypB2g1;

		// Token: 0x0404FC3A RID: 326714 RVA: 0x0014AE40 File Offset: 0x00149040
		static readonly int YzRzVS4kjF;

		// Token: 0x0404FC3B RID: 326715 RVA: 0x0014AE48 File Offset: 0x00149048
		static readonly int 1MnpueP50t;

		// Token: 0x0404FC3C RID: 326716 RVA: 0x0014AE50 File Offset: 0x00149050
		static readonly int RJ9F5XMkLT;

		// Token: 0x0404FC3D RID: 326717 RVA: 0x0014AE58 File Offset: 0x00149058
		static readonly int rEV3i8nnD5;

		// Token: 0x0404FC3E RID: 326718 RVA: 0x0014AE60 File Offset: 0x00149060
		static readonly int e1HftLpCPT;

		// Token: 0x0404FC3F RID: 326719 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ZFCwkO0L37;

		// Token: 0x0404FC40 RID: 326720 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int FUZQYx0uGw;

		// Token: 0x0404FC41 RID: 326721 RVA: 0x0014AE68 File Offset: 0x00149068
		static readonly int 1m24OZCdWt;

		// Token: 0x0404FC42 RID: 326722 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int sKU13lBiTT;

		// Token: 0x0404FC43 RID: 326723 RVA: 0x0014AE70 File Offset: 0x00149070
		static readonly int HbtGzKc1G6;

		// Token: 0x0404FC44 RID: 326724 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int V55ccxNHiL;

		// Token: 0x0404FC45 RID: 326725 RVA: 0x0014AE78 File Offset: 0x00149078
		static readonly int MWzJO59iXw;

		// Token: 0x0404FC46 RID: 326726 RVA: 0x0014AE68 File Offset: 0x00149068
		static readonly int vSaxoZ2wFE;

		// Token: 0x0404FC47 RID: 326727 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 6LWaYxO2ZF;

		// Token: 0x0404FC48 RID: 326728 RVA: 0x0014AE78 File Offset: 0x00149078
		static readonly int Y4AIHumj13;

		// Token: 0x0404FC49 RID: 326729 RVA: 0x0014AE80 File Offset: 0x00149080
		static readonly int K4dTKDeIxD;

		// Token: 0x0404FC4A RID: 326730 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 5aCdOBAZvb;

		// Token: 0x0404FC4B RID: 326731 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int rHISY1RSp4;

		// Token: 0x0404FC4C RID: 326732 RVA: 0x0014AE88 File Offset: 0x00149088
		static readonly int xS5L4CrCPV;

		// Token: 0x0404FC4D RID: 326733 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int SGEWJ71g3G;

		// Token: 0x0404FC4E RID: 326734 RVA: 0x0014AE90 File Offset: 0x00149090
		static readonly int uMyaMCvL5T;

		// Token: 0x0404FC4F RID: 326735 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int vMd3Qmf0jL;

		// Token: 0x0404FC50 RID: 326736 RVA: 0x0014AE98 File Offset: 0x00149098
		static readonly int T7JZIlDwIa;

		// Token: 0x0404FC51 RID: 326737 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 9uYiJkdf91;

		// Token: 0x0404FC52 RID: 326738 RVA: 0x0014AEA0 File Offset: 0x001490A0
		static readonly int RfH6kGmLGg;

		// Token: 0x0404FC53 RID: 326739 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int cB7sxxDZRl;

		// Token: 0x0404FC54 RID: 326740 RVA: 0x0014AE90 File Offset: 0x00149090
		static readonly int 98DeUAy4tp;

		// Token: 0x0404FC55 RID: 326741 RVA: 0x0014AE98 File Offset: 0x00149098
		static readonly int JA1r4x0NyC;

		// Token: 0x0404FC56 RID: 326742 RVA: 0x0014AEA8 File Offset: 0x001490A8
		static readonly int 82ql88xpvW;

		// Token: 0x0404FC57 RID: 326743 RVA: 0x0014AEB0 File Offset: 0x001490B0
		static readonly int gENY2Scmlk;

		// Token: 0x0404FC58 RID: 326744 RVA: 0x0014AEB8 File Offset: 0x001490B8
		static readonly int SsbaXcJQy9;

		// Token: 0x0404FC59 RID: 326745 RVA: 0x0014AEC0 File Offset: 0x001490C0
		static readonly int 7zkOmHScgV;

		// Token: 0x0404FC5A RID: 326746 RVA: 0x0014AEC8 File Offset: 0x001490C8
		static readonly int NIJXIFwdyl;

		// Token: 0x0404FC5B RID: 326747 RVA: 0x0014AED0 File Offset: 0x001490D0
		static readonly int VNlOuPaQNf;

		// Token: 0x0404FC5C RID: 326748 RVA: 0x0014AED8 File Offset: 0x001490D8
		static readonly int yg1wZrd8vu;

		// Token: 0x0404FC5D RID: 326749 RVA: 0x0014AEE0 File Offset: 0x001490E0
		static readonly int AAFPWJjDRS;

		// Token: 0x0404FC5E RID: 326750 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int pqbMntOVeX;

		// Token: 0x0404FC5F RID: 326751 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int qCOBhqQW8b;

		// Token: 0x0404FC60 RID: 326752 RVA: 0x0014AEE8 File Offset: 0x001490E8
		static readonly int lxsDlVHV1k;

		// Token: 0x0404FC61 RID: 326753 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int qX85zIEpIp;

		// Token: 0x0404FC62 RID: 326754 RVA: 0x0014AEF0 File Offset: 0x001490F0
		static readonly int cIeYE8vEsq;

		// Token: 0x0404FC63 RID: 326755 RVA: 0x0014AEF8 File Offset: 0x001490F8
		static readonly int 3MFzr28XkS;

		// Token: 0x0404FC64 RID: 326756 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int m2d3qTDTLY;

		// Token: 0x0404FC65 RID: 326757 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lkOS9cST9n;

		// Token: 0x0404FC66 RID: 326758 RVA: 0x0014AF00 File Offset: 0x00149100
		static readonly int kCmLreRJN7;

		// Token: 0x0404FC67 RID: 326759 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int KrF0Djokrv;

		// Token: 0x0404FC68 RID: 326760 RVA: 0x0014AF08 File Offset: 0x00149108
		static readonly int 4b3UES7x0O;

		// Token: 0x0404FC69 RID: 326761 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int joY6sjQSMM;

		// Token: 0x0404FC6A RID: 326762 RVA: 0x0014AF10 File Offset: 0x00149110
		static readonly int B3FNO4fYOZ;

		// Token: 0x0404FC6B RID: 326763 RVA: 0x0014AF18 File Offset: 0x00149118
		static readonly int ysmOsIISHY;

		// Token: 0x0404FC6C RID: 326764 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int geT9XgTIHd;

		// Token: 0x0404FC6D RID: 326765 RVA: 0x0014AF20 File Offset: 0x00149120
		static readonly int TWYftBWpFJ;

		// Token: 0x0404FC6E RID: 326766 RVA: 0x0014AEE8 File Offset: 0x001490E8
		static readonly int xjiaa1CJOk;

		// Token: 0x0404FC6F RID: 326767 RVA: 0x0014AF28 File Offset: 0x00149128
		static readonly int a7KyqhkGzr;

		// Token: 0x0404FC70 RID: 326768 RVA: 0x0014AF30 File Offset: 0x00149130
		static readonly int lXQuFbTHfr;

		// Token: 0x0404FC71 RID: 326769 RVA: 0x0014AF00 File Offset: 0x00149100
		static readonly int vdM7l652jg;

		// Token: 0x0404FC72 RID: 326770 RVA: 0x0014AF08 File Offset: 0x00149108
		static readonly int eJ4hDWLkyL;

		// Token: 0x0404FC73 RID: 326771 RVA: 0x0014AF38 File Offset: 0x00149138
		static readonly int bPzXiaTxV8;

		// Token: 0x0404FC74 RID: 326772 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int h4ogy7uNMt;

		// Token: 0x0404FC75 RID: 326773 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mrhTNcdsrs;

		// Token: 0x0404FC76 RID: 326774 RVA: 0x0014AF40 File Offset: 0x00149140
		static readonly int QtSTQgnyZL;

		// Token: 0x0404FC77 RID: 326775 RVA: 0x0014AF48 File Offset: 0x00149148
		static readonly int nHhk8jeXtF;

		// Token: 0x0404FC78 RID: 326776 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int l8XEiusgKG;

		// Token: 0x0404FC79 RID: 326777 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 6kFmsymUQR;

		// Token: 0x0404FC7A RID: 326778 RVA: 0x0014AF50 File Offset: 0x00149150
		static readonly int T5yBGeJ6Uo;

		// Token: 0x0404FC7B RID: 326779 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7F8lHRVOug;

		// Token: 0x0404FC7C RID: 326780 RVA: 0x0014AF58 File Offset: 0x00149158
		static readonly int xHoTOCB52K;

		// Token: 0x0404FC7D RID: 326781 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 7JHbwqKV7E;

		// Token: 0x0404FC7E RID: 326782 RVA: 0x0014AF60 File Offset: 0x00149160
		static readonly int kwLfI1lefa;

		// Token: 0x0404FC7F RID: 326783 RVA: 0x0014AF68 File Offset: 0x00149168
		static readonly int cYjteMRexD;

		// Token: 0x0404FC80 RID: 326784 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int cNDKrx7hza;

		// Token: 0x0404FC81 RID: 326785 RVA: 0x0014AF70 File Offset: 0x00149170
		static readonly int H9Qq5B5IKW;

		// Token: 0x0404FC82 RID: 326786 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bhacrjkX7j;

		// Token: 0x0404FC83 RID: 326787 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Ypi4lXsByU;

		// Token: 0x0404FC84 RID: 326788 RVA: 0x0014AF78 File Offset: 0x00149178
		static readonly int 3EoESdI3yc;

		// Token: 0x0404FC85 RID: 326789 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int QIUam4wkcI;

		// Token: 0x0404FC86 RID: 326790 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int NkjPBbbVEi;

		// Token: 0x0404FC87 RID: 326791 RVA: 0x0014AF80 File Offset: 0x00149180
		static readonly int S3UzcX3WJO;

		// Token: 0x0404FC88 RID: 326792 RVA: 0x0014AF50 File Offset: 0x00149150
		static readonly int bqieTQVHRr;

		// Token: 0x0404FC89 RID: 326793 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kHiqHTeZC1;

		// Token: 0x0404FC8A RID: 326794 RVA: 0x0014AF88 File Offset: 0x00149188
		static readonly int BwyQKWye8P;

		// Token: 0x0404FC8B RID: 326795 RVA: 0x0014AF90 File Offset: 0x00149190
		static readonly int BabOrgBF6v;

		// Token: 0x0404FC8C RID: 326796 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int GUEX7KVnsJ;

		// Token: 0x0404FC8D RID: 326797 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 2dTSMp2SU6;

		// Token: 0x0404FC8E RID: 326798 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int c0JCpJqU9k;

		// Token: 0x0404FC8F RID: 326799 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int RYcRurrbS9;

		// Token: 0x0404FC90 RID: 326800 RVA: 0x0014AF98 File Offset: 0x00149198
		static readonly int BKvyWhGIBC;

		// Token: 0x0404FC91 RID: 326801 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int osv9SQKCry;

		// Token: 0x0404FC92 RID: 326802 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int eAoI1eACif;

		// Token: 0x0404FC93 RID: 326803 RVA: 0x0014AFA0 File Offset: 0x001491A0
		static readonly int 7aAU4REUpH;

		// Token: 0x0404FC94 RID: 326804 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ChS75jnd8e;

		// Token: 0x0404FC95 RID: 326805 RVA: 0x0014AFA8 File Offset: 0x001491A8
		static readonly int gptdeAgn62;

		// Token: 0x0404FC96 RID: 326806 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int gEkgEOsaEB;

		// Token: 0x0404FC97 RID: 326807 RVA: 0x0014AFB0 File Offset: 0x001491B0
		static readonly int L0Wkv7rqMS;

		// Token: 0x0404FC98 RID: 326808 RVA: 0x0014AFA0 File Offset: 0x001491A0
		static readonly int 0hEE8Rqg03;

		// Token: 0x0404FC99 RID: 326809 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int vaYwk86w2r;

		// Token: 0x0404FC9A RID: 326810 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 0MY7SqSJsh;

		// Token: 0x0404FC9B RID: 326811 RVA: 0x0014AFB8 File Offset: 0x001491B8
		static readonly int TzboB99ghw;

		// Token: 0x0404FC9C RID: 326812 RVA: 0x0014AFC0 File Offset: 0x001491C0
		static readonly int hLkKPuck9w;

		// Token: 0x0404FC9D RID: 326813 RVA: 0x0014AFC8 File Offset: 0x001491C8
		static readonly int A5yeboJHvS;

		// Token: 0x0404FC9E RID: 326814 RVA: 0x0014AFD0 File Offset: 0x001491D0
		static readonly int 9hySk69uul;

		// Token: 0x0404FC9F RID: 326815 RVA: 0x0014AFD8 File Offset: 0x001491D8
		static readonly int 8aOFKpmNrh;

		// Token: 0x0404FCA0 RID: 326816 RVA: 0x0014AFE0 File Offset: 0x001491E0
		static readonly int OsK5hXA6MX;

		// Token: 0x0404FCA1 RID: 326817 RVA: 0x0014AFE8 File Offset: 0x001491E8
		static readonly int 02uPx9XRkT;
	}
}
