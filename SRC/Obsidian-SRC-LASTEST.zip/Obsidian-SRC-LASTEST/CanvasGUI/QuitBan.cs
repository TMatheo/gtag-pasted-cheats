﻿using System;
using HarmonyLib;

namespace CanvasGUI
{
	// Token: 0x0200002F RID: 47
	[HarmonyPatch(typeof(GorillaGameManager), "ForceStopGame_DisconnectAndDestroy")]
	public class QuitBan
	{
		// Token: 0x060001D5 RID: 469 RVA: 0x00642258 File Offset: 0x00640458
		private unsafe static bool Prefix()
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			if ((*(&QuitBan.qVCvKkJ1H8) ^ *(&QuitBan.qVCvKkJ1H8)) != 0)
			{
				goto IL_24;
			}
			goto IL_A7C;
			uint num2;
			int[] array9;
			bool result;
			for (;;)
			{
				IL_29:
				uint num;
				switch ((num = (num2 ^ (uint)(*(&QuitBan.VZ79LOa9tF)))) % (uint)(*(&QuitBan.E9SEU7gbEU)))
				{
				case 0U:
					num2 = 2630397875U;
					continue;
				case 1U:
				{
					int num4;
					int num3 = num4 / 450;
					uint[] array = new uint[*(&QuitBan.4UzuTAK9qF)];
					array[*(&QuitBan.ppugwxgzmg)] = (uint)(*(&QuitBan.7OpiWd8eKR));
					array[*(&QuitBan.AN1XPXLdZb)] = (uint)(*(&QuitBan.n4nJ6O2fM6));
					array[*(&QuitBan.5NK8SqoQY0)] = (uint)(*(&QuitBan.CqyZEcyWQZ));
					array[*(&QuitBan.mCaL3CkgmH) + *(&QuitBan.kdRNVxC2Fj)] = (uint)(*(&QuitBan.s4FiY7FOEe));
					array[*(&QuitBan.afOxT2w9FP)] = (uint)(*(&QuitBan.FHoQPjYlDR) + *(&QuitBan.Z5Rrqs72w5));
					uint num5 = num * array[*(&QuitBan.7WcIrFOe3c)];
					uint num6 = ((num5 ^ (uint)(*(&QuitBan.ADx0dlQyTz))) | (uint)(*(&QuitBan.ieKwEeOhGl))) + (uint)(*(&QuitBan.54MJRtpfjK));
					num2 = ((num6 | array[*(&QuitBan.U4rlQWIbNF) + *(&QuitBan.bIi7WdMpEM)]) ^ (uint)(*(&QuitBan.0rXRgG0niu) + *(&QuitBan.6uOJeowjgr)));
					continue;
				}
				case 2U:
				{
					uint num7 = num | (uint)(*(&QuitBan.aBe3dEcWvZ) + *(&QuitBan.NHgC0d26Gc));
					uint num8 = num7 | (uint)(*(&QuitBan.LJuFjit3Nv) + *(&QuitBan.8OhDvZJmVJ));
					num2 = (((num8 & (uint)(*(&QuitBan.UlGTLHdZDj))) ^ (uint)(*(&QuitBan.ql4CeQQYT4))) * (uint)(*(&QuitBan.UiI9a8kdRb)) * (uint)(*(&QuitBan.UQk6HjDa4b)) ^ (uint)(*(&QuitBan.EUzoFXUfie)));
					continue;
				}
				case 3U:
				{
					int num9;
					int num4 = num9 ^ 1176334305;
					uint num10 = ((num ^ (uint)(*(&QuitBan.JL1dPCdRQe))) & (uint)(*(&QuitBan.RgKW0r1ekX))) ^ (uint)(*(&QuitBan.QuCTTKcdFy));
					num2 = ((num10 ^ (uint)(*(&QuitBan.fC4NcG1ySw))) * (uint)(*(&QuitBan.3mRor5AAT8)) + (uint)(*(&QuitBan.qeZ6NZJiKF)) ^ (uint)(*(&QuitBan.j9Lc9Ol63u)));
					continue;
				}
				case 5U:
				{
					int num3;
					int num9;
					int num4 = num9 | num3;
					uint[] array2 = new uint[*(&QuitBan.ouqqOShNSd) + *(&QuitBan.yqi4pxCS43)];
					array2[*(&QuitBan.m5QoquyNqn)] = (uint)(*(&QuitBan.vgVq8beU8h));
					array2[*(&QuitBan.7XHFT0H31P)] = (uint)(*(&QuitBan.zCNjfseCAe) + *(&QuitBan.eUhpsSV25O));
					array2[*(&QuitBan.SrTX6PxKV0)] = (uint)(*(&QuitBan.m5VaytSvKP));
					array2[*(&QuitBan.6cUeCnzcXB) + *(&QuitBan.eP7n6Hs0nQ)] = (uint)(*(&QuitBan.5TrK1j8H09));
					uint num11 = num & (uint)(*(&QuitBan.9krpR0XzUS));
					uint num12 = num11 & array2[*(&QuitBan.aUxTVX7sdr)];
					num2 = (((num12 | array2[*(&QuitBan.AcI4UmvKnd) + *(&QuitBan.osmXB4hRWG)]) & (uint)(*(&QuitBan.t3fUzkgXyd))) ^ (uint)(*(&QuitBan.lQnJ8hbwVo)));
					continue;
				}
				case 6U:
					goto IL_A7C;
				case 7U:
				{
					int num3;
					int num9;
					num3 &= num9;
					uint[] array3 = new uint[*(&QuitBan.i7hCVvIjg4)];
					array3[*(&QuitBan.nNu12UqYaM)] = (uint)(*(&QuitBan.iRTrB6xs1a));
					array3[*(&QuitBan.p4vaLx2PUj)] = (uint)(*(&QuitBan.bcxhcv1VYe));
					array3[*(&QuitBan.LbQ2QRn0AZ) + *(&QuitBan.7ZsFOscTqF)] = (uint)(*(&QuitBan.baD1uGdwOQ));
					array3[*(&QuitBan.FbTWPNo3J3)] = (uint)(*(&QuitBan.JBP5lBtsSu));
					num2 = ((num * array3[*(&QuitBan.ShpTCuXYHK)] * array3[*(&QuitBan.x1ltTgGV0B)] & (uint)(*(&QuitBan.DiJw6ZKHPs))) + array3[*(&QuitBan.Wvde7hwATe)] ^ (uint)(*(&QuitBan.zPv9GRafmF) + *(&QuitBan.5X1RqtX2Wn)));
					continue;
				}
				case 8U:
				{
					int num3 = *(ref QuitBan.sMmToPHViG + (IntPtr)num3);
					int num4;
					int[] array4;
					array4[num4 + 7 - num4] = num4 - 4;
					uint[] array5 = new uint[*(&QuitBan.kPJYyBYHwv)];
					array5[*(&QuitBan.tFBWLxxKqo)] = (uint)(*(&QuitBan.9ofKw84LxN));
					array5[*(&QuitBan.K4oq3jGXLF)] = (uint)(*(&QuitBan.3St0V0WfG2));
					array5[*(&QuitBan.6NMsn5u9lz)] = (uint)(*(&QuitBan.HMTilzaUcl));
					array5[*(&QuitBan.rZ9kvq5py6)] = (uint)(*(&QuitBan.mYE4R6r6D8));
					array5[*(&QuitBan.zHvV7q9LOg)] = (uint)(*(&QuitBan.ZBCfLgNl66));
					uint num13 = num + (uint)(*(&QuitBan.AFLpNsIYQo));
					uint num14 = num13 + (uint)(*(&QuitBan.IeRdvkonnE));
					uint num15 = num14 - array5[*(&QuitBan.rtaRglWjtu)] + (uint)(*(&QuitBan.sF9G8u5GIP));
					num2 = (num15 ^ array5[*(&QuitBan.ik4kY4tjtl) + *(&QuitBan.2k82PQo3Im)] ^ (uint)(*(&QuitBan.Wipg6CfKfB)));
					continue;
				}
				case 9U:
					goto IL_24;
				case 10U:
				{
					int[] array6 = new int[10];
					int[] array4 = new int[10];
					int num4;
					int num9;
					array6[num4 + 7 - num4] = (num9 | 8);
					num9 -= 686;
					int num3;
					*(ref num9 + (IntPtr)num3) = num3;
					uint[] array7 = new uint[*(&QuitBan.0ME5IVmzCn) + *(&QuitBan.mR7QEzx4XS)];
					array7[*(&QuitBan.0LSzoMiODU)] = (uint)(*(&QuitBan.2sXc9JUB00));
					array7[*(&QuitBan.lk7GcwCBAf)] = (uint)(*(&QuitBan.KlDveo3PR6));
					array7[*(&QuitBan.xXwrv34eQ5)] = (uint)(*(&QuitBan.ewEhqPNMW2));
					array7[*(&QuitBan.JgOhKQol8U)] = (uint)(*(&QuitBan.PFu3COxQUj));
					array7[*(&QuitBan.1ivEAXhgEO)] = (uint)(*(&QuitBan.br2ZxRIPge));
					uint num16 = (num | array7[*(&QuitBan.PSg6pZCLec)]) - array7[*(&QuitBan.b61xAluJgx)];
					uint num17 = num16 * array7[*(&QuitBan.sIht2hMUFv) + *(&QuitBan.Fiu0TjBzYk)];
					num2 = ((num17 + array7[*(&QuitBan.VWBmxfzFYL)]) * (uint)(*(&QuitBan.g9stvHvwDI)) ^ (uint)(*(&QuitBan.NrFsX3LBda)));
					continue;
				}
				case 11U:
				{
					int num9;
					int num4 = num9 * 43;
					int num3;
					num2 = (((num3 > num3) ? 1914139062U : 1806076806U) ^ num * 912149801U);
					continue;
				}
				case 12U:
				{
					int num9;
					num9 |= 1345157500;
					int num3;
					num3 -= 81;
					int num4;
					num3 = *(ref num4 + (IntPtr)num3);
					uint num18 = num | (uint)(*(&QuitBan.oifXgGz03l));
					uint num19 = num18 - (uint)(*(&QuitBan.1w0H1IHH1s));
					num2 = (((num19 ^ (uint)(*(&QuitBan.FC7g2A5YoW))) * (uint)(*(&QuitBan.ZjDs6UEkVI)) | (uint)(*(&QuitBan.byAhujrhox) + *(&QuitBan.4YSw5mk9eg))) ^ (uint)(*(&QuitBan.LbMhMStIKh)));
					continue;
				}
				case 13U:
				{
					int num9;
					*(ref QuitBan.sMmToPHViG + (IntPtr)num9) = num9;
					num2 = 3860749695U;
					continue;
				}
				case 14U:
				{
					int num3;
					int num9;
					*(ref num9 + (IntPtr)num3) = num3;
					num2 = (((num9 <= num9) ? 1768879922U : 1858009550U) ^ num * 398609282U);
					continue;
				}
				case 15U:
				{
					int num3;
					int num4 = num3;
					uint[] array8 = new uint[*(&QuitBan.HDbHcFDo5d) + *(&QuitBan.IZLdTN7wVM)];
					array8[*(&QuitBan.UcEClPSdqk)] = (uint)(*(&QuitBan.OndCq3QZFJ));
					array8[*(&QuitBan.kiyJK0btOh)] = (uint)(*(&QuitBan.ALjJno8ZgN) + *(&QuitBan.wk8VPe5Jwa));
					array8[*(&QuitBan.7hqLmwo52v) + *(&QuitBan.xiOIjCEUYC)] = (uint)(*(&QuitBan.4132W9kc4p) + *(&QuitBan.4S7yjcfXh1));
					num2 = ((num | (uint)(*(&QuitBan.9DgvZOVzvN)) | (uint)(*(&QuitBan.alutfGoyzm))) + array8[*(&QuitBan.MLAN0flajH)] ^ (uint)(*(&QuitBan.hqxhD1VIdI)));
					continue;
				}
				case 16U:
					num2 = 3043899409U;
					continue;
				case 17U:
				{
					result = (array9[0] != 0);
					uint[] array10 = new uint[*(&QuitBan.BUZ3qArcAW)];
					array10[*(&QuitBan.X8TNndVgWQ)] = (uint)(*(&QuitBan.u6McFPRJif) + *(&QuitBan.yCJNLxCAuO));
					array10[*(&QuitBan.UyltEYG0pP)] = (uint)(*(&QuitBan.zenJSEI7xb));
					array10[*(&QuitBan.sh4ehVyFCz) + *(&QuitBan.bVwH66VcXr)] = (uint)(*(&QuitBan.JadSqUZ95G));
					array10[*(&QuitBan.pENTfw4HMs) + *(&QuitBan.jAy0yesfNW)] = (uint)(*(&QuitBan.tpjFRSDlyN));
					uint num20 = num | (uint)(*(&QuitBan.6zK5JWHcmK));
					uint num21 = num20 & array10[*(&QuitBan.BNQoHIlmeL)];
					num2 = ((num21 + (uint)(*(&QuitBan.l4wiXAfHBN)) & array10[*(&QuitBan.sTS8wu03rc)]) ^ (uint)(*(&QuitBan.WP2CVgY48J)));
					continue;
				}
				case 18U:
				{
					int num3;
					int num9 = num3 - num9;
					uint[] array11 = new uint[*(&QuitBan.ENL0orsZSb)];
					array11[*(&QuitBan.zpVX7H6yEt)] = (uint)(*(&QuitBan.GXVJ2XFcZe));
					array11[*(&QuitBan.cu6rBfropI)] = (uint)(*(&QuitBan.1GFXn54PL1) + *(&QuitBan.knslhr2B8R));
					array11[*(&QuitBan.mQAx8EtnVb) + *(&QuitBan.ZRI62AS8g6)] = (uint)(*(&QuitBan.czQh3yCVKU));
					array11[*(&QuitBan.nqqYflFRYj)] = (uint)(*(&QuitBan.MR4ubTfvsg));
					uint num22 = num * array11[*(&QuitBan.Y3fCyx9c4J)];
					uint num23 = num22 * (uint)(*(&QuitBan.CXdBxsluaQ));
					uint num24 = num23 - (uint)(*(&QuitBan.5Bj6uL5gGk));
					num2 = ((num24 & array11[*(&QuitBan.TQmn5tLnjs) + *(&QuitBan.mmXOgyx26t)]) ^ (uint)(*(&QuitBan.rvUclXTiSm) + *(&QuitBan.1cWT0vuzFD)));
					continue;
				}
				case 19U:
					num2 = 2863930830U;
					continue;
				case 20U:
				{
					int num3;
					*(ref QuitBan.sMmToPHViG + (IntPtr)num3) = num3;
					int num4;
					int num9 = -num4;
					int[] array6;
					num4 = array6[num3 + 8 - num3] + 4;
					num2 = (((num3 <= num3) ? 3760198870U : 2362669327U) ^ num * 2670134639U);
					continue;
				}
				case 21U:
				{
					uint num25 = (num | (uint)(*(&QuitBan.qbHnlCClhI))) & (uint)(*(&QuitBan.0AbYbr4S2W));
					uint num26 = num25 & (uint)(*(&QuitBan.Rs5ByWBtM1));
					uint num27 = (num26 & (uint)(*(&QuitBan.mkJ2hRLpWu))) ^ (uint)(*(&QuitBan.sOVjlWydln) + *(&QuitBan.lGCl17gFyP));
					num2 = (num27 ^ (uint)(*(&QuitBan.ASZqgP1i1K)) ^ (uint)(*(&QuitBan.gO5HoDWVac)));
					continue;
				}
				case 22U:
					num2 = 2428764838U;
					continue;
				case 23U:
				{
					int num9;
					int num3 = num9;
					uint[] array12 = new uint[*(&QuitBan.0vBpFLl4kd)];
					array12[*(&QuitBan.JmV1skI17i)] = (uint)(*(&QuitBan.Aw0blEX4xB));
					array12[*(&QuitBan.2RywJuRgiG)] = (uint)(*(&QuitBan.mlQzRvXkqV));
					array12[*(&QuitBan.Ti98pE4jDB) + *(&QuitBan.yqHjl2yir7)] = (uint)(*(&QuitBan.TmT15ZfBJ0));
					num2 = (num * (uint)(*(&QuitBan.qxNcrURzHF)) * array12[*(&QuitBan.zrchR5drOZ)] + array12[*(&QuitBan.7y2sCrOICP) + *(&QuitBan.j3aNUBcp2Q)] ^ (uint)(*(&QuitBan.k8bmImKwjA)));
					continue;
				}
				case 24U:
				{
					int num9 = (int)((byte)num9);
					uint num28 = (num | (uint)(*(&QuitBan.uSI1UCmz5i))) - (uint)(*(&QuitBan.z4c2ZKtUC4));
					uint num29 = num28 & (uint)(*(&QuitBan.xJQxZPDAln) + *(&QuitBan.t8EvxklvwA));
					uint num30 = num29 * (uint)(*(&QuitBan.iBAqRel0Qu));
					num2 = (num30 ^ (uint)(*(&QuitBan.uZSqVkCUcF)) ^ (uint)(*(&QuitBan.8lNRy1zqEz)));
					continue;
				}
				case 25U:
				{
					int num3;
					int num4 = num3;
					int num9;
					int[] array4;
					array4[num4 + 5 - num9] = num9 - 6;
					num2 = (((num | (uint)(*(&QuitBan.IvSbzvcG2M) + *(&QuitBan.hAHmPaA744))) & (uint)(*(&QuitBan.M0d10Ase4D))) - (uint)(*(&QuitBan.oE4xTj7JHW)) - (uint)(*(&QuitBan.G7is4DMNYo)) ^ (uint)(*(&QuitBan.WXkoRSRaky)));
					continue;
				}
				case 26U:
				{
					int[] array13 = array9;
					int num31 = 0;
					int num32 = ~((array9[0] << 7) * 243 - -496);
					int num33 = (-44 == 0) ? (num32 - 67) : (num32 + -44);
					array13[num31] = (array9[0] ^ num33 ^ (689785809 ^ num33));
					num2 = 3977277555U;
					continue;
				}
				case 27U:
				{
					int num3 = num3;
					uint[] array14 = new uint[*(&QuitBan.5ywu324fZ9)];
					array14[*(&QuitBan.FJw1f5ROMQ)] = (uint)(*(&QuitBan.dyy7z8XPka));
					array14[*(&QuitBan.hcjCUuHpUc)] = (uint)(*(&QuitBan.G7P2LbMjGM));
					array14[*(&QuitBan.U5jThG9y54)] = (uint)(*(&QuitBan.eo49cmjuhv));
					array14[*(&QuitBan.yl4uJfj5wX)] = (uint)(*(&QuitBan.wxJXFm3QfN) + *(&QuitBan.vSuZ7bCPaj));
					array14[*(&QuitBan.1bCVYtAyJB)] = (uint)(*(&QuitBan.gDChIrfh40));
					uint num34 = num & array14[*(&QuitBan.sTOU9g0exr)];
					uint num35 = num34 + array14[*(&QuitBan.dUfMgUvx9V)] + array14[*(&QuitBan.lEGeqrPNRP)];
					num2 = ((num35 * (uint)(*(&QuitBan.6fVk0hNsV1) + *(&QuitBan.2fBbiMizBx)) & array14[*(&QuitBan.6shiOnNunS)]) ^ (uint)(*(&QuitBan.QnNhv784W8)));
					continue;
				}
				case 28U:
				{
					int num4;
					int num9;
					int[] array4;
					array4[num9 + 9 - num4] = num9 - -4;
					int num3 = num9 + 974;
					uint[] array15 = new uint[*(&QuitBan.WxTBKxVPwy) + *(&QuitBan.h9bWTngZEK)];
					array15[*(&QuitBan.ge2dJq3Zcs)] = (uint)(*(&QuitBan.qmJW0DYWHt));
					array15[*(&QuitBan.ul0tN6S201)] = (uint)(*(&QuitBan.HXeVL14z1d));
					array15[*(&QuitBan.36xEH4zFgP)] = (uint)(*(&QuitBan.PJSVa4nIQM));
					array15[*(&QuitBan.XBiklTHyL8) + *(&QuitBan.JienzxywmS)] = (uint)(*(&QuitBan.GNVlm7EJ5Q) + *(&QuitBan.OvjpF2YMcy));
					uint num36 = (num | array15[*(&QuitBan.wB3hFqpofm)]) ^ array15[*(&QuitBan.G1g7FJq78n)];
					num2 = ((num36 * array15[*(&QuitBan.O825uY9zh7)] | array15[*(&QuitBan.ZlTxgFUxf5)]) ^ (uint)(*(&QuitBan.SZoSJWOlk6)));
					continue;
				}
				case 29U:
				{
					int num3;
					int num9;
					int[] array6;
					array6[num9 + 5 - num3] = num3 - 0;
					int num4;
					int[] array4;
					array4[num3 + 9 - num4] = num4 - 0;
					num9 = -num3;
					num2 = (num + (uint)(*(&QuitBan.DgvtRRBavT)) ^ (uint)(*(&QuitBan.SXt0bAQQwU)) ^ (uint)(*(&QuitBan.tFGz79mdUc)) ^ (uint)(*(&QuitBan.0jXGtYnjfo)));
					continue;
				}
				case 30U:
				{
					uint num37 = num * (uint)(*(&QuitBan.Z9ksFknTWU));
					uint num38 = num37 | (uint)(*(&QuitBan.WJtrMZikbv));
					num2 = ((num38 * (uint)(*(&QuitBan.4O7lSCiS4d)) & (uint)(*(&QuitBan.oWcRq0BkRN))) - (uint)(*(&QuitBan.Ib3bPBRmGc)) ^ (uint)(*(&QuitBan.XZEStLB9aD)));
					continue;
				}
				case 31U:
				{
					int[] array6;
					int num9 = array6[num9 + 6 - num9] ^ 7;
					uint num39 = num + (uint)(*(&QuitBan.Nl30FcP9BZ));
					uint num40 = num39 * (uint)(*(&QuitBan.Ao4ZJrCWqe) + *(&QuitBan.yviFV0h4KQ)) ^ (uint)(*(&QuitBan.FAd4tDBWmK));
					num2 = (num40 * (uint)(*(&QuitBan.rAOscy3TOm)) ^ (uint)(*(&QuitBan.4mB9ucDxfP)));
					continue;
				}
				case 32U:
				{
					int num3;
					int num9 = num3 / 314;
					uint num41 = num & (uint)(*(&QuitBan.D8MyicGUSq));
					num2 = ((num41 - (uint)(*(&QuitBan.c0zixPRv7w)) | (uint)(*(&QuitBan.xfFPrReQfB) + *(&QuitBan.RgiTTIutKc))) ^ (uint)(*(&QuitBan.724sMfhC0C)));
					continue;
				}
				case 33U:
				{
					int num4;
					int num3 = num4 * 883;
					int num9;
					int[] array6;
					array6[num4 + 6 - num9] = num3 - -5;
					num3 = num3;
					num2 = (((num3 > num3) ? 3227971365U : 3915797569U) ^ num * 1936930875U);
					continue;
				}
				case 34U:
				{
					int num9;
					num9 |= 1025127198;
					uint[] array16 = new uint[*(&QuitBan.j5u5bWG56X)];
					array16[*(&QuitBan.sG54PG0BEM)] = (uint)(*(&QuitBan.yPvQXoQSO3));
					array16[*(&QuitBan.Tyl8lkOwRZ)] = (uint)(*(&QuitBan.A00pZGvLcR));
					array16[*(&QuitBan.CK7RmUKeix)] = (uint)(*(&QuitBan.GyqCE3e7Sp));
					array16[*(&QuitBan.1EtpM8YG0Q)] = (uint)(*(&QuitBan.2Fz71I1UVR) + *(&QuitBan.auNeSMJylg));
					array16[*(&QuitBan.lx2xZ8aSFn)] = (uint)(*(&QuitBan.5DnR4A8tL5));
					array16[*(&QuitBan.CKlBPH0PW9) + *(&QuitBan.ykfUpFMCh3)] = (uint)(*(&QuitBan.siPsVWH6jR));
					uint num42 = num + array16[*(&QuitBan.NanqdbM1hS)] + array16[*(&QuitBan.HL5FzViSmz)];
					uint num43 = num42 + array16[*(&QuitBan.x5MSMd53p3) + *(&QuitBan.A4pEwY7z1N)] & array16[*(&QuitBan.3VfPvgnJ29)];
					uint num44 = num43 | (uint)(*(&QuitBan.xyTudSOUd9));
					num2 = (num44 + array16[*(&QuitBan.fSMnRNg1Tb)] ^ (uint)(*(&QuitBan.YtbY6cZ6gq)));
					continue;
				}
				case 35U:
				{
					int num3;
					int num9 = num3;
					uint[] array17 = new uint[*(&QuitBan.AgdyBh27HQ)];
					array17[*(&QuitBan.80yRY5SgPp)] = (uint)(*(&QuitBan.eilez4kXCL));
					array17[*(&QuitBan.tcZdBvCuRv)] = (uint)(*(&QuitBan.Pxl3eGDnTQ));
					array17[*(&QuitBan.NBwLhb499G)] = (uint)(*(&QuitBan.7f46hgaVQn));
					array17[*(&QuitBan.3hOeZr7sAs)] = (uint)(*(&QuitBan.07Dw8rpO5j));
					array17[*(&QuitBan.0DvLyu3oW8)] = (uint)(*(&QuitBan.qsWqXpxSw0));
					uint num45 = num ^ array17[*(&QuitBan.dM8QP9bH8z)];
					uint num46 = num45 - array17[*(&QuitBan.0MZqwzwDpo)];
					uint num47 = num46 - array17[*(&QuitBan.xSVCCIkXZS) + *(&QuitBan.4WcFFnFe5y)];
					num2 = ((num47 | array17[*(&QuitBan.TvqgHdSp4h)]) - (uint)(*(&QuitBan.2tnHCL05OH)) ^ (uint)(*(&QuitBan.ZEsp4euUlI)));
					continue;
				}
				case 36U:
				{
					int num9;
					QuitBan.sMmToPHViG = num9;
					int num4 = num9 >> 3;
					uint num48 = num * (uint)(*(&QuitBan.zDLydncXlY));
					uint num49 = (num48 | (uint)(*(&QuitBan.KcKHIAn7AC))) * (uint)(*(&QuitBan.6TnNM4azpc)) + (uint)(*(&QuitBan.TDHjImSldj));
					uint num50 = num49 * (uint)(*(&QuitBan.7v6v4HzET8));
					num2 = ((num50 | (uint)(*(&QuitBan.ln60xfZ8lj))) ^ (uint)(*(&QuitBan.NmsJEGVl8f)));
					continue;
				}
				case 37U:
				{
					int num51 = 494;
					uint[] array18 = new uint[*(&QuitBan.MaNzjyI8xr)];
					array18[*(&QuitBan.r0HhNehsbA)] = (uint)(*(&QuitBan.z2bCVzTkvX));
					array18[*(&QuitBan.JXPlv8XeOs)] = (uint)(*(&QuitBan.6WAyNcSGFp));
					array18[*(&QuitBan.ygKjGT8Ldu) + *(&QuitBan.eiMZhUkfwO)] = (uint)(*(&QuitBan.GDetEd2ny3));
					array18[*(&QuitBan.gNfGjnNpeb) + *(&QuitBan.AMAeNXJkQ3)] = (uint)(*(&QuitBan.1wU0ivBafn));
					array18[*(&QuitBan.bVWkNRDG04)] = (uint)(*(&QuitBan.G5AUO3C9fq));
					array18[*(&QuitBan.TRX4Bu3oiy) + *(&QuitBan.lwK1Ao0aR6)] = (uint)(*(&QuitBan.TDuVx5v9mo));
					uint num52 = (num ^ array18[*(&QuitBan.sC4yTK8bic)]) - array18[*(&QuitBan.YZiCSTvJUj)];
					uint num53 = num52 ^ (uint)(*(&QuitBan.DmrjWQgBHF) + *(&QuitBan.93B3Fi1Viz));
					uint num54 = num53 | (uint)(*(&QuitBan.qY2zi4fsCd));
					num2 = (num54 - array18[*(&QuitBan.KmpDlGUVbD) + *(&QuitBan.n6TcdeXo6u)] ^ (uint)(*(&QuitBan.cZle2ot2Bc)) ^ (uint)(*(&QuitBan.uy8o5XO8S9)));
					continue;
				}
				case 38U:
				{
					int num4;
					int num3 = num4 | num3;
					uint[] array19 = new uint[*(&QuitBan.kKNLNyrVFM)];
					array19[*(&QuitBan.BcV0x8a5wR)] = (uint)(*(&QuitBan.oiFSctAmHC));
					array19[*(&QuitBan.XrvItj14mI)] = (uint)(*(&QuitBan.SQXIbYNgTv));
					array19[*(&QuitBan.8rxO9CE4se)] = (uint)(*(&QuitBan.yEOCyUqMGO));
					array19[*(&QuitBan.GfTn8XK71E)] = (uint)(*(&QuitBan.fdTWEp3hJq));
					uint num55 = num * array19[*(&QuitBan.e6MIUNCUTG)] - array19[*(&QuitBan.rBaEocXKPl)];
					uint num56 = num55 & array19[*(&QuitBan.2HCn8Vv28J) + *(&QuitBan.aJCZuKSLSv)];
					num2 = (num56 + (uint)(*(&QuitBan.VzovWdDOrm)) ^ (uint)(*(&QuitBan.StRiyW3iJ9) + *(&QuitBan.bKWKpi8AUe)));
					continue;
				}
				case 39U:
				{
					int num4;
					int num3;
					int num9;
					int[] array4;
					array4[num4 + 9 - num3] = num9 - -8;
					uint[] array20 = new uint[*(&QuitBan.h8KsnSoVa5)];
					array20[*(&QuitBan.YCjX3i5KCi)] = (uint)(*(&QuitBan.amV61JPDYv));
					array20[*(&QuitBan.D7w2LtlmyS)] = (uint)(*(&QuitBan.t8IWOy39aS) + *(&QuitBan.zkxhn4mN1e));
					array20[*(&QuitBan.Dk7o1aPrLJ)] = (uint)(*(&QuitBan.7TVuybe9rC));
					uint num57 = num * (uint)(*(&QuitBan.QQmG5cKPOQ));
					num2 = ((num57 ^ array20[*(&QuitBan.GXvUPIBdey)]) - (uint)(*(&QuitBan.iMyQUgPCsL)) ^ (uint)(*(&QuitBan.anfzNw71tY) + *(&QuitBan.PAc4CjhAfp)));
					continue;
				}
				case 40U:
				{
					array9[0] = 689785809;
					uint[] array21 = new uint[*(&QuitBan.Og4eMuFZVD) + *(&QuitBan.g0vSBvAKK6)];
					array21[*(&QuitBan.WbT8Sz8phG)] = (uint)(*(&QuitBan.QZV7f5eGSI));
					array21[*(&QuitBan.jTh853CpnJ)] = (uint)(*(&QuitBan.WDxVmwM5MX) + *(&QuitBan.vZ2PwHfyxF));
					array21[*(&QuitBan.R41CXC4VCY)] = (uint)(*(&QuitBan.wSCYtNl9Ut));
					array21[*(&QuitBan.ti45WKbRLy) + *(&QuitBan.YN2h1cLv8j)] = (uint)(*(&QuitBan.202xkcWegj));
					array21[*(&QuitBan.ffeEVs96pN)] = (uint)(*(&QuitBan.lnJO9iaegR));
					uint num58 = num | (uint)(*(&QuitBan.B0Bu02pHU3) + *(&QuitBan.x7vmT3tyMJ));
					uint num59 = num58 & array21[*(&QuitBan.dPFv8OroxB)];
					uint num60 = num59 * array21[*(&QuitBan.C17PhpetNd)];
					uint num61 = num60 | array21[*(&QuitBan.D2lwZn2h5G)];
					num2 = ((num61 | (uint)(*(&QuitBan.zmSXywuPvl))) ^ (uint)(*(&QuitBan.LATS169fEn)));
					continue;
				}
				case 41U:
				{
					int num3;
					int[] array4;
					int num9 = array4[num9 + 9 - num3] ^ -5;
					uint[] array22 = new uint[*(&QuitBan.sCeaFLX2SF)];
					array22[*(&QuitBan.EWfq1pHQvn)] = (uint)(*(&QuitBan.MU93WUCxrx));
					array22[*(&QuitBan.wOFxQiJfum)] = (uint)(*(&QuitBan.Ihpfe1GCRZ));
					array22[*(&QuitBan.9EzVTXCkDv) + *(&QuitBan.IjKfT0QsZS)] = (uint)(*(&QuitBan.glfJeopdYe) + *(&QuitBan.NAfRyrYue2));
					array22[*(&QuitBan.gic9eiWKMo) + *(&QuitBan.lYm92Xjp1o)] = (uint)(*(&QuitBan.siMiiHE2ql));
					array22[*(&QuitBan.bfNgw7Jfp5) + *(&QuitBan.ReRu3yXgZb)] = (uint)(*(&QuitBan.Is30K7W3bW));
					uint num62 = num & (uint)(*(&QuitBan.edelMFLGN5));
					uint num63 = num62 + (uint)(*(&QuitBan.NDA5WNRbpt)) & array22[*(&QuitBan.uhdOdtmXWz) + *(&QuitBan.lQESbyAqiy)];
					uint num64 = num63 & array22[*(&QuitBan.nRSeNEs8d6)];
					num2 = ((num64 | (uint)(*(&QuitBan.p4Nsm6APHd))) ^ (uint)(*(&QuitBan.cxtYT78rei)));
					continue;
				}
				case 42U:
				{
					int num51;
					num2 = (((num51 == 494) ? 609892637U : 1255676101U) ^ num * 2168124794U);
					continue;
				}
				}
				break;
			}
			return result;
			IL_24:
			num2 = 3552758071U;
			goto IL_29;
			IL_A7C:
			array9 = new int[15];
			num2 = 3799925227U;
			goto IL_29;
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x006435D4 File Offset: 0x006417D4
		public unsafe QuitBan()
		{
			if ((*(&QuitBan.t3zD3uwJYR) ^ *(&QuitBan.t3zD3uwJYR)) != 0)
			{
				int[] array = new int[10];
				int num2;
				int num3;
				int num = num2 | num3;
				num3 = *(ref QuitBan.sMmToPHViG + (IntPtr)num3);
				int num4;
				if (num4 > num4)
				{
					num >>= 2;
				}
				if (num3 > num3)
				{
					num3 = ~num3;
				}
				num3 = -num3;
				num4 = (num3 & 1755578420);
				num += 706;
				num2 = (num3 | 1201518952);
				num4 = (num & 1459376387);
				num4 = (int)((sbyte)num4);
				num2 = (num3 & num2);
				num = num3 >> 1;
				array[num3 + 7 - num] = (num4 | 6);
				num = (num3 ^ 355332758);
				num = (int)((sbyte)num3);
				num4 = num2;
				if (num4 > num4)
				{
					QuitBan.sMmToPHViG = num2;
					QuitBan.sMmToPHViG = num3;
				}
				num3 = (num2 | num3);
				*(ref QuitBan.sMmToPHViG + (IntPtr)num2) = num2;
				num = num4 << 3;
				if (num2 > num2)
				{
					num3 = (int)((sbyte)num4);
				}
				num3 = num % num2;
				if (num > num)
				{
					*(ref num + (IntPtr)num2) = num2;
				}
				num4 = QuitBan.sMmToPHViG;
				if (num3 > num3)
				{
					num = num3 * 986;
					if (num4 > num4)
					{
						num = (num4 ^ 1741605830);
						array[num4 + 8 - num3] = num - -6;
						num3 = num2;
						num3 = -num4;
					}
					array[num + 6 - num] = (num | 0);
					num2 = ~num4;
					num4 = (num3 ^ 1982822219);
					QuitBan.sMmToPHViG = num2;
					num3 = (int)((byte)num2);
				}
				num4 -= 950;
				array[num4 + 5 - num2] = num4 - -1;
				num3 = -num4;
				num2 /= 960;
				num3 = num2;
				num = -num2;
				if (num4 > num4)
				{
					if (num4 > num4)
					{
						num2 = num3 / 446;
						array[num3 + 7 - num] = num2 - -3;
						num2 = num4 / 840;
						num2 = (int)((byte)num3);
						num = ~num;
						num3 /= num2;
						num = num2;
						num4 = (array[num3 + 5 - num3] ^ -7);
						num3 = num2;
					}
					*(ref num2 + (IntPtr)num3) = num3;
					num3 = *(ref num4 + (IntPtr)num2);
					array[num2 + 6 - num] = (num2 | 3);
				}
				num4 = (array[num + 5 - num] ^ 6);
				if (num > num)
				{
					num = num3 % num2;
					num |= 41403933;
					num = num2;
					if (num2 > num2)
					{
						num2 &= num3;
					}
				}
				num3 = (num2 ^ 1407663189);
				array[num3 + 9 - num4] = (num3 | 8);
			}
			base..ctor();
		}

		// Token: 0x0404E96D RID: 321901 RVA: 0x001461B0 File Offset: 0x001443B0
		static int qVCvKkJ1H8;

		// Token: 0x0404E96E RID: 321902 RVA: 0x001461B8 File Offset: 0x001443B8
		static int sMmToPHViG;

		// Token: 0x0404E96F RID: 321903 RVA: 0x001461C0 File Offset: 0x001443C0
		static int t3zD3uwJYR;

		// Token: 0x0404E970 RID: 321904 RVA: 0x001461C8 File Offset: 0x001443C8
		static readonly int VZ79LOa9tF;

		// Token: 0x0404E971 RID: 321905 RVA: 0x00018D70 File Offset: 0x00016F70
		static readonly int E9SEU7gbEU;

		// Token: 0x0404E972 RID: 321906 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 0ME5IVmzCn;

		// Token: 0x0404E973 RID: 321907 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int mR7QEzx4XS;

		// Token: 0x0404E974 RID: 321908 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 0LSzoMiODU;

		// Token: 0x0404E975 RID: 321909 RVA: 0x001461D0 File Offset: 0x001443D0
		static readonly int 2sXc9JUB00;

		// Token: 0x0404E976 RID: 321910 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lk7GcwCBAf;

		// Token: 0x0404E977 RID: 321911 RVA: 0x001461D8 File Offset: 0x001443D8
		static readonly int KlDveo3PR6;

		// Token: 0x0404E978 RID: 321912 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int xXwrv34eQ5;

		// Token: 0x0404E979 RID: 321913 RVA: 0x001461E0 File Offset: 0x001443E0
		static readonly int ewEhqPNMW2;

		// Token: 0x0404E97A RID: 321914 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int JgOhKQol8U;

		// Token: 0x0404E97B RID: 321915 RVA: 0x001461E8 File Offset: 0x001443E8
		static readonly int PFu3COxQUj;

		// Token: 0x0404E97C RID: 321916 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 1ivEAXhgEO;

		// Token: 0x0404E97D RID: 321917 RVA: 0x001461F0 File Offset: 0x001443F0
		static readonly int br2ZxRIPge;

		// Token: 0x0404E97E RID: 321918 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int PSg6pZCLec;

		// Token: 0x0404E97F RID: 321919 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int b61xAluJgx;

		// Token: 0x0404E980 RID: 321920 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int sIht2hMUFv;

		// Token: 0x0404E981 RID: 321921 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Fiu0TjBzYk;

		// Token: 0x0404E982 RID: 321922 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int VWBmxfzFYL;

		// Token: 0x0404E983 RID: 321923 RVA: 0x001461F0 File Offset: 0x001443F0
		static readonly int g9stvHvwDI;

		// Token: 0x0404E984 RID: 321924 RVA: 0x001461F8 File Offset: 0x001443F8
		static readonly int NrFsX3LBda;

		// Token: 0x0404E985 RID: 321925 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int j5u5bWG56X;

		// Token: 0x0404E986 RID: 321926 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sG54PG0BEM;

		// Token: 0x0404E987 RID: 321927 RVA: 0x00146200 File Offset: 0x00144400
		static readonly int yPvQXoQSO3;

		// Token: 0x0404E988 RID: 321928 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Tyl8lkOwRZ;

		// Token: 0x0404E989 RID: 321929 RVA: 0x00146208 File Offset: 0x00144408
		static readonly int A00pZGvLcR;

		// Token: 0x0404E98A RID: 321930 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int CK7RmUKeix;

		// Token: 0x0404E98B RID: 321931 RVA: 0x00146210 File Offset: 0x00144410
		static readonly int GyqCE3e7Sp;

		// Token: 0x0404E98C RID: 321932 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 1EtpM8YG0Q;

		// Token: 0x0404E98D RID: 321933 RVA: 0x00146218 File Offset: 0x00144418
		static readonly int 2Fz71I1UVR;

		// Token: 0x0404E98E RID: 321934 RVA: 0x00146220 File Offset: 0x00144420
		static readonly int auNeSMJylg;

		// Token: 0x0404E98F RID: 321935 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int lx2xZ8aSFn;

		// Token: 0x0404E990 RID: 321936 RVA: 0x00146228 File Offset: 0x00144428
		static readonly int 5DnR4A8tL5;

		// Token: 0x0404E991 RID: 321937 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int CKlBPH0PW9;

		// Token: 0x0404E992 RID: 321938 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ykfUpFMCh3;

		// Token: 0x0404E993 RID: 321939 RVA: 0x00146230 File Offset: 0x00144430
		static readonly int siPsVWH6jR;

		// Token: 0x0404E994 RID: 321940 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int NanqdbM1hS;

		// Token: 0x0404E995 RID: 321941 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int HL5FzViSmz;

		// Token: 0x0404E996 RID: 321942 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int x5MSMd53p3;

		// Token: 0x0404E997 RID: 321943 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int A4pEwY7z1N;

		// Token: 0x0404E998 RID: 321944 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 3VfPvgnJ29;

		// Token: 0x0404E999 RID: 321945 RVA: 0x00146228 File Offset: 0x00144428
		static readonly int xyTudSOUd9;

		// Token: 0x0404E99A RID: 321946 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int fSMnRNg1Tb;

		// Token: 0x0404E99B RID: 321947 RVA: 0x00146238 File Offset: 0x00144438
		static readonly int YtbY6cZ6gq;

		// Token: 0x0404E99C RID: 321948 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 0vBpFLl4kd;

		// Token: 0x0404E99D RID: 321949 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int JmV1skI17i;

		// Token: 0x0404E99E RID: 321950 RVA: 0x00146240 File Offset: 0x00144440
		static readonly int Aw0blEX4xB;

		// Token: 0x0404E99F RID: 321951 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2RywJuRgiG;

		// Token: 0x0404E9A0 RID: 321952 RVA: 0x00146248 File Offset: 0x00144448
		static readonly int mlQzRvXkqV;

		// Token: 0x0404E9A1 RID: 321953 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Ti98pE4jDB;

		// Token: 0x0404E9A2 RID: 321954 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yqHjl2yir7;

		// Token: 0x0404E9A3 RID: 321955 RVA: 0x00146250 File Offset: 0x00144450
		static readonly int TmT15ZfBJ0;

		// Token: 0x0404E9A4 RID: 321956 RVA: 0x00146240 File Offset: 0x00144440
		static readonly int qxNcrURzHF;

		// Token: 0x0404E9A5 RID: 321957 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int zrchR5drOZ;

		// Token: 0x0404E9A6 RID: 321958 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7y2sCrOICP;

		// Token: 0x0404E9A7 RID: 321959 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int j3aNUBcp2Q;

		// Token: 0x0404E9A8 RID: 321960 RVA: 0x00146258 File Offset: 0x00144458
		static readonly int k8bmImKwjA;

		// Token: 0x0404E9A9 RID: 321961 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 5ywu324fZ9;

		// Token: 0x0404E9AA RID: 321962 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int FJw1f5ROMQ;

		// Token: 0x0404E9AB RID: 321963 RVA: 0x00146260 File Offset: 0x00144460
		static readonly int dyy7z8XPka;

		// Token: 0x0404E9AC RID: 321964 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int hcjCUuHpUc;

		// Token: 0x0404E9AD RID: 321965 RVA: 0x00146268 File Offset: 0x00144468
		static readonly int G7P2LbMjGM;

		// Token: 0x0404E9AE RID: 321966 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int U5jThG9y54;

		// Token: 0x0404E9AF RID: 321967 RVA: 0x00146270 File Offset: 0x00144470
		static readonly int eo49cmjuhv;

		// Token: 0x0404E9B0 RID: 321968 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int yl4uJfj5wX;

		// Token: 0x0404E9B1 RID: 321969 RVA: 0x00146278 File Offset: 0x00144478
		static readonly int wxJXFm3QfN;

		// Token: 0x0404E9B2 RID: 321970 RVA: 0x00146280 File Offset: 0x00144480
		static readonly int vSuZ7bCPaj;

		// Token: 0x0404E9B3 RID: 321971 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 1bCVYtAyJB;

		// Token: 0x0404E9B4 RID: 321972 RVA: 0x00146288 File Offset: 0x00144488
		static readonly int gDChIrfh40;

		// Token: 0x0404E9B5 RID: 321973 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sTOU9g0exr;

		// Token: 0x0404E9B6 RID: 321974 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int dUfMgUvx9V;

		// Token: 0x0404E9B7 RID: 321975 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int lEGeqrPNRP;

		// Token: 0x0404E9B8 RID: 321976 RVA: 0x00146290 File Offset: 0x00144490
		static readonly int 6fVk0hNsV1;

		// Token: 0x0404E9B9 RID: 321977 RVA: 0x00146298 File Offset: 0x00144498
		static readonly int 2fBbiMizBx;

		// Token: 0x0404E9BA RID: 321978 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 6shiOnNunS;

		// Token: 0x0404E9BB RID: 321979 RVA: 0x001462A0 File Offset: 0x001444A0
		static readonly int QnNhv784W8;

		// Token: 0x0404E9BC RID: 321980 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int HDbHcFDo5d;

		// Token: 0x0404E9BD RID: 321981 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int IZLdTN7wVM;

		// Token: 0x0404E9BE RID: 321982 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int UcEClPSdqk;

		// Token: 0x0404E9BF RID: 321983 RVA: 0x001462A8 File Offset: 0x001444A8
		static readonly int OndCq3QZFJ;

		// Token: 0x0404E9C0 RID: 321984 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kiyJK0btOh;

		// Token: 0x0404E9C1 RID: 321985 RVA: 0x001462B0 File Offset: 0x001444B0
		static readonly int ALjJno8ZgN;

		// Token: 0x0404E9C2 RID: 321986 RVA: 0x001462B8 File Offset: 0x001444B8
		static readonly int wk8VPe5Jwa;

		// Token: 0x0404E9C3 RID: 321987 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7hqLmwo52v;

		// Token: 0x0404E9C4 RID: 321988 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xiOIjCEUYC;

		// Token: 0x0404E9C5 RID: 321989 RVA: 0x001462C0 File Offset: 0x001444C0
		static readonly int 4132W9kc4p;

		// Token: 0x0404E9C6 RID: 321990 RVA: 0x001462C8 File Offset: 0x001444C8
		static readonly int 4S7yjcfXh1;

		// Token: 0x0404E9C7 RID: 321991 RVA: 0x001462A8 File Offset: 0x001444A8
		static readonly int 9DgvZOVzvN;

		// Token: 0x0404E9C8 RID: 321992 RVA: 0x001462D0 File Offset: 0x001444D0
		static readonly int alutfGoyzm;

		// Token: 0x0404E9C9 RID: 321993 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int MLAN0flajH;

		// Token: 0x0404E9CA RID: 321994 RVA: 0x001462D8 File Offset: 0x001444D8
		static readonly int hqxhD1VIdI;

		// Token: 0x0404E9CB RID: 321995 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ouqqOShNSd;

		// Token: 0x0404E9CC RID: 321996 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int yqi4pxCS43;

		// Token: 0x0404E9CD RID: 321997 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int m5QoquyNqn;

		// Token: 0x0404E9CE RID: 321998 RVA: 0x001462E0 File Offset: 0x001444E0
		static readonly int vgVq8beU8h;

		// Token: 0x0404E9CF RID: 321999 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7XHFT0H31P;

		// Token: 0x0404E9D0 RID: 322000 RVA: 0x001462E8 File Offset: 0x001444E8
		static readonly int zCNjfseCAe;

		// Token: 0x0404E9D1 RID: 322001 RVA: 0x001462F0 File Offset: 0x001444F0
		static readonly int eUhpsSV25O;

		// Token: 0x0404E9D2 RID: 322002 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int SrTX6PxKV0;

		// Token: 0x0404E9D3 RID: 322003 RVA: 0x001462F8 File Offset: 0x001444F8
		static readonly int m5VaytSvKP;

		// Token: 0x0404E9D4 RID: 322004 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 6cUeCnzcXB;

		// Token: 0x0404E9D5 RID: 322005 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int eP7n6Hs0nQ;

		// Token: 0x0404E9D6 RID: 322006 RVA: 0x00146300 File Offset: 0x00144500
		static readonly int 5TrK1j8H09;

		// Token: 0x0404E9D7 RID: 322007 RVA: 0x001462E0 File Offset: 0x001444E0
		static readonly int 9krpR0XzUS;

		// Token: 0x0404E9D8 RID: 322008 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int aUxTVX7sdr;

		// Token: 0x0404E9D9 RID: 322009 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int AcI4UmvKnd;

		// Token: 0x0404E9DA RID: 322010 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int osmXB4hRWG;

		// Token: 0x0404E9DB RID: 322011 RVA: 0x00146300 File Offset: 0x00144500
		static readonly int t3fUzkgXyd;

		// Token: 0x0404E9DC RID: 322012 RVA: 0x00146308 File Offset: 0x00144508
		static readonly int lQnJ8hbwVo;

		// Token: 0x0404E9DD RID: 322013 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int ENL0orsZSb;

		// Token: 0x0404E9DE RID: 322014 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int zpVX7H6yEt;

		// Token: 0x0404E9DF RID: 322015 RVA: 0x00146310 File Offset: 0x00144510
		static readonly int GXVJ2XFcZe;

		// Token: 0x0404E9E0 RID: 322016 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int cu6rBfropI;

		// Token: 0x0404E9E1 RID: 322017 RVA: 0x00146318 File Offset: 0x00144518
		static readonly int 1GFXn54PL1;

		// Token: 0x0404E9E2 RID: 322018 RVA: 0x00146320 File Offset: 0x00144520
		static readonly int knslhr2B8R;

		// Token: 0x0404E9E3 RID: 322019 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mQAx8EtnVb;

		// Token: 0x0404E9E4 RID: 322020 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ZRI62AS8g6;

		// Token: 0x0404E9E5 RID: 322021 RVA: 0x00146328 File Offset: 0x00144528
		static readonly int czQh3yCVKU;

		// Token: 0x0404E9E6 RID: 322022 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int nqqYflFRYj;

		// Token: 0x0404E9E7 RID: 322023 RVA: 0x00146330 File Offset: 0x00144530
		static readonly int MR4ubTfvsg;

		// Token: 0x0404E9E8 RID: 322024 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int Y3fCyx9c4J;

		// Token: 0x0404E9E9 RID: 322025 RVA: 0x00146338 File Offset: 0x00144538
		static readonly int CXdBxsluaQ;

		// Token: 0x0404E9EA RID: 322026 RVA: 0x00146328 File Offset: 0x00144528
		static readonly int 5Bj6uL5gGk;

		// Token: 0x0404E9EB RID: 322027 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TQmn5tLnjs;

		// Token: 0x0404E9EC RID: 322028 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int mmXOgyx26t;

		// Token: 0x0404E9ED RID: 322029 RVA: 0x00146340 File Offset: 0x00144540
		static readonly int rvUclXTiSm;

		// Token: 0x0404E9EE RID: 322030 RVA: 0x00146348 File Offset: 0x00144548
		static readonly int 1cWT0vuzFD;

		// Token: 0x0404E9EF RID: 322031 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int h8KsnSoVa5;

		// Token: 0x0404E9F0 RID: 322032 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int YCjX3i5KCi;

		// Token: 0x0404E9F1 RID: 322033 RVA: 0x00146350 File Offset: 0x00144550
		static readonly int amV61JPDYv;

		// Token: 0x0404E9F2 RID: 322034 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int D7w2LtlmyS;

		// Token: 0x0404E9F3 RID: 322035 RVA: 0x00146358 File Offset: 0x00144558
		static readonly int t8IWOy39aS;

		// Token: 0x0404E9F4 RID: 322036 RVA: 0x00146360 File Offset: 0x00144560
		static readonly int zkxhn4mN1e;

		// Token: 0x0404E9F5 RID: 322037 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Dk7o1aPrLJ;

		// Token: 0x0404E9F6 RID: 322038 RVA: 0x00146368 File Offset: 0x00144568
		static readonly int 7TVuybe9rC;

		// Token: 0x0404E9F7 RID: 322039 RVA: 0x00146350 File Offset: 0x00144550
		static readonly int QQmG5cKPOQ;

		// Token: 0x0404E9F8 RID: 322040 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int GXvUPIBdey;

		// Token: 0x0404E9F9 RID: 322041 RVA: 0x00146368 File Offset: 0x00144568
		static readonly int iMyQUgPCsL;

		// Token: 0x0404E9FA RID: 322042 RVA: 0x00146370 File Offset: 0x00144570
		static readonly int anfzNw71tY;

		// Token: 0x0404E9FB RID: 322043 RVA: 0x00146378 File Offset: 0x00144578
		static readonly int PAc4CjhAfp;

		// Token: 0x0404E9FC RID: 322044 RVA: 0x00146380 File Offset: 0x00144580
		static readonly int aBe3dEcWvZ;

		// Token: 0x0404E9FD RID: 322045 RVA: 0x00146388 File Offset: 0x00144588
		static readonly int NHgC0d26Gc;

		// Token: 0x0404E9FE RID: 322046 RVA: 0x00146390 File Offset: 0x00144590
		static readonly int LJuFjit3Nv;

		// Token: 0x0404E9FF RID: 322047 RVA: 0x00146398 File Offset: 0x00144598
		static readonly int 8OhDvZJmVJ;

		// Token: 0x0404EA00 RID: 322048 RVA: 0x001463A0 File Offset: 0x001445A0
		static readonly int UlGTLHdZDj;

		// Token: 0x0404EA01 RID: 322049 RVA: 0x001463A8 File Offset: 0x001445A8
		static readonly int ql4CeQQYT4;

		// Token: 0x0404EA02 RID: 322050 RVA: 0x001463B0 File Offset: 0x001445B0
		static readonly int UiI9a8kdRb;

		// Token: 0x0404EA03 RID: 322051 RVA: 0x001463B8 File Offset: 0x001445B8
		static readonly int UQk6HjDa4b;

		// Token: 0x0404EA04 RID: 322052 RVA: 0x001463C0 File Offset: 0x001445C0
		static readonly int EUzoFXUfie;

		// Token: 0x0404EA05 RID: 322053 RVA: 0x001463C8 File Offset: 0x001445C8
		static readonly int IvSbzvcG2M;

		// Token: 0x0404EA06 RID: 322054 RVA: 0x001463D0 File Offset: 0x001445D0
		static readonly int hAHmPaA744;

		// Token: 0x0404EA07 RID: 322055 RVA: 0x001463D8 File Offset: 0x001445D8
		static readonly int M0d10Ase4D;

		// Token: 0x0404EA08 RID: 322056 RVA: 0x001463E0 File Offset: 0x001445E0
		static readonly int oE4xTj7JHW;

		// Token: 0x0404EA09 RID: 322057 RVA: 0x001463E8 File Offset: 0x001445E8
		static readonly int G7is4DMNYo;

		// Token: 0x0404EA0A RID: 322058 RVA: 0x001463F0 File Offset: 0x001445F0
		static readonly int WXkoRSRaky;

		// Token: 0x0404EA0B RID: 322059 RVA: 0x001463F8 File Offset: 0x001445F8
		static readonly int D8MyicGUSq;

		// Token: 0x0404EA0C RID: 322060 RVA: 0x00146400 File Offset: 0x00144600
		static readonly int c0zixPRv7w;

		// Token: 0x0404EA0D RID: 322061 RVA: 0x00146408 File Offset: 0x00144608
		static readonly int xfFPrReQfB;

		// Token: 0x0404EA0E RID: 322062 RVA: 0x00146410 File Offset: 0x00144610
		static readonly int RgiTTIutKc;

		// Token: 0x0404EA0F RID: 322063 RVA: 0x00146418 File Offset: 0x00144618
		static readonly int 724sMfhC0C;

		// Token: 0x0404EA10 RID: 322064 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int AgdyBh27HQ;

		// Token: 0x0404EA11 RID: 322065 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 80yRY5SgPp;

		// Token: 0x0404EA12 RID: 322066 RVA: 0x00146420 File Offset: 0x00144620
		static readonly int eilez4kXCL;

		// Token: 0x0404EA13 RID: 322067 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int tcZdBvCuRv;

		// Token: 0x0404EA14 RID: 322068 RVA: 0x00146428 File Offset: 0x00144628
		static readonly int Pxl3eGDnTQ;

		// Token: 0x0404EA15 RID: 322069 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int NBwLhb499G;

		// Token: 0x0404EA16 RID: 322070 RVA: 0x00146430 File Offset: 0x00144630
		static readonly int 7f46hgaVQn;

		// Token: 0x0404EA17 RID: 322071 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 3hOeZr7sAs;

		// Token: 0x0404EA18 RID: 322072 RVA: 0x00146438 File Offset: 0x00144638
		static readonly int 07Dw8rpO5j;

		// Token: 0x0404EA19 RID: 322073 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 0DvLyu3oW8;

		// Token: 0x0404EA1A RID: 322074 RVA: 0x00146440 File Offset: 0x00144640
		static readonly int qsWqXpxSw0;

		// Token: 0x0404EA1B RID: 322075 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int dM8QP9bH8z;

		// Token: 0x0404EA1C RID: 322076 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 0MZqwzwDpo;

		// Token: 0x0404EA1D RID: 322077 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xSVCCIkXZS;

		// Token: 0x0404EA1E RID: 322078 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4WcFFnFe5y;

		// Token: 0x0404EA1F RID: 322079 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int TvqgHdSp4h;

		// Token: 0x0404EA20 RID: 322080 RVA: 0x00146440 File Offset: 0x00144640
		static readonly int 2tnHCL05OH;

		// Token: 0x0404EA21 RID: 322081 RVA: 0x00146448 File Offset: 0x00144648
		static readonly int ZEsp4euUlI;

		// Token: 0x0404EA22 RID: 322082 RVA: 0x00146450 File Offset: 0x00144650
		static readonly int uSI1UCmz5i;

		// Token: 0x0404EA23 RID: 322083 RVA: 0x00146458 File Offset: 0x00144658
		static readonly int z4c2ZKtUC4;

		// Token: 0x0404EA24 RID: 322084 RVA: 0x00146460 File Offset: 0x00144660
		static readonly int xJQxZPDAln;

		// Token: 0x0404EA25 RID: 322085 RVA: 0x00146468 File Offset: 0x00144668
		static readonly int t8EvxklvwA;

		// Token: 0x0404EA26 RID: 322086 RVA: 0x00146470 File Offset: 0x00144670
		static readonly int iBAqRel0Qu;

		// Token: 0x0404EA27 RID: 322087 RVA: 0x00146478 File Offset: 0x00144678
		static readonly int uZSqVkCUcF;

		// Token: 0x0404EA28 RID: 322088 RVA: 0x00146480 File Offset: 0x00144680
		static readonly int 8lNRy1zqEz;

		// Token: 0x0404EA29 RID: 322089 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int i7hCVvIjg4;

		// Token: 0x0404EA2A RID: 322090 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int nNu12UqYaM;

		// Token: 0x0404EA2B RID: 322091 RVA: 0x00146488 File Offset: 0x00144688
		static readonly int iRTrB6xs1a;

		// Token: 0x0404EA2C RID: 322092 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int p4vaLx2PUj;

		// Token: 0x0404EA2D RID: 322093 RVA: 0x00146490 File Offset: 0x00144690
		static readonly int bcxhcv1VYe;

		// Token: 0x0404EA2E RID: 322094 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int LbQ2QRn0AZ;

		// Token: 0x0404EA2F RID: 322095 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 7ZsFOscTqF;

		// Token: 0x0404EA30 RID: 322096 RVA: 0x00146498 File Offset: 0x00144698
		static readonly int baD1uGdwOQ;

		// Token: 0x0404EA31 RID: 322097 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int FbTWPNo3J3;

		// Token: 0x0404EA32 RID: 322098 RVA: 0x001464A0 File Offset: 0x001446A0
		static readonly int JBP5lBtsSu;

		// Token: 0x0404EA33 RID: 322099 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ShpTCuXYHK;

		// Token: 0x0404EA34 RID: 322100 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int x1ltTgGV0B;

		// Token: 0x0404EA35 RID: 322101 RVA: 0x00146498 File Offset: 0x00144698
		static readonly int DiJw6ZKHPs;

		// Token: 0x0404EA36 RID: 322102 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Wvde7hwATe;

		// Token: 0x0404EA37 RID: 322103 RVA: 0x001464A8 File Offset: 0x001446A8
		static readonly int zPv9GRafmF;

		// Token: 0x0404EA38 RID: 322104 RVA: 0x001464B0 File Offset: 0x001446B0
		static readonly int 5X1RqtX2Wn;

		// Token: 0x0404EA39 RID: 322105 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int kPJYyBYHwv;

		// Token: 0x0404EA3A RID: 322106 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int tFBWLxxKqo;

		// Token: 0x0404EA3B RID: 322107 RVA: 0x001464B8 File Offset: 0x001446B8
		static readonly int 9ofKw84LxN;

		// Token: 0x0404EA3C RID: 322108 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int K4oq3jGXLF;

		// Token: 0x0404EA3D RID: 322109 RVA: 0x001464C0 File Offset: 0x001446C0
		static readonly int 3St0V0WfG2;

		// Token: 0x0404EA3E RID: 322110 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 6NMsn5u9lz;

		// Token: 0x0404EA3F RID: 322111 RVA: 0x001464C8 File Offset: 0x001446C8
		static readonly int HMTilzaUcl;

		// Token: 0x0404EA40 RID: 322112 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int rZ9kvq5py6;

		// Token: 0x0404EA41 RID: 322113 RVA: 0x001464D0 File Offset: 0x001446D0
		static readonly int mYE4R6r6D8;

		// Token: 0x0404EA42 RID: 322114 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int zHvV7q9LOg;

		// Token: 0x0404EA43 RID: 322115 RVA: 0x001464D8 File Offset: 0x001446D8
		static readonly int ZBCfLgNl66;

		// Token: 0x0404EA44 RID: 322116 RVA: 0x001464B8 File Offset: 0x001446B8
		static readonly int AFLpNsIYQo;

		// Token: 0x0404EA45 RID: 322117 RVA: 0x001464C0 File Offset: 0x001446C0
		static readonly int IeRdvkonnE;

		// Token: 0x0404EA46 RID: 322118 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int rtaRglWjtu;

		// Token: 0x0404EA47 RID: 322119 RVA: 0x001464D0 File Offset: 0x001446D0
		static readonly int sF9G8u5GIP;

		// Token: 0x0404EA48 RID: 322120 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ik4kY4tjtl;

		// Token: 0x0404EA49 RID: 322121 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 2k82PQo3Im;

		// Token: 0x0404EA4A RID: 322122 RVA: 0x001464E0 File Offset: 0x001446E0
		static readonly int Wipg6CfKfB;

		// Token: 0x0404EA4B RID: 322123 RVA: 0x001464E8 File Offset: 0x001446E8
		static readonly int oifXgGz03l;

		// Token: 0x0404EA4C RID: 322124 RVA: 0x001464F0 File Offset: 0x001446F0
		static readonly int 1w0H1IHH1s;

		// Token: 0x0404EA4D RID: 322125 RVA: 0x001464F8 File Offset: 0x001446F8
		static readonly int FC7g2A5YoW;

		// Token: 0x0404EA4E RID: 322126 RVA: 0x00146500 File Offset: 0x00144700
		static readonly int ZjDs6UEkVI;

		// Token: 0x0404EA4F RID: 322127 RVA: 0x00146508 File Offset: 0x00144708
		static readonly int byAhujrhox;

		// Token: 0x0404EA50 RID: 322128 RVA: 0x00146510 File Offset: 0x00144710
		static readonly int 4YSw5mk9eg;

		// Token: 0x0404EA51 RID: 322129 RVA: 0x00146518 File Offset: 0x00144718
		static readonly int LbMhMStIKh;

		// Token: 0x0404EA52 RID: 322130 RVA: 0x00146520 File Offset: 0x00144720
		static readonly int DgvtRRBavT;

		// Token: 0x0404EA53 RID: 322131 RVA: 0x00146528 File Offset: 0x00144728
		static readonly int SXt0bAQQwU;

		// Token: 0x0404EA54 RID: 322132 RVA: 0x00146530 File Offset: 0x00144730
		static readonly int tFGz79mdUc;

		// Token: 0x0404EA55 RID: 322133 RVA: 0x00146538 File Offset: 0x00144738
		static readonly int 0jXGtYnjfo;

		// Token: 0x0404EA56 RID: 322134 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int kKNLNyrVFM;

		// Token: 0x0404EA57 RID: 322135 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int BcV0x8a5wR;

		// Token: 0x0404EA58 RID: 322136 RVA: 0x00146540 File Offset: 0x00144740
		static readonly int oiFSctAmHC;

		// Token: 0x0404EA59 RID: 322137 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int XrvItj14mI;

		// Token: 0x0404EA5A RID: 322138 RVA: 0x00146548 File Offset: 0x00144748
		static readonly int SQXIbYNgTv;

		// Token: 0x0404EA5B RID: 322139 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 8rxO9CE4se;

		// Token: 0x0404EA5C RID: 322140 RVA: 0x00146550 File Offset: 0x00144750
		static readonly int yEOCyUqMGO;

		// Token: 0x0404EA5D RID: 322141 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int GfTn8XK71E;

		// Token: 0x0404EA5E RID: 322142 RVA: 0x00146558 File Offset: 0x00144758
		static readonly int fdTWEp3hJq;

		// Token: 0x0404EA5F RID: 322143 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int e6MIUNCUTG;

		// Token: 0x0404EA60 RID: 322144 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int rBaEocXKPl;

		// Token: 0x0404EA61 RID: 322145 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 2HCn8Vv28J;

		// Token: 0x0404EA62 RID: 322146 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int aJCZuKSLSv;

		// Token: 0x0404EA63 RID: 322147 RVA: 0x00146558 File Offset: 0x00144758
		static readonly int VzovWdDOrm;

		// Token: 0x0404EA64 RID: 322148 RVA: 0x00146560 File Offset: 0x00144760
		static readonly int StRiyW3iJ9;

		// Token: 0x0404EA65 RID: 322149 RVA: 0x00146568 File Offset: 0x00144768
		static readonly int bKWKpi8AUe;

		// Token: 0x0404EA66 RID: 322150 RVA: 0x00146570 File Offset: 0x00144770
		static readonly int JL1dPCdRQe;

		// Token: 0x0404EA67 RID: 322151 RVA: 0x00146578 File Offset: 0x00144778
		static readonly int RgKW0r1ekX;

		// Token: 0x0404EA68 RID: 322152 RVA: 0x00146580 File Offset: 0x00144780
		static readonly int QuCTTKcdFy;

		// Token: 0x0404EA69 RID: 322153 RVA: 0x00146588 File Offset: 0x00144788
		static readonly int fC4NcG1ySw;

		// Token: 0x0404EA6A RID: 322154 RVA: 0x00146590 File Offset: 0x00144790
		static readonly int 3mRor5AAT8;

		// Token: 0x0404EA6B RID: 322155 RVA: 0x00146598 File Offset: 0x00144798
		static readonly int qeZ6NZJiKF;

		// Token: 0x0404EA6C RID: 322156 RVA: 0x001465A0 File Offset: 0x001447A0
		static readonly int j9Lc9Ol63u;

		// Token: 0x0404EA6D RID: 322157 RVA: 0x001465A8 File Offset: 0x001447A8
		static readonly int zDLydncXlY;

		// Token: 0x0404EA6E RID: 322158 RVA: 0x001465B0 File Offset: 0x001447B0
		static readonly int KcKHIAn7AC;

		// Token: 0x0404EA6F RID: 322159 RVA: 0x001465B8 File Offset: 0x001447B8
		static readonly int 6TnNM4azpc;

		// Token: 0x0404EA70 RID: 322160 RVA: 0x001465C0 File Offset: 0x001447C0
		static readonly int TDHjImSldj;

		// Token: 0x0404EA71 RID: 322161 RVA: 0x001465C8 File Offset: 0x001447C8
		static readonly int 7v6v4HzET8;

		// Token: 0x0404EA72 RID: 322162 RVA: 0x001465D0 File Offset: 0x001447D0
		static readonly int ln60xfZ8lj;

		// Token: 0x0404EA73 RID: 322163 RVA: 0x001465D8 File Offset: 0x001447D8
		static readonly int NmsJEGVl8f;

		// Token: 0x0404EA74 RID: 322164 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int sCeaFLX2SF;

		// Token: 0x0404EA75 RID: 322165 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int EWfq1pHQvn;

		// Token: 0x0404EA76 RID: 322166 RVA: 0x001465E0 File Offset: 0x001447E0
		static readonly int MU93WUCxrx;

		// Token: 0x0404EA77 RID: 322167 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int wOFxQiJfum;

		// Token: 0x0404EA78 RID: 322168 RVA: 0x001465E8 File Offset: 0x001447E8
		static readonly int Ihpfe1GCRZ;

		// Token: 0x0404EA79 RID: 322169 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 9EzVTXCkDv;

		// Token: 0x0404EA7A RID: 322170 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int IjKfT0QsZS;

		// Token: 0x0404EA7B RID: 322171 RVA: 0x001465F0 File Offset: 0x001447F0
		static readonly int glfJeopdYe;

		// Token: 0x0404EA7C RID: 322172 RVA: 0x001465F8 File Offset: 0x001447F8
		static readonly int NAfRyrYue2;

		// Token: 0x0404EA7D RID: 322173 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int gic9eiWKMo;

		// Token: 0x0404EA7E RID: 322174 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lYm92Xjp1o;

		// Token: 0x0404EA7F RID: 322175 RVA: 0x00146600 File Offset: 0x00144800
		static readonly int siMiiHE2ql;

		// Token: 0x0404EA80 RID: 322176 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int bfNgw7Jfp5;

		// Token: 0x0404EA81 RID: 322177 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int ReRu3yXgZb;

		// Token: 0x0404EA82 RID: 322178 RVA: 0x00146608 File Offset: 0x00144808
		static readonly int Is30K7W3bW;

		// Token: 0x0404EA83 RID: 322179 RVA: 0x001465E0 File Offset: 0x001447E0
		static readonly int edelMFLGN5;

		// Token: 0x0404EA84 RID: 322180 RVA: 0x001465E8 File Offset: 0x001447E8
		static readonly int NDA5WNRbpt;

		// Token: 0x0404EA85 RID: 322181 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int uhdOdtmXWz;

		// Token: 0x0404EA86 RID: 322182 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lQESbyAqiy;

		// Token: 0x0404EA87 RID: 322183 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int nRSeNEs8d6;

		// Token: 0x0404EA88 RID: 322184 RVA: 0x00146608 File Offset: 0x00144808
		static readonly int p4Nsm6APHd;

		// Token: 0x0404EA89 RID: 322185 RVA: 0x00146610 File Offset: 0x00144810
		static readonly int cxtYT78rei;

		// Token: 0x0404EA8A RID: 322186 RVA: 0x00146618 File Offset: 0x00144818
		static readonly int Nl30FcP9BZ;

		// Token: 0x0404EA8B RID: 322187 RVA: 0x00146620 File Offset: 0x00144820
		static readonly int Ao4ZJrCWqe;

		// Token: 0x0404EA8C RID: 322188 RVA: 0x00146628 File Offset: 0x00144828
		static readonly int yviFV0h4KQ;

		// Token: 0x0404EA8D RID: 322189 RVA: 0x00146630 File Offset: 0x00144830
		static readonly int FAd4tDBWmK;

		// Token: 0x0404EA8E RID: 322190 RVA: 0x00146638 File Offset: 0x00144838
		static readonly int rAOscy3TOm;

		// Token: 0x0404EA8F RID: 322191 RVA: 0x00146640 File Offset: 0x00144840
		static readonly int 4mB9ucDxfP;

		// Token: 0x0404EA90 RID: 322192 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int 4UzuTAK9qF;

		// Token: 0x0404EA91 RID: 322193 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ppugwxgzmg;

		// Token: 0x0404EA92 RID: 322194 RVA: 0x00146648 File Offset: 0x00144848
		static readonly int 7OpiWd8eKR;

		// Token: 0x0404EA93 RID: 322195 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int AN1XPXLdZb;

		// Token: 0x0404EA94 RID: 322196 RVA: 0x00146650 File Offset: 0x00144850
		static readonly int n4nJ6O2fM6;

		// Token: 0x0404EA95 RID: 322197 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 5NK8SqoQY0;

		// Token: 0x0404EA96 RID: 322198 RVA: 0x00146658 File Offset: 0x00144858
		static readonly int CqyZEcyWQZ;

		// Token: 0x0404EA97 RID: 322199 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int mCaL3CkgmH;

		// Token: 0x0404EA98 RID: 322200 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int kdRNVxC2Fj;

		// Token: 0x0404EA99 RID: 322201 RVA: 0x00146660 File Offset: 0x00144860
		static readonly int s4FiY7FOEe;

		// Token: 0x0404EA9A RID: 322202 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int afOxT2w9FP;

		// Token: 0x0404EA9B RID: 322203 RVA: 0x00146668 File Offset: 0x00144868
		static readonly int FHoQPjYlDR;

		// Token: 0x0404EA9C RID: 322204 RVA: 0x00146670 File Offset: 0x00144870
		static readonly int Z5Rrqs72w5;

		// Token: 0x0404EA9D RID: 322205 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 7WcIrFOe3c;

		// Token: 0x0404EA9E RID: 322206 RVA: 0x00146650 File Offset: 0x00144850
		static readonly int ADx0dlQyTz;

		// Token: 0x0404EA9F RID: 322207 RVA: 0x00146658 File Offset: 0x00144858
		static readonly int ieKwEeOhGl;

		// Token: 0x0404EAA0 RID: 322208 RVA: 0x00146660 File Offset: 0x00144860
		static readonly int 54MJRtpfjK;

		// Token: 0x0404EAA1 RID: 322209 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int U4rlQWIbNF;

		// Token: 0x0404EAA2 RID: 322210 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int bIi7WdMpEM;

		// Token: 0x0404EAA3 RID: 322211 RVA: 0x00146678 File Offset: 0x00144878
		static readonly int 0rXRgG0niu;

		// Token: 0x0404EAA4 RID: 322212 RVA: 0x00146680 File Offset: 0x00144880
		static readonly int 6uOJeowjgr;

		// Token: 0x0404EAA5 RID: 322213 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int WxTBKxVPwy;

		// Token: 0x0404EAA6 RID: 322214 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int h9bWTngZEK;

		// Token: 0x0404EAA7 RID: 322215 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ge2dJq3Zcs;

		// Token: 0x0404EAA8 RID: 322216 RVA: 0x00146688 File Offset: 0x00144888
		static readonly int qmJW0DYWHt;

		// Token: 0x0404EAA9 RID: 322217 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ul0tN6S201;

		// Token: 0x0404EAAA RID: 322218 RVA: 0x00146690 File Offset: 0x00144890
		static readonly int HXeVL14z1d;

		// Token: 0x0404EAAB RID: 322219 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 36xEH4zFgP;

		// Token: 0x0404EAAC RID: 322220 RVA: 0x00146698 File Offset: 0x00144898
		static readonly int PJSVa4nIQM;

		// Token: 0x0404EAAD RID: 322221 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int XBiklTHyL8;

		// Token: 0x0404EAAE RID: 322222 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int JienzxywmS;

		// Token: 0x0404EAAF RID: 322223 RVA: 0x001466A0 File Offset: 0x001448A0
		static readonly int GNVlm7EJ5Q;

		// Token: 0x0404EAB0 RID: 322224 RVA: 0x001466A8 File Offset: 0x001448A8
		static readonly int OvjpF2YMcy;

		// Token: 0x0404EAB1 RID: 322225 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int wB3hFqpofm;

		// Token: 0x0404EAB2 RID: 322226 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int G1g7FJq78n;

		// Token: 0x0404EAB3 RID: 322227 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int O825uY9zh7;

		// Token: 0x0404EAB4 RID: 322228 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ZlTxgFUxf5;

		// Token: 0x0404EAB5 RID: 322229 RVA: 0x001466B0 File Offset: 0x001448B0
		static readonly int SZoSJWOlk6;

		// Token: 0x0404EAB6 RID: 322230 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int MaNzjyI8xr;

		// Token: 0x0404EAB7 RID: 322231 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int r0HhNehsbA;

		// Token: 0x0404EAB8 RID: 322232 RVA: 0x001466B8 File Offset: 0x001448B8
		static readonly int z2bCVzTkvX;

		// Token: 0x0404EAB9 RID: 322233 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int JXPlv8XeOs;

		// Token: 0x0404EABA RID: 322234 RVA: 0x001466C0 File Offset: 0x001448C0
		static readonly int 6WAyNcSGFp;

		// Token: 0x0404EABB RID: 322235 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ygKjGT8Ldu;

		// Token: 0x0404EABC RID: 322236 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int eiMZhUkfwO;

		// Token: 0x0404EABD RID: 322237 RVA: 0x001466C8 File Offset: 0x001448C8
		static readonly int GDetEd2ny3;

		// Token: 0x0404EABE RID: 322238 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int gNfGjnNpeb;

		// Token: 0x0404EABF RID: 322239 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int AMAeNXJkQ3;

		// Token: 0x0404EAC0 RID: 322240 RVA: 0x001466D0 File Offset: 0x001448D0
		static readonly int 1wU0ivBafn;

		// Token: 0x0404EAC1 RID: 322241 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int bVWkNRDG04;

		// Token: 0x0404EAC2 RID: 322242 RVA: 0x001466D8 File Offset: 0x001448D8
		static readonly int G5AUO3C9fq;

		// Token: 0x0404EAC3 RID: 322243 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int TRX4Bu3oiy;

		// Token: 0x0404EAC4 RID: 322244 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int lwK1Ao0aR6;

		// Token: 0x0404EAC5 RID: 322245 RVA: 0x001466E0 File Offset: 0x001448E0
		static readonly int TDuVx5v9mo;

		// Token: 0x0404EAC6 RID: 322246 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int sC4yTK8bic;

		// Token: 0x0404EAC7 RID: 322247 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int YZiCSTvJUj;

		// Token: 0x0404EAC8 RID: 322248 RVA: 0x001466E8 File Offset: 0x001448E8
		static readonly int DmrjWQgBHF;

		// Token: 0x0404EAC9 RID: 322249 RVA: 0x001466F0 File Offset: 0x001448F0
		static readonly int 93B3Fi1Viz;

		// Token: 0x0404EACA RID: 322250 RVA: 0x001466D0 File Offset: 0x001448D0
		static readonly int qY2zi4fsCd;

		// Token: 0x0404EACB RID: 322251 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int KmpDlGUVbD;

		// Token: 0x0404EACC RID: 322252 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int n6TcdeXo6u;

		// Token: 0x0404EACD RID: 322253 RVA: 0x001466E0 File Offset: 0x001448E0
		static readonly int cZle2ot2Bc;

		// Token: 0x0404EACE RID: 322254 RVA: 0x001466F8 File Offset: 0x001448F8
		static readonly int uy8o5XO8S9;

		// Token: 0x0404EACF RID: 322255 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int Og4eMuFZVD;

		// Token: 0x0404EAD0 RID: 322256 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int g0vSBvAKK6;

		// Token: 0x0404EAD1 RID: 322257 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int WbT8Sz8phG;

		// Token: 0x0404EAD2 RID: 322258 RVA: 0x00146700 File Offset: 0x00144900
		static readonly int QZV7f5eGSI;

		// Token: 0x0404EAD3 RID: 322259 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jTh853CpnJ;

		// Token: 0x0404EAD4 RID: 322260 RVA: 0x00146708 File Offset: 0x00144908
		static readonly int WDxVmwM5MX;

		// Token: 0x0404EAD5 RID: 322261 RVA: 0x00146710 File Offset: 0x00144910
		static readonly int vZ2PwHfyxF;

		// Token: 0x0404EAD6 RID: 322262 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int R41CXC4VCY;

		// Token: 0x0404EAD7 RID: 322263 RVA: 0x00146718 File Offset: 0x00144918
		static readonly int wSCYtNl9Ut;

		// Token: 0x0404EAD8 RID: 322264 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ti45WKbRLy;

		// Token: 0x0404EAD9 RID: 322265 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int YN2h1cLv8j;

		// Token: 0x0404EADA RID: 322266 RVA: 0x00146720 File Offset: 0x00144920
		static readonly int 202xkcWegj;

		// Token: 0x0404EADB RID: 322267 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int ffeEVs96pN;

		// Token: 0x0404EADC RID: 322268 RVA: 0x00146728 File Offset: 0x00144928
		static readonly int lnJO9iaegR;

		// Token: 0x0404EADD RID: 322269 RVA: 0x00146730 File Offset: 0x00144930
		static readonly int B0Bu02pHU3;

		// Token: 0x0404EADE RID: 322270 RVA: 0x00146738 File Offset: 0x00144938
		static readonly int x7vmT3tyMJ;

		// Token: 0x0404EADF RID: 322271 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int dPFv8OroxB;

		// Token: 0x0404EAE0 RID: 322272 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int C17PhpetNd;

		// Token: 0x0404EAE1 RID: 322273 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int D2lwZn2h5G;

		// Token: 0x0404EAE2 RID: 322274 RVA: 0x00146728 File Offset: 0x00144928
		static readonly int zmSXywuPvl;

		// Token: 0x0404EAE3 RID: 322275 RVA: 0x00146740 File Offset: 0x00144940
		static readonly int LATS169fEn;

		// Token: 0x0404EAE4 RID: 322276 RVA: 0x00146748 File Offset: 0x00144948
		static readonly int Z9ksFknTWU;

		// Token: 0x0404EAE5 RID: 322277 RVA: 0x00146750 File Offset: 0x00144950
		static readonly int WJtrMZikbv;

		// Token: 0x0404EAE6 RID: 322278 RVA: 0x00146758 File Offset: 0x00144958
		static readonly int 4O7lSCiS4d;

		// Token: 0x0404EAE7 RID: 322279 RVA: 0x00146760 File Offset: 0x00144960
		static readonly int oWcRq0BkRN;

		// Token: 0x0404EAE8 RID: 322280 RVA: 0x00146768 File Offset: 0x00144968
		static readonly int Ib3bPBRmGc;

		// Token: 0x0404EAE9 RID: 322281 RVA: 0x00146770 File Offset: 0x00144970
		static readonly int XZEStLB9aD;

		// Token: 0x0404EAEA RID: 322282 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int BUZ3qArcAW;

		// Token: 0x0404EAEB RID: 322283 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int X8TNndVgWQ;

		// Token: 0x0404EAEC RID: 322284 RVA: 0x00146778 File Offset: 0x00144978
		static readonly int u6McFPRJif;

		// Token: 0x0404EAED RID: 322285 RVA: 0x00146780 File Offset: 0x00144980
		static readonly int yCJNLxCAuO;

		// Token: 0x0404EAEE RID: 322286 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int UyltEYG0pP;

		// Token: 0x0404EAEF RID: 322287 RVA: 0x00146788 File Offset: 0x00144988
		static readonly int zenJSEI7xb;

		// Token: 0x0404EAF0 RID: 322288 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int sh4ehVyFCz;

		// Token: 0x0404EAF1 RID: 322289 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int bVwH66VcXr;

		// Token: 0x0404EAF2 RID: 322290 RVA: 0x00146790 File Offset: 0x00144990
		static readonly int JadSqUZ95G;

		// Token: 0x0404EAF3 RID: 322291 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int pENTfw4HMs;

		// Token: 0x0404EAF4 RID: 322292 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jAy0yesfNW;

		// Token: 0x0404EAF5 RID: 322293 RVA: 0x00146798 File Offset: 0x00144998
		static readonly int tpjFRSDlyN;

		// Token: 0x0404EAF6 RID: 322294 RVA: 0x001467A0 File Offset: 0x001449A0
		static readonly int 6zK5JWHcmK;

		// Token: 0x0404EAF7 RID: 322295 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int BNQoHIlmeL;

		// Token: 0x0404EAF8 RID: 322296 RVA: 0x00146790 File Offset: 0x00144990
		static readonly int l4wiXAfHBN;

		// Token: 0x0404EAF9 RID: 322297 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int sTS8wu03rc;

		// Token: 0x0404EAFA RID: 322298 RVA: 0x001467A8 File Offset: 0x001449A8
		static readonly int WP2CVgY48J;

		// Token: 0x0404EAFB RID: 322299 RVA: 0x001467B0 File Offset: 0x001449B0
		static readonly int qbHnlCClhI;

		// Token: 0x0404EAFC RID: 322300 RVA: 0x001467B8 File Offset: 0x001449B8
		static readonly int 0AbYbr4S2W;

		// Token: 0x0404EAFD RID: 322301 RVA: 0x001467C0 File Offset: 0x001449C0
		static readonly int Rs5ByWBtM1;

		// Token: 0x0404EAFE RID: 322302 RVA: 0x001467C8 File Offset: 0x001449C8
		static readonly int mkJ2hRLpWu;

		// Token: 0x0404EAFF RID: 322303 RVA: 0x001467D0 File Offset: 0x001449D0
		static readonly int sOVjlWydln;

		// Token: 0x0404EB00 RID: 322304 RVA: 0x001467D8 File Offset: 0x001449D8
		static readonly int lGCl17gFyP;

		// Token: 0x0404EB01 RID: 322305 RVA: 0x001467E0 File Offset: 0x001449E0
		static readonly int ASZqgP1i1K;

		// Token: 0x0404EB02 RID: 322306 RVA: 0x001467E8 File Offset: 0x001449E8
		static readonly int gO5HoDWVac;
	}
}
