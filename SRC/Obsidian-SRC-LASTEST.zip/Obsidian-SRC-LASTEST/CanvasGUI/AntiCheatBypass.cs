﻿using System;
using HarmonyLib;

namespace CanvasGUI
{
	// Token: 0x02000028 RID: 40
	[HarmonyPatch(typeof(GorillaNot), "SendReport")]
	internal class AntiCheatBypass
	{
		// Token: 0x060001CB RID: 459 RVA: 0x00638130 File Offset: 0x00636330
		private unsafe static bool Prefix(string susReason, string susId, string susNick)
		{
			"_______________________________________________________The Fryer" != "_______________________________________________________The Fryer";
			if ((*(&AntiCheatBypass.D8n2hwGGo3) ^ *(&AntiCheatBypass.D8n2hwGGo3)) != 0)
			{
				goto IL_24;
			}
			goto IL_68C;
			uint num2;
			int[] array;
			bool result;
			for (;;)
			{
				IL_29:
				uint num;
				switch ((num = (num2 ^ (uint)(*(&AntiCheatBypass.cfDvrvvAO2)))) % (uint)(*(&AntiCheatBypass.K45CYKVdmX) + *(&AntiCheatBypass.fAw2a6KNQU)))
				{
				case 0U:
				{
					susNick.Remove(calli(Photon.Realtime.Player(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array[3] ^ array[4]) - array[5]]).NickName.Length);
					susId.Remove(calli(Photon.Realtime.Player(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array[6] ^ array[7]) - array[8]]).UserId.Length);
					uint[] array2 = new uint[*(&AntiCheatBypass.oOBiOBXPyV)];
					array2[*(&AntiCheatBypass.pccxmADarc)] = (uint)(*(&AntiCheatBypass.g42721V3TA) + *(&AntiCheatBypass.KM5Do5BYFC));
					array2[*(&AntiCheatBypass.nEu9fbKynS)] = (uint)(*(&AntiCheatBypass.eQ5xSuVDpX));
					array2[*(&AntiCheatBypass.pe6yKcgZIr)] = (uint)(*(&AntiCheatBypass.8oVozcJ2ba));
					uint num3 = (num - array2[*(&AntiCheatBypass.qgQBf4RHu3)]) * (uint)(*(&AntiCheatBypass.j7tsXIH6zD));
					num2 = ((num3 | array2[*(&AntiCheatBypass.5vp5Tz5Q70)]) ^ (uint)(*(&AntiCheatBypass.kclOqIN5SQ)));
					continue;
				}
				case 1U:
				{
					int[] array3;
					int num5;
					int num4 = array3[num5 + 8 - num5] ^ -1;
					num5 = num4 % 760;
					int num6;
					AntiCheatBypass.vB0NgYFNda = num6;
					num6 = (num4 & 235928151);
					uint num7 = ((num & (uint)(*(&AntiCheatBypass.WU58GdYPE5))) ^ (uint)(*(&AntiCheatBypass.gESC0McVHq))) - (uint)(*(&AntiCheatBypass.TCKmyw1XSi));
					num2 = ((num7 | (uint)(*(&AntiCheatBypass.uYwvZEdxk9))) ^ (uint)(*(&AntiCheatBypass.Kc8SFcjN69)));
					continue;
				}
				case 2U:
				{
					int num6 = 1782861380;
					uint[] array4 = new uint[*(&AntiCheatBypass.Ja4QbXC3rQ)];
					array4[*(&AntiCheatBypass.4ZozYaj22X)] = (uint)(*(&AntiCheatBypass.LgVNFwpqcF) + *(&AntiCheatBypass.cjccPfD2UG));
					array4[*(&AntiCheatBypass.y95angGzjE)] = (uint)(*(&AntiCheatBypass.SYgYCmFrLp));
					array4[*(&AntiCheatBypass.rWalxU7Mj2)] = (uint)(*(&AntiCheatBypass.XrhwiLl4ji));
					array4[*(&AntiCheatBypass.p0GXxDCDZm)] = (uint)(*(&AntiCheatBypass.aWroYbjTmS));
					uint num8 = num ^ array4[*(&AntiCheatBypass.i3Pqrk0tz0)];
					uint num9 = num8 * array4[*(&AntiCheatBypass.BLHm91PCyu)];
					uint num10 = num9 & (uint)(*(&AntiCheatBypass.R4w7cBA2YH) + *(&AntiCheatBypass.mRRQ9vlZqN));
					num2 = ((num10 & (uint)(*(&AntiCheatBypass.MSNjkOOEph) + *(&AntiCheatBypass.Lhf1BoHROq))) ^ (uint)(*(&AntiCheatBypass.k8VsNu30mN)));
					continue;
				}
				case 3U:
				{
					int num6;
					int num4 = ~num6;
					uint num11 = (num | (uint)(*(&AntiCheatBypass.CM8QGaLHRx))) * (uint)(*(&AntiCheatBypass.iTHOTSsmFY));
					uint num12 = num11 ^ (uint)(*(&AntiCheatBypass.4wvC13Qp9W));
					num2 = (num12 ^ (uint)(*(&AntiCheatBypass.qznZifM5dR)) ^ (uint)(*(&AntiCheatBypass.BMIUSCmgzh) + *(&AntiCheatBypass.XGx1VPa5YM)));
					continue;
				}
				case 4U:
					goto IL_24;
				case 5U:
				{
					int num6;
					int num5 = num6 >> 7;
					num2 = (num + (uint)(*(&AntiCheatBypass.YsoWOEJBuB)) + (uint)(*(&AntiCheatBypass.hTn87t9NpY)) - (uint)(*(&AntiCheatBypass.67Iwd12nqh)) ^ (uint)(*(&AntiCheatBypass.6vo7f1RZvN)));
					continue;
				}
				case 6U:
				{
					array[5] = 258208859;
					uint[] array5 = new uint[*(&AntiCheatBypass.WDmhbbPU8o)];
					array5[*(&AntiCheatBypass.VK0A0oqUKW)] = (uint)(*(&AntiCheatBypass.t8q1GuY4N2) + *(&AntiCheatBypass.FPa8kBtkIQ));
					array5[*(&AntiCheatBypass.gZrFB4lgD1)] = (uint)(*(&AntiCheatBypass.YFnxwYWvaq));
					array5[*(&AntiCheatBypass.CVHFiGt1az) + *(&AntiCheatBypass.4FM4zTRl0L)] = (uint)(*(&AntiCheatBypass.I20VdAmmLM));
					array5[*(&AntiCheatBypass.o8JbNKSlh5)] = (uint)(*(&AntiCheatBypass.KuGO6T3s7c));
					array5[*(&AntiCheatBypass.Gv4OiKevmi)] = (uint)(*(&AntiCheatBypass.dHpNK65uqp));
					array5[*(&AntiCheatBypass.BpE5BYwmYK) + *(&AntiCheatBypass.G3ptF3D43D)] = (uint)(*(&AntiCheatBypass.pg98bDE2DA));
					uint num13 = num + array5[*(&AntiCheatBypass.XICSbbr9NJ)];
					uint num14 = num13 * (uint)(*(&AntiCheatBypass.Y2Xbbkc6IQ));
					uint num15 = num14 ^ (uint)(*(&AntiCheatBypass.2A1n9epFd7));
					uint num16 = num15 - array5[*(&AntiCheatBypass.U3iXx81WSn) + *(&AntiCheatBypass.MDrtpxJig0)] + array5[*(&AntiCheatBypass.lHtwHWRYT6)];
					num2 = (num16 + (uint)(*(&AntiCheatBypass.wlfQzeT9od)) ^ (uint)(*(&AntiCheatBypass.tFoeEzTH8L)));
					continue;
				}
				case 7U:
				{
					int num5;
					int num4;
					num5 += num4;
					uint[] array6 = new uint[*(&AntiCheatBypass.Tmomw2s0c1)];
					array6[*(&AntiCheatBypass.X0JFJIPUVa)] = (uint)(*(&AntiCheatBypass.ryQTvgIedm));
					array6[*(&AntiCheatBypass.GN0opgoCwT)] = (uint)(*(&AntiCheatBypass.Oydkh7Qkim));
					array6[*(&AntiCheatBypass.yfzkhfVV1Q) + *(&AntiCheatBypass.tNXzvJAeam)] = (uint)(*(&AntiCheatBypass.dMiBL3Vpwx));
					array6[*(&AntiCheatBypass.Qh50ykYQHK)] = (uint)(*(&AntiCheatBypass.LTLfjAanzX));
					array6[*(&AntiCheatBypass.7vJ6Il7xYo)] = (uint)(*(&AntiCheatBypass.JpiDAMSgAK));
					array6[*(&AntiCheatBypass.uuXQaKBCcL)] = (uint)(*(&AntiCheatBypass.cr0Y0fY9sN));
					uint num17 = num + array6[*(&AntiCheatBypass.nl2dAfuIfX)] - (uint)(*(&AntiCheatBypass.s3nonNY3f7) + *(&AntiCheatBypass.j4UMMczKNe));
					uint num18 = (num17 | (uint)(*(&AntiCheatBypass.xSywhJ23Q5))) - (uint)(*(&AntiCheatBypass.a3hFciDLvm));
					uint num19 = num18 ^ array6[*(&AntiCheatBypass.HedunsQpRh)];
					num2 = (num19 * array6[*(&AntiCheatBypass.pk4AjZF1Gd) + *(&AntiCheatBypass.VenkhqXPun)] ^ (uint)(*(&AntiCheatBypass.YnYkXTzDIz)));
					continue;
				}
				case 8U:
				{
					int[] array7 = array;
					int num20 = 11;
					int num21 = (array[11] ^ -267) + -103 << 1;
					int num22 = (-404 == 0) ? (num21 - 45) : (num21 + -404);
					array7[num20] = (array[11] ^ num22 ^ (1907835093 ^ num22));
					num2 = 2668335920U;
					continue;
				}
				case 9U:
				{
					int num5;
					int num4 = (int)((sbyte)num5);
					int num6;
					num2 = (((num6 > num6) ? 1706236218U : 2021829625U) ^ num * 3389085657U);
					continue;
				}
				case 10U:
					goto IL_68C;
				case 11U:
				{
					int[] array8 = array;
					int num23 = 6;
					int num22 = (array[6] >> 1 << 2) + -270 << 4;
					array8[num23] = (array[6] ^ num22 ^ (1907835093 ^ num22));
					uint num24 = num - (uint)(*(&AntiCheatBypass.akOV8OhWfP));
					uint num25 = num24 | (uint)(*(&AntiCheatBypass.pAqbhLHqwR));
					num2 = (((num25 | (uint)(*(&AntiCheatBypass.VZs1QNKi5e))) - (uint)(*(&AntiCheatBypass.V5JyASlHdn)) | (uint)(*(&AntiCheatBypass.UuNU0nHZAx))) ^ (uint)(*(&AntiCheatBypass.KjoBFB2XFu)));
					continue;
				}
				case 12U:
				{
					int[] array9 = array;
					int num26 = 7;
					int num22 = ((array[7] ^ -20) + -258) * -474 - 345 ^ 47;
					array9[num26] = (array[7] ^ num22 ^ (1907835093 ^ num22));
					uint num27 = num & (uint)(*(&AntiCheatBypass.E8aA3t11aO));
					uint num28 = (num27 | (uint)(*(&AntiCheatBypass.j9MI7lLXAm))) * (uint)(*(&AntiCheatBypass.GviIUwRHt8)) & (uint)(*(&AntiCheatBypass.ZNCsiWTNaG));
					num2 = (num28 + (uint)(*(&AntiCheatBypass.vP8vNLWfEe)) ^ (uint)(*(&AntiCheatBypass.0eWcoTZSqG)) ^ (uint)(*(&AntiCheatBypass.cuIbyW6ejl) + *(&AntiCheatBypass.R76410wx5I)));
					continue;
				}
				case 13U:
					num2 = 4126839605U;
					continue;
				case 14U:
				{
					calli(System.Void(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array[9] ^ array[10]) - array[11]]);
					uint num29 = num | (uint)(*(&AntiCheatBypass.LYoPIB5mRr));
					uint num30 = num29 * (uint)(*(&AntiCheatBypass.UNDYf50Urp)) * (uint)(*(&AntiCheatBypass.8BJ3SGVeBO)) & (uint)(*(&AntiCheatBypass.5Mni1gGaxS));
					num2 = ((num30 & (uint)(*(&AntiCheatBypass.4S8QgXZNtu))) * (uint)(*(&AntiCheatBypass.R3NmRKOv6B)) ^ (uint)(*(&AntiCheatBypass.palDvIjeg8)));
					continue;
				}
				case 15U:
				{
					int num5;
					num2 = (((num5 > num5) ? 3565273093U : 4230891350U) ^ num * 3487460692U);
					continue;
				}
				case 16U:
				{
					int num5;
					int num6;
					num6 -= num5;
					int num4 = num5 | 39098630;
					num2 = (((num ^ (uint)(*(&AntiCheatBypass.p52Xpsi2xS))) & (uint)(*(&AntiCheatBypass.EIlBUtH8OZ))) + (uint)(*(&AntiCheatBypass.ZaoPgF1onl)) + (uint)(*(&AntiCheatBypass.ue4RyqBu1t)) ^ (uint)(*(&AntiCheatBypass.IvZSVefKn9)));
					continue;
				}
				case 17U:
				{
					int[] array10 = array;
					int num31 = 10;
					int num32 = ((array[10] & 483) | -174) % 11;
					int num22 = (297 == 0) ? (num32 - 63) : (num32 + 297);
					array10[num31] = (array[10] ^ num22 ^ (1907835093 ^ num22));
					num2 = 2624521064U;
					continue;
				}
				case 18U:
				{
					int num5;
					int num6;
					int num4 = num6 + num5;
					num6 = num5 - num4;
					num5 <<= 2;
					uint[] array11 = new uint[*(&AntiCheatBypass.n9lcNUqtZk)];
					array11[*(&AntiCheatBypass.ba7QbiI1N4)] = (uint)(*(&AntiCheatBypass.z9MaF8N2tf) + *(&AntiCheatBypass.dC2v0v3Ems));
					array11[*(&AntiCheatBypass.1VxTIOGeyd)] = (uint)(*(&AntiCheatBypass.z6iHwoxKXO));
					array11[*(&AntiCheatBypass.GxA3HZiMZp)] = (uint)(*(&AntiCheatBypass.pEOfCeM2R1));
					array11[*(&AntiCheatBypass.1tEQpgdu9M)] = (uint)(*(&AntiCheatBypass.8sqXlDV3Mt));
					num2 = ((num * (uint)(*(&AntiCheatBypass.p4EIyvrDER)) | array11[*(&AntiCheatBypass.b43gXWttOk)] | array11[*(&AntiCheatBypass.6xMNq6Y039)] | (uint)(*(&AntiCheatBypass.ITpiL6p5c4))) ^ (uint)(*(&AntiCheatBypass.yZpruDzKAO)));
					continue;
				}
				case 19U:
				{
					uint[] array12 = new uint[*(&AntiCheatBypass.Z2Oxt7KTTu)];
					array12[*(&AntiCheatBypass.nak5pLNPZg)] = (uint)(*(&AntiCheatBypass.RaNYpCRce4) + *(&AntiCheatBypass.IEBmSdrwmv));
					array12[*(&AntiCheatBypass.Fw9CTvB2rG)] = (uint)(*(&AntiCheatBypass.MGLgV9pzIq));
					array12[*(&AntiCheatBypass.qsyYljY8mM)] = (uint)(*(&AntiCheatBypass.ebnnafaLE3) + *(&AntiCheatBypass.AYvXsC3eQT));
					array12[*(&AntiCheatBypass.x1o5EX7lau)] = (uint)(*(&AntiCheatBypass.WDQemudhF0) + *(&AntiCheatBypass.iduOpS6bqj));
					uint num33 = num + (uint)(*(&AntiCheatBypass.q4rTYmxrjD)) ^ array12[*(&AntiCheatBypass.hzvUg7IRu7)];
					num2 = (num33 * (uint)(*(&AntiCheatBypass.jVZauUHZPv)) ^ (uint)(*(&AntiCheatBypass.af50EcW6F9)) ^ (uint)(*(&AntiCheatBypass.7v8BTssass)));
					continue;
				}
				case 20U:
					num2 = 3082648971U;
					continue;
				case 21U:
				{
					uint[] array13 = new uint[*(&AntiCheatBypass.SNODW1alz6)];
					array13[*(&AntiCheatBypass.d4MvDSuTmH)] = (uint)(*(&AntiCheatBypass.zJ0DeFZKlT));
					array13[*(&AntiCheatBypass.mZ9QhhAyrD)] = (uint)(*(&AntiCheatBypass.HPtGweMMMa));
					array13[*(&AntiCheatBypass.lUYfIIWKiR)] = (uint)(*(&AntiCheatBypass.cQ9gTD45Ng) + *(&AntiCheatBypass.R5li9kauRA));
					array13[*(&AntiCheatBypass.2M7LsRBdHY)] = (uint)(*(&AntiCheatBypass.K0Pal1PMws));
					array13[*(&AntiCheatBypass.jQ9qJptzgi) + *(&AntiCheatBypass.sm3hYPSxyC)] = (uint)(*(&AntiCheatBypass.CbxzVaqL7I));
					num2 = ((((num | (uint)(*(&AntiCheatBypass.UN7ibmMRCC) + *(&AntiCheatBypass.iL7jqi7sBV))) & array13[*(&AntiCheatBypass.jcYuqIcKUs)]) - (uint)(*(&AntiCheatBypass.9h1YNeoUGw)) ^ array13[*(&AntiCheatBypass.DAvvd0dOIw) + *(&AntiCheatBypass.d7Jlj2zM2T)]) * (uint)(*(&AntiCheatBypass.JC7UDAUjVL)) ^ (uint)(*(&AntiCheatBypass.4mmPSirmQz)));
					continue;
				}
				case 22U:
					num2 = 2879704236U;
					continue;
				case 23U:
				{
					int num5;
					int num4 = -num5;
					uint[] array14 = new uint[*(&AntiCheatBypass.ToglkTOYuO)];
					array14[*(&AntiCheatBypass.j5nkfHQcvG)] = (uint)(*(&AntiCheatBypass.CzcvZ8NI7A));
					array14[*(&AntiCheatBypass.smi1WP1U5u)] = (uint)(*(&AntiCheatBypass.2W5VDQpFzj) + *(&AntiCheatBypass.fphModMuMm));
					array14[*(&AntiCheatBypass.GFatf7XvNP) + *(&AntiCheatBypass.P5gBOp4GsJ)] = (uint)(*(&AntiCheatBypass.TITYfDEWN3));
					array14[*(&AntiCheatBypass.DGITow5L0G)] = (uint)(*(&AntiCheatBypass.231jTkJg78));
					array14[*(&AntiCheatBypass.iFCDT7wCOc)] = (uint)(*(&AntiCheatBypass.3AiTMJwNXc));
					uint num34 = num + array14[*(&AntiCheatBypass.tsPlQZQuE4)];
					uint num35 = num34 + array14[*(&AntiCheatBypass.4hYOU7EF9r)] | array14[*(&AntiCheatBypass.A36YN2UiXK)];
					num2 = ((num35 & array14[*(&AntiCheatBypass.x5JfOzzaw3)] & array14[*(&AntiCheatBypass.qB7TiVmT8O)]) ^ (uint)(*(&AntiCheatBypass.EqNqc0v1YY)));
					continue;
				}
				case 24U:
				{
					int num4;
					AntiCheatBypass.vB0NgYFNda = num4;
					uint num36 = (num ^ (uint)(*(&AntiCheatBypass.El7pEPRm1k))) * (uint)(*(&AntiCheatBypass.03OLijOTNn)) * (uint)(*(&AntiCheatBypass.rXHfQoBV3C));
					num2 = (num36 + (uint)(*(&AntiCheatBypass.jrAohIgONj)) ^ (uint)(*(&AntiCheatBypass.ZY3Q2PgNuv)));
					continue;
				}
				case 25U:
				{
					bool flag;
					num2 = ((flag ? 2653163848U : 3511060455U) ^ num * 2447300215U);
					continue;
				}
				case 26U:
				{
					array[0] = 218422573;
					array[1] = 138281460;
					array[2] = 1955437408;
					uint num37 = num - (uint)(*(&AntiCheatBypass.S01wmxpSv9));
					uint num38 = num37 * (uint)(*(&AntiCheatBypass.Inz6dOpG68) + *(&AntiCheatBypass.RQVAC8amP0));
					num2 = (num38 ^ (uint)(*(&AntiCheatBypass.zt2e9iN1ME)) ^ (uint)(*(&AntiCheatBypass.zxl4v0weyg)));
					continue;
				}
				case 27U:
				{
					uint[] array15 = new uint[*(&AntiCheatBypass.EsW4H8Y3Af)];
					array15[*(&AntiCheatBypass.HnSFA85nz2)] = (uint)(*(&AntiCheatBypass.PBjJGGrcCX));
					array15[*(&AntiCheatBypass.D8CYz7pDMj)] = (uint)(*(&AntiCheatBypass.6sTdGaXHpe));
					array15[*(&AntiCheatBypass.5IBfIDJNxA)] = (uint)(*(&AntiCheatBypass.R61mbJl4QC));
					array15[*(&AntiCheatBypass.S1aQ6hsGCp)] = (uint)(*(&AntiCheatBypass.tjxic56hQv));
					array15[*(&AntiCheatBypass.ybQMSA1qC6)] = (uint)(*(&AntiCheatBypass.zd0mLErvjk));
					array15[*(&AntiCheatBypass.VDLIRrITKf) + *(&AntiCheatBypass.NEofO1lO76)] = (uint)(*(&AntiCheatBypass.qBDF0PsKWX));
					uint num39 = num + (uint)(*(&AntiCheatBypass.NK7pavQI4k) + *(&AntiCheatBypass.1hggtuzVYU)) ^ (uint)(*(&AntiCheatBypass.ddxn4T9FRB));
					uint num40 = num39 * (uint)(*(&AntiCheatBypass.986wSDG8Ed));
					num2 = ((num40 + array15[*(&AntiCheatBypass.kdTXEIegWF)] & (uint)(*(&AntiCheatBypass.aWwB4uWUvG))) + array15[*(&AntiCheatBypass.vL03l3luOq)] ^ (uint)(*(&AntiCheatBypass.o0R4tAJaiv)));
					continue;
				}
				case 28U:
					num2 = 3431018189U;
					continue;
				case 29U:
				{
					int[] array16 = array;
					int num41 = 2;
					int num22 = (array[2] << 3) + -129;
					array16[num41] = (array[2] ^ num22 ^ (1907835093 ^ num22));
					int[] array17 = array;
					int num42 = 3;
					num22 = (array[3] % 96 - 246 | -384) >> 1 << 2;
					array17[num42] = (array[3] ^ num22 ^ (1907835093 ^ num22));
					int[] array18 = array;
					int num43 = 4;
					int num44 = array[4];
					int num45 = ((-409 == 0) ? (num44 - 65) : (num44 + -409)) - -416;
					num22 = ~(((316 == 0) ? (num45 - 93) : (num45 + 316)) % 68);
					array18[num43] = (array[4] ^ num22 ^ (1907835093 ^ num22));
					int[] array19 = array;
					int num46 = 5;
					num22 = (array[5] * -282 & -457) + 74 + -276;
					array19[num46] = (array[5] ^ num22 ^ (1907835093 ^ num22));
					num2 = 2797274119U;
					continue;
				}
				case 30U:
				{
					int num4;
					int num5 = num4;
					uint num47 = num + (uint)(*(&AntiCheatBypass.zcsLlmL52i));
					num2 = ((num47 - (uint)(*(&AntiCheatBypass.qvN7rZmavL))) * (uint)(*(&AntiCheatBypass.huSqajF1R3)) - (uint)(*(&AntiCheatBypass.k6w9RTcoR9)) ^ (uint)(*(&AntiCheatBypass.rq1p93nUNU)));
					continue;
				}
				case 31U:
				{
					int num4;
					AntiCheatBypass.vB0NgYFNda = num4;
					uint[] array20 = new uint[*(&AntiCheatBypass.KpqsAVeRiE)];
					array20[*(&AntiCheatBypass.fXcynB44PD)] = (uint)(*(&AntiCheatBypass.kLLv9yWXHC));
					array20[*(&AntiCheatBypass.lqrgkvyM0t)] = (uint)(*(&AntiCheatBypass.8FYAekTKYR));
					array20[*(&AntiCheatBypass.yyLpH9d5tM) + *(&AntiCheatBypass.8HJgdyq5N2)] = (uint)(*(&AntiCheatBypass.MrDfFexLQZ));
					uint num48 = num | (uint)(*(&AntiCheatBypass.fM80NxfCYl));
					num2 = (((num48 | array20[*(&AntiCheatBypass.R3dov151hq)]) & array20[*(&AntiCheatBypass.3X6gEGvpjn)]) ^ (uint)(*(&AntiCheatBypass.LSpUqvITSq)));
					continue;
				}
				case 32U:
				{
					uint[] array21 = new uint[*(&AntiCheatBypass.zZgZvqC3X5)];
					array21[*(&AntiCheatBypass.qIvQ6B8BRr)] = (uint)(*(&AntiCheatBypass.SVewmer4eY));
					array21[*(&AntiCheatBypass.x4qu51Wx1l)] = (uint)(*(&AntiCheatBypass.HVYAUgpUHu) + *(&AntiCheatBypass.JiNzqe5uwR));
					array21[*(&AntiCheatBypass.8HY8HwbAVE)] = (uint)(*(&AntiCheatBypass.oLKpj66dbG));
					array21[*(&AntiCheatBypass.yXxuPPr1Ea)] = (uint)(*(&AntiCheatBypass.6mAjnA7Z3i));
					array21[*(&AntiCheatBypass.Fo8DF7XiPt) + *(&AntiCheatBypass.hbTqclUnt2)] = (uint)(*(&AntiCheatBypass.Fj64HCKkCj));
					uint num49 = (num & array21[*(&AntiCheatBypass.9hk2BKYupR)]) ^ (uint)(*(&AntiCheatBypass.1ImU3eSUHB) + *(&AntiCheatBypass.qTpAdfsD5C));
					uint num50 = num49 - (uint)(*(&AntiCheatBypass.xxfpu91apS));
					uint num51 = num50 | array21[*(&AntiCheatBypass.Mj8cA67lBm)];
					num2 = (num51 + array21[*(&AntiCheatBypass.u0cA3p1jZg)] ^ (uint)(*(&AntiCheatBypass.bVzndEn7k3)));
					continue;
				}
				case 33U:
				{
					bool flag = susId == calli(Photon.Realtime.Player(), Fryer_76fc2c5589044154aa0639a0ff3b3382.Fryer[(array[0] ^ array[1]) - array[2]]).UserId;
					uint num52 = num - (uint)(*(&AntiCheatBypass.awCPI51jDP)) + (uint)(*(&AntiCheatBypass.6BhToAGh61));
					uint num53 = num52 | (uint)(*(&AntiCheatBypass.O15dM2hclx));
					uint num54 = num53 | (uint)(*(&AntiCheatBypass.hlXhqqs3T3));
					num2 = ((num54 & (uint)(*(&AntiCheatBypass.eXaUoQZnP0) + *(&AntiCheatBypass.uO1E4i0iCP))) ^ (uint)(*(&AntiCheatBypass.YZ8QsVoAn8)));
					continue;
				}
				case 34U:
				{
					int num5;
					int num4 = num5;
					uint[] array22 = new uint[*(&AntiCheatBypass.JgH5Gsprqx)];
					array22[*(&AntiCheatBypass.GxIxXsnatz)] = (uint)(*(&AntiCheatBypass.Qu0c8kBvDS));
					array22[*(&AntiCheatBypass.EQgQHfENNj)] = (uint)(*(&AntiCheatBypass.W50Bak7Aen));
					array22[*(&AntiCheatBypass.l9Mj6Zqp6g)] = (uint)(*(&AntiCheatBypass.q3nXs0Q1p2));
					array22[*(&AntiCheatBypass.oaNKcV3yBY)] = (uint)(*(&AntiCheatBypass.nBRaqEE7Us));
					array22[*(&AntiCheatBypass.zYQr3cRcTk) + *(&AntiCheatBypass.TFUm9LwCGk)] = (uint)(*(&AntiCheatBypass.f1oh2omNqn));
					uint num55 = num - array22[*(&AntiCheatBypass.wTh7DPJfQA)];
					uint num56 = num55 - array22[*(&AntiCheatBypass.EbfaFhrobf)] - array22[*(&AntiCheatBypass.SC0tN7uszO)] | array22[*(&AntiCheatBypass.zEwpy9iWjt)];
					num2 = ((num56 & (uint)(*(&AntiCheatBypass.CRvFgEWNcU) + *(&AntiCheatBypass.77vLVucxuF))) ^ (uint)(*(&AntiCheatBypass.faqCK9ozmF)));
					continue;
				}
				case 36U:
					result = false;
					num2 = 3761543276U;
					continue;
				case 37U:
				{
					int num5;
					int num4 = *(ref AntiCheatBypass.vB0NgYFNda + (IntPtr)num5);
					int num6 = num4 / 722;
					uint[] array23 = new uint[*(&AntiCheatBypass.QzVli8qMWN)];
					array23[*(&AntiCheatBypass.x6N15FwZPV)] = (uint)(*(&AntiCheatBypass.oTKAmO7fV0));
					array23[*(&AntiCheatBypass.VXbbRVL4TC)] = (uint)(*(&AntiCheatBypass.845B2ouewI));
					array23[*(&AntiCheatBypass.8dlRj6pV8U) + *(&AntiCheatBypass.BK1g1Zewkk)] = (uint)(*(&AntiCheatBypass.31GNWuYJH8));
					array23[*(&AntiCheatBypass.ecsM22wJ1U)] = (uint)(*(&AntiCheatBypass.qz69AxDZKd));
					array23[*(&AntiCheatBypass.J74MOGXX4z)] = (uint)(*(&AntiCheatBypass.igO90ibon9));
					array23[*(&AntiCheatBypass.nV4P3E5GMj) + *(&AntiCheatBypass.q98ozgig7w)] = (uint)(*(&AntiCheatBypass.eYPCwKl6Jc));
					uint num57 = num - (uint)(*(&AntiCheatBypass.VZvKzyCoTK)) - array23[*(&AntiCheatBypass.LQLVIjhjJT)] & array23[*(&AntiCheatBypass.95q1ePF2dt) + *(&AntiCheatBypass.c87uNRNxyB)] & array23[*(&AntiCheatBypass.d3MxlON33N)] & array23[*(&AntiCheatBypass.nBxzcZs4qk)];
					num2 = (num57 ^ (uint)(*(&AntiCheatBypass.sKLksMTaI1)) ^ (uint)(*(&AntiCheatBypass.VtuI0Ft3QQ)));
					continue;
				}
				case 38U:
				{
					int num6;
					num6 <<= 3;
					int num5 = num6 | 1156993755;
					int num4;
					num5 *= num4;
					num2 = ((num ^ (uint)(*(&AntiCheatBypass.pjRKQewlO2) + *(&AntiCheatBypass.ST6zeXoP4g))) * (uint)(*(&AntiCheatBypass.k139YQVIwR)) * (uint)(*(&AntiCheatBypass.ZEnz2fFX43)) ^ (uint)(*(&AntiCheatBypass.elbRuibmQR)));
					continue;
				}
				case 39U:
				{
					int[] array24 = array;
					int num58 = 1;
					int num22 = array[1] - -297 + -436 + -194;
					array24[num58] = (array[1] ^ num22 ^ (1907835093 ^ num22));
					uint num59 = num * (uint)(*(&AntiCheatBypass.8a3JAubtbH));
					uint num60 = num59 ^ (uint)(*(&AntiCheatBypass.eWBZhHus69));
					uint num61 = num60 * (uint)(*(&AntiCheatBypass.2XEb3i2lP9));
					uint num62 = num61 - (uint)(*(&AntiCheatBypass.PnPS0Bd62Z));
					uint num63 = num62 - (uint)(*(&AntiCheatBypass.BkIoIcIRW4));
					num2 = ((num63 & (uint)(*(&AntiCheatBypass.BAG3wlWcPb) + *(&AntiCheatBypass.2zdb21Gsjf))) ^ (uint)(*(&AntiCheatBypass.ox0h8SPaTb)));
					continue;
				}
				case 40U:
				{
					int[] array25 = array;
					int num64 = 0;
					int num65 = array[0] % 32;
					int num22 = ((264 == 0) ? (num65 - 78) : (num65 + 264)) % 17 + -475;
					array25[num64] = (array[0] ^ num22 ^ (1907835093 ^ num22));
					num2 = 2475971399U;
					continue;
				}
				case 41U:
				{
					int num6;
					num2 = (((num6 <= num6) ? 1916908048U : 811092744U) ^ num * 1427486691U);
					continue;
				}
				case 42U:
				{
					int num4;
					*(ref AntiCheatBypass.vB0NgYFNda + (IntPtr)num4) = num4;
					uint num66 = ((num | (uint)(*(&AntiCheatBypass.q36GhJhw4g) + *(&AntiCheatBypass.S49YpeqAUM))) ^ (uint)(*(&AntiCheatBypass.evAFiiuxHW))) & (uint)(*(&AntiCheatBypass.WkykxBZ3S7)) & (uint)(*(&AntiCheatBypass.vfoiyOZ5Ym) + *(&AntiCheatBypass.UHpx0420i8));
					num2 = (num66 * (uint)(*(&AntiCheatBypass.ZtpiJsFYkn) + *(&AntiCheatBypass.EwsXb8HcRU)) * (uint)(*(&AntiCheatBypass.JyYeBP4Bt3)) ^ (uint)(*(&AntiCheatBypass.IjVTiB0FYG)));
					continue;
				}
				case 43U:
				{
					array[10] = 649431466;
					uint[] array26 = new uint[*(&AntiCheatBypass.xEors4RprV) + *(&AntiCheatBypass.Gm1lrynRp3)];
					array26[*(&AntiCheatBypass.T3fiOFqNEB)] = (uint)(*(&AntiCheatBypass.6Jhfadvwj0));
					array26[*(&AntiCheatBypass.umvDS2xPTx)] = (uint)(*(&AntiCheatBypass.rUeZG4jGdm));
					array26[*(&AntiCheatBypass.NDkpZ7FVKN) + *(&AntiCheatBypass.D0syIqHbPV)] = (uint)(*(&AntiCheatBypass.Sb4RTmoHZg));
					array26[*(&AntiCheatBypass.4oT6nrBGnV) + *(&AntiCheatBypass.xbEGu1lpRZ)] = (uint)(*(&AntiCheatBypass.wH1HUwJTVx) + *(&AntiCheatBypass.T75oSYgvLa));
					uint num67 = num - array26[*(&AntiCheatBypass.oBx3h0Wyhc)];
					uint num68 = num67 | array26[*(&AntiCheatBypass.A9z9uxxLl0)];
					uint num69 = num68 * (uint)(*(&AntiCheatBypass.isu0CzfZxV));
					num2 = ((num69 | (uint)(*(&AntiCheatBypass.U0d0vuT7ke) + *(&AntiCheatBypass.ZVv3wTI64f))) ^ (uint)(*(&AntiCheatBypass.lVJU25R71r)));
					continue;
				}
				case 44U:
				{
					array[3] = 1014998404;
					array[4] = 1118507062;
					uint num70 = num * (uint)(*(&AntiCheatBypass.2UpSABe1tn) + *(&AntiCheatBypass.XDD5KYvU74));
					num2 = (((num70 ^ (uint)(*(&AntiCheatBypass.Ay41IepbOM))) - (uint)(*(&AntiCheatBypass.M5xs7fDke7)) | (uint)(*(&AntiCheatBypass.EWIjrwuquW))) ^ (uint)(*(&AntiCheatBypass.Fcg3fEaxJg)));
					continue;
				}
				case 45U:
				{
					int num6 = 1201829619;
					int num5 = num6 / num5;
					uint[] array27 = new uint[*(&AntiCheatBypass.xI89BTJTJU)];
					array27[*(&AntiCheatBypass.lB7fLIShnw)] = (uint)(*(&AntiCheatBypass.tpvHf1E2gV));
					array27[*(&AntiCheatBypass.NobTulZxuF)] = (uint)(*(&AntiCheatBypass.4JnPXJfcH6));
					array27[*(&AntiCheatBypass.KCjJPIX0dK) + *(&AntiCheatBypass.PRwxH7jnvj)] = (uint)(*(&AntiCheatBypass.tfwh1jBfuW) + *(&AntiCheatBypass.VmujLLERDl));
					array27[*(&AntiCheatBypass.OjTjznXzIa)] = (uint)(*(&AntiCheatBypass.j1qhNpPBSq));
					array27[*(&AntiCheatBypass.G1GHyngMm5)] = (uint)(*(&AntiCheatBypass.3SkJUJLMsO));
					array27[*(&AntiCheatBypass.LMWTwe5NVf)] = (uint)(*(&AntiCheatBypass.5C8XfWcMvM));
					uint num71 = (num ^ array27[*(&AntiCheatBypass.GLMMhRRgME)]) - (uint)(*(&AntiCheatBypass.eCTDe4fwVU)) | (uint)(*(&AntiCheatBypass.rT0GA0TMo8) + *(&AntiCheatBypass.r9bfIA9Jwf));
					num2 = ((num71 + array27[*(&AntiCheatBypass.NYARB3s42k) + *(&AntiCheatBypass.0q1bfwUFMq)] | (uint)(*(&AntiCheatBypass.7E1OXeky5d))) - (uint)(*(&AntiCheatBypass.5WA0GSSiFG)) ^ (uint)(*(&AntiCheatBypass.IYUEHAHAAV)));
					continue;
				}
				case 46U:
				{
					int[] array3;
					int num4 = array3[num4 + 5 - num4] ^ -8;
					int num5;
					num5 >>= 1;
					uint num72 = (num & (uint)(*(&AntiCheatBypass.xKOknuIXf6))) ^ (uint)(*(&AntiCheatBypass.mPfqGDnPpI));
					uint num73 = num72 ^ (uint)(*(&AntiCheatBypass.MEmVxUq9ve));
					num2 = (num73 ^ (uint)(*(&AntiCheatBypass.m3HgbqnMlZ)) ^ (uint)(*(&AntiCheatBypass.mHM8sLkMFd)));
					continue;
				}
				case 47U:
				{
					int num4 = num4;
					int num5;
					int num6 = *(ref num6 + (IntPtr)num5);
					num6 += 270;
					num2 = 3159386730U;
					continue;
				}
				case 48U:
				{
					int[] array28 = array;
					int num74 = 8;
					int num75 = array[8];
					int num22 = (((403 == 0) ? (num75 - 97) : (num75 + 403)) ^ 421) % 98;
					array28[num74] = (array[8] ^ num22 ^ (1907835093 ^ num22));
					int[] array29 = array;
					int num76 = 9;
					num22 = (-(array[9] * 345) & -240);
					array29[num76] = (array[9] ^ num22 ^ (1907835093 ^ num22));
					num2 = 2781863787U;
					continue;
				}
				case 49U:
				{
					int num4 = -num4;
					uint num77 = (num & (uint)(*(&AntiCheatBypass.RpDdYJQ8Wj))) + (uint)(*(&AntiCheatBypass.uMaSxxhECR)) + (uint)(*(&AntiCheatBypass.ox3bOf06Ch));
					num2 = (num77 ^ (uint)(*(&AntiCheatBypass.FWiKYQNpKD)) ^ (uint)(*(&AntiCheatBypass.2Xbuo6GvSN)));
					continue;
				}
				case 50U:
				{
					int num4 = num4;
					AntiCheatBypass.vB0NgYFNda = num4;
					int num5;
					num4 = num5;
					num2 = (((num4 <= num4) ? 1432392211U : 1207870721U) ^ num * 3023291343U);
					continue;
				}
				case 51U:
				{
					int[] array3 = new int[10];
					int num4;
					int num5 = num4 & 1226513756;
					uint num78 = num + (uint)(*(&AntiCheatBypass.sJXfNIjGbC) + *(&AntiCheatBypass.Hc5XnDSDDw));
					uint num79 = num78 & (uint)(*(&AntiCheatBypass.ffp5XbtKUu));
					num2 = (((num79 | (uint)(*(&AntiCheatBypass.kit3JAgayQ) + *(&AntiCheatBypass.lOBjPCFYPW))) & (uint)(*(&AntiCheatBypass.oGKdzNdcHv)) & (uint)(*(&AntiCheatBypass.ZYwqcjsCOm))) ^ (uint)(*(&AntiCheatBypass.h2PwLQdFpV)));
					continue;
				}
				case 52U:
				{
					int num5;
					int num4 = num5 >> 1;
					uint[] array30 = new uint[*(&AntiCheatBypass.2MmsPz8ggD) + *(&AntiCheatBypass.dMFRRm13N6)];
					array30[*(&AntiCheatBypass.UB5nJCLTmQ)] = (uint)(*(&AntiCheatBypass.kBsQkI25Ur));
					array30[*(&AntiCheatBypass.r1sqKMiGTv)] = (uint)(*(&AntiCheatBypass.b60Lf1R8iN));
					array30[*(&AntiCheatBypass.op3PdbeyqJ)] = (uint)(*(&AntiCheatBypass.u6ifPcSOd7) + *(&AntiCheatBypass.eEA1ynLgut));
					array30[*(&AntiCheatBypass.04WHDC7dNt)] = (uint)(*(&AntiCheatBypass.rtZJBeXU6D));
					array30[*(&AntiCheatBypass.iDfltjoCaz)] = (uint)(*(&AntiCheatBypass.Q8D7T0kbcM) + *(&AntiCheatBypass.fzAuPuo1zU));
					array30[*(&AntiCheatBypass.Q0jrLwYuYe) + *(&AntiCheatBypass.X5CYctpczL)] = (uint)(*(&AntiCheatBypass.461uhsCuW8) + *(&AntiCheatBypass.4xMGiZYVvg));
					uint num80 = num * (uint)(*(&AntiCheatBypass.bzD8yjxmRf) + *(&AntiCheatBypass.EMBoZU9yJc));
					num2 = (((((num80 & (uint)(*(&AntiCheatBypass.toYZjjs5zD))) ^ (uint)(*(&AntiCheatBypass.UUqStE2357)) ^ (uint)(*(&AntiCheatBypass.5ad03swhrO))) | (uint)(*(&AntiCheatBypass.ajLTxxbnYO))) & (uint)(*(&AntiCheatBypass.12xOKufs5V))) ^ (uint)(*(&AntiCheatBypass.bF3LhTKhg1)));
					continue;
				}
				case 53U:
				{
					array[6] = 1628676299;
					array[7] = 1849428536;
					array[8] = 2123950362;
					array[9] = 1955273760;
					uint[] array31 = new uint[*(&AntiCheatBypass.UHjnVMJwPa) + *(&AntiCheatBypass.qcCV1kha4K)];
					array31[*(&AntiCheatBypass.eK3DGfdOsS)] = (uint)(*(&AntiCheatBypass.CKaHmoC24m));
					array31[*(&AntiCheatBypass.UgtNwQCSnd)] = (uint)(*(&AntiCheatBypass.R2MxrKNfg0));
					array31[*(&AntiCheatBypass.t4E7YgC5tM) + *(&AntiCheatBypass.ipgSz7aqQz)] = (uint)(*(&AntiCheatBypass.dLlOBJ8mab));
					uint num81 = (num & array31[*(&AntiCheatBypass.bgWE3acwzP)]) ^ array31[*(&AntiCheatBypass.OHja5mW37t)];
					num2 = (num81 ^ array31[*(&AntiCheatBypass.thOqXhT05O) + *(&AntiCheatBypass.iaeRvCScYZ)] ^ (uint)(*(&AntiCheatBypass.fo0BlVlKSZ)));
					continue;
				}
				case 54U:
				{
					int num4;
					int num6 = -num4;
					num2 = (((num6 > num6) ? 1332436430U : 231498749U) ^ num * 822137789U);
					continue;
				}
				case 55U:
					num2 = 3114401147U;
					continue;
				case 56U:
				{
					uint[] array32 = new uint[*(&AntiCheatBypass.n1ozzGVNAh) + *(&AntiCheatBypass.hHCSS6UfvE)];
					array32[*(&AntiCheatBypass.HRBJ01uU86)] = (uint)(*(&AntiCheatBypass.TAAH92MnLx));
					array32[*(&AntiCheatBypass.Toj28USgUh)] = (uint)(*(&AntiCheatBypass.tILgvVze87));
					array32[*(&AntiCheatBypass.VAOENhG4TZ) + *(&AntiCheatBypass.urT8udsJLg)] = (uint)(*(&AntiCheatBypass.iOAbMLyeWn));
					uint num82 = num | (uint)(*(&AntiCheatBypass.CroNbTZeoa));
					num2 = ((num82 ^ (uint)(*(&AntiCheatBypass.NYN5wCyNvS) + *(&AntiCheatBypass.npTcYHAx1C))) * (uint)(*(&AntiCheatBypass.tmiqXDCFgb)) ^ (uint)(*(&AntiCheatBypass.DNfuTKAFpK)));
					continue;
				}
				case 57U:
				{
					int num4 = num4;
					uint[] array33 = new uint[*(&AntiCheatBypass.IAUviiYSV2)];
					array33[*(&AntiCheatBypass.wajNzkVLg4)] = (uint)(*(&AntiCheatBypass.xEprefaYyZ) + *(&AntiCheatBypass.IBDLLIdn6c));
					array33[*(&AntiCheatBypass.1lp0Gs9He7)] = (uint)(*(&AntiCheatBypass.qpieSDUnQC));
					array33[*(&AntiCheatBypass.IAd5uvWYBq)] = (uint)(*(&AntiCheatBypass.GrPECMZylw));
					uint num83 = num | array33[*(&AntiCheatBypass.gS41tdcj2I)];
					uint num84 = num83 * (uint)(*(&AntiCheatBypass.y0X3U0HtGV));
					num2 = ((num84 & array33[*(&AntiCheatBypass.VlGx09aebG)]) ^ (uint)(*(&AntiCheatBypass.ogCdg0FmMQ)));
					continue;
				}
				case 58U:
				{
					int num5 = ~num5;
					int num6;
					num5 = num6 % num5;
					uint num85 = num - (uint)(*(&AntiCheatBypass.PM7ARqdbYa) + *(&AntiCheatBypass.N5szAJ3koZ));
					uint num86 = num85 & (uint)(*(&AntiCheatBypass.C9GoNTe0nB));
					uint num87 = num86 + (uint)(*(&AntiCheatBypass.HxkIwXtAW1) + *(&AntiCheatBypass.pFzxVdpEQs));
					num2 = (num87 * (uint)(*(&AntiCheatBypass.W5jVsPFTw7)) ^ (uint)(*(&AntiCheatBypass.MmyWSaVkCn)));
					continue;
				}
				case 59U:
				{
					array[11] = 596235349;
					uint num88 = num * (uint)(*(&AntiCheatBypass.U6ALHKf8O9) + *(&AntiCheatBypass.dzlHbM70Ds));
					num2 = (num88 ^ (uint)(*(&AntiCheatBypass.rjfRu9qI7z)) ^ (uint)(*(&AntiCheatBypass.cWF2KcUjwm)) ^ (uint)(*(&AntiCheatBypass.yJr4BvtC3p)));
					continue;
				}
				case 60U:
				{
					int num4;
					int num6 = ~num4;
					uint num89 = (num | (uint)(*(&AntiCheatBypass.Sxf32QUVuM)) | (uint)(*(&AntiCheatBypass.EprPb4MGAu))) - (uint)(*(&AntiCheatBypass.D8HweRy3Xe));
					num2 = ((num89 & (uint)(*(&AntiCheatBypass.ufg0ChFM4k))) ^ (uint)(*(&AntiCheatBypass.oEuPC8ywBl)));
					continue;
				}
				case 61U:
				{
					int num6;
					*(ref AntiCheatBypass.vB0NgYFNda + (IntPtr)num6) = num6;
					uint[] array34 = new uint[*(&AntiCheatBypass.9UFscARuNI)];
					array34[*(&AntiCheatBypass.lgPeQ2SkUD)] = (uint)(*(&AntiCheatBypass.gumdOlls5g));
					array34[*(&AntiCheatBypass.ZgkXUm2DsU)] = (uint)(*(&AntiCheatBypass.dskle8KMvS));
					array34[*(&AntiCheatBypass.qEfiiPsle0)] = (uint)(*(&AntiCheatBypass.ZizqtE52Jo));
					array34[*(&AntiCheatBypass.9P19kyKB9P)] = (uint)(*(&AntiCheatBypass.bZ6mzVBBzF));
					uint num90 = num - (uint)(*(&AntiCheatBypass.3Qi144231a)) | array34[*(&AntiCheatBypass.CSCHSaMf8t)];
					uint num91 = num90 | array34[*(&AntiCheatBypass.ErmOZAmM0Y) + *(&AntiCheatBypass.C3CDutqAEq)];
					num2 = (num91 * (uint)(*(&AntiCheatBypass.6QJiMIWyTY)) ^ (uint)(*(&AntiCheatBypass.JgDGBMnUb4)));
					continue;
				}
				}
				break;
			}
			return result;
			IL_24:
			num2 = 2802612035U;
			goto IL_29;
			IL_68C:
			array = new int[22];
			int num92 = 386;
			num2 = ((num92 == 386) ? 2581257960U : 2668335920U);
			goto IL_29;
		}

		// Token: 0x060001CC RID: 460 RVA: 0x00639B94 File Offset: 0x00637D94
		public unsafe AntiCheatBypass()
		{
			if ((*(&AntiCheatBypass.YSHG7x7PLf) ^ *(&AntiCheatBypass.YSHG7x7PLf)) != 0)
			{
				int[] array = new int[10];
				int num2;
				int num = num2 | 271628230;
				int num3;
				num = num3 - num;
				num2 = num3 - num;
				num = (int)((short)num);
				if (num > num)
				{
					AntiCheatBypass.vB0NgYFNda = num;
					num = (array[num + 9 - num3] ^ 8);
					num = num2 + 325;
					num3 = -num2;
					num2 = num % num2;
					num2 = num + num2;
					num = num2 - num;
				}
				num3 = (int)((short)num2);
				num2 = (num ^ num2);
				array[num + 9 - num2] = (num3 | 7);
				num2 = (num3 | 677894866);
				num = *(ref num2 + (IntPtr)num);
				if (num2 > num2)
				{
					num2 = num3 % 708;
					num = num2;
					num3 = *(ref num2 + (IntPtr)num);
					num3 = num >> 6;
					num = num;
					num = num2 << 7;
					if (num2 > num2)
					{
						num *= num2;
						num = -num3;
						num3 = num + 109;
						num3 = (int)((ushort)num);
					}
					num2 = array[num3 + 7 - num2] + 9;
					num = num2 % num;
				}
				if (num3 > num3)
				{
					num = num3;
					num3 = num - num2;
					num2 = num / 937;
					if (num2 > num2)
					{
						num3 = num2 - num;
						num3 = ~num;
					}
					num = num2 >> 5;
					num = num2;
					num = (num3 ^ num);
				}
				num = (int)((byte)num);
				if (num2 > num2)
				{
					num = (int)((ushort)num3);
					num3 = num;
					num3 = (num & num2);
					num3 = num2 % num;
					num2 = num3 << 2;
					num %= 704;
					num = num2 >> 5;
				}
				if (num3 > num3)
				{
					num = num3 % 223;
					*(ref AntiCheatBypass.vB0NgYFNda + (IntPtr)num) = num;
					num2 = num3 << 1;
				}
				array[num3 + 5 - num3] = (num3 | 8);
				num2 |= num;
				num3 = -num3;
				array[num2 + 8 - num3] = num - 8;
				num3 = num2 % 344;
				num3 = *(ref AntiCheatBypass.vB0NgYFNda + (IntPtr)num3);
				num2 = 162483949;
				num2 = num3 >> 2;
				num3 = (array[num2 + 6 - num] ^ -1);
				num3 = (array[num3 + 5 - num3] ^ 2);
				num = AntiCheatBypass.vB0NgYFNda;
				num2 = num3 << 4;
				num2 ^= 449629857;
				num = num3 * 832;
				num2 = num - num2;
				num = (num3 | 1465114419);
				array[num2 + 7 - num2] = num2 - -9;
				num2 = num >> 3;
				num3 = num % num2;
				num3 ^= num;
				num = 930914984;
				num2 = num;
				num2 = num3 - 642;
				if (num3 > num3)
				{
					AntiCheatBypass.vB0NgYFNda = num2;
					num = num3 + 952;
					num3 = (int)((ushort)num3);
					num = (array[num3 + 8 - num3] ^ -7);
				}
			}
			base..ctor();
		}

		// Token: 0x0404DDBF RID: 318911 RVA: 0x00143080 File Offset: 0x00141280
		static int D8n2hwGGo3;

		// Token: 0x0404DDC0 RID: 318912 RVA: 0x00143088 File Offset: 0x00141288
		static int vB0NgYFNda;

		// Token: 0x0404DDC1 RID: 318913 RVA: 0x00143090 File Offset: 0x00141290
		static int YSHG7x7PLf;

		// Token: 0x0404DDC2 RID: 318914 RVA: 0x00143098 File Offset: 0x00141298
		static readonly int cfDvrvvAO2;

		// Token: 0x0404DDC3 RID: 318915 RVA: 0x00011608 File Offset: 0x0000F808
		static readonly int K45CYKVdmX;

		// Token: 0x0404DDC4 RID: 318916 RVA: 0x000560A8 File Offset: 0x000542A8
		static readonly int fAw2a6KNQU;

		// Token: 0x0404DDC5 RID: 318917 RVA: 0x001430A0 File Offset: 0x001412A0
		static readonly int sJXfNIjGbC;

		// Token: 0x0404DDC6 RID: 318918 RVA: 0x001430A8 File Offset: 0x001412A8
		static readonly int Hc5XnDSDDw;

		// Token: 0x0404DDC7 RID: 318919 RVA: 0x001430B0 File Offset: 0x001412B0
		static readonly int ffp5XbtKUu;

		// Token: 0x0404DDC8 RID: 318920 RVA: 0x001430B8 File Offset: 0x001412B8
		static readonly int kit3JAgayQ;

		// Token: 0x0404DDC9 RID: 318921 RVA: 0x001430C0 File Offset: 0x001412C0
		static readonly int lOBjPCFYPW;

		// Token: 0x0404DDCA RID: 318922 RVA: 0x001430C8 File Offset: 0x001412C8
		static readonly int oGKdzNdcHv;

		// Token: 0x0404DDCB RID: 318923 RVA: 0x001430D0 File Offset: 0x001412D0
		static readonly int ZYwqcjsCOm;

		// Token: 0x0404DDCC RID: 318924 RVA: 0x001430D8 File Offset: 0x001412D8
		static readonly int h2PwLQdFpV;

		// Token: 0x0404DDCD RID: 318925 RVA: 0x001430E0 File Offset: 0x001412E0
		static readonly int WU58GdYPE5;

		// Token: 0x0404DDCE RID: 318926 RVA: 0x001430E8 File Offset: 0x001412E8
		static readonly int gESC0McVHq;

		// Token: 0x0404DDCF RID: 318927 RVA: 0x001430F0 File Offset: 0x001412F0
		static readonly int TCKmyw1XSi;

		// Token: 0x0404DDD0 RID: 318928 RVA: 0x001430F8 File Offset: 0x001412F8
		static readonly int uYwvZEdxk9;

		// Token: 0x0404DDD1 RID: 318929 RVA: 0x00143100 File Offset: 0x00141300
		static readonly int Kc8SFcjN69;

		// Token: 0x0404DDD2 RID: 318930 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int xI89BTJTJU;

		// Token: 0x0404DDD3 RID: 318931 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int lB7fLIShnw;

		// Token: 0x0404DDD4 RID: 318932 RVA: 0x00143108 File Offset: 0x00141308
		static readonly int tpvHf1E2gV;

		// Token: 0x0404DDD5 RID: 318933 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NobTulZxuF;

		// Token: 0x0404DDD6 RID: 318934 RVA: 0x00143110 File Offset: 0x00141310
		static readonly int 4JnPXJfcH6;

		// Token: 0x0404DDD7 RID: 318935 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int KCjJPIX0dK;

		// Token: 0x0404DDD8 RID: 318936 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int PRwxH7jnvj;

		// Token: 0x0404DDD9 RID: 318937 RVA: 0x00143118 File Offset: 0x00141318
		static readonly int tfwh1jBfuW;

		// Token: 0x0404DDDA RID: 318938 RVA: 0x00143120 File Offset: 0x00141320
		static readonly int VmujLLERDl;

		// Token: 0x0404DDDB RID: 318939 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int OjTjznXzIa;

		// Token: 0x0404DDDC RID: 318940 RVA: 0x00143128 File Offset: 0x00141328
		static readonly int j1qhNpPBSq;

		// Token: 0x0404DDDD RID: 318941 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int G1GHyngMm5;

		// Token: 0x0404DDDE RID: 318942 RVA: 0x00143130 File Offset: 0x00141330
		static readonly int 3SkJUJLMsO;

		// Token: 0x0404DDDF RID: 318943 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int LMWTwe5NVf;

		// Token: 0x0404DDE0 RID: 318944 RVA: 0x00143138 File Offset: 0x00141338
		static readonly int 5C8XfWcMvM;

		// Token: 0x0404DDE1 RID: 318945 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int GLMMhRRgME;

		// Token: 0x0404DDE2 RID: 318946 RVA: 0x00143110 File Offset: 0x00141310
		static readonly int eCTDe4fwVU;

		// Token: 0x0404DDE3 RID: 318947 RVA: 0x00143140 File Offset: 0x00141340
		static readonly int rT0GA0TMo8;

		// Token: 0x0404DDE4 RID: 318948 RVA: 0x00143148 File Offset: 0x00141348
		static readonly int r9bfIA9Jwf;

		// Token: 0x0404DDE5 RID: 318949 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int NYARB3s42k;

		// Token: 0x0404DDE6 RID: 318950 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 0q1bfwUFMq;

		// Token: 0x0404DDE7 RID: 318951 RVA: 0x00143130 File Offset: 0x00141330
		static readonly int 7E1OXeky5d;

		// Token: 0x0404DDE8 RID: 318952 RVA: 0x00143138 File Offset: 0x00141338
		static readonly int 5WA0GSSiFG;

		// Token: 0x0404DDE9 RID: 318953 RVA: 0x00143150 File Offset: 0x00141350
		static readonly int IYUEHAHAAV;

		// Token: 0x0404DDEA RID: 318954 RVA: 0x00143158 File Offset: 0x00141358
		static readonly int q36GhJhw4g;

		// Token: 0x0404DDEB RID: 318955 RVA: 0x00143160 File Offset: 0x00141360
		static readonly int S49YpeqAUM;

		// Token: 0x0404DDEC RID: 318956 RVA: 0x00143168 File Offset: 0x00141368
		static readonly int evAFiiuxHW;

		// Token: 0x0404DDED RID: 318957 RVA: 0x00143170 File Offset: 0x00141370
		static readonly int WkykxBZ3S7;

		// Token: 0x0404DDEE RID: 318958 RVA: 0x00143178 File Offset: 0x00141378
		static readonly int vfoiyOZ5Ym;

		// Token: 0x0404DDEF RID: 318959 RVA: 0x00143180 File Offset: 0x00141380
		static readonly int UHpx0420i8;

		// Token: 0x0404DDF0 RID: 318960 RVA: 0x00143188 File Offset: 0x00141388
		static readonly int ZtpiJsFYkn;

		// Token: 0x0404DDF1 RID: 318961 RVA: 0x00143190 File Offset: 0x00141390
		static readonly int EwsXb8HcRU;

		// Token: 0x0404DDF2 RID: 318962 RVA: 0x00143198 File Offset: 0x00141398
		static readonly int JyYeBP4Bt3;

		// Token: 0x0404DDF3 RID: 318963 RVA: 0x001431A0 File Offset: 0x001413A0
		static readonly int IjVTiB0FYG;

		// Token: 0x0404DDF4 RID: 318964 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int IAUviiYSV2;

		// Token: 0x0404DDF5 RID: 318965 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int wajNzkVLg4;

		// Token: 0x0404DDF6 RID: 318966 RVA: 0x001431A8 File Offset: 0x001413A8
		static readonly int xEprefaYyZ;

		// Token: 0x0404DDF7 RID: 318967 RVA: 0x001431B0 File Offset: 0x001413B0
		static readonly int IBDLLIdn6c;

		// Token: 0x0404DDF8 RID: 318968 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1lp0Gs9He7;

		// Token: 0x0404DDF9 RID: 318969 RVA: 0x001431B8 File Offset: 0x001413B8
		static readonly int qpieSDUnQC;

		// Token: 0x0404DDFA RID: 318970 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int IAd5uvWYBq;

		// Token: 0x0404DDFB RID: 318971 RVA: 0x001431C0 File Offset: 0x001413C0
		static readonly int GrPECMZylw;

		// Token: 0x0404DDFC RID: 318972 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int gS41tdcj2I;

		// Token: 0x0404DDFD RID: 318973 RVA: 0x001431B8 File Offset: 0x001413B8
		static readonly int y0X3U0HtGV;

		// Token: 0x0404DDFE RID: 318974 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int VlGx09aebG;

		// Token: 0x0404DDFF RID: 318975 RVA: 0x001431C8 File Offset: 0x001413C8
		static readonly int ogCdg0FmMQ;

		// Token: 0x0404DE00 RID: 318976 RVA: 0x001431D0 File Offset: 0x001413D0
		static readonly int Sxf32QUVuM;

		// Token: 0x0404DE01 RID: 318977 RVA: 0x001431D8 File Offset: 0x001413D8
		static readonly int EprPb4MGAu;

		// Token: 0x0404DE02 RID: 318978 RVA: 0x001431E0 File Offset: 0x001413E0
		static readonly int D8HweRy3Xe;

		// Token: 0x0404DE03 RID: 318979 RVA: 0x001431E8 File Offset: 0x001413E8
		static readonly int ufg0ChFM4k;

		// Token: 0x0404DE04 RID: 318980 RVA: 0x001431F0 File Offset: 0x001413F0
		static readonly int oEuPC8ywBl;

		// Token: 0x0404DE05 RID: 318981 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int n9lcNUqtZk;

		// Token: 0x0404DE06 RID: 318982 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int ba7QbiI1N4;

		// Token: 0x0404DE07 RID: 318983 RVA: 0x001431F8 File Offset: 0x001413F8
		static readonly int z9MaF8N2tf;

		// Token: 0x0404DE08 RID: 318984 RVA: 0x00143200 File Offset: 0x00141400
		static readonly int dC2v0v3Ems;

		// Token: 0x0404DE09 RID: 318985 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 1VxTIOGeyd;

		// Token: 0x0404DE0A RID: 318986 RVA: 0x00143208 File Offset: 0x00141408
		static readonly int z6iHwoxKXO;

		// Token: 0x0404DE0B RID: 318987 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int GxA3HZiMZp;

		// Token: 0x0404DE0C RID: 318988 RVA: 0x00143210 File Offset: 0x00141410
		static readonly int pEOfCeM2R1;

		// Token: 0x0404DE0D RID: 318989 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 1tEQpgdu9M;

		// Token: 0x0404DE0E RID: 318990 RVA: 0x00143218 File Offset: 0x00141418
		static readonly int 8sqXlDV3Mt;

		// Token: 0x0404DE0F RID: 318991 RVA: 0x00143220 File Offset: 0x00141420
		static readonly int p4EIyvrDER;

		// Token: 0x0404DE10 RID: 318992 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int b43gXWttOk;

		// Token: 0x0404DE11 RID: 318993 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 6xMNq6Y039;

		// Token: 0x0404DE12 RID: 318994 RVA: 0x00143218 File Offset: 0x00141418
		static readonly int ITpiL6p5c4;

		// Token: 0x0404DE13 RID: 318995 RVA: 0x00143228 File Offset: 0x00141428
		static readonly int yZpruDzKAO;

		// Token: 0x0404DE14 RID: 318996 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int Tmomw2s0c1;

		// Token: 0x0404DE15 RID: 318997 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int X0JFJIPUVa;

		// Token: 0x0404DE16 RID: 318998 RVA: 0x00143230 File Offset: 0x00141430
		static readonly int ryQTvgIedm;

		// Token: 0x0404DE17 RID: 318999 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int GN0opgoCwT;

		// Token: 0x0404DE18 RID: 319000 RVA: 0x00143238 File Offset: 0x00141438
		static readonly int Oydkh7Qkim;

		// Token: 0x0404DE19 RID: 319001 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yfzkhfVV1Q;

		// Token: 0x0404DE1A RID: 319002 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int tNXzvJAeam;

		// Token: 0x0404DE1B RID: 319003 RVA: 0x00143240 File Offset: 0x00141440
		static readonly int dMiBL3Vpwx;

		// Token: 0x0404DE1C RID: 319004 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Qh50ykYQHK;

		// Token: 0x0404DE1D RID: 319005 RVA: 0x00143248 File Offset: 0x00141448
		static readonly int LTLfjAanzX;

		// Token: 0x0404DE1E RID: 319006 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 7vJ6Il7xYo;

		// Token: 0x0404DE1F RID: 319007 RVA: 0x00143250 File Offset: 0x00141450
		static readonly int JpiDAMSgAK;

		// Token: 0x0404DE20 RID: 319008 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int uuXQaKBCcL;

		// Token: 0x0404DE21 RID: 319009 RVA: 0x00143258 File Offset: 0x00141458
		static readonly int cr0Y0fY9sN;

		// Token: 0x0404DE22 RID: 319010 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int nl2dAfuIfX;

		// Token: 0x0404DE23 RID: 319011 RVA: 0x00143260 File Offset: 0x00141460
		static readonly int s3nonNY3f7;

		// Token: 0x0404DE24 RID: 319012 RVA: 0x00143268 File Offset: 0x00141468
		static readonly int j4UMMczKNe;

		// Token: 0x0404DE25 RID: 319013 RVA: 0x00143240 File Offset: 0x00141440
		static readonly int xSywhJ23Q5;

		// Token: 0x0404DE26 RID: 319014 RVA: 0x00143248 File Offset: 0x00141448
		static readonly int a3hFciDLvm;

		// Token: 0x0404DE27 RID: 319015 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int HedunsQpRh;

		// Token: 0x0404DE28 RID: 319016 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int pk4AjZF1Gd;

		// Token: 0x0404DE29 RID: 319017 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int VenkhqXPun;

		// Token: 0x0404DE2A RID: 319018 RVA: 0x00143270 File Offset: 0x00141470
		static readonly int YnYkXTzDIz;

		// Token: 0x0404DE2B RID: 319019 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 2MmsPz8ggD;

		// Token: 0x0404DE2C RID: 319020 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int dMFRRm13N6;

		// Token: 0x0404DE2D RID: 319021 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int UB5nJCLTmQ;

		// Token: 0x0404DE2E RID: 319022 RVA: 0x00143278 File Offset: 0x00141478
		static readonly int kBsQkI25Ur;

		// Token: 0x0404DE2F RID: 319023 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int r1sqKMiGTv;

		// Token: 0x0404DE30 RID: 319024 RVA: 0x00143280 File Offset: 0x00141480
		static readonly int b60Lf1R8iN;

		// Token: 0x0404DE31 RID: 319025 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int op3PdbeyqJ;

		// Token: 0x0404DE32 RID: 319026 RVA: 0x00143288 File Offset: 0x00141488
		static readonly int u6ifPcSOd7;

		// Token: 0x0404DE33 RID: 319027 RVA: 0x00143290 File Offset: 0x00141490
		static readonly int eEA1ynLgut;

		// Token: 0x0404DE34 RID: 319028 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 04WHDC7dNt;

		// Token: 0x0404DE35 RID: 319029 RVA: 0x00143298 File Offset: 0x00141498
		static readonly int rtZJBeXU6D;

		// Token: 0x0404DE36 RID: 319030 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int iDfltjoCaz;

		// Token: 0x0404DE37 RID: 319031 RVA: 0x001432A0 File Offset: 0x001414A0
		static readonly int Q8D7T0kbcM;

		// Token: 0x0404DE38 RID: 319032 RVA: 0x001432A8 File Offset: 0x001414A8
		static readonly int fzAuPuo1zU;

		// Token: 0x0404DE39 RID: 319033 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Q0jrLwYuYe;

		// Token: 0x0404DE3A RID: 319034 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int X5CYctpczL;

		// Token: 0x0404DE3B RID: 319035 RVA: 0x001432B0 File Offset: 0x001414B0
		static readonly int 461uhsCuW8;

		// Token: 0x0404DE3C RID: 319036 RVA: 0x001432B8 File Offset: 0x001414B8
		static readonly int 4xMGiZYVvg;

		// Token: 0x0404DE3D RID: 319037 RVA: 0x001432C0 File Offset: 0x001414C0
		static readonly int bzD8yjxmRf;

		// Token: 0x0404DE3E RID: 319038 RVA: 0x001432C8 File Offset: 0x001414C8
		static readonly int EMBoZU9yJc;

		// Token: 0x0404DE3F RID: 319039 RVA: 0x00143280 File Offset: 0x00141480
		static readonly int toYZjjs5zD;

		// Token: 0x0404DE40 RID: 319040 RVA: 0x001432D0 File Offset: 0x001414D0
		static readonly int UUqStE2357;

		// Token: 0x0404DE41 RID: 319041 RVA: 0x00143298 File Offset: 0x00141498
		static readonly int 5ad03swhrO;

		// Token: 0x0404DE42 RID: 319042 RVA: 0x001432D8 File Offset: 0x001414D8
		static readonly int ajLTxxbnYO;

		// Token: 0x0404DE43 RID: 319043 RVA: 0x001432E0 File Offset: 0x001414E0
		static readonly int 12xOKufs5V;

		// Token: 0x0404DE44 RID: 319044 RVA: 0x001432E8 File Offset: 0x001414E8
		static readonly int bF3LhTKhg1;

		// Token: 0x0404DE45 RID: 319045 RVA: 0x001432F0 File Offset: 0x001414F0
		static readonly int xKOknuIXf6;

		// Token: 0x0404DE46 RID: 319046 RVA: 0x001432F8 File Offset: 0x001414F8
		static readonly int mPfqGDnPpI;

		// Token: 0x0404DE47 RID: 319047 RVA: 0x00143300 File Offset: 0x00141500
		static readonly int MEmVxUq9ve;

		// Token: 0x0404DE48 RID: 319048 RVA: 0x00143308 File Offset: 0x00141508
		static readonly int m3HgbqnMlZ;

		// Token: 0x0404DE49 RID: 319049 RVA: 0x00143310 File Offset: 0x00141510
		static readonly int mHM8sLkMFd;

		// Token: 0x0404DE4A RID: 319050 RVA: 0x00143318 File Offset: 0x00141518
		static readonly int p52Xpsi2xS;

		// Token: 0x0404DE4B RID: 319051 RVA: 0x00143320 File Offset: 0x00141520
		static readonly int EIlBUtH8OZ;

		// Token: 0x0404DE4C RID: 319052 RVA: 0x00143328 File Offset: 0x00141528
		static readonly int ZaoPgF1onl;

		// Token: 0x0404DE4D RID: 319053 RVA: 0x00143330 File Offset: 0x00141530
		static readonly int ue4RyqBu1t;

		// Token: 0x0404DE4E RID: 319054 RVA: 0x00143338 File Offset: 0x00141538
		static readonly int IvZSVefKn9;

		// Token: 0x0404DE4F RID: 319055 RVA: 0x00143340 File Offset: 0x00141540
		static readonly int El7pEPRm1k;

		// Token: 0x0404DE50 RID: 319056 RVA: 0x00143348 File Offset: 0x00141548
		static readonly int 03OLijOTNn;

		// Token: 0x0404DE51 RID: 319057 RVA: 0x00143350 File Offset: 0x00141550
		static readonly int rXHfQoBV3C;

		// Token: 0x0404DE52 RID: 319058 RVA: 0x00143358 File Offset: 0x00141558
		static readonly int jrAohIgONj;

		// Token: 0x0404DE53 RID: 319059 RVA: 0x00143360 File Offset: 0x00141560
		static readonly int ZY3Q2PgNuv;

		// Token: 0x0404DE54 RID: 319060 RVA: 0x00143368 File Offset: 0x00141568
		static readonly int PM7ARqdbYa;

		// Token: 0x0404DE55 RID: 319061 RVA: 0x00143370 File Offset: 0x00141570
		static readonly int N5szAJ3koZ;

		// Token: 0x0404DE56 RID: 319062 RVA: 0x00143378 File Offset: 0x00141578
		static readonly int C9GoNTe0nB;

		// Token: 0x0404DE57 RID: 319063 RVA: 0x00143380 File Offset: 0x00141580
		static readonly int HxkIwXtAW1;

		// Token: 0x0404DE58 RID: 319064 RVA: 0x00143388 File Offset: 0x00141588
		static readonly int pFzxVdpEQs;

		// Token: 0x0404DE59 RID: 319065 RVA: 0x00143390 File Offset: 0x00141590
		static readonly int W5jVsPFTw7;

		// Token: 0x0404DE5A RID: 319066 RVA: 0x00143398 File Offset: 0x00141598
		static readonly int MmyWSaVkCn;

		// Token: 0x0404DE5B RID: 319067 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int Z2Oxt7KTTu;

		// Token: 0x0404DE5C RID: 319068 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int nak5pLNPZg;

		// Token: 0x0404DE5D RID: 319069 RVA: 0x001433A0 File Offset: 0x001415A0
		static readonly int RaNYpCRce4;

		// Token: 0x0404DE5E RID: 319070 RVA: 0x001433A8 File Offset: 0x001415A8
		static readonly int IEBmSdrwmv;

		// Token: 0x0404DE5F RID: 319071 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Fw9CTvB2rG;

		// Token: 0x0404DE60 RID: 319072 RVA: 0x001433B0 File Offset: 0x001415B0
		static readonly int MGLgV9pzIq;

		// Token: 0x0404DE61 RID: 319073 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int qsyYljY8mM;

		// Token: 0x0404DE62 RID: 319074 RVA: 0x001433B8 File Offset: 0x001415B8
		static readonly int ebnnafaLE3;

		// Token: 0x0404DE63 RID: 319075 RVA: 0x001433C0 File Offset: 0x001415C0
		static readonly int AYvXsC3eQT;

		// Token: 0x0404DE64 RID: 319076 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int x1o5EX7lau;

		// Token: 0x0404DE65 RID: 319077 RVA: 0x001433C8 File Offset: 0x001415C8
		static readonly int WDQemudhF0;

		// Token: 0x0404DE66 RID: 319078 RVA: 0x001433D0 File Offset: 0x001415D0
		static readonly int iduOpS6bqj;

		// Token: 0x0404DE67 RID: 319079 RVA: 0x001433D8 File Offset: 0x001415D8
		static readonly int q4rTYmxrjD;

		// Token: 0x0404DE68 RID: 319080 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int hzvUg7IRu7;

		// Token: 0x0404DE69 RID: 319081 RVA: 0x001433E0 File Offset: 0x001415E0
		static readonly int jVZauUHZPv;

		// Token: 0x0404DE6A RID: 319082 RVA: 0x001433E8 File Offset: 0x001415E8
		static readonly int af50EcW6F9;

		// Token: 0x0404DE6B RID: 319083 RVA: 0x001433F0 File Offset: 0x001415F0
		static readonly int 7v8BTssass;

		// Token: 0x0404DE6C RID: 319084 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int KpqsAVeRiE;

		// Token: 0x0404DE6D RID: 319085 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int fXcynB44PD;

		// Token: 0x0404DE6E RID: 319086 RVA: 0x001433F8 File Offset: 0x001415F8
		static readonly int kLLv9yWXHC;

		// Token: 0x0404DE6F RID: 319087 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int lqrgkvyM0t;

		// Token: 0x0404DE70 RID: 319088 RVA: 0x00143400 File Offset: 0x00141600
		static readonly int 8FYAekTKYR;

		// Token: 0x0404DE71 RID: 319089 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int yyLpH9d5tM;

		// Token: 0x0404DE72 RID: 319090 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8HJgdyq5N2;

		// Token: 0x0404DE73 RID: 319091 RVA: 0x00143408 File Offset: 0x00141608
		static readonly int MrDfFexLQZ;

		// Token: 0x0404DE74 RID: 319092 RVA: 0x001433F8 File Offset: 0x001415F8
		static readonly int fM80NxfCYl;

		// Token: 0x0404DE75 RID: 319093 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int R3dov151hq;

		// Token: 0x0404DE76 RID: 319094 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 3X6gEGvpjn;

		// Token: 0x0404DE77 RID: 319095 RVA: 0x00143410 File Offset: 0x00141610
		static readonly int LSpUqvITSq;

		// Token: 0x0404DE78 RID: 319096 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int ToglkTOYuO;

		// Token: 0x0404DE79 RID: 319097 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int j5nkfHQcvG;

		// Token: 0x0404DE7A RID: 319098 RVA: 0x00143418 File Offset: 0x00141618
		static readonly int CzcvZ8NI7A;

		// Token: 0x0404DE7B RID: 319099 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int smi1WP1U5u;

		// Token: 0x0404DE7C RID: 319100 RVA: 0x00143420 File Offset: 0x00141620
		static readonly int 2W5VDQpFzj;

		// Token: 0x0404DE7D RID: 319101 RVA: 0x00143428 File Offset: 0x00141628
		static readonly int fphModMuMm;

		// Token: 0x0404DE7E RID: 319102 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int GFatf7XvNP;

		// Token: 0x0404DE7F RID: 319103 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int P5gBOp4GsJ;

		// Token: 0x0404DE80 RID: 319104 RVA: 0x00143430 File Offset: 0x00141630
		static readonly int TITYfDEWN3;

		// Token: 0x0404DE81 RID: 319105 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int DGITow5L0G;

		// Token: 0x0404DE82 RID: 319106 RVA: 0x00143438 File Offset: 0x00141638
		static readonly int 231jTkJg78;

		// Token: 0x0404DE83 RID: 319107 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int iFCDT7wCOc;

		// Token: 0x0404DE84 RID: 319108 RVA: 0x00143440 File Offset: 0x00141640
		static readonly int 3AiTMJwNXc;

		// Token: 0x0404DE85 RID: 319109 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int tsPlQZQuE4;

		// Token: 0x0404DE86 RID: 319110 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4hYOU7EF9r;

		// Token: 0x0404DE87 RID: 319111 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int A36YN2UiXK;

		// Token: 0x0404DE88 RID: 319112 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int x5JfOzzaw3;

		// Token: 0x0404DE89 RID: 319113 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int qB7TiVmT8O;

		// Token: 0x0404DE8A RID: 319114 RVA: 0x00143448 File Offset: 0x00141648
		static readonly int EqNqc0v1YY;

		// Token: 0x0404DE8B RID: 319115 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int EsW4H8Y3Af;

		// Token: 0x0404DE8C RID: 319116 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int HnSFA85nz2;

		// Token: 0x0404DE8D RID: 319117 RVA: 0x00143450 File Offset: 0x00141650
		static readonly int PBjJGGrcCX;

		// Token: 0x0404DE8E RID: 319118 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int D8CYz7pDMj;

		// Token: 0x0404DE8F RID: 319119 RVA: 0x00143458 File Offset: 0x00141658
		static readonly int 6sTdGaXHpe;

		// Token: 0x0404DE90 RID: 319120 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 5IBfIDJNxA;

		// Token: 0x0404DE91 RID: 319121 RVA: 0x00143460 File Offset: 0x00141660
		static readonly int R61mbJl4QC;

		// Token: 0x0404DE92 RID: 319122 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int S1aQ6hsGCp;

		// Token: 0x0404DE93 RID: 319123 RVA: 0x00143468 File Offset: 0x00141668
		static readonly int tjxic56hQv;

		// Token: 0x0404DE94 RID: 319124 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int ybQMSA1qC6;

		// Token: 0x0404DE95 RID: 319125 RVA: 0x00143470 File Offset: 0x00141670
		static readonly int zd0mLErvjk;

		// Token: 0x0404DE96 RID: 319126 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int VDLIRrITKf;

		// Token: 0x0404DE97 RID: 319127 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int NEofO1lO76;

		// Token: 0x0404DE98 RID: 319128 RVA: 0x00143478 File Offset: 0x00141678
		static readonly int qBDF0PsKWX;

		// Token: 0x0404DE99 RID: 319129 RVA: 0x00143480 File Offset: 0x00141680
		static readonly int NK7pavQI4k;

		// Token: 0x0404DE9A RID: 319130 RVA: 0x00143488 File Offset: 0x00141688
		static readonly int 1hggtuzVYU;

		// Token: 0x0404DE9B RID: 319131 RVA: 0x00143458 File Offset: 0x00141658
		static readonly int ddxn4T9FRB;

		// Token: 0x0404DE9C RID: 319132 RVA: 0x00143460 File Offset: 0x00141660
		static readonly int 986wSDG8Ed;

		// Token: 0x0404DE9D RID: 319133 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int kdTXEIegWF;

		// Token: 0x0404DE9E RID: 319134 RVA: 0x00143470 File Offset: 0x00141670
		static readonly int aWwB4uWUvG;

		// Token: 0x0404DE9F RID: 319135 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int vL03l3luOq;

		// Token: 0x0404DEA0 RID: 319136 RVA: 0x00143490 File Offset: 0x00141690
		static readonly int o0R4tAJaiv;

		// Token: 0x0404DEA1 RID: 319137 RVA: 0x00143498 File Offset: 0x00141698
		static readonly int zcsLlmL52i;

		// Token: 0x0404DEA2 RID: 319138 RVA: 0x001434A0 File Offset: 0x001416A0
		static readonly int qvN7rZmavL;

		// Token: 0x0404DEA3 RID: 319139 RVA: 0x001434A8 File Offset: 0x001416A8
		static readonly int huSqajF1R3;

		// Token: 0x0404DEA4 RID: 319140 RVA: 0x001434B0 File Offset: 0x001416B0
		static readonly int k6w9RTcoR9;

		// Token: 0x0404DEA5 RID: 319141 RVA: 0x001434B8 File Offset: 0x001416B8
		static readonly int rq1p93nUNU;

		// Token: 0x0404DEA6 RID: 319142 RVA: 0x001434C0 File Offset: 0x001416C0
		static readonly int YsoWOEJBuB;

		// Token: 0x0404DEA7 RID: 319143 RVA: 0x001434C8 File Offset: 0x001416C8
		static readonly int hTn87t9NpY;

		// Token: 0x0404DEA8 RID: 319144 RVA: 0x001434D0 File Offset: 0x001416D0
		static readonly int 67Iwd12nqh;

		// Token: 0x0404DEA9 RID: 319145 RVA: 0x001434D8 File Offset: 0x001416D8
		static readonly int 6vo7f1RZvN;

		// Token: 0x0404DEAA RID: 319146 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int Ja4QbXC3rQ;

		// Token: 0x0404DEAB RID: 319147 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 4ZozYaj22X;

		// Token: 0x0404DEAC RID: 319148 RVA: 0x001434E0 File Offset: 0x001416E0
		static readonly int LgVNFwpqcF;

		// Token: 0x0404DEAD RID: 319149 RVA: 0x001434E8 File Offset: 0x001416E8
		static readonly int cjccPfD2UG;

		// Token: 0x0404DEAE RID: 319150 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int y95angGzjE;

		// Token: 0x0404DEAF RID: 319151 RVA: 0x001434F0 File Offset: 0x001416F0
		static readonly int SYgYCmFrLp;

		// Token: 0x0404DEB0 RID: 319152 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int rWalxU7Mj2;

		// Token: 0x0404DEB1 RID: 319153 RVA: 0x001434F8 File Offset: 0x001416F8
		static readonly int XrhwiLl4ji;

		// Token: 0x0404DEB2 RID: 319154 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int p0GXxDCDZm;

		// Token: 0x0404DEB3 RID: 319155 RVA: 0x00143500 File Offset: 0x00141700
		static readonly int aWroYbjTmS;

		// Token: 0x0404DEB4 RID: 319156 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int i3Pqrk0tz0;

		// Token: 0x0404DEB5 RID: 319157 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int BLHm91PCyu;

		// Token: 0x0404DEB6 RID: 319158 RVA: 0x00143508 File Offset: 0x00141708
		static readonly int R4w7cBA2YH;

		// Token: 0x0404DEB7 RID: 319159 RVA: 0x00143510 File Offset: 0x00141710
		static readonly int mRRQ9vlZqN;

		// Token: 0x0404DEB8 RID: 319160 RVA: 0x00143518 File Offset: 0x00141718
		static readonly int MSNjkOOEph;

		// Token: 0x0404DEB9 RID: 319161 RVA: 0x00143520 File Offset: 0x00141720
		static readonly int Lhf1BoHROq;

		// Token: 0x0404DEBA RID: 319162 RVA: 0x00143528 File Offset: 0x00141728
		static readonly int k8VsNu30mN;

		// Token: 0x0404DEBB RID: 319163 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int QzVli8qMWN;

		// Token: 0x0404DEBC RID: 319164 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int x6N15FwZPV;

		// Token: 0x0404DEBD RID: 319165 RVA: 0x00143530 File Offset: 0x00141730
		static readonly int oTKAmO7fV0;

		// Token: 0x0404DEBE RID: 319166 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int VXbbRVL4TC;

		// Token: 0x0404DEBF RID: 319167 RVA: 0x00143538 File Offset: 0x00141738
		static readonly int 845B2ouewI;

		// Token: 0x0404DEC0 RID: 319168 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 8dlRj6pV8U;

		// Token: 0x0404DEC1 RID: 319169 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int BK1g1Zewkk;

		// Token: 0x0404DEC2 RID: 319170 RVA: 0x00143540 File Offset: 0x00141740
		static readonly int 31GNWuYJH8;

		// Token: 0x0404DEC3 RID: 319171 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int ecsM22wJ1U;

		// Token: 0x0404DEC4 RID: 319172 RVA: 0x00143548 File Offset: 0x00141748
		static readonly int qz69AxDZKd;

		// Token: 0x0404DEC5 RID: 319173 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int J74MOGXX4z;

		// Token: 0x0404DEC6 RID: 319174 RVA: 0x00143550 File Offset: 0x00141750
		static readonly int igO90ibon9;

		// Token: 0x0404DEC7 RID: 319175 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int nV4P3E5GMj;

		// Token: 0x0404DEC8 RID: 319176 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int q98ozgig7w;

		// Token: 0x0404DEC9 RID: 319177 RVA: 0x00143558 File Offset: 0x00141758
		static readonly int eYPCwKl6Jc;

		// Token: 0x0404DECA RID: 319178 RVA: 0x00143530 File Offset: 0x00141730
		static readonly int VZvKzyCoTK;

		// Token: 0x0404DECB RID: 319179 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int LQLVIjhjJT;

		// Token: 0x0404DECC RID: 319180 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 95q1ePF2dt;

		// Token: 0x0404DECD RID: 319181 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int c87uNRNxyB;

		// Token: 0x0404DECE RID: 319182 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int d3MxlON33N;

		// Token: 0x0404DECF RID: 319183 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int nBxzcZs4qk;

		// Token: 0x0404DED0 RID: 319184 RVA: 0x00143558 File Offset: 0x00141758
		static readonly int sKLksMTaI1;

		// Token: 0x0404DED1 RID: 319185 RVA: 0x00143560 File Offset: 0x00141760
		static readonly int VtuI0Ft3QQ;

		// Token: 0x0404DED2 RID: 319186 RVA: 0x00143568 File Offset: 0x00141768
		static readonly int CM8QGaLHRx;

		// Token: 0x0404DED3 RID: 319187 RVA: 0x00143570 File Offset: 0x00141770
		static readonly int iTHOTSsmFY;

		// Token: 0x0404DED4 RID: 319188 RVA: 0x00143578 File Offset: 0x00141778
		static readonly int 4wvC13Qp9W;

		// Token: 0x0404DED5 RID: 319189 RVA: 0x00143580 File Offset: 0x00141780
		static readonly int qznZifM5dR;

		// Token: 0x0404DED6 RID: 319190 RVA: 0x00143588 File Offset: 0x00141788
		static readonly int BMIUSCmgzh;

		// Token: 0x0404DED7 RID: 319191 RVA: 0x00143590 File Offset: 0x00141790
		static readonly int XGx1VPa5YM;

		// Token: 0x0404DED8 RID: 319192 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int JgH5Gsprqx;

		// Token: 0x0404DED9 RID: 319193 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int GxIxXsnatz;

		// Token: 0x0404DEDA RID: 319194 RVA: 0x00143598 File Offset: 0x00141798
		static readonly int Qu0c8kBvDS;

		// Token: 0x0404DEDB RID: 319195 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int EQgQHfENNj;

		// Token: 0x0404DEDC RID: 319196 RVA: 0x001435A0 File Offset: 0x001417A0
		static readonly int W50Bak7Aen;

		// Token: 0x0404DEDD RID: 319197 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int l9Mj6Zqp6g;

		// Token: 0x0404DEDE RID: 319198 RVA: 0x001435A8 File Offset: 0x001417A8
		static readonly int q3nXs0Q1p2;

		// Token: 0x0404DEDF RID: 319199 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int oaNKcV3yBY;

		// Token: 0x0404DEE0 RID: 319200 RVA: 0x001435B0 File Offset: 0x001417B0
		static readonly int nBRaqEE7Us;

		// Token: 0x0404DEE1 RID: 319201 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int zYQr3cRcTk;

		// Token: 0x0404DEE2 RID: 319202 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int TFUm9LwCGk;

		// Token: 0x0404DEE3 RID: 319203 RVA: 0x001435B8 File Offset: 0x001417B8
		static readonly int f1oh2omNqn;

		// Token: 0x0404DEE4 RID: 319204 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int wTh7DPJfQA;

		// Token: 0x0404DEE5 RID: 319205 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int EbfaFhrobf;

		// Token: 0x0404DEE6 RID: 319206 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int SC0tN7uszO;

		// Token: 0x0404DEE7 RID: 319207 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int zEwpy9iWjt;

		// Token: 0x0404DEE8 RID: 319208 RVA: 0x001435C0 File Offset: 0x001417C0
		static readonly int CRvFgEWNcU;

		// Token: 0x0404DEE9 RID: 319209 RVA: 0x001435C8 File Offset: 0x001417C8
		static readonly int 77vLVucxuF;

		// Token: 0x0404DEEA RID: 319210 RVA: 0x001435D0 File Offset: 0x001417D0
		static readonly int faqCK9ozmF;

		// Token: 0x0404DEEB RID: 319211 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int 9UFscARuNI;

		// Token: 0x0404DEEC RID: 319212 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int lgPeQ2SkUD;

		// Token: 0x0404DEED RID: 319213 RVA: 0x001435D8 File Offset: 0x001417D8
		static readonly int gumdOlls5g;

		// Token: 0x0404DEEE RID: 319214 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ZgkXUm2DsU;

		// Token: 0x0404DEEF RID: 319215 RVA: 0x001435E0 File Offset: 0x001417E0
		static readonly int dskle8KMvS;

		// Token: 0x0404DEF0 RID: 319216 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int qEfiiPsle0;

		// Token: 0x0404DEF1 RID: 319217 RVA: 0x001435E8 File Offset: 0x001417E8
		static readonly int ZizqtE52Jo;

		// Token: 0x0404DEF2 RID: 319218 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 9P19kyKB9P;

		// Token: 0x0404DEF3 RID: 319219 RVA: 0x001435F0 File Offset: 0x001417F0
		static readonly int bZ6mzVBBzF;

		// Token: 0x0404DEF4 RID: 319220 RVA: 0x001435D8 File Offset: 0x001417D8
		static readonly int 3Qi144231a;

		// Token: 0x0404DEF5 RID: 319221 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int CSCHSaMf8t;

		// Token: 0x0404DEF6 RID: 319222 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ErmOZAmM0Y;

		// Token: 0x0404DEF7 RID: 319223 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int C3CDutqAEq;

		// Token: 0x0404DEF8 RID: 319224 RVA: 0x001435F0 File Offset: 0x001417F0
		static readonly int 6QJiMIWyTY;

		// Token: 0x0404DEF9 RID: 319225 RVA: 0x001435F8 File Offset: 0x001417F8
		static readonly int JgDGBMnUb4;

		// Token: 0x0404DEFA RID: 319226 RVA: 0x00143600 File Offset: 0x00141800
		static readonly int RpDdYJQ8Wj;

		// Token: 0x0404DEFB RID: 319227 RVA: 0x00143608 File Offset: 0x00141808
		static readonly int uMaSxxhECR;

		// Token: 0x0404DEFC RID: 319228 RVA: 0x00143610 File Offset: 0x00141810
		static readonly int ox3bOf06Ch;

		// Token: 0x0404DEFD RID: 319229 RVA: 0x00143618 File Offset: 0x00141818
		static readonly int FWiKYQNpKD;

		// Token: 0x0404DEFE RID: 319230 RVA: 0x00143620 File Offset: 0x00141820
		static readonly int 2Xbuo6GvSN;

		// Token: 0x0404DEFF RID: 319231 RVA: 0x00143628 File Offset: 0x00141828
		static readonly int pjRKQewlO2;

		// Token: 0x0404DF00 RID: 319232 RVA: 0x00143630 File Offset: 0x00141830
		static readonly int ST6zeXoP4g;

		// Token: 0x0404DF01 RID: 319233 RVA: 0x00143638 File Offset: 0x00141838
		static readonly int k139YQVIwR;

		// Token: 0x0404DF02 RID: 319234 RVA: 0x00143640 File Offset: 0x00141840
		static readonly int ZEnz2fFX43;

		// Token: 0x0404DF03 RID: 319235 RVA: 0x00143648 File Offset: 0x00141848
		static readonly int elbRuibmQR;

		// Token: 0x0404DF04 RID: 319236 RVA: 0x00143650 File Offset: 0x00141850
		static readonly int S01wmxpSv9;

		// Token: 0x0404DF05 RID: 319237 RVA: 0x00143658 File Offset: 0x00141858
		static readonly int Inz6dOpG68;

		// Token: 0x0404DF06 RID: 319238 RVA: 0x00143660 File Offset: 0x00141860
		static readonly int RQVAC8amP0;

		// Token: 0x0404DF07 RID: 319239 RVA: 0x00143668 File Offset: 0x00141868
		static readonly int zt2e9iN1ME;

		// Token: 0x0404DF08 RID: 319240 RVA: 0x00143670 File Offset: 0x00141870
		static readonly int zxl4v0weyg;

		// Token: 0x0404DF09 RID: 319241 RVA: 0x00143678 File Offset: 0x00141878
		static readonly int 2UpSABe1tn;

		// Token: 0x0404DF0A RID: 319242 RVA: 0x00143680 File Offset: 0x00141880
		static readonly int XDD5KYvU74;

		// Token: 0x0404DF0B RID: 319243 RVA: 0x00143688 File Offset: 0x00141888
		static readonly int Ay41IepbOM;

		// Token: 0x0404DF0C RID: 319244 RVA: 0x00143690 File Offset: 0x00141890
		static readonly int M5xs7fDke7;

		// Token: 0x0404DF0D RID: 319245 RVA: 0x00143698 File Offset: 0x00141898
		static readonly int EWIjrwuquW;

		// Token: 0x0404DF0E RID: 319246 RVA: 0x001436A0 File Offset: 0x001418A0
		static readonly int Fcg3fEaxJg;

		// Token: 0x0404DF0F RID: 319247 RVA: 0x000021D0 File Offset: 0x000003D0
		static readonly int WDmhbbPU8o;

		// Token: 0x0404DF10 RID: 319248 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int VK0A0oqUKW;

		// Token: 0x0404DF11 RID: 319249 RVA: 0x001436A8 File Offset: 0x001418A8
		static readonly int t8q1GuY4N2;

		// Token: 0x0404DF12 RID: 319250 RVA: 0x001436B0 File Offset: 0x001418B0
		static readonly int FPa8kBtkIQ;

		// Token: 0x0404DF13 RID: 319251 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int gZrFB4lgD1;

		// Token: 0x0404DF14 RID: 319252 RVA: 0x001436B8 File Offset: 0x001418B8
		static readonly int YFnxwYWvaq;

		// Token: 0x0404DF15 RID: 319253 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int CVHFiGt1az;

		// Token: 0x0404DF16 RID: 319254 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4FM4zTRl0L;

		// Token: 0x0404DF17 RID: 319255 RVA: 0x001436C0 File Offset: 0x001418C0
		static readonly int I20VdAmmLM;

		// Token: 0x0404DF18 RID: 319256 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int o8JbNKSlh5;

		// Token: 0x0404DF19 RID: 319257 RVA: 0x001436C8 File Offset: 0x001418C8
		static readonly int KuGO6T3s7c;

		// Token: 0x0404DF1A RID: 319258 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int Gv4OiKevmi;

		// Token: 0x0404DF1B RID: 319259 RVA: 0x001436D0 File Offset: 0x001418D0
		static readonly int dHpNK65uqp;

		// Token: 0x0404DF1C RID: 319260 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int BpE5BYwmYK;

		// Token: 0x0404DF1D RID: 319261 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int G3ptF3D43D;

		// Token: 0x0404DF1E RID: 319262 RVA: 0x001436D8 File Offset: 0x001418D8
		static readonly int pg98bDE2DA;

		// Token: 0x0404DF1F RID: 319263 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int XICSbbr9NJ;

		// Token: 0x0404DF20 RID: 319264 RVA: 0x001436B8 File Offset: 0x001418B8
		static readonly int Y2Xbbkc6IQ;

		// Token: 0x0404DF21 RID: 319265 RVA: 0x001436C0 File Offset: 0x001418C0
		static readonly int 2A1n9epFd7;

		// Token: 0x0404DF22 RID: 319266 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int U3iXx81WSn;

		// Token: 0x0404DF23 RID: 319267 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int MDrtpxJig0;

		// Token: 0x0404DF24 RID: 319268 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int lHtwHWRYT6;

		// Token: 0x0404DF25 RID: 319269 RVA: 0x001436D8 File Offset: 0x001418D8
		static readonly int wlfQzeT9od;

		// Token: 0x0404DF26 RID: 319270 RVA: 0x001436E0 File Offset: 0x001418E0
		static readonly int tFoeEzTH8L;

		// Token: 0x0404DF27 RID: 319271 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int UHjnVMJwPa;

		// Token: 0x0404DF28 RID: 319272 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int qcCV1kha4K;

		// Token: 0x0404DF29 RID: 319273 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int eK3DGfdOsS;

		// Token: 0x0404DF2A RID: 319274 RVA: 0x001436E8 File Offset: 0x001418E8
		static readonly int CKaHmoC24m;

		// Token: 0x0404DF2B RID: 319275 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int UgtNwQCSnd;

		// Token: 0x0404DF2C RID: 319276 RVA: 0x001436F0 File Offset: 0x001418F0
		static readonly int R2MxrKNfg0;

		// Token: 0x0404DF2D RID: 319277 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int t4E7YgC5tM;

		// Token: 0x0404DF2E RID: 319278 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int ipgSz7aqQz;

		// Token: 0x0404DF2F RID: 319279 RVA: 0x001436F8 File Offset: 0x001418F8
		static readonly int dLlOBJ8mab;

		// Token: 0x0404DF30 RID: 319280 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int bgWE3acwzP;

		// Token: 0x0404DF31 RID: 319281 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int OHja5mW37t;

		// Token: 0x0404DF32 RID: 319282 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int thOqXhT05O;

		// Token: 0x0404DF33 RID: 319283 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int iaeRvCScYZ;

		// Token: 0x0404DF34 RID: 319284 RVA: 0x00143700 File Offset: 0x00141900
		static readonly int fo0BlVlKSZ;

		// Token: 0x0404DF35 RID: 319285 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int xEors4RprV;

		// Token: 0x0404DF36 RID: 319286 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Gm1lrynRp3;

		// Token: 0x0404DF37 RID: 319287 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int T3fiOFqNEB;

		// Token: 0x0404DF38 RID: 319288 RVA: 0x00143708 File Offset: 0x00141908
		static readonly int 6Jhfadvwj0;

		// Token: 0x0404DF39 RID: 319289 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int umvDS2xPTx;

		// Token: 0x0404DF3A RID: 319290 RVA: 0x00143710 File Offset: 0x00141910
		static readonly int rUeZG4jGdm;

		// Token: 0x0404DF3B RID: 319291 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int NDkpZ7FVKN;

		// Token: 0x0404DF3C RID: 319292 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int D0syIqHbPV;

		// Token: 0x0404DF3D RID: 319293 RVA: 0x00143718 File Offset: 0x00141918
		static readonly int Sb4RTmoHZg;

		// Token: 0x0404DF3E RID: 319294 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int 4oT6nrBGnV;

		// Token: 0x0404DF3F RID: 319295 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int xbEGu1lpRZ;

		// Token: 0x0404DF40 RID: 319296 RVA: 0x00143720 File Offset: 0x00141920
		static readonly int wH1HUwJTVx;

		// Token: 0x0404DF41 RID: 319297 RVA: 0x00143728 File Offset: 0x00141928
		static readonly int T75oSYgvLa;

		// Token: 0x0404DF42 RID: 319298 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int oBx3h0Wyhc;

		// Token: 0x0404DF43 RID: 319299 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int A9z9uxxLl0;

		// Token: 0x0404DF44 RID: 319300 RVA: 0x00143718 File Offset: 0x00141918
		static readonly int isu0CzfZxV;

		// Token: 0x0404DF45 RID: 319301 RVA: 0x00143730 File Offset: 0x00141930
		static readonly int U0d0vuT7ke;

		// Token: 0x0404DF46 RID: 319302 RVA: 0x00143738 File Offset: 0x00141938
		static readonly int ZVv3wTI64f;

		// Token: 0x0404DF47 RID: 319303 RVA: 0x00143740 File Offset: 0x00141940
		static readonly int lVJU25R71r;

		// Token: 0x0404DF48 RID: 319304 RVA: 0x00143748 File Offset: 0x00141948
		static readonly int U6ALHKf8O9;

		// Token: 0x0404DF49 RID: 319305 RVA: 0x00143750 File Offset: 0x00141950
		static readonly int dzlHbM70Ds;

		// Token: 0x0404DF4A RID: 319306 RVA: 0x00143758 File Offset: 0x00141958
		static readonly int rjfRu9qI7z;

		// Token: 0x0404DF4B RID: 319307 RVA: 0x00143760 File Offset: 0x00141960
		static readonly int cWF2KcUjwm;

		// Token: 0x0404DF4C RID: 319308 RVA: 0x00143768 File Offset: 0x00141968
		static readonly int yJr4BvtC3p;

		// Token: 0x0404DF4D RID: 319309 RVA: 0x00143770 File Offset: 0x00141970
		static readonly int 8a3JAubtbH;

		// Token: 0x0404DF4E RID: 319310 RVA: 0x00143778 File Offset: 0x00141978
		static readonly int eWBZhHus69;

		// Token: 0x0404DF4F RID: 319311 RVA: 0x00143780 File Offset: 0x00141980
		static readonly int 2XEb3i2lP9;

		// Token: 0x0404DF50 RID: 319312 RVA: 0x00143788 File Offset: 0x00141988
		static readonly int PnPS0Bd62Z;

		// Token: 0x0404DF51 RID: 319313 RVA: 0x00143790 File Offset: 0x00141990
		static readonly int BkIoIcIRW4;

		// Token: 0x0404DF52 RID: 319314 RVA: 0x00143798 File Offset: 0x00141998
		static readonly int BAG3wlWcPb;

		// Token: 0x0404DF53 RID: 319315 RVA: 0x001437A0 File Offset: 0x001419A0
		static readonly int 2zdb21Gsjf;

		// Token: 0x0404DF54 RID: 319316 RVA: 0x001437A8 File Offset: 0x001419A8
		static readonly int ox0h8SPaTb;

		// Token: 0x0404DF55 RID: 319317 RVA: 0x001437B0 File Offset: 0x001419B0
		static readonly int akOV8OhWfP;

		// Token: 0x0404DF56 RID: 319318 RVA: 0x001437B8 File Offset: 0x001419B8
		static readonly int pAqbhLHqwR;

		// Token: 0x0404DF57 RID: 319319 RVA: 0x001437C0 File Offset: 0x001419C0
		static readonly int VZs1QNKi5e;

		// Token: 0x0404DF58 RID: 319320 RVA: 0x001437C8 File Offset: 0x001419C8
		static readonly int V5JyASlHdn;

		// Token: 0x0404DF59 RID: 319321 RVA: 0x001437D0 File Offset: 0x001419D0
		static readonly int UuNU0nHZAx;

		// Token: 0x0404DF5A RID: 319322 RVA: 0x001437D8 File Offset: 0x001419D8
		static readonly int KjoBFB2XFu;

		// Token: 0x0404DF5B RID: 319323 RVA: 0x001437E0 File Offset: 0x001419E0
		static readonly int E8aA3t11aO;

		// Token: 0x0404DF5C RID: 319324 RVA: 0x001437E8 File Offset: 0x001419E8
		static readonly int j9MI7lLXAm;

		// Token: 0x0404DF5D RID: 319325 RVA: 0x001437F0 File Offset: 0x001419F0
		static readonly int GviIUwRHt8;

		// Token: 0x0404DF5E RID: 319326 RVA: 0x001437F8 File Offset: 0x001419F8
		static readonly int ZNCsiWTNaG;

		// Token: 0x0404DF5F RID: 319327 RVA: 0x00143800 File Offset: 0x00141A00
		static readonly int vP8vNLWfEe;

		// Token: 0x0404DF60 RID: 319328 RVA: 0x00143808 File Offset: 0x00141A08
		static readonly int 0eWcoTZSqG;

		// Token: 0x0404DF61 RID: 319329 RVA: 0x00143810 File Offset: 0x00141A10
		static readonly int cuIbyW6ejl;

		// Token: 0x0404DF62 RID: 319330 RVA: 0x00143818 File Offset: 0x00141A18
		static readonly int R76410wx5I;

		// Token: 0x0404DF63 RID: 319331 RVA: 0x00143820 File Offset: 0x00141A20
		static readonly int awCPI51jDP;

		// Token: 0x0404DF64 RID: 319332 RVA: 0x00143828 File Offset: 0x00141A28
		static readonly int 6BhToAGh61;

		// Token: 0x0404DF65 RID: 319333 RVA: 0x00143830 File Offset: 0x00141A30
		static readonly int O15dM2hclx;

		// Token: 0x0404DF66 RID: 319334 RVA: 0x00143838 File Offset: 0x00141A38
		static readonly int hlXhqqs3T3;

		// Token: 0x0404DF67 RID: 319335 RVA: 0x00143840 File Offset: 0x00141A40
		static readonly int eXaUoQZnP0;

		// Token: 0x0404DF68 RID: 319336 RVA: 0x00143848 File Offset: 0x00141A48
		static readonly int uO1E4i0iCP;

		// Token: 0x0404DF69 RID: 319337 RVA: 0x00143850 File Offset: 0x00141A50
		static readonly int YZ8QsVoAn8;

		// Token: 0x0404DF6A RID: 319338 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int SNODW1alz6;

		// Token: 0x0404DF6B RID: 319339 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int d4MvDSuTmH;

		// Token: 0x0404DF6C RID: 319340 RVA: 0x00143858 File Offset: 0x00141A58
		static readonly int zJ0DeFZKlT;

		// Token: 0x0404DF6D RID: 319341 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int mZ9QhhAyrD;

		// Token: 0x0404DF6E RID: 319342 RVA: 0x00143860 File Offset: 0x00141A60
		static readonly int HPtGweMMMa;

		// Token: 0x0404DF6F RID: 319343 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int lUYfIIWKiR;

		// Token: 0x0404DF70 RID: 319344 RVA: 0x00143868 File Offset: 0x00141A68
		static readonly int cQ9gTD45Ng;

		// Token: 0x0404DF71 RID: 319345 RVA: 0x00143870 File Offset: 0x00141A70
		static readonly int R5li9kauRA;

		// Token: 0x0404DF72 RID: 319346 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int 2M7LsRBdHY;

		// Token: 0x0404DF73 RID: 319347 RVA: 0x00143878 File Offset: 0x00141A78
		static readonly int K0Pal1PMws;

		// Token: 0x0404DF74 RID: 319348 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jQ9qJptzgi;

		// Token: 0x0404DF75 RID: 319349 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int sm3hYPSxyC;

		// Token: 0x0404DF76 RID: 319350 RVA: 0x00143880 File Offset: 0x00141A80
		static readonly int CbxzVaqL7I;

		// Token: 0x0404DF77 RID: 319351 RVA: 0x00143888 File Offset: 0x00141A88
		static readonly int UN7ibmMRCC;

		// Token: 0x0404DF78 RID: 319352 RVA: 0x00143890 File Offset: 0x00141A90
		static readonly int iL7jqi7sBV;

		// Token: 0x0404DF79 RID: 319353 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int jcYuqIcKUs;

		// Token: 0x0404DF7A RID: 319354 RVA: 0x00143898 File Offset: 0x00141A98
		static readonly int 9h1YNeoUGw;

		// Token: 0x0404DF7B RID: 319355 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int DAvvd0dOIw;

		// Token: 0x0404DF7C RID: 319356 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int d7Jlj2zM2T;

		// Token: 0x0404DF7D RID: 319357 RVA: 0x00143880 File Offset: 0x00141A80
		static readonly int JC7UDAUjVL;

		// Token: 0x0404DF7E RID: 319358 RVA: 0x001438A0 File Offset: 0x00141AA0
		static readonly int 4mmPSirmQz;

		// Token: 0x0404DF7F RID: 319359 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int oOBiOBXPyV;

		// Token: 0x0404DF80 RID: 319360 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int pccxmADarc;

		// Token: 0x0404DF81 RID: 319361 RVA: 0x001438A8 File Offset: 0x00141AA8
		static readonly int g42721V3TA;

		// Token: 0x0404DF82 RID: 319362 RVA: 0x001438B0 File Offset: 0x00141AB0
		static readonly int KM5Do5BYFC;

		// Token: 0x0404DF83 RID: 319363 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int nEu9fbKynS;

		// Token: 0x0404DF84 RID: 319364 RVA: 0x001438B8 File Offset: 0x00141AB8
		static readonly int eQ5xSuVDpX;

		// Token: 0x0404DF85 RID: 319365 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int pe6yKcgZIr;

		// Token: 0x0404DF86 RID: 319366 RVA: 0x001438C0 File Offset: 0x00141AC0
		static readonly int 8oVozcJ2ba;

		// Token: 0x0404DF87 RID: 319367 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int qgQBf4RHu3;

		// Token: 0x0404DF88 RID: 319368 RVA: 0x001438B8 File Offset: 0x00141AB8
		static readonly int j7tsXIH6zD;

		// Token: 0x0404DF89 RID: 319369 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 5vp5Tz5Q70;

		// Token: 0x0404DF8A RID: 319370 RVA: 0x001438C8 File Offset: 0x00141AC8
		static readonly int kclOqIN5SQ;

		// Token: 0x0404DF8B RID: 319371 RVA: 0x001438D0 File Offset: 0x00141AD0
		static readonly int LYoPIB5mRr;

		// Token: 0x0404DF8C RID: 319372 RVA: 0x001438D8 File Offset: 0x00141AD8
		static readonly int UNDYf50Urp;

		// Token: 0x0404DF8D RID: 319373 RVA: 0x001438E0 File Offset: 0x00141AE0
		static readonly int 8BJ3SGVeBO;

		// Token: 0x0404DF8E RID: 319374 RVA: 0x001438E8 File Offset: 0x00141AE8
		static readonly int 5Mni1gGaxS;

		// Token: 0x0404DF8F RID: 319375 RVA: 0x001438F0 File Offset: 0x00141AF0
		static readonly int 4S8QgXZNtu;

		// Token: 0x0404DF90 RID: 319376 RVA: 0x001438F8 File Offset: 0x00141AF8
		static readonly int R3NmRKOv6B;

		// Token: 0x0404DF91 RID: 319377 RVA: 0x00143900 File Offset: 0x00141B00
		static readonly int palDvIjeg8;

		// Token: 0x0404DF92 RID: 319378 RVA: 0x00002120 File Offset: 0x00000320
		static readonly int zZgZvqC3X5;

		// Token: 0x0404DF93 RID: 319379 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int qIvQ6B8BRr;

		// Token: 0x0404DF94 RID: 319380 RVA: 0x00143908 File Offset: 0x00141B08
		static readonly int SVewmer4eY;

		// Token: 0x0404DF95 RID: 319381 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int x4qu51Wx1l;

		// Token: 0x0404DF96 RID: 319382 RVA: 0x00143910 File Offset: 0x00141B10
		static readonly int HVYAUgpUHu;

		// Token: 0x0404DF97 RID: 319383 RVA: 0x00143918 File Offset: 0x00141B18
		static readonly int JiNzqe5uwR;

		// Token: 0x0404DF98 RID: 319384 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int 8HY8HwbAVE;

		// Token: 0x0404DF99 RID: 319385 RVA: 0x00143920 File Offset: 0x00141B20
		static readonly int oLKpj66dbG;

		// Token: 0x0404DF9A RID: 319386 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int yXxuPPr1Ea;

		// Token: 0x0404DF9B RID: 319387 RVA: 0x00143928 File Offset: 0x00141B28
		static readonly int 6mAjnA7Z3i;

		// Token: 0x0404DF9C RID: 319388 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int Fo8DF7XiPt;

		// Token: 0x0404DF9D RID: 319389 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int hbTqclUnt2;

		// Token: 0x0404DF9E RID: 319390 RVA: 0x00143930 File Offset: 0x00141B30
		static readonly int Fj64HCKkCj;

		// Token: 0x0404DF9F RID: 319391 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int 9hk2BKYupR;

		// Token: 0x0404DFA0 RID: 319392 RVA: 0x00143938 File Offset: 0x00141B38
		static readonly int 1ImU3eSUHB;

		// Token: 0x0404DFA1 RID: 319393 RVA: 0x00143940 File Offset: 0x00141B40
		static readonly int qTpAdfsD5C;

		// Token: 0x0404DFA2 RID: 319394 RVA: 0x00143920 File Offset: 0x00141B20
		static readonly int xxfpu91apS;

		// Token: 0x0404DFA3 RID: 319395 RVA: 0x00002108 File Offset: 0x00000308
		static readonly int Mj8cA67lBm;

		// Token: 0x0404DFA4 RID: 319396 RVA: 0x000020B0 File Offset: 0x000002B0
		static readonly int u0cA3p1jZg;

		// Token: 0x0404DFA5 RID: 319397 RVA: 0x00143948 File Offset: 0x00141B48
		static readonly int bVzndEn7k3;

		// Token: 0x0404DFA6 RID: 319398 RVA: 0x00002070 File Offset: 0x00000270
		static readonly int n1ozzGVNAh;

		// Token: 0x0404DFA7 RID: 319399 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int hHCSS6UfvE;

		// Token: 0x0404DFA8 RID: 319400 RVA: 0x00002080 File Offset: 0x00000280
		static readonly int HRBJ01uU86;

		// Token: 0x0404DFA9 RID: 319401 RVA: 0x00143950 File Offset: 0x00141B50
		static readonly int TAAH92MnLx;

		// Token: 0x0404DFAA RID: 319402 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int Toj28USgUh;

		// Token: 0x0404DFAB RID: 319403 RVA: 0x00143958 File Offset: 0x00141B58
		static readonly int tILgvVze87;

		// Token: 0x0404DFAC RID: 319404 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int VAOENhG4TZ;

		// Token: 0x0404DFAD RID: 319405 RVA: 0x00002078 File Offset: 0x00000278
		static readonly int urT8udsJLg;

		// Token: 0x0404DFAE RID: 319406 RVA: 0x00143960 File Offset: 0x00141B60
		static readonly int iOAbMLyeWn;

		// Token: 0x0404DFAF RID: 319407 RVA: 0x00143950 File Offset: 0x00141B50
		static readonly int CroNbTZeoa;

		// Token: 0x0404DFB0 RID: 319408 RVA: 0x00143968 File Offset: 0x00141B68
		static readonly int NYN5wCyNvS;

		// Token: 0x0404DFB1 RID: 319409 RVA: 0x00143970 File Offset: 0x00141B70
		static readonly int npTcYHAx1C;

		// Token: 0x0404DFB2 RID: 319410 RVA: 0x00143960 File Offset: 0x00141B60
		static readonly int tmiqXDCFgb;

		// Token: 0x0404DFB3 RID: 319411 RVA: 0x00143978 File Offset: 0x00141B78
		static readonly int DNfuTKAFpK;
	}
}
